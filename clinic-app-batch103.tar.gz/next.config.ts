import type { NextConfig } from "next";

// رفع ملفات المرضى لم يعد يمر عبر Server Actions أو نسخة الـproxy المحفوظة
// في الذاكرة؛ له endpoint متدفق إلى القرص، لذلك لا يحتاج حدًا مجمعًا هنا.
const nextConfig: NextConfig = {
  // طبقة دفاع ثانية على مستوى التطبيق نفسه — مستقلة عن أي إعداد في Nginx،
  // فتفضل شغالة حتى لو الإعداد ده اتغير أو السيرفر اتنقل.
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          // يمنع المتصفح من "تخمين" نوع الملف ويشغّله كحاجة تانية — مهم تحديدًا
          // لراوت /patient-files اللي بيقدّم صور وملفات PDF مرفوعة.
          { key: "X-Content-Type-Options", value: "nosniff" },
          // يمنع وضع النظام داخل إطار في موقع تاني (clickjacking).
          { key: "X-Frame-Options", value: "DENY" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          // النظام مش بيحتاج كاميرا/ميكروفون/موقع من المتصفح.
          { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), interest-cohort=()" },
          // HTTPS إجباري لمدة سنة. آمن هنا لأن النظام بيتفتح عبر النطاق
          // بـHTTPS بالفعل — لو اتفتح على http محلي المتصفح بيتجاهل الهيدر ده.
          { key: "Strict-Transport-Security", value: "max-age=31536000; includeSubDomains" },
        ],
      },
    ];
  },
};

export default nextConfig;
