import "server-only";
import { cookies } from "next/headers";
import { cache } from "react";
import { db } from "./db/client";
import { SESSION_COOKIE, verifySessionToken, type SessionPayload } from "./auth";

// التوكن بيتوقّع مرة واحدة وقت الدخول وصالح 12 ساعة، وبيحمل جواه role و
// doctorId. من غير الخطوة اللي تحت، إيقاف موظف (active=0) أو تغيير دوره أو
// تصفير كلمة سره مكانش بيأثر على جلسته المفتوحة لحد 12 ساعة كاملة.
//
// الحل الأبسط: نقرأ صف المستخدم من قاعدة البيانات مع كل طلب ونستخدم القيم
// الحقيقية بدل اللي في التوكن. ده استعلام واحد على مفتاح أساسي في SQLite
// محلية — تكلفته صفر عمليًا، والصلاحيات أصلاً بتتقرا بنفس الطريقة في
// lib/permissions.ts. الـcache() بتاعة React بتخلي الاستعلام يحصل مرة واحدة
// بس في الطلب الواحد مهما اتنادت getSession كام مرة.
const loadLiveUser = cache(async (userId: number) => {
  return db
    .selectFrom("users")
    .select(["id", "username", "full_name", "role", "doctor_id", "active", "must_change_password"])
    .where("id", "=", userId)
    .executeTakeFirst();
});

export async function getSession(): Promise<SessionPayload | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;

  const payload = await verifySessionToken(token);
  if (!payload) return null;

  const user = await loadLiveUser(payload.userId);
  // الحساب اتوقف أو اتمسح؟ الجلسة تبقى منتهية فورًا.
  if (!user || user.active !== 1) return null;

  return {
    userId: user.id,
    username: user.username,
    fullName: user.full_name,
    role: user.role,
    doctorId: user.doctor_id,
    mustChangePassword: user.must_change_password === 1,
  };
}
