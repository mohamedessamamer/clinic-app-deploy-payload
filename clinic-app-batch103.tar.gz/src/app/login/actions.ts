"use server";

import { cookies, headers } from "next/headers";
import { sql } from "kysely";
import { db } from "@/lib/db/client";
import { DEFAULT_PASSWORD, SESSION_COOKIE, createSessionToken, verifyPassword } from "@/lib/auth";
import { getLoginLockState, recordLoginAttempt } from "@/lib/login-attempts";

export type LoginState = {
  error?: "missing" | "invalid" | "locked";
  minutesLeft?: number;
  redirectTo?: string;
};

// NOTE: We intentionally do NOT call redirect() from inside this Server
// Action. Next.js's fetch-based Server Action redirect path (used whenever
// the client has JS enabled) resolves the redirect via an internal loopback
// request and then copies that loopback response's headers onto the outer
// response - but it explicitly excludes `set-cookie` when doing so. That
// silently drops the session cookie we just set a few lines above, which is
// why the browser looked logged-out immediately after a successful login.
// Returning state and letting the client navigate avoids that code path
// entirely: the Set-Cookie header rides on this action's own direct
// response, which does not go through the loopback-and-strip logic.
export async function loginAction(
  _prevState: LoginState,
  formData: FormData
): Promise<LoginState> {
  const username = String(formData.get("username") || "").trim();
  const password = String(formData.get("password") || "");
  const next = String(formData.get("next") || "/");

  if (!username || !password) {
    return { error: "missing" };
  }

  // القفل بيتفحص قبل أي لمسة لقاعدة بيانات المستخدمين أو أي مقارنة bcrypt.
  const lock = await getLoginLockState(username);
  if (lock.locked) {
    return { error: "locked", minutesLeft: lock.minutesLeft };
  }

  const user = await db
    .selectFrom("users")
    .selectAll()
    // Karim / karim / KARIM هم نفس اسم المستخدم عند الدخول.
    .where(sql<string>`lower(username)`, "=", username.toLowerCase())
    .where("active", "=", 1)
    .executeTakeFirst();

  if (!user || !(await verifyPassword(password, user.password_hash))) {
    await recordLoginAttempt(username, false);
    return { error: "invalid" };
  }

  await recordLoginAttempt(username, true);

  // الحساب لسه على كلمة السر الافتراضية؟ نعرف ده هنا بالظبط لأن ده المكان
  // الوحيد اللي بيوصله النص الصريح لكلمة السر. بنكتب النتيجة في قاعدة البيانات
  // بدل ما نحطها في التوكن، عشان الحالة تفضل صح حتى لو الجلسة اتجددت، وعشان
  // الحساب اللي غيّر كلمة سره قبل كده يتصحّح لوحده أول دخول من غير أي تخمين.
  const usingDefaultPassword = password === DEFAULT_PASSWORD;
  if ((user.must_change_password === 1) !== usingDefaultPassword) {
    await db
      .updateTable("users")
      .set({ must_change_password: usingDefaultPassword ? 1 : 0 })
      .where("id", "=", user.id)
      .execute();
  }

  const token = await createSessionToken({
    userId: user.id,
    username: user.username,
    fullName: user.full_name,
    role: user.role,
    doctorId: user.doctor_id,
    mustChangePassword: usingDefaultPassword,
  });

  // Only mark the cookie Secure when the request actually arrived over HTTPS.
  // Browsers silently refuse to store Secure cookies on a plain-HTTP connection,
  // which (before this fix) caused every post-login request to look logged-out.
  const hdrs = await headers();
  const isHttps = hdrs.get("x-forwarded-proto") === "https";

  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: isHttps,
    path: "/",
    maxAge: 60 * 60 * 12,
  });

  // "//example.com" بيبدأ بـ"/" لكن المتصفح بيقراه كعنوان خارجي كامل — لازم
  // يترفض، وإلا بقى رابط /login?next=... أداة تحويل لموقع تصيّد من نطاق العيادة.
  const safeNext = next.startsWith("/") && !next.startsWith("//") ? next : "/";

  // كل دخول بكلمة السر الافتراضية بينزل على صفحة تغيير كلمة السر. قبل الموعد
  // النهائي فيها زرار "تخطي الآن" بيكمّل للوجهة الأصلية، وبعده التخطي بيختفي.
  if (usingDefaultPassword) {
    return { redirectTo: `/change-password?next=${encodeURIComponent(safeNext)}` };
  }

  return { redirectTo: safeNext };
}
