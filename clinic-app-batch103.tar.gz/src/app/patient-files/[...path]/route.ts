import { NextRequest, NextResponse } from "next/server";
import fs from "node:fs/promises";
import path from "node:path";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";

// بيقرأ صور/أشعة المرضى من القرص وقت الطلب نفسه، بدل ما يعتمد على مجلد "public"
// اللي Next.js بياخد له "لقطة" (snapshot) لأسماء الملفات مرة واحدة بس وقت ما
// السيرفر يشتغل — يعني أي صورة تترفع بعد كده (من غير إعادة تشغيل/نشر) كانت
// هترجع 404 دايمًا لحد أول إعادة تشغيل تالية. الراوت ده بيتجنب المشكلة دي
// تمامًا لأنه بيقرأ من القرص فعليًا في كل طلب.
const UPLOAD_ROOT = process.env.CLINIC_UPLOAD_DIR
  ? path.resolve(process.env.CLINIC_UPLOAD_DIR)
  : path.join(process.cwd(), "data", "uploads");

const CONTENT_TYPES: Record<string, string> = {
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".gif": "image/gif",
  ".webp": "image/webp",
  ".pdf": "application/pdf",
};

export async function GET(_req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  const session = await getSession();
  if (!session) {
    return new NextResponse("غير مصرح", { status: 401 });
  }

  const { path: segments } = await params;

  // مستندات HR (عقود، صور بطاقات، مستندات رواتب) بتتخزن تحت نفس جذر الرفع
  // وبيخدمها نفس الراوت ده. رفعها بيطلب manage_hr — فقراءتها لازم تطلبها كمان،
  // وإلا أي مستخدم مسجّل دخول يقدر يفتحها بمجرد معرفة الرابط.
  // صور وأشعة المرضى فاضلة متاحة لأي مستخدم مسجّل دخول زي ما هي، عشان
  // الاستقبال والدكاترة بيتعاملوا معاها فعلاً وأي تضييق هنا ممكن يكسر شارت
  // التقويم — لو حبيت نقفلها كمان دي دفعة منفصلة تحتاج مراجعة مين محتاجها.
  if (segments[0] === "hr-documents") {
    if (!(await hasPermission(session.userId, session.role, "manage_hr"))) {
      return new NextResponse("غير مصرح", { status: 403 });
    }
  }

  // امنع أي محاولة صعود لمجلد أعلى (زي "..") عشان محدش يقدر يقرأ ملفات برة
  // مجلد الرفع المخصص.
  if (!segments.length || segments.some((s) => !s || s === "." || s === "..")) {
    return new NextResponse("غير موجود", { status: 404 });
  }

  const filePath = path.join(UPLOAD_ROOT, ...segments);
  if (filePath !== UPLOAD_ROOT && !filePath.startsWith(UPLOAD_ROOT + path.sep)) {
    return new NextResponse("غير موجود", { status: 404 });
  }

  try {
    const data = await fs.readFile(filePath);
    const ext = path.extname(filePath).toLowerCase();
    const contentType = CONTENT_TYPES[ext] || "application/octet-stream";
    return new NextResponse(new Uint8Array(data), {
      headers: {
        "Content-Type": contentType,
        "Cache-Control": "private, max-age=3600",
      },
    });
  } catch {
    return new NextResponse("غير موجود", { status: 404 });
  }
}
