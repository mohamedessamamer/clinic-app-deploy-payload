import Link from "next/link";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getClinicToday } from "@/lib/clinic-date";
import { EXPENSE_CATEGORIES, EXPENSE_CATEGORY_LABELS, ensureRecurringExpensesForMonth, getExpenseSummary, monthBounds } from "@/lib/expenses";
import { calculateHrPayroll, getCollectedAfterLab } from "@/lib/hr-payroll";
import { PAYMENT_METHODS, paymentMethodLabel } from "@/lib/payment-methods";
import { addExpenseAction, addExpenseTemplateAction, deleteExpenseTemplateAction, stopExpenseTemplateAction, updateExpenseTemplateAction } from "./actions";
import DeleteExpenseButton from "@/components/DeleteExpenseButton";
import HrPayrollTable from "@/components/HrPayrollTable";
import ClearExpensesDataButton from "@/components/ClearExpensesDataButton";

function validDate(value?: string) { return !!value && /^\d{4}-\d{2}-\d{2}$/.test(value); }
function previousMonth(month: string) {
  const [year, monthNumber] = month.split("-").map(Number);
  const date = new Date(Date.UTC(year, monthNumber - 2, 1));
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;
}

// رسايل الفشل اللي كانت صامتة — بتوصل في ?err= من expenseError في actions.ts.
const EXPENSE_ERRORS: Record<string, string> = {
  category: "اختار بند مصروف صحيح (بند المرتبات بيتسجل من شاشة HR).",
  title: "لازم تكتب اسم/بيان المصروف.",
  amount: "المبلغ لازم يكون رقم أكبر من صفر.",
  date: "التاريخ غير صحيح.",
  daterange: "تاريخ النهاية لازم يكون بعد تاريخ البداية.",
  service: "الخدمة المختارة مش موجودة.",
  labdouble: "الخدمة دي تكلفة معملها بتتخصم تلقائيًا — تسجيلها هنا كمان هيخصمها مرتين.",
  template: "البند المتكرر ده مش موجود.",
  already: "البند ده متسجل بالفعل للفترة دي.",
  person: "اختار الشخص الأول.",
  norule: "مفيش قاعدة راتب معرّفة للشخص ده — عرّفها من شاشة HR أول.",
  alreadypaid: "الكشف ده مدفوع بالفعل ومينفعش يتعدل.",
  run: "الكشف ده مش موجود.",
  zerorun: "الكشف قيمته صفر — راجع قاعدة الراتب أو الفترة قبل الصرف.",
};

export default async function ExpensesPage({ searchParams }: { searchParams: Promise<{ month?: string; from?: string; to?: string; err?: string }> }) {
  const session = await getSession();
  const canManage = session ? await hasPermission(session.userId, session.role, "manage_expenses") : false;
  if (!session || !canManage) return <div className="card-3d rounded-xl p-5 text-sm text-muted">مفيش صلاحية عندك لعرض المصروفات.</div>;
  const canClearData = await hasPermission(session.userId, session.role, "clear_expenses_data");

  const params = await searchParams;
  const errorMessage = params.err ? EXPENSE_ERRORS[params.err] || "البيانات غير مكتملة أو غير صحيحة." : null;
  const today = getClinicToday();
  const currentMonth = today.slice(0, 7);
  const selectedMonth = monthBounds(params.month ?? "") ? params.month! : null;
  const customFrom = validDate(params.from) ? params.from! : null;
  const customTo = validDate(params.to) ? params.to! : null;
  const monthlyRange = monthBounds(selectedMonth ?? currentMonth)!;
  const from = customFrom && customTo && customFrom <= customTo ? customFrom : monthlyRange.from;
  const to = customFrom && customTo && customFrom <= customTo ? customTo : monthlyRange.to;
  const fullMonth = !customFrom && !customTo;
  const activeMonth = fullMonth ? (selectedMonth ?? currentMonth) : null;
  if (activeMonth) await ensureRecurringExpensesForMonth(activeMonth, session.userId);
  const currentMonthRange = monthBounds(currentMonth)!;
  const previousMonthRange = monthBounds(previousMonth(currentMonth))!;

  const [expenses, templates, summary, doctors, staff, patients, services, rules, runs] = await Promise.all([
    db.selectFrom("expenses").selectAll().where("expense_date", ">=", from).where("expense_date", "<=", to).orderBy("expense_date", "desc").orderBy("id", "desc").execute(),
    db.selectFrom("expense_templates").selectAll().orderBy("active", "desc").orderBy("category").orderBy("title").execute(),
    getExpenseSummary(from, to),
    db.selectFrom("doctors").select(["id", "full_name", "active"]).orderBy("full_name").execute(),
    db.selectFrom("hr_staff").select(["id", "full_name", "active"]).orderBy("full_name").execute(),
    db.selectFrom("patients").select(["id", "full_name", "file_number"]).orderBy("full_name").execute(),
    db.selectFrom("services").select(["id", "name", "code", "has_lab_cost", "lab_cost"]).orderBy("name").execute(),
    db.selectFrom("hr_compensation_rules").selectAll().where("active", "=", 1).where("effective_from", "<=", to).where((eb) => eb.or([eb("effective_to", "is", null), eb("effective_to", ">=", from)])).execute(),
    db.selectFrom("hr_payroll_runs").selectAll().where("period_from", "=", from).where("period_to", "=", to).execute(),
  ]);
  // استحقاقات الأطباء/الموظفين المعروضة تقتصر على النشط منهم فقط. مين بقى غير
  // نشط (تم إيقافه من الإعدادات أو من HR) يختفي من هذا الجدول، حتى لو كانت
  // قاعدته لسه active=1 من فترة عمله؛ مصروفاته المصروفة فعليًا محفوظة في
  // سجل expenses بشكل منفصل ومش بتتأثر بده.
  const doctorNames = new Map(doctors.filter((person) => person.active === 1).map((person) => [person.id, person.full_name]));
  const staffNames = new Map(staff.filter((person) => person.active === 1).map((person) => [person.id, person.full_name]));
  const runMap = new Map(runs.map((run) => [`${run.person_type}-${run.person_id}`, run]));
  let clinicCollection: Awaited<ReturnType<typeof getCollectedAfterLab>> | null = null;
  const payrollRows = await Promise.all(rules.map(async (rule) => {
    const key = `${rule.person_type}-${rule.person_id}`;
    const name = rule.person_type === "doctor" ? doctorNames.get(rule.person_id) : staffNames.get(rule.person_id);
    if (!name) return null;
    const run = runMap.get(key);
    let collection;
    if (rule.percentage_basis === "personal" && rule.person_type === "doctor") collection = await getCollectedAfterLab(from, to, rule.person_id);
    else { clinicCollection ??= await getCollectedAfterLab(from, to, null); collection = clinicCollection; }
    const preview = calculateHrPayroll(rule, collection.netCollected, run?.shift_count ?? 0);
    return { key, name, rule, run, collection, preview, personType: rule.person_type, personId: rule.person_id, group: rule.staff_group, gross: collection.grossCollected, lab: collection.labCost, net: collection.netCollected };
  }));
  const visiblePayrollRows = payrollRows.filter((row): row is NonNullable<typeof row> => !!row);
  const payrollTotal = visiblePayrollRows.reduce((sum, row) => sum + (row.run?.total_amount ?? row.preview.totalAmount), 0);
  const collected = (clinicCollection ?? await getCollectedAfterLab(from, to, null)).grossCollected;

  return <div className="space-y-6">{errorMessage && <p className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{errorMessage}</p>}
    <style>{`select[name="category"] option[value="salary"]{display:none}`}</style>
    <div className="flex items-start justify-between gap-4 flex-wrap"><div><h1 className="text-2xl font-bold">المصروفات والرواتب</h1><p className="mt-1 text-sm text-muted">من {from} إلى {to}. البنود المتكررة غير الخاصة بالرواتب تُضاف تلقائيًا عند فتح الشهر.</p></div><div className="flex flex-wrap gap-2"><Link href={`/expenses?month=${currentMonth}`} className="rounded-md btn-3d-primary px-3 py-2 text-sm">الشهر الحالي</Link><Link href={`/expenses?month=${previousMonth(currentMonth)}`} className="rounded-md border border-border px-3 py-2 text-sm hover:bg-primary-soft">الشهر الماضي</Link>{canClearData && <ClearExpensesDataButton currentRange={{ from, to }} currentMonthRange={currentMonthRange} previousMonthRange={previousMonthRange} />}</div></div>

    <form className="card-3d rounded-xl p-4 flex flex-wrap items-end gap-3"><label><span className="block text-xs text-muted mb-1">من</span><input name="from" type="date" defaultValue={from} className="rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">إلى</span><input name="to" type="date" defaultValue={to} className="rounded border border-border bg-background px-2 py-2 text-sm" /></label><button className="rounded-md border border-primary px-4 py-2 text-sm text-primary hover:bg-primary-soft">عرض الفترة</button></form>

    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4"><div className="card-3d rounded-xl p-4"><div className="text-xs text-muted">المحصّل فعليًا</div><div className="text-2xl font-bold text-primary">{collected.toFixed(0)} ج.م</div></div><div className="card-3d rounded-xl p-4"><div className="text-xs text-muted">المصروفات المسجلة</div><div className="text-2xl font-bold text-danger">{summary.total.toFixed(0)} ج.م</div></div><div className="card-3d rounded-xl p-4"><div className="text-xs text-muted">استحقاقات العاملين</div><div className="text-2xl font-bold">{payrollTotal.toFixed(0)} ج.م</div></div><div className="card-3d rounded-xl p-4"><div className="text-xs text-muted">صافي النقدية بعد المصروفات</div><div className={`text-2xl font-bold ${collected - summary.total >= 0 ? "text-primary" : "text-danger"}`}>{(collected - summary.total).toFixed(0)} ج.م</div></div></div>

    <HrPayrollTable rows={visiblePayrollRows.map(({ key, name, rule, run, gross, lab, net, personType, personId, group }) => ({ key, name, rule, run: run ? { id: run.id, shift_count: run.shift_count, fixed_amount: run.fixed_amount, percentage_amount: run.percentage_amount, incentives: run.incentives, deductions: run.deductions, total_amount: run.total_amount, status: run.status, paid_date: run.paid_date } : null, gross, lab, net, personType, personId, group }))} from={from} to={to} today={today} />

    <section className="card-3d rounded-xl p-5 space-y-4"><div><h2 className="font-semibold">مصروف معمل يدوي</h2><p className="mt-1 text-xs text-muted">استخدمه فقط عندما لا تكون تكلفة المعمل معرّفة داخل الخدمة. ربطه بالطبيب يجعله يُخصم من تحصيله قبل حساب النسبة.</p></div><form action={addExpenseAction} className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 items-end"><input type="hidden" name="category" value="lab" /><label><span className="block text-xs text-muted mb-1">التاريخ</span><input name="expense_date" type="date" required defaultValue={today} className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">الطبيب *</span><select name="doctor_id" required className="w-full rounded border border-border bg-background px-2 py-2 text-sm"><option value="">اختر الطبيب</option>{doctors.filter((doctor) => doctor.active === 1).map((doctor) => <option key={doctor.id} value={doctor.id}>{doctor.full_name}</option>)}</select></label><label><span className="block text-xs text-muted mb-1">المريض (اختياري)</span><select name="patient_id" className="w-full rounded border border-border bg-background px-2 py-2 text-sm"><option value="">غير محدد</option>{patients.map((patient) => <option key={patient.id} value={patient.id}>{patient.full_name} — {patient.file_number}</option>)}</select></label><label><span className="block text-xs text-muted mb-1">الخدمة (اختياري)</span><select name="service_id" className="w-full rounded border border-border bg-background px-2 py-2 text-sm"><option value="">غير معرفة</option>{services.map((service) => <option key={service.id} value={service.id}>{service.name}{service.has_lab_cost ? ` — معرفة ${service.lab_cost} ج.م` : ""}</option>)}</select></label><label><span className="block text-xs text-muted mb-1">البيان *</span><input name="title" required placeholder="مثال: معمل كراون زيركون" className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">التكلفة *</span><input name="amount" type="number" min="0.01" step="0.01" required className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">المعمل</span><input name="payee" placeholder="اسم المعمل" className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">ملاحظة</span><input name="note" className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><button className="rounded-md btn-3d-primary px-4 py-2 text-sm">حفظ تكلفة المعمل</button></form></section>

    <section className="card-3d rounded-xl p-5 space-y-4"><div><h2 className="font-semibold">البنود المتكررة</h2><p className="mt-1 text-xs text-muted">الإيجار والمصاريف الثابتة تُضاف تلقائيًا أول الشهر. مرتبات الأشخاص تُدار من HR لمنع التكرار.</p></div><form action={addExpenseTemplateAction} className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-3 items-end"><label><span className="block text-xs text-muted mb-1">البند</span><input name="title" required className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">التصنيف</span><select name="category" defaultValue="fixed" className="w-full rounded border border-border bg-background px-2 py-2 text-sm">{["fixed", "other"].map((category) => <option key={category} value={category}>{EXPENSE_CATEGORY_LABELS[category as keyof typeof EXPENSE_CATEGORY_LABELS]}</option>)}</select></label><label><span className="block text-xs text-muted mb-1">القيمة</span><input name="default_amount" type="number" min="0.01" step="0.01" required className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">المدفوع له</span><input name="payee" className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">تسري من</span><input name="effective_from" type="date" required defaultValue={today} className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><button className="rounded border border-primary px-4 py-2 text-sm text-primary">إضافة بند متكرر</button></form><div className="space-y-2">{templates.map((template) => <details key={template.id} className="rounded-lg border border-border p-3" open={false}><summary className="cursor-pointer text-sm"><b>{template.title}</b> — {template.default_amount.toFixed(0)} ج.م <span className={template.active ? "text-primary" : "text-muted"}>({template.active ? "نشط" : "متوقف"})</span></summary><form action={updateExpenseTemplateAction} className="mt-3 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-6 gap-2 items-end"><input type="hidden" name="template_id" value={template.id} /><input name="title" defaultValue={template.title} required className="rounded border border-border bg-background px-2 py-1.5 text-sm" /><select name="category" defaultValue={template.category} className="rounded border border-border bg-background px-2 py-1.5 text-sm">{["fixed", "other", "salary"].map((category) => <option key={category} value={category}>{EXPENSE_CATEGORY_LABELS[category as keyof typeof EXPENSE_CATEGORY_LABELS]}</option>)}</select><input name="default_amount" type="number" min="0.01" step="0.01" defaultValue={template.default_amount} required className="rounded border border-border bg-background px-2 py-1.5 text-sm" /><input name="payee" defaultValue={template.payee ?? ""} placeholder="المدفوع له" className="rounded border border-border bg-background px-2 py-1.5 text-sm" /><input name="effective_from" type="date" required defaultValue={template.effective_from ?? today} className="rounded border border-border bg-background px-2 py-1.5 text-sm" /><input name="effective_to" type="date" defaultValue={template.effective_to ?? ""} className="rounded border border-border bg-background px-2 py-1.5 text-sm" /><button className="rounded border border-border px-3 py-1.5 text-sm">حفظ التعديل</button></form><div className="mt-2 flex gap-3">{template.active === 1 && <form action={stopExpenseTemplateAction}><input type="hidden" name="template_id" value={template.id} /><button className="text-xs text-amber-700 hover:underline">إيقاف من الآن</button></form>}<form action={deleteExpenseTemplateAction}><input type="hidden" name="template_id" value={template.id} /><button className="text-xs text-danger hover:underline">حذف{template.active ? " / إيقاف مع حفظ القديم" : ""}</button></form></div></details>)}{templates.length === 0 && <p className="text-sm text-muted">لا توجد بنود متكررة.</p>}</div></section>

    <section className="card-3d rounded-xl p-5 space-y-3"><h2 className="font-semibold">تسجيل مصروف آخر</h2><form action={addExpenseAction} className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 items-end"><label><span className="block text-xs text-muted mb-1">التاريخ</span><input name="expense_date" type="date" required defaultValue={today} className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">التصنيف</span><select name="category" defaultValue="petty" className="w-full rounded border border-border bg-background px-2 py-2 text-sm">{EXPENSE_CATEGORIES.filter((category) => category !== "lab").map((category) => <option key={category} value={category}>{EXPENSE_CATEGORY_LABELS[category]}</option>)}</select></label><label><span className="block text-xs text-muted mb-1">البند</span><input name="title" required className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">المبلغ</span><input name="amount" type="number" min="0.01" step="0.01" required className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">المدفوع له</span><input name="payee" className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">وسيلة الدفع</span><select name="payment_method" defaultValue="cash" className="w-full rounded border border-border bg-background px-2 py-2 text-sm">{PAYMENT_METHODS.map((method) => <option key={method.value} value={method.value}>{method.label}</option>)}</select></label><label className="sm:col-span-2"><span className="block text-xs text-muted mb-1">ملاحظة</span><input name="note" className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><button className="rounded-md btn-3d-primary px-4 py-2 text-sm">حفظ المصروف</button></form></section>

    <section className="card-3d rounded-xl overflow-hidden"><div className="px-4 py-3 font-semibold">مصروفات الفترة</div><div className="overflow-x-auto"><table className="w-full text-sm"><thead className="bg-primary-soft text-primary-dark"><tr><th className="px-3 py-2 text-right">التاريخ</th><th className="px-3 py-2 text-right">التصنيف</th><th className="px-3 py-2 text-right">البند</th><th className="px-3 py-2 text-right">المدفوع له</th><th className="px-3 py-2 text-right">المبلغ</th><th className="px-3 py-2 text-right">الدفع</th><th className="px-3 py-2 text-right">ملاحظة</th><th /></tr></thead><tbody>{expenses.map((expense) => <tr key={expense.id} className="border-t border-border"><td className="px-3 py-2 whitespace-nowrap">{expense.expense_date}</td><td className="px-3 py-2">{EXPENSE_CATEGORY_LABELS[expense.category as keyof typeof EXPENSE_CATEGORY_LABELS] ?? expense.category}</td><td className="px-3 py-2 font-medium">{expense.title}</td><td className="px-3 py-2">{expense.payee ?? "-"}</td><td className="px-3 py-2 text-danger">{expense.amount.toFixed(0)} ج.م</td><td className="px-3 py-2">{paymentMethodLabel(expense.payment_method)}</td><td className="px-3 py-2 text-muted">{expense.note ?? "-"}</td><td className="px-3 py-2">{["manual", "template"].includes(expense.source_type) && <DeleteExpenseButton expenseId={expense.id} label={expense.title} />}</td></tr>)}{expenses.length === 0 && <tr><td colSpan={8} className="px-3 py-7 text-center text-muted">لا توجد مصروفات في الفترة.</td></tr>}</tbody></table></div></section>
  </div>;
}
