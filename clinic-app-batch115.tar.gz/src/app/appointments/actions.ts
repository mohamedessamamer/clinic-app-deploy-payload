"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { logAdminEvent } from "@/lib/audit";
import { notifyDoctorOfCancellation } from "@/lib/notifications";
import { applyGeneralConsumablesForCompletedAppointment } from "@/lib/inventory-stock";
import { evaluateInventoryReorderNeeds } from "@/lib/inventory-reorder";
import { getClinicToday } from "@/lib/clinic-date";
import { computeNeedsNewPhotosMap } from "@/lib/photo-reminder";
import { computeConsultantReminderMap } from "@/lib/consultant-reminder";
import { normalizePhoneNumber } from "@/lib/phone";
import { autoCloseReferralTasksForAppointment } from "@/lib/tasks";
import { canEditAppointmentSlot } from "@/lib/appointment-edit";
import { reactivatePatientForCare } from "@/lib/patient-archive";

export type BookingPatientSearchResult = {
  id: number;
  full_name: string;
  file_number: string;
  birth_date: string | null;
  phone: string | null;
  needs_new_photos: boolean;
  needs_consultant_visit: boolean;
  consultant_name: string | null;
};

// بحث المريض في بوكس "حجز موعد" بالجدول المركزي — كان بيدور في نسخة محملة
// مسبقًا من أحدث 500 مريض بس (memory filter)، فمريض قديم برقم ملف صغير كان
// مايظهرش في نتيجة البحث خالص. هنا بندوّر في كل جدول المرضى مباشرة بكويري
// LIKE (مفهرس على الاسم/رقم الملف/التليفون) بدل ما نحمّل الجدول كله في
// الذاكرة — نفس منطق المطابقة المستخدم في صفحة "ملفات المرضى" (بحث %term%
// على full_name/file_number/phone).
export async function searchPatientsForBookingAction(query: string): Promise<BookingPatientSearchResult[]> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "schedule_edit"))) return [];

  const term = query.trim();
  if (!term) return [];
  const like = `%${term}%`;
  const phoneDigits = normalizePhoneNumber(term);
  const phoneLike = phoneDigits ? `%${phoneDigits}%` : null;

  const rows = await db
    .selectFrom("patients")
    .select(["id", "full_name", "file_number", "birth_date", "phone"])
    .where((eb) => {
      const conditions = [eb("full_name", "like", like), eb("file_number", "like", like)];
      if (phoneLike) conditions.push(eb("phone", "like", phoneLike));
      return eb.or(conditions);
    })
    .orderBy("id", "desc")
    .limit(8)
    .execute();
  if (rows.length === 0) return [];

  const ids = rows.map((r) => r.id);
  const [needsPhotosMap, consultantReminderMap] = await Promise.all([
    computeNeedsNewPhotosMap(ids),
    computeConsultantReminderMap(ids),
  ]);

  return rows.map((r) => ({
    ...r,
    needs_new_photos: needsPhotosMap.get(r.id) ?? false,
    needs_consultant_visit: consultantReminderMap.get(r.id)?.needsConsultantVisit ?? false,
    consultant_name: consultantReminderMap.get(r.id)?.consultantName ?? null,
  }));
}

// "المريض جاي يعمل إيه" (دفعة 26) — بيتقرأ من الفورم وبيترجع الشكل الجاهز للحفظ،
// أو null لو مفيش اختيار (يفضل الحقل فاضي، سلوك قديم زي ما هو). مستخدمة في الحجز
// وفي تعديل الموعد بعد كده (نفس القواعد في المكانين).
//
// دفعة 27 (P3.2): حقل رابع اختياري purpose_linked_invoice_id — لو الاستقبال ربط
// الاختيار (تقويم/عام "متابعة") بفاتورة مفتوحة فعلية من القائمة الجديدة. بيتحقق
// هنا (مش مجرد ثقة في الفورم) إن الفاتورة دي فعلاً بتاعة نفس المريض ولسه فاتورة
// أصلية مفتوحة (parent_invoice_id فاضي)، عشان مايحصلش خلط بيانات بين مرضى.
async function readPurpose(
  formData: FormData,
  patientId: number
): Promise<{
  purpose_type: "bonding_upper" | "bonding_lower" | "service" | null;
  purpose_service_id: number | null;
  purpose_linked_invoice_id: number | null;
}> {
  const raw = String(formData.get("purpose_type") || "");
  const linkedRaw = Number(formData.get("purpose_linked_invoice_id"));
  let purpose_linked_invoice_id: number | null = null;
  if (linkedRaw && patientId) {
    const linked = await db
      .selectFrom("invoices")
      .select(["invoices.id"])
      .where("invoices.id", "=", linkedRaw)
      .where("invoices.patient_id", "=", patientId)
      .where("invoices.parent_invoice_id", "is", null)
      .executeTakeFirst();
    if (linked) purpose_linked_invoice_id = linked.id;
  }

  if (raw === "bonding_upper" || raw === "bonding_lower") {
    return { purpose_type: raw, purpose_service_id: null, purpose_linked_invoice_id };
  }
  if (raw === "service") {
    const serviceId = Number(formData.get("purpose_service_id"));
    if (serviceId) return { purpose_type: "service", purpose_service_id: serviceId, purpose_linked_invoice_id };
  }
  return { purpose_type: null, purpose_service_id: null, purpose_linked_invoice_id: null };
}

export async function addAppointmentAction(formData: FormData) {
  // حجز موعد لازم صلاحية تعديل المواعيد — كانت الوحيدة في الملف من غير فحص.
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "schedule_edit"))) return;

  const patient_id = Number(formData.get("patient_id"));
  const room_id = Number(formData.get("room_id"));
  const doctor_id = Number(formData.get("doctor_id"));
  const appointment_date = String(formData.get("appointment_date") || "");
  const start_time = String(formData.get("start_time") || "");
  const notes = String(formData.get("notes") || "").trim() || null;
  // بيوصل من الجدول المركزي كعدد دقايق (مضاعفات وحدة الزمن)؛ لو مبعوتش أو صفر
  // بيتعامل معاه كموعد بطول خانة واحدة بس (نفس السلوك القديم قبل ما الحقل ده يتضاف).
  const durationRaw = formData.get("duration_minutes");
  const duration_minutes = durationRaw ? Number(durationRaw) || null : null;

  if (!patient_id || !room_id || !doctor_id || !appointment_date || !start_time) return;
  if (!(await canEditAppointmentSlot(session, { doctorId: doctor_id, roomId: room_id, date: appointment_date, startTime: start_time, durationMinutes: duration_minutes }))) return;

  const { purpose_type, purpose_service_id, purpose_linked_invoice_id } = await readPurpose(formData, patient_id);

  await db
    .insertInto("appointments")
    .values({
      patient_id,
      room_id,
      doctor_id,
      appointment_date,
      start_time,
      duration_minutes,
      notes,
      purpose_type,
      purpose_service_id,
      purpose_linked_invoice_id,
    })
    .execute();
  await reactivatePatientForCare(patient_id);
  revalidatePath("/front-desk");
  revalidatePath("/");
}

// شفت استثنائي — دفعة 27: تسهيل ليوم بعينه (زي "دكتور جاي في يوم غير يومه")
// من غير ما نلمس الشيفت الأسبوعي المتكرر (doctor_weekly_shifts) خالص. الأثر
// الوحيد: صاحب الشفت الاستثنائي ده بيبقى الدكتور المقترح افتراضيًا لأي حجز
// جديد في نفس الغرفة/اليوم ده (شوف roomShiftDoctorIds في front-desk/page.tsx
// و app/page.tsx) — قابل للتغيير يدويًا لكل حجز، مش قيد. نفس صلاحية تعديل
// الجدول (schedule_edit) اللي أصلاً بتتحكم في الحجز والحالة.
export async function setExceptionalShiftAction(formData: FormData): Promise<{ ok: boolean; reason?: string }> {
  const session = await getSession();
  if (!session) return { ok: false, reason: "غير مسموح" };
  const canEdit = await hasPermission(session.userId, session.role, "schedule_edit");
  if (!canEdit) return { ok: false, reason: "محتاج صلاحية تعديل الجدول" };

  const room_id = Number(formData.get("room_id"));
  const doctor_id = Number(formData.get("doctor_id"));
  const shift_date = String(formData.get("shift_date") || "");
  if (!room_id || !doctor_id || !shift_date) return { ok: false, reason: "بيانات ناقصة" };

  await db
    .insertInto("doctor_date_shifts")
    .values({ room_id, doctor_id, shift_date, created_by: session.userId })
    .onConflict((oc) => oc.columns(["room_id", "shift_date"]).doUpdateSet({ doctor_id, created_by: session.userId }))
    .execute();

  revalidatePath("/front-desk");
  revalidatePath("/");
  return { ok: true };
}

// إلغاء شفت استثنائي (رجوع للشيفت الأسبوعي العادي كمصدر الافتراضي).
export async function clearExceptionalShiftAction(formData: FormData): Promise<{ ok: boolean; reason?: string }> {
  const session = await getSession();
  if (!session) return { ok: false, reason: "غير مسموح" };
  const canEdit = await hasPermission(session.userId, session.role, "schedule_edit");
  if (!canEdit) return { ok: false, reason: "محتاج صلاحية تعديل الجدول" };

  const room_id = Number(formData.get("room_id"));
  const shift_date = String(formData.get("shift_date") || "");
  if (!room_id || !shift_date) return { ok: false, reason: "بيانات ناقصة" };

  await db.deleteFrom("doctor_date_shifts").where("room_id", "=", room_id).where("shift_date", "=", shift_date).execute();

  revalidatePath("/front-desk");
  revalidatePath("/");
  return { ok: true };
}

// تحديد/تغيير "المريض جاي يعمل إيه" لموعد موجود بالفعل — قابل للاستدعاء في أي وقت
// (وقت الحجز أو بعده) من خانة الموعد في الجدول المركزي مباشرة، مش بس من بوكس
// الحجز. نفس صلاحية تعديل الجدول (schedule_edit) اللي أصلاً بتتحكم في ظهور بوكس
// الحجز وزراير الحالة — تحقق حقيقي في السيرفر، مش بس إخفاء زرار في الواجهة.
export async function setAppointmentPurposeAction(formData: FormData) {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "schedule_edit"))) return;

  const id = Number(formData.get("appointment_id"));
  if (!id) return;

  const appt = await db.selectFrom("appointments").select(["patient_id", "doctor_id", "room_id", "appointment_date", "start_time", "duration_minutes"]).where("id", "=", id).executeTakeFirst();
  if (!appt) return;
  if (!(await canEditAppointmentSlot(session, { doctorId: appt.doctor_id, roomId: appt.room_id, date: appt.appointment_date, startTime: appt.start_time, durationMinutes: appt.duration_minutes }))) return;

  const { purpose_type, purpose_service_id, purpose_linked_invoice_id } = await readPurpose(formData, appt.patient_id);

  await db
    .updateTable("appointments")
    .set({ purpose_type, purpose_service_id, purpose_linked_invoice_id })
    .where("id", "=", id)
    .execute();
  revalidatePath("/front-desk");
  revalidatePath("/");
}

// موعد "تم" نهائي — مايترجعش لحالة تانية خالص (اتفقنا على كده من دفعة 8). الجدول
// المركزي (CentralSchedule.tsx) أصلاً مايعرضش أي خيار تراجع لموعد "تم" في الواجهة،
// لكن ده كان بس قيد في الواجهة — السيرفر هنا كان بيقبل أي تغيير حالة من غير أي
// تحقق، وده اللي خلى صفحة "المواعيد والشيفتات" القديمة (كان فيها StatusSelect حر
// بيقدر يرجّع أي موعد "تم" لـ"محجوز"/"ملغي" بسهولة) تكسر الاتفاق ده فعليًا — الصفحة
// دي اتشالت بالكامل (كانت مكررة مع الجدول المركزي بالكامل)، وهنا كمان بقى فيه تحقق
// في السيرفر نفسه بغض النظر عن مين بيستدعي الأكشن.
export async function updateAppointmentStatusAction(formData: FormData) {
  const session = await getSession();
  if (!session) return;
  const id = Number(formData.get("id"));
  const status = String(formData.get("status") || "") as "booked" | "attended" | "done" | "cancelled" | "no_show";
  if (!id || !["booked", "attended", "done", "cancelled", "no_show"].includes(status)) return;

  const current = await db.selectFrom("appointments").select(["status", "doctor_id", "room_id", "appointment_date", "start_time", "duration_minutes", "attended_at"]).where("id", "=", id).executeTakeFirst();
  if (!current) return;
  if (current.status === "done") return;

  const canEditSchedule = await hasPermission(session.userId, session.role, "schedule_edit");
  const canMarkDone = status === "done" && (await hasPermission(session.userId, session.role, "mark_appointment_done"));
  if (!canEditSchedule && !canMarkDone) return;
  if (session.role === "doctor" && current.appointment_date !== getClinicToday() && !["booked", "cancelled"].includes(status)) return;
  if (canEditSchedule && !(await canEditAppointmentSlot(session, { doctorId: current.doctor_id, roomId: current.room_id, date: current.appointment_date, startTime: current.start_time, durationMinutes: current.duration_minutes }))) return;
  if (!canEditSchedule) {
    if (session.role !== "doctor" || !session.doctorId || current.doctor_id !== session.doctorId) return;
    if (current.appointment_date !== getClinicToday()) return;
  }

  const update: { status: typeof status; attended_at?: string | null; completed_at?: string | null } = { status };
  if (status === "attended" && current.status !== "attended") {
    update.attended_at = new Date().toISOString();
  } else if (status === "booked") {
    // لو الاستقبال رجّع الموعد إلى «محجوز»، الوصول التالي يأخذ ترتيبًا جديدًا.
    update.attended_at = null;
  }
  if (status === "done") update.completed_at = new Date().toISOString();
  await db.updateTable("appointments").set(update).where("id", "=", id).execute();
  // الإلغاء و"لم يحضر" و"تم" بيأثروا على الفواتير والتقارير — لازم يفضل لهم أثر.
  if (["done", "cancelled", "no_show"].includes(status)) {
    await logAdminEvent({
      entityType: "appointment", entityId: id, event: "appointment_status",
      details: `حالة الموعد #${id} اتغيّرت من ${current.status} إلى ${status}`,
      changedBy: session.userId,
    });
  }
  if (status === "done") {
    await autoCloseReferralTasksForAppointment(id, session.userId);
    await applyGeneralConsumablesForCompletedAppointment(id);
    await evaluateInventoryReorderNeeds();
  }
  if (status === "cancelled") await notifyDoctorOfCancellation(id);
  revalidatePath("/front-desk");
  revalidatePath("/");
  if (status === "done") revalidatePath("/", "layout");
}
