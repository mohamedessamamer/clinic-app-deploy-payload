import type { Role } from "./auth";

// ثوابت الصلاحيات فقط — من غير أي استيراد لطبقة قاعدة البيانات، عشان يصلح
// للاستخدام في مكونات العميل (client components) زي PermissionsManager كمان.
// الدوال اللي بتلمس قاعدة البيانات (getPermissionOverrides..) موجودة في lib/permissions.ts.
export const PERMISSION_GROUPS = [
  { key: "appointments", label: "الاستقبال والمواعيد" },
  { key: "medical", label: "الصلاحيات الطبية" },
  { key: "financial", label: "الصلاحيات المالية والتقارير" },
  { key: "inventory", label: "صلاحيات المخزن" },
  { key: "whatsapp_manual", label: "واتساب يدوي" },
  { key: "whatsapp_meta", label: "Meta WhatsApp API" },
  { key: "administration", label: "الإدارة والتواصل" },
] as const;

export const PERMISSION_DEFS = [
  { key: "schedule_all_rooms", group: "appointments", title: "عرض كل العيادات", description: "يعرض الجدول المركزي لكل الغرف بدل شيفت المستخدم فقط." },
  { key: "schedule_edit", group: "appointments", title: "تعديل المواعيد", description: "حجز موعد وتغيير حالته من الجدول المركزي." },
  { key: "mark_appointment_done", group: "appointments", title: "إنهاء الموعد", description: "يسمح للطبيب بتحديد مواعيده اليوم كحالة تم، بعيدًا عن التحصيل." },
  { key: "view_needs_treatment_reminder", group: "appointments", title: "تنبيه المعالجة الناقصة", description: "يعرض تنبيه الموعد الذي تم بدون تسجيل المعالجة." },
  { key: "create_collection_requests_all_doctors", group: "appointments", title: "طلبات تحصيل كل الأطباء", description: "يسجل طلب التحصيل نيابة عن أي طبيب مع حفظ اسم طبيب الموعد." },
  { key: "view_whatsapp_reminder_report", group: "appointments", title: "متابعة تأكيد المواعيد", description: "يعرض ردود تذكير المواعيد ويعتمد طلبات التعديل." },
  { key: "configure_followup_thresholds", group: "appointments", title: "تعديل مدد المتابعة", description: "يغير حدود تقرير متابعة التقويم المتأخرة." },
  { key: "view_patient_review_report", group: "appointments", title: "تقرير تقييمات المرضى", description: "يعرض متوسط التقييمات والتعليقات عند الطلب." },
  // دمج ثلاث صلاحيات كانت منفصلة (متابعة التقويم، التحويلات، مدة المريض في
  // العيادة) في صلاحية واحدة لتبويب "تقارير المرضى" بالكامل — كانت مبعثرة
  // بلا داعٍ. أي دور كان عنده أي واحدة منهم اتضاف له هنا بدلها، فمحدش بيفقد
  // وصوله لكل تقارير المرضى (شوف ROLE_DEFAULT_PERMISSIONS تحت).
  { key: "view_patient_reports", group: "appointments", title: "عرض تقارير المرضى", description: "يعرض تقارير متابعة التقويم والتحويلات ومدة المريض في العيادة والكشوفات غير المكتملة." },

  { key: "view_patients_list", group: "medical", title: "قائمة المرضى", description: "يعرض قائمة المرضى للطبيب، وليس مرضى مواعيده فقط." },
  { key: "view_patient_personal_data", group: "medical", title: "البيانات الشخصية", description: "يعرض السن والهاتف وتاريخ الميلاد والعنوان." },
  { key: "edit_patient_info", group: "medical", title: "تعديل بيانات المريض", description: "تعديل الاسم والميلاد والهاتف والعنوان." },
  { key: "override_visit_doctor", group: "medical", title: "اختيار طبيب مساعد", description: "يحدد مقدم خدمة مختلف بدون تغيير صاحب التحصيل." },
  { key: "edit_old_visits", group: "medical", title: "تعديل الزيارات القديمة", description: "يعدل زيارات الملف الطبي بعد انتهاء مهلة الثلاثة أيام." },
  { key: "edit_visit_assistant_doctor", group: "medical", title: "تعديل الطبيب المساعد", description: "يعدل الطبيب المساعد في زيارة محفوظة فقط." },
  { key: "edit_ortho_visit_after_save", group: "medical", title: "تعديل زيارات التقويم القديمة", description: "يفعّل زر Edit للزيارات المحفوظة في شارت التقويم." },
  { key: "upload_ortho_photos", group: "medical", title: "صور وأشعة التقويم", description: "رفع وتدوير وحذف صور التقويم بدون صلاحية تعديل الشارت كاملًا." },
  { key: "view_patient_files", group: "medical", title: "عرض ملفات المرضى", description: "يعرض الصور والأشعة والملفات الطبية المرفوعة." },
  { key: "delete_visits", group: "medical", title: "حذف الزيارات", description: "يحذف الزيارة وفاتورتها نهائيًا لتصحيح الإدخال الخاطئ." },
  { key: "manage_ortho_chart_options", group: "medical", title: "قوائم ملخص شارت التقويم", description: "يعدل خيارات Chief complaint وTreatment وDiagnosis في إعدادات شارت التقويم." },

  { key: "reports_full", group: "financial", title: "كل التقارير", description: "يعرض تقارير كل الأطباء والفترات." },
  { key: "reports_own", group: "financial", title: "التقرير الشخصي", description: "يعرض تقرير الطبيب نفسه ضمن الحد الزمني المحدد." },
  { key: "collect_payments", group: "financial", title: "تحصيل المدفوعات", description: "يسجل التحصيل من شاشة الاستقبال." },
  { key: "view_patient_billing", group: "financial", title: "الملف المالي للمريض", description: "يعرض فواتير ومدفوعات المريض وإضافة خدمة مالية." },
  { key: "edit_invoice_payments", group: "financial", title: "تصحيح الفواتير", description: "يعدل السعر أو المدفوع ويسمح بالتسجيل بتاريخ قديم." },
  { key: "edit_patient_billing_entry", group: "financial", title: "تعديل صف الملف المالي", description: "يعدل خدمة/دفعة مسجلة في الملف المالي للمريض (المبلغ والخصم وطريقة الدفع والدكتور والتاريخ والخدمة المرتبطة) بدل حذفها وإعادة تسجيلها." },
  { key: "view_invoice_totals", group: "financial", title: "إجماليات الفواتير", description: "يعرض إجمالي الفواتير والمحصّل والمتبقي." },
  { key: "manage_expenses", group: "financial", title: "المصروفات والمرتبات", description: "إدارة المصروفات وكشوف رواتب الأطباء." },
  { key: "manage_hr", group: "financial", title: "إدارة HR وقواعد الرواتب", description: "تعريف الرواتب الثابتة والشيفتات والنسب الثابتة أو التصاعدية للأطباء والموظفين والتمريض." },
  { key: "clear_expenses_data", group: "financial", title: "مسح كل بيانات المصروفات", description: "حذف كل المصروفات وكشوف رواتب HR والبنود المتكررة نهائيًا من شاشة المصروفات. للأدمن فقط، ولا يمكن التراجع عنه." },

  { key: "manage_inventory", group: "inventory", title: "استخدام المخزن", description: "فتح المخزن وتسجيل الجرد والتوريدات." },
  { key: "edit_inventory_catalog", group: "inventory", title: "تعديل كتالوج المخزن", description: "إضافة وتعديل الأصناف والتخصصات وإعداداتها." },
  { key: "delete_inventory_records", group: "inventory", title: "حذف بيانات المخزن", description: "يحذف أو يلغي بيانات المخزن المسجلة بالخطأ." },
  { key: "toggle_inventory_deductions", group: "inventory", title: "تشغيل وإيقاف خصم المخزن", description: "يتحكم في المفتاح العام لخصم المستهلكات من كل المخزن بعد رسالة تأكيد." },
  { key: "undo_ortho_inventory_deduction", group: "inventory", title: "إلغاء خصم التقويم", description: "يلغي خصمًا مسجلًا من Inventory list في شارت التقويم." },
  { key: "receive_low_stock_alerts", group: "inventory", title: "استقبال تنبيهات نقص المخزون", description: "يصل لصاحب الصلاحية إشعار عند وصول أي صنف لحد الطلب أو الحد الحرج." },
  { key: "manage_suppliers", group: "inventory", title: "إدارة الموردين", description: "إضافة وتعديل الموردين من المخزن، وتسجيل فواتيرهم ودفعاتهم من شاشة الموردين تحت المصروفات." },

  { key: "whatsapp_manual_send", group: "whatsapp_manual", title: "إرسال رسائل يدوية", description: "يفتح واتساب لإرسال القوالب اليدوية للمستلمين." },
  { key: "whatsapp_manual_templates", group: "whatsapp_manual", title: "إدارة القوالب اليدوية", description: "ينشئ ويعدل القوالب والفئات والمتغيرات والخمس رسائل السريعة." },
  { key: "whatsapp_bulk_send", group: "whatsapp_manual", title: "إرسال جماعي", description: "يجهز أو يرسل رسائل مجموعة مرضى لفترة محددة." },
  { key: "whatsapp_automation", group: "whatsapp_meta", title: "قواعد الإرسال التلقائي", description: "ينشئ ويعدل قواعد إرسال قوالب Meta تلقائيًا." },

  { key: "whatsapp_meta_connection", group: "whatsapp_meta", title: "اتصال Meta", description: "يعرض ويربط حساب ورقم WhatsApp Cloud API." },
  { key: "whatsapp_meta_conversations", group: "whatsapp_meta", title: "محادثات Meta", description: "يعرض المحادثات ويرسل منها." },
  { key: "whatsapp_meta_templates", group: "whatsapp_meta", title: "إنشاء قوالب Meta", description: "ينشئ قوالب رسمية لإرسالها إلى Meta." },
  { key: "whatsapp_meta_sync", group: "whatsapp_meta", title: "مزامنة قوالب Meta", description: "يحدث الحالات ويحذف محليًا ما حُذف من Meta." },

  { key: "manage_settings", group: "administration", title: "صفحة الإعدادات", description: "يسمح بالدخول إلى إعدادات النظام." },
  { key: "send_staff_chat_to_doctors", group: "administration", title: "مراسلة الأطباء", description: "يسمح للطبيب بإرسال رسالة لطبيب أو لكل الأطباء." },
  { key: "view_system_log", group: "administration", title: "سجل النظام", description: "يعرض تقرير كل ما يحدث في النظام: من عدّل أو حذف ماذا ومتى، بفترة تاريخية." },
  { key: "manage_whatsapp", group: "administration", title: "واتساب", description: "ربط حساب واتساب وعرض/إرسال الرسائل وإدارة القوالب." },
] as const;

export type PermissionKey = (typeof PERMISSION_DEFS)[number]["key"];

export const ROLE_DEFAULT_PERMISSIONS: Record<Role, PermissionKey[]> = {
  admin: [
    "view_system_log",
    "reports_full",
    "collect_payments",
    "manage_inventory",
    "edit_inventory_catalog",
    "delete_inventory_records",
    "manage_suppliers",
    "manage_expenses",
    "manage_hr",
    "clear_expenses_data",
    "manage_settings",
    "schedule_all_rooms",
    "schedule_edit",
    "override_visit_doctor",
    "edit_old_visits",
    "edit_invoice_payments",
    "edit_patient_billing_entry",
    "delete_visits",
    "edit_patient_info",
    "edit_visit_assistant_doctor",
    "edit_ortho_visit_after_save",
    "view_patient_files",
    "undo_ortho_inventory_deduction",
    "manage_whatsapp",
    "view_whatsapp_reminder_report",
    "view_patient_reports",
    "configure_followup_thresholds",
    "view_patient_review_report",
    "whatsapp_manual_send",
    "whatsapp_manual_templates",
    "whatsapp_bulk_send",
    "whatsapp_automation",
    "whatsapp_meta_connection",
    "whatsapp_meta_conversations",
    "whatsapp_meta_templates",
    "whatsapp_meta_sync",
  ],
  clinic_manager: [
    "reports_full",
    "manage_inventory",
    "schedule_all_rooms",
    "override_visit_doctor",
    "edit_old_visits",
    "edit_invoice_payments",
    "edit_visit_assistant_doctor",
    "view_patient_files",
    "view_whatsapp_reminder_report",
    "view_patient_reports",
  ],
  accountant: [
    "reports_full",
    "collect_payments",
    "manage_expenses",
    "manage_hr",
    "edit_invoice_payments",
  ],
  // manage_inventory ضمن الافتراضي هنا عشان الاستقبال كان عنده وصول للمخزون
  // أصلاً (رابط ثابت في القائمة قبل ما يبقى صلاحية) — عشان التحويل للنظام
  // الجديد ميقفلش حاجة كانت شغالة بالفعل. لسه ممكن تُسحب من مستخدم استقبال
  // معيّن من الإعدادات لو حابب.
  reception: [
    "collect_payments",
    "schedule_all_rooms",
    "schedule_edit",
    "manage_inventory",
    "edit_patient_info",
    "view_patient_personal_data",
    "edit_visit_assistant_doctor",
    "upload_ortho_photos",
    "view_patient_files",
    "view_whatsapp_reminder_report",
    "view_patient_reports",
    "whatsapp_manual_send",
    "whatsapp_bulk_send",
  ],
  // الدكتور افتراضيًا يشوف الجدول المركزي لشيفته/غرفته بس النهاردة، وبشكل عرض فقط
  // (من غير حجز أو تغيير حالة) — الأدمن يقدر يوسّع الصلاحيات دي لدكتور معيّن من
  // صفحة الإعدادات لو حابب (schedule_all_rooms و/أو schedule_edit).
  doctor: ["reports_own", "view_needs_treatment_reminder", "mark_appointment_done", "view_patient_files"],
};
