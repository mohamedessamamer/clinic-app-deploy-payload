"use client";

import { useEffect, useState, useTransition } from "react";
import { listMessagesAction, sendMessageAction } from "@/app/whatsapp/actions";

type Conversation = { id: number; waId: string; profileName: string | null; lastMessageAt: string | null };
type Message = { id: number; direction: "inbound" | "outbound"; body: string | null; status: string; isEcho: boolean; createdAt: string };

export default function WhatsAppChat({ conversations }: { conversations: Conversation[] }) {
  const [activeId, setActiveId] = useState<number | null>(conversations[0]?.id ?? null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [draft, setDraft] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    if (!activeId) return;
    let cancelled = false;
    async function load() {
      const rows = await listMessagesAction(activeId!);
      if (!cancelled) setMessages(rows);
    }
    load();
    // بولينج بسيط كل 5 ثواني — كافي لواجهة رسائل تجريبية/عيادة صغيرة، من غير
    // الحاجة لطبقة WebSocket إضافية.
    const interval = setInterval(load, 5000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [activeId]);

  function handleSend() {
    if (!activeId || !draft.trim()) return;
    setError(null);
    const formData = new FormData();
    formData.set("contact_id", String(activeId));
    formData.set("body", draft.trim());
    startTransition(async () => {
      const result = await sendMessageAction(formData);
      if (!result.ok) {
        setError(result.error ?? "فشل الإرسال");
      } else {
        setDraft("");
        const rows = await listMessagesAction(activeId);
        setMessages(rows);
      }
    });
  }

  if (conversations.length === 0) {
    return <p className="text-sm text-muted">لسه مفيش أي محادثة واردة. ابعت رسالة من رقم شخصي للرقم المتصل عشان تظهر هنا.</p>;
  }

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
      <div className="space-y-1 md:col-span-1">
        {conversations.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => setActiveId(c.id)}
            className={`w-full rounded-lg p-2 text-right text-sm ${activeId === c.id ? "bg-emerald-100 font-medium" : "hover:bg-slate-50"}`}
          >
            <div>{c.profileName || c.waId}</div>
            <div className="text-xs text-muted">+{c.waId}</div>
          </button>
        ))}
      </div>

      <div className="flex flex-col gap-3 md:col-span-2">
        <div className="max-h-96 min-h-[200px] space-y-2 overflow-y-auto rounded-lg border border-slate-200 p-3">
          {messages.map((m) => (
            <div key={m.id} className={`flex ${m.direction === "outbound" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${
                  m.direction === "outbound" ? "bg-emerald-600 text-white" : "bg-slate-100 text-slate-900"
                }`}
              >
                <div>{m.body}</div>
                <div className="mt-1 text-[10px] opacity-70">
                  {new Date(m.createdAt).toLocaleString("ar-EG")}
                  {m.direction === "outbound" ? ` — ${m.status}` : m.isEcho ? " — من تطبيق واتساب بزنس" : ""}
                </div>
              </div>
            </div>
          ))}
          {messages.length === 0 && <p className="text-sm text-muted">مفيش رسائل لسه في المحادثة دي.</p>}
        </div>

        <div className="flex gap-2">
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder="اكتب رسالة..."
            className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm"
          />
          <button type="button" disabled={isPending} onClick={handleSend} className="btn-primary rounded-lg px-4 py-2 text-sm">
            إرسال
          </button>
        </div>
        {error && <p className="text-sm text-red-700">{error}</p>}
      </div>
    </div>
  );
}
