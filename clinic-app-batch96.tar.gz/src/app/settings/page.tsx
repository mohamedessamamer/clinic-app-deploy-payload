import { getAllSettings, buildTimeSlots, WEEKDAY_LABELS, WEEKDAY_DISPLAY_ORDER } from "@/lib/settings";
import { getSession } from "@/lib/session";
import { db } from "@/lib/db/client";
import Link from "next/link";
import { saveSettingsAction, saveNotificationSettingsAction } from "./actions";
import ServicesManager from "@/components/ServicesManager";
import AddDoctorForm from "@/components/AddDoctorForm";
import AddEmployeeForm from "@/components/AddEmployeeForm";
import UsersList from "@/components/UsersList";
import PermissionsManager from "@/components/PermissionsManager";
import RoomsManager from "@/components/RoomsManager";
import WeeklyShiftsManager from "@/components/WeeklyShiftsManager";
import SettingsSidebarLayout from "@/components/SettingsSidebarLayout";
import ChatSoundPicker from "@/components/ChatSoundPicker";
import DoctorConsultantManager from "@/components/DoctorConsultantManager";
import ClearStaffChatButton from "@/components/ClearStaffChatButton";
import InventoryCatalogManager from "@/components/InventoryCatalogManager";
import { getPermissionOverrides } from "@/lib/permissions";


const ROOM_ERROR_LABELS: Record<string, string> = {
  in_use: "العيادة/الغرفة دي مستخدمة في شيفتات أو مواعيد أو زيارات مسجلة، لازم تشيلها من هناك الأول قبل الحذف.",
};

export default async function SettingsPage({
  searchParams,
}: {
  searchParams: Promise<{ roomerror?: string; resetpw?: string }>;
}) {
  const session = await getSession();

  if (!session) {
    return (
      <div className="card-3d rounded-xl p-5 text-sm text-muted">
        لازم تسجل دخول عشان توصل للإعدادات.
      </div>
    );
  }

  const { roomerror, resetpw } = await searchParams;

  // تغيير كلمة السر بقى في صفحة /change-password المستقلة — عشان الدكتور
  // والاستقبال يوصلوها من غير ما يعدّوا على شاشة الإعدادات (المتاحة للأدمن بس).
  const changePasswordSection = (
    <div className="card-3d rounded-xl p-5 max-w-lg space-y-2">
      <h2 className="font-semibold">كلمة السر</h2>
      <p className="text-sm text-muted">تقدر تغيّر كلمة سر حسابك من صفحة مستقلة.</p>
      <Link
        href="/change-password?next=/settings"
        className="inline-block rounded-md btn-3d-primary px-4 py-2 text-sm font-medium"
      >
        تغيير كلمة السر
      </Link>
    </div>
  );

  if (session.role !== "admin") {
    return (
      <div className="space-y-6">
        <h1 className="text-xl font-bold">الإعدادات</h1>
        {changePasswordSection}
        <div className="card-3d rounded-xl p-5 text-sm text-muted max-w-lg">
          باقي الإعدادات (وحدة الزمن والشيفتات) متاحة لمدير النظام فقط.
        </div>
      </div>
    );
  }

  const [settings, rooms, doctors, weeklyShiftsRaw, services, users, consultantAssistantRows, inventorySpecialties, inventoryCategories, inventoryProducts, inventoryAttributeGroups, inventoryAttributeValues, inventoryUnits, inventorySuppliers] = await Promise.all([
    getAllSettings(),
    db.selectFrom("rooms").selectAll().execute(),
    db.selectFrom("doctors").select(["id", "full_name", "is_consultant"]).where("active", "=", 1).execute(),
    db
      .selectFrom("doctor_weekly_shifts")
      .leftJoin("rooms", "rooms.id", "doctor_weekly_shifts.room_id")
      .leftJoin("doctors", "doctors.id", "doctor_weekly_shifts.doctor_id")
      .select([
        "doctor_weekly_shifts.id",
        "doctor_weekly_shifts.weekday",
        "doctor_weekly_shifts.start_time",
        "doctor_weekly_shifts.end_time",
        "rooms.name as room_name",
        "doctors.full_name as doctor_name",
      ])
      .orderBy("doctor_weekly_shifts.weekday")
      .orderBy("doctor_weekly_shifts.start_time")
      .execute(),
    db.selectFrom("services").selectAll().orderBy("name").execute(),
    db.selectFrom("users").select(["id", "username", "full_name", "contact_name", "role"]).where("active", "=", 1).execute(),
    db.selectFrom("consultant_assistants").selectAll().execute(),
    db.selectFrom("inventory_specialties").select(["id", "name", "parent_id"]).where("active", "=", 1).orderBy("name").execute(),
    db.selectFrom("inventory_categories").select(["id", "name", "specialty_id"]).where("active", "=", 1).orderBy("name").execute(),
    db.selectFrom("inventory_products").select(["id", "name", "category_id"]).where("active", "=", 1).orderBy("name").execute(),
    db.selectFrom("inventory_attribute_groups").select(["id", "name", "product_id"]).orderBy("sort_order").execute(),
    db.selectFrom("inventory_attribute_values").select(["id", "value", "attribute_group_id"]).where("active", "=", 1).orderBy("sort_order").execute(),
    db.selectFrom("inventory_units").select(["id", "name", "short_name"]).where("active", "=", 1).orderBy("name").execute(),
    db.selectFrom("inventory_suppliers").select(["id", "name", "phone_country_code", "phone"]).where("active", "=", 1).orderBy("name").execute(),
  ]);

  // دفعة 22: خريطة استشاري -> قائمة الدكاترة المساعدين تحته، لعرضها في
  // DoctorConsultantManager (كل صف بياخد قايمته هو بس).
  const assistantsByConsultant: Record<number, number[]> = {};
  for (const row of consultantAssistantRows) {
    if (!assistantsByConsultant[row.consultant_doctor_id]) assistantsByConsultant[row.consultant_doctor_id] = [];
    assistantsByConsultant[row.consultant_doctor_id].push(row.assistant_doctor_id);
  }

  const overridesEntries = await Promise.all(
    users.filter((u) => u.role !== "admin").map(async (u) => [u.id, await getPermissionOverrides(u.id)] as const)
  );
  const overridesByUser = Object.fromEntries(overridesEntries);

  const timeSlots = buildTimeSlots(settings.day_start, settings.day_end, Number(settings.slot_minutes));
  const holidayWeekdays = settings.holiday_weekdays
    ? settings.holiday_weekdays.split(",").filter(Boolean).map(Number)
    : [];

  // قائمة جانبية (دفعة 22) بدل الأقسام كلها تحت بعض — أي إعادة توجيه بيحصل من
  // أكشن (تغيير كلمة السر، حذف عيادة، تصفير كلمة سر) بيحدد تلقائيًا القسم اللي
  // يفتح عليه، عشان المستخدم يشوف نتيجة الأكشن على طول من غير ما يدور عليها.
  const initialKey = roomerror ? "clinics" : resetpw ? "users" : "profile";

  const profileSection = (
    <>
      <h1 className="text-xl font-bold">إعدادات العيادة</h1>
      {changePasswordSection}
    </>
  );

  const clinicsSection = (
    <section className="card-3d rounded-xl p-5 space-y-6">
        <h2 className="font-semibold">إعدادات العيادات</h2>

        {roomerror && (
          <p className="text-sm text-red-700 bg-red-50 border border-red-200 rounded-md px-3 py-2">
            {ROOM_ERROR_LABELS[roomerror] || "حصل خطأ، حاول تاني."}
          </p>
        )}

        <form action={saveSettingsAction} className="space-y-4">
          <h3 className="text-sm font-medium">وحدة الزمن</h3>
          <div>
            <label className="block text-sm text-muted mb-1">وحدة الزمن (مدة الموعد الواحد بالدقايق)</label>
            <select
              name="slot_minutes"
              defaultValue={settings.slot_minutes}
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
            >
              {[5, 10, 15, 20, 30, 45, 60].map((m) => (
                <option key={m} value={m}>
                  {m} دقيقة
                </option>
              ))}
            </select>
            <p className="text-xs text-muted mt-1">
              ده بيتحكم في الفواصل الزمنية اللي بتظهر عند حجز موعد جديد (مثلاً كل 15 دقيقة) — وده نفسه اللي بيحدد
              اختيارات الوقت في شيفتات الأطباء الأسبوعية تحت.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-muted mb-1">بداية يوم العمل</label>
              <input
                type="time"
                name="day_start"
                defaultValue={settings.day_start}
                className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-sm text-muted mb-1">نهاية يوم العمل</label>
              <input
                type="time"
                name="day_end"
                defaultValue={settings.day_end}
                className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm text-muted mb-1">أيام الإجازة الأسبوعية</label>
            <div className="flex flex-wrap gap-3">
              {WEEKDAY_DISPLAY_ORDER.map((idx) => (
                <label key={idx} className="flex items-center gap-1.5 text-sm">
                  <input
                    type="checkbox"
                    name="holiday_weekdays"
                    value={idx}
                    defaultChecked={holidayWeekdays.includes(idx)}
                    className="h-4 w-4"
                  />
                  {WEEKDAY_LABELS[idx]}
                </label>
              ))}
            </div>
          </div>

          <button
            type="submit"
            className="rounded-md btn-3d-primary px-4 py-2 text-sm font-medium transition-colors"
          >
            حفظ الإعدادات
          </button>
        </form>

        <div className="border-t border-border pt-5">
          <h3 className="text-sm font-medium mb-2">العيادات/الغرف</h3>
          <RoomsManager rooms={rooms} />
        </div>

        <div className="border-t border-border pt-5">
          <h3 className="text-sm font-medium mb-1">شيفتات الأطباء الأسبوعية</h3>
          <p className="text-xs text-muted mb-3">
            هنا بتحدد مين الدكتور صاحب الشيفت في كل عيادة/غرفة في كل يوم من أيام الأسبوع، وده اللي هيتحدد تلقائيًا
            في سجل الاستقبال والمواعيد كل أسبوع من غير ما تحتاج تضيفه كل يوم.
          </p>
          <WeeklyShiftsManager rooms={rooms} doctors={doctors} timeSlots={timeSlots} weeklyShifts={weeklyShiftsRaw} />
        </div>
      </section>
  );

  const servicesSection = (
    <section className="card-3d rounded-xl p-5 space-y-4">
      <h2 className="font-semibold">إعدادات الخدمات</h2>
      <ServicesManager services={services} />
    </section>
  );

  const inventorySection = (
    <section className="card-3d rounded-xl p-5 space-y-4">
      <h2 className="font-semibold">إعدادات المخزن</h2>
      <InventoryCatalogManager
        specialties={inventorySpecialties}
        categories={inventoryCategories}
        products={inventoryProducts}
        attributeGroups={inventoryAttributeGroups}
        attributeValues={inventoryAttributeValues}
        units={inventoryUnits}
        suppliers={inventorySuppliers}
        users={users}
        recipientIds={settings.inventory_low_stock_recipient_ids.split(",").map(Number).filter((id) => id > 0)}
      />
    </section>
  );

  const usersSection = (
    <section className="card-3d rounded-xl p-5 space-y-5">
      <h2 className="font-semibold">إعدادات المستخدمين</h2>

      <div>
        <h3 className="text-sm font-medium mb-2">إضافة طبيب</h3>
        <AddDoctorForm />
      </div>

      <div>
        <h3 className="text-sm font-medium mb-1">الدكاترة الاستشاريين والمساعدين</h3>
        <p className="text-xs text-muted mb-2">
          حدّد أي دكتور كاستشاري واربطه بالدكاترة المساعدين اللي بيشتغلوا تحته — دخل الحالة يتحسب على الاستشاري.
        </p>
        <DoctorConsultantManager doctors={doctors} assistantsByConsultant={assistantsByConsultant} />
      </div>

      <div>
        <h3 className="text-sm font-medium mb-2">إضافة موظف (استقبال / محاسب / مدير عيادة)</h3>
        <AddEmployeeForm />
      </div>

      <div>
        <h3 className="text-sm font-medium mb-2">المستخدمون الحاليون</h3>
        {resetpw && (
          <p className="text-sm text-primary-dark bg-primary-soft border border-primary rounded-md px-3 py-2 mb-2">
            تم تصفير كلمة سر &quot;{resetpw}&quot; لكلمة السر الافتراضية &quot;123&quot;.
          </p>
        )}
        <UsersList users={users} currentUserId={session.userId} />
      </div>
    </section>
  );

  const permissionsSection = (
    <section className="card-3d rounded-xl p-5 space-y-4">
      <h2 className="font-semibold">إعدادات الصلاحيات</h2>
      <p className="text-xs text-muted -mt-2">
        كل مستخدم بياخد صلاحيات افتراضية حسب دوره، وممكن تخصّصها له لوحده من هنا.
      </p>
      <PermissionsManager
        users={users}
        overridesByUser={overridesByUser}
        doctorReportMaxDays={settings.doctor_report_max_days}
      />
    </section>
  );

  const notificationsSection = (
    <section className="card-3d rounded-xl p-5 space-y-4 max-w-2xl">
      <div>
        <h2 className="font-semibold">الإشعارات والشات</h2>
        <p className="text-xs text-muted mt-1">
          القواعد هنا مرنة: اكتب مراحل تنبيه تأخر التقويم بالأيام مفصولة بفاصلة، مثل 40، 60، 90. آخر مرحلة تطلب من الاستقبال سببًا أو تاريخ متابعة جديدًا.
        </p>
      </div>
      <form action={saveNotificationSettingsAction} className="space-y-4">
        <div>
          <label className="block text-sm text-muted mb-1">مراحل تنبيه متابعة التقويم المتأخرة (أيام)</label>
          <input name="notification_ortho_stages_days" defaultValue={settings.notification_ortho_stages_days} placeholder="40,60,90" className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm" />
          <p className="text-xs text-muted mt-1">التنبيه يذهب للاستقبال والطبيب الذي أجرى آخر متابعة. يمكن تغيير القائمة لاحقًا دون نشر نسخة جديدة.</p>
        </div>
        <div className="grid sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-sm text-muted mb-1">تكرار المرحلة النهائية</label>
            <input type="number" min="1" name="notification_ortho_final_repeat_days" defaultValue={settings.notification_ortho_final_repeat_days} className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm" />
            <p className="text-xs text-muted mt-1">بالأيام</p>
          </div>
          <div>
            <label className="block text-sm text-muted mb-1">تنبيه الصور بعد</label>
            <input type="number" min="1" name="notification_photo_days" defaultValue={settings.notification_photo_days} className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm" />
            <p className="text-xs text-muted mt-1">بالأيام</p>
          </div>
          <div>
            <label className="block text-sm text-muted mb-1">الاحتفاظ بالإشعار</label>
            <input type="number" min="1" name="notification_retention_hours" defaultValue={settings.notification_retention_hours} className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm" />
            <p className="text-xs text-muted mt-1">ساعة — الافتراضي 48</p>
          </div>
        </div>
        <div className="rounded-md bg-primary-soft/50 p-3 text-xs text-muted">
          رسائل الشات الداخلي تحفظ 48 ساعة ثم تُحذف تلقائيًا. لا يؤثر حذف الإشعار بعد 48 ساعة على حالة متابعة المريض أو السبب الذي سجله الاستقبال.
        </div>
        <div>
          <label className="block text-sm text-muted mb-1">صوت وصول رسالة شات جديدة</label>
          <ChatSoundPicker initialValue={settings.chat_notification_sound} />
          <p className="text-xs text-muted mt-1">الصوت يعمل بعد أول ضغطة داخل الصفحة بسبب قواعد المتصفح.</p>
        </div>
        <div className="border-t border-border pt-4 space-y-2">
          <h3 className="text-sm font-medium text-danger">تصفير الشات</h3>
          <p className="text-xs text-muted">يحذف كل رسائل الشات فورًا قبل انتهاء مدة الـ48 ساعة. هذا الإجراء متاح لمدير النظام فقط ويطلب تأكيدًا.</p>
          <ClearStaffChatButton />
        </div>
        <button type="submit" className="rounded-md btn-3d-primary px-4 py-2 text-sm">حفظ إعدادات الإشعارات</button>
      </form>
    </section>
  );

  return (
    <div className="max-w-5xl">
      <SettingsSidebarLayout
        initialKey={initialKey}
        sections={[
          { key: "profile", label: "الملف الشخصي", content: profileSection },
          { key: "clinics", label: "العيادات", content: clinicsSection },
          { key: "services", label: "الخدمات", content: servicesSection },
          { key: "inventory", label: "المخزن", content: inventorySection },
          { key: "users", label: "المستخدمين", content: usersSection },
          { key: "permissions", label: "الصلاحيات", content: permissionsSection },
          { key: "notifications", label: "الإشعارات والشات", content: notificationsSection },
        ]}
      />
    </div>
  );
}
