"use client";

import { useEffect, useMemo, useRef, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { addAppointmentAction, updateAppointmentStatusAction } from "@/app/appointments/actions";
import {
  getPatientBillableInvoicesAction,
  recordAppointmentBillingAction,
  recordPendingBillingAction,
} from "@/app/appointments/billing-actions";

type Room = { id: number; name: string };
type Patient = { id: number; full_name: string; file_number: string };
type Doctor = { id: number; full_name: string };
type Service = { id: number; name: string; code: string | null; default_price: number };
type BillableInvoice = { id: number; service_name: string; visit_date: string; balance: number };
const PAYMENT_METHODS = [
  { value: "cash", label: "نقدي" },
  { value: "visa", label: "فيزا" },
  { value: "instapay", label: "انستاباي" },
];
type Appt = {
  id: number;
  patient_id: number;
  patient_name: string;
  doctor_id: number;
  doctor_name: string;
  room_id: number;
  start_time: string;
  duration_minutes: number | null;
  status: "booked" | "attended" | "done" | "cancelled" | "no_show";
  notes: string | null;
  // true لو الموعد "تم" بس لسه ملوش فاتورة/زيارة مسجلة (حصل "تم" من غير بوكس تحصيل —
  // إما لأن اللي حددها معهوش صلاحية تحصيل المدفوعات، أو دوس "تخطي"). بيستخدم عشان
  // الاستقبال يقدر يفتح بوكس التحصيل لاحقًا لموعد "تم" أصلاً من غير رجوعه لحالة تانية.
  needs_billing?: boolean;
  // لو اللي حدد "تم" معهوش صلاحية تحصيل المدفوعات (زي الدكتور)، بيقدر يحدد هنا الخدمة
  // والسعر المتوقع "المطلوب دفعه" من غير ما يسجل دفع فعلي — بتظهر جنب "محتاج تحصيل"
  // في الجدول عشان الاستقبال يشوفها على طول، وبتتملى تلقائي في بوكس التحصيل بتاعه.
  pending_service_id?: number | null;
  pending_service_name?: string | null;
  pending_price?: number | null;
  pending_discount_percent?: number | null;
};

const STATUS_LABELS: Record<Appt["status"], string> = {
  booked: "محجوز",
  attended: "حضر",
  done: "تم",
  cancelled: "ملغي",
  no_show: "لم يحضر",
};

function statusClasses(status: Appt["status"]): string {
  switch (status) {
    case "booked":
      return "bg-primary-soft text-primary-dark border-primary/40";
    case "attended":
      return "bg-amber-100 text-amber-900 border-amber-300";
    case "done":
      return "bg-emerald-100 text-emerald-900 border-emerald-300";
    case "no_show":
      return "bg-danger-soft text-danger border-danger/40";
    default:
      return "bg-background text-foreground border-border";
  }
}

type CellPlan = { kind: "empty" } | { kind: "skip" } | { kind: "start"; appt: Appt; span: number };

export default function CentralSchedule({
  date,
  rooms,
  timeSlots,
  slotMinutes,
  appointments,
  patients,
  doctors,
  services = [],
  canEdit = true,
  canCollectPayments = false,
  isDoctorView = false,
}: {
  date: string;
  rooms: Room[];
  timeSlots: string[];
  slotMinutes: number;
  appointments: Appt[];
  patients: Patient[];
  doctors: Doctor[];
  services?: Service[];
  // لو false، الجدول بيبقى عرض بس — من غير حجز خانة فاضية أو تغيير حالة موعد
  // بالزر اليمين (حسب صلاحية "schedule_edit"). التزامن التلقائي بيفضل شغال زي ما هو.
  canEdit?: boolean;
  // لو true، الضغط على "تم" بيفتح بوكس تحصيل (اختيار خدمة/سعر/خصم أو دفعة متابعة على
  // فاتورة سابقة) قبل ما يتحدد الموعد كـ"تم" — حسب صلاحية "collect_payments".
  canCollectPayments?: boolean;
  // بيحدد وجهة الضغط على اسم المريض في خانة الجدول: من أكونت الطبيب (true) بيفتح
  // الملف الطبي للمريض، ومن أي أكونت تاني (استقبال/محاسب/أدمن...) بيفتح ملفه المالي.
  isDoctorView?: boolean;
}) {
  const router = useRouter();
  const [, startTransition] = useTransition();
  const [contextMenu, setContextMenu] = useState<{
    apptId: number;
    x: number;
    y: number;
    patientName: string;
    status: Appt["status"];
    needsBilling: boolean;
  } | null>(null);
  const [bookingModal, setBookingModal] = useState<{ roomId: number; roomName: string; startTime: string } | null>(null);
  // بحث المريض جوه بوكس الحجز — نفس فكرة البحث الفوري اللي فوق الجدول، بس بيرجع
  // بالمريض المختار كـ patient_id مخفي بدل select عادي طويل.
  const [bookingPatientSearch, setBookingPatientSearch] = useState("");
  const [bookingSelectedPatient, setBookingSelectedPatient] = useState<Patient | null>(null);
  // mode "collect": بوكس التحصيل الكامل (لصلاحية collect_payments) — بيسجل دفع فعلي.
  // mode "pending": بوكس "المطلوب دفعه" بس (لمين معهوش الصلاحية، زي الدكتور) — بيحدد
  // خدمة وسعر متوقع من غير أي تسجيل مالي فعلي.
  const [billingModal, setBillingModal] = useState<{
    apptId: number;
    patientId: number;
    patientName: string;
    mode: "collect" | "pending";
  } | null>(null);
  const [highlightApptId, setHighlightApptId] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const menuRef = useRef<HTMLDivElement>(null);

  // حالة بوكس التحصيل
  const [serviceNameSearch, setServiceNameSearch] = useState("");
  const [serviceCodeSearch, setServiceCodeSearch] = useState("");
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [price, setPrice] = useState("");
  const [discountPercent, setDiscountPercent] = useState("0");
  const [amountNow, setAmountNow] = useState("");
  const [amountTouched, setAmountTouched] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState("cash");
  const [followupOptions, setFollowupOptions] = useState<BillableInvoice[] | null>(null);
  const [loadingFollowups, setLoadingFollowups] = useState(false);
  const [targetInvoiceId, setTargetInvoiceId] = useState("");

  // تزامن الجدول بين أكتر من جهاز/شاشة في الاستقبال — كل 4.5 ثانية، وطالما مفيش
  // مودال حجز أو قايمة يمين مفتوحة (عشان مايقطعش حد وهو بيدخل بيانات)، وطالما
  // التاب ده ظاهر فعليًا (مش تاب تاني مفتوح في الخلفية).
  useEffect(() => {
    const interval = setInterval(() => {
      if (document.visibilityState !== "visible") return;
      if (contextMenu || bookingModal || billingModal) return;
      router.refresh();
    }, 4500);
    return () => clearInterval(interval);
  }, [router, contextMenu, bookingModal, billingModal]);

  // لما يتم اختيار خدمة "متابعة" (كود 0) في بوكس التحصيل، بيتجاب فواتير المريض السابقة
  // اللي لسه عليها مبلغ مستحق، عشان تظهر في الـ drop list يتم الاختيار منها.
  useEffect(() => {
    if (!billingModal || selectedService?.code !== "0") {
      setFollowupOptions(null);
      return;
    }
    let cancelled = false;
    setLoadingFollowups(true);
    getPatientBillableInvoicesAction(billingModal.patientId).then((rows) => {
      if (cancelled) return;
      setFollowupOptions(rows);
      setLoadingFollowups(false);
    });
    return () => {
      cancelled = true;
    };
  }, [billingModal, selectedService]);

  useEffect(() => {
    if (!contextMenu) return;
    function onClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setContextMenu(null);
    }
    window.addEventListener("click", onClickOutside);
    return () => window.removeEventListener("click", onClickOutside);
  }, [contextMenu]);

  useEffect(() => {
    if (highlightApptId === null) return;
    const t = setTimeout(() => setHighlightApptId(null), 2500);
    return () => clearTimeout(t);
  }, [highlightApptId]);

  const liveAppointments = useMemo(() => appointments.filter((a) => a.status !== "cancelled"), [appointments]);

  // خطة كل خانة لكل غرفة: تبدأ موعد (وبتاخد rowSpan) أو خانة اتغطت بموعد فوقها (skip،
  // ملهاش <td> خالص) أو خانة فاضية قابلة للحجز.
  const plans = useMemo(() => {
    const result: Record<number, CellPlan[]> = {};
    for (const room of rooms) {
      const cells: CellPlan[] = timeSlots.map(() => ({ kind: "empty" }));
      const roomAppts = liveAppointments
        .filter((a) => a.room_id === room.id)
        .sort((a, b) => a.start_time.localeCompare(b.start_time));
      for (const appt of roomAppts) {
        const startIdx = timeSlots.indexOf(appt.start_time);
        if (startIdx === -1) continue;
        const span = Math.max(1, Math.round((appt.duration_minutes || slotMinutes) / slotMinutes));
        cells[startIdx] = { kind: "start", appt, span };
        for (let i = startIdx + 1; i < Math.min(startIdx + span, timeSlots.length); i++) {
          cells[i] = { kind: "skip" };
        }
      }
      result[room.id] = cells;
    }
    return result;
  }, [rooms, timeSlots, liveAppointments, slotMinutes]);

  const apptByPatient = useMemo(() => {
    const map = new Map<number, Appt[]>();
    for (const a of liveAppointments) {
      if (!map.has(a.patient_id)) map.set(a.patient_id, []);
      map.get(a.patient_id)!.push(a);
    }
    return map;
  }, [liveAppointments]);

  const searchResults = useMemo(() => {
    const q = search.trim();
    if (!q) return [];
    return patients
      .filter((p) => p.full_name.includes(q) || p.file_number.includes(q))
      .slice(0, 8);
  }, [search, patients]);

  function jumpToAppointment(apptId: number) {
    setHighlightApptId(apptId);
    setSearch("");
    setTimeout(() => {
      document.getElementById(`appt-cell-${apptId}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 50);
  }

  function openBookingModal(roomId: number, roomName: string, startTime: string) {
    setBookingPatientSearch("");
    setBookingSelectedPatient(null);
    setBookingModal({ roomId, roomName, startTime });
  }

  function closeBookingModal() {
    setBookingModal(null);
    setBookingPatientSearch("");
    setBookingSelectedPatient(null);
  }

  // بحث المريض في بوكس الحجز: بيبدأ بيه الاسم (مش أي جزء منه) — كتابة "أ" بترجع كل
  // اللي اسمه يبدأ بـ"أ"، "أح" بترجع "أحمد" وهكذا، زي ما اتفقنا. بيدور بالكود/رقم
  // الملف كمان (مطابقة أول الرقم) لسهولة اللقاء لو المستخدم عارف الرقم مش الاسم.
  const bookingPatientResults = useMemo(() => {
    const q = bookingPatientSearch.trim();
    if (!q) return [];
    return patients.filter((p) => p.full_name.startsWith(q) || p.file_number.startsWith(q)).slice(0, 8);
  }, [bookingPatientSearch, patients]);

  function submitBooking(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!bookingModal || !bookingSelectedPatient) return;
    const fd = new FormData(e.currentTarget);
    startTransition(() => {
      addAppointmentAction(fd);
    });
    closeBookingModal();
  }

  function setStatus(id: number, status: string) {
    const fd = new FormData();
    fd.set("id", String(id));
    fd.set("status", status);
    startTransition(() => {
      updateAppointmentStatusAction(fd);
    });
    setContextMenu(null);
  }

  // "تم": لو المستخدم عنده صلاحية تحصيل المدفوعات، بيفتح بوكس الفوترة الكامل (السعر
  // بيتحدد وبعدين يتحدد الموعد "تم" لما البوكس يتقفل، والدفع الفعلي بيتسجل). لو معهوش
  // الصلاحية (زي الدكتور)، بيفتحله بوكس "المطلوب دفعه" بس — يحدد الخدمة والسعر المتوقع
  // من غير ما يقدر يسجل دفع فعلي؛ الاستقبال بيشوفها على طول جنب "محتاج تحصيل" في
  // الجدول، وبتتملى تلقائي لما يفتح بوكس التحصيل الحقيقي بأثر رجعي (تسجيل التحصيل).
  function onMarkDone(appt: Appt) {
    setContextMenu(null);
    setServiceNameSearch("");
    setServiceCodeSearch("");
    setTargetInvoiceId("");
    setFollowupOptions(null);
    setPaymentMethod("cash");

    if (!canCollectPayments) {
      setSelectedService(null);
      setPrice("");
      setDiscountPercent("0");
      setAmountNow("");
      setAmountTouched(false);
      setBillingModal({ apptId: appt.id, patientId: appt.patient_id, patientName: appt.patient_name, mode: "pending" });
      return;
    }

    // فتح بوكس التحصيل بأثر رجعي لموعد "تم" أصلاً وحدد له الدكتور "المطلوب دفعه" —
    // نملي بيانات الخدمة/السعر من هناك تلقائيًا عشان الاستقبال ميحتاجش يدخلها تاني.
    if (appt.needs_billing && appt.pending_service_id) {
      const svc = services.find((s) => s.id === appt.pending_service_id) ?? null;
      setSelectedService(svc);
      setPrice(appt.pending_price != null ? String(appt.pending_price) : svc ? String(svc.default_price) : "");
      setDiscountPercent(appt.pending_discount_percent != null ? String(appt.pending_discount_percent) : "0");
      setAmountNow("");
      setAmountTouched(false);
    } else {
      setSelectedService(null);
      setPrice("");
      setDiscountPercent("0");
      setAmountNow("");
      setAmountTouched(false);
    }
    setBillingModal({ apptId: appt.id, patientId: appt.patient_id, patientName: appt.patient_name, mode: "collect" });
  }

  function closeBillingModal() {
    setBillingModal(null);
    setSelectedService(null);
  }

  function selectService(s: Service) {
    setSelectedService(s);
    setServiceNameSearch("");
    setServiceCodeSearch("");
    setTargetInvoiceId("");
    if (s.code === "0") {
      // خدمة متابعة: مفيش سعر/خصم — البوكس بيبان فاضي علشان يتكتب فيه اللي هيتدفع دلوقتي.
      setPrice("0");
      setDiscountPercent("0");
      setAmountNow("");
      setAmountTouched(false);
    } else {
      setPrice(String(s.default_price));
      setDiscountPercent("0");
      setAmountNow(String(s.default_price));
      setAmountTouched(false);
    }
  }

  const computedTotal = useMemo(() => {
    const p = Number(price) || 0;
    const d = Math.min(100, Math.max(0, Number(discountPercent) || 0));
    return Math.max(0, p * (1 - d / 100));
  }, [price, discountPercent]);

  // المبلغ المطلوب دفعه بيتحدث تلقائيًا مع السعر/الخصم طالما المستخدم لسه ما عدلش
  // خانة "المبلغ المدفوع دلوقتي" بنفسه يدويًا (بعد اختيار الخدمة).
  useEffect(() => {
    if (!selectedService || selectedService.code === "0" || amountTouched) return;
    setAmountNow(String(Math.round(computedTotal * 100) / 100));
  }, [computedTotal, selectedService, amountTouched]);

  // مربوطين بمربعين منفصلين: البحث بالاسم بيدور على أي جزء من الاسم (substring)، لكن
  // البحث بالكود لازم يكون تطابق تام للرقم بالظبط — عشان كتابة "0" متجيبش أي خدمة
  // كودها فيه صفر زي "100" أو "120" أو "160"، تجيب بس اللي كودها "0" نفسه.
  const filteredServices = useMemo(() => {
    const nameQ = serviceNameSearch.trim();
    const codeQ = serviceCodeSearch.trim();
    if (!nameQ && !codeQ) return [];
    const byName = nameQ ? services.filter((s) => s.name.includes(nameQ)) : [];
    const byCode = codeQ ? services.filter((s) => s.code === codeQ) : [];
    const merged = new Map<number, Service>();
    for (const s of [...byName, ...byCode]) merged.set(s.id, s);
    return [...merged.values()].slice(0, 8);
  }, [serviceNameSearch, serviceCodeSearch, services]);

  const selectedTargetBalance = useMemo(() => {
    if (!targetInvoiceId || !followupOptions) return null;
    return followupOptions.find((f) => String(f.id) === targetInvoiceId) ?? null;
  }, [targetInvoiceId, followupOptions]);

  function submitBilling() {
    if (!billingModal || !selectedService) return;
    const isFollowup = selectedService.code === "0";
    if (isFollowup && !targetInvoiceId) return;

    const fd = new FormData();
    fd.set("appointment_id", String(billingModal.apptId));
    fd.set("service_id", String(selectedService.id));
    fd.set("payment_method", paymentMethod);
    fd.set("amount_now", String(Number(amountNow) || 0));
    if (isFollowup) {
      fd.set("target_invoice_id", targetInvoiceId);
    } else {
      fd.set("price", String(Number(price) || 0));
      fd.set("discount_percent", String(Number(discountPercent) || 0));
    }
    startTransition(() => {
      recordAppointmentBillingAction(fd);
    });
    closeBillingModal();
  }

  // بوكس "المطلوب دفعه" (لمين معهوش صلاحية تحصيل المدفوعات) — بيسجل الخدمة والسعر
  // المتوقع كـ pending_* على الموعد نفسه من غير أي زيارة/فاتورة أو دفع فعلي.
  function submitPending() {
    if (!billingModal || !selectedService) return;
    const fd = new FormData();
    fd.set("appointment_id", String(billingModal.apptId));
    fd.set("service_id", String(selectedService.id));
    fd.set("price", String(Number(price) || 0));
    fd.set("discount_percent", String(Number(discountPercent) || 0));
    startTransition(() => {
      recordPendingBillingAction(fd);
    });
    closeBillingModal();
  }

  const durationOptions = [1, 2, 3, 4].map((n) => n * slotMinutes);

  return (
    <div className="space-y-3">
      {/* بحث فوري عن مريض */}
      <div className="relative max-w-sm">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="بحث عن مريض بالاسم أو رقم الملف..."
          className="w-full rounded-md border border-border bg-background px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
        {searchResults.length > 0 && (
          <div className="absolute z-20 mt-1 w-full bg-surface border border-border rounded-md shadow-lg overflow-hidden">
            {searchResults.map((p) => {
              const todays = apptByPatient.get(p.id) ?? [];
              return (
                <div key={p.id} className="flex items-center justify-between gap-2 px-3 py-2 text-sm border-b border-border last:border-b-0 hover:bg-primary-soft">
                  <div>
                    <div className="font-medium">{p.full_name}</div>
                    <div className="text-xs text-muted">ملف {p.file_number}</div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    {todays.map((a) => (
                      <button
                        key={a.id}
                        type="button"
                        onClick={() => jumpToAppointment(a.id)}
                        className="text-xs px-2 py-1 rounded-md bg-primary-soft text-primary-dark hover:bg-primary hover:text-white"
                        title="روح لموعده في الجدول"
                      >
                        {a.start_time}
                      </button>
                    ))}
                    <Link
                      href={`/patients/${p.id}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs px-2 py-1 rounded-md border border-border hover:bg-primary-soft whitespace-nowrap"
                    >
                      فتح الملف
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* legend */}
      <div className="flex flex-wrap items-center gap-3 text-xs text-muted">
        {(["booked", "attended", "done", "no_show"] as const).map((s) => (
          <span key={s} className="flex items-center gap-1">
            <span className={`inline-block w-3 h-3 rounded-sm border ${statusClasses(s)}`} />
            {STATUS_LABELS[s]}
          </span>
        ))}
        {canEdit ? (
          <span className="text-muted">
            دوس على خانة فاضية للحجز، أو دوس بالزر اليمين على موعد لتغيير حالته. الموعد اللي "تم" مبيترجعش أو يتلغي.
            {" "}
            <span className="text-danger font-semibold">محتاج تحصيل</span> يعني "تم" بس لسه من غير فوترة
            {canCollectPayments ? " — دوس بالزر اليمين عليه لتسجيل التحصيل." : "."}
          </span>
        ) : (
          <span className="text-muted">عرض فقط — التعديل في الجدول (حجز/تغيير حالة) مقصور على الاستقبال.</span>
        )}
      </div>

      {/* central grid */}
      <div className="bg-surface border border-border rounded-xl overflow-auto max-h-[70vh]">
        <table className="w-full text-xs border-collapse">
          <thead className="sticky top-0 z-10">
            <tr className="bg-primary-soft text-primary-dark">
              <th className="sticky right-0 z-20 bg-primary-soft px-2 py-2 font-medium whitespace-nowrap">الوقت</th>
              {rooms.map((r) => (
                <th key={r.id} className="px-2 py-2 font-medium whitespace-nowrap min-w-[140px]">
                  {r.name}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {timeSlots.map((time, rowIdx) => (
              <tr key={time}>
                <td className="sticky right-0 bg-surface z-10 px-2 py-1 text-muted whitespace-nowrap border-e border-border">{time}</td>
                {rooms.map((room) => {
                  const plan = plans[room.id]?.[rowIdx] ?? { kind: "empty" as const };
                  if (plan.kind === "skip") return null;
                  if (plan.kind === "start") {
                    const appt = plan.appt;
                    const highlighted = highlightApptId === appt.id;
                    // موعد "تم" وليه فاتورة/زيارة مسجلة بقى سجل نهائي — مينفعش يتلغى أو تتغير
                    // حالته تاني. لو "تم" بس لسه محتاج تحصيل (حصل "تم" من غير بوكس)، بس
                    // اللي عنده صلاحية تحصيل المدفوعات هو اللي يقدر يفتحله قايمة (لتسجيل
                    // التحصيل بأثر رجعي) — أي حد تاني (زي الدكتور اللي حدده) مش هيقدر يعمل
                    // حاجة تانية بيه.
                    const canActOnAppt = canEdit && (appt.status !== "done" || (!!appt.needs_billing && canCollectPayments));
                    return (
                      <td
                        key={room.id}
                        id={`appt-cell-${appt.id}`}
                        rowSpan={plan.span}
                        onContextMenu={(e) => {
                          if (!canActOnAppt) return;
                          e.preventDefault();
                          setContextMenu({
                            apptId: appt.id,
                            x: e.clientX,
                            y: e.clientY,
                            patientName: appt.patient_name,
                            status: appt.status,
                            needsBilling: !!appt.needs_billing,
                          });
                        }}
                        className={`align-top p-1.5 border ${statusClasses(appt.status)} transition-shadow ${
                          canActOnAppt ? "cursor-context-menu" : "cursor-default"
                        } ${highlighted ? "ring-2 ring-primary ring-offset-1" : ""}`}
                      >
                        <Link
                          href={isDoctorView ? `/patients/${appt.patient_id}` : `/patients/${appt.patient_id}/billing`}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="font-semibold truncate block hover:underline"
                          title={isDoctorView ? "فتح الملف الطبي" : "فتح الملف المالي"}
                        >
                          {appt.patient_name}
                        </Link>
                        <div className="text-[10px] truncate">{appt.doctor_name}</div>
                        <div className="text-[10px] opacity-80">{STATUS_LABELS[appt.status]}</div>
                        {appt.status === "done" && appt.needs_billing && (
                          <div className="text-[10px] font-semibold text-danger">
                            محتاج تحصيل
                            {appt.pending_service_name && (
                              <>
                                {" "}
                                — {appt.pending_service_name} ·{" "}
                                {Math.max(0, (appt.pending_price ?? 0) * (1 - (appt.pending_discount_percent ?? 0) / 100)).toFixed(0)} ج.م
                              </>
                            )}
                          </div>
                        )}
                        {appt.notes && <div className="text-[10px] opacity-70 truncate">{appt.notes}</div>}
                      </td>
                    );
                  }
                  return (
                    <td
                      key={room.id}
                      onClick={canEdit ? () => openBookingModal(room.id, room.name, time) : undefined}
                      className={`border border-border h-7 ${canEdit ? "cursor-pointer hover:bg-primary-soft/50" : ""}`}
                      title={canEdit ? "دوس للحجز" : undefined}
                    />
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* right-click context menu */}
      {contextMenu && (
        <div
          ref={menuRef}
          style={{ position: "fixed", top: contextMenu.y, left: contextMenu.x }}
          className="z-50 bg-surface border border-border rounded-md shadow-lg py-1 text-sm min-w-[140px]"
        >
          <div className="px-3 py-1.5 text-xs text-muted border-b border-border truncate">{contextMenu.patientName}</div>
          {contextMenu.status === "done" ? (
            // بيوصل هنا بس لو الموعد "تم" ومحتاج تحصيل ومعاه صلاحية التحصيل (اتفحص قبل
            // فتح القايمة أصلاً) — الخيار الوحيد المتاح هو تسجيل التحصيل بأثر رجعي، من غير
            // أي إمكانية للرجوع لحالة تانية أو الإلغاء.
            <button
              type="button"
              onClick={() => {
                const appt = liveAppointments.find((a) => a.id === contextMenu.apptId);
                if (!appt) return;
                onMarkDone(appt);
              }}
              className="w-full text-right px-3 py-1.5 hover:bg-primary-soft"
            >
              تسجيل التحصيل
            </button>
          ) : (
            <>
              <button type="button" onClick={() => setStatus(contextMenu.apptId, "attended")} className="w-full text-right px-3 py-1.5 hover:bg-primary-soft">
                حضر
              </button>
              <button
                type="button"
                onClick={() => {
                  const appt = liveAppointments.find((a) => a.id === contextMenu.apptId);
                  if (!appt) return;
                  onMarkDone(appt);
                }}
                className="w-full text-right px-3 py-1.5 hover:bg-primary-soft"
              >
                تم
              </button>
              <button
                type="button"
                onClick={() => setStatus(contextMenu.apptId, "cancelled")}
                className="w-full text-right px-3 py-1.5 hover:bg-danger-soft text-danger"
              >
                إلغاء (تفضية الخانة)
              </button>
            </>
          )}
        </div>
      )}

      {/* booking modal */}
      {bookingModal && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={closeBookingModal}>
          <form
            onClick={(e) => e.stopPropagation()}
            onSubmit={submitBooking}
            className="bg-surface border border-border rounded-xl p-5 w-full max-w-sm space-y-3"
          >
            <h3 className="font-semibold">
              حجز — {bookingModal.roomName} · {bookingModal.startTime}
            </h3>
            <input type="hidden" name="appointment_date" value={date} />
            <input type="hidden" name="room_id" value={bookingModal.roomId} />
            <input type="hidden" name="start_time" value={bookingModal.startTime} />

            <div className="relative">
              <label className="block text-xs text-muted mb-1">المريض</label>
              <input type="hidden" name="patient_id" value={bookingSelectedPatient?.id ?? ""} />
              {bookingSelectedPatient ? (
                <div className="flex items-center justify-between gap-2 rounded-md border border-border bg-background px-2 py-1.5 text-sm">
                  <span>
                    {bookingSelectedPatient.full_name} ({bookingSelectedPatient.file_number})
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setBookingSelectedPatient(null);
                      setBookingPatientSearch("");
                    }}
                    className="text-xs text-primary hover:underline shrink-0"
                  >
                    تغيير
                  </button>
                </div>
              ) : (
                <>
                  <input
                    type="text"
                    autoFocus
                    value={bookingPatientSearch}
                    onChange={(e) => setBookingPatientSearch(e.target.value)}
                    placeholder="اكتب اسم المريض أو رقم الملف..."
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                  {bookingPatientResults.length > 0 && (
                    <div className="absolute z-10 mt-1 w-full bg-surface border border-border rounded-md shadow-lg overflow-hidden max-h-48 overflow-y-auto">
                      {bookingPatientResults.map((p) => (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => {
                            setBookingSelectedPatient(p);
                            setBookingPatientSearch("");
                          }}
                          className="w-full text-right px-3 py-1.5 text-sm hover:bg-primary-soft flex items-center justify-between gap-2"
                        >
                          <span>{p.full_name}</span>
                          <span className="text-xs text-muted shrink-0">{p.file_number}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>

            <div>
              <label className="block text-xs text-muted mb-1">الدكتور</label>
              <select name="doctor_id" required className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm">
                <option value="">اختر دكتور</option>
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.full_name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-muted mb-1">المدة</label>
              <select name="duration_minutes" defaultValue={slotMinutes} className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm">
                {durationOptions.map((m) => (
                  <option key={m} value={m}>
                    {m} دقيقة
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-muted mb-1">ملاحظات (اختياري)</label>
              <input name="notes" className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
            </div>

            <div className="flex gap-2 justify-end pt-1">
              <button type="button" onClick={closeBookingModal} className="px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft">
                إلغاء
              </button>
              <button
                type="submit"
                disabled={!bookingSelectedPatient}
                className="px-3 py-1.5 rounded-md bg-primary text-white text-sm font-medium hover:bg-primary-dark disabled:opacity-50 disabled:cursor-not-allowed"
              >
                + حجز
              </button>
            </div>
          </form>
        </div>
      )}

      {/* بوكس التحصيل — بيتفتح لما يتم اختيار "تم" (لو المستخدم عنده صلاحية تحصيل المدفوعات) */}
      {billingModal && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={closeBillingModal}>
          <div onClick={(e) => e.stopPropagation()} className="bg-surface border border-border rounded-xl p-5 w-full max-w-sm space-y-3 max-h-[90vh] overflow-y-auto">
            <h3 className="font-semibold">
              {billingModal.mode === "collect" ? "تحصيل" : "المطلوب دفعه"} — {billingModal.patientName}
            </h3>
            {billingModal.mode === "pending" && (
              <p className="text-xs text-muted -mt-2">
                حدد الخدمة والسعر المتوقع بس من غير تسجيل دفع فعلي — الاستقبال هيشوفها ويسجل التحصيل الفعلي بعدين.
              </p>
            )}

            {/* اختيار الخدمة بالبحث بالاسم أو الكود */}
            <div className="relative">
              <label className="block text-xs text-muted mb-1">الخدمة</label>
              {selectedService ? (
                <div className="flex items-center justify-between gap-2 rounded-md border border-border bg-background px-2 py-1.5 text-sm">
                  <span>
                    {selectedService.name} {selectedService.code ? `(${selectedService.code})` : ""}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedService(null);
                      setFollowupOptions(null);
                      setTargetInvoiceId("");
                      setServiceNameSearch("");
                      setServiceCodeSearch("");
                    }}
                    className="text-xs text-primary hover:underline shrink-0"
                  >
                    تغيير
                  </button>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      autoFocus
                      value={serviceNameSearch}
                      onChange={(e) => setServiceNameSearch(e.target.value)}
                      placeholder="بحث بالاسم..."
                      className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                    <input
                      type="text"
                      value={serviceCodeSearch}
                      onChange={(e) => setServiceCodeSearch(e.target.value)}
                      placeholder="بحث بالكود (بالظبط)..."
                      className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  {filteredServices.length > 0 && (
                    <div className="absolute z-10 mt-1 w-full bg-surface border border-border rounded-md shadow-lg overflow-hidden max-h-48 overflow-y-auto">
                      {filteredServices.map((s) => (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => selectService(s)}
                          className="w-full text-right px-3 py-1.5 text-sm hover:bg-primary-soft flex items-center justify-between gap-2"
                        >
                          <span>{s.name}</span>
                          <span className="text-xs text-muted shrink-0">
                            {s.code ? `#${s.code}` : ""} {s.code !== "0" ? `— ${s.default_price} ج.م` : ""}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>

            {/* بوكس "المطلوب دفعه" (مين معهوش صلاحية تحصيل المدفوعات) — سعر وخصم بس،
                من غير مبلغ مدفوع أو وسيلة دفع، لأنه مش بيسجل دفع فعلي. */}
            {selectedService && billingModal.mode === "pending" && (
              <>
                <div>
                  <label className="block text-xs text-muted mb-1">السعر</label>
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs text-muted mb-1">خصم (%)</label>
                  <input
                    type="number"
                    step="1"
                    min={0}
                    max={100}
                    value={discountPercent}
                    onChange={(e) => setDiscountPercent(e.target.value)}
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
                <div className="text-sm">
                  المطلوب دفعه: <span className="font-semibold">{computedTotal.toFixed(0)} ج.م</span>
                </div>
              </>
            )}

            {selectedService && billingModal.mode === "collect" && selectedService.code === "0" && (
              <>
                <div>
                  <label className="block text-xs text-muted mb-1">الخدمة الأصلية (اللي هتتخصم منها الدفعة)</label>
                  {loadingFollowups ? (
                    <div className="text-xs text-muted">جاري التحميل...</div>
                  ) : followupOptions && followupOptions.length > 0 ? (
                    <select
                      value={targetInvoiceId}
                      onChange={(e) => setTargetInvoiceId(e.target.value)}
                      className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                    >
                      <option value="">اختر خدمة</option>
                      {followupOptions.map((f) => (
                        <option key={f.id} value={f.id}>
                          {f.service_name} — {f.visit_date} — الباقي {f.balance.toFixed(0)} ج.م
                        </option>
                      ))}
                    </select>
                  ) : (
                    <div className="text-xs text-danger">مفيش فواتير سابقة لسه عليها مبلغ مستحق لهذا المريض.</div>
                  )}
                </div>

                {selectedTargetBalance && (
                  <div className="text-sm">
                    الباقي المستحق: <span className="text-danger font-semibold">{selectedTargetBalance.balance.toFixed(0)} ج.م</span>
                  </div>
                )}

                <div>
                  <label className="block text-xs text-muted mb-1">المبلغ المدفوع دلوقتي</label>
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    value={amountNow}
                    onChange={(e) => setAmountNow(e.target.value)}
                    placeholder="0"
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
              </>
            )}

            {selectedService && billingModal.mode === "collect" && selectedService.code !== "0" && (
              <>
                <div>
                  <label className="block text-xs text-muted mb-1">السعر</label>
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs text-muted mb-1">خصم (%)</label>
                  <input
                    type="number"
                    step="1"
                    min={0}
                    max={100}
                    value={discountPercent}
                    onChange={(e) => setDiscountPercent(e.target.value)}
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
                <div className="text-sm">
                  المطلوب دفعه: <span className="font-semibold">{computedTotal.toFixed(0)} ج.م</span>
                </div>
                <div>
                  <label className="block text-xs text-muted mb-1">المبلغ المدفوع دلوقتي</label>
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    value={amountNow}
                    onChange={(e) => {
                      setAmountTouched(true);
                      setAmountNow(e.target.value);
                    }}
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
              </>
            )}

            {selectedService && billingModal.mode === "collect" && (
              <div>
                <label className="block text-xs text-muted mb-1">وسيلة الدفع</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                >
                  {PAYMENT_METHODS.map((m) => (
                    <option key={m.value} value={m.value}>
                      {m.label}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="flex items-center justify-between gap-2 pt-1 flex-wrap">
              <button
                type="button"
                onClick={() => {
                  setStatus(billingModal.apptId, "done");
                  closeBillingModal();
                }}
                className="text-xs text-muted hover:underline"
              >
                تخطي وتحديد &quot;تم&quot; من غير تسجيل مالي
              </button>
              <div className="flex gap-2">
                <button type="button" onClick={closeBillingModal} className="px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft">
                  إلغاء
                </button>
                {billingModal.mode === "pending" ? (
                  <button
                    type="button"
                    disabled={!selectedService}
                    onClick={submitPending}
                    className="px-3 py-1.5 rounded-md bg-primary text-white text-sm font-medium hover:bg-primary-dark disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    تسجيل المطلوب و&quot;تم&quot;
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={!selectedService || (selectedService.code === "0" && !targetInvoiceId)}
                    onClick={submitBilling}
                    className="px-3 py-1.5 rounded-md bg-primary text-white text-sm font-medium hover:bg-primary-dark disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    تسجيل وإنهاء
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
