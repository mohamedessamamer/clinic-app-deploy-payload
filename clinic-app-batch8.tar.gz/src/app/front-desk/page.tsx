import { db } from "@/lib/db/client";
import FrontDeskClient from "@/components/FrontDeskClient";
import CentralSchedule from "@/components/CentralSchedule";
import { getAllSettings, buildTimeSlots, weekdayOf } from "@/lib/settings";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getDoctorRoomIdsForDate } from "@/lib/schedule";

export default async function FrontDeskPage({
  searchParams,
}: {
  searchParams: Promise<{ date?: string; room?: string }>;
}) {
  const { date, room } = await searchParams;
  const day = date && /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : new Date().toISOString().slice(0, 10);
  const weekday = weekdayOf(day);

  const session = await getSession();
  const [canEditSchedule, canSeeAllRooms, canCollectPayments] = session
    ? await Promise.all([
        hasPermission(session.userId, session.role, "schedule_edit"),
        hasPermission(session.userId, session.role, "schedule_all_rooms"),
        hasPermission(session.userId, session.role, "collect_payments"),
      ])
    : [false, false, false];

  const rooms = await db.selectFrom("rooms").selectAll().execute();
  const roomId = room ? Number(room) : rooms[0]?.id ?? null;

  // لو المستخدم معهوش صلاحية "كل الغرف" وهو دكتور، الجدول المركزي بيتقيد على
  // الغرفة/الغرف اللي شيفته فيها النهاردة بس. أي دور تاني (استقبال/محاسب...) من
  // غير الصلاحية دي حالة نادرة (الأدمن يقدر يقيّدها يدويًا) فبيشوف كل الغرف برضه
  // لعدم وجود مفهوم "شيفت" له.
  const doctorRoomIds =
    !canSeeAllRooms && session?.doctorId ? await getDoctorRoomIdsForDate(session.doctorId, day) : null;
  const visibleRooms = doctorRoomIds ? rooms.filter((r) => doctorRoomIds.includes(r.id)) : rooms;

  const [patients, services, doctors, shiftForRoom, rowsRaw, appointmentsRaw, billedApptRows, settings] = await Promise.all([
    db.selectFrom("patients").select(["id", "full_name", "file_number"]).orderBy("id", "desc").limit(500).execute(),
    db.selectFrom("services").select(["id", "name", "default_price", "code"]).execute(),
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).execute(),
    roomId
      ? db
          .selectFrom("doctor_weekly_shifts")
          .select(["doctor_id"])
          .where("room_id", "=", roomId)
          .where("weekday", "=", weekday)
          .orderBy("start_time")
          .limit(1)
          .executeTakeFirst()
      : Promise.resolve(undefined),
    db
      .selectFrom("visits")
      .innerJoin("patients", "patients.id", "visits.patient_id")
      .innerJoin("invoices", "invoices.visit_id", "visits.id")
      .leftJoin("services", "services.id", "visits.service_id")
      .leftJoin("doctors", "doctors.id", "visits.primary_doctor_id")
      .select([
        "invoices.id",
        "visits.id as visit_id",
        "patients.id as patient_id",
        "patients.full_name as patient_name",
        "visits.visit_date",
        "services.name as service_name",
        "invoices.discount_percent",
        "invoices.original_price",
        "invoices.amount",
        "invoices.price_overridden",
        "doctors.full_name as doctor_name",
      ])
      .where("visits.visit_date", "=", day)
      .$if(!!roomId, (qb) => qb.where("visits.room_id", "=", roomId!))
      .orderBy("invoices.id", "desc")
      .execute(),
    db
      .selectFrom("appointments")
      .innerJoin("patients", "patients.id", "appointments.patient_id")
      .leftJoin("doctors", "doctors.id", "appointments.doctor_id")
      .leftJoin("services", "services.id", "appointments.pending_service_id")
      .select([
        "appointments.id",
        "appointments.patient_id",
        "patients.full_name as patient_name",
        "appointments.doctor_id",
        "doctors.full_name as doctor_name",
        "appointments.room_id",
        "appointments.start_time",
        "appointments.duration_minutes",
        "appointments.status",
        "appointments.notes",
        "appointments.pending_service_id",
        "appointments.pending_price",
        "appointments.pending_discount_percent",
        "services.name as pending_service_name",
      ])
      .where("appointment_date", "=", day)
      .where("status", "!=", "cancelled")
      .orderBy("appointments.start_time")
      .execute(),
    db
      .selectFrom("visits")
      .select("appointment_id")
      .where("visit_date", "=", day)
      .where("appointment_id", "is not", null)
      .execute(),
    getAllSettings(),
  ]);

  const defaultDoctorId = shiftForRoom?.doctor_id ?? null;
  const slotMinutes = Number(settings.slot_minutes);
  const timeSlots = buildTimeSlots(settings.day_start, settings.day_end, slotMinutes);

  // موعد "تم" وليه زيارة مرتبطة بيه (appointment_id) يبقى اتحصّل عليه أصلاً؛ لو "تم"
  // من غير زيارة مرتبطة، يبقى محتاج تحصيل (شوف needs_billing في CentralSchedule).
  const billedApptIds = new Set(billedApptRows.map((r) => r.appointment_id).filter((id): id is number => id != null));

  const appointments = appointmentsRaw.map((a) => ({
    id: a.id,
    patient_id: a.patient_id,
    patient_name: a.patient_name,
    doctor_id: a.doctor_id,
    doctor_name: a.doctor_name ?? "-",
    room_id: a.room_id,
    start_time: a.start_time,
    duration_minutes: a.duration_minutes,
    status: a.status as "booked" | "attended" | "done" | "cancelled" | "no_show",
    notes: a.notes,
    needs_billing: a.status === "done" && !billedApptIds.has(a.id),
    pending_service_id: a.pending_service_id,
    pending_service_name: a.pending_service_name,
    pending_price: a.pending_price,
    pending_discount_percent: a.pending_discount_percent,
  }));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h1 className="text-xl font-bold">جدول الاستقبال</h1>
        <form className="flex items-center gap-2 flex-wrap">
          <label className="text-sm text-muted">اليوم:</label>
          <input type="date" name="date" defaultValue={day} className="rounded-md border border-border bg-surface px-2 py-1.5 text-sm" />
          <button type="submit" className="px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft">
            عرض
          </button>
        </form>
      </div>

      {/* الجدول المركزي: كل الغرف/العيادات في مكان واحد، بيتزامن أوتوماتيك بين أي شاشات استقبال تانية مفتوحة */}
      <section className="space-y-2">
        {visibleRooms.length === 0 ? (
          <div className="text-sm bg-danger-soft text-danger rounded-md px-3 py-2">
            مفيش شيفت أسبوعي مسجل ليك في يوم النهاردة — كلم الأدمن لو محتاج تشوف الجدول برضه.
          </div>
        ) : (
          <CentralSchedule
            date={day}
            rooms={visibleRooms}
            timeSlots={timeSlots}
            slotMinutes={slotMinutes}
            appointments={appointments}
            patients={patients}
            doctors={doctors}
            services={services}
            canEdit={canEditSchedule}
            canCollectPayments={canCollectPayments}
          />
        )}
      </section>

      {/* سجل اليوم (تسجيل الخدمات والتحصيل) — مدموج هنا تحت الجدول المركزي، مقسّم حسب الغرفة */}
      <section className="space-y-3">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <h2 className="font-semibold">سجل اليوم — تسجيل الخدمات</h2>
          <form className="flex items-center gap-2 flex-wrap">
            <input type="hidden" name="date" value={day} />
            <label className="text-sm text-muted">الغرفة:</label>
            <select name="room" defaultValue={roomId ?? ""} className="rounded-md border border-border bg-surface px-2 py-1.5 text-sm">
              {rooms.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name}
                </option>
              ))}
            </select>
            <button type="submit" className="px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft">
              عرض
            </button>
          </form>
        </div>

        {!defaultDoctorId && (
          <div className="text-sm bg-danger-soft text-danger rounded-md px-3 py-2">
            مفيش شيفت أسبوعي مسجل للغرفة دي في يوم النهاردة — حدد صاحب الشيفت من صفحة{" "}
            <a href="/settings" className="underline">
              الإعدادات
            </a>
            .
          </div>
        )}

        <FrontDeskClient
          date={day}
          roomId={roomId}
          patients={patients}
          services={services}
          doctors={doctors}
          defaultDoctorId={defaultDoctorId}
          rows={rowsRaw}
        />
      </section>
    </div>
  );
}
