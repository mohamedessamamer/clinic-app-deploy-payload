"use server";

import { cookies } from "next/headers";
import { db } from "@/lib/db/client";
import { verifyPassword } from "@/lib/auth";
import { getSession } from "@/lib/session";
import { getReportsData, type ReportsSearchParams } from "@/lib/reports-data";
import { createDoctorReportAccessToken, DOCTOR_REPORT_ACCESS_COOKIE } from "@/lib/report-access";

export async function unlockDoctorReportAction(formData: FormData): Promise<{ ok: boolean; reason?: string; url?: string }> {
  const session = await getSession();
  if (!session || session.role !== "doctor") return { ok: false, reason: "غير مسموح" };

  const password = String(formData.get("password") || "");
  const user = await db.selectFrom("users").select("password_hash").where("id", "=", session.userId).where("active", "=", 1).executeTakeFirst();
  if (!user || !(await verifyPassword(password, user.password_hash))) {
    return { ok: false, reason: "كلمة المرور غير صحيحة" };
  }

  const params: ReportsSearchParams = {
    from: String(formData.get("from") || "") || undefined,
    to: String(formData.get("to") || "") || undefined,
    doctor_id: String(formData.get("doctor_id") || "") || undefined,
    service_id: String(formData.get("service_id") || "") || undefined,
  };
  const data = await getReportsData(session, params);
  if (!data.ok) return { ok: false, reason: "تعذر فتح التقرير بهذه البيانات" };

  const token = await createDoctorReportAccessToken({
    userId: session.userId,
    from: data.from,
    to: data.to,
    doctorId: data.doctorId,
    serviceId: data.serviceId,
  });
  const cookieStore = await cookies();
  cookieStore.set(DOCTOR_REPORT_ACCESS_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/reports",
    maxAge: 10 * 60,
  });

  const query = new URLSearchParams({ from: data.from, to: data.to, applied: "1" });
  if (data.serviceId) query.set("service_id", String(data.serviceId));
  if (data.reportsFull && data.doctorId) query.set("doctor_id", String(data.doctorId));
  return { ok: true, url: `/reports?${query.toString()}` };
}
