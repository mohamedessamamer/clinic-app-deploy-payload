import { loginAction } from "./actions";

const ERROR_MESSAGES: Record<string, string> = {
  invalid: "اسم المستخدم أو كلمة السر غير صحيحة.",
  missing: "من فضلك أدخل اسم المستخدم وكلمة السر.",
};

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; next?: string }>;
}) {
  const { error, next } = await searchParams;

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="w-full max-w-sm bg-surface border border-border rounded-xl shadow-sm p-8">
        <div className="text-center mb-6">
          <div className="text-2xl font-bold text-primary">عيادتي</div>
          <div className="text-sm text-muted mt-1">تسجيل الدخول إلى نظام إدارة العيادة</div>
        </div>

        {error && (
          <div className="mb-4 rounded-md bg-danger-soft text-danger text-sm px-3 py-2">
            {ERROR_MESSAGES[error] || "حصل خطأ، حاول تاني."}
          </div>
        )}

        <form action={loginAction} className="space-y-4">
          <input type="hidden" name="next" value={next || "/"} />
          <div>
            <label className="block text-sm text-muted mb-1" htmlFor="username">
              اسم المستخدم
            </label>
            <input
              id="username"
              name="username"
              autoComplete="username"
              required
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          <div>
            <label className="block text-sm text-muted mb-1" htmlFor="password">
              كلمة السر
            </label>
            <input
              id="password"
              name="password"
              type="password"
              autoComplete="current-password"
              required
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          <button
            type="submit"
            className="w-full rounded-md bg-primary text-white py-2 text-sm font-medium hover:bg-primary-dark transition-colors"
          >
            دخول
          </button>
        </form>
      </div>
    </div>
  );
}
