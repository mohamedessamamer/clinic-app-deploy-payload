"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { db } from "@/lib/db/client";
import { SESSION_COOKIE, createSessionToken, verifyPassword } from "@/lib/auth";

export async function loginAction(formData: FormData) {
  const username = String(formData.get("username") || "").trim();
  const password = String(formData.get("password") || "");
  const next = String(formData.get("next") || "/");

  if (!username || !password) {
    redirect(`/login?error=missing&next=${encodeURIComponent(next)}`);
  }

  const user = await db
    .selectFrom("users")
    .selectAll()
    .where("username", "=", username)
    .where("active", "=", 1)
    .executeTakeFirst();

  if (!user || !(await verifyPassword(password, user.password_hash))) {
    redirect(`/login?error=invalid&next=${encodeURIComponent(next)}`);
  }

  const token = await createSessionToken({
    userId: user.id,
    username: user.username,
    fullName: user.full_name,
    role: user.role,
    doctorId: user.doctor_id,
  });

  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 12,
  });

  redirect(next && next.startsWith("/") ? next : "/");
}
