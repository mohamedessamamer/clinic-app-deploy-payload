"use server";

import { revalidatePath } from "next/cache";
import { setSetting } from "@/lib/settings";

export async function saveSettingsAction(formData: FormData) {
  const slot_minutes = String(formData.get("slot_minutes") || "15");
  const day_start = String(formData.get("day_start") || "09:00");
  const day_end = String(formData.get("day_end") || "22:00");

  await setSetting("slot_minutes", slot_minutes);
  await setSetting("day_start", day_start);
  await setSetting("day_end", day_end);

  revalidatePath("/settings");
  revalidatePath("/appointments");
}
