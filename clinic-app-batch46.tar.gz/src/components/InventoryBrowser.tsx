"use client";

import { useMemo, useState, useTransition, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { addInventoryCategoryAction, archiveInventoryCategoryAction, archiveInventoryItemAction, receiveInventorySupplyAction, recordInventoryCountAction, saveInventoryItemUsageSettingsAction, setInventoryItemAvailabilityAction, updateInventoryItemAdminAction } from "@/app/inventory/actions";
import OrthodonticBracketStock from "@/components/OrthodonticBracketStock";

type Specialty = { id: number; name: string };
type Category = { id: number; specialty_id: number; name: string };
type Item = {
  id: number;
  name: string;
  quantity: number;
  unit: string | null;
  specialty_id: number | null;
  category_id: number | null;
  catalog_group: string | null;
  critical_stock_threshold: number;
  auto_deduction_key: string | null;
  auto_deduction_per_attachment: number;
  available_in_clinical_selection: number;
};
type Batch = { id: number; item_id: number; brand: string | null; supplier_name: string | null; quantity_received: number; quantity_remaining: number; total_cost: number | null; purchase_unit_label: string | null; package_count: number | null; units_per_package: number | null; };
type Supplier = { id: number; name: string };

const inputClass = "w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm";

// نقطة الدخول اليومية للمخزن: التخصص ثم الفئة ثم المجموعة الفرعية. لا تُظهر
// شاشة التوريد الكاملة إلا عند الحاجة؛ الشراء المعتاد يتسجل بجوار الصنف نفسه.
export default function InventoryBrowser({ specialties, categories, items, canEditCatalog, canManage, isAdmin, suppliers = [], bracketStock = [], batches = [] }: {
  specialties: Specialty[];
  categories: Category[];
  items: Item[];
  canEditCatalog: boolean;
  canManage: boolean;
  isAdmin: boolean;
  suppliers?: Supplier[];
  bracketStock?: Array<{ brand: string; fdi: number; quantity: number }>;
  batches?: Batch[];
}) {
  const [specialtyId, setSpecialtyId] = useState<number | null>(null);
  const [categoryId, setCategoryId] = useState<number | null>(null);
  const [addingCategory, setAddingCategory] = useState(false);
  const [isPending, startTransition] = useTransition();
  const router = useRouter();
  const visibleCategories = useMemo(() => categories.filter((category) => category.specialty_id === specialtyId), [categories, specialtyId]);
  const visibleItems = useMemo(() => items.filter((item) => item.category_id === categoryId), [items, categoryId]);
  const groups = useMemo(() => {
    const map = new Map<string, Item[]>();
    for (const item of visibleItems) {
      const group = item.catalog_group || "أصناف أخرى";
      map.set(group, [...(map.get(group) ?? []), item]);
    }
    return Array.from(map.entries()).sort(([a], [b]) => a.localeCompare(b));
  }, [visibleItems]);

  const selectedCategory = categories.find((category) => category.id === categoryId);
  const showingBrackets = selectedCategory?.name.toUpperCase() === "BRACKETS";
  const batchesByItem = useMemo(() => {
    const map = new Map<number, Batch[]>();
    for (const batch of batches) map.set(batch.item_id, [...(map.get(batch.item_id) ?? []), batch]);
    return map;
  }, [batches]);
  function submit(action: (formData: FormData) => Promise<void>, after?: () => void) {
    return (event: FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      const form = event.currentTarget;
      startTransition(async () => { await action(new FormData(form)); form.reset(); after?.(); router.refresh(); });
    };
  }
  function removeCategory(category: Category) {
    if (!window.confirm(`هل أنت متأكد من حذف فئة «${category.name}»؟`)) return;
    if (!window.confirm("سيقوم هذا الإجراء بحذف البيان بالكامل وما يحتويه من خامات من شاشة المخزن. هل تريد المتابعة؟")) return;
    startTransition(async () => { await archiveInventoryCategoryAction(category.id); if (categoryId === category.id) setCategoryId(null); router.refresh(); });
  }
  return <section className="card-3d rounded-xl p-5 space-y-4">
    <div>
      <h2 className="font-semibold">تصفح المخزن والجرد السريع</h2>
      <p className="text-xs text-muted mt-1">اختر التخصص، ثم الفئة. الرصيد بوحدة الاستهلاك، أما الشراء فيسجل كعبوات ومحتوى كل عبوة داخل تفاصيل الصنف.</p>
    </div>

    <div className="max-w-sm">
      <label className="block text-xs text-muted mb-1">التخصص</label>
      <select value={specialtyId ?? ""} onChange={(event) => { setSpecialtyId(event.target.value ? Number(event.target.value) : null); setCategoryId(null); }} className={inputClass}>
        <option value="">اختر التخصص</option>
        {specialties.map((specialty) => <option key={specialty.id} value={specialty.id}>{specialty.name}</option>)}
      </select>
    </div>

    {specialtyId && <div className="flex flex-wrap gap-2 items-center">
      {visibleCategories.map((category) => {
        const count = category.name.toUpperCase() === "BRACKETS" ? bracketStock.length : items.filter((item) => item.category_id === category.id).length;
        return <span key={category.id} className={`inline-flex overflow-hidden rounded-lg border text-sm transition ${categoryId === category.id ? "border-primary bg-primary-soft text-primary-dark font-semibold" : "border-border hover:bg-primary-soft"}`}><button type="button" onClick={() => setCategoryId(category.id)} className="px-3 py-2">{category.name} <span className="text-xs opacity-70">({count})</span></button>{isAdmin && <button type="button" onClick={() => removeCategory(category)} disabled={isPending} aria-label={`حذف فئة ${category.name}`} className="border-r border-current/15 px-2 text-red-600 hover:bg-red-50 disabled:opacity-50">×</button>}</span>;
      })}
      {isAdmin && <button type="button" onClick={() => setAddingCategory((value) => !value)} className="rounded-lg border border-dashed border-primary px-3 py-2 text-primary hover:bg-primary-soft" aria-label="إضافة فئة">+</button>}
      {visibleCategories.length === 0 && <span className="text-sm text-muted">لا توجد فئات تحت هذا التخصص بعد.</span>}
    </div>}

    {specialtyId && addingCategory && isAdmin && <form onSubmit={submit(addInventoryCategoryAction, () => setAddingCategory(false))} className="flex flex-wrap items-end gap-2 rounded-lg border border-dashed border-primary/50 bg-primary-soft/30 p-3"><input type="hidden" name="specialty_id" value={specialtyId} /><label className="text-sm"><span className="block text-xs text-muted mb-1">اسم الفئة الجديدة</span><input name="name" required autoFocus className={inputClass} /></label><button disabled={isPending} className="rounded-md btn-3d-primary px-3 py-1.5 text-sm disabled:opacity-60">إضافة</button><button type="button" onClick={() => setAddingCategory(false)} className="rounded-md border border-border px-3 py-1.5 text-sm">إلغاء</button></form>}

    {categoryId && <div className="space-y-4">
      {showingBrackets && <OrthodonticBracketStock cells={bracketStock} canEditCatalog={canEditCatalog} />}
      {groups.map(([group, groupItems]) => <div key={group} className="rounded-lg border border-border overflow-hidden">
        <div className="bg-primary-soft px-4 py-2 text-sm font-semibold">{group}</div>
        <div className="divide-y divide-border">
          <div className="hidden xl:grid xl:grid-cols-[minmax(180px,1fr)_auto_auto_auto] gap-3 items-center bg-muted/30 px-4 py-2 text-xs font-semibold text-muted">
            <span>الصنف</span><span>المخزون الحالي</span><span>بيانات التوريد والجرد</span><span>وحدة الاستهلاك / الحد الحرج</span>
          </div>
          {groupItems.map((item) => <div key={item.id} className="grid grid-cols-1 xl:grid-cols-[minmax(180px,1fr)_auto_auto_auto] gap-3 items-center px-4 py-3">
            <div className="font-medium text-sm">{item.name}</div>
            <div className="rounded-md border border-primary/30 bg-primary-soft px-3 py-1.5 text-sm whitespace-nowrap">المخزون: <b>{item.quantity}</b> {item.unit ?? ""}</div>
            <span className="text-xs text-muted">افتح التفاصيل لتسجيل توريد أو جرد</span>
            {canEditCatalog && <form action={saveInventoryItemUsageSettingsAction} className="flex items-center gap-1.5 flex-wrap">
              <input type="hidden" name="item_id" value={item.id} />
              <input name="unit" required defaultValue={item.unit ?? ""} placeholder="وحدة الاستعمال" aria-label={`وحدة استعمال ${item.name}`} className="w-28 rounded-md border border-border bg-background px-2 py-1.5 text-xs" />
              <input name="critical_stock_threshold" type="number" min="0" step="0.01" defaultValue={item.critical_stock_threshold || ""} placeholder="الحد الحرج" aria-label={`الحد الحرج لـ ${item.name}`} className="w-24 rounded-md border border-border bg-background px-2 py-1.5 text-xs" />
              <button className="rounded-md border border-border px-2 py-1.5 text-xs hover:bg-primary-soft">حفظ</button>
            </form>}
            <details className="xl:col-span-4 rounded-md border border-border px-2 py-1.5 text-xs">
              <summary className="cursor-pointer text-muted">بيانات التوريد والجرد</summary>
              <div className="mt-2 flex flex-wrap gap-2 items-end">
                <div className="min-w-56 flex-1 rounded border border-border bg-primary-soft/30 p-2"><span className="font-semibold">الرصيد الحالي: {item.quantity} {item.unit ?? ""}</span>{(batchesByItem.get(item.id) ?? []).filter((batch) => Boolean(batch.package_count && batch.units_per_package)).length > 0 && <ul className="mt-2 space-y-1 text-muted">{(batchesByItem.get(item.id) ?? []).filter((batch) => Boolean(batch.package_count && batch.units_per_package)).map((batch) => <li key={batch.id}>• {batch.brand ?? "بدون شركة"} — {batch.supplier_name ?? "بدون مورد"}: {batch.package_count} {batch.purchase_unit_label ?? "عبوة"} × {batch.units_per_package} {item.unit ?? ""} — المتبقي {batch.quantity_remaining}/{batch.quantity_received} {item.unit ?? ""}{batch.total_cost != null ? ` — ${batch.total_cost.toFixed(0)} ج.م` : ""}</li>)}</ul>}</div>
                {canManage && <form onSubmit={submit(receiveInventorySupplyAction)} className="flex flex-wrap gap-2 items-end rounded border border-border bg-background p-2"><input type="hidden" name="item_id" value={item.id} /><label><span className="block mb-1 text-muted">المورد</span><select name="supplier_id" required className="w-32 rounded border border-border bg-background px-2 py-1"><option value="">اختر المورد</option>{suppliers.map((supplier) => <option key={supplier.id} value={supplier.id}>{supplier.name}</option>)}</select></label><label><span className="block mb-1 text-muted">الشركة</span><input name="brand" placeholder="American" className="w-24 rounded border border-border bg-background px-2 py-1" /></label><label><span className="block mb-1 text-muted">وحدة الشراء</span><input name="purchase_unit_label" required defaultValue="علبة" className="w-20 rounded border border-border bg-background px-2 py-1" /></label><label><span className="block mb-1 text-muted">عدد العبوات</span><input name="package_count" type="number" min="0.01" step="0.01" required className="w-20 rounded border border-border bg-background px-2 py-1" /></label><label><span className="block mb-1 text-muted">داخل العبوة ({item.unit ?? "وحدة"})</span><input name="units_per_package" type="number" min="0.01" step="0.01" required className="w-20 rounded border border-border bg-background px-2 py-1" /></label><label><span className="block mb-1 text-muted">التكلفة</span><input name="total_cost" type="number" min="0" step="0.01" className="w-20 rounded border border-border bg-background px-2 py-1" /></label><button disabled={isPending} className="rounded-md btn-3d-primary px-3 py-1 text-xs disabled:opacity-60">تسجيل التوريد</button></form>}
                {canManage && <div className="flex flex-wrap gap-2 items-end"><form action={recordInventoryCountAction} className="flex gap-1 items-end"><input type="hidden" name="item_id" value={item.id} /><label><span className="block mb-1 text-muted">جرد فعلي ({item.unit ?? "وحدة الاستهلاك"})</span><input name="counted_quantity" type="number" min="0" step="0.01" defaultValue={item.quantity} className="w-24 rounded border border-border bg-background px-2 py-1" /></label><button className="rounded border border-border px-2 py-1 hover:bg-primary-soft">حفظ</button></form><form action={setInventoryItemAvailabilityAction} className="flex items-end gap-1"><input type="hidden" name="item_id" value={item.id} /><label className="flex items-center gap-1 py-1"><input name="available_in_clinical_selection" type="checkbox" value="1" defaultChecked={item.available_in_clinical_selection === 1} /> يظهر للطبيب</label><button className="rounded border border-border px-2 py-1 hover:bg-primary-soft">حفظ</button></form></div>}
              </div>
            </details>
            {canEditCatalog && <details className="xl:col-span-4 rounded-md border border-border px-2 py-1.5 text-xs">
              <summary className="cursor-pointer text-muted">تعديل أو حذف الصنف</summary>
              <div className="mt-2 flex flex-wrap gap-2 items-end">
                <form action={updateInventoryItemAdminAction} className="flex flex-wrap gap-2 items-end flex-1">
                  <input type="hidden" name="item_id" value={item.id} />
                  <label><span className="block mb-1 text-muted">الاسم</span><input name="name" required defaultValue={item.name} className="w-40 rounded border border-border bg-background px-2 py-1" /></label>
                  <label><span className="block mb-1 text-muted">الفئة</span><select name="category_id" required defaultValue={item.category_id ?? ""} className="w-36 rounded border border-border bg-background px-2 py-1">{categories.map((category) => <option key={category.id} value={category.id}>{category.name}</option>)}</select></label>
                  <label><span className="block mb-1 text-muted">مجموعة فرعية</span><input name="catalog_group" defaultValue={item.catalog_group ?? ""} className="w-28 rounded border border-border bg-background px-2 py-1" /></label>
                  <label><span className="block mb-1 text-muted">الوحدة</span><input name="unit" required defaultValue={item.unit ?? ""} className="w-20 rounded border border-border bg-background px-2 py-1" /></label>
                  {item.auto_deduction_key === "orthodontic_composite" && <label><span className="block mb-1 text-muted">استهلاك لكل سن ({item.unit ?? "وحدة"})</span><input name="auto_deduction_per_attachment" type="number" min="0.01" step="0.01" required defaultValue={item.auto_deduction_per_attachment} className="w-24 rounded border border-border bg-background px-2 py-1" /></label>}
                  <label><span className="block mb-1 text-muted">الحد الحرج</span><input name="critical_stock_threshold" type="number" min="0" step="0.01" defaultValue={item.critical_stock_threshold || ""} className="w-20 rounded border border-border bg-background px-2 py-1" /></label>
                  <label className="flex items-center gap-1 py-1"><input name="available_in_clinical_selection" type="checkbox" value="1" defaultChecked /> يظهر للطبيب</label>
                  <button className="rounded border border-border px-2 py-1 hover:bg-primary-soft">حفظ التعديل</button>
                </form>
                <form action={archiveInventoryItemAction}><input type="hidden" name="item_id" value={item.id} /><button className="rounded border border-red-300 px-2 py-1 text-red-700 hover:bg-red-50">حذف من المخزن</button></form>
              </div>
            </details>}
          </div>)}
        </div>
      </div>)}
      {groups.length === 0 && !showingBrackets && <div className="rounded-lg border border-dashed border-border p-5 text-sm text-muted">لا توجد أصناف داخل هذه الفئة بعد. يمكنك إضافتها من قسم «تعريف خامة» بالأسفل.</div>}
    </div>}
  </section>;
}
