import Link from "next/link";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { redirect } from "next/navigation";
import { displayAge } from "@/lib/age";
import DeletePatientButton from "@/components/DeletePatientButton";
import { missingPatientDetails } from "@/lib/patient-details";
import { formatPatientPhone } from "@/lib/phone";

export default async function PatientsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q } = await searchParams;
  const session = await getSession();
  const isAdmin = session?.role === "admin";

  // نفس القاعدة الموحّدة من دفعة 8: "من أكونت الطبيب بيفتح الملف الطبي، من أي
  // أكونت تاني بيفتح الملف المالي" — لغاية دفعة 21 الصفحة دي كانت الاستثناء
  // الوحيد اللي بيفتح الملف الطبي لأي حد بغض النظر عن دوره، وده كان بيسبب لبس
  // للاستقبال (بيفتح الملف المالي من الجدول المركزي، بس الملف الطبي من هنا).
  // لو المستخدم مش دكتور بس مالوش صلاحية view_patient_billing فعليًا (نادر)،
  // بيرجع للملف الطبي كـ fallback عشان ميوصلش لصفحة "مفيش صلاحية" على طول.
  const isDoctorRole = session?.role === "doctor";
  const canViewPatientsList = session
    ? !isDoctorRole || (await hasPermission(session.userId, session.role, "view_patients_list"))
    : false;
  // إخفاء الرابط وحده لا يكفي: الطبيب الذي لم تُمنح له الصلاحية لا يستطيع فتح
  // قائمة كل المرضى حتى لو كتب الرابط يدويًا، بينما يظل قادرًا على فتح مريض
  // موعده من جدول اليوم والملف الطبي كما كان.
  if (!canViewPatientsList) redirect("/");
  const canViewBilling = session ? await hasPermission(session.userId, session.role, "view_patient_billing") : false;
  const patientHref = (id: number) => (!isDoctorRole && canViewBilling ? `/patients/${id}/billing` : `/patients/${id}`);

  let query = db.selectFrom("patients").selectAll().orderBy("id", "desc").limit(50);
  if (q && q.trim()) {
    const term = `%${q.trim()}%`;
    query = query.where((eb) =>
      eb.or([
        eb("full_name", "like", term),
        eb("phone", "like", term),
        eb("file_number", "like", term),
      ])
    );
  }
  const patients = await query.execute();

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h1 className="text-xl font-bold">ملفات المرضى</h1>
        <Link href="/patients/new" className="px-3 py-2 rounded-md btn-3d-primary text-sm">
          + مريض جديد
        </Link>
      </div>

      <form className="flex gap-2">
        <input
          type="text"
          name="q"
          defaultValue={q}
          placeholder="ابحث بالاسم أو رقم التليفون أو رقم الملف..."
          className="flex-1 rounded-md border border-border bg-surface px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
        <button className="px-4 py-2 rounded-md border border-border text-sm hover:bg-primary-soft">بحث</button>
      </form>

      <div className="card-3d rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-primary-soft text-primary-dark">
            <tr>
              <th className="text-right px-4 py-2 font-medium">رقم الملف</th>
              <th className="text-right px-4 py-2 font-medium">الاسم</th>
              <th className="text-right px-4 py-2 font-medium">السن</th>
              <th className="text-right px-4 py-2 font-medium">التليفون</th>
              <th className="px-4 py-2"></th>
            </tr>
          </thead>
          <tbody>
            {patients.map((p) => (
              <tr key={p.id} className="border-t border-border hover:bg-background">
                <td className="px-4 py-2 text-muted">{p.file_number}</td>
                <td className="px-4 py-2 font-medium">
                  <Link href={patientHref(p.id)} className="hover:text-primary hover:underline">
                    {p.full_name}
                  </Link>
                  {missingPatientDetails(p).length > 0 && (
                    <span className="mr-2 inline-flex rounded-full bg-amber-100 px-2 py-0.5 text-[11px] font-medium text-amber-800">
                      بيانات ناقصة
                    </span>
                  )}
                </td>
                <td className="px-4 py-2">{displayAge(p) ?? "-"}</td>
                <td className="px-4 py-2" dir="ltr">{formatPatientPhone(p.phone_country_code, p.phone) ?? "-"}</td>
                <td className="px-4 py-2 text-left">
                  <div className="flex items-center justify-end gap-3">
                    {/* لينك "فتح الملف" المنفصل اتشال (دفعة 21) — بقى مكرر مع الدوسة على
                        الاسم بعد ما بقى النظام كله تاب واحد. */}
                    {/* حذف حالة نهائيًا - للأدمن بس، أساسًا لتنظيف حالات تجربة (test) بعد
                        الانتهاء منها. */}
                    {isAdmin && <DeletePatientButton patientId={p.id} patientName={p.full_name} />}
                  </div>
                </td>
              </tr>
            ))}
            {patients.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-muted">
                  لا يوجد مرضى مطابقين.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
