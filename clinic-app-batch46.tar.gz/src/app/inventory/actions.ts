"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { setSetting } from "@/lib/settings";
import { evaluateInventoryReorderNeeds } from "@/lib/inventory-reorder";
import { deductInventoryItem, returnInventoryItem } from "@/lib/inventory-stock";
import { ELASTOMERIC_COLORS, elastomericItemName } from "@/lib/ortho/elastomeric-colors";
import { BRACKET_TEETH, isBracketBrand } from "@/lib/ortho/bracket-stock";
import { getClinicToday } from "@/lib/clinic-date";

async function requireManageInventory(): Promise<boolean> {
  const session = await getSession();
  if (!session) return false;
  return hasPermission(session.userId, session.role, "manage_inventory");
}

async function requireEditInventoryCatalog(): Promise<boolean> {
  const session = await getSession();
  if (!session) return false;
  return hasPermission(session.userId, session.role, "edit_inventory_catalog");
}

async function requireInventoryAdmin(): Promise<boolean> {
  const session = await getSession();
  return Boolean(session && session.role === "admin");
}

function text(formData: FormData, key: string): string {
  return String(formData.get(key) || "").trim();
}

function positiveId(formData: FormData, key: string): number | null {
  const value = Number(formData.get(key));
  return Number.isInteger(value) && value > 0 ? value : null;
}

function nonNegative(formData: FormData, key: string, fallback = 0): number {
  const value = Number(formData.get(key));
  return Number.isFinite(value) && value >= 0 ? value : fallback;
}

function refreshInventoryPages() {
  revalidatePath("/inventory");
  revalidatePath("/settings");
}

// البراكتس لها جرد منفصل لكل سن؛ لا نخلطها برصيد inventory_items المجمع.
export async function receiveOrthodonticBracketCaseAction(formData: FormData) {
  if (!(await requireManageInventory())) return;
  const session = await getSession();
  const brand = text(formData, "brand");
  const cases = Math.floor(nonNegative(formData, "cases"));
  if (!session || !isBracketBrand(brand) || cases <= 0) return;
  await db.transaction().execute(async (trx) => {
    for (const fdi of BRACKET_TEETH) {
      await trx.updateTable("orthodontic_bracket_stock")
        .set((eb) => ({ quantity: eb("quantity", "+", cases), updated_at: new Date().toISOString() }))
        .where("brand", "=", brand).where("fdi", "=", fdi).execute();
      await trx.insertInto("orthodontic_bracket_stock_movements").values({ brand, fdi, quantity: cases, movement_type: "case_purchase", created_by: session.userId, note: `${cases} Case` }).execute();
    }
  });
  refreshInventoryPages();
}

export async function receiveOrthodonticBracketRefillAction(formData: FormData) {
  if (!(await requireManageInventory())) return;
  const session = await getSession();
  const brand = text(formData, "brand");
  const fdi = positiveId(formData, "fdi");
  const quantity = Math.floor(nonNegative(formData, "quantity"));
  if (!session || !isBracketBrand(brand) || !fdi || !BRACKET_TEETH.includes(fdi as typeof BRACKET_TEETH[number]) || quantity <= 0) return;
  await db.transaction().execute(async (trx) => {
    await trx.updateTable("orthodontic_bracket_stock").set((eb) => ({ quantity: eb("quantity", "+", quantity), updated_at: new Date().toISOString() })).where("brand", "=", brand).where("fdi", "=", fdi).execute();
    await trx.insertInto("orthodontic_bracket_stock_movements").values({ brand, fdi, quantity, movement_type: "refill_purchase", created_by: session.userId, note: "Refill" }).execute();
  });
  refreshInventoryPages();
}

export async function setOrthodonticBracketCountAction(formData: FormData) {
  if (!(await requireEditInventoryCatalog())) return;
  const session = await getSession();
  const brand = text(formData, "brand");
  const fdi = positiveId(formData, "fdi");
  const quantity = Math.floor(nonNegative(formData, "quantity"));
  if (!session || !isBracketBrand(brand) || !fdi || !BRACKET_TEETH.includes(fdi as typeof BRACKET_TEETH[number])) return;
  await db.transaction().execute(async (trx) => {
    const row = await trx.selectFrom("orthodontic_bracket_stock").select("quantity").where("brand", "=", brand).where("fdi", "=", fdi).executeTakeFirst();
    if (!row) return;
    await trx.updateTable("orthodontic_bracket_stock").set({ quantity, updated_at: new Date().toISOString() }).where("brand", "=", brand).where("fdi", "=", fdi).execute();
    await trx.insertInto("orthodontic_bracket_stock_movements").values({ brand, fdi, quantity: quantity - row.quantity, movement_type: "manual_count", created_by: session.userId, note: "جرد يدوي" }).execute();
  });
  refreshInventoryPages();
}

export async function addInventorySpecialtyAction(formData: FormData) {
  if (!(await requireInventoryAdmin())) return;
  const name = text(formData, "name");
  if (!name) return;
  const parentId = positiveId(formData, "parent_id");
  await db
    .insertInto("inventory_specialties")
    .values({ name, parent_id: parentId })
    .onConflict((oc) => oc.column("name").doNothing())
    .execute();
  refreshInventoryPages();
}

export async function addInventoryCategoryAction(formData: FormData) {
  if (!(await requireInventoryAdmin())) return;
  const specialtyId = positiveId(formData, "specialty_id");
  const name = text(formData, "name");
  if (!specialtyId || !name) return;
  await db
    .insertInto("inventory_categories")
    .values({ specialty_id: specialtyId, name })
    .onConflict((oc) => oc.columns(["specialty_id", "name"]).doUpdateSet({ active: 1 }))
    .execute();
  refreshInventoryPages();
}

// الحذف من واجهة الفئات يكون منطقياً آمناً: تختفي الفئة وكل خاماتها من
// النظام واختيارات الطبيب، بينما نحافظ على دفتر الحركات القديم للتقارير.
// لو أُعيد إنشاء الاسم نفسه من زر + تُفعَّل الفئة من جديد بدل إنشاء تكرار.
export async function archiveInventoryCategoryAction(categoryId: number) {
  if (!(await requireInventoryAdmin()) || !Number.isInteger(categoryId) || categoryId <= 0) return;
  await db.transaction().execute(async (trx) => {
    await trx.updateTable("inventory_items").set({ active: 0, available_in_clinical_selection: 0 }).where("category_id", "=", categoryId).execute();
    await trx.updateTable("inventory_categories").set({ active: 0 }).where("id", "=", categoryId).execute();
  });
  refreshInventoryPages();
}

// إنشاء كتالوج التقويم الأولي من القائمة المعتمدة بالعيادة. هذه العملية آمنة
// للتكرار: لا تمسح توريداً أو رصيداً موجوداً ولا تضيف الاسم نفسه مرتين.
export async function seedClinicalOrthodonticInventoryAction() {
  if (!(await requireInventoryAdmin())) return;

  const categories = ["TADS", "BRACKETS", "BANDS", "WIRES", "AUXILIARIES", "ELASTICS", "ADHESIVES"];
  await db.transaction().execute(async (trx) => {
    await trx.insertInto("inventory_specialties").values({ name: "تقويم" }).onConflict((oc) => oc.column("name").doNothing()).execute();
    const specialty = await trx.selectFrom("inventory_specialties").select("id").where("name", "=", "تقويم").executeTakeFirstOrThrow();

    for (const name of categories) {
      await trx.insertInto("inventory_categories").values({ specialty_id: specialty.id, name }).onConflict((oc) => oc.columns(["specialty_id", "name"]).doNothing()).execute();
    }
    const categoryRows = await trx.selectFrom("inventory_categories").select(["id", "name"]).where("specialty_id", "=", specialty.id).execute();
    const categoryId = new Map(categoryRows.map((row) => [row.name, row.id]));

    const add = async (name: string, category: string, unit: string, orthoUsage: string | null, catalogGroup: string | null = null, autoDeductionKey: string | null = null, oldName?: string) => {
      const exists = await trx.selectFrom("inventory_items").select("id").where("name", "=", name).executeTakeFirst();
      if (exists) {
        await trx.updateTable("inventory_items").set({ specialty_id: specialty.id, category_id: categoryId.get(category) ?? null, catalog_group: catalogGroup, ortho_usage: orthoUsage, auto_deduction_key: autoDeductionKey }).where("id", "=", exists.id).execute();
        return;
      }
      const legacy = oldName ? await trx.selectFrom("inventory_items").select("id").where("name", "=", oldName).executeTakeFirst() : null;
      if (legacy) {
        await trx.updateTable("inventory_items").set({ name, unit, specialty_id: specialty.id, category_id: categoryId.get(category) ?? null, catalog_group: catalogGroup, ortho_usage: orthoUsage, auto_deduction_key: autoDeductionKey }).where("id", "=", legacy.id).execute();
        return;
      }
      await trx.insertInto("inventory_items").values({
        name,
        unit,
        quantity: 0,
        specialty_id: specialty.id,
        category_id: categoryId.get(category) ?? null,
        catalog_group: catalogGroup,
        ortho_usage: orthoUsage,
        auto_deduction_key: autoDeductionKey,
      }).execute();
    };

    await Promise.all([
      add("TAD 1.6 × 8", "TADS", "screw", "anchorage_device", "TAD"),
      add("TAD 1.6 × 10", "TADS", "screw", "anchorage_device", "TAD"),
      ...[
        "American Roth 0.018", "American Roth 0.022", "American MBT 0.018", "American MBT 0.022",
        "Ormco Roth 0.018", "Ormco Roth 0.022", "Ormco MBT 0.018", "Ormco MBT 0.022",
      ].map((name) => add(name, "BRACKETS", "bracket", "bracket", name.replace(/ 0\.\d+$/, ""))),
      ...[
        "American Roth 0.018", "American Roth 0.022", "American MBT 0.018", "American MBT 0.022",
        "Ormco Roth 0.018", "Ormco Roth 0.022", "Ormco MBT 0.018", "Ormco MBT 0.022",
      ].map((name) => add(`${name} — Tube`, "BRACKETS", "tube", "tube", `${name.replace(/ 0\.\d+$/, "")} Tubes`)),
      ...["0.012", "0.014", "0.016", "0.016 × 0.022", "0.017 × 0.025", "0.019 × 0.025"].map((size) => add(`NiTi ${size}`, "WIRES", "wire", "wire", "NiTi")),
      ...["0.012", "0.016", "0.018", "0.016 × 0.022", "0.017 × 0.025", "0.019 × 0.025"].map((size) => add(`St.St ${size}`, "WIRES", "wire", "wire", "St.St")),
      add("Elastic 1/8", "ELASTICS", "packet", "elastic", "Elastics"),
      add("Elastic 3/16", "ELASTICS", "packet", "elastic", "Elastics"),
      add("Elastic 5/16", "ELASTICS", "packet", "elastic", "Elastics"),
      ...ELASTOMERIC_COLORS.flatMap(([code, name, hex]) => {
        const color = { code, name, hex };
        return [
          add(elastomericItemName("O-tie", color), "ELASTICS", "piece", "otie", "O-tie", null, `O-tie — ${name}`),
          add(elastomericItemName("Power chain", color), "ELASTICS", "piece", "power_chain", "Power chain", null, `Power chain — ${name}`),
        ];
      }),
      add("Compressed coil", "AUXILIARIES", "mm", "compressed_coil", "Coils"),
      add("Button", "AUXILIARIES", "piece", "button", "Buttons"),
      add("Stripping paper", "AUXILIARIES", "mm", null, "Stripping"),
      add("Ligature wire", "AUXILIARIES", "piece", null, "Ligature wire"),
      add("Orthodontic composite", "ADHESIVES", "mg", null, "Composite", "orthodontic_composite"),
    ]);
  });

  await evaluateInventoryReorderNeeds();
  refreshInventoryPages();
}

export async function addInventoryProductAction(formData: FormData) {
  if (!(await requireInventoryAdmin())) return;
  const categoryId = positiveId(formData, "category_id");
  const name = text(formData, "name");
  if (!categoryId || !name) return;
  await db
    .insertInto("inventory_products")
    .values({ category_id: categoryId, name })
    .onConflict((oc) => oc.columns(["category_id", "name"]).doNothing())
    .execute();
  refreshInventoryPages();
}

export async function addInventoryAttributeGroupAction(formData: FormData) {
  if (!(await requireInventoryAdmin())) return;
  const productId = positiveId(formData, "product_id");
  const name = text(formData, "name");
  if (!productId || !name) return;
  await db.insertInto("inventory_attribute_groups").values({ product_id: productId, name }).execute();
  refreshInventoryPages();
}

export async function addInventoryAttributeValueAction(formData: FormData) {
  if (!(await requireInventoryAdmin())) return;
  const attributeGroupId = positiveId(formData, "attribute_group_id");
  const value = text(formData, "value");
  if (!attributeGroupId || !value) return;
  await db
    .insertInto("inventory_attribute_values")
    .values({ attribute_group_id: attributeGroupId, value })
    .onConflict((oc) => oc.columns(["attribute_group_id", "value"]).doNothing())
    .execute();
  refreshInventoryPages();
}

export async function addInventoryUnitAction(formData: FormData) {
  if (!(await requireInventoryAdmin())) return;
  const name = text(formData, "name");
  const shortName = text(formData, "short_name");
  if (!name) return;
  await db
    .insertInto("inventory_units")
    .values({ name, short_name: shortName || name })
    .onConflict((oc) => oc.column("name").doNothing())
    .execute();
  refreshInventoryPages();
}

export async function addInventorySupplierAction(formData: FormData) {
  if (!(await requireInventoryAdmin())) return;
  const name = text(formData, "name");
  if (!name) return;
  await db
    .insertInto("inventory_suppliers")
    .values({
      name,
      phone_country_code: text(formData, "phone_country_code") || "+20",
      phone: text(formData, "phone") || null,
      notes: text(formData, "notes") || null,
    })
    .onConflict((oc) => oc.column("name").doNothing())
    .execute();
  refreshInventoryPages();
}

export async function saveInventoryNotificationRecipientsAction(formData: FormData) {
  if (!(await requireInventoryAdmin())) return;
  const ids = formData
    .getAll("recipient_user_ids")
    .map((value) => Number(value))
    .filter((value) => Number.isInteger(value) && value > 0);
  await setSetting("inventory_low_stock_recipient_ids", Array.from(new Set(ids)).join(","));
  refreshInventoryPages();
}

// ينشئ الهيكل فقط، لا ينشئ أي رصيد أو مورد أو صنف فعلي. لذلك يمكن تشغيله
// بأمان مرة أو أكثر؛ القيم الموجودة لا تتكرر ولا تُستبدل.
export async function seedOrthodonticInventoryCatalogAction() {
  if (!(await requireInventoryAdmin())) return;
  const specialtyName = "تقويم";
  await db.insertInto("inventory_specialties").values({ name: specialtyName }).onConflict((oc) => oc.column("name").doNothing()).execute();
  const specialty = await db.selectFrom("inventory_specialties").select("id").where("name", "=", specialtyName).executeTakeFirst();
  if (!specialty) return;

  const blueprint: Array<{ category: string; product: string; attributes: string[] }> = [
    { category: "Wires", product: "Orthodontic wire", attributes: ["Size", "Type", "Arch", "Company"] },
    { category: "Brackets", product: "Bracket", attributes: ["Company", "Prescription", "Slot", "Arch"] },
    { category: "Tubes", product: "Tube", attributes: ["Company", "Prescription", "Side"] },
    { category: "O-ties", product: "O-tie", attributes: ["Color", "Company"] },
    { category: "Elastics", product: "Elastic", attributes: ["Size", "Force", "Company"] },
    { category: "Power chain", product: "Power chain", attributes: ["Color", "Type", "Company"] },
    { category: "Buttons", product: "Button", attributes: ["Type", "Company"] },
    { category: "Compressed coil", product: "Compressed coil", attributes: ["Size", "Length", "Company"] },
    { category: "Anchorage", product: "Anchorage device", attributes: ["Type", "Company"] },
  ];
  for (const entry of blueprint) {
    await db.insertInto("inventory_categories").values({ specialty_id: specialty.id, name: entry.category }).onConflict((oc) => oc.columns(["specialty_id", "name"]).doNothing()).execute();
    const category = await db.selectFrom("inventory_categories").select("id").where("specialty_id", "=", specialty.id).where("name", "=", entry.category).executeTakeFirst();
    if (!category) continue;
    await db.insertInto("inventory_products").values({ category_id: category.id, name: entry.product }).onConflict((oc) => oc.columns(["category_id", "name"]).doNothing()).execute();
    const product = await db.selectFrom("inventory_products").select("id").where("category_id", "=", category.id).where("name", "=", entry.product).executeTakeFirst();
    if (!product) continue;
    for (const name of entry.attributes) {
      await db.insertInto("inventory_attribute_groups").values({ product_id: product.id, name }).onConflict((oc) => oc.columns(["product_id", "name"]).doNothing()).execute();
    }
  }
  refreshInventoryPages();
}

export async function addInventoryVariantAction(formData: FormData) {
  if (!(await requireManageInventory())) return;
  const productId = positiveId(formData, "product_id");
  const supplierId = positiveId(formData, "supplier_id");
  const orthoUsage = text(formData, "ortho_usage");
  const validOrthoUsages = new Set(["wire", "bracket", "tube", "elastic", "otie", "power_chain", "button", "compressed_coil", "anchorage_device"]);
  if (orthoUsage && !validOrthoUsages.has(orthoUsage)) return;
  let name = text(formData, "name");
  const selectedAttributes = Array.from(formData.entries())
    .filter(([key, value]) => key.startsWith("attribute_group_") && String(value))
    .map(([, value]) => Number(value))
    .filter((value) => Number.isInteger(value) && value > 0);

  if (productId) {
    const product = await db
      .selectFrom("inventory_products")
      .innerJoin("inventory_categories", "inventory_categories.id", "inventory_products.category_id")
      .innerJoin("inventory_specialties", "inventory_specialties.id", "inventory_categories.specialty_id")
      .select(["inventory_products.name", "inventory_specialties.name as specialty_name"])
      .where("inventory_products.id", "=", productId)
      .where("inventory_products.active", "=", 1)
      .executeTakeFirst();
    if (!product) return;
    if (orthoUsage && product.specialty_name !== "تقويم") return;
    const values = selectedAttributes.length
      ? await db
          .selectFrom("inventory_attribute_values")
          .innerJoin("inventory_attribute_groups", "inventory_attribute_groups.id", "inventory_attribute_values.attribute_group_id")
          .select(["inventory_attribute_values.id", "inventory_attribute_values.value"])
          .where("inventory_attribute_groups.product_id", "=", productId)
          .where("inventory_attribute_values.id", "in", selectedAttributes)
          .execute()
      : [];
    const validValueIds = values.map((value) => value.id);
    if (!name) name = [product.name, ...values.map((value) => value.value)].join(" — ");
    await createVariant(formData, { productId, supplierId, name, attributeValueIds: validValueIds, orthoUsage });
  } else {
    if (!name || orthoUsage) return;
    await createVariant(formData, { productId: null, supplierId, name, attributeValueIds: [], orthoUsage: "" });
  }
  await evaluateInventoryReorderNeeds();
  refreshInventoryPages();
}

async function createVariant(
  formData: FormData,
  input: { productId: number | null; supplierId: number | null; name: string; attributeValueIds: number[]; orthoUsage: string }
) {
  const lowStock = nonNegative(formData, "low_stock_threshold");
  const criticalStock = Math.min(nonNegative(formData, "critical_stock_threshold"), lowStock);
  await db
    .insertInto("inventory_items")
    .values({
      name: input.name,
      product_id: input.productId,
      supplier_id: input.supplierId,
      attribute_value_ids: input.attributeValueIds.length ? input.attributeValueIds.join(",") : null,
      item_code: text(formData, "item_code") || null,
      ortho_usage: input.orthoUsage || null,
      quantity: nonNegative(formData, "quantity"),
      unit: text(formData, "unit") || null,
      expiry_date: text(formData, "expiry_date") || null,
      low_stock_threshold: lowStock,
      critical_stock_threshold: criticalStock,
      reorder_quantity: nonNegative(formData, "reorder_quantity"),
    })
    .execute();
}

// نحافظ على الاسم القديم حتى لا يتعطل أي استدعاء قديم من الواجهة.
export async function addItemAction(formData: FormData) {
  await addInventoryVariantAction(formData);
}

export async function updateQuantityAction(formData: FormData) {
  if (!(await requireManageInventory())) return;
  const id = positiveId(formData, "id");
  const quantity = nonNegative(formData, "quantity", -1);
  if (!id || quantity < 0) return;
  await db.updateTable("inventory_items").set({ quantity }).where("id", "=", id).execute();
  await evaluateInventoryReorderNeeds();
  revalidatePath("/inventory");
}

// النسخة البسيطة من المخزن: السطر هنا هو "الخامة العلاجية" التي يراها
// الطبيب ويجردها المستخدم. المورد/الشركة لا ينشئان سطراً آخر؛ يُضافان
// لاحقاً كتوريد تحت السطر نفسه.
export async function addSimpleInventoryItemAction(formData: FormData) {
  const session = await getSession();
  if (!session || !(await requireManageInventory())) return;
  const name = text(formData, "name");
  const unit = text(formData, "unit");
  const specialtyId = positiveId(formData, "specialty_id");
  const categoryId = positiveId(formData, "category_id");
  const catalogGroup = text(formData, "catalog_group");
  const orthoUsage = text(formData, "ortho_usage");
  const generalConsumable = text(formData, "is_general_consumable") === "1";
  const availableInClinicalSelection = text(formData, "available_in_clinical_selection") === "1";
  const validOrthoUsages = new Set(["wire", "bracket", "tube", "elastic", "otie", "power_chain", "button", "compressed_coil", "anchorage_device"]);
  if (!name || !unit || (generalConsumable && orthoUsage) || (orthoUsage && !validOrthoUsages.has(orthoUsage))) return;

  const category = categoryId ? await db.selectFrom("inventory_categories").select(["id", "specialty_id"]).where("id", "=", categoryId).executeTakeFirst() : null;
  if (categoryId && !category) return;
  const resolvedSpecialtyId = category?.specialty_id ?? specialtyId;
  const exists = await db.selectFrom("inventory_items").select("id").where("name", "=", name).executeTakeFirst();
  if (exists) return;

  const lowStock = nonNegative(formData, "low_stock_threshold");
  await db
    .insertInto("inventory_items")
    .values({
      name,
      unit,
      specialty_id: resolvedSpecialtyId,
      category_id: category?.id ?? null,
      catalog_group: catalogGroup || null,
      available_in_clinical_selection: availableInClinicalSelection ? 1 : 0,
      is_general_consumable: generalConsumable ? 1 : 0,
      ortho_usage: orthoUsage || null,
      low_stock_threshold: lowStock,
      critical_stock_threshold: Math.min(nonNegative(formData, "critical_stock_threshold"), lowStock),
      reorder_quantity: nonNegative(formData, "reorder_quantity"),
      supplier_id: positiveId(formData, "preferred_supplier_id"),
      quantity: 0,
    })
    .execute();
  await evaluateInventoryReorderNeeds();
  refreshInventoryPages();
}

// إخفاء الصنف من قوائم الاستخدام الطبي عند نفاده/توقفه، من غير حذف رصيده أو
// توريداته أو سجله. ينطبق على كل الأنواع: ألوان، Brackets، TADs وغيرها.
export async function setInventoryItemAvailabilityAction(formData: FormData) {
  if (!(await requireEditInventoryCatalog())) return;
  const itemId = positiveId(formData, "item_id");
  if (!itemId) return;
  await db
    .updateTable("inventory_items")
    .set({ available_in_clinical_selection: text(formData, "available_in_clinical_selection") === "1" ? 1 : 0 })
    .where("id", "=", itemId)
    .execute();
  refreshInventoryPages();
  revalidatePath("/patients");
}

// إعداد سريع من صف الجرد نفسه: وحدة الاستعمال والحد الذي يبدأ عنده التنبيه.
// بما أن الواجهة الحالية تطلب حداً واحداً فقط، نحفظه كحد تنبيه وحرج معاً.
export async function saveInventoryItemUsageSettingsAction(formData: FormData) {
  if (!(await requireEditInventoryCatalog())) return;
  const itemId = positiveId(formData, "item_id");
  const unit = text(formData, "unit");
  const critical = nonNegative(formData, "critical_stock_threshold", -1);
  if (!itemId || !unit || critical < 0) return;
  await db
    .updateTable("inventory_items")
    .set({ unit, low_stock_threshold: critical, critical_stock_threshold: critical })
    .where("id", "=", itemId)
    .execute();
  await evaluateInventoryReorderNeeds();
  refreshInventoryPages();
}

// تعديل إداري كامل للصنف. الصلاحية هي manage_inventory، فيستطيع الأدمن منحها
// لطبيب موثوق عند الحاجة من غير أن يفتح صلاحيات المخزن لبقية الحسابات.
export async function updateInventoryItemAdminAction(formData: FormData) {
  if (!(await requireEditInventoryCatalog())) return;
  const itemId = positiveId(formData, "item_id");
  const name = text(formData, "name");
  const unit = text(formData, "unit");
  const categoryId = positiveId(formData, "category_id");
  const critical = nonNegative(formData, "critical_stock_threshold", -1);
  if (!itemId || !name || !unit || !categoryId || critical < 0) return;
  const [category, item] = await Promise.all([
    db.selectFrom("inventory_categories").select(["id", "specialty_id"]).where("id", "=", categoryId).where("active", "=", 1).executeTakeFirst(),
    db.selectFrom("inventory_items").select("auto_deduction_key").where("id", "=", itemId).executeTakeFirst(),
  ]);
  if (!category || !item) return;
  const perAttachment = nonNegative(formData, "auto_deduction_per_attachment", -1);
  if (item.auto_deduction_key === "orthodontic_composite" && perAttachment <= 0) return;
  await db.updateTable("inventory_items").set({
    name,
    unit,
    specialty_id: category.specialty_id,
    category_id: category.id,
    catalog_group: text(formData, "catalog_group") || null,
    low_stock_threshold: critical,
    critical_stock_threshold: critical,
    available_in_clinical_selection: text(formData, "available_in_clinical_selection") === "1" ? 1 : 0,
    ...(item.auto_deduction_key === "orthodontic_composite" ? { auto_deduction_per_attachment: perAttachment } : {}),
  }).where("id", "=", itemId).execute();
  await evaluateInventoryReorderNeeds();
  refreshInventoryPages();
}

// أرشفة بدل حذف تاريخي نهائي: السطر يختفي من المخزن ومن اختيارات الطبيب،
// بينما تظل حركاته القديمة قابلة للمراجعة في التقارير.
export async function archiveInventoryItemAction(formData: FormData) {
  if (!(await requireEditInventoryCatalog())) return;
  const itemId = positiveId(formData, "item_id");
  if (!itemId) return;
  await db.updateTable("inventory_items").set({ active: 0, available_in_clinical_selection: 0 }).where("id", "=", itemId).execute();
  refreshInventoryPages();
}

// استلام توريد: الاستقبال يكتب العبوات ومحتوى العبوة (2 علبة × 500 منديل)،
// والنظام يحولها تلقائياً لوحدة الاستهلاك الداخلية (1000 منديل). لذلك يظل
// الخصم دقيقاً حتى لو كانت علبة المورد التالي محتواها مختلفاً.
export async function receiveInventorySupplyAction(formData: FormData) {
  const session = await getSession();
  if (!session || !(await requireManageInventory())) return;
  const itemId = positiveId(formData, "item_id");
  const supplierId = positiveId(formData, "supplier_id");
  const packageCount = nonNegative(formData, "package_count", -1);
  const unitsPerPackage = nonNegative(formData, "units_per_package", -1);
  const legacyQuantity = nonNegative(formData, "quantity_received", -1);
  const hasPackaging = packageCount > 0 && unitsPerPackage > 0;
  const quantity = hasPackaging ? packageCount * unitsPerPackage : legacyQuantity;
  const purchaseUnit = text(formData, "purchase_unit_label") || null;
  const totalCostRaw = String(formData.get("total_cost") ?? "").trim();
  const totalCost = totalCostRaw === "" ? null : nonNegative(formData, "total_cost", -1);
  if (!itemId || quantity <= 0 || (totalCost !== null && totalCost < 0)) return;

  await db.transaction().execute(async (trx) => {
    const item = await trx
      .selectFrom("inventory_items")
      .leftJoin("inventory_specialties", "inventory_specialties.id", "inventory_items.specialty_id")
      .leftJoin("inventory_suppliers", "inventory_suppliers.id", "inventory_items.supplier_id")
      .select([
        "inventory_items.id",
        "inventory_items.name",
        "inventory_items.supplier_id",
        "inventory_specialties.name as specialty_name",
        "inventory_suppliers.name as preferred_supplier_name",
      ])
      .where("inventory_items.id", "=", itemId)
      .executeTakeFirst();
    if (!item) return;
    const selectedSupplier = supplierId
      ? await trx.selectFrom("inventory_suppliers").select("name").where("id", "=", supplierId).executeTakeFirst()
      : null;
    const inserted = await trx
      .insertInto("inventory_supply_batches")
      .values({
        item_id: itemId,
        supplier_id: supplierId,
        brand: text(formData, "brand") || null,
        quantity_received: quantity,
        quantity_remaining: quantity,
        purchase_unit_label: hasPackaging ? purchaseUnit : null,
        package_count: hasPackaging ? packageCount : null,
        units_per_package: hasPackaging ? unitsPerPackage : null,
        total_cost: totalCost,
        received_at: text(formData, "received_at") || getClinicToday(),
        note: text(formData, "note") || null,
        created_by: session.userId,
      })
      .executeTakeFirstOrThrow();
    const batchId = Number(inserted.insertId);
    await trx
      .updateTable("inventory_items")
      .set({ quantity: (eb) => eb("quantity", "+", quantity), supplier_id: item.supplier_id ?? supplierId })
      .where("id", "=", itemId)
      .execute();
    await trx
      .insertInto("inventory_stock_movements")
      .values({ item_id: itemId, batch_id: batchId, appointment_id: null, movement_type: "supply", quantity, note: hasPackaging ? `توريد ${packageCount} ${purchaseUnit ?? "عبوة"} × ${unitsPerPackage}` : "توريد مخزون", created_by: session.userId })
      .execute();
    // تكلفة توريد المخزن مصروف فعلي، فتُسجل تلقائياً في السجل المركزي. ربطها
    // برقم batch يجعل كل توريد يظهر مرة واحدة فقط مهما توسع نظام المشتريات لاحقاً.
    if (totalCost != null && totalCost > 0) {
      const receivedAt = text(formData, "received_at") || getClinicToday();
      await trx
        .insertInto("expenses")
        .values({
          expense_date: receivedAt,
          category: item.specialty_name === "تقويم" ? "inventory_orthodontic" : "inventory_general",
          title: `توريد مخزن — ${item.name}`,
          payee: selectedSupplier?.name ?? item.preferred_supplier_name ?? null,
          amount: totalCost,
          payment_method: null,
          note: hasPackaging ? `${packageCount} ${purchaseUnit ?? "عبوة"} × ${unitsPerPackage}` : "توريد مخزون",
          source_type: "inventory_supply",
          source_id: batchId,
          template_id: null,
          created_by: session.userId,
        })
        .execute();
    }
  });
  await evaluateInventoryReorderNeeds();
  refreshInventoryPages();
  revalidatePath("/expenses");
  revalidatePath("/reports");
}

// الجرد يعدل الرصيد الإجمالي للخامة. الزيادة تسجل كتسوية، والنقص يوزع على
// أقدم التوريدات مثل أي خصم آخر، فيظل تحليل الموردين متماسكاً قدر الإمكان.
export async function recordInventoryCountAction(formData: FormData) {
  const session = await getSession();
  if (!session || !(await requireManageInventory())) return;
  const itemId = positiveId(formData, "item_id");
  const counted = nonNegative(formData, "counted_quantity", -1);
  if (!itemId || counted < 0) return;
  await db.transaction().execute(async (trx) => {
    const item = await trx.selectFrom("inventory_items").select(["id", "quantity"]).where("id", "=", itemId).executeTakeFirst();
    if (!item) return;
    const delta = Math.round((counted - item.quantity) * 1000) / 1000;
    if (delta > 0) await returnInventoryItem(trx, { itemId, quantity: delta, note: "تسوية جرد: زيادة فعلية", createdBy: session.userId });
    if (delta < 0) await deductInventoryItem(trx, { itemId, quantity: Math.abs(delta), movementType: "count_adjustment", note: "تسوية جرد: نقص فعلي", createdBy: session.userId });
  });
  await evaluateInventoryReorderNeeds();
  refreshInventoryPages();
}

export async function saveGeneralConsumableRuleAction(formData: FormData) {
  const session = await getSession();
  if (!session || !(await requireManageInventory())) return;
  const itemId = positiveId(formData, "item_id");
  const quantity = nonNegative(formData, "quantity_per_completed_appointment");
  if (!itemId) return;
  const item = await db.selectFrom("inventory_items").select("is_general_consumable").where("id", "=", itemId).executeTakeFirst();
  if (!item || item.is_general_consumable !== 1) return;
  await db
    .insertInto("inventory_consumable_rules")
    .values({ item_id: itemId, quantity_per_completed_appointment: quantity, active: quantity > 0 ? 1 : 0, updated_at: new Date().toISOString().replace("T", " ").slice(0, 19) })
    .onConflict((oc) => oc.column("item_id").doUpdateSet({ quantity_per_completed_appointment: quantity, active: quantity > 0 ? 1 : 0, updated_at: new Date().toISOString().replace("T", " ").slice(0, 19) }))
    .execute();
  refreshInventoryPages();
}

export async function markInventoryDraftSentAction(formData: FormData) {
  if (!(await requireManageInventory())) return;
  const id = positiveId(formData, "draft_id");
  if (!id) return;
  await db.updateTable("inventory_purchase_drafts").set({ status: "sent", updated_at: new Date().toISOString().replace("T", " ").slice(0, 19) }).where("id", "=", id).execute();
  revalidatePath("/inventory");
}
