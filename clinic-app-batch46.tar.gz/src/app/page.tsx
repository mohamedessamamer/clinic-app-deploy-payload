import Link from "next/link";
import { redirect } from "next/navigation";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { ROLE_LABELS } from "@/lib/auth";
import { getAllSettings, buildTimeSlots, weekdayOf } from "@/lib/settings";
import { hasPermission } from "@/lib/permissions";
import { getDoctorRoomIdsForDate } from "@/lib/schedule";
import { computeNeedsNewPhotosMap } from "@/lib/photo-reminder";
import { computeNeedsTreatmentMap } from "@/lib/needs-treatment";
import { getClinicToday } from "@/lib/clinic-date";
import CentralSchedule from "@/components/CentralSchedule";
import AdHocAppointmentCard from "@/components/AdHocAppointmentCard";

function clinicDateOffset(isoDate: string, days: number): string {
  const [year, month, day] = isoDate.split("-").map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

async function DoctorHome({ userId, doctorId, scheduleDate }: { userId: number; doctorId: number; scheduleDate: string }) {
  const today = getClinicToday();
  const viewingToday = scheduleDate === today;
  const earliestScheduleDate = clinicDateOffset(today, -14);
  const weekday = weekdayOf(scheduleDate);

  const [canEditSchedule, canSeeAllRooms, canCollectPayments, canViewReports, canEditAssistantDoctor, canSeeNeedsTreatment, canQuickAddService, canBackdateInvoice] = await Promise.all([
    hasPermission(userId, "doctor", "schedule_edit"),
    hasPermission(userId, "doctor", "schedule_all_rooms"),
    hasPermission(userId, "doctor", "collect_payments"),
    hasPermission(userId, "doctor", "reports_own"),
    // دفعة 22: حقل "الطبيب المساعد" الاختياري جوه بوكس التحصيل — نفس صلاحية
    // سجل الزيارات بالملف الطبي.
    hasPermission(userId, "doctor", "edit_visit_assistant_doctor").then(
      async (v) => v || (await hasPermission(userId, "doctor", "override_visit_doctor"))
    ),
    // دفعة 27 (P2.4): تنبيه "محتاج إدخال معالجة" — للدكتور افتراضيًا.
    hasPermission(userId, "doctor", "view_needs_treatment_reminder"),
    // دفعة 27 (P3.1): بوكس "إضافة خدمة للتحصيل" السريع — الدكتور افتراضيًا
    // معهوش صلاحية view_patient_billing (الفصل الكامل بين الملفين)، فمش هيبان
    // ليه إلا لو اتمنحله لوحده صراحة من الإعدادات.
    hasPermission(userId, "doctor", "view_patient_billing"),
    hasPermission(userId, "doctor", "edit_invoice_payments"),
  ]);

  const allRooms = await db.selectFrom("rooms").selectAll().execute();
  const myRoomIds = canSeeAllRooms ? null : await getDoctorRoomIdsForDate(doctorId, scheduleDate);
  const visibleRooms = myRoomIds ? allRooms.filter((r) => myRoomIds.includes(r.id)) : allRooms;

  const [appointmentsRaw, patients, doctors, services, billedApptRows, settings, roomShiftsToday, exceptionalShiftsToday] = await Promise.all([
    db
      .selectFrom("appointments")
      .innerJoin("patients", "patients.id", "appointments.patient_id")
      .leftJoin("doctors", "doctors.id", "appointments.doctor_id")
      .leftJoin("services", "services.id", "appointments.pending_service_id")
      .leftJoin("services as purpose_services", "purpose_services.id", "appointments.purpose_service_id")
      .select([
        "appointments.id",
        "appointments.patient_id",
        "patients.full_name as patient_name",
        "appointments.doctor_id",
        "doctors.full_name as doctor_name",
        "appointments.room_id",
        "appointments.start_time",
        "appointments.duration_minutes",
        "appointments.status",
        "appointments.notes",
        "appointments.pending_service_id",
        "appointments.pending_price",
        "appointments.pending_discount_percent",
        "services.name as pending_service_name",
        "appointments.purpose_type",
        "appointments.purpose_service_id",
        "purpose_services.name as purpose_service_name",
        "purpose_services.name_en as purpose_service_name_en",
        "purpose_services.category as purpose_service_category",
        "appointments.purpose_linked_invoice_id",
      ])
      .where("appointment_date", "=", scheduleDate)
      .where("status", "!=", "cancelled")
      .orderBy("appointments.start_time")
      .execute(),
    // جدول الطبيب لا يحتاج إلا الاسم ورقم الملف للحجز/فتح الملف؛ لا نرسل بيانات
    // شخصية مثل الهاتف أو تاريخ الميلاد إلى واجهته أصلًا.
    db.selectFrom("patients").select(["id", "full_name", "file_number"]).orderBy("id", "desc").limit(500).execute(),
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).execute(),
    db.selectFrom("services").select(["id", "name", "default_price", "code"]).execute(),
    db
      .selectFrom("invoices")
      .select("appointment_id")
      .where("appointment_id", "is not", null)
      .execute(),
    getAllSettings(),
    // نفس فكرة roomShiftDoctorIds في front-desk/page.tsx — عشان بوكس الحجز هنا كمان
    // يحدد صاحب شيفت الغرفة افتراضيًا (الجدول المركزي مدموج هنا كصفحة رئيسية للدكتور).
    visibleRooms.length > 0
      ? db
          .selectFrom("doctor_weekly_shifts")
          .select(["room_id", "doctor_id", "start_time"])
          .where(
            "room_id",
            "in",
            visibleRooms.map((r) => r.id)
          )
          .where("weekday", "=", weekday)
          .orderBy("start_time")
          .execute()
      : Promise.resolve([]),
    // شفت استثنائي مسجّل لليوم/الغرف الظاهرة دي — دفعة 27. بياخد أولوية على
    // الشيفت الأسبوعي العادي في تحديد الدكتور المقترح افتراضيًا (تحت). زرار
    // الإضافة/الإلغاء نفسه موجود بس في صفحة الاستقبال؛ هنا بنستفيد من الأثر بس.
    visibleRooms.length > 0
      ? db
          .selectFrom("doctor_date_shifts")
          .innerJoin("doctors", "doctors.id", "doctor_date_shifts.doctor_id")
          .select(["doctor_date_shifts.room_id", "doctor_date_shifts.doctor_id", "doctors.full_name as doctor_name"])
          .where(
            "doctor_date_shifts.room_id",
            "in",
            visibleRooms.map((r) => r.id)
          )
      .where("doctor_date_shifts.shift_date", "=", scheduleDate)
          .execute()
      : Promise.resolve([]),
  ]);

  const slotMinutes = Number(settings.slot_minutes);
  const timeSlots = buildTimeSlots(settings.day_start, settings.day_end, slotMinutes);

  const roomShiftDoctorIds: Record<number, number> = {};
  for (const s of roomShiftsToday) {
    if (!(s.room_id in roomShiftDoctorIds)) roomShiftDoctorIds[s.room_id] = s.doctor_id;
  }
  for (const s of exceptionalShiftsToday) {
    roomShiftDoctorIds[s.room_id] = s.doctor_id;
  }

  const billedApptIds = new Set(billedApptRows.map((r) => r.appointment_id).filter((id): id is number => id != null));
  const needsPhotosMap = await computeNeedsNewPhotosMap(appointmentsRaw.map((a) => a.patient_id));
  // دفعة 27 (P2.4): تنبيه "محتاج إدخال معالجة" — بيوصل للواجهة بـfalse لمين
  // معهوش صلاحية view_needs_treatment_reminder، تحقق حقيقي هنا.
  const needsTreatmentMap = canSeeNeedsTreatment
    ? await computeNeedsTreatmentMap(
        appointmentsRaw.map((a) => ({ id: a.id, patient_id: a.patient_id, appointment_date: scheduleDate, status: a.status }))
      )
    : new Map<number, boolean>();

  // دفعة المراجعة 2026-08-27: أي مريض تقويم (عنده شارت تقويم فعلي بالفعل، حتى
  // لو الموعد النهاردة معلمش عليه "المريض جاي يعمل إيه") — دوسة على الموعد بتاعه
  // تفتح شارت التقويم على طول بدل الملف الطبي العادي، بدون ما يحتاج حد يحدد
  // الغرض من كل موعد يدويًا في كل مرة.
  const orthoPatientIds =
    appointmentsRaw.length > 0
      ? new Set(
          (
            await db
              .selectFrom("orthodontic_charts")
              .select("patient_id")
              .where(
                "patient_id",
                "in",
                Array.from(new Set(appointmentsRaw.map((a) => a.patient_id)))
              )
              .execute()
          ).map((r) => r.patient_id)
        )
      : new Set<number>();

  const appointments = appointmentsRaw.map((a) => ({
    id: a.id,
    patient_id: a.patient_id,
    patient_name: a.patient_name,
    doctor_id: a.doctor_id,
    doctor_name: a.doctor_name ?? "-",
    room_id: a.room_id,
    start_time: a.start_time,
    duration_minutes: a.duration_minutes,
    status: a.status as "booked" | "attended" | "done" | "cancelled" | "no_show",
    notes: a.notes,
    needs_billing: a.status === "done" && !billedApptIds.has(a.id),
    pending_service_id: a.pending_service_id,
    pending_service_name: a.pending_service_name,
    pending_price: a.pending_price,
    pending_discount_percent: a.pending_discount_percent,
    needs_new_photos: needsPhotosMap.get(a.patient_id) ?? false,
    needs_treatment: needsTreatmentMap.get(a.id) ?? false,
    purpose_type: a.purpose_type,
    purpose_service_id: a.purpose_service_id,
    purpose_service_name: a.purpose_service_name,
    purpose_service_name_en: a.purpose_service_name_en,
    purpose_service_category: a.purpose_service_category,
    purpose_linked_invoice_id: a.purpose_linked_invoice_id,
    is_ortho_patient: orthoPatientIds.has(a.patient_id),
  }));

  // دفعة 24 (طلب المستخدم صراحة): دكتور من غير شيفت أسبوعي النهاردة أصلاً
  // مايشوفش أي جدول (ده متعمّد ومطلوب). الاستثناء: لو الاستقبال حجزت له مريض
  // في يوم مش يوم شيفته العادي (حالة استثنائية/طارئة)، لازم يشوف اسم المريض ده
  // بس (مش الجدول كله ولا باقي حجوزات الغرفة من دكاترة تانيين) مع الساعة
  // المحجوزة، ويقدر يعمله "تم" ويفتح ملفه — من غير ما يحتاج شيفت مسجل أصلًا.
  const adHocAppointments = visibleRooms.length === 0 ? appointments.filter((a) => a.doctor_id === doctorId) : [];
  const roomNameById = new Map(allRooms.map((r) => [r.id, r.name]));

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-xl font-bold">{viewingToday ? "جدول اليوم" : `جدول ${scheduleDate}`}</h1>
          <p className="text-muted text-sm mt-1">
            {viewingToday
              ? canSeeAllRooms
                ? "الجدول المركزي لكل العيادات — بيتزامن أوتوماتيك مع الاستقبال."
                : "جدول شيفتك النهاردة — بيتزامن أوتوماتيك مع الاستقبال."
              : "عرض مواعيدك السابقة فقط — لا يمكن تعديلها من هنا."}
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <form className="flex items-center gap-2 text-sm">
            <label className="text-muted" htmlFor="doctor-schedule-date">التاريخ:</label>
            <input
              id="doctor-schedule-date"
              type="date"
              name="date"
              min={earliestScheduleDate}
              max={today}
              defaultValue={scheduleDate}
              className="rounded-md border border-border bg-surface px-2 py-1.5 text-sm"
            />
            <button type="submit" className="rounded-md border border-border px-3 py-1.5 text-sm hover:bg-primary-soft">عرض</button>
          </form>
          {canViewReports && (
            <Link href="/reports" className="px-3 py-2 rounded-md border border-border text-sm hover:bg-primary-soft whitespace-nowrap">
              تقريري
            </Link>
          )}
        </div>
      </div>

      {visibleRooms.length === 0 ? (
        adHocAppointments.length > 0 ? (
          <div className="space-y-3">
            <div className="text-sm bg-amber-50 dark:bg-amber-900/10 text-amber-700 dark:text-amber-400 rounded-md px-3 py-2">
              {viewingToday
                ? "مفيش شيفت أسبوعي مسجل ليك في يوم النهاردة، بس الاستقبال حجزلك المريض/المرضى دول استثنائيًا:"
                : "مفيش شيفت أسبوعي مسجل في هذا اليوم، لكن هذه مواعيدك الاستثنائية المسجلة:"}
            </div>
            {adHocAppointments.map((a) => (
              <AdHocAppointmentCard
                key={a.id}
                appointmentId={a.id}
                patientId={a.patient_id}
                patientName={a.patient_name}
                startTime={a.start_time}
                roomName={roomNameById.get(a.room_id) ?? "-"}
                needsBilling={a.needs_billing}
                pendingServiceName={a.pending_service_name}
                services={services}
                doctors={doctors}
                canEdit={canEditSchedule}
                canCollectPayments={canCollectPayments}
                canEditAssistantDoctor={canEditAssistantDoctor}
                isDoctorView
              />
            ))}
          </div>
        ) : (
          <div className="text-sm bg-danger-soft text-danger rounded-md px-3 py-2">
            {viewingToday
              ? "مفيش شيفت أسبوعي مسجل ليك في يوم النهاردة — كلم الأدمن لو محتاج تتأكد من شيفتاتك."
              : "لا يوجد شيفت أو مواعيد مسجلة لك في هذا اليوم."}
          </div>
        )
      ) : (
        <CentralSchedule
          date={scheduleDate}
          rooms={visibleRooms}
          timeSlots={timeSlots}
          slotMinutes={slotMinutes}
          appointments={appointments}
          patients={patients}
          doctors={doctors}
          services={services}
          canEdit={viewingToday && canEditSchedule}
          canCollectPayments={viewingToday && canCollectPayments}
          canEditAssistantDoctor={canEditAssistantDoctor}
          isDoctorView
          roomShiftDoctorIds={roomShiftDoctorIds}
          canQuickAddService={viewingToday && canQuickAddService}
          canBackdateInvoice={viewingToday && canBackdateInvoice}
        />
      )}
    </div>
  );
}

async function getStats() {
  const [{ count: patients } = { count: 0 }] = await db
    .selectFrom("patients")
    .select((eb) => eb.fn.countAll<number>().as("count"))
    .execute();

  const [{ count: todayAppointments } = { count: 0 }] = await db
    .selectFrom("appointments")
    .select((eb) => eb.fn.countAll<number>().as("count"))
    .where("appointment_date", "=", getClinicToday())
    .execute();

  const [{ count: todayVisits } = { count: 0 }] = await db
    .selectFrom("visits")
    .select((eb) => eb.fn.countAll<number>().as("count"))
    .where("visit_date", "=", getClinicToday())
    .execute();

  return { patients, todayAppointments, todayVisits };
}

export default async function HomePage({ searchParams }: { searchParams: Promise<{ date?: string }> }) {
  const session = await getSession();

  if (session?.role === "doctor" && session.doctorId) {
    const { date } = await searchParams;
    const today = getClinicToday();
    const earliestScheduleDate = clinicDateOffset(today, -14);
    const isAllowedDate = !!date && /^\d{4}-\d{2}-\d{2}$/.test(date) && date >= earliestScheduleDate && date <= today;
    return <DoctorHome userId={session.userId} doctorId={session.doctorId} scheduleDate={isAllowedDate ? date! : today} />;
  }

  // الاستقبال: صفحته الرئيسية هي الجدول المركزي مباشرة (مفيش داعي لصفحة إحصائيات
  // وسيطة قبله)، بدل ما يضطر يدوس "جدول الاستقبال" من القايمة كل مرة يسجل دخول.
  if (session?.role === "reception") {
    redirect("/front-desk");
  }

  const stats = await getStats();

  const cards = [
    { label: "إجمالي المرضى", value: stats.patients, href: "/patients" },
    { label: "مواعيد اليوم", value: stats.todayAppointments, href: "/front-desk" },
    { label: "زيارات اليوم", value: stats.todayVisits, href: "/patients" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold">لوحة التحكم</h1>
        <p className="text-muted text-sm mt-1">
          نظرة سريعة على العيادة اليوم — {ROLE_LABELS[session!.role]}
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {cards.map((c) => (
          <Link
            key={c.label}
            href={c.href}
            className="card-3d rounded-xl p-5 hover:border-primary transition-colors"
          >
            <div className="text-3xl font-bold text-primary">{c.value}</div>
            <div className="text-sm text-muted mt-1">{c.label}</div>
          </Link>
        ))}
      </div>

      <div className="card-3d rounded-xl p-5">
        <h2 className="font-semibold mb-3">روابط سريعة</h2>
        <div className="flex flex-wrap gap-2">
          <Link href="/patients/new" className="px-3 py-2 rounded-md btn-3d-primary text-sm">
            + مريض جديد
          </Link>
          <Link href="/front-desk" className="px-3 py-2 rounded-md border border-border text-sm hover:bg-primary-soft">
            الاستقبال
          </Link>
          <Link href="/invoices" className="px-3 py-2 rounded-md border border-border text-sm hover:bg-primary-soft">
            الفواتير
          </Link>
        </div>
      </div>
    </div>
  );
}
