"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { sql } from "kysely";
import { setSetting } from "@/lib/settings";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hashPassword } from "@/lib/auth";
import { PERMISSION_DEFS, setPermissionOverride } from "@/lib/permissions";
import { logAdminEvent } from "@/lib/audit";

export async function saveSettingsAction(formData: FormData) {
  // كانت الوحيدة في الملف من غير فحص — كل الأكشنات المجاورة أدمن فقط.
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const slot_minutes = String(formData.get("slot_minutes") || "15");
  const day_start = String(formData.get("day_start") || "09:00");
  const day_end = String(formData.get("day_end") || "22:00");
  const holidayWeekdays = formData.getAll("holiday_weekdays").map(String).join(",");

  await setSetting("slot_minutes", slot_minutes);
  await setSetting("day_start", day_start);
  await setSetting("day_end", day_end);
  await setSetting("holiday_weekdays", holidayWeekdays);

  revalidatePath("/settings");
  revalidatePath("/front-desk");
}

// إعدادات قواعد الإشعارات — الأرقام محفوظة في قاعدة البيانات، لذلك لا تحتاج
// تعديل كود عند تغيير 40/60/90 أو مدة الصور أو فترة إعادة تنبيه المرحلة النهائية.
export async function saveNotificationSettingsAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const rawStages = String(formData.get("notification_ortho_stages_days") || "");
  const stages = Array.from(
    new Set(
      rawStages
        .split(",")
        .map((part) => Number(part.trim()))
        .filter((day) => Number.isFinite(day) && day > 0)
        .map((day) => Math.round(day))
    )
  )
    .sort((a, b) => a - b)
    .slice(0, 8);
  if (!stages.length) return;

  const finalRepeat = Math.max(1, Math.min(365, Number(formData.get("notification_ortho_final_repeat_days")) || 7));
  const photoDays = Math.max(1, Math.min(3650, Number(formData.get("notification_photo_days")) || 180));
  const retentionHours = Math.max(1, Math.min(720, Number(formData.get("notification_retention_hours")) || 48));
  const requestedChatSound = String(formData.get("chat_notification_sound") || "gentle_bell");
  const chatSound = ["soft_chime", "gentle_bell", "water_drop", "off"].includes(requestedChatSound) ? requestedChatSound : "gentle_bell";

  await Promise.all([
    setSetting("notification_ortho_stages_days", stages.join(",")),
    setSetting("notification_ortho_final_repeat_days", String(Math.round(finalRepeat))),
    setSetting("notification_photo_days", String(Math.round(photoDays))),
    setSetting("notification_retention_hours", String(Math.round(retentionHours))),
    setSetting("chat_notification_sound", chatSound),
  ]);
  revalidatePath("/settings");
  revalidatePath("/");
  revalidatePath("/front-desk");
}

export async function clearStaffChatAction(): Promise<{ ok: boolean; reason?: string }> {
  const session = await getSession();
  if (!session || session.role !== "admin") return { ok: false, reason: "تصفير الشات متاح لمدير النظام فقط." };
  await db.deleteFrom("chat_messages").execute();
  revalidatePath("/", "layout");
  return { ok: true };
}

// --- إعدادات العيادات (الغرف) -----------------------------------------------

export async function addRoomAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const name = String(formData.get("name") || "").trim();
  if (!name) return;

  await db.insertInto("rooms").values({ name }).execute();
  revalidatePath("/settings");
  revalidatePath("/front-desk");
}

// مينفعش نحذف عيادة/غرفة لسه مربوطة بشيفتات أو مواعيد أو زيارات — لازم الأدمن
// يشيلها من هناك الأول، عشان منكسرش أي بيانات تاريخية أو نخالف قيد الـ foreign key.
export async function deleteRoomAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const id = Number(formData.get("id"));
  if (!id) return;

  const [inShifts, inWeeklyShifts, inAppointments, inVisits] = await Promise.all([
    db.selectFrom("shifts").select("id").where("room_id", "=", id).executeTakeFirst(),
    db.selectFrom("doctor_weekly_shifts").select("id").where("room_id", "=", id).executeTakeFirst(),
    db.selectFrom("appointments").select("id").where("room_id", "=", id).executeTakeFirst(),
    db.selectFrom("visits").select("id").where("room_id", "=", id).executeTakeFirst(),
  ]);
  if (inShifts || inWeeklyShifts || inAppointments || inVisits) {
    redirect("/settings?roomerror=in_use");
  }

  await db.deleteFrom("rooms").where("id", "=", id).execute();
  revalidatePath("/settings");
  revalidatePath("/front-desk");
}

// --- إعدادات الصلاحيات ------------------------------------------------------

export async function saveDoctorReportMaxDaysAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const days = Number(formData.get("doctor_report_max_days") || 60);
  await setSetting("doctor_report_max_days", String(Math.max(1, days)));
  revalidatePath("/settings");
}

export async function updatePermissionsAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const userId = Number(formData.get("user_id"));
  if (!userId) return;

  const granted: string[] = [];
  for (const def of PERMISSION_DEFS) {
    const isGranted = formData.get(`perm_${def.key}`) === "on";
    if (isGranted) granted.push(def.key);
    await setPermissionOverride(userId, def.key, isGranted);
  }
  await logAdminEvent({
    entityType: "user", entityId: userId, event: "update_permissions",
    details: granted.length ? `الصلاحيات بعد التعديل: ${granted.join(", ")}` : "كل الصلاحيات اتسحبت",
    changedBy: session.userId,
  });

  revalidatePath("/settings");
}

export async function updateUserContactNameAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;
  const userId = Number(formData.get("user_id"));
  const contactName = String(formData.get("contact_name") || "").trim().slice(0, 80) || null;
  if (!userId) return;
  await db.updateTable("users").set({ contact_name: contactName }).where("id", "=", userId).execute();
  revalidatePath("/settings");
}

// --- إعدادات الخدمات ---------------------------------------------------

export async function addServiceAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const name = String(formData.get("name") || "").trim();
  const name_en = String(formData.get("name_en") || "").trim() || null;
  const category = String(formData.get("category") || "").trim() || null;
  const default_price = Number(formData.get("default_price") || 0);
  const code = String(formData.get("code") || "").trim() || null;
  const price_note = String(formData.get("price_note") || "").trim() || null;
  const prepaid = formData.get("prepaid") ? 1 : 0;
  const has_lab_cost = formData.get("has_lab_cost") ? 1 : 0;
  const lab_cost = Math.max(0, Number(formData.get("lab_cost") || 0));
  if (!name) return;

  await db
    .insertInto("services")
    .values({ name, name_en, category, default_price, code, price_note, prepaid, has_lab_cost, lab_cost: has_lab_cost ? lab_cost : 0 })
    .execute();
  revalidatePath("/settings");
}

// السعر تحديدًا يحتاج تأكيد قبل الحفظ (اتفقنا عليه في الخطة) - الفرونت إند بيعرض
// window.confirm قبل استدعاء الأكشن ده لما يتغير السعر تحديدًا، فالتأكيد بيحصل
// في الطبقة العميلة قبل الوصول هنا أصلاً.
export async function updateServiceAction(formData: FormData) {
  // السعر بالذات: من غير الفحص ده كان أي مستخدم مسجّل دخول يقدر يغيّر أسعار
  // الخدمات، مهما كان دوره.
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const id = Number(formData.get("id"));
  const name = String(formData.get("name") || "").trim();
  const name_en = String(formData.get("name_en") || "").trim() || null;
  const category = String(formData.get("category") || "").trim() || null;
  const default_price = Number(formData.get("default_price") || 0);
  const code = String(formData.get("code") || "").trim() || null;
  const price_note = String(formData.get("price_note") || "").trim() || null;
  const prepaid = formData.get("prepaid") ? 1 : 0;
  const has_lab_cost = formData.get("has_lab_cost") ? 1 : 0;
  const lab_cost = Math.max(0, Number(formData.get("lab_cost") || 0));
  if (!id || !name) return;

  await db
    .updateTable("services")
    .set({ name, name_en, category, default_price, code, price_note, prepaid, has_lab_cost, lab_cost: has_lab_cost ? lab_cost : 0 })
    .where("id", "=", id)
    .execute();
  revalidatePath("/settings");
}

// --- شيفتات الأطباء الأسبوعية ------------------------------------------

export async function addWeeklyShiftAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const room_id = Number(formData.get("room_id"));
  const weekday = Number(formData.get("weekday"));
  const doctor_id = Number(formData.get("doctor_id"));
  const start_time = String(formData.get("start_time") || "");
  const end_time = String(formData.get("end_time") || "");

  if (!room_id || !doctor_id || !start_time || !end_time) return;
  if (!Number.isInteger(weekday) || weekday < 0 || weekday > 6) return;

  await db.insertInto("doctor_weekly_shifts").values({ room_id, weekday, doctor_id, start_time, end_time }).execute();
  revalidatePath("/settings");
  revalidatePath("/front-desk");
}

export async function deleteWeeklyShiftAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const id = Number(formData.get("id"));
  if (!id) return;

  await db.deleteFrom("doctor_weekly_shifts").where("id", "=", id).execute();
  revalidatePath("/settings");
  revalidatePath("/front-desk");
}

// --- إعدادات الأطباء ------------------------------------------------------

// خريطة تحويل تقريبية من الحروف العربية لحروف لاتينية، عشان اليوزرنيم يبقى
// مرتبط باسم الدكتور الحقيقي حتى لو الاسم مكتوب عربي بالكامل (الحالة الشائعة هنا).
const ARABIC_TRANSLITERATION: Record<string, string> = {
  ا: "a", أ: "a", إ: "e", آ: "a", ب: "b", ت: "t", ث: "th", ج: "g", ح: "h",
  خ: "kh", د: "d", ذ: "th", ر: "r", ز: "z", س: "s", ش: "sh", ص: "s", ض: "d",
  ط: "t", ظ: "z", ع: "a", غ: "gh", ف: "f", ق: "q", ك: "k", ل: "l", م: "m",
  ن: "n", ه: "h", و: "w", ي: "y", ى: "a", ة: "a", ء: "", ئ: "e", ؤ: "o",
};

function transliterateArabic(word: string): string {
  return word
    .split("")
    .map((ch) => (ch in ARABIC_TRANSLITERATION ? ARABIC_TRANSLITERATION[ch] : ""))
    .join("");
}

function generateUsername(fullName: string): string {
  // شيل الألقاب الشائعة (مذكر ومؤنث: "د."، "دكتور"، "دكتورة"، "الدكتور"، "الدكتورة")
  // عشان اليوزرنيم يتبني على الاسم الفعلي مش على اللقب.
  const withoutTitle = fullName
    .trim()
    .replace(/^(د\.?|الدكتورة|الدكتور|دكتورة|دكتور)\s+/u, "");
  const firstWord = withoutTitle.split(/\s+/)[0]?.replace(/[^ء-يa-zA-Z0-9]/g, "") || "";

  let base: string;
  if (/[a-zA-Z]/.test(firstWord)) {
    base = firstWord.toLowerCase();
  } else if (firstWord) {
    base = transliterateArabic(firstWord) || "dr";
  } else {
    base = "dr";
  }

  return `dr.${base}${Math.floor(100 + Math.random() * 900)}`;
}

// كلمة سر افتراضية ثابتة "123" لأي مستخدم جديد (دكتور أو موظف) — بدل كلمة سر
// عشوائية معقدة كانت بتتولد وتتعرض مرة واحدة بس. القرار: أسهل للأدمن إنه يقول
// لليوزر الجديد كلمة السر من غير ما يحتاج يسجلها وقت الإنشاء، والمتوقع إن كل
// مستخدم يغيّرها بنفسه من "تغيير كلمة السر" بعد أول دخول (الميزة دي جاهزة من
// دفعة 1). ملحوظة: "123" أقل من الحد الأدنى (6 حروف) المفروض على كلمة سر
// جديدة في changePasswordAction تحت — وده مقصود ومش بيتعارض مع حاجة، لأن الحد
// الأدنى ده بيتطبق بس وقت ما اليوزر يغيّر كلمة سره هو بنفسه، مش وقت الإنشاء.
function generatePassword(): string {
  return "123";
}

async function usernameExists(username: string): Promise<boolean> {
  const row = await db
    .selectFrom("users")
    .select("id")
    // يمنع إنشاء Karim و karim كحسابين مختلفين.
    .where(sql<string>`lower(username)`, "=", username.toLowerCase())
    .executeTakeFirst();
  return !!row;
}

// اسم مستخدم فريد لمين اليوزرنيم التلقائي بتاعه اتصادف واتكرر (نادر جدًا بسبب
// الرقم العشوائي في generateUsername، بس بيتأكد منه بدل ما يعتمد على قيد
// قاعدة البيانات بس ويرمي خطأ غير مفهوم للمستخدم).
async function generateUniqueUsername(fullName: string): Promise<string> {
  for (let i = 0; i < 5; i++) {
    const candidate = generateUsername(fullName);
    if (!(await usernameExists(candidate))) return candidate;
  }
  return `${generateUsername(fullName)}${Date.now() % 1000}`;
}

// اسم المستخدم اللي الأدمن بيكتبه يدويًا (اختياري) — لازم يكون حروف إنجليزي/أرقام/
// نقطة/شرطة سفلية/شرطة بس (نفس نمط اليوزرنيمات الحالية المتولدة تلقائيًا)، عشان
// يفضل يصلح كإيميل/لوجين من غير مشاكل ترميز، وميتعارضش مع يوزرنيم موجود بالفعل.
const USERNAME_PATTERN = /^[a-zA-Z0-9._-]{3,30}$/;

async function resolveUsername(rawInput: string | undefined, fullName: string): Promise<{ username: string } | { error: string }> {
  const custom = (rawInput ?? "").trim();
  if (!custom) return { username: await generateUniqueUsername(fullName) };

  if (!USERNAME_PATTERN.test(custom)) return { error: "invalid_username" };
  if (await usernameExists(custom)) return { error: "username_taken" };
  return { username: custom };
}

// بيرجع بيانات الدخول الجديدة عشان تتعرض للأدمن مرة واحدة بس وقت الإنشاء
// (زي أي نظام - كلمة السر مش بتتخزن نص صريح، فلازم تتعرض دلوقتي أو متتعرفش تاني).
export async function addDoctorAction(
  _prevState: { username?: string; password?: string; error?: string } | null,
  formData: FormData
): Promise<{ username?: string; password?: string; error?: string }> {
  const session = await getSession();
  if (!session || session.role !== "admin") return { error: "unauthorized" };

  const full_name = String(formData.get("full_name") || "").trim();
  if (!full_name) return { error: "missing" };

  // بيتحقق من اسم المستخدم (لو الأدمن كتب واحد يدوي) قبل إنشاء صف الدكتور،
  // عشان لو غلط ميفضلش صف دكتور يتيم من غير حساب مستخدم مرتبط بيه.
  const usernameResult = await resolveUsername(formData.get("username")?.toString(), full_name);
  if ("error" in usernameResult) return { error: usernameResult.error };

  const doctorResult = await db.insertInto("doctors").values({ full_name }).executeTakeFirst();
  const doctorId = Number(doctorResult.insertId);

  const { username } = usernameResult;
  const password = generatePassword();
  const password_hash = await hashPassword(password);

  await db
    .insertInto("users")
    .values({ username, password_hash, full_name, role: "doctor", doctor_id: doctorId })
    .execute();

  revalidatePath("/settings");
  return { username, password };
}

// دفعة 22: تحديد إن الدكتور "استشاري" + قائمة الدكاترة المساعدين تحته
// (many-to-many — استشاري ممكن يكون عنده أكتر من مساعد). بيمسح قائمة المساعدين
// القديمة ويسجل الجديدة كل مرة (استبدال كامل، أبسط من diff جزئي). أدمن بس.
export async function updateDoctorConsultantAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const doctorId = Number(formData.get("doctor_id"));
  if (!doctorId) return;

  const isConsultant = formData.get("is_consultant") ? 1 : 0;
  const assistantIds = formData
    .getAll("assistant_doctor_ids")
    .map((v) => Number(v))
    .filter((id) => Number.isFinite(id) && id > 0 && id !== doctorId);

  await db.updateTable("doctors").set({ is_consultant: isConsultant }).where("id", "=", doctorId).execute();

  await db.deleteFrom("consultant_assistants").where("consultant_doctor_id", "=", doctorId).execute();
  if (isConsultant && assistantIds.length > 0) {
    await db
      .insertInto("consultant_assistants")
      .values(assistantIds.map((assistantId) => ({ consultant_doctor_id: doctorId, assistant_doctor_id: assistantId })))
      .execute();
  }

  revalidatePath("/settings");
}

// --- إعدادات المستخدمين (موظفين غير الأطباء) -------------------------------

const EMPLOYEE_ROLES = ["reception", "accountant", "clinic_manager"] as const;

export async function addEmployeeAction(
  _prevState: { username?: string; password?: string; error?: string } | null,
  formData: FormData
): Promise<{ username?: string; password?: string; error?: string }> {
  const session = await getSession();
  if (!session || session.role !== "admin") return { error: "unauthorized" };

  const full_name = String(formData.get("full_name") || "").trim();
  const role = String(formData.get("role") || "");
  if (!full_name || !EMPLOYEE_ROLES.includes(role as (typeof EMPLOYEE_ROLES)[number])) {
    return { error: "missing" };
  }

  const usernameResult = await resolveUsername(formData.get("username")?.toString(), full_name);
  if ("error" in usernameResult) return { error: usernameResult.error };
  const { username } = usernameResult;
  const password = generatePassword();
  const password_hash = await hashPassword(password);

  await db
    .insertInto("users")
    .values({ username, password_hash, full_name, role: role as (typeof EMPLOYEE_ROLES)[number], doctor_id: null })
    .execute();

  revalidatePath("/settings");
  return { username, password };
}

// حذف "منطقي" (active=0) مش حذف فعلي، عشان الصفوف القديمة (زيارات، سجل تعديلات..)
// اللي بتشاور على المستخدم ده متتكسرش. بيتفلتر تلقائيًا من كل الاستعلامات الحالية
// اللي بتحدد where active = 1.
//
// دفعة 22: لو المستخدم ده حساب دكتور، بنعطّل (active=0) صف الطبيب نفسه في جدول
// doctors كمان — مش بس حسابه. قبل كده كان حذف "الحساب" بس بيقفل تسجيل الدخول،
// لكن الطبيب كان بيفضل ظاهر في كل قوائم اختيار الدكاترة (سجل الزيارات، الجدول
// المركزي، إضافة خدمة من الملف المالي..) لأن الاستعلامات دي بتفلتر على
// doctors.active بشكل منفصل عن users.active. دلوقتي "حذف" من هنا بيشيله من
// الاتنين مرة واحدة — من غير ما يمسح أي بيانات تاريخية (زياراته/فواتيره
// وتقاريره القديمة تفضل زي ما هي بالظبط).
export async function deleteUserAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const id = Number(formData.get("id"));
  if (!id || id === session.userId) return; // ما ينفعش المستخدم يحذف نفسه

  const target = await db.selectFrom("users").select(["role", "doctor_id"]).where("id", "=", id).executeTakeFirst();
  if (!target || target.role === "admin") return; // حماية حسابات الأدمن من الحذف عن طريق الواجهة

  await db.updateTable("users").set({ active: 0 }).where("id", "=", id).execute();

  if (target.role === "doctor" && target.doctor_id) {
    await db.updateTable("doctors").set({ active: 0 }).where("id", "=", target.doctor_id).execute();
  }

  revalidatePath("/settings");
  revalidatePath("/");
  revalidatePath("/front-desk");
}

// إعادة تعيين كلمة سر أي مستخدم (غير الأدمن الحالي نفسه) لكلمة السر الافتراضية
// الثابتة "123" — للأدمن بس، لحالات زي "المستخدم نسي كلمة سره" من غير ما يحتاج
// يعرف كلمة سره القديمة أصلاً. بتستخدم نفس generatePassword() المستخدمة وقت
// إنشاء أي حساب جديد، عشان القيمة الافتراضية تفضل واحدة موحّدة في كل التطبيق.
export async function resetUserPasswordAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const id = Number(formData.get("id"));
  if (!id) return;

  const target = await db.selectFrom("users").select(["id", "full_name"]).where("id", "=", id).executeTakeFirst();
  if (!target) return;

  const newPassword = generatePassword();
  const password_hash = await hashPassword(newPassword);
  // رجوع الحساب لكلمة السر الافتراضية معناه إنه لازم يغيّرها تاني عند أول دخول.
  await db.updateTable("users").set({ password_hash, must_change_password: 1 }).where("id", "=", id).execute();
  await logAdminEvent({
    entityType: "user", entityId: id, event: "reset_password",
    details: `تصفير كلمة سر ${target.full_name} للافتراضية`, changedBy: session.userId,
  });

  revalidatePath("/settings");
  redirect(`/settings?resetpw=${encodeURIComponent(target.full_name)}`);
}

// تغيير كلمة السر اتنقل لصفحة /change-password المستقلة: أي مستخدم يوصلها
// (الدكتور مش لازم يبقى عنده صلاحية الإعدادات عشان يغيّر كلمة سره)، وهي نفس
// الصفحة اللي بيتحوّل ليها اللي لسه على كلمة السر الافتراضية "123".

// --- شارت التقويم v2: قوايم الاختيارات (مقاسات/أنواع الوير، ألوان الـO-tie،
// مقاسات الإيلاستكس) — دمج 2026-08-27، طلب صريح من المستخدم إنه يقدر
// يضيف/يعدّل القوايم دي بنفسه من هنا بدل ما تبقى قيم ثابتة في الكود. ---

const ORTHO_OPTION_CATEGORIES = ["wire_size", "wire_type", "otie_color", "elastic_size", "anchorage_device"] as const;
type OrthoOptionCategory = (typeof ORTHO_OPTION_CATEGORIES)[number];

export async function addOrthoOptionAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const category = String(formData.get("category") || "");
  const value = String(formData.get("value") || "").trim();
  if (!ORTHO_OPTION_CATEGORIES.includes(category as OrthoOptionCategory) || !value) return;

  const maxSort = await db
    .selectFrom("ortho_option_lists")
    .select((eb) => eb.fn.max("sort_order").as("max_sort"))
    .where("category", "=", category as OrthoOptionCategory)
    .executeTakeFirst();

  await db
    .insertInto("ortho_option_lists")
    .values({ category: category as OrthoOptionCategory, value, sort_order: (maxSort?.max_sort ?? -1) + 1 })
    .execute();

  revalidatePath("/settings");
  revalidatePath("/patients", "layout");
}

export async function deleteOrthoOptionAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const id = Number(formData.get("id"));
  if (!id) return;

  // مسح فعلي (مش soft-delete) — القيمة دي كانت بس اختيار في دروب داون، لو
  // اتمسحت مفيش أي بيانات مرتبطة بيها بشكل مباشر (الزيارات القديمة بتحتفظ
  // بالنص نفسه اللي كان مسجل وقتها في ortho_visits، مش بمرجع لسطر القايمة).
  await db.deleteFrom("ortho_option_lists").where("id", "=", id).execute();

  revalidatePath("/settings");
  revalidatePath("/patients", "layout");
}
