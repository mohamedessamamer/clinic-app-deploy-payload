import { db } from "@/lib/db/client";

// دفعة 27 (P3.2): سياق "متابعة: <اسم الخدمة>" اللي بيظهر للدكتور وقت إدخال
// معالجة (سواء الملف الطبي العادي أو شارت التقويم) — من غير أي دخل ليه في
// الجزء المالي نفسه (الفصل الكامل بين الملفين فاضل زي ما هو)، مجرد سياق يوضح
// إن الزيارة دي متابعة لخدمة سبق فتحها من الاستقبال (appointments.purpose_linked_invoice_id).
export type PurposeContext = {
  serviceName: string;
  balance: number;
};

// بيدوّر على أقرب موعد للمريض النهاردة معاه purpose_linked_invoice_id، ولو
// لقى، بيرجّع اسم الخدمة الأصلية والباقي المتبقي عليها فعليًا (بعد خصم أي
// دفعات متابعة سابقة). بيرجّع null لو مفيش موعد النهاردة أو مفيش ربط أصلاً.
export async function getTodayPurposeContext(patientId: number, today: string): Promise<PurposeContext | null> {
  if (!patientId) return null;

  const appt = await db
    .selectFrom("appointments")
    .select(["purpose_linked_invoice_id"])
    .where("patient_id", "=", patientId)
    .where("appointment_date", "=", today)
    .where("status", "!=", "cancelled")
    .where("purpose_linked_invoice_id", "is not", null)
    .orderBy("start_time")
    .executeTakeFirst();

  if (!appt || !appt.purpose_linked_invoice_id) return null;

  const invoice = await db
    .selectFrom("invoices")
    .innerJoin("visits", "visits.id", "invoices.visit_id")
    .leftJoin("services", "services.id", "visits.service_id")
    .select(["invoices.id", "invoices.amount", "invoices.paid", "services.name as service_name"])
    .where("invoices.id", "=", appt.purpose_linked_invoice_id)
    .executeTakeFirst();
  if (!invoice) return null;

  const followupPaid = await db
    .selectFrom("invoices")
    .select(["paid"])
    .where("parent_invoice_id", "=", invoice.id)
    .execute();
  const followupSum = followupPaid.reduce((sum, f) => sum + f.paid, 0);

  return {
    serviceName: invoice.service_name ?? "-",
    balance: Math.round((invoice.amount - invoice.paid - followupSum) * 100) / 100,
  };
}
