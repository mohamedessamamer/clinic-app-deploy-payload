import Link from "next/link";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import {
  addSimpleInventoryItemAction,
  receiveInventorySupplyAction,
  recordInventoryCountAction,
  saveGeneralConsumableRuleAction,
} from "./actions";

const inputClass = "w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm";

function money(amount: number | null) {
  return amount == null ? "—" : `${amount.toFixed(0)} ج.م`;
}

const orthoLabels: Record<string, string> = {
  wire: "Wire", bracket: "Bracket", tube: "Tube", elastic: "Elastic", otie: "O-tie",
  power_chain: "Power chain", button: "Button", compressed_coil: "Compressed coil", anchorage_device: "Anchorage device",
};

export default async function InventoryPage() {
  const session = await getSession();
  const canManage = session ? await hasPermission(session.userId, session.role, "manage_inventory") : false;
  if (!canManage) return <div className="card-3d rounded-xl p-5 text-sm text-muted">مفيش صلاحية عندك لعرض المخزن — كلم الأدمن لو محتاج توصل له.</div>;

  const [specialties, suppliers, items, batches] = await Promise.all([
    db.selectFrom("inventory_specialties").select(["id", "name"]).where("active", "=", 1).orderBy("name").execute(),
    db.selectFrom("inventory_suppliers").select(["id", "name"]).where("active", "=", 1).orderBy("name").execute(),
    db.selectFrom("inventory_items")
      .leftJoin("inventory_specialties", "inventory_specialties.id", "inventory_items.specialty_id")
      .leftJoin("inventory_suppliers", "inventory_suppliers.id", "inventory_items.supplier_id")
      .leftJoin("inventory_consumable_rules", "inventory_consumable_rules.item_id", "inventory_items.id")
      .select([
        "inventory_items.id", "inventory_items.name", "inventory_items.quantity", "inventory_items.unit",
        "inventory_items.low_stock_threshold", "inventory_items.critical_stock_threshold", "inventory_items.reorder_quantity",
        "inventory_items.ortho_usage", "inventory_items.is_general_consumable", "inventory_specialties.name as specialty_name",
        "inventory_suppliers.name as preferred_supplier_name", "inventory_consumable_rules.quantity_per_completed_appointment",
        "inventory_consumable_rules.active as consumable_rule_active",
      ])
      .orderBy("inventory_items.is_general_consumable", "desc").orderBy("inventory_items.name").execute(),
    db.selectFrom("inventory_supply_batches")
      .leftJoin("inventory_suppliers", "inventory_suppliers.id", "inventory_supply_batches.supplier_id")
      .select([
        "inventory_supply_batches.id", "inventory_supply_batches.item_id", "inventory_supply_batches.brand",
        "inventory_supply_batches.quantity_received", "inventory_supply_batches.quantity_remaining", "inventory_supply_batches.total_cost",
        "inventory_supply_batches.received_at", "inventory_suppliers.name as supplier_name",
      ])
      .orderBy("inventory_supply_batches.received_at", "asc").orderBy("inventory_supply_batches.id", "asc").execute(),
  ]);

  const batchesByItem = new Map<number, typeof batches>();
  for (const batch of batches) batchesByItem.set(batch.item_id, [...(batchesByItem.get(batch.item_id) ?? []), batch]);
  const brands = [...new Set(batches.map((batch) => batch.brand).filter((brand): brand is string => Boolean(brand)))].sort();
  const generalItems = items.filter((item) => item.is_general_consumable === 1);

  return <div className="space-y-6">
    <div className="flex flex-wrap items-start justify-between gap-3">
      <div><h1 className="text-xl font-bold">المخزن</h1><p className="text-sm text-muted mt-1">الخامة سطر واحد للجرد ولشارت التقويم؛ الشركات والموردون توريدات تحتها.</p></div>
      <Link href="/settings" className="rounded-md border border-border px-3 py-2 text-sm hover:bg-primary-soft">إدارة الموردين والتخصصات</Link>
    </div>

    <section className="card-3d rounded-xl p-5 space-y-4">
      <div><h2 className="font-semibold">1) تعريف خامة علاجية أو مستهلك عام</h2><p className="text-xs text-muted mt-1">اكتب الخامة التي تريد جردها واختيارها طبيًا، مثل <b>NiTi 0.012</b> أو <b>O-tie Blue</b>، من غير شركة.</p></div>
      <form action={addSimpleInventoryItemAction} className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3 items-end">
        <div className="xl:col-span-2"><label className="block text-xs text-muted mb-1">اسم الخامة العلاجية *</label><input name="name" required placeholder="NiTi 0.012 أو O-tie Blue" className={inputClass} /></div>
        <div><label className="block text-xs text-muted mb-1">التخصص</label><select name="specialty_id" className={inputClass}><option value="">عام</option>{specialties.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></div>
        <div><label className="block text-xs text-muted mb-1">وحدة الجرد *</label><input name="unit" required placeholder="Wire / قطعة / Pair" className={inputClass} /></div>
        <div><label className="block text-xs text-muted mb-1">استخدامه بشارت التقويم</label><select name="ortho_usage" className={inputClass}><option value="">ليس خامة شارت تقويم</option>{Object.entries(orthoLabels).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select></div>
        <label className="flex items-center gap-2 text-sm rounded-md border border-border px-3 py-2"><input type="checkbox" name="is_general_consumable" value="1" /> مستهلك عام لكل مريض تم</label>
        <div><label className="block text-xs text-muted mb-1">حد التنبيه</label><input name="low_stock_threshold" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} /></div>
        <div><label className="block text-xs text-muted mb-1">الحد الحرج</label><input name="critical_stock_threshold" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} /></div>
        <div><label className="block text-xs text-muted mb-1">كمية طلب مقترحة</label><input name="reorder_quantity" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} /></div>
        <div><label className="block text-xs text-muted mb-1">المورد المفضل للطلب</label><select name="preferred_supplier_id" className={inputClass}><option value="">يُحدد لاحقًا</option>{suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></div>
        <button className="rounded-md btn-3d-primary px-3 py-2 text-sm font-medium">حفظ الخامة</button>
      </form>
    </section>

    <section className="card-3d rounded-xl p-5 space-y-4">
      <div><h2 className="font-semibold">2) استلام توريد</h2><p className="text-xs text-muted mt-1">أدخل الكمية بوحدة الجرد. علبة فيها 10 wires وسعرها 420 ج.م: الكمية 10 والتكلفة 420.</p></div>
      <form action={receiveInventorySupplyAction} className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-3 items-end">
        <div className="xl:col-span-2"><label className="block text-xs text-muted mb-1">الخامة *</label><select name="item_id" required className={inputClass}><option value="">اختر الخامة</option>{items.map((item) => <option key={item.id} value={item.id}>{item.name} — الرصيد {item.quantity} {item.unit ?? ""}</option>)}</select></div>
        <div><label className="block text-xs text-muted mb-1">المورد</label><select name="supplier_id" className={inputClass}><option value="">غير محدد</option>{suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></div>
        <div><label className="block text-xs text-muted mb-1">الشركة / البراند</label><input name="brand" list="inventory-brands" placeholder="American / Ormco" className={inputClass} /><datalist id="inventory-brands">{brands.map((brand) => <option key={brand} value={brand} />)}</datalist></div>
        <div><label className="block text-xs text-muted mb-1">الكمية المستلمة *</label><input name="quantity_received" type="number" min="0.01" step="0.01" required className={inputClass} /></div>
        <div><label className="block text-xs text-muted mb-1">إجمالي التكلفة</label><input name="total_cost" type="number" min="0" step="0.01" className={inputClass} /></div>
        <div><label className="block text-xs text-muted mb-1">تاريخ التوريد</label><input name="received_at" type="date" className={inputClass} /></div>
        <div className="xl:col-span-2"><label className="block text-xs text-muted mb-1">ملاحظة</label><input name="note" className={inputClass} /></div>
        <button className="rounded-md btn-3d-primary px-3 py-2 text-sm font-medium">تسجيل التوريد</button>
      </form>
    </section>

    {generalItems.length > 0 && <section className="card-3d rounded-xl p-5 space-y-3">
      <div><h2 className="font-semibold">استهلاك المستهلكات العامة لكل مريض تم</h2><p className="text-xs text-muted mt-1">يخصم النظام الكمية مرة واحدة عند تحول الموعد إلى «تم». اتركها صفرًا لإيقاف الخصم التلقائي.</p></div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">{generalItems.map((item) => <form key={item.id} action={saveGeneralConsumableRuleAction} className="rounded-lg border border-border p-3 flex gap-2 items-end"><input type="hidden" name="item_id" value={item.id} /><div className="flex-1"><label className="block text-xs text-muted mb-1">{item.name} ({item.unit}) لكل مريض</label><input name="quantity_per_completed_appointment" type="number" min="0" step="0.01" defaultValue={item.consumable_rule_active ? item.quantity_per_completed_appointment ?? 0 : 0} className={inputClass} /></div><button className="rounded-md border border-border px-3 py-1.5 text-sm hover:bg-primary-soft">حفظ</button></form>)}</div>
    </section>}

    <section className="card-3d rounded-xl overflow-hidden">
      <div className="px-5 py-4 flex items-center justify-between gap-3 flex-wrap"><div><h2 className="font-semibold">الجرد والرصد الحالي</h2><p className="text-xs text-muted mt-1">الرصيد إجمالي كل التوريدات البديلة. افتح التفاصيل لرؤية الشركة والمورد والسعر.</p></div><span className="text-xs text-muted">{items.length} خامة</span></div>
      <div className="overflow-x-auto"><table className="w-full text-sm"><thead className="bg-primary-soft text-primary-dark"><tr><th className="text-right px-4 py-2">الخامة</th><th className="text-right px-4 py-2">الرصيد</th><th className="text-right px-4 py-2">الحد الأدنى</th><th className="text-right px-4 py-2">الاستهلاك</th><th className="text-right px-4 py-2">جرد فعلي</th></tr></thead><tbody>
        {items.map((item) => {
          const low = item.low_stock_threshold > 0 && item.quantity <= item.low_stock_threshold;
          const critical = low && item.quantity <= item.critical_stock_threshold;
          const itemBatches = batchesByItem.get(item.id) ?? [];
          return <tr key={item.id} className="border-t border-border align-top"><td className="px-4 py-3 min-w-72"><div className="font-medium">{item.name}</div><div className="text-xs text-muted mt-0.5">{item.specialty_name ?? "عام"}{item.ortho_usage ? ` · شارت التقويم: ${orthoLabels[item.ortho_usage] ?? item.ortho_usage}` : ""}{item.is_general_consumable ? " · مستهلك عام" : ""}</div>{itemBatches.length > 0 && <details className="mt-2 text-xs"><summary className="cursor-pointer text-primary">توريدات وتفصيل الشركات ({itemBatches.length})</summary><ul className="mt-1 space-y-1 text-muted">{itemBatches.map((batch) => <li key={batch.id}>• {batch.brand ?? "بدون شركة"} — {batch.supplier_name ?? "بدون مورد"}: المتبقي {batch.quantity_remaining}/{batch.quantity_received} {item.unit ?? ""} — تكلفة التوريد {money(batch.total_cost)}{batch.total_cost != null ? ` (${(batch.total_cost / batch.quantity_received).toFixed(2)} ج.م/${item.unit ?? "وحدة"})` : ""}</li>)}</ul></details>}</td><td className="px-4 py-3 whitespace-nowrap"><span className={low ? "font-bold text-danger" : "font-semibold"}>{item.quantity} {item.unit ?? ""}</span>{critical ? <div className="text-xs text-danger">حرج</div> : low ? <div className="text-xs text-danger">قرب النفاد</div> : null}</td><td className="px-4 py-3">{item.low_stock_threshold || "—"}{item.reorder_quantity > 0 ? <div className="text-xs text-muted">اطلب {item.reorder_quantity}</div> : null}</td><td className="px-4 py-3">{item.is_general_consumable ? item.consumable_rule_active ? `${item.quantity_per_completed_appointment} ${item.unit ?? ""} / مريض` : "غير مفعل" : "—"}</td><td className="px-4 py-3"><form action={recordInventoryCountAction} className="flex gap-1 min-w-44"><input type="hidden" name="item_id" value={item.id} /><input name="counted_quantity" type="number" min="0" step="0.01" defaultValue={item.quantity} className="w-24 rounded-md border border-border bg-background px-2 py-1 text-xs" /><button className="rounded-md border border-border px-2 py-1 text-xs hover:bg-primary-soft">حفظ</button></form></td></tr>;
        })}
        {items.length === 0 && <tr><td colSpan={5} className="px-4 py-8 text-center text-muted">ابدأ بتعريف الخامة، ثم سجّل أول توريد لها.</td></tr>}
      </tbody></table></div>
    </section>
  </div>;
}
