// راوت معزول تمامًا للمعاينة — من غير أي ربط بالـnav أو الداتا الحقيقية،
// من غير أي تسجيل دخول لازم (بروتوتايب للمراجعة بس، هيتشال أو يترّبط بالسيستم
// الحقيقي بعد الموافقة النهائية على الشكل). شوف orthodontic-chart-v2-*.md في
// مشروع "Clinic mangment system" على claude.ai للتفاصيل الكاملة.

import OrthoChartV2 from "@/components/prototype/OrthoChartV2";

export default function OrthoChartV2PreviewPage() {
  return (
    <div className="min-h-screen bg-background p-4 sm:p-8 max-w-5xl mx-auto">
      <div className="mb-4 text-xs text-muted">
        معاينة بروتوتايب — شارت التقويم v2 (صفحة 1) — <span className="font-semibold">مش الشارت الحقيقي المنشور، ومفيش أي بيانات بتتحفظ فعليًا</span>
      </div>
      <OrthoChartV2 patientName="مريض تجريبي (بروتوتايب معاينة)" />
    </div>
  );
}
