"use client";

// ===================================================================
// Orthodontic chart v2 — "Interactive chart" (isolated prototype, mock data only)
// ===================================================================
// Full behavior spec: project "Clinic mangment system" on claude.ai —
// orthodontic-chart-v2-interactive-chart-spec.md. Quick summary:
//
// - Real photographic teeth (from the user's PowerPoint), FDI numbering.
// - Bracket box: beige = no bracket, blue = bonded, red = broken.
// - Double-click (or long-press on mobile) a blue box → confirm break → red + date.
// - Double-click a red box → choose "new" or "old" → rebonds (blue) + rebonding
//   counter increments (only "new" deducts from the mock "inventory").
// - Right-click (or long-press) anywhere else on the tooth → "Extracted".
// - Stripping/Miniscrew modes: a button toggles the mode, lines/circles appear
//   between every two adjacent teeth, click records, click elsewhere exits the
//   mode (whatever was actually recorded stays visible).
// - bulkBond(arch) is exposed via ref so a "Bonding Upper/Lower" follow-up visit
//   can auto-bond the whole arch (all teeth except the 2nd/3rd molars, FDI
//   positions 7 & 8) — see orthodontic-chart-v2-canva-redesign.md.
//
// Local-state prototype only (useState) — no real database connection. The
// component is kept always mounted (parent toggles it with CSS, not
// conditional rendering) so this state survives switching to Diagnostic chart
// and back.

import { useState, forwardRef, useImperativeHandle } from "react";
import { UPPER_ROW, LOWER_ROW, gapsFor, type ToothMeta } from "@/lib/prototype/fdi-teeth";

type BracketStatus = "none" | "bonded" | "broken";

interface ToothState {
  bracket: BracketStatus;
  debondDate: string | null;
  rebondCount: number;
  extracted: boolean;
  comment: string;
}

type ToothStateMap = Record<number, ToothState>;
type GapMode = "none" | "stripping" | "miniscrew";

function emptyToothState(): ToothState {
  return { bracket: "none", debondDate: null, rebondCount: 0, extracted: false, comment: "" };
}

function todayStr(): string {
  const d = new Date();
  return `${String(d.getDate()).padStart(2, "0")}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getFullYear()).slice(2)}`;
}

const UPPER_GAPS = gapsFor(UPPER_ROW);
const LOWER_GAPS = gapsFor(LOWER_ROW);

export interface MockInventoryLog {
  label: string;
  qty: number;
}

export interface InteractiveToothChartHandle {
  /** Bonds every tooth in the given arch except the 2nd/3rd molars (FDI position 7 & 8). */
  bulkBond: (arch: "upper" | "lower") => void;
}

const InteractiveToothChart = forwardRef<InteractiveToothChartHandle, { onInventoryDeduct?: (log: MockInventoryLog) => void }>(
  function InteractiveToothChart({ onInventoryDeduct }, ref) {
    const [teeth, setTeeth] = useState<ToothStateMap>(() => {
      const m: ToothStateMap = {};
      [...UPPER_ROW, ...LOWER_ROW].forEach((t) => (m[t.fdi] = emptyToothState()));
      return m;
    });
    const [stripCounts, setStripCounts] = useState<Record<string, number>>({});
    const [miniscrews, setMiniscrews] = useState<Record<string, boolean>>({});
    const [mode, setMode] = useState<GapMode>("none");
    const [rebondPrompt, setRebondPrompt] = useState<{ fdi: number; x: number; y: number } | null>(null);
    const [extractMenu, setExtractMenu] = useState<{ fdi: number; x: number; y: number } | null>(null);
    const [selectedTooth, setSelectedTooth] = useState<number | null>(null);

    function patchTooth(fdi: number, patch: Partial<ToothState>) {
      setTeeth((prev) => ({ ...prev, [fdi]: { ...prev[fdi], ...patch } }));
    }

    useImperativeHandle(ref, () => ({
      bulkBond(arch: "upper" | "lower") {
        const row = arch === "upper" ? UPPER_ROW : LOWER_ROW;
        const targets = row.filter((t) => t.position <= 6);
        setTeeth((prev) => {
          const next = { ...prev };
          targets.forEach((t) => {
            if (!next[t.fdi].extracted) {
              next[t.fdi] = { ...next[t.fdi], bracket: "bonded", debondDate: null };
            }
          });
          return next;
        });
        onInventoryDeduct?.({ label: `Brackets — Bonding ${arch === "upper" ? "Upper" : "Lower"}`, qty: targets.length });
      },
    }));

    function handleBracketDoubleClick(t: ToothMeta) {
      const state = teeth[t.fdi];
      if (state.bracket === "bonded") {
        if (window.confirm(`Bracket ${t.fdi} debonded?`)) {
          patchTooth(t.fdi, { bracket: "broken", debondDate: todayStr() });
        }
      } else if (state.bracket === "broken") {
        setRebondPrompt({ fdi: t.fdi, x: 0, y: 0 });
      } else {
        // No bracket yet (beige) — double-click bonds it as a first-time quick test.
        if (window.confirm(`Bond a new bracket on tooth ${t.fdi}?`)) {
          patchTooth(t.fdi, { bracket: "bonded" });
          onInventoryDeduct?.({ label: `Bracket (tooth ${t.fdi})`, qty: 1 });
        }
      }
    }

    function confirmRebond(kind: "new" | "old") {
      if (!rebondPrompt) return;
      const { fdi } = rebondPrompt;
      setTeeth((prev) => ({
        ...prev,
        [fdi]: { ...prev[fdi], bracket: "bonded", debondDate: null, rebondCount: prev[fdi].rebondCount + 1 },
      }));
      if (kind === "new") onInventoryDeduct?.({ label: `New bracket (tooth ${fdi})`, qty: 1 });
      setRebondPrompt(null);
    }

    function handleToothContextMenu(e: React.MouseEvent, t: ToothMeta) {
      e.preventDefault();
      setExtractMenu({ fdi: t.fdi, x: e.clientX, y: e.clientY });
    }

    // Long-press for mobile/tablet (right-click equivalent) — same pattern already
    // used in the central schedule (CentralSchedule.tsx) for other context menus.
    function useLongPress(onLongPress: (e: React.TouchEvent) => void) {
      let timer: ReturnType<typeof setTimeout> | null = null;
      let moved = false;
      let startX = 0,
        startY = 0;
      return {
        onTouchStart: (e: React.TouchEvent) => {
          moved = false;
          startX = e.touches[0].clientX;
          startY = e.touches[0].clientY;
          timer = setTimeout(() => {
            if (!moved) onLongPress(e);
          }, 550);
        },
        onTouchMove: (e: React.TouchEvent) => {
          const dx = Math.abs(e.touches[0].clientX - startX);
          const dy = Math.abs(e.touches[0].clientY - startY);
          if (dx > 10 || dy > 10) moved = true;
        },
        onTouchEnd: () => {
          if (timer) clearTimeout(timer);
        },
      };
    }

    function toggleExtracted() {
      if (!extractMenu) return;
      const { fdi } = extractMenu;
      patchTooth(fdi, { extracted: !teeth[fdi].extracted });
      setExtractMenu(null);
    }

    function handleGapClick(gapId: string) {
      if (mode === "stripping") {
        setStripCounts((prev) => ({ ...prev, [gapId]: (prev[gapId] ?? 0) + 1 }));
      } else if (mode === "miniscrew") {
        setMiniscrews((prev) => ({ ...prev, [gapId]: !prev[gapId] }));
      }
    }

    function backgroundClick() {
      if (mode !== "none") setMode("none");
      setSelectedTooth(null);
    }

    function bracketColor(status: BracketStatus) {
      if (status === "bonded") return "bg-blue-500 border-blue-700";
      if (status === "broken") return "bg-red-500 border-red-700";
      return "bg-[#e8dcc8] border-[#c9b892]";
    }

    function renderRow(row: ToothMeta[], gaps: { id: string; a: number; b: number }[], arch: "upper" | "lower") {
      return (
        <div className="relative flex justify-center">
          {row.map((t, idx) => {
            const state = teeth[t.fdi];
            const isMidline = idx === 7; // between tooth 8 and tooth 9 in each row = midline
            return (
              <div key={t.fdi} className="flex items-stretch">
                <div
                  className={`relative z-0 flex flex-col items-center px-0 cursor-pointer select-none ${
                    selectedTooth === t.fdi ? "ring-2 ring-primary rounded" : ""
                  }`}
                  style={{ opacity: state.extracted ? 0.25 : 1 }}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedTooth(t.fdi);
                  }}
                  onContextMenu={(e) => {
                    e.stopPropagation();
                    handleToothContextMenu(e, t);
                  }}
                  {...useLongPress(() => {
                    setExtractMenu({ fdi: t.fdi, x: 200, y: 200 });
                  })}
                  title={`FDI ${t.fdi}`}
                >
                  {/* Real tooth photo — upper arch renders crown-down, lower arch crown-up,
                      matching the natural look of each arch. */}
                  <img
                    src={`/ortho-v2/teeth/${t.image}`}
                    alt={`FDI ${t.fdi}`}
                    className="h-20 sm:h-28 w-auto object-contain pointer-events-none"
                    style={t.flip ? { transform: "scaleX(-1)" } : undefined}
                    draggable={false}
                  />

                  {/* Rebonding counter — mid-root */}
                  {state.rebondCount > 0 && (
                    <span
                      className="absolute z-10 text-[9px] leading-none bg-white border border-border rounded-full w-4 h-4 flex items-center justify-center"
                      style={{ [arch === "upper" ? "top" : "bottom"]: "38%", left: "50%", transform: "translateX(-50%)" } as React.CSSProperties}
                    >
                      {state.rebondCount}
                    </span>
                  )}

                  {/* Bracket box */}
                  <button
                    type="button"
                    onDoubleClick={(e) => {
                      e.stopPropagation();
                      handleBracketDoubleClick(t);
                    }}
                    className={`absolute z-10 w-3.5 h-3.5 sm:w-4 sm:h-4 border ${bracketColor(state.bracket)}`}
                    style={
                      arch === "upper"
                        ? { bottom: "30%", left: "50%", transform: "translateX(-50%)" }
                        : { top: "17%", left: "50%", transform: "translateX(-50%)" }
                    }
                    title={
                      state.bracket === "bonded"
                        ? "Bracket bonded — double-click to record a break"
                        : state.bracket === "broken"
                        ? `Broken ${state.debondDate ? "(" + state.debondDate + ")" : ""} — double-click to rebond`
                        : "No bracket"
                    }
                  />

                  {/* Debond date */}
                  {state.bracket === "broken" && state.debondDate && (
                    <span
                      className="absolute z-10 text-[8px] leading-none bg-red-50 text-red-700 border border-red-300 rounded px-0.5 whitespace-nowrap"
                      style={{ [arch === "upper" ? "bottom" : "top"]: "2%", left: "50%", transform: "translateX(-50%)" } as React.CSSProperties}
                    >
                      {state.debondDate}
                    </span>
                  )}

                  <span className="text-[9px] text-muted mt-0.5">{t.fdi}</span>
                </div>

                {/* Gap to the next tooth — stripping/miniscrew target */}
                {idx < row.length - 1 && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleGapClick(gaps[idx].id);
                    }}
                    className={`w-2.5 sm:w-3 relative z-10 ${isMidline ? "mx-0.5" : ""}`}
                    title={mode === "none" ? undefined : "Click to record"}
                  >
                    {mode === "stripping" && <span className="absolute inset-y-2 left-1/2 w-px bg-amber-500" />}
                    {mode === "miniscrew" && (
                      <span
                        className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2.5 h-2.5 rounded-full border ${
                          miniscrews[gaps[idx].id] ? "bg-blue-500 border-blue-700" : "border-muted"
                        }`}
                      />
                    )}
                    {mode !== "stripping" && stripCounts[gaps[idx].id] > 0 && (
                      <span className="absolute inset-y-2 left-1/2 w-px bg-amber-300" />
                    )}
                    {mode !== "miniscrew" && miniscrews[gaps[idx].id] && (
                      <span className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2.5 h-2.5 rounded-full bg-blue-500 border border-blue-700" />
                    )}
                    {stripCounts[gaps[idx].id] > 0 && (
                      <span className="absolute z-20 -top-1.5 left-1/2 -translate-x-1/2 min-w-[15px] h-[15px] px-0.5 flex items-center justify-center text-[10px] font-semibold leading-none bg-white text-foreground border border-amber-400 rounded-full shadow-sm">
                        {stripCounts[gaps[idx].id]}
                      </span>
                    )}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      );
    }

    return (
      <div className="space-y-4" onClick={backgroundClick}>
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-4 text-xs text-muted flex-wrap">
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 inline-block bg-[#e8dcc8] border border-[#c9b892]" /> No bracket
            </span>
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 inline-block bg-blue-500 border border-blue-700" /> Bonded
            </span>
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 inline-block bg-red-500 border border-red-700" /> Broken
            </span>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setMode((m) => (m === "stripping" ? "none" : "stripping"));
              }}
              className={`px-3 py-1.5 rounded-md border text-xs ${mode === "stripping" ? "bg-primary text-white border-primary" : "border-border hover:bg-primary-soft"}`}
            >
              Stripping
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setMode((m) => (m === "miniscrew" ? "none" : "miniscrew"));
              }}
              className={`px-3 py-1.5 rounded-md border text-xs ${mode === "miniscrew" ? "bg-primary text-white border-primary" : "border-border hover:bg-primary-soft"}`}
            >
              Miniscrew
            </button>
          </div>
        </div>

        <p className="text-xs text-muted">
          Double-click a bracket box = record a break / rebond. Right-click (or long-press on mobile) anywhere else on the tooth = extraction.
        </p>

        <div className="overflow-x-auto py-2">
          <div className="min-w-[680px] space-y-3">
            {renderRow(UPPER_ROW, UPPER_GAPS, "upper")}
            <div className="border-t border-dashed border-border" />
            {renderRow(LOWER_ROW, LOWER_GAPS, "lower")}
          </div>
        </div>

        {selectedTooth != null && (
          <div className="card-3d rounded-lg p-3 text-sm space-y-2" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <span className="font-semibold">Tooth FDI {selectedTooth} details</span>
              <button type="button" className="text-xs text-muted hover:underline" onClick={() => setSelectedTooth(null)}>
                Close
              </button>
            </div>
            <textarea
              value={teeth[selectedTooth].comment}
              onChange={(e) => patchTooth(selectedTooth, { comment: e.target.value })}
              placeholder="Note on this tooth..."
              rows={2}
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-xs"
            />
          </div>
        )}

        {/* Rebonding popup */}
        {rebondPrompt && (
          <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/30" onClick={() => setRebondPrompt(null)}>
            <div className="card-3d rounded-lg p-4 space-y-3 w-64" onClick={(e) => e.stopPropagation()}>
              <div className="text-sm font-semibold text-center">Rebond tooth {rebondPrompt.fdi}</div>
              <div className="flex gap-2 justify-center">
                <button type="button" onClick={() => confirmRebond("new")} className="btn-3d-primary px-3 py-1.5 rounded-md text-xs">
                  New bracket
                </button>
                <button
                  type="button"
                  onClick={() => confirmRebond("old")}
                  className="px-3 py-1.5 rounded-md border border-border text-xs hover:bg-primary-soft"
                >
                  Old bracket
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Extraction context menu */}
        {extractMenu && (
          <div className="fixed inset-0 z-40" onClick={() => setExtractMenu(null)}>
            <div
              className="absolute card-3d rounded-md shadow-lg py-1 text-sm"
              style={{ left: extractMenu.x, top: extractMenu.y }}
              onClick={(e) => e.stopPropagation()}
            >
              <button type="button" onClick={toggleExtracted} className="w-full text-left px-3 py-1.5 hover:bg-primary-soft whitespace-nowrap">
                {teeth[extractMenu.fdi].extracted ? "Undo extraction" : "Extracted"}
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }
);

export default InteractiveToothChart;
