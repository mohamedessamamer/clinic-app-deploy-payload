"use client";

// ===================================================================
// شارت التقويم v2 — الـ"Interactive chart" (بروتوتايب معزول، mock data بس)
// ===================================================================
// تفاصيل السلوك كاملة في مشروع "Clinic mangment system" على claude.ai —
// ملف orthodontic-chart-v2-interactive-chart-spec.md. ملخص سريع:
//
// - أسنان بصور فوتوغرافية حقيقية (من الباوربوينت اللي بعته المستخدم)، ترقيم FDI.
// - مربع البراكت: بيج = مفيش براكت، أزرق = متركب، أحمر = اتكسر.
// - دبل-كليك (أو long-press على موبايل) على مربع أزرق → تأكيد كسر → أحمر + تاريخ.
// - دبل-كليك على مربع أحمر → اختيار "جديد" أو "قديم" → يترّكب (أزرق) + عداد
//   ريبوندينج يزيد (الجديد بس بيخصم من "المخزون" الوهمي هنا).
// - right-click (أو long-press) على أي حتة في السن برة مربع البراكت → "Extracted".
// - وضعي Stripping/Miniscrew: زرار يفعّل، تظهر خطوط/دوائر بين كل سنتين متجاورتين،
//   كليك يسجّل، كليك في أي حتة تانية يقفل الوضع (بس اللي اتسجل فعلاً يفضل باين).
//
// ده بروتوتايب بمنطق محلي (useState) بس — مفيش أي اتصال بالداتابيز الحقيقية.

import { useState } from "react";
import { UPPER_ROW, LOWER_ROW, gapsFor, type ToothMeta } from "@/lib/prototype/fdi-teeth";

type BracketStatus = "none" | "bonded" | "broken";

interface ToothState {
  bracket: BracketStatus;
  debondDate: string | null;
  rebondCount: number;
  extracted: boolean;
  comment: string;
}

type ToothStateMap = Record<number, ToothState>;
type GapMode = "none" | "stripping" | "miniscrew";

function emptyToothState(): ToothState {
  return { bracket: "none", debondDate: null, rebondCount: 0, extracted: false, comment: "" };
}

function todayStr(): string {
  const d = new Date();
  return `${String(d.getDate()).padStart(2, "0")}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getFullYear()).slice(2)}`;
}

const UPPER_GAPS = gapsFor(UPPER_ROW);
const LOWER_GAPS = gapsFor(LOWER_ROW);

export interface MockInventoryLog {
  label: string;
  qty: number;
}

export default function InteractiveToothChart({
  onInventoryDeduct,
}: {
  onInventoryDeduct?: (log: MockInventoryLog) => void;
}) {
  const [teeth, setTeeth] = useState<ToothStateMap>(() => {
    const m: ToothStateMap = {};
    [...UPPER_ROW, ...LOWER_ROW].forEach((t) => (m[t.fdi] = emptyToothState()));
    return m;
  });
  const [stripCounts, setStripCounts] = useState<Record<string, number>>({});
  const [miniscrews, setMiniscrews] = useState<Record<string, boolean>>({});
  const [mode, setMode] = useState<GapMode>("none");
  const [rebondPrompt, setRebondPrompt] = useState<{ fdi: number; x: number; y: number } | null>(null);
  const [extractMenu, setExtractMenu] = useState<{ fdi: number; x: number; y: number } | null>(null);
  const [commentTooth, setCommentTooth] = useState<number | null>(null);
  const [selectedTooth, setSelectedTooth] = useState<number | null>(null);

  function patchTooth(fdi: number, patch: Partial<ToothState>) {
    setTeeth((prev) => ({ ...prev, [fdi]: { ...prev[fdi], ...patch } }));
  }

  function handleBracketDoubleClick(t: ToothMeta) {
    const state = teeth[t.fdi];
    if (state.bracket === "bonded") {
      if (window.confirm(`Bracket ${t.fdi} debonded?`)) {
        patchTooth(t.fdi, { bracket: "broken", debondDate: todayStr() });
      }
    } else if (state.bracket === "broken") {
      setRebondPrompt({ fdi: t.fdi, x: 0, y: 0 });
    } else {
      // مفيش براكت متركب أصلًا (بيج) — دبل كليك هنا بيركّبها كأول تركيب (زرار سريع للتجربة بس)
      if (window.confirm(`تركيب براكت جديد على السن ${t.fdi}؟`)) {
        patchTooth(t.fdi, { bracket: "bonded" });
        onInventoryDeduct?.({ label: `براكت (سن ${t.fdi})`, qty: 1 });
      }
    }
  }

  function confirmRebond(kind: "new" | "old") {
    if (!rebondPrompt) return;
    const { fdi } = rebondPrompt;
    setTeeth((prev) => ({
      ...prev,
      [fdi]: { ...prev[fdi], bracket: "bonded", debondDate: null, rebondCount: prev[fdi].rebondCount + 1 },
    }));
    if (kind === "new") onInventoryDeduct?.({ label: `براكت جديد (سن ${fdi})`, qty: 1 });
    setRebondPrompt(null);
  }

  function handleToothContextMenu(e: React.MouseEvent, t: ToothMeta) {
    e.preventDefault();
    setExtractMenu({ fdi: t.fdi, x: e.clientX, y: e.clientY });
  }

  // long-press للموبايل/التابلت (مكافئ right-click) — نفس النمط المستخدم بالفعل
  // في الجدول المركزي (CentralSchedule.tsx) لباقي القوائم بالكليك اليمين.
  function useLongPress(onLongPress: (e: React.TouchEvent) => void) {
    let timer: ReturnType<typeof setTimeout> | null = null;
    let moved = false;
    let startX = 0,
      startY = 0;
    return {
      onTouchStart: (e: React.TouchEvent) => {
        moved = false;
        startX = e.touches[0].clientX;
        startY = e.touches[0].clientY;
        timer = setTimeout(() => {
          if (!moved) onLongPress(e);
        }, 550);
      },
      onTouchMove: (e: React.TouchEvent) => {
        const dx = Math.abs(e.touches[0].clientX - startX);
        const dy = Math.abs(e.touches[0].clientY - startY);
        if (dx > 10 || dy > 10) moved = true;
      },
      onTouchEnd: () => {
        if (timer) clearTimeout(timer);
      },
    };
  }

  function toggleExtracted() {
    if (!extractMenu) return;
    const { fdi } = extractMenu;
    patchTooth(fdi, { extracted: !teeth[fdi].extracted });
    setExtractMenu(null);
  }

  function handleGapClick(gapId: string) {
    if (mode === "stripping") {
      setStripCounts((prev) => ({ ...prev, [gapId]: (prev[gapId] ?? 0) + 1 }));
    } else if (mode === "miniscrew") {
      setMiniscrews((prev) => ({ ...prev, [gapId]: !prev[gapId] }));
    }
  }

  function backgroundClick() {
    if (mode !== "none") setMode("none");
    setSelectedTooth(null);
  }

  function bracketColor(status: BracketStatus) {
    if (status === "bonded") return "bg-blue-500 border-blue-700";
    if (status === "broken") return "bg-red-500 border-red-700";
    return "bg-[#e8dcc8] border-[#c9b892]";
  }

  function renderRow(row: ToothMeta[], gaps: { id: string; a: number; b: number }[], arch: "upper" | "lower") {
    return (
      <div className="relative flex justify-center" dir="ltr">
        {row.map((t, idx) => {
          const state = teeth[t.fdi];
          const isMidline = idx === 7; // بين السن 8 والسن 9 في كل صف = خط النص
          return (
            <div key={t.fdi} className="flex items-stretch">
              <div
                className={`relative flex flex-col items-center px-0.5 cursor-pointer select-none ${
                  selectedTooth === t.fdi ? "ring-2 ring-primary rounded" : ""
                }`}
                style={{ opacity: state.extracted ? 0.25 : 1 }}
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedTooth(t.fdi);
                }}
                onContextMenu={(e) => {
                  e.stopPropagation();
                  handleToothContextMenu(e, t);
                }}
                {...useLongPress(() => {
                  setExtractMenu({ fdi: t.fdi, x: 200, y: 200 });
                })}
                title={`FDI ${t.fdi}`}
              >
                {/* الصورة الحقيقية للسن — الفك العلوي بيبان معكوس رأسيًا (التاج تحت)،
                    السفلي التاج فوق، بالظبط زي الترتيب الطبيعي للفكين */}
                <img
                  src={`/ortho-v2/teeth/${t.image}`}
                  alt={`FDI ${t.fdi}`}
                  className="h-16 sm:h-20 w-auto object-contain pointer-events-none"
                  style={t.flip ? { transform: "scaleX(-1)" } : undefined}
                  draggable={false}
                />

                {/* عداد الريبوندينج — منتصف الجذر */}
                {state.rebondCount > 0 && (
                  <span
                    className="absolute text-[9px] leading-none bg-white border border-border rounded-full w-4 h-4 flex items-center justify-center"
                    style={{ [arch === "upper" ? "top" : "bottom"]: "38%", left: "50%", transform: "translateX(-50%)" } as React.CSSProperties}
                  >
                    {state.rebondCount}
                  </span>
                )}

                {/* مربع البراكت */}
                <button
                  type="button"
                  onDoubleClick={(e) => {
                    e.stopPropagation();
                    handleBracketDoubleClick(t);
                  }}
                  className={`absolute w-3 h-3 sm:w-3.5 sm:h-3.5 border ${bracketColor(state.bracket)}`}
                  style={{ [arch === "upper" ? "bottom" : "top"]: "18%", left: "50%", transform: "translateX(-50%)" } as React.CSSProperties}
                  title={
                    state.bracket === "bonded"
                      ? "براكت متركّب — دبل كليك لتسجيل كسر"
                      : state.bracket === "broken"
                      ? `اتكسرت ${state.debondDate ? "(" + state.debondDate + ")" : ""} — دبل كليك لإعادة التركيب`
                      : "مفيش براكت"
                  }
                />

                {/* تاريخ الكسر */}
                {state.bracket === "broken" && state.debondDate && (
                  <span
                    className="absolute text-[8px] leading-none bg-red-50 text-red-700 border border-red-300 rounded px-0.5 whitespace-nowrap"
                    style={{ [arch === "upper" ? "bottom" : "top"]: "2%", left: "50%", transform: "translateX(-50%)" } as React.CSSProperties}
                  >
                    {state.debondDate}
                  </span>
                )}

                <span className="text-[9px] text-muted mt-0.5">{t.fdi}</span>
              </div>

              {/* الفجوة بين السن دي واللي بعدها — مربع stripping/miniscrew */}
              {idx < row.length - 1 && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleGapClick(gaps[idx].id);
                  }}
                  className={`w-2 sm:w-2.5 relative ${isMidline ? "mx-0.5" : ""}`}
                  title={mode === "none" ? undefined : "دوس لتسجيل"}
                >
                  {mode === "stripping" && <span className="absolute inset-y-2 left-1/2 w-px bg-amber-500" />}
                  {mode === "miniscrew" && (
                    <span
                      className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2.5 h-2.5 rounded-full border ${
                        miniscrews[gaps[idx].id] ? "bg-blue-500 border-blue-700" : "border-muted"
                      }`}
                    />
                  )}
                  {mode !== "stripping" && stripCounts[gaps[idx].id] > 0 && (
                    <span className="absolute inset-y-2 left-1/2 w-px bg-amber-300" />
                  )}
                  {mode !== "miniscrew" && miniscrews[gaps[idx].id] && (
                    <span className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2.5 h-2.5 rounded-full bg-blue-500 border border-blue-700" />
                  )}
                  {stripCounts[gaps[idx].id] > 0 && (
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 text-[8px] bg-white border border-border rounded px-0.5 leading-none">
                      {stripCounts[gaps[idx].id]}
                    </span>
                  )}
                </button>
              )}
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <div className="space-y-4" dir="rtl" onClick={backgroundClick}>
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-4 text-xs text-muted flex-wrap">
          <span className="flex items-center gap-1">
            <span className="w-3 h-3 inline-block bg-[#e8dcc8] border border-[#c9b892]" /> مفيش براكت
          </span>
          <span className="flex items-center gap-1">
            <span className="w-3 h-3 inline-block bg-blue-500 border border-blue-700" /> متركّبة
          </span>
          <span className="flex items-center gap-1">
            <span className="w-3 h-3 inline-block bg-red-500 border border-red-700" /> اتكسرت
          </span>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setMode((m) => (m === "stripping" ? "none" : "stripping"));
            }}
            className={`px-3 py-1.5 rounded-md border text-xs ${mode === "stripping" ? "bg-primary text-white border-primary" : "border-border hover:bg-primary-soft"}`}
          >
            Stripping
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setMode((m) => (m === "miniscrew" ? "none" : "miniscrew"));
            }}
            className={`px-3 py-1.5 rounded-md border text-xs ${mode === "miniscrew" ? "bg-primary text-white border-primary" : "border-border hover:bg-primary-soft"}`}
          >
            Miniscrew
          </button>
        </div>
      </div>

      <p className="text-xs text-muted">
        دبل كليك على مربع براكت = تسجيل كسر/إعادة تركيب. right-click (أو دوسة طويلة على الموبايل) على أي حتة تانية في السن = خلع.
      </p>

      <div className="overflow-x-auto py-2">
        <div className="min-w-[560px] space-y-3">
          {renderRow(UPPER_ROW, UPPER_GAPS, "upper")}
          <div className="border-t border-dashed border-border" />
          {renderRow(LOWER_ROW, LOWER_GAPS, "lower")}
        </div>
      </div>

      {selectedTooth != null && (
        <div className="card-3d rounded-lg p-3 text-sm space-y-2" onClick={(e) => e.stopPropagation()}>
          <div className="flex items-center justify-between">
            <span className="font-semibold">تفاصيل السن FDI {selectedTooth}</span>
            <button type="button" className="text-xs text-muted hover:underline" onClick={() => setSelectedTooth(null)}>
              إغلاق
            </button>
          </div>
          <textarea
            value={teeth[selectedTooth].comment}
            onChange={(e) => patchTooth(selectedTooth, { comment: e.target.value })}
            placeholder="ملاحظة على السن ده..."
            rows={2}
            className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-xs"
          />
        </div>
      )}

      {/* Rebonding popup */}
      {rebondPrompt && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/30" onClick={() => setRebondPrompt(null)}>
          <div className="card-3d rounded-lg p-4 space-y-3 w-64" onClick={(e) => e.stopPropagation()}>
            <div className="text-sm font-semibold text-center">إعادة تركيب السن {rebondPrompt.fdi}</div>
            <div className="flex gap-2 justify-center">
              <button type="button" onClick={() => confirmRebond("new")} className="btn-3d-primary px-3 py-1.5 rounded-md text-xs">
                New bracket
              </button>
              <button
                type="button"
                onClick={() => confirmRebond("old")}
                className="px-3 py-1.5 rounded-md border border-border text-xs hover:bg-primary-soft"
              >
                Old bracket
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Extraction context menu */}
      {extractMenu && (
        <div className="fixed inset-0 z-40" onClick={() => setExtractMenu(null)}>
          <div
            className="absolute card-3d rounded-md shadow-lg py-1 text-sm"
            style={{ left: extractMenu.x, top: extractMenu.y }}
            onClick={(e) => e.stopPropagation()}
          >
            <button type="button" onClick={toggleExtracted} className="w-full text-right px-3 py-1.5 hover:bg-primary-soft whitespace-nowrap">
              {teeth[extractMenu.fdi].extracted ? "إلغاء الخلع" : "Extracted"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
