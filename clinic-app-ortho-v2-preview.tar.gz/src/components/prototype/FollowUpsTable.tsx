"use client";

// ===================================================================
// Orthodontic chart v2 — "Follow ups" table (isolated prototype, mock data only)
// ===================================================================
// 2026-08-27 rebuild: re-checked literally against Canva page 2's current
// content (design_id: DAHTZKEWWQI) instead of the earlier textual spec —
// Procedures = "U [size][type]  L [size][type]" on one line, then ONE shared
// free-text note below (not two separate U/L notes, per the user's feedback
// that two boxes felt bulky), Doctor is a per-row dropdown (Canva shows the
// privileged "pick any doctor" view — the assistant-only static-name case
// stays a deferred permission decision, see orthodontic-chart-v2-canva-redesign.md).
//
// New fields added per the user's feedback (a real visit doesn't always use
// these, so all three stay optional/blank by default):
// - Elastics: dispensed this visit? if yes, pick a size (3/16, 1/8, 5/16).
// - O-tie color (ligature ties).
// - Power chain: how many links used, if any.
// Every wire/elastics/O-tie/power-chain selection deducts from the shared
// mock inventory via onInventoryDeduct (the parent renders the actual
// deletable ledger — see the "Inventory list" link under Chief Complaint in
// OrthoChartV2.tsx).
//
// "+ New visit" is left always-enabled in this preview (no once-per-day gate)
// so the user can freely add several visits to review the shape — the real
// system will re-add the "only if no visit today yet" rule from the spec.

import { useState } from "react";
import type { MockInventoryLog } from "./InteractiveToothChart";

const MOCK_SERVICES = ["Follow up", "Bonding Upper", "Bonding Lower", "Debonding", "Retainer delivery", "Consultation"];
const WIRE_SIZES = ["12", "14", "16", "16x22", "17x25", "19x25"];
const WIRE_TYPES = ["NiTi", "SS", "TMA"];
const ELASTIC_SIZES = ["3/16", "1/8", "5/16"];
const OTIE_COLORS = ["Clear", "Silver", "Blue", "Red", "Green", "Yellow", "Pink", "Purple", "Orange", "Black", "White", "Gold"];
const MOCK_DOCTORS = ["Dr. Mohamed", "Dr. Kareem", "Dr. Gouda", "Dr. Nassar", "Dr. Amer"];

interface FollowUpRow {
  id: string;
  date: string;
  service: string;
  upperSize: string;
  upperType: string;
  lowerSize: string;
  lowerType: string;
  note: string;
  elasticsDispensed: boolean;
  elasticsSize: string;
  otieColor: string;
  powerChainQty: string;
  doctor: string;
}

function todayStr(): string {
  const d = new Date();
  return `${String(d.getDate()).padStart(2, "0")}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getFullYear()).slice(2)}`;
}

function makeEmptyRow(doctor: string): FollowUpRow {
  return {
    id: `${Date.now()}-${Math.random()}`,
    date: "",
    service: "",
    upperSize: "",
    upperType: "",
    lowerSize: "",
    lowerType: "",
    note: "",
    elasticsDispensed: false,
    elasticsSize: "",
    otieColor: "",
    powerChainQty: "",
    doctor,
  };
}

function AutoGrowTextarea({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <textarea
      value={value}
      onChange={(e) => {
        onChange(e.target.value);
        e.target.style.height = "auto";
        e.target.style.height = `${e.target.scrollHeight}px`;
      }}
      placeholder={placeholder}
      rows={1}
      className="w-full min-w-0 resize-none overflow-hidden rounded-md border border-border bg-background px-2 py-1 text-xs"
    />
  );
}

function Dropdown({
  value,
  onChange,
  options,
  placeholder = "—",
  className = "",
}: {
  value: string;
  onChange: (v: string) => void;
  options: string[];
  placeholder?: string;
  className?: string;
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className={`rounded-md border border-border bg-background px-1.5 py-1 text-xs ${className}`}
    >
      <option value="">{placeholder}</option>
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  );
}

export default function FollowUpsTable({
  doctorName = "Dr. Mohamed",
  onBulkBond,
  onInventoryDeduct,
}: {
  doctorName?: string;
  onBulkBond?: (arch: "upper" | "lower") => void;
  onInventoryDeduct?: (log: MockInventoryLog) => void;
}) {
  const [rows, setRows] = useState<FollowUpRow[]>([]);

  function addVisit() {
    setRows((prev) => [makeEmptyRow(doctorName), ...prev]);
  }

  function patchRow(id: string, patch: Partial<FollowUpRow>) {
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  }

  function setToday(id: string) {
    patchRow(id, { date: todayStr() });
  }

  function onServiceChange(id: string, service: string) {
    patchRow(id, { service });
    if (service === "Bonding Upper") onBulkBond?.("upper");
    if (service === "Bonding Lower") onBulkBond?.("lower");
  }

  function onWireChange(id: string, arch: "Upper" | "Lower", patch: Partial<FollowUpRow>, size: string, type: string) {
    patchRow(id, patch);
    if (size && type) onInventoryDeduct?.({ label: `Wire ${size} ${type} (${arch})`, qty: 1 });
  }

  function onElasticsSizeChange(id: string, dispensed: boolean, size: string) {
    patchRow(id, { elasticsSize: size });
    if (dispensed && size) onInventoryDeduct?.({ label: `Elastics ${size}`, qty: 1 });
  }

  function onOtieChange(id: string, color: string) {
    patchRow(id, { otieColor: color });
    if (color) onInventoryDeduct?.({ label: `O-ties — ${color}`, qty: 1 });
  }

  function onPowerChainBlur(id: string, qty: string) {
    const n = parseInt(qty, 10);
    if (n > 0) onInventoryDeduct?.({ label: "Power chain links", qty: n });
  }

  return (
    <div className="card-3d rounded-xl p-5 space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h3 className="font-bold">Follow ups</h3>
        <button
          type="button"
          onClick={addVisit}
          className="text-xs px-3 py-1.5 rounded-md border border-dashed border-border hover:bg-primary-soft text-muted"
        >
          + New visit
        </button>
      </div>

      {rows.length === 0 && <p className="text-xs text-muted">No visits recorded yet.</p>}

      <div className="space-y-3">
        {rows.map((r) => (
          <div key={r.id} className="rounded-lg border border-border p-3 space-y-2">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-3 flex-wrap">
                <button
                  type="button"
                  onClick={() => setToday(r.id)}
                  className="flex items-center gap-1.5 text-xs px-2 py-1 rounded-md border border-border hover:bg-primary-soft"
                  title="Set to today"
                >
                  📅 {r.date || "Set date"}
                </button>
                <Dropdown value={r.service} onChange={(v) => onServiceChange(r.id, v)} options={MOCK_SERVICES} placeholder="Service" />
              </div>
              <Dropdown value={r.doctor} onChange={(v) => patchRow(r.id, { doctor: v })} options={MOCK_DOCTORS} placeholder="Doctor" />
            </div>

            {/* Procedures — U/L wire size+type on one line, per Canva */}
            <div className="flex items-center gap-3 flex-wrap text-xs">
              <div className="flex items-center gap-1.5">
                <span className="font-semibold text-muted w-4 shrink-0">U</span>
                <Dropdown value={r.upperSize} onChange={(v) => onWireChange(r.id, "Upper", { upperSize: v }, v, r.upperType)} options={WIRE_SIZES} placeholder="Size" />
                <Dropdown value={r.upperType} onChange={(v) => onWireChange(r.id, "Upper", { upperType: v }, r.upperSize, v)} options={WIRE_TYPES} placeholder="Type" />
              </div>
              <div className="flex items-center gap-1.5">
                <span className="font-semibold text-muted w-4 shrink-0">L</span>
                <Dropdown value={r.lowerSize} onChange={(v) => onWireChange(r.id, "Lower", { lowerSize: v }, v, r.lowerType)} options={WIRE_SIZES} placeholder="Size" />
                <Dropdown value={r.lowerType} onChange={(v) => onWireChange(r.id, "Lower", { lowerType: v }, r.lowerSize, v)} options={WIRE_TYPES} placeholder="Type" />
              </div>
            </div>

            {/* One shared free-text note, per the user's feedback (was two boxes) */}
            <AutoGrowTextarea value={r.note} onChange={(v) => patchRow(r.id, { note: v })} placeholder="e.g.: retraction 13 & 23" />

            {/* Elastics / O-tie / Power chain — all optional, not used every visit */}
            <div className="flex items-center gap-4 flex-wrap text-xs pt-1 border-t border-border">
              <label className="flex items-center gap-1.5">
                <input
                  type="checkbox"
                  checked={r.elasticsDispensed}
                  onChange={(e) => patchRow(r.id, { elasticsDispensed: e.target.checked, elasticsSize: e.target.checked ? r.elasticsSize : "" })}
                />
                Elastics dispensed
                {r.elasticsDispensed && (
                  <Dropdown value={r.elasticsSize} onChange={(v) => onElasticsSizeChange(r.id, r.elasticsDispensed, v)} options={ELASTIC_SIZES} placeholder="Size" />
                )}
              </label>
              <label className="flex items-center gap-1.5">
                O-tie color
                <Dropdown value={r.otieColor} onChange={(v) => onOtieChange(r.id, v)} options={OTIE_COLORS} placeholder="—" />
              </label>
              <label className="flex items-center gap-1.5">
                Power chain
                <input
                  type="number"
                  min={0}
                  value={r.powerChainQty}
                  onChange={(e) => patchRow(r.id, { powerChainQty: e.target.value })}
                  onBlur={(e) => onPowerChainBlur(r.id, e.target.value)}
                  placeholder="0"
                  className="w-14 rounded-md border border-border bg-background px-1.5 py-1 text-xs"
                />
              </label>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
