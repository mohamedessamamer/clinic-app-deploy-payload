"use client";

// ===================================================================
// Orthodontic chart v2 — "Follow ups" table (isolated prototype, mock data only)
// ===================================================================
// Full spec: project "Clinic mangment system" on claude.ai —
// orthodontic-chart-v2-canva-redesign.md ("جدول Follow ups — صفحة 2"). Summary:
//
// - Columns: Date | Service | Procedures (Upper & Lower wire + free-text note
//   each, wire deducts from inventory) | Doctor.
// - Fixed position right below the Interactive chart, regardless of the
//   Interactive/Diagnostic toggle above it.
// - A new empty row is offered only while there's no visit recorded for today
//   yet (mocked here as an explicit "+ New visit" button, disabled once
//   today's row exists — the real system auto-detects this from saved data).
// - Service list is mocked to the "Orthodontics" category (in the real system
//   this reuses the existing services.category filter, already built).
// - Selecting "Bonding Upper"/"Bonding Lower" as the service auto-bonds the
//   whole arch (except the 2nd/3rd molars) on the Interactive chart above,
//   via the onBulkBond callback.
// - The real system needs no horizontal scroll on any screen — this prototype
//   stacks each visit as a card instead of a literal wide table row so it
//   never needs one either.
// - Doctor column here always shows the mock signed-in doctor's name (the
//   "assistant, no permission" case). The privileged doctor-picker dropdown
//   is deferred (registered decision, not built yet) — see the spec doc.

import { useState } from "react";

const MOCK_ORTHO_SERVICES = ["Bonding Upper", "Bonding Lower", "Adjustment visit", "Wire change", "Debonding", "Retainer delivery", "Consultation"];

const WIRE_OPTIONS = ["0.012 NiTi", "0.014 NiTi", "0.016 NiTi", "0.016×0.022 NiTi", "0.017×0.025 NiTi", "0.019×0.025 SS"];

interface FollowUpRow {
  id: string;
  date: string;
  service: string;
  upperWire: string;
  upperNote: string;
  lowerWire: string;
  lowerNote: string;
}

function todayStr(): string {
  const d = new Date();
  return `${String(d.getDate()).padStart(2, "0")}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getFullYear()).slice(2)}`;
}

function makeEmptyRow(): FollowUpRow {
  return { id: `${Date.now()}-${Math.random()}`, date: "", service: "", upperWire: "", upperNote: "", lowerWire: "", lowerNote: "" };
}

function AutoGrowTextarea({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <textarea
      value={value}
      onChange={(e) => {
        onChange(e.target.value);
        e.target.style.height = "auto";
        e.target.style.height = `${e.target.scrollHeight}px`;
      }}
      placeholder={placeholder}
      rows={1}
      className="w-full min-w-0 flex-1 resize-none overflow-hidden rounded-md border border-border bg-background px-2 py-1 text-xs"
    />
  );
}

function Dropdown({
  value,
  onChange,
  options,
  placeholder = "—",
  className = "",
}: {
  value: string;
  onChange: (v: string) => void;
  options: string[];
  placeholder?: string;
  className?: string;
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className={`rounded-md border border-border bg-background px-1.5 py-1 text-xs ${className}`}
    >
      <option value="">{placeholder}</option>
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  );
}

export default function FollowUpsTable({
  doctorName = "Dr. Mohamed",
  onBulkBond,
}: {
  doctorName?: string;
  onBulkBond?: (arch: "upper" | "lower") => void;
}) {
  const [rows, setRows] = useState<FollowUpRow[]>([]);

  const hasTodayRow = rows.length > 0 && rows[0].date === todayStr();

  function addVisit() {
    if (hasTodayRow) return;
    setRows((prev) => [makeEmptyRow(), ...prev]);
  }

  function patchRow(id: string, patch: Partial<FollowUpRow>) {
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  }

  function setToday(id: string) {
    patchRow(id, { date: todayStr() });
  }

  function onServiceChange(id: string, service: string) {
    patchRow(id, { service });
    if (service === "Bonding Upper") onBulkBond?.("upper");
    if (service === "Bonding Lower") onBulkBond?.("lower");
  }

  return (
    <div className="card-3d rounded-xl p-5 space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h3 className="font-bold">Follow ups</h3>
        <button
          type="button"
          onClick={addVisit}
          disabled={hasTodayRow}
          className="text-xs px-3 py-1.5 rounded-md border border-dashed border-border hover:bg-primary-soft text-muted disabled:opacity-40 disabled:cursor-not-allowed"
          title={hasTodayRow ? "There's already a visit recorded for today" : "Add today's visit"}
        >
          + New visit
        </button>
      </div>

      {rows.length === 0 && <p className="text-xs text-muted">No visits recorded yet.</p>}

      <div className="space-y-3">
        {rows.map((r) => (
          <div key={r.id} className="rounded-lg border border-border p-3 space-y-2">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-3 flex-wrap">
                <button
                  type="button"
                  onClick={() => setToday(r.id)}
                  className="flex items-center gap-1.5 text-xs px-2 py-1 rounded-md border border-border hover:bg-primary-soft"
                  title="Set to today"
                >
                  📅 {r.date || "Set date"}
                </button>
                <Dropdown value={r.service} onChange={(v) => onServiceChange(r.id, v)} options={MOCK_ORTHO_SERVICES} placeholder="Service" />
              </div>
              <span className="text-xs text-muted">{doctorName}</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div className="flex items-start gap-1.5">
                <span className="text-xs font-semibold text-muted pt-1 w-4 shrink-0">U</span>
                <Dropdown value={r.upperWire} onChange={(v) => patchRow(r.id, { upperWire: v })} options={WIRE_OPTIONS} placeholder="Wire" className="shrink-0" />
                <AutoGrowTextarea value={r.upperNote} onChange={(v) => patchRow(r.id, { upperNote: v })} placeholder="e.g.: retraction 13 & 23" />
              </div>
              <div className="flex items-start gap-1.5">
                <span className="text-xs font-semibold text-muted pt-1 w-4 shrink-0">L</span>
                <Dropdown value={r.lowerWire} onChange={(v) => patchRow(r.id, { lowerWire: v })} options={WIRE_OPTIONS} placeholder="Wire" className="shrink-0" />
                <AutoGrowTextarea value={r.lowerNote} onChange={(v) => patchRow(r.id, { lowerNote: v })} placeholder="e.g.: retraction 13 & 23" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
