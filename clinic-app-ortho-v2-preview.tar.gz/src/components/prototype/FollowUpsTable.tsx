"use client";

// ===================================================================
// Orthodontic chart v2 — "Follow ups" table (isolated prototype, mock data only)
// ===================================================================
// 2026-08-27 rebuild: re-checked literally against Canva page 2's current
// content (design_id: DAHTZKEWWQI) instead of the earlier textual spec —
// Procedures = "U [size][type]  L [size][type]" on one line, then ONE shared
// free-text note below (not two separate U/L notes, per the user's feedback
// that two boxes felt bulky), Doctor is a per-row dropdown (Canva shows the
// privileged "pick any doctor" view — the assistant-only static-name case
// stays a deferred permission decision, see orthodontic-chart-v2-canva-redesign.md).
//
// New fields added per the user's feedback (a real visit doesn't always use
// these, so all three stay optional/blank by default):
// - Elastics: dispensed this visit? if yes, pick a size (3/16, 1/8, 5/16).
// - O-tie color (ligature ties).
// - Power chain: how many links used, if any.
// Every wire/elastics/O-tie/power-chain selection deducts from the shared
// mock inventory via onInventoryDeduct, stamped with this row's own date (the
// parent renders the actual deletable ledger grouped by date — see the
// "Inventory list" link under Chief Complaint in OrthoChartV2.tsx).
//
// "+ New visit" is left always-enabled in this preview (no once-per-day gate)
// so the user can freely add several visits to review the shape — the real
// system will re-add the "only if no visit today yet" rule from the spec.
//
// 2026-08-27, next-round feedback:
// - Wire often doesn't change visit to visit, so both the Size and Type
//   dropdowns lead with a "Same" option (picking it never deducts inventory).
// - The wire row moved back UP onto the header line (next to date/service,
//   before the doctor dropdown) instead of its own row underneath.
// - Power chain sits right next to the O-tie color on the extras line.
// - Two more optional extras next to Power chain: Buttons (a quantity used
//   this visit) and Compressed Coil (length in mm used) — both deduct from
//   the mock inventory the same way, only when actually filled in.
//
// 2026-08-27, later round: nothing in a visit row applies (bulk-bond, any
// inventory deduction) as the fields change anymore — that used to fire on
// every single change/blur, which the user flagged as risky ("ممكن ادوس مرة
// غلط", one accidental click and it's recorded). Every field now only patches
// local row state; a row-level "Save" button (next to Elastics/O-tie/etc. on
// the extras line) is what actually applies everything for that visit in one
// shot — see onSaveVisit. Once saved, the row's fields lock (read-only) so a
// second accidental click can't double-apply the same visit.

import { useState } from "react";
import type { MockInventoryLog } from "./InteractiveToothChart";

const MOCK_SERVICES = ["Follow up", "Bonding Upper", "Bonding Lower", "Debonding", "Retainer delivery", "Consultation"];
const WIRE_SIZES = ["Same", "12", "14", "16", "16x22", "17x25", "19x25"];
const WIRE_TYPES = ["Same", "NiTi", "SS", "TMA"];
const ELASTIC_SIZES = ["3/16", "1/8", "5/16"];
const OTIE_COLORS = ["Clear", "Silver", "Blue", "Red", "Green", "Yellow", "Pink", "Purple", "Orange", "Black", "White", "Gold"];
const MOCK_DOCTORS = ["Dr. Mohamed", "Dr. Kareem", "Dr. Gouda", "Dr. Nassar", "Dr. Amer"];

interface FollowUpRow {
  id: string;
  date: string;
  service: string;
  upperSize: string;
  upperType: string;
  lowerSize: string;
  lowerType: string;
  note: string;
  elasticsDispensed: boolean;
  elasticsSize: string;
  otieColor: string;
  powerChainQty: string;
  buttonsQty: string;
  compressedCoilMm: string;
  doctor: string;
  /** True once "Save" has been clicked for this visit — everything about it
   * (bulk-bond, inventory deductions) has already been applied, and the row's
   * fields lock to read-only so a second click can't double-apply it. */
  saved: boolean;
}

function todayStr(): string {
  const d = new Date();
  return `${String(d.getDate()).padStart(2, "0")}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getFullYear()).slice(2)}`;
}

function makeEmptyRow(doctor: string): FollowUpRow {
  return {
    id: `${Date.now()}-${Math.random()}`,
    date: "",
    service: "",
    upperSize: "",
    upperType: "",
    lowerSize: "",
    lowerType: "",
    note: "",
    elasticsDispensed: false,
    elasticsSize: "",
    otieColor: "",
    powerChainQty: "",
    buttonsQty: "",
    compressedCoilMm: "",
    doctor,
    saved: false,
  };
}

function AutoGrowTextarea({
  value,
  onChange,
  placeholder,
  disabled = false,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  disabled?: boolean;
}) {
  return (
    <textarea
      value={value}
      onChange={(e) => {
        onChange(e.target.value);
        e.target.style.height = "auto";
        e.target.style.height = `${e.target.scrollHeight}px`;
      }}
      placeholder={placeholder}
      rows={1}
      disabled={disabled}
      className="w-full min-w-0 resize-none overflow-hidden rounded-md border border-border bg-background px-2 py-1 text-xs disabled:opacity-60 disabled:cursor-not-allowed"
    />
  );
}

function Dropdown({
  value,
  onChange,
  options,
  placeholder = "—",
  className = "",
  disabled = false,
}: {
  value: string;
  onChange: (v: string) => void;
  options: string[];
  placeholder?: string;
  className?: string;
  disabled?: boolean;
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      disabled={disabled}
      className={`rounded-md border border-border bg-background px-1.5 py-1 text-xs disabled:opacity-60 disabled:cursor-not-allowed ${className}`}
    >
      <option value="">{placeholder}</option>
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  );
}

export default function FollowUpsTable({
  doctorName = "Dr. Mohamed",
  onBulkBond,
  onInventoryDeduct,
}: {
  doctorName?: string;
  onBulkBond?: (arch: "upper" | "lower", date?: string) => void;
  onInventoryDeduct?: (log: MockInventoryLog) => void;
}) {
  const [rows, setRows] = useState<FollowUpRow[]>([]);

  function addVisit() {
    setRows((prev) => [makeEmptyRow(doctorName), ...prev]);
  }

  function patchRow(id: string, patch: Partial<FollowUpRow>) {
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  }

  function setToday(id: string) {
    patchRow(id, { date: todayStr() });
  }

  // Nothing below applies to the chart or the inventory anymore — every
  // handler just patches local row state. Save (onSaveVisit) is what actually
  // fires bulk-bond and every inventory deduction, all at once, for the
  // row's current values.
  function onServiceChange(id: string, service: string) {
    patchRow(id, { service });
  }

  function onWireChange(id: string, patch: Partial<FollowUpRow>) {
    patchRow(id, patch);
  }

  function onElasticsSizeChange(id: string, size: string) {
    patchRow(id, { elasticsSize: size });
  }

  function onOtieChange(id: string, color: string) {
    patchRow(id, { otieColor: color });
  }

  function onSaveVisit(id: string) {
    const r = rows.find((row) => row.id === id);
    if (!r || r.saved) return;
    const date = r.date || todayStr();

    if (r.service === "Bonding Upper") onBulkBond?.("upper", date);
    if (r.service === "Bonding Lower") onBulkBond?.("lower", date);

    // "Same" means the wire wasn't actually changed this visit — nothing to deduct.
    if (r.upperSize && r.upperType && r.upperSize !== "Same" && r.upperType !== "Same") {
      onInventoryDeduct?.({ label: `Wire ${r.upperSize} ${r.upperType} (Upper)`, qty: 1, date });
    }
    if (r.lowerSize && r.lowerType && r.lowerSize !== "Same" && r.lowerType !== "Same") {
      onInventoryDeduct?.({ label: `Wire ${r.lowerSize} ${r.lowerType} (Lower)`, qty: 1, date });
    }

    if (r.elasticsDispensed && r.elasticsSize) {
      onInventoryDeduct?.({ label: `Elastics ${r.elasticsSize}`, qty: 1, date });
    }

    if (r.otieColor) {
      onInventoryDeduct?.({ label: `O-ties — ${r.otieColor}`, qty: 1, date });
    }

    const powerChainQty = parseInt(r.powerChainQty, 10);
    if (powerChainQty > 0) onInventoryDeduct?.({ label: "Power chain links", qty: powerChainQty, date });

    const buttonsQty = parseInt(r.buttonsQty, 10);
    if (buttonsQty > 0) onInventoryDeduct?.({ label: "Buttons", qty: buttonsQty, date });

    const coilMm = parseInt(r.compressedCoilMm, 10);
    if (coilMm > 0) onInventoryDeduct?.({ label: "Compressed coil (mm)", qty: coilMm, date });

    patchRow(id, { date, saved: true });
  }

  return (
    <div className="card-3d rounded-xl p-5 space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h3 className="font-bold">Follow ups</h3>
        <button
          type="button"
          onClick={addVisit}
          className="text-xs px-3 py-1.5 rounded-md border border-dashed border-border hover:bg-primary-soft text-muted"
        >
          + New visit
        </button>
      </div>

      {rows.length === 0 && <p className="text-xs text-muted">No visits recorded yet.</p>}

      <div>
        {rows.map((r, idx) => (
          <div key={r.id}>
            {/* Clear separator between one visit and the next — each visit
                card already has its own border, but the user asked for an
                extra visible line between them so the boundary reads at a
                glance, not just from the card padding. */}
            {idx > 0 && <div className="my-3 border-t-2 border-dashed border-border" />}
            <div className={`rounded-lg border border-border p-3 space-y-2 ${r.saved ? "bg-primary-soft/20" : ""}`}>
              {/* Date + Service + Wire (U/L) — all on one line, Doctor at the end. */}
              <div className="flex items-center justify-between flex-wrap gap-3">
                <div className="flex items-center gap-3 flex-wrap">
                  <button
                    type="button"
                    onClick={() => setToday(r.id)}
                    disabled={r.saved}
                    className="flex items-center gap-1.5 text-xs px-2 py-1 rounded-md border border-border hover:bg-primary-soft disabled:opacity-60 disabled:cursor-not-allowed"
                    title="Set to today"
                  >
                    📅 {r.date || "Set date"}
                  </button>
                  <Dropdown value={r.service} onChange={(v) => onServiceChange(r.id, v)} options={MOCK_SERVICES} placeholder="Service" disabled={r.saved} />

                  <div className="flex items-center gap-1.5 text-xs">
                    <span className="font-semibold text-muted w-4 shrink-0">U</span>
                    <Dropdown value={r.upperSize} onChange={(v) => onWireChange(r.id, { upperSize: v })} options={WIRE_SIZES} placeholder="Size" disabled={r.saved} />
                    <Dropdown value={r.upperType} onChange={(v) => onWireChange(r.id, { upperType: v })} options={WIRE_TYPES} placeholder="Type" disabled={r.saved} />
                  </div>
                  <div className="flex items-center gap-1.5 text-xs">
                    <span className="font-semibold text-muted w-4 shrink-0">L</span>
                    <Dropdown value={r.lowerSize} onChange={(v) => onWireChange(r.id, { lowerSize: v })} options={WIRE_SIZES} placeholder="Size" disabled={r.saved} />
                    <Dropdown value={r.lowerType} onChange={(v) => onWireChange(r.id, { lowerType: v })} options={WIRE_TYPES} placeholder="Type" disabled={r.saved} />
                  </div>
                </div>
                <Dropdown value={r.doctor} onChange={(v) => patchRow(r.id, { doctor: v })} options={MOCK_DOCTORS} placeholder="Doctor" disabled={r.saved} />
              </div>

              {/* One shared free-text note, per the user's feedback (was two boxes) */}
              <AutoGrowTextarea value={r.note} onChange={(v) => patchRow(r.id, { note: v })} placeholder="e.g.: retraction 13 & 23" disabled={r.saved} />

              {/* Elastics / O-tie + Power chain + Save — all optional (bar Save),
                  not used every visit. O-tie color and Power chain are grouped
                  together (power chain right next to the color) since they're
                  often noted together. Save is on the same line, at the end. */}
              <div className="flex items-center gap-4 flex-wrap text-xs pt-1 border-t border-border">
                <label className="flex items-center gap-1.5">
                  <input
                    type="checkbox"
                    checked={r.elasticsDispensed}
                    disabled={r.saved}
                    onChange={(e) => patchRow(r.id, { elasticsDispensed: e.target.checked, elasticsSize: e.target.checked ? r.elasticsSize : "" })}
                  />
                  Elastics dispensed
                  {r.elasticsDispensed && (
                    <Dropdown value={r.elasticsSize} onChange={(v) => onElasticsSizeChange(r.id, v)} options={ELASTIC_SIZES} placeholder="Size" disabled={r.saved} />
                  )}
                </label>
                <div className="flex items-center gap-3 whitespace-nowrap">
                  <label className="flex items-center gap-1.5">
                    O-tie color
                    <Dropdown value={r.otieColor} onChange={(v) => onOtieChange(r.id, v)} options={OTIE_COLORS} placeholder="—" disabled={r.saved} />
                  </label>
                  <label className="flex items-center gap-1.5">
                    Power chain
                    <input
                      type="number"
                      min={0}
                      value={r.powerChainQty}
                      disabled={r.saved}
                      onChange={(e) => patchRow(r.id, { powerChainQty: e.target.value })}
                      placeholder="0"
                      className="w-14 rounded-md border border-border bg-background px-1.5 py-1 text-xs disabled:opacity-60 disabled:cursor-not-allowed"
                    />
                  </label>
                  <label className="flex items-center gap-1.5">
                    Buttons
                    <input
                      type="number"
                      min={0}
                      value={r.buttonsQty}
                      disabled={r.saved}
                      onChange={(e) => patchRow(r.id, { buttonsQty: e.target.value })}
                      placeholder="0"
                      className="w-14 rounded-md border border-border bg-background px-1.5 py-1 text-xs disabled:opacity-60 disabled:cursor-not-allowed"
                    />
                  </label>
                  <label className="flex items-center gap-1.5">
                    Compressed coil (mm)
                    <input
                      type="number"
                      min={0}
                      value={r.compressedCoilMm}
                      disabled={r.saved}
                      onChange={(e) => patchRow(r.id, { compressedCoilMm: e.target.value })}
                      placeholder="0"
                      className="w-14 rounded-md border border-border bg-background px-1.5 py-1 text-xs disabled:opacity-60 disabled:cursor-not-allowed"
                    />
                  </label>
                </div>
                <button
                  type="button"
                  onClick={() => onSaveVisit(r.id)}
                  disabled={r.saved}
                  className={`ml-auto px-3 py-1.5 rounded-md text-xs font-medium shrink-0 ${
                    r.saved
                      ? "border border-green-300 bg-green-50 text-green-700 cursor-default"
                      : "btn-3d-primary"
                  }`}
                  title={r.saved ? "This visit is saved" : "Save this visit — applies bonding + inventory deductions"}
                >
                  {r.saved ? "✓ Saved" : "Save"}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
