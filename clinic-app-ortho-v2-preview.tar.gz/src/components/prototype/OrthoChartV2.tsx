"use client";

// ===================================================================
// Orthodontic chart v2 — full page 1 (isolated prototype, mock data only)
// ===================================================================
// Built on the user's Canva design (design_id: DAHTZKEWWQI). Fully isolated
// route — not linked to nav or real data — so the user can review the shape
// and give feedback before anything is merged into the real system.
//
// 2026-08-27 fidelity pass: layout/labels/fields re-checked literally against
// Canva page 1's own element content and coordinates (not from memory).
// 2026-08-27 feedback round 2: whole chart switched to English + LTR (matches
// Canva's own coordinate system exactly, no more RTL mirroring); Follow ups
// table (page 2 design) added below the Interactive/Diagnostic card, fixed in
// place regardless of the toggle; Treatment Plan reworked — Extraction (with
// a small quadrant/position "cross" mark, per the user's own sketch) sits
// beside Anchorage, and a free-text notes box takes Anchorage's old spot;
// selecting "Bonding Upper/Lower" in a Follow-up visit now auto-bonds that
// whole arch (except the 2nd/3rd molars) on the Interactive chart; the
// Interactive/Diagnostic chart components stay mounted (hidden via CSS
// instead of unmounted) so bonding state survives the toggle; stripping-count
// badges enlarged/re-stacked so they no longer get clipped by the next tooth.
// Full history: project "Clinic mangment system" on claude.ai
// (orthodontic-chart-v2-*.md).

import { useState, useRef } from "react";
import InteractiveToothChart, { type MockInventoryLog, type InteractiveToothChartHandle } from "./InteractiveToothChart";
import DiagnosticChart from "./DiagnosticChart";
import FollowUpsTable from "./FollowUpsTable";

const MOCK_BRACKET_TYPES = ["American", "Ormco", "3M"];
const PRESCRIPTION_OPTIONS = ["Roth", "MBT", "Andrews"];
const SLOT_OPTIONS = ["18", "22"];
// Anchorage device type — no other source of truth for this list yet, seeded
// with "Mini-screw" (the value shown in the design) + common ortho anchorage
// types. Needs confirmation from the user before this merges for real.
const ANCHORAGE_OPTIONS = ["Mini-screw", "Headgear", "Nance appliance", "TPA", "Lingual arch", "Class II elastics", "Class III elastics"];

const QUADRANTS = ["1", "2", "3", "4", "5", "6", "7", "8"];
const POSITIONS = ["1", "2", "3", "4", "5", "6", "7", "8"];

type ChartView = "interactive" | "diagnostic";

interface MockPhoto {
  id: string;
  url: string;
  rotation: number;
}

interface ExtractionRow {
  id: string;
  quadrant: string;
  position: string;
}

// Extraction is capped at a FIXED 4 rows (per the user: "we never extract
// more than 4 teeth in ortho") — no add/remove controls, per Round 3 feedback.
function makeFixedExtractionRows(): ExtractionRow[] {
  return [0, 1, 2, 3].map((i) => ({ id: `extraction-${i}`, quadrant: "", position: "" }));
}

interface LoggedInventoryEntry extends MockInventoryLog {
  id: string;
}

function Dropdown({
  value,
  onChange,
  options,
  placeholder = "—",
}: {
  value: string | null;
  onChange: (v: string) => void;
  options: string[];
  placeholder?: string;
}) {
  return (
    <select
      value={value ?? ""}
      onChange={(e) => onChange(e.target.value)}
      className="rounded-md border border-border bg-background px-2 py-1 text-xs"
    >
      <option value="">{placeholder}</option>
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  );
}

export default function OrthoChartV2({ patientName }: { patientName: string }) {
  const [bracketType, setBracketType] = useState<string | null>(null);
  const [prescription, setPrescription] = useState<string | null>(null);
  const [slot, setSlot] = useState<string | null>(null);

  const [photos, setPhotos] = useState<MockPhoto[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const [photoDescription, setPhotoDescription] = useState("");

  const [chiefComplaint, setChiefComplaint] = useState("");

  const [extractionRows, setExtractionRows] = useState<ExtractionRow[]>(makeFixedExtractionRows());
  const [anchorage, setAnchorage] = useState<string | null>(null);
  const [treatmentNote, setTreatmentNote] = useState("");

  const [view, setView] = useState<ChartView>("interactive");
  const [inventoryLog, setInventoryLog] = useState<LoggedInventoryEntry[]>([]);
  const [showInventoryModal, setShowInventoryModal] = useState(false);
  const chartRef = useRef<InteractiveToothChartHandle>(null);

  function addPhotosFromFiles(files: FileList | null) {
    if (!files) return;
    const next: MockPhoto[] = [];
    Array.from(files).forEach((f) => {
      if (!f.type.startsWith("image/")) return;
      next.push({ id: `${Date.now()}-${f.name}-${Math.random()}`, url: URL.createObjectURL(f), rotation: 0 });
    });
    setPhotos((prev) => [...prev, ...next]);
  }

  function rotatePhoto(id: string) {
    setPhotos((prev) => prev.map((p) => (p.id === id ? { ...p, rotation: (p.rotation + 90) % 360 } : p)));
  }

  function removePhoto(id: string) {
    setPhotos((prev) => prev.filter((p) => p.id !== id));
  }

  function updateExtractionRow(id: string, patch: Partial<ExtractionRow>) {
    setExtractionRows((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  }

  function onInventoryDeduct(log: MockInventoryLog) {
    setInventoryLog((prev) => [{ ...log, id: `${Date.now()}-${Math.random()}` }, ...prev]);
  }

  function deleteInventoryEntry(id: string) {
    // Mock-level delete for this preview — the real system should gate this
    // to admins only, per the user's explicit request ("على الاقل تبقى مع الادمن").
    setInventoryLog((prev) => prev.filter((l) => l.id !== id));
  }

  return (
    <div className="space-y-4">
      {/* Title + Name + Brackets/Rx/Slot — one row, matching the design */}
      <div className="card-3d rounded-xl p-5 space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h1 className="text-lg font-bold flex-1 text-center">Orthodontic chart</h1>
          <span className="text-[10px] px-2 py-1 rounded-full bg-amber-100 text-amber-800 border border-amber-300">
            Preview prototype — not connected to real data
          </span>
        </div>
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="text-sm">
            <span className="text-muted">Name: </span>
            <span className="font-semibold">{patientName}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-muted">Brackets:</span>
            <Dropdown value={bracketType} onChange={setBracketType} options={MOCK_BRACKET_TYPES} />
            <Dropdown value={prescription} onChange={setPrescription} options={PRESCRIPTION_OPTIONS} />
            <Dropdown value={slot} onChange={setSlot} options={SLOT_OPTIONS} />
          </div>
        </div>
      </div>

      {/* Photos & X-rays — + button plus a Description (Optional) field, per the design */}
      <div className="card-3d rounded-xl p-5 space-y-1.5">
        <div className="text-xs text-muted">Photos &amp; X-rays</div>
        <div className="flex gap-3 flex-wrap items-start">
          {photos.map((p) => (
            <div key={p.id} className="relative w-20 h-20 rounded-md overflow-hidden border border-border bg-background group">
              <img
                src={p.url}
                alt=""
                className="w-full h-full object-cover"
                style={{ transform: `rotate(${p.rotation}deg)` }}
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-center justify-center gap-1 opacity-0 group-hover:opacity-100">
                <button
                  type="button"
                  onClick={() => rotatePhoto(p.id)}
                  className="text-white text-xs bg-black/50 rounded px-1.5 py-0.5"
                  title="Rotate"
                >
                  ↻
                </button>
                <button
                  type="button"
                  onClick={() => removePhoto(p.id)}
                  className="text-white text-xs bg-black/50 rounded px-1.5 py-0.5"
                  title="Delete"
                >
                  ×
                </button>
              </div>
            </div>
          ))}
          <label
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              addPhotosFromFiles(e.dataTransfer.files);
            }}
            className={`w-20 h-20 rounded-md border-2 border-dashed flex items-center justify-center cursor-pointer text-2xl text-muted transition-colors ${
              dragOver ? "border-primary bg-primary-soft" : "border-border hover:bg-primary-soft"
            }`}
          >
            +
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={(e) => addPhotosFromFiles(e.target.files)}
            />
          </label>
        </div>
        <div className="pt-1 max-w-xs">
          <div className="text-[11px] text-muted mb-1">Description (Optional)</div>
          <input
            type="text"
            value={photoDescription}
            onChange={(e) => setPhotoDescription(e.target.value)}
            placeholder="Eg.: Panorama"
            className="w-full rounded-md border border-border bg-background px-2 py-1 text-xs"
          />
        </div>
      </div>

      {/* Chief Complaint + Treatment Plan — side by side, per the design */}
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="card-3d rounded-xl p-5 space-y-1.5">
          <div className="text-sm font-semibold">Chief Complaint</div>
          <textarea
            value={chiefComplaint}
            onChange={(e) => setChiefComplaint(e.target.value)}
            rows={3}
            placeholder="Eg.: Spacing"
            className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm placeholder:text-muted"
          />
          <button
            type="button"
            onClick={() => setShowInventoryModal(true)}
            className="text-xs text-primary underline hover:no-underline"
          >
            Inventory list{inventoryLog.length > 0 ? ` (${inventoryLog.length})` : ""}
          </button>
        </div>

        <div className="card-3d rounded-xl p-5 space-y-3">
          <div className="text-sm font-semibold">Treatment Plan</div>

          <div className="flex items-start gap-6 flex-wrap">
            <div className="space-y-1.5">
              <div className="text-xs text-muted">Extraction:</div>
              {/* Fixed at 4 rows — we never extract more than 4 teeth in ortho,
                  per the user, so no add/remove controls. Black quadrant/position
                  cross-mark (was orange), no border under the last row. */}
              <div className="relative inline-block">
                <div className="grid grid-cols-2 gap-x-3 gap-y-1.5">
                  {extractionRows.flatMap((r, i) => {
                    const isLast = i === extractionRows.length - 1;
                    const cellStyle = isLast ? undefined : { borderBottom: "2px solid #1c2521" };
                    return [
                      <div key={`${r.id}-q`} className="pb-1 flex justify-center" style={cellStyle}>
                        <Dropdown value={r.quadrant} onChange={(v) => updateExtractionRow(r.id, { quadrant: v })} options={QUADRANTS} />
                      </div>,
                      <div key={`${r.id}-p`} className="pb-1 flex justify-center" style={cellStyle}>
                        <Dropdown value={r.position} onChange={(v) => updateExtractionRow(r.id, { position: v })} options={POSITIONS} />
                      </div>,
                    ];
                  })}
                </div>
                <div
                  className="absolute top-0 bottom-1.5 left-1/2 -translate-x-1/2 pointer-events-none"
                  style={{ width: "2px", background: "#1c2521" }}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="text-xs text-muted">Anchorage:</div>
              <Dropdown value={anchorage} onChange={setAnchorage} options={ANCHORAGE_OPTIONS} />
            </div>
          </div>

          <div className="space-y-1">
            <div className="text-xs text-muted">Notes (free text)</div>
            <textarea
              value={treatmentNote}
              onChange={(e) => setTreatmentNote(e.target.value)}
              rows={2}
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
            />
          </div>
        </div>
      </div>

      {/* Diagnosis / Interactive chart toggle — both stay mounted (hidden with
          CSS, not unmounted) so bonding/extraction state survives switching. */}
      <div className="card-3d rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={() => setView((v) => (v === "interactive" ? "diagnostic" : "interactive"))}
            className="text-xs text-primary underline hover:no-underline"
          >
            {view === "interactive" ? "Diagnostic chart" : "Interactive chart"}
          </button>
          <h3 className="font-bold">{view === "interactive" ? "Interactive chart" : "Diagnosis:"}</h3>
        </div>

        <div style={{ display: view === "interactive" ? "block" : "none" }}>
          <InteractiveToothChart ref={chartRef} onInventoryDeduct={onInventoryDeduct} />
        </div>
        <div style={{ display: view === "diagnostic" ? "block" : "none" }}>
          <DiagnosticChart />
        </div>
      </div>

      {/* Follow ups — fixed right below the Interactive chart, regardless of
          the toggle above (page 2 of the design). Picking "Bonding Upper/Lower"
          as the service auto-bonds that arch on the Interactive chart, and
          wire/elastics/O-tie/power-chain selections deduct from the shared
          mock inventory (see the "Inventory list" link + modal above, under
          Chief Complaint). */}
      <FollowUpsTable onBulkBond={(arch) => chartRef.current?.bulkBond(arch)} onInventoryDeduct={onInventoryDeduct} />

      {/* Inventory list modal — full deduction history since the patient
          started treatment, with a delete/undo button per entry (mock-level
          here; the real system should gate deletion to admins only). */}
      {showInventoryModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
          onClick={() => setShowInventoryModal(false)}
        >
          <div
            className="card-3d rounded-xl p-5 w-full max-w-md max-h-[80vh] flex flex-col space-y-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold">Inventory list</h3>
              <button type="button" onClick={() => setShowInventoryModal(false)} className="text-muted text-lg leading-none px-1">
                ×
              </button>
            </div>
            <p className="text-xs text-muted">Materials used for this patient since treatment started.</p>
            <div className="overflow-y-auto space-y-1.5">
              {inventoryLog.length === 0 && <p className="text-xs text-muted">Nothing used yet.</p>}
              {inventoryLog.map((l) => (
                <div key={l.id} className="flex items-center justify-between gap-2 text-xs rounded-md border border-border px-2 py-1.5">
                  <span>
                    − {l.qty} × {l.label}
                  </span>
                  <button
                    type="button"
                    onClick={() => deleteInventoryEntry(l.id)}
                    className="text-muted hover:text-red-600 shrink-0"
                    title="Delete / undo this deduction"
                  >
                    Undo
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
