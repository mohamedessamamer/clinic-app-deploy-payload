"use client";

// ===================================================================
// شارت التقويم v2 — صفحة 1 كاملة (بروتوتايب معزول، mock data بس)
// ===================================================================
// بيبني على تصميم Canva بتاع المستخدم (design_id: DAHTZKEWWQI). راوت منعزل
// تمامًا — مش مربوط بالـnav ولا بالداتا الحقيقية، عشان المستخدم يعاين الشكل
// ويدي ملاحظات قبل أي دمج في السيستم الفعلي.
//
// آخر تحديث (2026-08-27): اتراجع الترتيب/التسميات/الحقول دي كلها حرفيًا من
// محتوى وإحداثيات عناصر صفحة 1 على Canva نفسها (مش من الذاكرة) عشان تتطابق مع
// "حافظ تماما على الشكل زي ما انا عامله بالظبط على canva":
//  - Name + Brackets/Prescription/Slot في نفس الصف.
//  - مربع الصور معاه حقل "Description (Optional)" (placeholder: Eg.: Panorama).
//  - Chief Complaint وTreatment Plan صف واحد جنب بعض (مش تحت بعض).
//  - Extraction بقت أرقام أسنان مركّبة (Quadrant + Position) بدل نص حر، وAnchorage
//    بقى drop-list (نوع الجهاز، مش مستوى) بقيمة مبدئية "Mini-screw" زي التصميم.
//  - Diagnosis بقت شبكة 7 صفوف × عمودين بدون Cephalometric (مش موجودة في التصميم).
// التفاصيل والقرارات كاملة في مشروع "Clinic mangment system" على claude.ai
// (orthodontic-chart-v2-*.md).

import { useState, useRef } from "react";
import InteractiveToothChart, { type MockInventoryLog } from "./InteractiveToothChart";
import DiagnosticChart from "./DiagnosticChart";

const MOCK_BRACKET_TYPES = ["American", "Ormco", "3M"];
const PRESCRIPTION_OPTIONS = ["Roth", "MBT", "Andrews"];
const SLOT_OPTIONS = ["18", "22"];
// نوع جهاز الإرساء — مش موجود عندنا مصدر تاني للقيمة دي، اتحطت مبدئيًا بالاعتماد
// على "Mini-screw" (القيمة الظاهرة في التصميم) + خيارات تقويم شائعة. يحتاج تأكيد
// من المستخدم قبل الدمج النهائي.
const ANCHORAGE_OPTIONS = ["Mini-screw", "Headgear", "Nance appliance", "TPA", "Lingual arch", "Class II elastics", "Class III elastics"];

const QUADRANTS = ["1", "2", "3", "4", "5", "6", "7", "8"];
const POSITIONS = ["1", "2", "3", "4", "5", "6", "7", "8"];

type ChartView = "interactive" | "diagnostic";

interface MockPhoto {
  id: string;
  url: string;
  rotation: number;
}

interface ExtractionRow {
  id: string;
  quadrant: string;
  position: string;
}

function Dropdown({
  value,
  onChange,
  options,
  placeholder = "—",
}: {
  value: string | null;
  onChange: (v: string) => void;
  options: string[];
  placeholder?: string;
}) {
  return (
    <select
      value={value ?? ""}
      onChange={(e) => onChange(e.target.value)}
      className="rounded-md border border-border bg-background px-2 py-1 text-xs"
    >
      <option value="">{placeholder}</option>
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  );
}

export default function OrthoChartV2({ patientName }: { patientName: string }) {
  const [bracketType, setBracketType] = useState<string | null>(null);
  const [prescription, setPrescription] = useState<string | null>(null);
  const [slot, setSlot] = useState<string | null>(null);

  const [photos, setPhotos] = useState<MockPhoto[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const [photoDescription, setPhotoDescription] = useState("");

  const [chiefComplaint, setChiefComplaint] = useState("");

  const [extractionRows, setExtractionRows] = useState<ExtractionRow[]>([]);
  const [anchorage, setAnchorage] = useState<string | null>(null);

  const [view, setView] = useState<ChartView>("interactive");
  const [inventoryLog, setInventoryLog] = useState<MockInventoryLog[]>([]);

  function addPhotosFromFiles(files: FileList | null) {
    if (!files) return;
    const next: MockPhoto[] = [];
    Array.from(files).forEach((f) => {
      if (!f.type.startsWith("image/")) return;
      next.push({ id: `${Date.now()}-${f.name}-${Math.random()}`, url: URL.createObjectURL(f), rotation: 0 });
    });
    setPhotos((prev) => [...prev, ...next]);
  }

  function rotatePhoto(id: string) {
    setPhotos((prev) => prev.map((p) => (p.id === id ? { ...p, rotation: (p.rotation + 90) % 360 } : p)));
  }

  function removePhoto(id: string) {
    setPhotos((prev) => prev.filter((p) => p.id !== id));
  }

  function addExtractionRow() {
    setExtractionRows((prev) => [...prev, { id: `${Date.now()}-${Math.random()}`, quadrant: "", position: "" }]);
  }

  function updateExtractionRow(id: string, patch: Partial<ExtractionRow>) {
    setExtractionRows((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  }

  function removeExtractionRow(id: string) {
    setExtractionRows((prev) => prev.filter((r) => r.id !== id));
  }

  function onInventoryDeduct(log: MockInventoryLog) {
    setInventoryLog((prev) => [log, ...prev].slice(0, 8));
  }

  return (
    <div className="space-y-4" dir="rtl">
      {/* العنوان + Name + Brackets/Rx/Slot — صف واحد زي التصميم بالظبط */}
      <div className="card-3d rounded-xl p-5 space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h1 className="text-lg font-bold flex-1 text-center">Orthodontic chart</h1>
          <span className="text-[10px] px-2 py-1 rounded-full bg-amber-100 text-amber-800 border border-amber-300">
            بروتوتايب معاينة — مش متصل بالداتا الحقيقية
          </span>
        </div>
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="text-sm">
            <span className="text-muted">Name: </span>
            <span className="font-semibold">{patientName}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-muted">Brackets:</span>
            <Dropdown value={bracketType} onChange={setBracketType} options={MOCK_BRACKET_TYPES} />
            <Dropdown value={prescription} onChange={setPrescription} options={PRESCRIPTION_OPTIONS} />
            <Dropdown value={slot} onChange={setSlot} options={SLOT_OPTIONS} />
          </div>
        </div>
      </div>

      {/* الصور والأشعة — + مع Description (Optional) زي التصميم */}
      <div className="card-3d rounded-xl p-5 space-y-1.5">
        <div className="text-xs text-muted">الصور والأشعة</div>
        <div className="flex gap-3 flex-wrap items-start">
          {photos.map((p) => (
            <div key={p.id} className="relative w-20 h-20 rounded-md overflow-hidden border border-border bg-background group">
              <img
                src={p.url}
                alt=""
                className="w-full h-full object-cover"
                style={{ transform: `rotate(${p.rotation}deg)` }}
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-center justify-center gap-1 opacity-0 group-hover:opacity-100">
                <button
                  type="button"
                  onClick={() => rotatePhoto(p.id)}
                  className="text-white text-xs bg-black/50 rounded px-1.5 py-0.5"
                  title="تدوير"
                >
                  ↻
                </button>
                <button
                  type="button"
                  onClick={() => removePhoto(p.id)}
                  className="text-white text-xs bg-black/50 rounded px-1.5 py-0.5"
                  title="حذف"
                >
                  ×
                </button>
              </div>
            </div>
          ))}
          <label
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              addPhotosFromFiles(e.dataTransfer.files);
            }}
            className={`w-20 h-20 rounded-md border-2 border-dashed flex items-center justify-center cursor-pointer text-2xl text-muted transition-colors ${
              dragOver ? "border-primary bg-primary-soft" : "border-border hover:bg-primary-soft"
            }`}
          >
            +
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={(e) => addPhotosFromFiles(e.target.files)}
            />
          </label>
        </div>
        <div className="pt-1 max-w-xs">
          <div className="text-[11px] text-muted mb-1">Description (Optional)</div>
          <input
            type="text"
            value={photoDescription}
            onChange={(e) => setPhotoDescription(e.target.value)}
            placeholder="Eg.: Panorama"
            className="w-full rounded-md border border-border bg-background px-2 py-1 text-xs"
          />
        </div>
      </div>

      {/* Chief Complaint + Treatment Plan — صف واحد جنب بعض زي التصميم */}
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="card-3d rounded-xl p-5 space-y-1.5">
          <div className="text-sm font-semibold">Chief Complaint</div>
          <textarea
            value={chiefComplaint}
            onChange={(e) => setChiefComplaint(e.target.value)}
            rows={3}
            placeholder="Eg.: Spacing"
            className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm placeholder:text-muted"
          />
        </div>

        <div className="card-3d rounded-xl p-5 space-y-3">
          <div className="text-sm font-semibold">Treatment Plan</div>

          <div className="space-y-1">
            <div className="text-xs text-muted">Extraction:</div>
            <div className="space-y-1">
              {extractionRows.map((r) => (
                <div key={r.id} className="flex items-center gap-1.5">
                  <Dropdown value={r.quadrant} onChange={(v) => updateExtractionRow(r.id, { quadrant: v })} options={QUADRANTS} />
                  <Dropdown value={r.position} onChange={(v) => updateExtractionRow(r.id, { position: v })} options={POSITIONS} />
                  <button type="button" onClick={() => removeExtractionRow(r.id)} className="text-muted text-xs px-1">
                    ×
                  </button>
                </div>
              ))}
              <button
                type="button"
                onClick={addExtractionRow}
                className="text-xs px-2 py-1 rounded-md border border-dashed border-border hover:bg-primary-soft text-muted"
              >
                + سن
              </button>
            </div>
          </div>

          <div className="space-y-1">
            <div className="text-xs text-muted">Anchorage:</div>
            <Dropdown value={anchorage} onChange={setAnchorage} options={ANCHORAGE_OPTIONS} />
          </div>
        </div>
      </div>

      {/* Diagnosis / Interactive chart toggle — صفحة/كرت منفصل، بيتبادلوا مكان بعض */}
      <div className="card-3d rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={() => setView((v) => (v === "interactive" ? "diagnostic" : "interactive"))}
            className="text-xs text-primary underline hover:no-underline"
          >
            {view === "interactive" ? "Diagnostic chart" : "Interactive chart"}
          </button>
          <h3 className="font-bold">{view === "interactive" ? "Interactive chart" : "Diagnosis:"}</h3>
        </div>

        {view === "interactive" ? <InteractiveToothChart onInventoryDeduct={onInventoryDeduct} /> : <DiagnosticChart />}

        {inventoryLog.length > 0 && (
          <div className="text-xs text-muted border-t border-border pt-2">
            <div className="font-semibold mb-1">سجل خصم المخزون (Mock)</div>
            <ul className="space-y-0.5">
              {inventoryLog.map((l, i) => (
                <li key={i}>
                  − {l.qty} × {l.label}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}
