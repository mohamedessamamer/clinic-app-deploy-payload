"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { logOverride } from "@/lib/audit";
import { FOLLOWUP_SERVICE_CODE } from "@/lib/followup";
import { getClinicToday } from "@/lib/clinic-date";
import { applyAvailableCreditsInTransaction } from "@/lib/credits";
import { parseMoney, parsePercent } from "@/lib/money";

// إضافة خدمة (وتحصيل دفعها) من داخل الملف المالي للمريض مباشرة — دي الطريقة
// الوحيدة دلوقتي لتسجيل خدمة/زيارة مالية بره سياق الجدول المركزي (بديل بوكس
// "إضافة خدمة" اللي كان تحت الجدول في /front-desk وانشال، دفعة 20). محصورة
// بصلاحية view_patient_billing — نفس الصلاحية اللي بتتحكم في عرض الصفحة دي
// أصلاً، عشان مين يقدر يشوف الملف المالي هو نفسه اللي يقدر يسجل عليه خدمة.
export async function addPatientServiceAction(formData: FormData) {
  const session = await getSession();
  if (!session) return;

  const canAdd = await hasPermission(session.userId, session.role, "view_patient_billing");
  if (!canAdd) return;

  const patientId = Number(formData.get("patient_id"));
  const serviceId = Number(formData.get("service_id"));
  const doctorId = Number(formData.get("doctor_id"));
  let visitDate = String(formData.get("visit_date") || "").trim();
  const paymentMethod = String(formData.get("payment_method") || "").trim() || null;
  const amountNow = parseMoney(formData.get("amount_now") || "0");

  if (!patientId || !serviceId || !doctorId || amountNow == null) return;

  const today = getClinicToday();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(visitDate)) visitDate = today;

  // تسجيل خدمة بتاريخ غير النهاردة ("تحصيل في يوم غير اليوم اللي دخل فيه
  // الفلوس") محصور بصلاحية edit_invoice_payments — نفس الصلاحية اللي أصلاً
  // بتحكم تعديل فاتورة اتسجلت بالفعل (مدير العيادة/المحاسب/الأدمن افتراضيًا،
  // قابلة للمنح لدكتور معيّن). الاستقبال (اللي معهوش الصلاحية دي افتراضيًا)
  // مقفول على تاريخ النهاردة بس، بغض النظر عن أي قيمة اتبعتت في الفورم.
  if (visitDate !== today) {
    const canBackdate = await hasPermission(session.userId, session.role, "edit_invoice_payments");
    if (!canBackdate) visitDate = today;
  }

  const service = await db
    .selectFrom("services")
    .select(["id", "name", "code", "default_price"])
    .where("id", "=", serviceId)
    .executeTakeFirst();
  if (!service) return;

  const isFollowup = service.code === FOLLOWUP_SERVICE_CODE;

  // هذه الشاشة مالية فقط: إضافة خدمة هنا لا تنشئ أو تعدل زيارة في الملف الطبي.
  if (isFollowup) {
    const targetInvoiceId = Number(formData.get("target_invoice_id"));
    if (!targetInvoiceId) return;

    // تأكيد إن الفاتورة الأصلية فعلاً بتاعة نفس المريض ده (وليست دفعة متابعة
    // هي نفسها) قبل الربط، عشان مايحصلش خلط بيانات بين مرضى.
    const targetInvoice = await db
      .selectFrom("invoices")
      .select(["invoices.id"])
      .where("invoices.id", "=", targetInvoiceId)
      .where("invoices.patient_id", "=", patientId)
      .where("invoices.parent_invoice_id", "is", null)
      .executeTakeFirst();
    if (!targetInvoice) return;

    await db
      .insertInto("invoices")
      .values({
        visit_id: null,
        patient_id: patientId,
        doctor_id: doctorId,
        appointment_id: null,
        service_id: service.id,
        invoice_date: visitDate,
        amount: 0,
        paid: amountNow,
        discount_percent: 0,
        price_overridden: 0,
        payment_method: paymentMethod,
        parent_invoice_id: targetInvoice.id,
      })
      .execute();
  } else {
    const price = parseMoney(formData.get("price") || String(service.default_price));
    const discountPercent = parsePercent(formData.get("discount_percent") || "0");
    if (price == null || discountPercent == null) return;
    const amount = Math.round(price * (1 - discountPercent / 100) * 100) / 100;
    const priceOverridden = Math.round(service.default_price) !== Math.round(price);

    const invoiceId = await db.transaction().execute(async (trx) => {
      const invoiceResult = await trx
        .insertInto("invoices")
        .values({
          visit_id: null,
          patient_id: patientId,
          doctor_id: doctorId,
          appointment_id: null,
          service_id: service.id,
          invoice_date: visitDate,
          amount,
          paid: amountNow,
          discount_percent: discountPercent,
          price_overridden: priceOverridden ? 1 : 0,
          payment_method: paymentMethod,
          parent_invoice_id: null,
          original_price: price,
        })
        .executeTakeFirst();
      const id = Number(invoiceResult.insertId);
      await applyAvailableCreditsInTransaction(trx, patientId, id);
      return id;
    });

    if (priceOverridden) {
      await logOverride({
        entityType: "invoice_price",
        entityId: invoiceId,
        field: "السعر",
        oldValue: service.default_price,
        newValue: price,
        changedBy: session.userId,
        reason: `تعديل سعر خدمة "${service.name}" عند الإضافة من الملف المالي`,
      });
    }
  }

  revalidatePath(`/patients/${patientId}/billing`);
  revalidatePath(`/patients/${patientId}`);
  revalidatePath("/invoices");
  revalidatePath("/front-desk");
  revalidatePath("/");
}
