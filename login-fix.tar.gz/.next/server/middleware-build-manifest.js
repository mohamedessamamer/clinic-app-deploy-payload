globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/MBH8msqtulUGbViYXx4s0/_buildManifest.js",
    "static/MBH8msqtulUGbViYXx4s0/_ssgManifest.js",
    "static/MBH8msqtulUGbViYXx4s0/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/19mx3mg6lkumu.js",
    "static/chunks/3e4keds9ktjdu.js",
    "static/chunks/2o1mrcqyza_ve.js",
    "static/chunks/06z9j7lk94lr4.js",
    "static/chunks/turbopack-2v2wbjl_wahci.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
