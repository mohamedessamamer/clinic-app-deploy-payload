var R=require("../../chunks/[turbopack]_runtime.js")("server/app/logout/route.js")
R.c("server/chunks/[externals]__114p9-9._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_1ynrhis._.js")
R.c("server/chunks/_next-internal_server_app_logout_route_actions_1o2cyj9.js")
R.m(60855)
module.exports=R.m(60855).exports
