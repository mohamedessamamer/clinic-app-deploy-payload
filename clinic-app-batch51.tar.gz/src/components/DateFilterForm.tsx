"use client";

// فورم فلتر التاريخ ("اليوم: ...") المستخدم في أعلى صفحات الجدول/الفواتير/المواعيد.
// بيبعت (submit) نفسه تلقائيًا بمجرد اختيار تاريخ من الكاليندر — من غير ما يحتاج
// المستخدم يدوس زرار "عرض" بعدها. الزرار فاضل موجود برضه كحماية إضافية (لو ال
// onChange لأي سبب ما اتفعّلش، أو لكتابة تاريخ يدويًا بدل الكاليندر).
//
// دفعة 28: كان `<form>` HTML عادي — أي submit (تغيير تاريخ) كان بيعمل إعادة
// تحميل كاملة للصفحة (hard navigation)، مش انتقال سلس. المستخدم بلغ إن التنقل
// بين الشهور/الأيام "مش smooth". الحل: `<Form>` من next/form بدل الـ<form>
// العادي — بيعمل نفس الحاجة بالظبط (GET بيحول قيم الفورم لـquery params) لكن
// عن طريق client-side navigation (زي next/link) بدل تحميل كامل جديد للصفحة.
import Form from "next/form";
import { useMemo, useRef } from "react";

export default function DateFilterForm({ day }: { day: string }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const label = useMemo(() => {
    const [year, month, date] = day.split("-").map(Number);
    return new Intl.DateTimeFormat("ar-EG-u-nu-latn", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
      timeZone: "UTC",
    }).format(new Date(Date.UTC(year, month - 1, date)));
  }, [day]);

  return (
    <Form action="/front-desk" className="relative inline-flex items-center">
      <button
        type="button"
        onClick={() => {
          inputRef.current?.showPicker?.();
          inputRef.current?.focus();
        }}
        className="schedule-date-button"
        aria-label="اختيار تاريخ الجدول"
      >
        <span>⌄</span>
        <span>{label}</span>
        <span aria-hidden="true">▣</span>
      </button>
      <input
        ref={inputRef}
        type="date"
        name="date"
        defaultValue={day}
        onChange={(e) => e.currentTarget.form?.requestSubmit()}
        className="schedule-date-native"
        tabIndex={-1}
      />
    </Form>
  );
}
