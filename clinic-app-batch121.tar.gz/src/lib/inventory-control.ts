import type { Kysely, Transaction } from "kysely";
import type { Database } from "@/lib/db/types";

type SettingsExecutor = Kysely<Database> | Transaction<Database>;

/** Batch 111 master switch. A missing setting intentionally means OFF. */
export async function inventoryDeductionsEnabled(executor: SettingsExecutor): Promise<boolean> {
  const setting = await executor
    .selectFrom("clinic_settings")
    .select("value")
    .where("key", "=", "inventory_deductions_enabled")
    .executeTakeFirst();
  return setting?.value === "1";
}
