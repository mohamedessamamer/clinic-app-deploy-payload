import bcrypt from "bcryptjs";
import { SignJWT, jwtVerify } from "jose";

// مفتاح توقيع الجلسة. في الإنتاج مفيش أي قيمة احتياطية: لو المتغير ناقص أو قصير
// أي محاولة توقيع/تحقق بتفشل بصوت عالي بدل ما التطبيق يشتغل عادي بمفتاح معروف
// للجميع — اللي كان معناه إن أي حد يعرف النص القديم يقدر يزوّر كوكي بدور admin.
//
// التحقق كسول (مش وقت تحميل الموديول) عن قصد: `next build` بيشغّل الكود بـ
// NODE_ENV=production وهو بيجمع بيانات الصفحات، وفي اللحظة دي متغيرات البيئة
// بتاعة السيرفر مش بالضرورة موجودة — رمي الخطأ وقت التحميل كان بيكسر البناء
// نفسه. الطلبات الحقيقية بس هي اللي بتلمس الدالة دي.
let cachedSecret: Uint8Array | null = null;

export function getSessionSecret(): Uint8Array {
  if (cachedSecret) return cachedSecret;
  const fromEnv = process.env.SESSION_SECRET;
  if (!fromEnv || fromEnv.length < 32) {
    if (process.env.NODE_ENV === "production") {
      throw new Error(
        "[auth] SESSION_SECRET مفقود أو أقصر من 32 حرفًا. الملف هو .env.production.local أو .env.production في /opt/clinic-app. " +
          "لازم تكون قيمة حقيقية — لو مكتوب فيه $(openssl ...) فده نص حرفي مش أمر، وملفات .env مبتنفذش أوامر. " +
          "ولّد القيمة بنفسك: openssl rand -hex 32 — والصق الناتج، وبعدها أعد تشغيل الخدمة."
      );
    }
    cachedSecret = new TextEncoder().encode("dev-only-secret-change-in-production-please");
    return cachedSecret;
  }
  cachedSecret = new TextEncoder().encode(fromEnv);
  return cachedSecret;
}

// مشتق من نفس المفتاح بلاحقة مختلفة — عشان توكن تقرير الطبيب ما ينفعش يستخدم كجلسة.
export function getDerivedSecret(purpose: string): Uint8Array {
  const base = process.env.SESSION_SECRET || "dev-only-secret-change-in-production-please";
  if (!process.env.SESSION_SECRET && process.env.NODE_ENV === "production") {
    getSessionSecret(); // بيرمي نفس الخطأ الواضح فوق
  }
  return new TextEncoder().encode(`${base}:${purpose}`);
}

export const SESSION_COOKIE = "clinic_session";
export const STANDARD_SESSION_MAX_AGE_SECONDS = 60 * 60 * 6;
export const REMEMBERED_SESSION_MAX_AGE_SECONDS = 60 * 60 * 24 * 30;

// كلمة السر الافتراضية اللي بيتعمل بيها أي حساب جديد وأي تصفير من الأدمن.
// أي مستخدم لسه عليها بيتطلب منه تغييرها عند كل دخول، ويقدر يأجّل بزر "تخطي"
// لحد التاريخ اللي تحت — وبعده التغيير إجباري ومفيش تخطي.
export const DEFAULT_PASSWORD = "123";
export const DEFAULT_PASSWORD_DEADLINE = "2026-10-01";

export function isDefaultPasswordDeadlinePassed(today: string) {
  return today >= DEFAULT_PASSWORD_DEADLINE;
}

// الحد الأدنى 8 بدل 6، مع قائمة قصيرة جدًا من الكلمات اللي بيتكرر اختيارها.
// مش نظام تعقيد بحروف كبيرة/رموز — ده بيدفع الناس تكتب كلمة السر على ورقة.
// الهدف بس إن اللي هيسيب "123" ميحطش "123456" مكانها.
export const MIN_PASSWORD_LENGTH = 8;

const WEAK_PASSWORDS = new Set([
  "12345678", "123456789", "1234567890", "password", "password1", "qwertyui",
  "11111111", "00000000", "abcd1234", "clinic123", "admin123", "iloveyou",
]);

export function isWeakPassword(password: string) {
  const lower = password.toLowerCase();
  if (WEAK_PASSWORDS.has(lower)) return true;
  // كله رقم واحد متكرر، أو أرقام متتابعة بس.
  if (/^(.)\1+$/.test(password)) return true;
  return false;
}

export type Role = "admin" | "doctor" | "reception" | "accountant" | "clinic_manager";

export interface SessionPayload {
  userId: number;
  username: string;
  fullName: string;
  role: Role;
  doctorId: number | null;
  // نسخة من users.must_change_password وقت إصدار التوكن — موجودة هنا عشان
  // proxy.ts يقدر يفرض التغيير بعد الموعد النهائي من غير ما يفتح قاعدة البيانات.
  // مصدر الحقيقة يفضل العمود في قاعدة البيانات، والاتنين بيتضبطوا مع بعض في
  // نفس اللحظتين بس: وقت الدخول، ووقت تغيير كلمة السر.
  mustChangePassword?: boolean;
  // الجلسة الطويلة لا تُمنح إلا بعد أن يختار المستخدم صراحة الاحتفاظ بالدخول
  // على هذا الجهاز من قائمة حسابه.
  keepSignedIn?: boolean;
  // Incremented whenever credentials are changed so older JWTs stop working.
  sessionVersion: number;
}

export async function hashPassword(plain: string) {
  return bcrypt.hash(plain, 10);
}

export async function verifyPassword(plain: string, hash: string) {
  return bcrypt.compare(plain, hash);
}

export async function createSessionToken(payload: SessionPayload) {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(payload.keepSignedIn ? "30d" : "6h")
    .sign(getSessionSecret());
}

export async function verifySessionToken(token: string): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, getSessionSecret());
    if (
      !Number.isInteger(payload.userId) ||
      !Number.isInteger(payload.sessionVersion) ||
      typeof payload.username !== "string" ||
      typeof payload.fullName !== "string" ||
      !["admin", "doctor", "reception", "accountant", "clinic_manager"].includes(String(payload.role))
    ) {
      return null;
    }
    return payload as unknown as SessionPayload;
  } catch {
    return null;
  }
}

// Role labels in Arabic for display in the UI.
export const ROLE_LABELS: Record<Role, string> = {
  admin: "مدير النظام",
  doctor: "دكتور",
  reception: "استقبال",
  accountant: "محاسب",
  clinic_manager: "مدير العيادة",
};
