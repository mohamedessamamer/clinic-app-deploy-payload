import "server-only";

import { db } from "@/lib/db/client";
import { getClinicToday } from "@/lib/clinic-date";

const sqlNow = () => new Date().toISOString().replace("T", " ").slice(0, 19);

function twoYearsAgo() {
  const [year, month, day] = getClinicToday().split("-").map(Number);
  return `${String(year - 2).padStart(4, "0")}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

/** أرشفة من لم يكن له أي نشاط علاجي أو حجز خلال آخر سنتين. */
export async function archiveInactivePatients() {
  const cutoff = twoYearsAgo();
  await db.updateTable("patients")
    .set({ archived_at: sqlNow(), archived_by: null, archive_reason: "inactive" })
    .where("archived_at", "is", null)
    .where((eb) => eb.or([
      eb("archive_activity_at", "<=", cutoff),
      eb.and([eb("archive_activity_at", "is", null), eb("created_at", "<=", cutoff)]),
    ]))
    .where((eb) => eb.not(eb.exists(
      eb.selectFrom("visits")
        .select("visits.id")
        .whereRef("visits.patient_id", "=", "patients.id")
        .where("visits.visit_date", ">", cutoff),
    )))
    .execute();
}

/** أي حجز أو زيارة جديدة يعيد المريض للقائمة العادية ويبدأ عدّ السنتين من جديد. */
export async function reactivatePatientForCare(patientId: number) {
  if (!Number.isInteger(patientId) || patientId <= 0) return;
  await db.updateTable("patients")
    .set({ archived_at: null, archived_by: null, archive_reason: null, archive_activity_at: getClinicToday() })
    .where("id", "=", patientId)
    .execute();
}

export async function isPatientArchived(patientId: number) {
  const patient = await db.selectFrom("patients").select("archived_at").where("id", "=", patientId).executeTakeFirst();
  return Boolean(patient?.archived_at);
}

