import "server-only";
import { db } from "@/lib/db/client";
import { hasPermission } from "@/lib/permissions";
import { getClinicToday } from "@/lib/clinic-date";
import { getDoctorRoomIdsForDate } from "@/lib/schedule";
import { weekdayOf } from "@/lib/settings";
import type { SessionPayload } from "@/lib/auth";

function offsetDate(isoDate: string, days: number) {
  const date = new Date(`${isoDate}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

function addMinutes(time: string, minutes: number) {
  const [hour, minute] = time.slice(0, 5).split(":").map(Number);
  const total = hour * 60 + minute + minutes;
  return `${String(Math.floor(total / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
}

export async function canEditAppointmentSlot(session: SessionPayload, target: {
  doctorId: number;
  roomId: number;
  date: string;
  startTime: string;
  durationMinutes?: number | null;
}) {
  if (!(await hasPermission(session.userId, session.role, "schedule_edit"))) return false;
  if (session.role !== "doctor") return true;
  if (!session.doctorId) return false;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(target.date) || !/^\d{2}:\d{2}/.test(target.startTime)) return false;
  const parsedDate = new Date(`${target.date}T00:00:00Z`);
  if (Number.isNaN(parsedDate.getTime()) || parsedDate.toISOString().slice(0, 10) !== target.date) return false;
  const today = getClinicToday();
  if (target.date < today || target.date > offsetDate(today, 90)) return false;
  if (await hasPermission(session.userId, session.role, "schedule_all_rooms")) return true;
  if (target.doctorId !== session.doctorId) return false;
  const rooms = await getDoctorRoomIdsForDate(session.doctorId, target.date);
  if (!rooms.includes(target.roomId)) return false;

  const exceptional = await db.selectFrom("doctor_date_shifts").select("id")
    .where("doctor_id", "=", session.doctorId).where("room_id", "=", target.roomId).where("shift_date", "=", target.date).executeTakeFirst();
  if (exceptional) return true;
  const shifts = await db.selectFrom("doctor_weekly_shifts").select(["start_time", "end_time"])
    .where("doctor_id", "=", session.doctorId).where("room_id", "=", target.roomId).where("weekday", "=", weekdayOf(target.date)).execute();
  const start = target.startTime.slice(0, 5);
  const end = addMinutes(start, target.durationMinutes && target.durationMinutes > 0 ? target.durationMinutes : 0);
  return shifts.some((shift) => start >= shift.start_time.slice(0, 5) && end <= shift.end_time.slice(0, 5));
}
