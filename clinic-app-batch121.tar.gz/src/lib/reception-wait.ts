import "server-only";

import { db } from "@/lib/db/client";

/** تثبيت بداية انتظار الاستقبال بعد مرور ثلاث دقائق من الحضور، حتى لو دخل المريض العيادة خلالها. */
export async function confirmReceptionWaits() {
  const threshold = new Date(Date.now() - 3 * 60_000).toISOString();
  await db.updateTable("appointments")
    .set((eb) => ({ reception_wait_started_at: eb.ref("attended_at") }))
    .where("status", "=", "attended")
    .where("attended_at", "is not", null)
    .where("attended_at", "<=", threshold)
    .where("reception_wait_started_at", "is", null)
    .execute();
}
