import type { Transaction } from "kysely";
import type { Database } from "@/lib/db/types";
import { inventoryDeductionsEnabled } from "@/lib/inventory-control";

export const TUBE_TEETH = [16, 17, 26, 27, 36, 37, 46, 47] as const;
export const TUBE_6_TEETH = [16, 26, 36, 46] as const;
export const TUBE_7_TEETH = [17, 27, 37, 47] as const;

export function isTubeTooth(fdi: number): fdi is (typeof TUBE_TEETH)[number] {
  return TUBE_TEETH.includes(fdi as (typeof TUBE_TEETH)[number]);
}

export async function deductTubeTooth(trx: Transaction<Database>, input: {
  fdi: number;
  patientId: number;
  visitId?: number | null;
  createdBy: number;
  note?: string | null;
}) {
  if (!isTubeTooth(input.fdi) || !(await inventoryDeductionsEnabled(trx))) return;
  await trx.updateTable("orthodontic_tube_stock")
    .set((eb) => ({ quantity: eb("quantity", "-", 1), updated_at: new Date().toISOString() }))
    .where("fdi", "=", input.fdi)
    .execute();
  await trx.insertInto("orthodontic_tube_stock_movements").values({
    fdi: input.fdi,
    quantity: -1,
    movement_type: "ortho_use",
    patient_id: input.patientId,
    visit_id: input.visitId ?? null,
    created_by: input.createdBy,
    note: input.note ?? null,
  }).execute();
}

export async function returnTubeTooth(trx: Transaction<Database>, input: {
  fdi: number;
  patientId: number;
  visitId?: number | null;
  createdBy: number;
  note?: string | null;
}) {
  if (!isTubeTooth(input.fdi) || !(await inventoryDeductionsEnabled(trx))) return;
  let query = trx.selectFrom("orthodontic_tube_stock_movements")
    .select("id")
    .where("fdi", "=", input.fdi)
    .where("patient_id", "=", input.patientId)
    .where("movement_type", "=", "ortho_use")
    .where("undone_at", "is", null);
  if (input.visitId) query = query.where("visit_id", "=", input.visitId);
  const used = await query.orderBy("id", "desc").executeTakeFirst();
  if (!used) return;

  const now = new Date().toISOString();
  await trx.updateTable("orthodontic_tube_stock_movements")
    .set({ undone_at: now, undone_by: input.createdBy })
    .where("id", "=", used.id)
    .where("undone_at", "is", null)
    .execute();
  await trx.updateTable("orthodontic_tube_stock")
    .set((eb) => ({ quantity: eb("quantity", "+", 1), updated_at: now }))
    .where("fdi", "=", input.fdi)
    .execute();
  await trx.insertInto("orthodontic_tube_stock_movements").values({
    fdi: input.fdi,
    quantity: 1,
    movement_type: "return",
    patient_id: input.patientId,
    visit_id: input.visitId ?? null,
    created_by: input.createdBy,
    note: input.note ?? null,
  }).execute();
}
