import "server-only";
import { db } from "@/lib/db/client";

export type TaskCenterItem = {
  id: number;
  patient_id: number | null;
  patient_name: string | null;
  created_by: number;
  creator_name: string;
  recipient_type: "user" | "reception";
  recipient_user_id: number | null;
  recipient_name: string | null;
  task_text: string;
  source_type: "manual" | "referral";
  status: "open" | "completed" | "closed";
  completed_at: string | null;
  closed_at: string | null;
  created_at: string;
};

export async function getTaskCenter(userId: number, role: string): Promise<TaskCenterItem[]> {
  const rows = await db.selectFrom("tasks")
    .innerJoin("users as creator", "creator.id", "tasks.created_by")
    .leftJoin("users as recipient", "recipient.id", "tasks.recipient_user_id")
    .leftJoin("patients", "patients.id", "tasks.patient_id")
    .select([
      "tasks.id", "tasks.patient_id", "patients.full_name as patient_name", "tasks.created_by",
      "creator.full_name as creator_name", "tasks.recipient_type", "tasks.recipient_user_id",
      "recipient.full_name as recipient_name", "tasks.task_text", "tasks.source_type", "tasks.status",
      "tasks.completed_at", "tasks.closed_at", "tasks.created_at",
    ])
    .where((eb) => eb.or([
      eb("tasks.created_by", "=", userId),
      eb("tasks.recipient_user_id", "=", userId),
      ...(role === "reception" ? [eb("tasks.recipient_type", "=", "reception" as const)] : []),
    ]))
    .orderBy("tasks.created_at", "desc")
    .limit(250)
    .execute();
  return rows as TaskCenterItem[];
}

export async function autoCloseReferralTasksForAppointment(appointmentId: number, completedBy: number) {
  const appointment = await db.selectFrom("appointments")
    .select(["patient_id", "doctor_id"])
    .where("id", "=", appointmentId)
    .executeTakeFirst();
  if (!appointment) return;
  const now = new Date().toISOString();
  const pending = await db.selectFrom("tasks")
    .innerJoin("users as recipient", "recipient.id", "tasks.recipient_user_id")
    .select(["tasks.id", "tasks.referral_id"])
    .where("tasks.patient_id", "=", appointment.patient_id)
    .where("tasks.source_type", "=", "referral")
    .where("tasks.status", "!=", "closed")
    .where("recipient.doctor_id", "=", appointment.doctor_id)
    .execute();
  if (!pending.length) return;
  const ids = pending.map((row) => row.id);
  await db.updateTable("tasks").set({
    status: "closed", completed_by: completedBy, completed_at: now,
    closed_by: completedBy, closed_at: now, updated_at: now,
  }).where("id", "in", ids).execute();
  const referralIds = pending.map((row) => row.referral_id).filter((id): id is number => id != null);
  if (referralIds.length) {
    await db.updateTable("patient_referrals").set({ status: "completed", completed_by: completedBy, completed_at: now })
      .where("id", "in", referralIds).execute();
  }
}
