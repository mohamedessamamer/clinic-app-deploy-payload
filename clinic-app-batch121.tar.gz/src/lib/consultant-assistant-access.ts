import "server-only";

import { db } from "@/lib/db/client";
import { getClinicToday } from "@/lib/clinic-date";

// علاقة المساعد بالاستشاري لا تمنح صلاحية عامة للمرضى. هي تسمح فقط بفتح
// وتحرير الملف الطبي لمريض له موعد فعلي اليوم مع الاستشاري المرتبط به.
export async function getConsultantDoctorIdsForAssistant(assistantDoctorId: number): Promise<number[]> {
  const rows = await db
    .selectFrom("consultant_assistants")
    .select("consultant_doctor_id")
    .where("assistant_doctor_id", "=", assistantDoctorId)
    .execute();
  return rows.map((row) => row.consultant_doctor_id);
}

export async function assistantCanEditConsultantPatient(assistantDoctorId: number, patientId: number): Promise<boolean> {
  const consultantIds = await getConsultantDoctorIdsForAssistant(assistantDoctorId);
  if (!consultantIds.length) return false;
  const appointment = await db
    .selectFrom("appointments")
    .select("id")
    .where("patient_id", "=", patientId)
    .where("appointment_date", "=", getClinicToday())
    .where("doctor_id", "in", consultantIds)
    .where("status", "!=", "cancelled")
    .executeTakeFirst();
  return Boolean(appointment);
}

export async function getConsultantAppointmentDoctorForAssistant(assistantDoctorId: number, patientId: number, visitDate: string): Promise<number | null> {
  if (visitDate !== getClinicToday()) return null;
  const consultantIds = await getConsultantDoctorIdsForAssistant(assistantDoctorId);
  if (!consultantIds.length) return null;
  const appointment = await db
    .selectFrom("appointments")
    .select("doctor_id")
    .where("patient_id", "=", patientId)
    .where("appointment_date", "=", visitDate)
    .where("doctor_id", "in", consultantIds)
    .where("status", "!=", "cancelled")
    .orderBy("start_time")
    .executeTakeFirst();
  return appointment?.doctor_id ?? null;
}
