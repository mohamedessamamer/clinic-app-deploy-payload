"use client";

import { useState, type ReactNode } from "react";

export type ReportSubnavItem = { key: string; label: string; content: ReactNode };

export default function ReportSubnav({ items, initialKey }: { items: ReportSubnavItem[]; initialKey?: string }) {
  const [activeKey, setActiveKey] = useState(items.some((item) => item.key === initialKey) ? initialKey : items[0]?.key);
  const active = items.find((item) => item.key === activeKey) ?? items[0];
  return <div className="space-y-5"><nav className="card-3d rounded-xl p-2 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-1">{items.map((item) => <button key={item.key} type="button" onClick={() => setActiveKey(item.key)} className={`rounded-lg px-3 py-2.5 text-sm text-right transition-colors ${activeKey === item.key ? "bg-primary text-white font-medium" : "hover:bg-primary-soft"}`}>{item.label}</button>)}</nav><div className="space-y-5">{active?.content}</div></div>;
}
