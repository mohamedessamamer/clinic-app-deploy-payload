"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

export type ClinicStatusRow = {
  id: number;
  label: string;
  doctorName?: string | null;
  patient?: { name: string; service: string; href: string; enteredAt: string | null };
};

function elapsed(enteredAt: string | null, now: number) {
  if (!enteredAt) return "00:00";
  const minutes = Math.max(0, Math.floor((now - new Date(enteredAt).getTime()) / 60_000));
  return `${String(Math.floor(minutes / 60)).padStart(2, "0")}:${String(minutes % 60).padStart(2, "0")}`;
}

export default function HomeClinicStatus({ rows, showDoctor }: { rows: ClinicStatusRow[]; showDoctor: boolean }) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 30_000);
    return () => window.clearInterval(timer);
  }, []);

  return <div className="home-clinic-timeline">
    {rows.map((room) => <div key={room.id} className="home-clinic-timeline-item">
      <div className="home-clinic-label"><b>{room.label}</b>{showDoctor && room.doctorName && <span>{room.doctorName}</span>}</div>
      {room.patient ? <div className="schedule-appointment-card home-clinic-card">
        <div className="schedule-card-clinical"><Link className="schedule-card-name font-semibold inline-block cursor-pointer hover:underline" href={room.patient.href}>{room.patient.name}</Link><div className="schedule-card-service">{room.patient.service}</div></div>
        <div className="schedule-card-meta"><span className="schedule-card-status schedule-card-status--entered">دخل {elapsed(room.patient.enteredAt, now)}</span></div>
      </div> : <div className="schedule-appointment-card home-clinic-card"><span>متاح</span></div>}
    </div>)}
  </div>;
}
