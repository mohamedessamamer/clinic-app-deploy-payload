"use client";

import { useMemo, useState, useTransition } from "react";
import { editPatientBillingEntryAction } from "@/app/patients/[id]/billing/actions";
import { PAYMENT_METHODS } from "@/lib/payment-methods";
import { FOLLOWUP_SERVICE_CODE } from "@/lib/followup";

type Service = { id: number; name: string; code?: string | null };
type Doctor = { id: number; full_name: string };
type BillableInvoice = { id: number; service_name: string; visit_date: string; balance: number };

export default function EditInvoiceButton({
  invoiceId,
  patientId,
  initial,
  services,
  doctors,
  billableInvoices,
}: {
  invoiceId: number;
  patientId: number;
  initial: {
    doctorId: number | null;
    invoiceDate: string;
    paymentMethod: string | null;
    paid: number;
    serviceId: number | null;
    originalPrice: number | null;
    discountPercent: number;
    parentInvoiceId: number | null;
  };
  services: Service[];
  doctors: Doctor[];
  billableInvoices: BillableInvoice[];
}) {
  const [open, setOpen] = useState(false);
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [doctorId, setDoctorId] = useState(String(initial.doctorId ?? ""));
  const [invoiceDate, setInvoiceDate] = useState(initial.invoiceDate);
  const [paymentMethod, setPaymentMethod] = useState(initial.paymentMethod ?? "cash");
  const [paid, setPaid] = useState(String(initial.paid));
  const [serviceId, setServiceId] = useState(String(initial.serviceId ?? ""));
  const [price, setPrice] = useState(String(initial.originalPrice ?? 0));
  const [discountPercent, setDiscountPercent] = useState(String(initial.discountPercent ?? 0));
  const [targetInvoiceId, setTargetInvoiceId] = useState(String(initial.parentInvoiceId ?? ""));

  const selectedService = useMemo(
    () => services.find((service) => String(service.id) === serviceId) ?? null,
    [services, serviceId]
  );
  const isFollowup = selectedService?.code === FOLLOWUP_SERVICE_CODE;
  const eligibleTargets = useMemo(
    () => billableInvoices.filter((invoice) =>
      invoice.id !== invoiceId && (invoice.balance > 0.01 || invoice.id === initial.parentInvoiceId)
    ),
    [billableInvoices, initial.parentInvoiceId, invoiceId]
  );

  function resetForm() {
    setError(null);
    setDoctorId(String(initial.doctorId ?? ""));
    setInvoiceDate(initial.invoiceDate);
    setPaymentMethod(initial.paymentMethod ?? "cash");
    setPaid(String(initial.paid));
    setServiceId(String(initial.serviceId ?? ""));
    setPrice(String(initial.originalPrice ?? 0));
    setDiscountPercent(String(initial.discountPercent ?? 0));
    setTargetInvoiceId(String(initial.parentInvoiceId ?? ""));
  }

  function handleServiceChange(nextServiceId: string) {
    setServiceId(nextServiceId);
    const nextService = services.find((service) => String(service.id) === nextServiceId);
    if (nextService?.code !== FOLLOWUP_SERVICE_CODE) setTargetInvoiceId("");
  }

  function close() {
    if (isPending) return;
    setOpen(false);
    resetForm();
  }

  function submit() {
    setError(null);
    const formData = new FormData();
    formData.set("invoice_id", String(invoiceId));
    formData.set("patient_id", String(patientId));
    formData.set("doctor_id", doctorId);
    formData.set("invoice_date", invoiceDate);
    formData.set("payment_method", paymentMethod);
    formData.set("paid", paid);
    formData.set("service_id", serviceId);
    if (isFollowup) {
      formData.set("target_invoice_id", targetInvoiceId);
    } else {
      formData.set("price", price);
      formData.set("discount_percent", discountPercent);
    }
    startTransition(async () => {
      const result = await editPatientBillingEntryAction(formData);
      if (!result.ok) {
        setError(result.reason ?? "معرفناش نحفظ التعديل.");
        return;
      }
      setOpen(false);
    });
  }

  if (!open) {
    return (
      <button
        type="button"
        onClick={(event) => {
          event.stopPropagation();
          resetForm();
          setOpen(true);
        }}
        className="text-xs text-primary hover:underline ms-2"
      >
        تعديل
      </button>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={close}>
      <div className="card-3d rounded-xl p-5 space-y-3 w-full max-w-md bg-background" onClick={(event) => event.stopPropagation()}>
        <h3 className="font-semibold">تعديل صف الملف المالي</h3>

        <div>
          <label className="block text-xs text-muted mb-1">الخدمة</label>
          <select value={serviceId} onChange={(event) => handleServiceChange(event.target.value)} className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm">
            <option value="">اختر خدمة</option>
            {services.map((service) => <option key={service.id} value={service.id}>{service.name}</option>)}
          </select>
        </div>

        {isFollowup ? (
          <div>
            <label className="block text-xs text-muted mb-1">الخدمة الأصلية (اللي مربوطة بيها الدفعة)</label>
            {eligibleTargets.length > 0 ? (
              <select value={targetInvoiceId} onChange={(event) => setTargetInvoiceId(event.target.value)} className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm">
                <option value="">اختر خدمة</option>
                {eligibleTargets.map((invoice) => (
                  <option key={invoice.id} value={invoice.id}>
                    {invoice.service_name} — {invoice.visit_date} — المتاح {Math.max(0, invoice.balance + (invoice.id === initial.parentInvoiceId ? initial.paid : 0)).toFixed(0)} ج.م
                  </option>
                ))}
              </select>
            ) : (
              <div className="text-xs text-danger">مفيش فواتير سابقة عليها مبلغ متاح لهذا المريض.</div>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-muted mb-1">السعر الأصلي</label>
              <input type="number" step="0.01" min={0} value={price} onChange={(event) => setPrice(event.target.value)} className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
            </div>
            <div>
              <label className="block text-xs text-muted mb-1">خصم (%)</label>
              <input type="number" step="1" min={0} max={100} value={discountPercent} onChange={(event) => setDiscountPercent(event.target.value)} className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs text-muted mb-1">المدفوع</label>
            <input type="number" step="0.01" min={0} value={paid} onChange={(event) => setPaid(event.target.value)} className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">طريقة الدفع</label>
            <select value={paymentMethod} onChange={(event) => setPaymentMethod(event.target.value)} className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm">
              {PAYMENT_METHODS.map((method) => <option key={method.value} value={method.value}>{method.label}</option>)}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs text-muted mb-1">التاريخ</label>
            <input type="date" value={invoiceDate} onChange={(event) => setInvoiceDate(event.target.value)} className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">الدكتور</label>
            <select value={doctorId} onChange={(event) => setDoctorId(event.target.value)} className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm">
              <option value="">اختر دكتور</option>
              {doctors.map((doctor) => <option key={doctor.id} value={doctor.id}>{doctor.full_name}</option>)}
            </select>
          </div>
        </div>

        {error && <div className="text-xs text-danger">{error}</div>}
        <div className="flex gap-2 justify-end">
          <button type="button" onClick={close} disabled={isPending} className="rounded-md border border-border px-3 py-1.5 text-sm disabled:opacity-60">إلغاء</button>
          <button type="button" disabled={isPending} onClick={submit} className="rounded-md btn-3d-primary px-3 py-1.5 text-sm font-medium disabled:opacity-60">
            {isPending ? "جاري الحفظ..." : "حفظ"}
          </button>
        </div>
      </div>
    </div>
  );
}
