import { saveOrthoChartSummaryOptionsAction } from "@/app/settings/actions";

type Lists = { chiefComplaint: string[]; treatment: string[]; diagnosis: string[] };

// كل سطر خيار مستقل. textarea مقصودة هنا بدل واجهة ترتيب معقدة: الترتيب في
// القائمة هو ترتيب السطور كما كتبه الطبيب، والحذف يتم بمسح السطر نفسه.
export default function OrthoChartSummaryOptionsForm({ lists }: { lists: Lists }) {
  const fields: { key: keyof Lists; name: string; label: string }[] = [
    { key: "chiefComplaint", name: "chief_complaint_options", label: "Chief complaint" },
    { key: "treatment", name: "treatment_options", label: "Treatment" },
    { key: "diagnosis", name: "diagnosis_options", label: "Diagnosis" },
  ];

  return (
    <form action={saveOrthoChartSummaryOptionsAction} className="space-y-4">
      <p className="text-xs text-muted">اكتب كل اختيار في سطر منفصل. الحذف يكون بمسح السطر، وترتيب السطور هو ترتيب ظهورها في الشارت.</p>
      <div className="grid gap-4 md:grid-cols-3">
        {fields.map((field) => (
          <label key={field.key} className="space-y-1.5">
            <span className="block text-sm font-medium">{field.label}</span>
            <textarea name={field.name} defaultValue={lists[field.key].join("\n")} rows={8} placeholder="أضف اختيارًا في كل سطر" className="w-full resize-y rounded-md border border-border bg-background px-2 py-2 text-sm" />
          </label>
        ))}
      </div>
      <button type="submit" className="rounded-md btn-3d-primary px-4 py-2 text-sm">حفظ خيارات الشارت</button>
    </form>
  );
}
