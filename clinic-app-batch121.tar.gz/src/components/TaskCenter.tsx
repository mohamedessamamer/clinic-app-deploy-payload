"use client";

import Link from "next/link";
import { useEffect, useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { closeTaskAction, completeTaskAction, createTaskAction, getTaskCenterAction, getTaskRecipientsAction } from "@/app/tasks/actions";
import type { TaskCenterItem } from "@/lib/tasks";

type Recipient = { id: number; full_name: string; role: string };

export default function TaskCenter({ initialTasks, currentUserId, currentRole }: { initialTasks: TaskCenterItem[]; currentUserId: number; currentRole: string }) {
  const router = useRouter();
  const [items, setItems] = useState(initialTasks);
  const [recipients, setRecipients] = useState<Recipient[]>([]);
  const [open, setOpen] = useState(false);
  const [composing, setComposing] = useState(false);
  const [busy, startTransition] = useTransition();
  const active = useMemo(() => items.filter((item) => item.status !== "closed").sort((a, b) => Number(a.status === "completed") - Number(b.status === "completed")), [items]);
  const closed = items.filter((item) => item.status === "closed");
  const openCount = active.filter((item) => item.status === "open").length;

  useEffect(() => {
    const timer = window.setInterval(() => getTaskCenterAction().then(setItems).catch(() => undefined), 30_000);
    return () => window.clearInterval(timer);
  }, []);

  function openPanel() {
    setOpen((value) => !value);
    if (!open && !recipients.length) getTaskRecipientsAction().then(setRecipients).catch(() => undefined);
  }

  function refresh() {
    return getTaskCenterAction().then((rows) => { setItems(rows); router.refresh(); });
  }

  function create(formData: FormData) {
    startTransition(async () => {
      const recipient = String(formData.get("recipient") || "reception");
      const result = await createTaskAction({
        taskText: String(formData.get("task_text") || ""),
        recipientType: recipient === "reception" ? "reception" : "user",
        recipientUserId: recipient === "reception" ? null : Number(recipient),
      });
      if (!result.ok) return window.alert(result.reason || "تعذر حفظ المهمة.");
      setComposing(false);
      await refresh();
    });
  }

  function act(action: (id: number) => Promise<{ ok: boolean; reason?: string }>, id: number) {
    startTransition(async () => {
      const result = await action(id);
      if (!result.ok) return window.alert(result.reason || "تعذر حفظ الإجراء.");
      await refresh();
    });
  }

  return <div className="relative clinic-notifications">
    <button type="button" onClick={openPanel} className="clinic-notification-trigger" title="المهام" aria-label="المهام">☑️<span className="absolute -top-1.5 -left-1.5 h-4 min-w-4 px-1 rounded-full bg-red-600 text-white text-[10px] leading-4 font-bold" hidden={!openCount}>{openCount > 99 ? "99+" : openCount}</span></button>
    {open && <div className="clinic-notifications-panel absolute z-50 left-0 mt-2 w-[min(28rem,calc(100vw-2rem))] max-h-[80vh] overflow-y-auto card-3d rounded-xl p-3 shadow-xl text-right">
      <div className="flex items-center justify-between gap-2 mb-2"><h2 className="font-semibold">المهام</h2><button type="button" onClick={() => setComposing((value) => !value)} className="rounded-md btn-3d-primary px-3 py-1.5 text-xs">+ مهمة جديدة</button></div>
      {composing && <form action={create} className="mb-3 space-y-2 rounded-lg border border-border bg-primary-soft/30 p-3"><textarea name="task_text" required maxLength={2000} rows={3} placeholder="اكتب المهمة المطلوبة" className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" /><select name="recipient" defaultValue="reception" className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"><option value="reception">فريق الاستقبال</option>{recipients.map((user) => <option key={user.id} value={user.id}>{user.full_name}</option>)}</select><button disabled={busy} className="rounded-md border border-primary px-3 py-1.5 text-sm text-primary disabled:opacity-60">إرسال المهمة</button></form>}
      {!active.length ? <p className="py-5 text-center text-sm text-muted">لا توجد مهام حالية.</p> : <div className="space-y-2">{active.map((item) => {
        const canComplete = item.status === "open" && (item.recipient_user_id === currentUserId || (item.recipient_type === "reception" && currentRole === "reception"));
        const canClose = item.status === "completed" && item.created_by === currentUserId;
        return <article key={item.id} className={`rounded-lg border p-3 text-sm ${item.status === "completed" ? "border-emerald-400 bg-emerald-50 text-emerald-950" : "border-border"}`}><div className="flex flex-wrap justify-between gap-2"><div><strong>{item.creator_name}</strong>{item.patient_id && <> · <Link href={`/patients/${item.patient_id}`} className="font-medium text-primary hover:underline">{item.patient_name || "فتح ملف المريض"}</Link></>}</div><span className="text-xs">إلى: {item.recipient_type === "reception" ? "فريق الاستقبال" : item.recipient_name}</span></div><p className="mt-1 whitespace-pre-wrap leading-5">{item.task_text}</p><p className="mt-1 text-[11px] text-muted">{item.created_at}{item.completed_at ? ` · تم التنفيذ ${item.completed_at}` : ""}</p>{canComplete && <button disabled={busy} onClick={() => act(completeTaskAction, item.id)} className="mt-2 rounded-md border border-primary px-2 py-1 text-xs text-primary">تم التنفيذ</button>}{canClose && <button disabled={busy} onClick={() => act(closeTaskAction, item.id)} className="mt-2 rounded-md bg-emerald-700 px-2 py-1 text-xs text-white">إغلاق المهمة</button>}</article>;
      })}</div>}
      {closed.length > 0 && <details className="mt-3 border-t border-border pt-2"><summary className="cursor-pointer text-xs text-muted">أرشيف المهام المغلقة ({closed.length})</summary><div className="mt-2 space-y-2">{closed.map((item) => <article key={item.id} className="rounded-lg border border-border p-2 text-xs opacity-75"><strong>{item.creator_name}</strong>{item.patient_id && <> · <Link href={`/patients/${item.patient_id}`} className="text-primary hover:underline">{item.patient_name}</Link></>}<p className="mt-1 whitespace-pre-wrap">{item.task_text}</p></article>)}</div></details>}
    </div>}
  </div>;
}
