"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { getAttendanceQueueAction, type AttendanceQueueData } from "@/app/attendance-queue/actions";

export default function AttendanceQueue() {
  const [open, setOpen] = useState(false);
  const [data, setData] = useState<AttendanceQueueData>({ queue: [], entered: [] });
  const [error, setError] = useState(false);
  const requestRunning = useRef(false);
  const mounted = useRef(true);

  const refresh = useCallback(async () => {
    if (requestRunning.current) return;
    requestRunning.current = true;
    try {
      const nextRooms = await getAttendanceQueueAction();
      if (!mounted.current) return;
      setData(nextRooms);
      setError(false);
    } catch {
      if (mounted.current) setError(true);
    } finally {
      requestRunning.current = false;
    }
  }, []);

  useEffect(() => {
    mounted.current = true;
    void refresh();
    const timer = window.setInterval(() => void refresh(), 5000);
    return () => {
      mounted.current = false;
      window.clearInterval(timer);
    };
  }, [refresh]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  useEffect(() => {
    if (!open) return;
    const timer = window.setTimeout(() => setOpen(false), 20_000);
    return () => window.clearTimeout(timer);
  }, [open]);

  const total = data.queue.length;

  function toggle() {
    setOpen((current) => !current);
    void refresh();
  }

  return (
    <>
      <button
        type="button"
        onClick={toggle}
        className="fixed z-40 top-[4.35rem] left-5 grid h-12 w-12 place-items-center rounded-full bg-amber-500 text-white shadow-lg shadow-amber-500/30 hover:bg-amber-600"
        title={open ? "إغلاق ترتيب الحضور" : "ترتيب الحضور"}
        aria-label={open ? "إغلاق ترتيب الحضور" : "فتح ترتيب الحضور"}
        aria-expanded={open}
      >
        <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6">
          <path d="M9 6h11M9 12h11M9 18h11" />
          <path d="M4 6h.01M4 12h.01M4 18h.01" />
        </svg>
        {total > 0 && (
          <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 grid place-items-center rounded-full bg-red-600 border-2 border-surface text-[10px] font-bold">
            {total > 99 ? "99+" : total}
          </span>
        )}
      </button>

      {open && (
        <section
          className="fixed z-50 top-[4.35rem] left-20 w-[min(38rem,calc(100vw-6rem))] max-h-[min(28rem,calc(100vh-7rem))] card-3d rounded-xl shadow-2xl overflow-hidden"
          dir="rtl"
          aria-label="ترتيب المرضى بالحضور"
        >
          <div className="max-h-[22rem] overflow-y-auto bg-background">
            {error && <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">تعذر تحديث ترتيب الحضور الآن.</p>}
            {!error && data.queue.length === 0 && <p className="py-7 text-center text-sm text-muted">لا يوجد مرضى في الانتظار حاليًا.</p>}
            <ol className="grid grid-cols-1 sm:grid-cols-3 gap-x-4 gap-y-2 bg-[#d8c9be] px-4 py-4">{data.queue.map((patient, index) => <li key={patient.appointmentId} className={`flex items-center gap-1.5 text-sm ${index === 0 ? "font-bold text-amber-800" : "text-foreground"}`}><span className={`grid h-5 min-w-5 place-items-center rounded-full px-1 text-[11px] ${index === 0 ? "bg-amber-500 text-white" : "bg-primary-soft text-primary-dark"}`}>{index + 1}</span><span>{patient.patientName}</span></li>)}</ol>
            <div className="flex flex-wrap gap-x-5 gap-y-2 px-4 py-3 bg-surface text-sm">{data.entered.map((item) => <span key={item.roomId}><b>{item.roomName}:</b> {item.patientName}</span>)}{data.entered.length === 0 && <span className="text-muted">لا يوجد مريض داخل العيادات الآن.</span>}</div>
          </div>
        </section>
      )}
    </>
  );
}
