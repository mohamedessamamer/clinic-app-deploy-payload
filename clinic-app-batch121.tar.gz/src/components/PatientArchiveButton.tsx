"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { setPatientArchiveAction } from "@/app/patients/[id]/actions";

export default function PatientArchiveButton({ patientId, archived, hasDebt = false }: { patientId: number; archived: boolean; hasDebt?: boolean }) {
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const label = archived ? "إلغاء الأرشفة" : "أرشفة";
  return <button type="button" disabled={pending} onClick={() => {
    const warning = archived
      ? "إلغاء أرشفة المريض وإعادته للقائمة العادية؟"
      : `${hasDebt ? "تنبيه: يوجد رصيد على المريض. " : ""}أرشفة المريض ستوقف فقط الرسائل التي تبدأها العيادة؛ سيظل الحجز والعلاج متاحين. متابعة؟`;
    if (!window.confirm(warning)) return;
    startTransition(async () => { const result = await setPatientArchiveAction(patientId, !archived); if (!result.ok) window.alert(result.error || "تعذر تحديث الأرشيف"); router.refresh(); });
  }} className={`text-xs ${archived ? "text-primary" : "text-amber-700"} disabled:opacity-50`}>{pending ? "جارٍ الحفظ…" : label}</button>;
}
