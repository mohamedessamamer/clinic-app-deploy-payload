"use client";

import { useMemo, useState } from "react";
import MedicalTimeline from "@/components/MedicalTimeline";
import VisitsTable from "@/components/VisitsTable";

type Visit = {
  id: number;
  visit_date: string;
  service_id: number | null;
  service_name: string | null;
  service_name_en?: string | null;
  notes: string | null;
  doctor_name: string | null;
  primary_doctor_name?: string | null;
  created_at: string;
  ortho_visit_id?: number | null;
  primary_doctor_id?: number | null;
  performing_doctor_id?: number | null;
};

type Service = { id: number; name: string; name_en?: string | null; code?: string | null; default_price?: number | null };
type Doctor = { id: number; full_name: string };
type ServiceTypeFilter = "all" | "general" | "ortho";

export default function MedicalVisitHistory({
  patientId,
  visits,
  services,
  doctors,
  canEditMedicalRecord,
  canEditOldVisits,
  canDeleteVisits,
  canEditAssistantDoctor,
  currentDoctorId,
  purposeContextLabel,
}: {
  patientId: number;
  visits: Visit[];
  services: Service[];
  doctors: Doctor[];
  canEditMedicalRecord: boolean;
  canEditOldVisits: boolean;
  canDeleteVisits: boolean;
  canEditAssistantDoctor: boolean;
  currentDoctorId: number | null;
  purposeContextLabel: string | null;
}) {
  const [serviceType, setServiceType] = useState<ServiceTypeFilter>("all");
  const [doctorId, setDoctorId] = useState("all");

  const patientDoctors = useMemo(() => {
    const byId = new Map<number, string>();
    for (const visit of visits) {
      if (visit.primary_doctor_id != null) {
        byId.set(visit.primary_doctor_id, visit.primary_doctor_name || `Doctor #${visit.primary_doctor_id}`);
      }
      if (visit.performing_doctor_id != null) {
        byId.set(visit.performing_doctor_id, visit.doctor_name || `Doctor #${visit.performing_doctor_id}`);
      }
    }
    return [...byId.entries()]
      .map(([id, full_name]) => ({ id, full_name }))
      .sort((a, b) => a.full_name.localeCompare(b.full_name, "en"));
  }, [visits]);

  const filteredVisits = useMemo(() => visits.filter((visit) => {
    const matchesType = serviceType === "all"
      || (serviceType === "ortho" ? visit.ortho_visit_id != null : visit.ortho_visit_id == null);
    const selectedDoctorId = doctorId === "all" ? null : Number(doctorId);
    const matchesDoctor = selectedDoctorId == null
      || visit.primary_doctor_id === selectedDoctorId
      || visit.performing_doctor_id === selectedDoctorId;
    return matchesType && matchesDoctor;
  }), [doctorId, serviceType, visits]);

  return (
    <>
      <section id="patient-summary" className="card-3d rounded-2xl p-4 space-y-3 scroll-mt-6">
        <div className="flex items-end justify-between gap-3 flex-wrap">
          <h2 className="font-semibold text-lg">Medical visit history</h2>
          <div className="flex items-end gap-2 flex-wrap">
            <label className="text-xs text-muted">
              <span className="block mb-1">Service type</span>
              <select value={serviceType} onChange={(event) => setServiceType(event.target.value as ServiceTypeFilter)} className="rounded-md border border-border bg-background px-2 py-1.5 text-sm text-foreground">
                <option value="all">All services</option>
                <option value="general">General</option>
                <option value="ortho">Ortho</option>
              </select>
            </label>
            <label className="text-xs text-muted">
              <span className="block mb-1">Doctor</span>
              <select value={doctorId} onChange={(event) => setDoctorId(event.target.value)} className="rounded-md border border-border bg-background px-2 py-1.5 text-sm text-foreground min-w-44">
                <option value="all">All doctors</option>
                {patientDoctors.map((doctor) => <option key={doctor.id} value={doctor.id}>{doctor.full_name}</option>)}
              </select>
            </label>
            <span className="text-xs text-muted pb-2">{filteredVisits.length} visit{filteredVisits.length === 1 ? "" : "s"}</span>
          </div>
        </div>
        <MedicalTimeline visits={filteredVisits} />
      </section>

      <section id="medical-visits" className="card-3d rounded-2xl p-4 space-y-4 scroll-mt-6">
        <h2 className="font-semibold">Medical visits</h2>
        {purposeContextLabel && <div className="text-sm bg-primary-soft text-primary-dark rounded-md px-3 py-2">{purposeContextLabel}</div>}
        <VisitsTable
          patientId={patientId}
          visits={filteredVisits}
          services={services}
          doctors={doctors}
          canEditMedicalRecord={canEditMedicalRecord}
          canEditOldVisits={canEditOldVisits}
          canDeleteVisits={canDeleteVisits}
          canEditAssistantDoctor={canEditAssistantDoctor}
          currentDoctorId={currentDoctorId}
          language="en"
          emptyMessage={visits.length > 0 ? "No visits match the selected filters." : undefined}
        />
      </section>
    </>
  );
}
