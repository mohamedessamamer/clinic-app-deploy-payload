"use client";

import Link from "next/link";
import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { updateAppointmentStatusAction } from "@/app/appointments/actions";

export type HomeAppointment = { id: number; doctorName: string; patientName: string; service: string; href: string; status: "booked" | "attended"; startTime: string; attendedAt: string | null };

function elapsed(value: string | null, now: number) {
  if (!value) return "00:00";
  const minutes = Math.max(0, Math.floor((now - new Date(value).getTime()) / 60_000));
  return `${String(Math.floor(minutes / 60)).padStart(2, "0")}:${String(minutes % 60).padStart(2, "0")}`;
}

export default function HomeAppointments({ items, canEdit, canMarkDone }: { items: HomeAppointment[]; canEdit: boolean; canMarkDone: boolean }) {
  const [now, setNow] = useState(() => Date.now());
  const [menuId, setMenuId] = useState<number | null>(null);
  const [, startTransition] = useTransition();
  const router = useRouter();
  useEffect(() => { const timer = window.setInterval(() => setNow(Date.now()), 30_000); return () => window.clearInterval(timer); }, []);
  function setStatus(id: number, status: "attended" | "done") {
    const data = new FormData(); data.set("id", String(id)); data.set("status", status);
    startTransition(async () => { await updateAppointmentStatusAction(data); router.refresh(); });
    setMenuId(null);
  }
  return <div className="home-clinic-timeline home-appointments-timeline">
    {items.map((item) => <div key={item.id} className="home-clinic-timeline-item">
      <div className="schedule-appointment-card home-appointment-card" onClick={(event) => {
        if (!canEdit || item.status !== "booked" || (event.target as HTMLElement).closest("a,button")) return;
        setStatus(item.id, "attended");
      }} onContextMenu={(event) => { if (!canEdit && !canMarkDone) return; event.preventDefault(); setMenuId(item.id); }}>
        <div className="schedule-card-clinical"><Link href={item.href} className="schedule-card-name font-semibold inline-block cursor-pointer hover:underline" onClick={(event) => event.stopPropagation()}>{item.patientName}</Link><Link href={item.href} className="schedule-card-service inline-block cursor-pointer" onClick={(event) => event.stopPropagation()}>{item.service}</Link></div>
        <div className="schedule-card-meta"><span className={`schedule-card-status schedule-card-status--${item.status}`}>{item.status === "attended" ? `حضر ${elapsed(item.attendedAt, now)}` : item.startTime}</span><span className="schedule-card-doctor">{item.doctorName}</span></div>
        {menuId === item.id && <div className="home-appointment-menu" onClick={(event) => event.stopPropagation()}>{canEdit && item.status === "booked" && <button type="button" onClick={() => setStatus(item.id, "attended")}>حضر</button>}{canMarkDone && <button type="button" onClick={() => setStatus(item.id, "done")}>تم</button>}<button type="button" onClick={() => setMenuId(null)}>إغلاق</button></div>}
      </div>
    </div>)}
  </div>;
}
