"use client";

import { useMemo, useState, useTransition, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { receiveOrthodonticTubeCaseAction, receiveOrthodonticTubeRefillAction, setOrthodonticTubeCountAction } from "@/app/inventory/actions";
import { TUBE_6_TEETH, TUBE_7_TEETH, TUBE_TEETH } from "@/lib/ortho/tube-stock";

type Cell = { fdi: number; quantity: number };
// نفس اتجاه الفك في جرد الـBrackets: يمين المريض يظهر في يسار الرسم.
const TUBE_ROWS = [
  { label: "علوي", teeth: [27, 26, 17, 16] },
  { label: "سفلي", teeth: [37, 36, 47, 46] },
] as const;

export default function OrthodonticTubeStock({ cells, canEditCatalog }: { cells: Cell[]; canEditCatalog: boolean }) {
  const [isPending, startTransition] = useTransition();
  const [localStock, setLocalStock] = useState<Record<number, number>>({});
  const router = useRouter();
  const stock = useMemo(() => new Map(cells.map((cell) => [cell.fdi, localStock[cell.fdi] ?? cell.quantity])), [cells, localStock]);

  function submitCase(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const formData = new FormData(form);
    const tubeType = String(formData.get("tube_type"));
    const cases = Number(formData.get("cases"));
    const teeth = tubeType === "6" ? TUBE_6_TEETH : TUBE_7_TEETH;
    if (!Number.isInteger(cases) || cases <= 0) return;
    startTransition(async () => {
      await receiveOrthodonticTubeCaseAction(formData);
      setLocalStock((current) => {
        const next = { ...current };
        for (const fdi of teeth) next[fdi] = (next[fdi] ?? stock.get(fdi) ?? 0) + cases;
        return next;
      });
      form.reset();
      router.refresh();
    });
  }

  function submitRefill(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const formData = new FormData(form);
    const fdi = Number(formData.get("fdi"));
    const quantity = Number(formData.get("quantity"));
    if (!TUBE_TEETH.includes(fdi as (typeof TUBE_TEETH)[number]) || !Number.isInteger(quantity) || quantity <= 0) return;
    startTransition(async () => {
      await receiveOrthodonticTubeRefillAction(formData);
      setLocalStock((current) => ({ ...current, [fdi]: (current[fdi] ?? stock.get(fdi) ?? 0) + quantity }));
      form.reset();
      router.refresh();
    });
  }

  function submitCount(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const fdi = Number(formData.get("fdi"));
    const quantity = Number(formData.get("quantity"));
    if (!TUBE_TEETH.includes(fdi as (typeof TUBE_TEETH)[number]) || !Number.isInteger(quantity) || quantity < 0) return;
    startTransition(async () => {
      await setOrthodonticTubeCountAction(formData);
      setLocalStock((current) => ({ ...current, [fdi]: quantity }));
      router.refresh();
    });
  }

  return <section className="card-3d rounded-xl p-5 space-y-4">
    <div><h2 className="font-semibold">Tubes — جرد الأسنان</h2><p className="text-xs text-muted mt-1">من غير شركات. حالة Tube 6 تضيف تيوب للأسنان 16 و26 و36 و46، وحالة Tube 7 تضيف للأسنان 17 و27 و37 و47.</p></div>
    <div className="grid gap-3 md:grid-cols-2">
      {["6", "7"].map((tubeType) => <form key={tubeType} onSubmit={submitCase} className="flex items-end gap-2 rounded-lg border border-border p-3"><input type="hidden" name="tube_type" value={tubeType} /><label className="flex-1 text-sm"><span className="block text-xs text-muted mb-1">إضافة حالة Tube {tubeType}</span><input name="cases" type="number" min="1" step="1" required placeholder="عدد الحالات" className="w-full rounded-md border border-border bg-background px-2 py-1.5" /></label><button disabled={isPending} className="rounded-md btn-3d-primary px-3 py-1.5 text-sm disabled:opacity-60">إضافة</button></form>)}
    </div>
    <div className="overflow-x-auto" dir="ltr"><div className="min-w-[620px] space-y-2">{TUBE_ROWS.map((row) => <div key={row.label} className="grid grid-cols-[4.5rem_repeat(4,minmax(0,1fr))] items-center gap-1"><strong className="text-right text-sm" dir="rtl">{row.label}</strong>{row.teeth.map((fdi) => <div key={fdi} className="rounded-md border border-border bg-background p-1 text-center"><span className="block text-xs text-muted mb-1">{fdi}</span>{canEditCatalog ? <form onSubmit={submitCount} className="flex justify-center gap-1"><input type="hidden" name="fdi" value={fdi} /><input name="quantity" type="number" min="0" step="1" value={stock.get(fdi) ?? 0} onChange={(event) => setLocalStock((current) => ({ ...current, [fdi]: Math.max(0, Number(event.target.value) || 0) }))} aria-label={`رصيد التيوب للسن ${fdi}`} className="w-12 rounded border border-border bg-background px-1 py-1 text-center text-sm" /><button disabled={isPending} title="حفظ الجرد اليدوي" className="text-xs text-primary">حفظ</button></form> : <b>{stock.get(fdi) ?? 0}</b>}</div>)}</div>)}</div></div>
    <form onSubmit={submitRefill} className="flex flex-wrap items-end gap-2 rounded-lg border border-border bg-primary-soft/30 p-3"><label className="text-sm"><span className="block text-xs text-muted mb-1">Refill لسن</span><select name="fdi" required defaultValue="" className="rounded-md border border-border bg-background px-2 py-1.5"><option value="" disabled>اختر السن</option>{TUBE_TEETH.map((fdi) => <option key={fdi} value={fdi}>{fdi}</option>)}</select></label><label className="text-sm"><span className="block text-xs text-muted mb-1">العدد</span><input name="quantity" type="number" min="1" step="1" required className="w-24 rounded-md border border-border bg-background px-2 py-1.5" /></label><button disabled={isPending} className="rounded-md border border-primary px-3 py-1.5 text-sm text-primary disabled:opacity-60">إضافة Refill</button></form>
  </section>;
}
