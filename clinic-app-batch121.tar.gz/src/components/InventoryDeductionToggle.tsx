"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { setInventoryDeductionsEnabledAction } from "@/app/inventory/actions";

export default function InventoryDeductionToggle({ enabled, canToggle }: { enabled: boolean; canToggle: boolean }) {
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState("");
  const router = useRouter();

  function toggle() {
    const next = !enabled;
    const message = next
      ? "هل أنت متأكد من تشغيل الخصم التلقائي من كل المخزن؟ لن تُخصم الزيارات السابقة بأثر رجعي."
      : "هل أنت متأكد من إيقاف الخصم التلقائي من كل المخزن؟ ستستمر الزيارات بدون تغيير الأرصدة.";
    if (!window.confirm(message)) return;
    setError("");
    startTransition(async () => {
      const result = await setInventoryDeductionsEnabledAction(next);
      if (!result.ok) return setError(result.reason ?? "تعذر تغيير حالة الخصم.");
      router.refresh();
    });
  }

  return <section className={`rounded-xl border p-4 ${enabled ? "border-emerald-300 bg-emerald-50" : "border-amber-300 bg-amber-50"}`}>
    <div className="flex flex-wrap items-center justify-between gap-3">
      <div>
        <h2 className="font-semibold text-slate-900">خصم المخزن: {enabled ? "يعمل" : "متوقف"}</h2>
        <p className="mt-1 text-xs text-slate-700">يشمل المستهلكات العامة وخامات التقويم والبراكت والـTubes. الجرد اليدوي والتوريدات يعملان في الحالتين.</p>
      </div>
      {canToggle && <button type="button" disabled={isPending} onClick={toggle} className={`rounded-md px-4 py-2 text-sm font-semibold text-white disabled:opacity-60 ${enabled ? "bg-amber-600" : "bg-emerald-700"}`}>{isPending ? "جارٍ الحفظ…" : enabled ? "إيقاف الخصم" : "تشغيل الخصم"}</button>}
    </div>
    {error && <p className="mt-2 text-sm text-red-700">{error}</p>}
  </section>;
}
