"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { inventoryDeductionsEnabled } from "@/lib/inventory-control";
import { getSession } from "@/lib/session";

// نفس قيود تعديل الملف الطبي العادي بالظبط (دكتور + أدمن + مدير عيادة) — شارت
// التقويم منفصل مكانيًا عن سجل الزيارات بس نفس منطق الصلاحيات، بقرار صريح من
// المستخدم. شوف canEditMedicalRecordFor في src/app/patients/[id]/actions.ts.
function canEditMedicalRecordFor(role: string | undefined): boolean {
  return role === "doctor" || role === "admin" || role === "clinic_manager";
}

function num(fd: FormData, key: string): number | null {
  const raw = fd.get(key);
  if (raw == null || raw === "") return null;
  const n = Number(raw);
  return Number.isFinite(n) ? n : null;
}

function str(fd: FormData, key: string): string | null {
  const raw = String(fd.get(key) ?? "").trim();
  return raw || null;
}

function jsonArray(fd: FormData, key: string): string | null {
  const raw = String(fd.get(key) ?? "");
  try {
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) return JSON.stringify(parsed);
  } catch {
    /* ignore */
  }
  return null;
}

// ملاحظات الأسنان (tooth_comments) — JSON object نصي {"UR6": "..."} بييجي من
// اللوحة التفصيلية لكل سن في الشارت الموحّد. بنشيل أي مفتاح نصه فاضي قبل الحفظ.
function jsonStringObject(fd: FormData, key: string): string | null {
  const raw = String(fd.get(key) ?? "");
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      const cleaned: Record<string, string> = {};
      for (const [k, v] of Object.entries(parsed)) {
        if (typeof v === "string" && v.trim()) cleaned[k] = v.trim();
      }
      if (Object.keys(cleaned).length > 0) return JSON.stringify(cleaned);
    }
  } catch {
    /* ignore */
  }
  return null;
}

// شارت التقويم سجل واحد بس لكل مريض (patient_id UNIQUE) — أول حفظ بيعمل insert،
// أي حفظ بعد كده بيحدّث نفس الصف (upsert). بيتملى/بيتعدّل مرة واحدة عادةً وقت
// بداية علاج التقويم، بس مفيش قفل يمنع التعديل بعدين لو المستخدم محتاج يصحح حاجة.
export async function saveOrthodonticChartAction(formData: FormData) {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return;

  const patientId = Number(formData.get("patient_id"));
  if (!patientId) return;

  const patient = await db.selectFrom("patients").select(["id"]).where("id", "=", patientId).executeTakeFirst();
  if (!patient) return;

  const sexRaw = str(formData, "sex");
  const sex: "male" | "female" | null = sexRaw === "male" || sexRaw === "female" ? sexRaw : null;

  const values = {
    patient_id: patientId,
    sex,
    prescription: str(formData, "prescription"),
    chief_complaint: str(formData, "chief_complaint"),
    past_medical_history: str(formData, "past_medical_history"),
    missing_teeth: jsonArray(formData, "missing_teeth"),
    antero_posterior: str(formData, "antero_posterior") as "class1" | "class2" | "class3" | null,
    facial_height: str(formData, "facial_height") as "increased" | "average" | "decreased" | null,
    mx_incisor_inclination: str(formData, "mx_incisor_inclination") as "proclined" | "average" | "retroclined" | null,
    mn_incisor_inclination: str(formData, "mn_incisor_inclination") as "proclined" | "average" | "retroclined" | null,
    molar_relation_right: str(formData, "molar_relation_right") as "class1" | "class2" | "class3" | null,
    molar_relation_left: str(formData, "molar_relation_left") as "class1" | "class2" | "class3" | null,
    overbite: str(formData, "overbite") as "open_bite" | "average" | "deep_bite" | null,
    overjet: str(formData, "overjet") as "increased" | "average" | "decreased" | null,
    midline_upper_direction: str(formData, "midline_upper_direction") as "right" | "left" | null,
    midline_upper_mm: num(formData, "midline_upper_mm"),
    midline_lower_direction: str(formData, "midline_lower_direction") as "right" | "left" | null,
    midline_lower_mm: num(formData, "midline_lower_mm"),
    space_upper_type: str(formData, "space_upper_type") as "crowding" | "spacing" | null,
    space_upper_mm: num(formData, "space_upper_mm"),
    space_lower_type: str(formData, "space_lower_type") as "crowding" | "spacing" | null,
    space_lower_mm: num(formData, "space_lower_mm"),
    sna_case: num(formData, "sna_case"),
    snb_case: num(formData, "snb_case"),
    anb_case: num(formData, "anb_case"),
    mma_case: num(formData, "mma_case"),
    u1_pp_case: num(formData, "u1_pp_case"),
    l1_mp_case: num(formData, "l1_mp_case"),
    nasolabial_case: num(formData, "nasolabial_case"),
    nasolabial_angle: str(formData, "nasolabial_angle") as "acute" | "average" | "obtuse" | null,
    lips: str(formData, "lips") as "competent" | "incompetent" | null,
    extraction_choice: str(formData, "extraction_choice") as "extraction" | "non_extraction" | null,
    extraction_teeth: jsonArray(formData, "extraction_teeth"),
    anchorage: str(formData, "anchorage") as "minimal" | "moderate" | "maximum" | null,
    anchorage_note: str(formData, "anchorage_note"),
    hints: str(formData, "hints"),
    tooth_comments: jsonStringObject(formData, "tooth_comments"),
    created_by: session!.userId,
    updated_by: session!.userId,
  };

  const existing = await db
    .selectFrom("orthodontic_charts")
    .select(["id"])
    .where("patient_id", "=", patientId)
    .executeTakeFirst();

  if (existing) {
    const { created_by, ...updateValues } = values;
    await db
      .updateTable("orthodontic_charts")
      .set({ ...updateValues, updated_at: new Date().toISOString() })
      .where("patient_id", "=", patientId)
      .execute();
  } else {
    await db.insertInto("orthodontic_charts").values(values).execute();
  }

  revalidatePath(`/patients/${patientId}/orthodontics`);
  revalidatePath(`/patients/${patientId}`);
}

async function ensureChartRow(patientId: number, userId: number) {
  const existing = await db
    .selectFrom("orthodontic_charts")
    .select(["id"])
    .where("patient_id", "=", patientId)
    .executeTakeFirst();
  if (existing) return;
  await db
    .insertInto("orthodontic_charts")
    .values({ patient_id: patientId, created_by: userId, updated_by: userId })
    .execute();
}

// تركيب التقويم (bonding) لفك واحد — بيحصل مرة واحدة بس لكل فك (لو bonding_*_date
// متسجل بالفعل، الأكشن بيرفض ومايعملش حاجة — تحقق حقيقي في السيرفر، مش بس زرار
// مختفي في الواجهة). بيخصم من المخزون فعليًا وقت التسجيل (براكت + تيوب، جوه
// transaction واحدة مع تحديث الشارت نفسه).
export async function confirmBondingAction(formData: FormData) {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const patientId = Number(formData.get("patient_id"));
  const arch = String(formData.get("arch") || "");
  if (!patientId || (arch !== "upper" && arch !== "lower")) return { ok: false, reason: "بيانات ناقصة" };

  const bracketItemId = num(formData, "bracket_item_id");
  const bracketQty = num(formData, "bracket_qty") ?? 0;
  const tubeItemId = num(formData, "tube_item_id");
  const tubeQty = num(formData, "tube_qty") ?? 0;
  const notBondedTeeth = jsonArray(formData, "not_bonded_teeth");
  const prescription = str(formData, "prescription");

  await ensureChartRow(patientId, session!.userId);

  const existing = await db
    .selectFrom("orthodontic_charts")
    .selectAll()
    .where("patient_id", "=", patientId)
    .executeTakeFirst();
  if (!existing) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const dateField = arch === "upper" ? "bonding_upper_date" : "bonding_lower_date";
  if (existing[dateField]) {
    return { ok: false, reason: `تركيب الفك ${arch === "upper" ? "العلوي" : "السفلي"} اتسجل بالفعل قبل كده` };
  }

  await db.transaction().execute(async (trx) => {
    await trx
      .updateTable("orthodontic_charts")
      .set({
        prescription: prescription ?? existing.prescription,
        ...(arch === "upper"
          ? {
              bonding_upper_bracket_item_id: bracketItemId,
              bonding_upper_bracket_qty: bracketQty,
              bonding_upper_tube_item_id: tubeItemId,
              bonding_upper_tube_qty: tubeQty,
              bonding_upper_date: new Date().toISOString(),
              bonding_upper_not_bonded_teeth: notBondedTeeth,
            }
          : {
              bonding_lower_bracket_item_id: bracketItemId,
              bonding_lower_bracket_qty: bracketQty,
              bonding_lower_tube_item_id: tubeItemId,
              bonding_lower_tube_qty: tubeQty,
              bonding_lower_date: new Date().toISOString(),
              bonding_lower_not_bonded_teeth: notBondedTeeth,
            }),
        updated_by: session!.userId,
        updated_at: new Date().toISOString(),
      })
      .where("patient_id", "=", patientId)
      .execute();

    const deductionsEnabled = await inventoryDeductionsEnabled(trx);
    if (deductionsEnabled && bracketItemId && bracketQty > 0) {
      await trx
        .updateTable("inventory_items")
        .set({ quantity: (eb) => eb("quantity", "-", bracketQty) })
        .where("id", "=", bracketItemId)
        .execute();
    }
    if (deductionsEnabled && tubeItemId && tubeQty > 0) {
      await trx
        .updateTable("inventory_items")
        .set({ quantity: (eb) => eb("quantity", "-", tubeQty) })
        .where("id", "=", tubeItemId)
        .execute();
    }
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  revalidatePath("/inventory");
  return { ok: true };
}

// علّم/شيل علامة "براكت مكسور دلوقتي" على سن معيّن — علم حالة بس، مفيش تأثير
// على المخزون. بيتقفل تلقائيًا (يتشال من broken_teeth) لما يتسجل ريبوندينج
// على نفس السن (شوف confirmRebondingAction تحت).
export async function toggleBrokenToothAction(formData: FormData) {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return;

  const patientId = Number(formData.get("patient_id"));
  const toothId = str(formData, "tooth_id");
  if (!patientId || !toothId) return;

  await ensureChartRow(patientId, session!.userId);
  const existing = await db
    .selectFrom("orthodontic_charts")
    .select(["broken_teeth"])
    .where("patient_id", "=", patientId)
    .executeTakeFirst();
  if (!existing) return;

  const current: string[] = existing.broken_teeth ? JSON.parse(existing.broken_teeth) : [];
  const next = current.includes(toothId) ? current.filter((t) => t !== toothId) : [...current, toothId];

  await db
    .updateTable("orthodontic_charts")
    .set({ broken_teeth: next.length ? JSON.stringify(next) : null, updated_by: session!.userId, updated_at: new Date().toISOString() })
    .where("patient_id", "=", patientId)
    .execute();

  revalidatePath(`/patients/${patientId}/orthodontics`);
}

// تسجيل عملية ريبوندينج على سن معيّن — تكراري (كل دوسة بترفع الرقم فوق السن
// بواحد)، بيخصم براكت واحد من الصنف المختار من المخزون، وبيشيل السن من
// broken_teeth (بقى متركّب تاني). السعر يدوي لحد دلوقتي (المستخدم اختار كده
// صراحة) — مفيش ربط بفاتورة هنا، الاستقبال/الدكتور يسجلوا الخدمة والسعر من
// الملف المالي عادي لو حابين.
export async function confirmRebondingAction(formData: FormData) {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const patientId = Number(formData.get("patient_id"));
  const toothId = str(formData, "tooth_id");
  const bracketItemId = num(formData, "bracket_item_id");
  if (!patientId || !toothId) return { ok: false, reason: "بيانات ناقصة" };

  await ensureChartRow(patientId, session!.userId);
  const existing = await db
    .selectFrom("orthodontic_charts")
    .select(["broken_teeth", "rebonding_counts"])
    .where("patient_id", "=", patientId)
    .executeTakeFirst();
  if (!existing) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const brokenTeeth: string[] = existing.broken_teeth ? JSON.parse(existing.broken_teeth) : [];
  const counts: Record<string, number> = existing.rebonding_counts ? JSON.parse(existing.rebonding_counts) : {};
  counts[toothId] = (counts[toothId] ?? 0) + 1;
  const nextBroken = brokenTeeth.filter((t) => t !== toothId);

  await db.transaction().execute(async (trx) => {
    await trx
      .updateTable("orthodontic_charts")
      .set({
        rebonding_counts: JSON.stringify(counts),
        broken_teeth: nextBroken.length ? JSON.stringify(nextBroken) : null,
        updated_by: session!.userId,
        updated_at: new Date().toISOString(),
      })
      .where("patient_id", "=", patientId)
      .execute();

    if ((await inventoryDeductionsEnabled(trx)) && bracketItemId) {
      await trx
        .updateTable("inventory_items")
        .set({ quantity: (eb) => eb("quantity", "-", 1) })
        .where("id", "=", bracketItemId)
        .execute();
    }
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  revalidatePath("/inventory");
  return { ok: true };
}
