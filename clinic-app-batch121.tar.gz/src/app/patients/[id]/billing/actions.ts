"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { logOverride, logAdminEvent } from "@/lib/audit";
import { FOLLOWUP_SERVICE_CODE } from "@/lib/followup";
import { getClinicToday } from "@/lib/clinic-date";
import { applyAvailableCreditsInTransaction } from "@/lib/credits";
import { parseMoney, parsePercent } from "@/lib/money";
import { PAYMENT_METHODS } from "@/lib/payment-methods";
import type { Updateable } from "kysely";
import type { InvoicesTable } from "@/lib/db/types";
import { reactivatePatientForCare } from "@/lib/patient-archive";

// إضافة خدمة (وتحصيل دفعها) من داخل الملف المالي للمريض مباشرة — دي الطريقة
// الوحيدة دلوقتي لتسجيل خدمة/زيارة مالية بره سياق الجدول المركزي (بديل بوكس
// "إضافة خدمة" اللي كان تحت الجدول في /front-desk وانشال، دفعة 20). محصورة
// بصلاحية view_patient_billing — نفس الصلاحية اللي بتتحكم في عرض الصفحة دي
// أصلاً، عشان مين يقدر يشوف الملف المالي هو نفسه اللي يقدر يسجل عليه خدمة.
export async function addPatientServiceAction(formData: FormData) {
  const session = await getSession();
  if (!session) return;

  const canAdd = await hasPermission(session.userId, session.role, "view_patient_billing");
  if (!canAdd) return;

  const patientId = Number(formData.get("patient_id"));
  const serviceId = Number(formData.get("service_id"));
  const doctorId = Number(formData.get("doctor_id"));
  let visitDate = String(formData.get("visit_date") || "").trim();
  const paymentMethod = String(formData.get("payment_method") || "").trim() || null;
  const amountNow = parseMoney(formData.get("amount_now") || "0");

  if (!patientId || !serviceId || !doctorId || amountNow == null) return;

  const today = getClinicToday();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(visitDate)) visitDate = today;

  // تسجيل خدمة بتاريخ غير النهاردة ("تحصيل في يوم غير اليوم اللي دخل فيه
  // الفلوس") محصور بصلاحية edit_invoice_payments — نفس الصلاحية اللي أصلاً
  // بتحكم تعديل فاتورة اتسجلت بالفعل (مدير العيادة/المحاسب/الأدمن افتراضيًا،
  // قابلة للمنح لدكتور معيّن). الاستقبال (اللي معهوش الصلاحية دي افتراضيًا)
  // مقفول على تاريخ النهاردة بس، بغض النظر عن أي قيمة اتبعتت في الفورم.
  if (visitDate !== today) {
    const canBackdate = await hasPermission(session.userId, session.role, "edit_invoice_payments");
    if (!canBackdate) visitDate = today;
  }

  const service = await db
    .selectFrom("services")
    .select(["id", "name", "code", "default_price"])
    .where("id", "=", serviceId)
    .executeTakeFirst();
  if (!service) return;

  const isFollowup = service.code === FOLLOWUP_SERVICE_CODE;

  // هذه الشاشة مالية فقط: إضافة خدمة هنا لا تنشئ أو تعدل زيارة في الملف الطبي.
  if (isFollowup) {
    const targetInvoiceId = Number(formData.get("target_invoice_id"));
    if (!targetInvoiceId) return;

    // تأكيد إن الفاتورة الأصلية فعلاً بتاعة نفس المريض ده (وليست دفعة متابعة
    // هي نفسها) قبل الربط، عشان مايحصلش خلط بيانات بين مرضى.
    const targetInvoice = await db
      .selectFrom("invoices")
      .select(["invoices.id"])
      .where("invoices.id", "=", targetInvoiceId)
      .where("invoices.patient_id", "=", patientId)
      .where("invoices.parent_invoice_id", "is", null)
      .executeTakeFirst();
    if (!targetInvoice) return;

    await db
      .insertInto("invoices")
      .values({
        visit_id: null,
        patient_id: patientId,
        doctor_id: doctorId,
        appointment_id: null,
        service_id: service.id,
        invoice_date: visitDate,
        amount: 0,
        paid: amountNow,
        discount_percent: 0,
        price_overridden: 0,
        payment_method: paymentMethod,
        parent_invoice_id: targetInvoice.id,
      })
      .execute();
  } else {
    const price = parseMoney(formData.get("price") || String(service.default_price));
    const discountPercent = parsePercent(formData.get("discount_percent") || "0");
    if (price == null || discountPercent == null) return;
    const amount = Math.round(price * (1 - discountPercent / 100) * 100) / 100;
    const priceOverridden = Math.round(service.default_price) !== Math.round(price);

    const invoiceId = await db.transaction().execute(async (trx) => {
      const invoiceResult = await trx
        .insertInto("invoices")
        .values({
          visit_id: null,
          patient_id: patientId,
          doctor_id: doctorId,
          appointment_id: null,
          service_id: service.id,
          invoice_date: visitDate,
          amount,
          paid: amountNow,
          discount_percent: discountPercent,
          price_overridden: priceOverridden ? 1 : 0,
          payment_method: paymentMethod,
          parent_invoice_id: null,
          original_price: price,
        })
        .executeTakeFirst();
      const id = Number(invoiceResult.insertId);
      await applyAvailableCreditsInTransaction(trx, patientId, id);
      return id;
    });

    if (priceOverridden) {
      await logOverride({
        entityType: "invoice_price",
        entityId: invoiceId,
        field: "السعر",
        oldValue: service.default_price,
        newValue: price,
        changedBy: session.userId,
        reason: `تعديل سعر خدمة "${service.name}" عند الإضافة من الملف المالي`,
      });
    }
  }

  await reactivatePatientForCare(patientId);
  revalidatePath(`/patients/${patientId}/billing`);
  revalidatePath(`/patients/${patientId}`);
  revalidatePath("/invoices");
  revalidatePath("/front-desk");
  revalidatePath("/");
}

export async function editPatientBillingEntryAction(formData: FormData): Promise<{ ok: boolean; reason?: string }> {
  const session = await getSession();
  if (!session) return { ok: false, reason: "لازم تسجل دخول." };

  const canEdit = await hasPermission(session.userId, session.role, "edit_patient_billing_entry");
  if (!canEdit) return { ok: false, reason: "مفيش صلاحية عندك لتعديل الملف المالي." };

  const invoiceId = Number(formData.get("invoice_id"));
  const patientId = Number(formData.get("patient_id"));
  if (!invoiceId || !patientId) return { ok: false, reason: "بيانات غير صالحة." };

  const doctorId = Number(formData.get("doctor_id"));
  const invoiceDate = String(formData.get("invoice_date") || "").trim();
  const paymentMethod = String(formData.get("payment_method") || "").trim() || null;
  const paid = parseMoney(formData.get("paid") || "0");
  const serviceId = Number(formData.get("service_id"));
  const parsedDate = new Date(`${invoiceDate}T00:00:00Z`);
  const validDate = /^\d{4}-\d{2}-\d{2}$/.test(invoiceDate)
    && !Number.isNaN(parsedDate.getTime())
    && parsedDate.toISOString().slice(0, 10) === invoiceDate;
  const validPaymentMethod = paymentMethod != null && PAYMENT_METHODS.some((method) => method.value === paymentMethod);

  if (!doctorId || !serviceId || !validDate || !validPaymentMethod || paid == null) {
    return { ok: false, reason: "بيانات غير صالحة." };
  }

  const [service, doctor] = await Promise.all([
    db.selectFrom("services").select(["id", "code", "default_price"]).where("id", "=", serviceId).executeTakeFirst(),
    db.selectFrom("doctors").select("id").where("id", "=", doctorId).executeTakeFirst(),
  ]);
  if (!service) return { ok: false, reason: "خدمة غير صالحة." };
  if (!doctor) return { ok: false, reason: "دكتور غير صالح." };
  const isFollowup = service.code === FOLLOWUP_SERVICE_CODE;

  let targetInvoiceId: number | null = null;
  let price: number | null = null;
  let discountPercent: number | null = null;
  if (isFollowup) {
    targetInvoiceId = Number(formData.get("target_invoice_id"));
    if (!targetInvoiceId) return { ok: false, reason: "لازم تختار الخدمة الأصلية اللي هتتخصم منها الدفعة." };
    if (targetInvoiceId === invoiceId) return { ok: false, reason: "مينفعش الخدمة تتربط بنفسها." };
  } else {
    price = parseMoney(formData.get("price") || "0");
    discountPercent = parsePercent(formData.get("discount_percent") || "0");
    if (price == null || discountPercent == null) return { ok: false, reason: "بيانات غير صالحة." };
  }

  const result = await db.transaction().execute(async (trx) => {
    const existing = await trx
      .selectFrom("invoices")
      .select(["id", "parent_invoice_id"])
      .where("id", "=", invoiceId)
      .where("patient_id", "=", patientId)
      .executeTakeFirst();
    if (!existing) return { ok: false, reason: "الفاتورة غير موجودة." };

    const updateValues: Updateable<InvoicesTable> = {
      doctor_id: doctorId,
      invoice_date: invoiceDate,
      payment_method: paymentMethod,
      paid,
      service_id: serviceId,
    };

    if (isFollowup) {
      const hasOwnFollowups = await trx
        .selectFrom("invoices")
        .select("id")
        .where("parent_invoice_id", "=", invoiceId)
        .executeTakeFirst();
      if (hasOwnFollowups) {
        return { ok: false, reason: "الخدمة دي مربوط بيها دفعات متابعة تانية بالفعل — مينفعش تتحول هي نفسها لمتابعة." };
      }

      const targetInvoice = await trx
        .selectFrom("invoices")
        .leftJoin("services", "services.id", "invoices.service_id")
        .select(["invoices.id", "invoices.amount", "invoices.paid", "services.code as service_code"])
        .where("invoices.id", "=", targetInvoiceId!)
        .where("invoices.patient_id", "=", patientId)
        .where("invoices.parent_invoice_id", "is", null)
        .executeTakeFirst();
      if (!targetInvoice || targetInvoice.service_code === FOLLOWUP_SERVICE_CODE) {
        return { ok: false, reason: "الفاتورة الأصلية غير صالحة." };
      }

      const otherFollowups = await trx
        .selectFrom("invoices")
        .select("paid")
        .where("parent_invoice_id", "=", targetInvoice.id)
        .where("id", "!=", invoiceId)
        .execute();
      const availableBalance = targetInvoice.amount - targetInvoice.paid - otherFollowups.reduce((sum, row) => sum + row.paid, 0);
      if (availableBalance <= 0.01 || paid > availableBalance + 0.01) {
        return { ok: false, reason: "مبلغ المتابعة أكبر من الرصيد المتاح على الخدمة الأصلية." };
      }

      updateValues.parent_invoice_id = targetInvoice.id;
      updateValues.amount = 0;
      updateValues.original_price = null;
      updateValues.discount_percent = 0;
      updateValues.price_overridden = 0;
    } else {
      const amount = Math.round(price! * (1 - discountPercent! / 100) * 100) / 100;
      updateValues.original_price = price;
      updateValues.discount_percent = discountPercent!;
      updateValues.amount = amount;
      updateValues.parent_invoice_id = null;
      updateValues.price_overridden = Math.round(service.default_price) !== Math.round(price!) ? 1 : 0;
    }

    await trx.updateTable("invoices").set(updateValues).where("id", "=", invoiceId).execute();
    return { ok: true };
  });

  if (!result.ok) return result;

  await logAdminEvent({
    entityType: "invoice",
    entityId: invoiceId,
    event: "edit_billing_entry",
    details: `تعديل صف الملف المالي للمريض #${patientId} (فاتورة #${invoiceId})`,
    changedBy: session.userId,
  });

  revalidatePath(`/patients/${patientId}/billing`);
  revalidatePath(`/patients/${patientId}`);
  revalidatePath("/invoices");
  revalidatePath("/front-desk");
  revalidatePath("/");

  return { ok: true };
}
