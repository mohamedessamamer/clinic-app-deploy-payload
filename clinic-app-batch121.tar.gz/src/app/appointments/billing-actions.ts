"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { logOverride } from "@/lib/audit";
import { FOLLOWUP_SERVICE_CODE } from "@/lib/followup";
import { applyAvailableCreditsInTransaction } from "@/lib/credits";
import { notifyReceptionOfCollectionRequest } from "@/lib/notifications";
import { applyGeneralConsumablesForCompletedAppointment } from "@/lib/inventory-stock";
import { evaluateInventoryReorderNeeds } from "@/lib/inventory-reorder";
import { parseMoney, parsePercent } from "@/lib/money";
import { autoCloseReferralTasksForAppointment } from "@/lib/tasks";

// فواتير المريض اللي لسه عليها مبلغ مستحق (باستثناء فواتير "دفعات المتابعة" نفسها) —
// بتتحسب مع طرح أي دفعات متابعة سابقة اتسجلت عليها، عشان الرصيد المعروض يكون دقيق.
// بتتنادى مباشرة من CentralSchedule (client component) لما يتم اختيار خدمة "متابعة".
export async function getPatientBillableInvoicesAction(patientId: number) {
  // بترجّع حالة المريض المالية — لازم صلاحية الملف المالي، مش مجرد جلسة.
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "view_patient_billing"))) return [];
  if (!patientId) return [];

  const originals = await db
    .selectFrom("invoices")
    .leftJoin("services", "services.id", "invoices.service_id")
    .select([
      "invoices.id",
      "invoices.amount",
      "invoices.paid",
      "invoices.invoice_date",
      "services.name as service_name",
    ])
    .where("invoices.patient_id", "=", patientId)
    .where("invoices.parent_invoice_id", "is", null)
    .orderBy("invoices.invoice_date", "desc")
    .execute();

  if (originals.length === 0) return [];

  const followups = await db
    .selectFrom("invoices")
    .select(["parent_invoice_id", "paid"])
    .where(
      "parent_invoice_id",
      "in",
      originals.map((o) => o.id)
    )
    .execute();

  const followupSum = new Map<number, number>();
  for (const f of followups) {
    if (f.parent_invoice_id == null) continue;
    followupSum.set(f.parent_invoice_id, (followupSum.get(f.parent_invoice_id) ?? 0) + f.paid);
  }

  return originals
    .map((o) => ({
      id: o.id,
      service_name: o.service_name ?? "-",
      visit_date: o.invoice_date,
      balance: Math.round((o.amount - o.paid - (followupSum.get(o.id) ?? 0)) * 100) / 100,
    }))
    .filter((o) => o.balance > 0.01);
}

// دفعة 27 (P3.2): نفس فكرة getPatientBillableInvoicesAction فوق بالظبط، بس مع
// فئة الخدمة (category) وفلترة اختيارية بيها — مستخدمة في قائمة "المريض جاي
// يعمل إيه" الجديدة عشان "تقويم" يشوف بس الفواتير المفتوحة لخدمات تقويم،
// و"عام" يشوف الباقي بس، والبحث الحر يشوف الكل من غير فلترة (scope="all").
export type PurposeOpenService = {
  id: number;
  service_id: number | null;
  service_name: string;
  visit_date: string;
  balance: number;
  category: string | null;
};

export async function getPatientOpenServicesForPurposeAction(
  patientId: number,
  scope: "ortho" | "general" | "all"
): Promise<PurposeOpenService[]> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "view_patient_billing"))) return [];
  if (!patientId) return [];

  const originals = await db
    .selectFrom("invoices")
    .leftJoin("services", "services.id", "invoices.service_id")
    .select([
      "invoices.id",
      "invoices.amount",
      "invoices.paid",
      "invoices.invoice_date",
      "services.id as service_id",
      "services.name as service_name",
      "services.category as category",
    ])
    .where("invoices.patient_id", "=", patientId)
    .where("invoices.parent_invoice_id", "is", null)
    .orderBy("invoices.invoice_date", "desc")
    .execute();

  if (originals.length === 0) return [];

  const followups = await db
    .selectFrom("invoices")
    .select(["parent_invoice_id", "paid"])
    .where(
      "parent_invoice_id",
      "in",
      originals.map((o) => o.id)
    )
    .execute();

  const followupSum = new Map<number, number>();
  for (const f of followups) {
    if (f.parent_invoice_id == null) continue;
    followupSum.set(f.parent_invoice_id, (followupSum.get(f.parent_invoice_id) ?? 0) + f.paid);
  }

  return originals
    .map((o) => ({
      id: o.id,
      service_id: o.service_id,
      service_name: o.service_name ?? "-",
      visit_date: o.invoice_date,
      balance: Math.round((o.amount - o.paid - (followupSum.get(o.id) ?? 0)) * 100) / 100,
      category: o.category,
    }))
    .filter((o) => o.balance > 0.01)
    .filter((o) => {
      if (scope === "all") return true;
      const isOrtho = o.category === "Orthodontics";
      return scope === "ortho" ? isOrtho : !isOrtho;
    });
}

// بيرجع مواعيد اليوم/الغرفة المحجوزة فعلًا (غير الملغية) — بتتنادى من بوكس "حجز
// الموعد القادم" الاختياري في بوكس التحصيل، عشان مربع الوقت يعرض بس الفترات
// المتاحة فعلًا للتاريخ والغرفة المختارين، مش كل فترات اليوم.
export async function getBookedSlotsForRoomDateAction(roomId: number, date: string): Promise<string[]> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "schedule_edit"))) return [];
  if (!roomId || !date) return [];
  const rows = await db
    .selectFrom("appointments")
    .select(["start_time"])
    .where("room_id", "=", roomId)
    .where("appointment_date", "=", date)
    .where("status", "!=", "cancelled")
    .execute();
  return rows.map((r) => r.start_time);
}

export async function getLastAppointmentTimeAction(patientId: number): Promise<string | null> {
  if (!(await getSession()) || !patientId) return null;
  const appointment = await db
    .selectFrom("appointments")
    .select("start_time")
    .where("patient_id", "=", patientId)
    .where("status", "!=", "cancelled")
    .orderBy("appointment_date", "desc")
    .orderBy("start_time", "desc")
    .executeTakeFirst();
  return appointment?.start_time ?? null;
}

// بيتسجل من بوكس الفوترة اللي بيتفتح لما يتم الضغط على "تم" في الجدول المركزي
// (لو المستخدم عنده صلاحية collect_payments). فيه مسارين:
// 1) خدمة عادية جديدة: بتتسجل زيارة + فاتورة جديدة بالسعر (قابل للتعديل) والخصم.
// 2) خدمة "متابعة" (كود 0): بتتسجل زيارة (تظهر في الملف الطبي) وفاتورة بمبلغ صفر
//    مربوطة بـ parent_invoice_id على الفاتورة الأصلية المختارة — المبلغ المدفوع
//    بيتحط في paid بتاعتها هي، عشان يتخصم من رصيد الفاتورة الأصلية تحديدًا من غير
//    ما يعمل استحقاق جديد.
// في الحالتين: بيحدّث حالة الموعد لـ "تم".
export async function recordAppointmentBillingAction(formData: FormData) {
  const appointmentId = Number(formData.get("appointment_id"));
  const serviceId = Number(formData.get("service_id"));
  const paymentMethod = String(formData.get("payment_method") || "").trim() || null;
  const amountNow = parseMoney(formData.get("amount_now") || "0");

  if (!appointmentId || !serviceId || amountNow == null) return;

  const session = await getSession();
  if (!session) return;

  // محصور بصلاحية collect_payments — نفس الصلاحية اللي بتتحكم في ظهور بوكس
  // التحصيل من الجدول المركزي أصلاً. الأكشن ده بقى ليه مدخلين دلوقتي (بوكس
  // التحصيل الفوري من الجدول، وبوكس تحصيل الموعد المعلّق من الملف المالي
  // للمريض، دفعة 21) فمحتاج يتحقق بنفسه مش يعتمد بس على إخفاء الزرار بالواجهة.
  const canCollect = await hasPermission(session.userId, session.role, "collect_payments");
  if (!canCollect) return;

  const appt = await db.selectFrom("appointments").selectAll().where("id", "=", appointmentId).executeTakeFirst();
  if (!appt) return;

  const service = await db
    .selectFrom("services")
    .select(["id", "name", "code", "default_price"])
    .where("id", "=", serviceId)
    .executeTakeFirst();
  if (!service) return;

  const isFollowup = service.code === FOLLOWUP_SERVICE_CODE;

  // دفعة 24 (متابعة تقرير ازدواجية الخدمات): "الطبيب المساعد" اختياري هنا كمان،
  // بما فيها حالة "متابعة" — نقلناها لفوق قبل تفرع isFollowup/else عشان تنطبق
  // على الحالتين، مش بس "غير المتابعة" زي ما كانت قبل كده.
  const canEditAssistant =
    (await hasPermission(session.userId, session.role, "edit_visit_assistant_doctor")) ||
    (await hasPermission(session.userId, session.role, "override_visit_doctor"));
  const performingRaw = formData.get("performing_doctor_id");
  const explicitPerforming = canEditAssistant && performingRaw ? Number(performingRaw) || null : null;

  const price = isFollowup ? 0 : parseMoney(formData.get("price") || String(service.default_price));
  const discountPercent = isFollowup ? 0 : parsePercent(formData.get("discount_percent") || "0");
  if (price == null || discountPercent == null) return;
  const amount = Math.round(price * (1 - discountPercent / 100) * 100) / 100;
  const priceOverridden = !isFollowup && Math.round(service.default_price) !== Math.round(price);
  const targetInvoiceId = isFollowup ? Number(formData.get("target_invoice_id")) : null;

  // الفاتورة وحالة الموعد وإغلاق طلب التحصيل تتغير معًا أو لا تتغير إطلاقًا.
  // معاملة SQLite تمنع الحالة الجزئية، والـunique index يمنع فاتورتين أصليتين
  // لنفس الموعد كخط دفاع ثانٍ عند وصول طلبين متزامنين.
  const transactionResult = await db.transaction().execute(async (trx) => {
    let recordedInvoiceId: number;

    if (isFollowup) {
      const targetInvoice = targetInvoiceId
        ? await trx.selectFrom("invoices").select("id")
            .where("id", "=", targetInvoiceId)
            .where("patient_id", "=", appt.patient_id)
            .where("parent_invoice_id", "is", null)
            .executeTakeFirst()
        : undefined;
      if (!targetInvoice) return null;
      const inserted = await trx.insertInto("invoices").values({
        visit_id: null, patient_id: appt.patient_id, doctor_id: appt.doctor_id,
        appointment_id: appt.id, service_id: service.id, invoice_date: appt.appointment_date,
        amount: 0, paid: amountNow, discount_percent: 0, price_overridden: 0,
        payment_method: paymentMethod, parent_invoice_id: targetInvoice.id,
      }).executeTakeFirst();
      recordedInvoiceId = Number(inserted.insertId);
    } else {
      const existingInvoice = await trx.selectFrom("invoices").select("id")
        .where("appointment_id", "=", appt.id).where("parent_invoice_id", "is", null).executeTakeFirst();
      if (existingInvoice) {
        recordedInvoiceId = existingInvoice.id;
        await trx.updateTable("invoices").set({
          amount, paid: amountNow, discount_percent: discountPercent,
          price_overridden: priceOverridden ? 1 : 0, payment_method: paymentMethod,
          original_price: price,
        }).where("id", "=", recordedInvoiceId).execute();
      } else {
        const inserted = await trx.insertInto("invoices").values({
          visit_id: null, patient_id: appt.patient_id, doctor_id: appt.doctor_id,
          appointment_id: appt.id, service_id: service.id, invoice_date: appt.appointment_date,
          amount, paid: amountNow, discount_percent: discountPercent,
          price_overridden: priceOverridden ? 1 : 0, payment_method: paymentMethod,
          parent_invoice_id: null, original_price: price,
        }).executeTakeFirst();
        recordedInvoiceId = Number(inserted.insertId);
      }
    }

    if (!isFollowup) {
      await applyAvailableCreditsInTransaction(trx, appt.patient_id, recordedInvoiceId);
    }

    const collectionRequest = await trx.selectFrom("collection_requests").select("id")
      .where("appointment_id", "=", appointmentId).where("status", "=", "pending").executeTakeFirst();
    const isNewlyDone = !collectionRequest && appt.status !== "done";
    await trx.updateTable("appointments").set({
      status: collectionRequest ? appt.status : "done",
      ...(isNewlyDone ? { completed_at: new Date().toISOString() } : {}),
      pending_service_id: null, pending_price: null, pending_discount_percent: null,
    }).where("id", "=", appointmentId).execute();

    if (collectionRequest && amountNow > 0) {
      await trx.updateTable("collection_requests").set({
        status: "settled", settled_by: session.userId,
        settled_at: new Date().toISOString().replace("T", " ").slice(0, 19),
      }).where("id", "=", collectionRequest.id).execute();
    }
    return { recordedInvoiceId, isNewlyDone };
  });
  if (!transactionResult) return;

  // التسجيل والمخزون ينفذان بعد تحرير قفل المعاملة المالية القصيرة.
  if (priceOverridden) {
    await logOverride({
      entityType: "invoice_price", entityId: transactionResult.recordedInvoiceId,
      field: "السعر", oldValue: service.default_price, newValue: price,
      changedBy: session.userId,
      reason: `تعديل سعر خدمة "${service.name}" عند التحصيل من الجدول المركزي`,
    });
  }
  if (transactionResult.isNewlyDone) {
    await autoCloseReferralTasksForAppointment(appointmentId, session.userId);
    await applyGeneralConsumablesForCompletedAppointment(appointmentId);
    await evaluateInventoryReorderNeeds();
  }

  revalidatePath("/front-desk");
  revalidatePath("/");
  revalidatePath("/invoices");
  revalidatePath(`/patients/${appt.patient_id}`);
  revalidatePath(`/patients/${appt.patient_id}/billing`);
}

export async function markAppointmentDoneWithoutPaymentAction(appointmentId: number) {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "collect_payments"))) return { ok: false, error: "غير مصرح" };
  const appointment = await db.selectFrom("appointments").select(["id", "patient_id", "status"]).where("id", "=", appointmentId).executeTakeFirst();
  if (!appointment || appointment.status === "done") return { ok: false, error: "الموعد غير متاح" };
  const invoices = await db.selectFrom("invoices").select(["amount", "paid"]).where("patient_id", "=", appointment.patient_id).execute();
  const debt = Math.max(0, invoices.reduce((sum, invoice) => sum + invoice.amount - invoice.paid, 0));
  await db.updateTable("appointments").set({ status: "done", completed_at: new Date().toISOString(), completed_without_payment: 1, debt_on_completion: Math.round(debt * 100) / 100, pending_service_id: null, pending_price: null, pending_discount_percent: null }).where("id", "=", appointment.id).execute();
  await autoCloseReferralTasksForAppointment(appointment.id, session.userId);
  await applyGeneralConsumablesForCompletedAppointment(appointment.id);
  await evaluateInventoryReorderNeeds();
  revalidatePath("/front-desk"); revalidatePath("/"); revalidatePath("/whatsapp");
  return { ok: true, debt };
}

// بيتسجل من بوكس "المطلوب دفعه" اللي بيفتح لما حد معهوش صلاحية collect_payments
// (زي الدكتور) يدوس "تم" — بيحدد الخدمة والسعر المتوقع كـ"مطلوب دفعه" (pending_*)
// من غير ما يسجل زيارة أو فاتورة أو أي دفع فعلي، وبيحدد الموعد "تم". الاستقبال
// بيشوف التفاصيل دي على طول جنب شارة "محتاج تحصيل" في الجدول، وبتتملى تلقائي في
// بوكس التحصيل بتاعه لما يفتحه بأثر رجعي (تسجيل التحصيل).
export async function recordPendingBillingAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "doctor" || !session.doctorId) return;

  const appointmentId = Number(formData.get("appointment_id"));
  const serviceId = Number(formData.get("service_id")) || null;
  const requestedAmount = parseMoney(formData.get("requested_amount") || "0");
  if (requestedAmount == null || !appointmentId || (!serviceId && requestedAmount <= 0)) return;

  const appt = await db
    .selectFrom("appointments")
    .select(["id", "patient_id", "doctor_id"])
    .where("id", "=", appointmentId)
    .executeTakeFirst();
  if (!appt) return;

  // الطبيب صاحب الموعد أو مساعد مُسجّل تحته فقط هو الذي يرسل طلب التحصيل.
  const isOwner = appt.doctor_id === session.doctorId;
  const isAssistant = isOwner
    ? false
    : !!(await db
        .selectFrom("consultant_assistants")
        .select("assistant_doctor_id")
        .where("consultant_doctor_id", "=", appt.doctor_id)
        .where("assistant_doctor_id", "=", session.doctorId)
        .executeTakeFirst());
  const canEnterForAnyDoctor = await hasPermission(
    session.userId,
    session.role,
    "create_collection_requests_all_doctors"
  );
  if (!isOwner && !isAssistant && !canEnterForAnyDoctor) return;

  if (serviceId) {
    const service = await db.selectFrom("services").select("id").where("id", "=", serviceId).executeTakeFirst();
    if (!service) return;
  }

  await db
    .insertInto("collection_requests")
    .values({
      appointment_id: appt.id,
      patient_id: appt.patient_id,
      doctor_id: appt.doctor_id,
      service_id: serviceId,
      requested_amount: requestedAmount > 0 ? requestedAmount : null,
      requested_by: session.userId,
    })
    .onConflict((oc) =>
      oc.column("appointment_id").doUpdateSet({
        service_id: serviceId,
        requested_amount: requestedAmount > 0 ? requestedAmount : null,
        status: "pending",
        requested_by: session.userId,
        requested_at: new Date().toISOString().replace("T", " ").slice(0, 19),
        settled_by: null,
        settled_at: null,
        cancelled_by: null,
        cancelled_at: null,
      })
    )
    .execute();

  const patient = await db.selectFrom("patients").select("full_name").where("id", "=", appt.patient_id).executeTakeFirst();
  if (patient) {
    await notifyReceptionOfCollectionRequest({
      appointmentId: appt.id,
      patientId: appt.patient_id,
      doctorId: appt.doctor_id,
      patientName: patient.full_name,
    });
  }

  // طلب التحصيل الصادر من الطبيب يعني أن الزيارة انتهت حتى لو كتب الطلب بعد
  // خروج المريض. لا نكرر خصم المستهلكات إن كانت الزيارة «تم» بالفعل.
  const currentAppointment = await db.selectFrom("appointments").select("status").where("id", "=", appt.id).executeTakeFirst();
  if (currentAppointment?.status !== "done") {
    await db.updateTable("appointments").set({ status: "done", completed_at: new Date().toISOString() }).where("id", "=", appt.id).execute();
    await autoCloseReferralTasksForAppointment(appt.id, session.userId);
    await applyGeneralConsumablesForCompletedAppointment(appt.id);
    await evaluateInventoryReorderNeeds();
  }

  revalidatePath("/front-desk");
  revalidatePath("/");
  revalidatePath("/inventory");
  revalidatePath(`/patients/${appt.patient_id}/billing`);
}

// دفعة مقدمة قبل الكشف أو قبل تحديد الخدمة. تُحفظ كرَصيد للمريض، ولا تغيّر
// حالة الموعد ولا تُنشئ زيارة طبية. عند التحصيل لاحقًا تُطبّق على الفاتورة.
export async function recordAdvancePaymentAction(formData: FormData) {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "collect_payments"))) return;

  const patientId = Number(formData.get("patient_id"));
  const appointmentId = Number(formData.get("appointment_id")) || null;
  const amount = parseMoney(formData.get("amount") || "0");
  const paymentMethod = String(formData.get("payment_method") || "").trim() || null;
  const note = String(formData.get("note") || "").trim() || null;
  if (!patientId || amount == null || amount <= 0) return;

  if (appointmentId) {
    const appointment = await db
      .selectFrom("appointments")
      .select("patient_id")
      .where("id", "=", appointmentId)
      .executeTakeFirst();
    if (!appointment || appointment.patient_id !== patientId) return;
  }

  await db
    .insertInto("patient_credits")
    .values({
      patient_id: patientId,
      appointment_id: appointmentId,
      original_amount: amount,
      available_amount: amount,
      payment_method: paymentMethod,
      received_by: session.userId,
      note,
    })
    .execute();

  revalidatePath(`/patients/${patientId}/billing`);
  revalidatePath("/front-desk");
  revalidatePath("/");
}
