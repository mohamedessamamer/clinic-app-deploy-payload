import Link from "next/link";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { paymentMethodLabel } from "@/lib/payment-methods";
import { getReportsData, type ReportsSearchParams } from "@/lib/reports-data";
import ReportsFilterForm from "@/components/ReportsFilterForm";
import { EXPENSE_CATEGORIES, EXPENSE_CATEGORY_LABELS, getExpenseSummary } from "@/lib/expenses";
import { db } from "@/lib/db/client";
import { calculateHrPayroll, getCollectedAfterLab } from "@/lib/hr-payroll";
import { cookies } from "next/headers";
import { DOCTOR_REPORT_ACCESS_COOKIE, verifyDoctorReportAccessToken } from "@/lib/report-access";
import WhatsAppOperationalReports from "@/components/WhatsAppOperationalReports";
import PatientReviewReport from "@/components/PatientReviewReport";
import { getSetting } from "@/lib/settings";
import SettingsSidebarLayout from "@/components/SettingsSidebarLayout";
import SystemLogReport from "@/components/SystemLogReport";
import PatientDurationReport from "@/components/PatientDurationReport";
import IncompleteCheckupReport from "@/components/IncompleteCheckupReport";

// تقرير رواتب بالتفصيل لتبويب "مصروفات" — نفس منطق حساب استحقاقات
// العاملين المستخدم في شاشة /expenses (rules + runs + getCollectedAfterLab)
// لكن هنا للعرض فقط بلا أي أكشنات صرف/تعديل.
async function getPayrollDetailReport(from: string, to: string) {
  const [doctors, staff, rules, runs] = await Promise.all([
    db.selectFrom("doctors").select(["id", "full_name", "active"]).orderBy("full_name").execute(),
    db.selectFrom("hr_staff").select(["id", "full_name", "active"]).orderBy("full_name").execute(),
    db.selectFrom("hr_compensation_rules").selectAll().where("active", "=", 1).where("effective_from", "<=", to).where((eb) => eb.or([eb("effective_to", "is", null), eb("effective_to", ">=", from)])).execute(),
    db.selectFrom("hr_payroll_runs").selectAll().where("period_from", "=", from).where("period_to", "=", to).execute(),
  ]);
  const doctorNames = new Map(doctors.filter((p) => p.active === 1).map((p) => [p.id, p.full_name]));
  const staffNames = new Map(staff.filter((p) => p.active === 1).map((p) => [p.id, p.full_name]));
  const runMap = new Map(runs.map((run) => [`${run.person_type}-${run.person_id}`, run]));
  let clinicCollection: Awaited<ReturnType<typeof getCollectedAfterLab>> | null = null;
  const rows = await Promise.all(rules.map(async (rule) => {
    const name = rule.person_type === "doctor" ? doctorNames.get(rule.person_id) : staffNames.get(rule.person_id);
    if (!name) return null;
    const run = runMap.get(`${rule.person_type}-${rule.person_id}`);
    let collection;
    if (rule.percentage_basis === "personal" && rule.person_type === "doctor") collection = await getCollectedAfterLab(from, to, rule.person_id);
    else { clinicCollection ??= await getCollectedAfterLab(from, to, null); collection = clinicCollection; }
    const preview = calculateHrPayroll(rule, collection.netCollected, run?.shift_count ?? 0);
    const total = run?.total_amount ?? preview.totalAmount;
    return { key: `${rule.person_type}-${rule.person_id}`, name, group: rule.staff_group, status: run?.status ?? "draft", total };
  }));
  const visibleRows = rows.filter((r): r is NonNullable<typeof r> => !!r);
  return { rows: visibleRows, total: visibleRows.reduce((sum, r) => sum + r.total, 0) };
}

// تقرير توريدات لتبويب "مصروفات" — فواتير المورد المسجلة في الفترة، المدفوع
// من قيمتها في نفس الفترة، والمديونية الصافية الحالية. بعد دفعة 107 التخصص
// بقى ممكن يتحدد لكل فاتورة (عمود specialty)، وبيرجع لتخصص المورد نفسه لو
// المورد بتخصص واحد بس أو الفاتورة قديمة من غير specialty. المديونية = مجموع
// "المتبقي" (قيمة الفاتورة - دفعاتها) لكل فواتير المورد، بلا تقييد بالفترة —
// وليس فرق مجموعين منفصلين، حتى تطابق تمامًا حساب قسم "خامات" في المصروفات.
// دفعات قديمة بدون فاتورة (invoice_id = NULL، من قبل إلغاء "الدفعة العامة")
// تُخصم من المديونية أيضًا رغم عدم ارتباطها بفاتورة معينة.
async function getSuppliersDetailReport(from: string, to: string) {
  const [suppliers, invoicesInPeriod, allInvoices, allPayments] = await Promise.all([
    db.selectFrom("inventory_suppliers").select(["id", "name", "is_ortho", "is_general"]).where("active", "=", 1).orderBy("name").execute(),
    db.selectFrom("supplier_invoices").select(["supplier_id", "amount"]).where("invoice_date", ">=", from).where("invoice_date", "<=", to).execute(),
    db.selectFrom("supplier_invoices").select(["id", "supplier_id", "amount", "specialty"]).execute(),
    db.selectFrom("supplier_payments").select(["supplier_id", "invoice_id", "amount", "payment_date"]).execute(),
  ]);
  const invoicedInPeriod = new Map<number, number>();
  for (const invoice of invoicesInPeriod) invoicedInPeriod.set(invoice.supplier_id, Math.round(((invoicedInPeriod.get(invoice.supplier_id) ?? 0) + invoice.amount) * 100) / 100);
  const paidInPeriod = new Map<number, number>();
  for (const payment of allPayments) {
    if (payment.payment_date < from || payment.payment_date > to) continue;
    paidInPeriod.set(payment.supplier_id, Math.round(((paidInPeriod.get(payment.supplier_id) ?? 0) + payment.amount) * 100) / 100);
  }
  const paymentsByInvoice = new Map<number, number>();
  const legacyPaymentsBySupplier = new Map<number, number>();
  for (const payment of allPayments) {
    if (payment.invoice_id != null) paymentsByInvoice.set(payment.invoice_id, Math.round(((paymentsByInvoice.get(payment.invoice_id) ?? 0) + payment.amount) * 100) / 100);
    else legacyPaymentsBySupplier.set(payment.supplier_id, Math.round(((legacyPaymentsBySupplier.get(payment.supplier_id) ?? 0) + payment.amount) * 100) / 100);
  }
  const debtBySupplier = new Map<number, number>();
  const supplierById = new Map(suppliers.map((s) => [s.id, s]));
  for (const invoice of allInvoices) {
    const remaining = Math.round((invoice.amount - (paymentsByInvoice.get(invoice.id) ?? 0)) * 100) / 100;
    debtBySupplier.set(invoice.supplier_id, Math.round(((debtBySupplier.get(invoice.supplier_id) ?? 0) + remaining) * 100) / 100);
  }
  for (const [supplierId, legacy] of legacyPaymentsBySupplier) {
    debtBySupplier.set(supplierId, Math.round(((debtBySupplier.get(supplierId) ?? 0) - legacy) * 100) / 100);
  }
  function specialtyOf(invoice: { specialty: string | null }, supplier: { is_ortho: number; is_general: number }): "ortho" | "general" | null {
    if (invoice.specialty === "ortho" || invoice.specialty === "general") return invoice.specialty;
    if (supplier.is_ortho === 1 && supplier.is_general !== 1) return "ortho";
    if (supplier.is_general === 1 && supplier.is_ortho !== 1) return "general";
    return null;
  }
  const orthoSupplierIds = new Set<number>();
  const generalSupplierIds = new Set<number>();
  for (const invoice of allInvoices) {
    const supplier = supplierById.get(invoice.supplier_id);
    if (!supplier) continue;
    const specialty = specialtyOf(invoice, supplier);
    if (specialty === "ortho") orthoSupplierIds.add(supplier.id);
    if (specialty === "general") generalSupplierIds.add(supplier.id);
  }
  // موردين معرَّفين بتخصص واحد بس لكن بدون فواتير أصلاً — يفضلوا يظهروا تحت
  // تخصصهم لو ليهم أي حركة في الفترة (مطابقة للسلوك القديم).
  for (const supplier of suppliers) {
    if (supplier.is_ortho === 1 && supplier.is_general !== 1) orthoSupplierIds.add(supplier.id);
    if (supplier.is_general === 1 && supplier.is_ortho !== 1) generalSupplierIds.add(supplier.id);
  }
  const rows = suppliers.map((supplier) => ({
    id: supplier.id,
    name: supplier.name,
    invoicedInPeriod: invoicedInPeriod.get(supplier.id) ?? 0,
    paidInPeriod: paidInPeriod.get(supplier.id) ?? 0,
    netDebt: debtBySupplier.get(supplier.id) ?? 0,
  })).filter((row) => row.invoicedInPeriod > 0 || row.paidInPeriod > 0 || row.netDebt !== 0);
  return {
    ortho: rows.filter((row) => orthoSupplierIds.has(row.id)),
    general: rows.filter((row) => generalSupplierIds.has(row.id)),
  };
}

// تقرير مصروفات نثرية بالتفصيل — سطر بسطر لبند "أخرى" في الفترة المختارة.
async function getMiscExpensesDetailReport(from: string, to: string) {
  const rows = await db
    .selectFrom("expenses")
    .select(["id", "expense_date", "title", "payee", "amount", "note"])
    .where("category", "=", "other")
    .where("expense_date", ">=", from)
    .where("expense_date", "<=", to)
    .orderBy("expense_date", "desc")
    .orderBy("id", "desc")
    .execute();
  return { rows, total: rows.reduce((sum, row) => sum + row.amount, 0) };
}

// تقرير الإيرادات — صفحة/صلاحية مستقلة (reports_full / reports_own، شوف
// permission-defs.ts) بتجمّع بيانات الفواتير الموجودة فعلاً (نفس مصدر بيانات
// /invoices والملف المالي لكل مريض) بفلاتر فترة/دكتور/خدمة، بدل ما تبقى صفحة
// منفصلة بمنطق حسابي مختلف. عمدًا بيربط رجوع لصفوف اليوم التفصيلية في /invoices
// (شوف "ربط الشاشات" في رابط عمود التاريخ تحت).
//
// منطق الجلب/التجميع الفعلي منقول لـ src/lib/reports-data.ts عشان يُستخدم هنا
// وفي تصدير الـ Excel (src/app/reports/export/route.ts) من غير تكرار.

export default async function ReportsPage({ searchParams }: { searchParams: Promise<ReportsSearchParams> }) {
  const session = await getSession();
  const sp = await searchParams;
  const data = await getReportsData(session, sp);
  const [canAppointmentReport, canPatientReports, canThresholds, canReviewReport, canConfigureReviews] = session ? await Promise.all([
    hasPermission(session.userId, session.role, "view_whatsapp_reminder_report"),
    hasPermission(session.userId, session.role, "view_patient_reports"),
    hasPermission(session.userId, session.role, "configure_followup_thresholds"),
    hasPermission(session.userId, session.role, "view_patient_review_report"),
    hasPermission(session.userId, session.role, "manage_settings"),
  ]) : [false, false, false, false, false];
  const hasOperationalReports = canAppointmentReport || canPatientReports;
  const hasExtraReports = hasOperationalReports || canReviewReport;
  // التقارير اتوزّعت على تلات مجموعات بدل ما تبقى كلها تحت بعض. الصلاحيات زي
  // ما هي بالظبط — اللي اتغيّر هو مكان العرض بس، فمحدش بيكسب ولا بيخسر وصول.
  // "تم بدون دفع" اتنقل من التشغيلية للمالية لأنه تقرير مالي فعلاً.
  const canSystemLog = session ? await hasPermission(session.userId, session.role, "view_system_log") : false;
  const financialExtras = canAppointmentReport
    ? <WhatsAppOperationalReports canAppointment canOrtho={false} canReferrals={false} canThresholds={false} only={["unpaid"]} title="تم بدون دفع" />
    : null;
  // تقارير متابعة التقويم والتحويلات ومدة المريض والكشوفات غير المكتملة كلهم
  // بقوا تحت صلاحية واحدة (view_patient_reports) بعد دفعة الدمج — شوف
  // permission-defs.ts.
  // القائمة الثانية لتقارير المرضى رأسية، وبنفس شكل مربعات القوائم في الجانب.
  const patientReports = (canPatientReports || canReviewReport) ? <SettingsSidebarLayout initialKey={(sp as { report?: string }).report} sections={[
    ...(canPatientReports ? [{ key: "ortho", label: "متابعة تقويم متأخرة", content: <WhatsAppOperationalReports canAppointment={false} canOrtho canReferrals={false} canThresholds={canThresholds} only={["ortho"]} defaultOpen title="متابعة تقويم متأخرة" /> }] : []),
    ...(canPatientReports ? [{ key: "referrals", label: "التحويلات", content: <WhatsAppOperationalReports canAppointment={false} canOrtho={false} canReferrals canThresholds={false} only={["referrals"]} defaultOpen title="التحويلات" /> }] : []),
    ...(canPatientReports ? [{ key: "duration", label: "مدة المريض في العيادة", content: <PatientDurationReport /> }] : []),
    ...(canPatientReports ? [{ key: "incomplete", label: "الكشوفات غير المكتملة", content: <IncompleteCheckupReport /> }] : []),
    ...(canReviewReport ? [{ key: "reviews", label: "تقييمات المرضى", content: <PatientReviewReport canConfigure={canConfigureReviews} initialGoogleUrl={await getSetting("google_review_url")} /> }] : []),
  ]} /> : null;
  const systemReports = canSystemLog ? <SystemLogReport /> : null;

  // بيلف محتوى التقارير المالية (تقرير الإيرادات بكل أشكاله) في تبويب، وبيضيف
  // جنبه تبويبي المرضى والنظام لو المستخدم عنده صلاحيتهم.
  function renderReportTabs(financialContent: React.ReactNode) {
    const sections = [
      { key: "financial", label: "تقارير مالية", content: <>{financialContent}{financialExtras}</> },
      ...(patientReports ? [{ key: "patients", label: "تقارير المرضى", content: patientReports }] : []),
      ...(systemReports ? [{ key: "system", label: "تقارير النظام", content: systemReports }] : []),
    ];
    if (sections.length === 1) return <>{sections[0].content}</>;
    return <SettingsSidebarLayout initialKey={(sp as { tab?: string }).tab} sections={sections} />;
  }

  if (!data.ok) {
    if (data.reason !== "no_session" && hasExtraReports) {
      return <div className="space-y-6"><div><h1 className="text-xl font-bold">التقارير</h1><p className="mt-1 text-xs text-muted">اختر التقرير والفترة، ولن تظهر البيانات إلا بعد الضغط على عرض التقرير.</p></div>{renderReportTabs(null)}</div>;
    }
    const message =
      data.reason === "no_session"
        ? "لازم تسجل دخول عشان توصل للتقارير."
        : data.reason === "no_permission"
          ? "مفيش صلاحية عندك لعرض التقارير — كلم الأدمن لو محتاج توصل للصفحة دي."
          : "الحساب ده مالوش دكتور مرتبط بيه، فمفيش تقرير شخصي نقدر نعرضه ليك.";
    return <div className="card-3d rounded-xl p-5 text-sm text-muted">{message}</div>;
  }

  const {
    reportsFull,
    from,
    to,
    dateRangeClamped,
    reportsOwnMinFrom,
    doctorId,
    serviceId,
    doctors,
    services,
    newAmount,
    collected,
    visitCount,
    byMethod,
    byDoctor,
    byService,
    byDay,
  } = data;
  const requiresPassword = session?.role === "doctor";
  const reportUnlocked = !requiresPassword || (
    sp.applied === "1" &&
    await verifyDoctorReportAccessToken((await cookies()).get(DOCTOR_REPORT_ACCESS_COOKIE)?.value, {
      userId: session!.userId,
      from,
      to,
      doctorId,
      serviceId,
    })
  );

  if (!reportUnlocked) {
    const lockedFinancial = (
      <div className="space-y-6">
        <div>
          <h1 className="text-xl font-bold">تقرير الإيرادات</h1>
          <p className="mt-1 text-xs text-muted">اختر الفترة ثم اضغط تطبيق لإظهار الإجماليات.</p>
        </div>
        <ReportsFilterForm
          from={from}
          to={to}
          minFrom={reportsOwnMinFrom}
          doctorId={reportsFull ? doctorId : null}
          serviceId={serviceId}
          doctors={doctors}
          services={services}
          showDoctorFilter={reportsFull}
          requirePassword
        />
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="card-3d rounded-xl p-4"><div className="text-xs text-muted">إجمالي الفواتير الجديدة في الفترة</div><div className="text-2xl font-bold">0 ج.م</div></div>
          <div className="card-3d rounded-xl p-4"><div className="text-xs text-muted">المحصّل في الفترة</div><div className="text-2xl font-bold text-primary">0 ج.م</div></div>
          <div className="card-3d rounded-xl p-4"><div className="text-xs text-muted">عدد الزيارات المفوترة</div><div className="text-2xl font-bold">0</div></div>
        </div>
        <div className="rounded-xl border border-border bg-primary-soft/40 px-4 py-5 text-center text-sm text-muted">الإجماليات مخفية حتى اختيار الفترة وتأكيد كلمة المرور.</div>
      </div>
    );
    return <div className="space-y-6"><h1 className="text-xl font-bold">التقارير</h1>{renderReportTabs(lockedFinancial)}</div>;
  }
  // المصروفات تخص العيادة ككل ولا يصح خلطها بتقرير طبيب أو خدمة واحدة؛ لذلك
  // تظهر فقط في التقرير العام لمن لديه صلاحية إدارة المصروفات.
  const canViewExpenseSummary = reportsFull && !doctorId && !serviceId && !!session && (await hasPermission(session.userId, session.role, "manage_expenses"));
  const expenseSummary = canViewExpenseSummary ? await getExpenseSummary(from, to) : null;
  const [payrollDetail, suppliersDetail, miscDetail] = canViewExpenseSummary
    ? await Promise.all([getPayrollDetailReport(from, to), getSuppliersDetailReport(from, to), getMiscExpensesDetailReport(from, to)])
    : [null, null, null];


  const qs = (overrides: Record<string, string | null>) => {
    const params = new URLSearchParams();
    params.set("from", from);
    params.set("to", to);
    if (doctorId) params.set("doctor_id", String(doctorId));
    if (serviceId) params.set("service_id", String(serviceId));
    for (const [k, v] of Object.entries(overrides)) {
      if (v == null) params.delete(k);
      else params.set(k, v);
    }
    return params.toString();
  };

  const financialContent = (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-xl font-bold">تقرير الإيرادات</h1>
          {dateRangeClamped && (
            <p className="text-xs text-muted mt-1">الفترة اتقصّرت لآخر شهرين — الحد الأقصى للتقرير الشخصي.</p>
          )}
        </div>
        <div className="flex items-center gap-3">
          <a href={`/reports/export?${qs({})}`} className="text-sm px-3 py-1.5 rounded-md border border-border hover:bg-primary-soft">
            تصدير Excel
          </a>
          <Link href={`/invoices?date=${to}`} className="text-sm text-primary hover:underline">
            فتح فواتير يوم {to} بالتفصيل
          </Link>
        </div>
      </div>

      <ReportsFilterForm
        from={from}
        to={to}
        minFrom={reportsOwnMinFrom}
        doctorId={reportsFull ? doctorId : null}
        serviceId={serviceId}
        doctors={doctors}
        services={services}
        showDoctorFilter={reportsFull}
        requirePassword={requiresPassword}
      />

      <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        <div className="card-3d rounded-xl p-4">
          <div className="text-xs text-muted">إجمالي الفواتير الجديدة في الفترة</div>
          <div className="text-2xl font-bold">{newAmount.toFixed(0)} ج.م</div>
        </div>
        <div className="card-3d rounded-xl p-4">
          <div className="text-xs text-muted">المحصّل في الفترة</div>
          <div className="text-2xl font-bold text-primary">{collected.toFixed(0)} ج.م</div>
          <div className="text-[10px] text-muted mt-0.5">شامل أي دفعات متابعة اتحصّلت في الفترة دي على فواتير أقدم</div>
        </div>
        {expenseSummary && (
          <div className="card-3d rounded-xl p-4">
            <div className="text-xs text-muted">صافي النقدية (المحصّل − المصروفات)</div>
            <div className={`text-2xl font-bold ${collected - expenseSummary.total >= 0 ? "text-primary" : "text-danger"}`}>{(collected - expenseSummary.total).toFixed(0)} ج.م</div>
          </div>
        )}
        <div className="card-3d rounded-xl p-4">
          <div className="text-xs text-muted">عدد الزيارات المفوترة</div>
          <div className="text-2xl font-bold">{visitCount}</div>
        </div>
      </div>

      {renderRevenueExpenseTabs()}
    </div>
  );

  // محتوى تفصيل الإيرادات (حسب وسيلة الدفع/الدكتور/الخدمة/يوم) — كان معروضًا
  // مباشرة تحت الإجماليات، بقى تحت تبويب "إيرادات" الفرعي جوه "تقارير مالية".
  function renderRevenueTab() {
    return (
      <div className="space-y-6">
      {byMethod.length > 0 && (
        <div className="card-3d rounded-xl p-4">
          <div className="text-sm font-semibold mb-2">المحصّل حسب وسيلة الدفع</div>
          <div className="flex flex-wrap gap-4">
            {byMethod.map(([method, amount]) => (
              <div key={method} className="text-sm">
                <span className="text-muted">{paymentMethodLabel(method)}: </span>
                <span className="font-semibold">{amount.toFixed(0)} ج.م</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {byDoctor.length > 0 && (
        <div className="card-3d rounded-xl overflow-hidden">
          <div className="px-4 py-2 font-semibold text-sm bg-primary-soft text-primary-dark">حسب الدكتور</div>
          <table className="w-full text-sm">
            <thead className="bg-primary-soft/50 text-muted">
              <tr>
                <th className="text-right px-3 py-2 font-medium">الدكتور</th>
                <th className="text-right px-3 py-2 font-medium">عدد الزيارات</th>
                <th className="text-right px-3 py-2 font-medium">الفواتير الجديدة</th>
                <th className="text-right px-3 py-2 font-medium">المحصّل</th>
              </tr>
            </thead>
            <tbody>
              {byDoctor.map((row) => (
                <tr key={row.key} className="border-t border-border">
                  <td className="px-3 py-2 font-medium">
                    <Link href={`/reports?${qs({ doctor_id: String(row.key) })}`} className="text-primary hover:underline">
                      {row.label}
                    </Link>
                  </td>
                  <td className="px-3 py-2">{row.visits}</td>
                  <td className="px-3 py-2">{row.amount.toFixed(0)}</td>
                  <td className="px-3 py-2 text-primary">{row.paid.toFixed(0)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {byService.length > 0 && (
        <div className="card-3d rounded-xl overflow-hidden">
          <div className="px-4 py-2 font-semibold text-sm bg-primary-soft text-primary-dark">حسب الخدمة</div>
          <table className="w-full text-sm">
            <thead className="bg-primary-soft/50 text-muted">
              <tr>
                <th className="text-right px-3 py-2 font-medium">الخدمة</th>
                <th className="text-right px-3 py-2 font-medium">عدد الزيارات</th>
                <th className="text-right px-3 py-2 font-medium">الفواتير الجديدة</th>
                <th className="text-right px-3 py-2 font-medium">المحصّل</th>
              </tr>
            </thead>
            <tbody>
              {byService.map((row) => (
                <tr key={row.key} className="border-t border-border">
                  <td className="px-3 py-2 font-medium">
                    <Link href={`/reports?${qs({ service_id: String(row.key) })}`} className="text-primary hover:underline">
                      {row.label}
                    </Link>
                  </td>
                  <td className="px-3 py-2">{row.visits}</td>
                  <td className="px-3 py-2">{row.amount.toFixed(0)}</td>
                  <td className="px-3 py-2 text-primary">{row.paid.toFixed(0)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="card-3d rounded-xl overflow-hidden">
        <div className="px-4 py-2 font-semibold text-sm bg-primary-soft text-primary-dark">تفصيل يومي</div>
        <table className="w-full text-sm">
          <thead className="bg-primary-soft/50 text-muted">
            <tr>
              <th className="text-right px-3 py-2 font-medium">اليوم</th>
              <th className="text-right px-3 py-2 font-medium">عدد الزيارات</th>
              <th className="text-right px-3 py-2 font-medium">الفواتير الجديدة</th>
              <th className="text-right px-3 py-2 font-medium">المحصّل</th>
              <th className="text-right px-3 py-2 font-medium" />
            </tr>
          </thead>
          <tbody>
            {byDay.map((row) => (
              <tr key={row.date} className="border-t border-border">
                <td className="px-3 py-2 whitespace-nowrap">{row.date}</td>
                <td className="px-3 py-2">{row.visits}</td>
                <td className="px-3 py-2">{row.amount.toFixed(0)}</td>
                <td className="px-3 py-2 text-primary">{row.paid.toFixed(0)}</td>
                <td className="px-3 py-2">
                  <Link href={`/invoices?date=${row.date}`} className="text-xs text-primary hover:underline whitespace-nowrap">
                    تفاصيل الفواتير ←
                  </Link>
                </td>
              </tr>
            ))}
            {byDay.length === 0 && (
              <tr>
                <td colSpan={5} className="px-3 py-6 text-center text-muted">
                  لا يوجد بيانات في الفترة المختارة.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      </div>
    );
  }

  // محتوى تبويب "مصروفات": بند "المصروفات وصافي النقدية" اللي كان معروضًا في
  // تقرير الإيرادات، زائد ثلاث تقارير تفصيلية جديدة لنفس الفترة المختارة.
  function renderExpensesTab() {
    if (!expenseSummary) {
      return <div className="rounded-xl border border-border bg-primary-soft/40 px-4 py-5 text-center text-sm text-muted">تقرير المصروفات متاح فقط لمن لديه صلاحية إدارة المصروفات، وبدون فلترة على دكتور/خدمة بعينها.</div>;
    }
    return (
      <div className="space-y-6">
        <section className="card-3d rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div>
              <h2 className="font-semibold text-sm">المصروفات وصافي النقدية</h2>
              <p className="text-xs text-muted mt-1">المصروفات هنا تخص العيادة بالكامل في الفترة المختارة، وتشمل توريدات المخزن المسجلة بتكلفة.</p>
            </div>
            <Link href={`/expenses?month=${to.slice(0, 7)}`} className="text-sm text-primary hover:underline">فتح المصروفات</Link>
          </div>
          <div><span className="text-xs text-muted">إجمالي المصروفات</span><div className="text-2xl font-bold text-danger">{expenseSummary.total.toFixed(0)} ج.م</div></div>
          <div className="flex flex-wrap gap-x-5 gap-y-2 text-sm">
            {EXPENSE_CATEGORIES.map((category) => <div key={category}><span className="text-muted">{EXPENSE_CATEGORY_LABELS[category]}: </span><b>{(expenseSummary.byCategory.get(category) ?? 0).toFixed(0)} ج.م</b></div>)}
          </div>
        </section>

        {payrollDetail && (
          <div className="card-3d rounded-xl overflow-hidden">
            <div className="px-4 py-2 font-semibold text-sm bg-primary-soft text-primary-dark flex items-center justify-between gap-3 flex-wrap">
              <span>تقرير رواتب بالتفصيل</span>
              <span className="text-xs font-normal text-muted">الإجمالي: {payrollDetail.total.toFixed(0)} ج.م</span>
            </div>
            <table className="w-full text-sm">
              <thead className="bg-primary-soft/50 text-muted">
                <tr>
                  <th className="text-right px-3 py-2 font-medium">الاسم</th>
                  <th className="text-right px-3 py-2 font-medium">الفئة</th>
                  <th className="text-right px-3 py-2 font-medium">الحالة</th>
                  <th className="text-right px-3 py-2 font-medium">المبلغ</th>
                </tr>
              </thead>
              <tbody>
                {payrollDetail.rows.map((row) => (
                  <tr key={row.key} className="border-t border-border">
                    <td className="px-3 py-2 font-medium">{row.name}</td>
                    <td className="px-3 py-2">{row.group ?? "-"}</td>
                    <td className="px-3 py-2">{row.status === "paid" ? "مصروف" : "مستحق (لسه ما اتصرفش)"}</td>
                    <td className="px-3 py-2 text-danger">{row.total.toFixed(0)} ج.م</td>
                  </tr>
                ))}
                {payrollDetail.rows.length === 0 && <tr><td colSpan={4} className="px-3 py-6 text-center text-muted">لا توجد استحقاقات في الفترة المختارة.</td></tr>}
              </tbody>
            </table>
          </div>
        )}

        {suppliersDetail && (
          <div className="space-y-4">
            {([
              { key: "ortho", title: "تقرير توريدات — تقويم", rows: suppliersDetail.ortho },
              { key: "general", title: "تقرير توريدات — جينيرال", rows: suppliersDetail.general },
            ] as const).map((group) => (
              <div key={group.key} className="card-3d rounded-xl overflow-hidden">
                <div className="px-4 py-2 font-semibold text-sm bg-primary-soft text-primary-dark">{group.title}</div>
                <table className="w-full text-sm">
                  <thead className="bg-primary-soft/50 text-muted">
                    <tr>
                      <th className="text-right px-3 py-2 font-medium">المورد</th>
                      <th className="text-right px-3 py-2 font-medium">فواتير الفترة</th>
                      <th className="text-right px-3 py-2 font-medium">مدفوع في الفترة</th>
                      <th className="text-right px-3 py-2 font-medium">صافي المديونية الحالية</th>
                    </tr>
                  </thead>
                  <tbody>
                    {group.rows.map((row) => (
                      <tr key={row.id} className="border-t border-border">
                        <td className="px-3 py-2 font-medium">
                          <Link href="/expenses" className="text-primary hover:underline">{row.name}</Link>
                        </td>
                        <td className="px-3 py-2">{row.invoicedInPeriod.toFixed(0)} ج.م</td>
                        <td className="px-3 py-2">{row.paidInPeriod.toFixed(0)} ج.م</td>
                        <td className={`px-3 py-2 ${row.netDebt > 0 ? "text-danger" : "text-primary"}`}>{row.netDebt.toFixed(0)} ج.م</td>
                      </tr>
                    ))}
                    {group.rows.length === 0 && <tr><td colSpan={4} className="px-3 py-6 text-center text-muted">لا توجد حركة موردين في هذا القسم للفترة المختارة.</td></tr>}
                  </tbody>
                </table>
              </div>
            ))}
          </div>
        )}

        {miscDetail && (
          <div className="card-3d rounded-xl overflow-hidden">
            <div className="px-4 py-2 font-semibold text-sm bg-primary-soft text-primary-dark flex items-center justify-between gap-3 flex-wrap">
              <span>تقرير مصروفات نثرية بالتفصيل</span>
              <span className="text-xs font-normal text-muted">الإجمالي: {miscDetail.total.toFixed(0)} ج.م</span>
            </div>
            <table className="w-full text-sm">
              <thead className="bg-primary-soft/50 text-muted">
                <tr>
                  <th className="text-right px-3 py-2 font-medium">التاريخ</th>
                  <th className="text-right px-3 py-2 font-medium">البند</th>
                  <th className="text-right px-3 py-2 font-medium">المدفوع له</th>
                  <th className="text-right px-3 py-2 font-medium">المبلغ</th>
                  <th className="text-right px-3 py-2 font-medium">ملاحظة</th>
                </tr>
              </thead>
              <tbody>
                {miscDetail.rows.map((row) => (
                  <tr key={row.id} className="border-t border-border">
                    <td className="px-3 py-2 whitespace-nowrap">{row.expense_date}</td>
                    <td className="px-3 py-2 font-medium">{row.title}</td>
                    <td className="px-3 py-2">{row.payee ?? "-"}</td>
                    <td className="px-3 py-2 text-danger">{row.amount.toFixed(0)} ج.م</td>
                    <td className="px-3 py-2 text-muted">{row.note ?? "-"}</td>
                  </tr>
                ))}
                {miscDetail.rows.length === 0 && <tr><td colSpan={5} className="px-3 py-6 text-center text-muted">لا توجد مصروفات نثرية في الفترة المختارة.</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </div>
    );
  }

  // يلف تفصيل الإيرادات وتقرير المصروفات في تبويبين فرعيين جوه "تقارير مالية"،
  // بنفس مكوّن التبويبات المستخدم للمجموعات الرئيسية (SettingsSidebarLayout).
  function renderRevenueExpenseTabs() {
    const sections = [
      { key: "revenue", label: "إيرادات", content: renderRevenueTab() },
      { key: "expenses", label: "مصروفات", content: renderExpensesTab() },
    ];
    return <SettingsSidebarLayout initialKey={(sp as { financial_tab?: string }).financial_tab} sections={sections} />;
  }

  return <div className="space-y-6"><h1 className="text-xl font-bold">التقارير</h1>{renderReportTabs(financialContent)}</div>;
}
