"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { getTaskCenter } from "@/lib/tasks";

function refreshTasks(patientId?: number | null) {
  revalidatePath("/", "layout");
  if (patientId) revalidatePath(`/patients/${patientId}`);
}

export async function getTaskCenterAction() {
  const session = await getSession();
  if (!session) return [];
  return getTaskCenter(session.userId, session.role);
}

export async function getTaskRecipientsAction() {
  const session = await getSession();
  if (!session) return [];
  return db.selectFrom("users").select(["id", "full_name", "role"]).where("active", "=", 1).orderBy("full_name").execute();
}

export async function createTaskAction(input: { taskText: string; recipientType: "user" | "reception"; recipientUserId?: number | null; patientId?: number | null }) {
  const session = await getSession();
  const taskText = input.taskText.trim();
  if (!session) return { ok: false, reason: "غير مصرح." };
  if (!taskText || taskText.length > 2000) return { ok: false, reason: "اكتب المهمة بحد أقصى 2000 حرف." };
  let recipientUserId: number | null = null;
  if (input.recipientType === "user") {
    recipientUserId = Number(input.recipientUserId);
    if (!Number.isInteger(recipientUserId) || recipientUserId <= 0) return { ok: false, reason: "اختار مستخدمًا متاحًا." };
    const recipient = await db.selectFrom("users").select("id").where("id", "=", recipientUserId).where("active", "=", 1).executeTakeFirst();
    if (!recipient) return { ok: false, reason: "اختار مستخدمًا متاحًا." };
  }
  const patientId = input.patientId ? Number(input.patientId) : null;
  if (patientId) {
    const patient = await db.selectFrom("patients").select("id").where("id", "=", patientId).executeTakeFirst();
    if (!patient) return { ok: false, reason: "ملف المريض غير موجود." };
  }
  await db.insertInto("tasks").values({
    patient_id: patientId, created_by: session.userId, recipient_type: input.recipientType,
    recipient_user_id: recipientUserId, task_text: taskText, source_type: "manual",
  }).execute();
  refreshTasks(patientId);
  return { ok: true };
}

export async function completeTaskAction(taskId: number) {
  const session = await getSession();
  if (!session || !Number.isInteger(taskId) || taskId <= 0) return { ok: false, reason: "غير مصرح." };
  const task = await db.selectFrom("tasks").select(["id", "patient_id", "status", "recipient_type", "recipient_user_id"]).where("id", "=", taskId).executeTakeFirst();
  const isRecipient = task && (task.recipient_user_id === session.userId || (task.recipient_type === "reception" && session.role === "reception"));
  if (!task || task.status !== "open" || !isRecipient) return { ok: false, reason: "المهمة غير متاحة للتنفيذ." };
  const now = new Date().toISOString();
  await db.updateTable("tasks").set({ status: "completed", completed_by: session.userId, completed_at: now, updated_at: now }).where("id", "=", task.id).execute();
  refreshTasks(task.patient_id);
  return { ok: true };
}

export async function closeTaskAction(taskId: number) {
  const session = await getSession();
  if (!session || !Number.isInteger(taskId) || taskId <= 0) return { ok: false, reason: "غير مصرح." };
  const task = await db.selectFrom("tasks").select(["id", "patient_id", "status", "created_by"]).where("id", "=", taskId).executeTakeFirst();
  if (!task || task.status !== "completed" || task.created_by !== session.userId) return { ok: false, reason: "صاحب المهمة فقط يقدر يقفلها بعد التنفيذ." };
  const now = new Date().toISOString();
  await db.updateTable("tasks").set({ status: "closed", closed_by: session.userId, closed_at: now, updated_at: now }).where("id", "=", task.id).execute();
  refreshTasks(task.patient_id);
  return { ok: true };
}
