"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";

function nowSql() {
  return new Date().toISOString().replace("T", " ").slice(0, 19);
}

export async function createReferralAction(input: { appointmentId: number; toDoctorId: number; requestText: string }) {
  const session = await getSession();
  if (!session || session.role !== "doctor" || !session.doctorId) return { ok: false, error: "غير مصرح" };
  const sourceDoctorId = session.doctorId;
  const requestText = input.requestText.trim();
  if (!input.appointmentId || !input.toDoctorId || !requestText) return { ok: false, error: "اختار الطبيب واكتب المطلوب." };
  if (input.toDoctorId === sourceDoctorId) return { ok: false, error: "اختار طبيبًا آخر." };

  const appointment = await db
    .selectFrom("appointments")
    .innerJoin("patients", "patients.id", "appointments.patient_id")
    .innerJoin("doctors", "doctors.id", "appointments.doctor_id")
    .select(["appointments.id", "appointments.patient_id", "appointments.doctor_id", "patients.full_name as patient_name", "doctors.full_name as from_name"])
    .where("appointments.id", "=", input.appointmentId)
    .executeTakeFirst();
  const target = await db.selectFrom("doctors").select(["id", "full_name"]).where("id", "=", input.toDoctorId).where("active", "=", 1).executeTakeFirst();
  if (!appointment || appointment.doctor_id !== sourceDoctorId || !target) return { ok: false, error: "تعذر إنشاء التحويل." };

  const recipient = await db.selectFrom("users").select("id").where("active", "=", 1).where("doctor_id", "=", target.id).orderBy("id").executeTakeFirst();
  if (!recipient) return { ok: false, error: "الطبيب المحول إليه ليس له حساب مستخدم نشط." };
  await db.transaction().execute(async (trx) => {
    const inserted = await trx.insertInto("patient_referrals").values({
      patient_id: appointment.patient_id,
      appointment_id: appointment.id,
      from_doctor_id: sourceDoctorId,
      to_doctor_id: target.id,
      request_text: requestText,
      created_by: session.userId,
    }).executeTakeFirstOrThrow();
    await trx.insertInto("tasks").values({
      patient_id: appointment.patient_id, created_by: session.userId,
      recipient_type: "user", recipient_user_id: recipient.id,
      task_text: requestText, source_type: "referral", referral_id: Number(inserted.insertId),
    }).execute();
  });
  revalidatePath(`/patients/${appointment.patient_id}`);
  revalidatePath("/", "layout");
  return { ok: true };
}

export async function completeReferralAction(referralId: number) {
  const session = await getSession();
  if (!session || !session.doctorId) return { ok: false, error: "غير مصرح" };
  const referral = await db
    .selectFrom("patient_referrals")
    .innerJoin("patients", "patients.id", "patient_referrals.patient_id")
    .innerJoin("doctors as source_doctor", "source_doctor.id", "patient_referrals.from_doctor_id")
    .innerJoin("doctors as target_doctor", "target_doctor.id", "patient_referrals.to_doctor_id")
    .select(["patient_referrals.id", "patient_referrals.patient_id", "patient_referrals.from_doctor_id", "patient_referrals.to_doctor_id", "patient_referrals.status", "patient_referrals.request_text", "patients.full_name as patient_name", "source_doctor.full_name as source_name", "target_doctor.full_name as target_name"])
    .where("patient_referrals.id", "=", referralId)
    .executeTakeFirst();
  if (!referral || referral.status !== "pending" || referral.to_doctor_id !== session.doctorId) return { ok: false, error: "التحويل غير متاح." };
  await db.updateTable("patient_referrals").set({ status: "completed", completed_by: session.userId, completed_at: nowSql() }).where("id", "=", referralId).execute();
  await db.updateTable("tasks").set({ status: "completed", completed_by: session.userId, completed_at: nowSql(), updated_at: nowSql() }).where("referral_id", "=", referral.id).where("status", "=", "open").execute();
  revalidatePath(`/patients/${referral.patient_id}`);
  revalidatePath("/", "layout");
  return { ok: true };
}
