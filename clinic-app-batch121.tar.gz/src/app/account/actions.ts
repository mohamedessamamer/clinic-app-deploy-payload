"use server";

import { revalidatePath } from "next/cache";
import { cookies, headers } from "next/headers";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { REMEMBERED_SESSION_MAX_AGE_SECONDS, SESSION_COOKIE, STANDARD_SESSION_MAX_AGE_SECONDS, createSessionToken } from "@/lib/auth";

export async function setMedicalUiLanguageAction(language: "en" | "ar") {
  const session = await getSession();
  if (!session || (language !== "en" && language !== "ar")) return;

  await db.updateTable("users").set({ medical_ui_language: language }).where("id", "=", session.userId).execute();
  revalidatePath("/", "layout");
  revalidatePath("/patients");
}

export async function setColorThemeAction(theme: "revere" | "medical") {
  const session = await getSession();
  if (!session || (theme !== "revere" && theme !== "medical")) return;

  await db.updateTable("users").set({ color_theme: theme }).where("id", "=", session.userId).execute();
  revalidatePath("/", "layout");
}

// لا نحتاج جدول أجهزة منفصل: session_version الموجودة بالفعل تبطل كل JWTs
// فورًا، بما فيها الجهاز الحالي، بدون أن نترك أي جلسة قديمة صالحة.
export async function signOutAllDevicesAction() {
  const session = await getSession();
  if (!session) return;
  await db.updateTable("users").set((eb) => ({ session_version: eb("session_version", "+", 1) })).where("id", "=", session.userId).execute();
  (await cookies()).delete(SESSION_COOKIE);
}

export async function setKeepSignedInThisDeviceAction(keepSignedIn: boolean) {
  const session = await getSession();
  if (!session) return;
  const token = await createSessionToken({ ...session, keepSignedIn: keepSignedIn === true });
  const isHttps = (await headers()).get("x-forwarded-proto") === "https";
  (await cookies()).set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: isHttps,
    path: "/",
    maxAge: keepSignedIn ? REMEMBERED_SESSION_MAX_AGE_SECONDS : STANDARD_SESSION_MAX_AGE_SECONDS,
  });
  revalidatePath("/", "layout");
}
