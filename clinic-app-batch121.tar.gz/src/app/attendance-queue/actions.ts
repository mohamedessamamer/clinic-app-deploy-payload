"use server";

import { db } from "@/lib/db/client";
import { getClinicToday } from "@/lib/clinic-date";
import { getSession } from "@/lib/session";

type QueuePatient = { appointmentId: number; patientName: string; attendedAt: string | null };
export type AttendanceQueueData = { queue: QueuePatient[]; entered: { roomId: number; roomName: string; patientName: string }[] };
const shortName = (name: string) => name.trim().split(/\s+/).slice(0, 2).join(" ");

export async function getAttendanceQueueAction(): Promise<AttendanceQueueData> {
  const session = await getSession();
  if (!session) return { queue: [], entered: [] };

  const rows = await db
    .selectFrom("appointments")
    .innerJoin("patients", "patients.id", "appointments.patient_id")
    .leftJoin("rooms as entered_rooms", "entered_rooms.id", "appointments.entered_room_id")
    .select([
      "appointments.id as appointment_id",
      "appointments.start_time",
      "appointments.attended_at",
      "appointments.entered_room_id",
      "patients.full_name as patient_name",
      "entered_rooms.name as entered_room_name",
    ])
    .where("appointments.appointment_date", "=", getClinicToday())
    .where("appointments.status", "=", "attended")
    .orderBy("appointments.attended_at", "asc")
    .execute();

  const queue = rows.filter((row) => !row.entered_room_id).sort((a,b) => (a.attended_at ?? a.start_time).localeCompare(b.attended_at ?? b.start_time)).map((row) => ({ appointmentId: row.appointment_id, patientName: shortName(row.patient_name), attendedAt: row.attended_at }));
  const entered = rows.filter((row) => row.entered_room_id).map((row) => ({ roomId: row.entered_room_id!, roomName: row.entered_room_name ?? "عيادة", patientName: shortName(row.patient_name) }));
  return { queue, entered };
}
