"use client";

import { useMemo, useState } from "react";
import { addVisitAction } from "@/app/patients/[id]/actions";

type Service = { id: number; name: string };
type Doctor = { id: number; full_name: string };

export default function AddVisitForm({
  patientId,
  services,
  doctors,
  serviceDoctorMap,
}: {
  patientId: number;
  services: Service[];
  doctors: Doctor[];
  serviceDoctorMap: Record<number, number[]>;
}) {
  const today = useMemo(() => new Date().toISOString().slice(0, 10), []);
  const [serviceId, setServiceId] = useState<string>("");

  const filteredDoctors = useMemo(() => {
    if (!serviceId) return doctors;
    const allowed = serviceDoctorMap[Number(serviceId)] || [];
    return doctors.filter((d) => allowed.includes(d.id));
  }, [serviceId, doctors, serviceDoctorMap]);

  return (
    <form action={addVisitAction} className="grid grid-cols-1 sm:grid-cols-5 gap-2 items-end">
      <input type="hidden" name="patient_id" value={patientId} />
      <div className="sm:col-span-1">
        <label className="block text-xs text-muted mb-1">التاريخ</label>
        <input
          type="date"
          name="visit_date"
          defaultValue={today}
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>
      <div className="sm:col-span-1">
        <label className="block text-xs text-muted mb-1">نوع الخدمة</label>
        <select
          name="service_id"
          value={serviceId}
          onChange={(e) => setServiceId(e.target.value)}
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        >
          <option value="">اختر خدمة</option>
          {services.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
      </div>
      <div className="sm:col-span-2">
        <label className="block text-xs text-muted mb-1">المعالجة</label>
        <input
          name="notes"
          placeholder="تفاصيل اللي تم عمله..."
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>
      <div className="sm:col-span-1">
        <label className="block text-xs text-muted mb-1">الدكتور</label>
        <select
          name="doctor_id"
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        >
          <option value="">اختر دكتور</option>
          {filteredDoctors.map((d) => (
            <option key={d.id} value={d.id}>
              {d.full_name}
            </option>
          ))}
        </select>
      </div>
      <div className="sm:col-span-5">
        <button
          type="submit"
          className="rounded-md bg-primary text-white px-4 py-1.5 text-sm font-medium hover:bg-primary-dark transition-colors"
        >
          + إضافة زيارة
        </button>
      </div>
    </form>
  );
}
