"use client";

import { useTransition } from "react";
import { logoutAction } from "@/app/logout/actions";

export default function LogoutButton() {
  const [isPending, startTransition] = useTransition();

  return (
    <button
      type="button"
      disabled={isPending}
      onClick={() => {
        startTransition(async () => {
          await logoutAction();
          window.location.assign("/login");
        });
      }}
      className="px-3 py-1.5 rounded-md border border-border hover:bg-danger-soft hover:text-danger hover:border-danger transition-colors disabled:opacity-60"
    >
      خروج
    </button>
  );
}
