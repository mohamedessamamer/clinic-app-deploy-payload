"use client";

import { useMemo } from "react";
import { addImageGroupAction } from "@/app/patients/[id]/actions";

export default function AddImageGroupForm({ patientId }: { patientId: number }) {
  const today = useMemo(() => new Date().toISOString().slice(0, 10), []);

  return (
    <form
      action={addImageGroupAction}
      encType="multipart/form-data"
      className="flex flex-wrap items-end gap-2 border-t border-dashed border-border pt-3 mt-1"
    >
      <input type="hidden" name="patient_id" value={patientId} />
      <div>
        <label className="block text-xs text-muted mb-1">التاريخ</label>
        <input
          type="date"
          name="taken_at"
          defaultValue={today}
          className="rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">وصف (اختياري)</label>
        <input
          name="label"
          placeholder="مثال: أشعة بانوراما"
          className="rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">الصور/الأشعة</label>
        <input
          type="file"
          name="files"
          multiple
          accept="image/*,.pdf"
          className="text-sm file:ml-2 file:rounded-md file:border-0 file:bg-primary-soft file:text-primary-dark file:px-3 file:py-1.5"
        />
      </div>
      <button
        type="submit"
        className="rounded-md bg-primary text-white px-4 py-1.5 text-sm font-medium hover:bg-primary-dark transition-colors"
      >
        + إضافة مجموعة
      </button>
    </form>
  );
}
