"use client";

import { addAppointmentAction } from "@/app/appointments/actions";

type Room = { id: number; name: string };
type Patient = { id: number; full_name: string; file_number: string };
type Doctor = { id: number; full_name: string };

export default function AppointmentForm({
  date,
  rooms,
  patients,
  doctors,
  timeSlots,
}: {
  date: string;
  rooms: Room[];
  patients: Patient[];
  doctors: Doctor[];
  timeSlots: string[];
}) {
  // Any doctor can be booked into any room's timeslot (primary/assisting doctor
  // flexibility per the clinic's workflow) — no filtering here on purpose.
  return (
    <form action={addAppointmentAction} className="grid grid-cols-1 sm:grid-cols-6 gap-2 items-end">
      <input type="hidden" name="appointment_date" value={date} />
      <div className="sm:col-span-2">
        <label className="block text-xs text-muted mb-1">المريض</label>
        <select
          name="patient_id"
          required
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        >
          <option value="">اختر مريض</option>
          {patients.map((p) => (
            <option key={p.id} value={p.id}>
              {p.full_name} ({p.file_number})
            </option>
          ))}
        </select>
      </div>
      <div className="sm:col-span-1">
        <label className="block text-xs text-muted mb-1">العيادة/الغرفة</label>
        <select
          name="room_id"
          required
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        >
          <option value="">اختر غرفة</option>
          {rooms.map((r) => (
            <option key={r.id} value={r.id}>
              {r.name}
            </option>
          ))}
        </select>
      </div>
      <div className="sm:col-span-1">
        <label className="block text-xs text-muted mb-1">الدكتور</label>
        <select
          name="doctor_id"
          required
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        >
          <option value="">اختر دكتور</option>
          {doctors.map((d) => (
            <option key={d.id} value={d.id}>
              {d.full_name}
            </option>
          ))}
        </select>
      </div>
      <div className="sm:col-span-1">
        <label className="block text-xs text-muted mb-1">الوقت</label>
        <select
          name="start_time"
          required
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        >
          {timeSlots.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
      </div>
      <div className="sm:col-span-1">
        <button
          type="submit"
          className="w-full rounded-md bg-primary text-white px-3 py-1.5 text-sm font-medium hover:bg-primary-dark transition-colors"
        >
          + حجز
        </button>
      </div>
    </form>
  );
}
