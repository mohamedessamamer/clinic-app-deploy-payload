"use client";

import { updateAppointmentStatusAction } from "@/app/appointments/actions";

const STATUS_LABELS: Record<string, string> = {
  booked: "محجوز",
  done: "تم",
  cancelled: "ملغي",
  no_show: "لم يحضر",
};

export default function StatusSelect({ id, status }: { id: number; status: string }) {
  return (
    <form action={updateAppointmentStatusAction} className="inline-flex items-center gap-1">
      <input type="hidden" name="id" value={id} />
      <select
        name="status"
        defaultValue={status}
        onChange={(e) => e.currentTarget.form?.requestSubmit()}
        className="rounded-md border border-border bg-background px-2 py-1 text-xs"
      >
        {Object.entries(STATUS_LABELS).map(([value, label]) => (
          <option key={value} value={value}>
            {label}
          </option>
        ))}
      </select>
    </form>
  );
}
