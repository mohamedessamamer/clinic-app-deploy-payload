import Database from "better-sqlite3";
import { Kysely, SqliteDialect } from "kysely";
import fs from "node:fs";
import path from "node:path";
import type { Database as DB } from "./types";

const DB_PATH = process.env.CLINIC_DB_PATH || path.join(process.cwd(), "data", "clinic.db");

// Ensure the data directory exists (works for local disk in dev; a real deployment
// on the VPS would point CLINIC_DB_PATH at a persistent volume).
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const sqlite = new Database(DB_PATH);
sqlite.pragma("journal_mode = WAL");
sqlite.pragma("foreign_keys = ON");

// Run schema.sql once at startup — idempotent (CREATE TABLE IF NOT EXISTS).
const schemaPath = path.join(process.cwd(), "src", "lib", "db", "schema.sql");
if (fs.existsSync(schemaPath)) {
  sqlite.exec(fs.readFileSync(schemaPath, "utf-8"));
}

// Lightweight migrations for columns added after the initial CREATE TABLE.
// SQLite has no "ADD COLUMN IF NOT EXISTS", so we just swallow the duplicate-column error.
function tryAddColumn(table: string, ddl: string) {
  try {
    sqlite.exec(`ALTER TABLE ${table} ADD COLUMN ${ddl}`);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    if (!message.includes("duplicate column name")) throw err;
  }
}
tryAddColumn("invoices", "discount_percent REAL NOT NULL DEFAULT 0");
tryAddColumn("invoices", "price_overridden INTEGER NOT NULL DEFAULT 0");

export const db = new Kysely<DB>({
  dialect: new SqliteDialect({ database: sqlite }),
});

export const rawSqlite = sqlite;
