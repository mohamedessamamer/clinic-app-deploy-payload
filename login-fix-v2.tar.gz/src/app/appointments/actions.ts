"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";

export async function addShiftAction(formData: FormData) {
  const room_id = Number(formData.get("room_id"));
  const doctor_id = Number(formData.get("doctor_id"));
  const shift_date = String(formData.get("shift_date") || "");
  const start_time = String(formData.get("start_time") || "");
  const end_time = String(formData.get("end_time") || "");

  if (!room_id || !doctor_id || !shift_date || !start_time || !end_time) return;

  await db.insertInto("shifts").values({ room_id, doctor_id, shift_date, start_time, end_time }).execute();
  revalidatePath("/appointments");
  revalidatePath("/settings");
  revalidatePath("/front-desk");
}

export async function addAppointmentAction(formData: FormData) {
  const patient_id = Number(formData.get("patient_id"));
  const room_id = Number(formData.get("room_id"));
  const doctor_id = Number(formData.get("doctor_id"));
  const appointment_date = String(formData.get("appointment_date") || "");
  const start_time = String(formData.get("start_time") || "");
  const notes = String(formData.get("notes") || "").trim() || null;

  if (!patient_id || !room_id || !doctor_id || !appointment_date || !start_time) return;

  await db
    .insertInto("appointments")
    .values({ patient_id, room_id, doctor_id, appointment_date, start_time, notes })
    .execute();
  revalidatePath("/appointments");
}

export async function updateAppointmentStatusAction(formData: FormData) {
  const id = Number(formData.get("id"));
  const status = String(formData.get("status") || "") as "booked" | "done" | "cancelled" | "no_show";
  if (!id || !status) return;
  await db.updateTable("appointments").set({ status }).where("id", "=", id).execute();
  revalidatePath("/appointments");
}
