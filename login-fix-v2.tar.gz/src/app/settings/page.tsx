import { getAllSettings, buildTimeSlots } from "@/lib/settings";
import { getSession } from "@/lib/session";
import { db } from "@/lib/db/client";
import { saveSettingsAction, changePasswordAction } from "./actions";
import { addShiftAction } from "../appointments/actions";

const PW_ERROR_LABELS: Record<string, string> = {
  missing: "لازم تملى كل الحقول.",
  short: "كلمة السر الجديدة لازم تكون 6 حروف/أرقام على الأقل.",
  mismatch: "كلمة السر الجديدة وتأكيدها مش متطابقين.",
  wrong: "كلمة السر الحالية غلط.",
};

export default async function SettingsPage({
  searchParams,
}: {
  searchParams: Promise<{ date?: string; pwerror?: string; pwsuccess?: string }>;
}) {
  const session = await getSession();

  if (!session) {
    return (
      <div className="bg-surface border border-border rounded-xl p-5 text-sm text-muted">
        لازم تسجل دخول عشان توصل للإعدادات.
      </div>
    );
  }

  const { date, pwerror, pwsuccess } = await searchParams;

  const changePasswordSection = (
    <section className="bg-surface border border-border rounded-xl p-5 space-y-4 max-w-lg">
      <h2 className="font-semibold">تغيير كلمة السر</h2>
      {pwsuccess && (
        <p className="text-sm text-green-700 bg-green-50 border border-green-200 rounded-md px-3 py-2">
          تم تغيير كلمة السر بنجاح.
        </p>
      )}
      {pwerror && (
        <p className="text-sm text-red-700 bg-red-50 border border-red-200 rounded-md px-3 py-2">
          {PW_ERROR_LABELS[pwerror] || "حصل خطأ، حاول تاني."}
        </p>
      )}
      <form action={changePasswordAction} className="space-y-3">
        <div>
          <label className="block text-sm text-muted mb-1">كلمة السر الحالية</label>
          <input
            type="password"
            name="current_password"
            required
            className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-sm text-muted mb-1">كلمة السر الجديدة</label>
          <input
            type="password"
            name="new_password"
            required
            minLength={6}
            className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-sm text-muted mb-1">تأكيد كلمة السر الجديدة</label>
          <input
            type="password"
            name="confirm_password"
            required
            minLength={6}
            className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
          />
        </div>
        <button
          type="submit"
          className="rounded-md bg-primary text-white px-4 py-2 text-sm font-medium hover:bg-primary-dark transition-colors"
        >
          حفظ كلمة السر
        </button>
      </form>
    </section>
  );

  if (session.role !== "admin") {
    return (
      <div className="space-y-6">
        <h1 className="text-xl font-bold">الإعدادات</h1>
        {changePasswordSection}
        <div className="bg-surface border border-border rounded-xl p-5 text-sm text-muted max-w-lg">
          باقي الإعدادات (وحدة الزمن والشيفتات) متاحة لمدير النظام فقط.
        </div>
      </div>
    );
  }
  const day = date && /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : new Date().toISOString().slice(0, 10);

  const [settings, rooms, doctors, shifts] = await Promise.all([
    getAllSettings(),
    db.selectFrom("rooms").selectAll().execute(),
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).execute(),
    db
      .selectFrom("shifts")
      .leftJoin("rooms", "rooms.id", "shifts.room_id")
      .leftJoin("doctors", "doctors.id", "shifts.doctor_id")
      .select([
        "shifts.id",
        "shifts.start_time",
        "shifts.end_time",
        "rooms.name as room_name",
        "doctors.full_name as doctor_name",
      ])
      .where("shift_date", "=", day)
      .orderBy("shifts.start_time")
      .execute(),
  ]);

  const timeSlots = buildTimeSlots(settings.day_start, settings.day_end, Number(settings.slot_minutes));

  return (
    <div className="max-w-lg space-y-6">
      <h1 className="text-xl font-bold">إعدادات العيادة</h1>

      {changePasswordSection}

      <form action={saveSettingsAction} className="bg-surface border border-border rounded-xl p-5 space-y-4">
        <h2 className="font-semibold">وحدة الزمن</h2>
        <div>
          <label className="block text-sm text-muted mb-1">وحدة الزمن (مدة الموعد الواحد بالدقايق)</label>
          <select
            name="slot_minutes"
            defaultValue={settings.slot_minutes}
            className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
          >
            {[5, 10, 15, 20, 30, 45, 60].map((m) => (
              <option key={m} value={m}>
                {m} دقيقة
              </option>
            ))}
          </select>
          <p className="text-xs text-muted mt-1">
            ده بيتحكم في الفواصل الزمنية اللي بتظهر عند حجز موعد جديد (مثلاً كل 15 دقيقة).
          </p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-muted mb-1">بداية يوم العمل</label>
            <input
              type="time"
              name="day_start"
              defaultValue={settings.day_start}
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-muted mb-1">نهاية يوم العمل</label>
            <input
              type="time"
              name="day_end"
              defaultValue={settings.day_end}
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
            />
          </div>
        </div>

        <button
          type="submit"
          className="rounded-md bg-primary text-white px-4 py-2 text-sm font-medium hover:bg-primary-dark transition-colors"
        >
          حفظ الإعدادات
        </button>
      </form>

      <section className="bg-surface border border-border rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <h2 className="font-semibold">الدكتور صاحب الشيفت</h2>
          <form className="flex items-center gap-2">
            <label className="text-sm text-muted">اليوم:</label>
            <input
              type="date"
              name="date"
              defaultValue={day}
              className="rounded-md border border-border bg-surface px-2 py-1.5 text-sm"
            />
            <button type="submit" className="px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft">
              عرض
            </button>
          </form>
        </div>
        <p className="text-xs text-muted -mt-2">
          هنا بتحدد مين الدكتور صاحب الشيفت في كل غرفة، وده اللي هيتحدد تلقائيًا في سجل الاستقبال والفواتير لحد ما يتغير.
        </p>

        <form action={addShiftAction} className="grid grid-cols-1 sm:grid-cols-5 gap-2 items-end">
          <input type="hidden" name="shift_date" value={day} />
          <div>
            <label className="block text-xs text-muted mb-1">الغرفة</label>
            <select
              name="room_id"
              required
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
            >
              {rooms.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">الدكتور صاحب الشيفت</label>
            <select
              name="doctor_id"
              required
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
            >
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.full_name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">من</label>
            <select name="start_time" required className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm">
              {timeSlots.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">إلى</label>
            <select name="end_time" required className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm">
              {timeSlots.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>
          <button type="submit" className="rounded-md bg-primary text-white px-3 py-1.5 text-sm font-medium hover:bg-primary-dark">
            + إضافة شيفت
          </button>
        </form>

        <div className="flex flex-wrap gap-2">
          {shifts.map((s) => (
            <span key={s.id} className="text-xs bg-primary-soft text-primary-dark rounded-full px-3 py-1.5">
              {s.room_name} · {s.doctor_name} · {s.start_time}–{s.end_time}
            </span>
          ))}
          {shifts.length === 0 && <p className="text-sm text-muted">مفيش شيفتات مسجلة لليوم ده.</p>}
        </div>
      </section>
    </div>
  );
}
