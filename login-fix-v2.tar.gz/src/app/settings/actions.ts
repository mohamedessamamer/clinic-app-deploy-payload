"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { setSetting } from "@/lib/settings";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hashPassword, verifyPassword } from "@/lib/auth";

export async function saveSettingsAction(formData: FormData) {
  const slot_minutes = String(formData.get("slot_minutes") || "15");
  const day_start = String(formData.get("day_start") || "09:00");
  const day_end = String(formData.get("day_end") || "22:00");

  await setSetting("slot_minutes", slot_minutes);
  await setSetting("day_start", day_start);
  await setSetting("day_end", day_end);

  revalidatePath("/settings");
  revalidatePath("/appointments");
}

export async function changePasswordAction(formData: FormData) {
  const session = await getSession();
  if (!session) {
    redirect("/login");
  }

  const currentPassword = String(formData.get("current_password") || "");
  const newPassword = String(formData.get("new_password") || "");
  const confirmPassword = String(formData.get("confirm_password") || "");

  if (!currentPassword || !newPassword || !confirmPassword) {
    redirect("/settings?pwerror=missing");
  }
  if (newPassword.length < 6) {
    redirect("/settings?pwerror=short");
  }
  if (newPassword !== confirmPassword) {
    redirect("/settings?pwerror=mismatch");
  }

  const user = await db
    .selectFrom("users")
    .selectAll()
    .where("id", "=", session.userId)
    .executeTakeFirst();

  if (!user || !(await verifyPassword(currentPassword, user.password_hash))) {
    redirect("/settings?pwerror=wrong");
  }

  const newHash = await hashPassword(newPassword);
  await db.updateTable("users").set({ password_hash: newHash }).where("id", "=", session.userId).execute();

  redirect("/settings?pwsuccess=1");
}
