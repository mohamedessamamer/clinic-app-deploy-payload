import { notFound } from "next/navigation";
import Link from "next/link";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";

export default async function PatientBillingPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const patientId = Number(id);
  if (!patientId) notFound();

  const session = await getSession();
  const patient = await db.selectFrom("patients").selectAll().where("id", "=", patientId).executeTakeFirst();
  if (!patient) notFound();

  // Doctors only ever see the services where they are the primary (revenue) doctor on the visit —
  // never the full financial picture across every doctor who treated this patient.
  const isDoctorScoped = session?.role === "doctor" && !!session.doctorId;

  let query = db
    .selectFrom("invoices")
    .innerJoin("visits", "visits.id", "invoices.visit_id")
    .leftJoin("services", "services.id", "visits.service_id")
    .leftJoin("doctors", "doctors.id", "visits.primary_doctor_id")
    .select([
      "invoices.id",
      "invoices.amount",
      "invoices.paid",
      "invoices.discount_percent",
      "visits.visit_date",
      "services.name as service_name",
      "doctors.full_name as doctor_name",
    ])
    .where("visits.patient_id", "=", patientId)
    .orderBy("visits.visit_date", "desc");

  if (isDoctorScoped) {
    query = query.where("visits.primary_doctor_id", "=", session!.doctorId!);
  }

  const invoices = await query.execute();

  const totals = invoices.reduce(
    (acc, inv) => {
      acc.amount += inv.amount;
      acc.paid += inv.paid;
      return acc;
    },
    { amount: 0, paid: 0 }
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <div className="text-xs text-muted">ملف رقم {patient.file_number}</div>
          <h1 className="text-xl font-bold">الملف المالي — {patient.full_name}</h1>
          {isDoctorScoped && (
            <p className="text-xs text-muted mt-1">
              بيظهرلك بس الخدمات اللي أنت الدكتور الأساسي فيها (اللي بيتحسب لك دخلها).
            </p>
          )}
        </div>
        <Link href={`/patients/${patientId}`} className="text-sm text-primary hover:underline">
          الرجوع للملف الطبي
        </Link>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-surface border border-border rounded-xl p-4">
          <div className="text-xs text-muted">إجمالي المستحق</div>
          <div className="text-2xl font-bold">{totals.amount.toFixed(0)} ج.م</div>
        </div>
        <div className="bg-surface border border-border rounded-xl p-4">
          <div className="text-xs text-muted">المدفوع</div>
          <div className="text-2xl font-bold text-primary">{totals.paid.toFixed(0)} ج.م</div>
        </div>
        <div className="bg-surface border border-border rounded-xl p-4">
          <div className="text-xs text-muted">الباقي عليه</div>
          <div className="text-2xl font-bold text-danger">{(totals.amount - totals.paid).toFixed(0)} ج.م</div>
        </div>
      </div>

      <div className="bg-surface border border-border rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-primary-soft text-primary-dark">
            <tr>
              <th className="text-right px-3 py-2 font-medium">التاريخ</th>
              <th className="text-right px-3 py-2 font-medium">الخدمة</th>
              {!isDoctorScoped && <th className="text-right px-3 py-2 font-medium">الدكتور</th>}
              <th className="text-right px-3 py-2 font-medium">الخصم</th>
              <th className="text-right px-3 py-2 font-medium">المبلغ</th>
              <th className="text-right px-3 py-2 font-medium">المدفوع</th>
              <th className="text-right px-3 py-2 font-medium">الباقي</th>
            </tr>
          </thead>
          <tbody>
            {invoices.map((inv) => (
              <tr key={inv.id} className="border-t border-border">
                <td className="px-3 py-2 text-muted whitespace-nowrap">{inv.visit_date}</td>
                <td className="px-3 py-2">{inv.service_name ?? "-"}</td>
                {!isDoctorScoped && <td className="px-3 py-2">{inv.doctor_name ?? "-"}</td>}
                <td className="px-3 py-2">{inv.discount_percent ? `${inv.discount_percent}%` : "-"}</td>
                <td className="px-3 py-2">{inv.amount.toFixed(0)}</td>
                <td className="px-3 py-2">{inv.paid.toFixed(0)}</td>
                <td className="px-3 py-2 text-danger">{(inv.amount - inv.paid).toFixed(0)}</td>
              </tr>
            ))}
            {invoices.length === 0 && (
              <tr>
                <td colSpan={isDoctorScoped ? 6 : 7} className="px-3 py-6 text-center text-muted">
                  لا يوجد فواتير مسجلة.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
