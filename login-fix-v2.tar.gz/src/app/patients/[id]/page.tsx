import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db/client";
import AddVisitForm from "@/components/AddVisitForm";
import AddImageGroupForm from "@/components/AddImageGroupForm";
import NextAppointmentForm from "@/components/NextAppointmentForm";
import { getAllSettings, buildTimeSlots } from "@/lib/settings";

export default async function PatientDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const patientId = Number(id);
  if (!patientId) notFound();

  const patient = await db.selectFrom("patients").selectAll().where("id", "=", patientId).executeTakeFirst();
  if (!patient) notFound();

  const [visits, doctors, services, serviceDoctorRows, imageGroups, rooms, settings] = await Promise.all([
    db
      .selectFrom("visits")
      .leftJoin("services", "services.id", "visits.service_id")
      .leftJoin("doctors", "doctors.id", "visits.primary_doctor_id")
      .select([
        "visits.id",
        "visits.visit_date",
        "visits.notes",
        "services.name as service_name",
        "doctors.full_name as doctor_name",
      ])
      .where("visits.patient_id", "=", patientId)
      .orderBy("visits.visit_date", "desc")
      .execute(),
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).execute(),
    db.selectFrom("services").select(["id", "name"]).execute(),
    db.selectFrom("service_doctors").select(["service_id", "doctor_id"]).execute(),
    db
      .selectFrom("patient_image_groups")
      .selectAll()
      .where("patient_id", "=", patientId)
      .orderBy("taken_at", "desc")
      .execute(),
    db.selectFrom("rooms").selectAll().execute(),
    getAllSettings(),
  ]);

  const timeSlots = buildTimeSlots(settings.day_start, settings.day_end, Number(settings.slot_minutes));

  const imageGroupsWithFiles = await Promise.all(
    imageGroups.map(async (g) => ({
      ...g,
      images: await db.selectFrom("patient_images").selectAll().where("group_id", "=", g.id).execute(),
    }))
  );

  const serviceDoctorMap: Record<number, number[]> = {};
  for (const row of serviceDoctorRows) {
    (serviceDoctorMap[row.service_id] ??= []).push(row.doctor_id);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <div className="text-xs text-muted">ملف رقم {patient.file_number}</div>
          <h1 className="text-xl font-bold">{patient.full_name}</h1>
          <div className="text-sm text-muted mt-1 flex gap-4 flex-wrap">
            {patient.age && <span>السن: {patient.age}</span>}
            {patient.phone && <span>التليفون: {patient.phone}</span>}
            {patient.address && <span>العنوان: {patient.address}</span>}
          </div>
        </div>
        <Link
          href={`/patients/${patientId}/billing`}
          target="_blank"
          rel="noopener noreferrer"
          className="px-3 py-2 rounded-md border border-border text-sm hover:bg-primary-soft whitespace-nowrap"
        >
          الملف المالي
        </Link>
      </div>

      {/* Quick booking for the patient's next appointment before they leave */}
      <section className="bg-surface border border-border rounded-xl p-5 space-y-3">
        <h2 className="font-semibold">حجز الموعد القادم</h2>
        <NextAppointmentForm patientId={patientId} rooms={rooms} doctors={doctors} timeSlots={timeSlots} />
      </section>

      {/* Image / X-ray gallery */}
      <section className="bg-surface border border-border rounded-xl p-5 space-y-3">
        <h2 className="font-semibold">الصور والأشعة</h2>

        {imageGroupsWithFiles.length > 0 ? (
          <div className="flex gap-4 overflow-x-auto pb-2">
            {imageGroupsWithFiles.map((g) => (
              <div key={g.id} className="shrink-0 w-40 border border-border rounded-lg p-2 bg-background">
                <div className="grid grid-cols-2 gap-1">
                  {g.images.slice(0, 4).map((img) => (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      key={img.id}
                      src={img.file_path}
                      alt={g.label || "صورة"}
                      className="w-full h-14 object-cover rounded"
                    />
                  ))}
                  {g.images.length === 0 && (
                    <div className="col-span-2 h-14 flex items-center justify-center text-xs text-muted bg-surface rounded">
                      لا صور
                    </div>
                  )}
                </div>
                <div className="text-xs text-muted mt-1">{g.taken_at}</div>
                {g.label && <div className="text-xs">{g.label}</div>}
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-muted">لا يوجد صور أو أشعة مرفوعة لهذا المريض بعد.</p>
        )}

        <AddImageGroupForm patientId={patientId} />
      </section>

      {/* Visits history table */}
      <section className="bg-surface border border-border rounded-xl p-5 space-y-4">
        <h2 className="font-semibold">سجل الكشوفات والزيارات</h2>

        <AddVisitForm
          patientId={patientId}
          services={services}
          doctors={doctors}
          serviceDoctorMap={serviceDoctorMap}
        />

        <div className="overflow-x-auto">
          <table className="w-full text-sm mt-2">
            <thead className="bg-primary-soft text-primary-dark">
              <tr>
                <th className="text-right px-3 py-2 font-medium">التاريخ</th>
                <th className="text-right px-3 py-2 font-medium">نوع الخدمة</th>
                <th className="text-right px-3 py-2 font-medium">المعالجة</th>
                <th className="text-right px-3 py-2 font-medium">الدكتور</th>
              </tr>
            </thead>
            <tbody>
              {visits.map((v) => (
                <tr key={v.id} className="border-t border-border">
                  <td className="px-3 py-2 text-muted whitespace-nowrap">{v.visit_date}</td>
                  <td className="px-3 py-2">{v.service_name ?? "-"}</td>
                  <td className="px-3 py-2">{v.notes ?? "-"}</td>
                  <td className="px-3 py-2 whitespace-nowrap">{v.doctor_name ?? "-"}</td>
                </tr>
              ))}
              {visits.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-3 py-6 text-center text-muted">
                    لا يوجد زيارات مسجلة بعد.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
