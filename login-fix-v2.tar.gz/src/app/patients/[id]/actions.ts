"use server";

import { revalidatePath } from "next/cache";
import path from "node:path";
import fs from "node:fs/promises";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";

export async function addVisitAction(formData: FormData) {
  const patientId = Number(formData.get("patient_id"));
  const visit_date = String(formData.get("visit_date") || "").trim();
  const service_id = formData.get("service_id") ? Number(formData.get("service_id")) : null;
  const notes = String(formData.get("notes") || "").trim() || null;
  const primary_doctor_id = formData.get("doctor_id") ? Number(formData.get("doctor_id")) : null;
  const session = await getSession();

  if (!patientId || !visit_date) return;

  const visitResult = await db
    .insertInto("visits")
    .values({
      patient_id: patientId,
      visit_date,
      service_id,
      notes,
      primary_doctor_id,
      performing_doctor_id: primary_doctor_id,
      room_id: null,
      created_by: session?.userId ?? null,
    })
    .executeTakeFirst();

  // Every visit gets an invoice automatically, pre-filled with the service's
  // default price when a service was chosen (staff can adjust the amount later).
  if (visitResult.insertId) {
    let amount = 0;
    if (service_id) {
      const service = await db
        .selectFrom("services")
        .select("default_price")
        .where("id", "=", service_id)
        .executeTakeFirst();
      amount = service?.default_price ?? 0;
    }
    await db
      .insertInto("invoices")
      .values({ visit_id: Number(visitResult.insertId), amount, paid: 0 })
      .execute();
  }

  revalidatePath(`/patients/${patientId}`);
  revalidatePath("/invoices");
}

const UPLOAD_ROOT = path.join(process.cwd(), "public", "uploads", "patients");

export async function addImageGroupAction(formData: FormData) {
  const patientId = Number(formData.get("patient_id"));
  const taken_at = String(formData.get("taken_at") || "").trim();
  const label = String(formData.get("label") || "").trim() || null;
  const files = formData.getAll("files") as File[];

  if (!patientId || !taken_at) return;

  const group = await db
    .insertInto("patient_image_groups")
    .values({ patient_id: patientId, taken_at, label })
    .executeTakeFirst();

  const groupId = Number(group.insertId);
  const dir = path.join(UPLOAD_ROOT, String(patientId));
  await fs.mkdir(dir, { recursive: true });

  for (const file of files) {
    if (!file || typeof file === "string" || !file.size) continue;
    const safeName = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
    const buffer = Buffer.from(await file.arrayBuffer());
    await fs.writeFile(path.join(dir, safeName), buffer);
    const publicPath = `/uploads/patients/${patientId}/${safeName}`;
    await db.insertInto("patient_images").values({ group_id: groupId, file_path: publicPath }).execute();
  }

  revalidatePath(`/patients/${patientId}`);
}
