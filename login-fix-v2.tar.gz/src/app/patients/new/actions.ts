"use server";

import { redirect } from "next/navigation";
import { db } from "@/lib/db/client";

async function nextFileNumber() {
  const last = await db
    .selectFrom("patients")
    .select("file_number")
    .orderBy("id", "desc")
    .limit(1)
    .executeTakeFirst();
  const lastNum = last ? parseInt(last.file_number.replace(/\D/g, ""), 10) || 0 : 0;
  return `P-${String(lastNum + 1).padStart(4, "0")}`;
}

export async function createPatientAction(formData: FormData) {
  const full_name = String(formData.get("full_name") || "").trim();
  const age = formData.get("age") ? Number(formData.get("age")) : null;
  const phone = String(formData.get("phone") || "").trim() || null;
  const address = String(formData.get("address") || "").trim() || null;

  if (!full_name) redirect("/patients/new?error=1");

  const file_number = await nextFileNumber();

  const result = await db
    .insertInto("patients")
    .values({ file_number, full_name, age, phone, address })
    .executeTakeFirst();

  redirect(`/patients/${result.insertId}`);
}
