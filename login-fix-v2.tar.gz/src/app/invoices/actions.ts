"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";

export async function updatePaymentAction(formData: FormData) {
  const id = Number(formData.get("id"));
  const paid = Number(formData.get("paid"));
  if (!id || Number.isNaN(paid)) return;

  await db.updateTable("invoices").set({ paid }).where("id", "=", id).execute();
  revalidatePath("/invoices");
}
