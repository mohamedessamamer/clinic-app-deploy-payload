import { db } from "@/lib/db/client";
import FrontDeskClient from "@/components/FrontDeskClient";

export default async function FrontDeskPage({
  searchParams,
}: {
  searchParams: Promise<{ date?: string; room?: string }>;
}) {
  const { date, room } = await searchParams;
  const day = date && /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : new Date().toISOString().slice(0, 10);

  const rooms = await db.selectFrom("rooms").selectAll().execute();
  const roomId = room ? Number(room) : rooms[0]?.id ?? null;

  const [patients, services, doctors, shiftForRoom, rowsRaw] = await Promise.all([
    db.selectFrom("patients").select(["id", "full_name", "file_number"]).orderBy("id", "desc").limit(300).execute(),
    db.selectFrom("services").select(["id", "name", "default_price"]).execute(),
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).execute(),
    roomId
      ? db
          .selectFrom("shifts")
          .select(["doctor_id"])
          .where("room_id", "=", roomId)
          .where("shift_date", "=", day)
          .orderBy("start_time")
          .limit(1)
          .executeTakeFirst()
      : Promise.resolve(undefined),
    db
      .selectFrom("visits")
      .innerJoin("patients", "patients.id", "visits.patient_id")
      .innerJoin("invoices", "invoices.visit_id", "visits.id")
      .leftJoin("services", "services.id", "visits.service_id")
      .leftJoin("doctors", "doctors.id", "visits.primary_doctor_id")
      .select([
        "invoices.id",
        "visits.id as visit_id",
        "patients.id as patient_id",
        "patients.full_name as patient_name",
        "visits.visit_date",
        "services.name as service_name",
        "invoices.discount_percent",
        "invoices.amount",
        "invoices.price_overridden",
        "doctors.full_name as doctor_name",
      ])
      .where("visits.visit_date", "=", day)
      .$if(!!roomId, (qb) => qb.where("visits.room_id", "=", roomId!))
      .orderBy("invoices.id", "desc")
      .execute(),
  ]);

  const defaultDoctorId = shiftForRoom?.doctor_id ?? null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h1 className="text-xl font-bold">سجل اليوم — الاستقبال</h1>
        <form className="flex items-center gap-2 flex-wrap">
          <label className="text-sm text-muted">الغرفة:</label>
          <select name="room" defaultValue={roomId ?? ""} className="rounded-md border border-border bg-surface px-2 py-1.5 text-sm">
            {rooms.map((r) => (
              <option key={r.id} value={r.id}>
                {r.name}
              </option>
            ))}
          </select>
          <label className="text-sm text-muted">اليوم:</label>
          <input type="date" name="date" defaultValue={day} className="rounded-md border border-border bg-surface px-2 py-1.5 text-sm" />
          <button type="submit" className="px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft">
            عرض
          </button>
        </form>
      </div>

      {!defaultDoctorId && (
        <div className="text-sm bg-danger-soft text-danger rounded-md px-3 py-2">
          مفيش شيفت مسجل للغرفة دي النهاردة — حدد صاحب الشيفت الأول من صفحة{" "}
          <a href={`/settings?date=${day}`} className="underline">
            الإعدادات
          </a>
          .
        </div>
      )}

      <FrontDeskClient
        date={day}
        roomId={roomId}
        patients={patients}
        services={services}
        doctors={doctors}
        defaultDoctorId={defaultDoctorId}
        rows={rowsRaw}
      />
    </div>
  );
}
