import { db } from "@/lib/db/client";
import { addItemAction, updateQuantityAction } from "./actions";

export default async function InventoryPage() {
  const items = await db.selectFrom("inventory_items").selectAll().orderBy("name").execute();
  const today = new Date().toISOString().slice(0, 10);
  const soon = new Date();
  soon.setDate(soon.getDate() + 30);
  const soonStr = soon.toISOString().slice(0, 10);

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold">المخزون والأدوية</h1>

      <section className="bg-surface border border-border rounded-xl p-5 space-y-4">
        <h2 className="font-semibold">إضافة صنف</h2>
        <form action={addItemAction} className="grid grid-cols-1 sm:grid-cols-5 gap-2 items-end">
          <div className="sm:col-span-2">
            <label className="block text-xs text-muted mb-1">الاسم</label>
            <input name="name" required className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">الكمية</label>
            <input name="quantity" type="number" step="0.01" defaultValue={0} className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">الوحدة</label>
            <input name="unit" placeholder="علبة، أنبوبة..." className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">تاريخ الصلاحية</label>
            <input name="expiry_date" type="date" className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">حد التنبيه</label>
            <input name="low_stock_threshold" type="number" step="0.01" defaultValue={0} className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
          </div>
          <button type="submit" className="rounded-md bg-primary text-white px-3 py-1.5 text-sm font-medium hover:bg-primary-dark">
            + إضافة
          </button>
        </form>
      </section>

      <div className="bg-surface border border-border rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-primary-soft text-primary-dark">
            <tr>
              <th className="text-right px-3 py-2 font-medium">الصنف</th>
              <th className="text-right px-3 py-2 font-medium">الكمية</th>
              <th className="text-right px-3 py-2 font-medium">الصلاحية</th>
              <th className="px-3 py-2"></th>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => {
              const low = item.quantity <= item.low_stock_threshold;
              const expiringSoon = item.expiry_date && item.expiry_date <= soonStr && item.expiry_date >= today;
              const expired = item.expiry_date && item.expiry_date < today;
              return (
                <tr key={item.id} className="border-t border-border">
                  <td className="px-3 py-2 font-medium">{item.name}</td>
                  <td className="px-3 py-2">
                    <span className={low ? "text-danger font-semibold" : ""}>
                      {item.quantity} {item.unit ?? ""}
                    </span>
                    {low && <span className="ms-2 text-xs bg-danger-soft text-danger rounded-full px-2 py-0.5">قرب النفاد</span>}
                  </td>
                  <td className="px-3 py-2">
                    <span className={expired ? "text-danger font-semibold" : expiringSoon ? "text-danger" : ""}>
                      {item.expiry_date ?? "-"}
                    </span>
                    {expired && <span className="ms-2 text-xs bg-danger-soft text-danger rounded-full px-2 py-0.5">منتهي</span>}
                    {!expired && expiringSoon && <span className="ms-2 text-xs bg-danger-soft text-danger rounded-full px-2 py-0.5">قريب الانتهاء</span>}
                  </td>
                  <td className="px-3 py-2">
                    <form action={updateQuantityAction} className="flex items-center gap-1">
                      <input type="hidden" name="id" value={item.id} />
                      <input type="number" name="quantity" defaultValue={item.quantity} step="0.01" className="w-20 rounded-md border border-border bg-background px-2 py-1 text-xs" />
                      <button type="submit" className="text-xs px-2 py-1 rounded-md border border-border hover:bg-primary-soft">
                        تحديث
                      </button>
                    </form>
                  </td>
                </tr>
              );
            })}
            {items.length === 0 && (
              <tr>
                <td colSpan={4} className="px-3 py-6 text-center text-muted">
                  لا يوجد أصناف مسجلة بعد.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
