"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { logAdminEvent } from "@/lib/audit";
import { redirect } from "next/navigation";

// نفس فكرة /hr: الأكشنات دي بتتنادى من <form action={...}> فمبتقدرش ترجّع قيمة
// للواجهة. بنحوّل لصفحة المصروفات ومعاها كود الخطأ والصفحة بتعرض السبب، بدل ما
// المستخدم يدوس "حفظ" ومايحصلش أي حاجة ولا يعرف ليه.
function expenseError(code: string): never {
  redirect(`/expenses?err=${code}`);
}
import { isExpenseCategory, monthBounds } from "@/lib/expenses";
import { getClinicToday } from "@/lib/clinic-date";

function text(formData: FormData, key: string) {
  return String(formData.get(key) ?? "").trim();
}

function positiveAmount(formData: FormData, key: string) {
  const value = Number(formData.get(key));
  return Number.isFinite(value) && value > 0 ? Math.round(value * 100) / 100 : null;
}

function validDate(value: string) {
  return /^\d{4}-\d{2}-\d{2}$/.test(value);
}

async function canManageExpenses() {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "manage_expenses"))) return null;
  return session;
}

function refreshExpenses() {
  revalidatePath("/expenses");
  revalidatePath("/reports");
}

// دفعة 134 — بحث المريض في فورم مصروف المعمل اليدوي.
//
// الخانة كانت <select> عادي، فكان لازم كل المرضى يتحمّلوا في الصفحة عشان
// المتصفح يرسمهم كلهم كخيارات — ده معناه إن أسماء كل مرضى العيادة كانت
// بتتبعت مع كل فتحة لشاشة المصروفات حتى لو الفورم ده ماتفتحش أصلاً، والحجم
// بيكبر مع كل مريض جديد ومابيصغرش أبدًا. وكمان البحث في <select> بيبقى
// بالحرف الأول بس (سلوك المتصفح الافتراضي) مش بأي جزء من الاسم زي باقي
// السيستم.
//
// بنفس طريقة بحث الحجز في الجدول المركزي: مفيش تحميل مسبق خالص، والسيرفر
// بيرجّع 8 نتايج بس مع كل كتابة. الفرق الوحيد إن الصلاحية هنا manage_expenses
// مش schedule_edit — اللي بيدخل المصروفات مش شرط يبقى معاه صلاحية المواعيد.
export type ExpensePatientSearchResult = { id: number; full_name: string; file_number: string; phone: string | null };

export async function searchPatientsForExpenseAction(query: string): Promise<ExpensePatientSearchResult[]> {
  const session = await canManageExpenses();
  if (!session) return [];
  const term = query.trim();
  if (term.length < 2) return [];
  const like = `%${term}%`;
  return db
    .selectFrom("patients")
    .select(["id", "full_name", "file_number", "phone"])
    .where((eb) => eb.or([eb("full_name", "like", like), eb("file_number", "like", like), eb("phone", "like", like)]))
    .orderBy("full_name")
    .limit(8)
    .execute();
}

/**
 * الطبيب اللي عمل الخدمة دي للمريض ده فعلاً، من آخر فاتورة مطابقة.
 *
 * مصروف المعمل بيتخصم من تحصيل الطبيب المحدد في الفورم قبل حساب نسبته. قبل
 * كده الطبيب كان بيتساب للاختيار اليدوي من غير أي ربط بالفاتورة — فاختيار
 * غلط كان بيخصم تكلفة المعمل من نسبة طبيب تاني بالكامل، في صمت. دلوقتي
 * الطبيب بيتملى من الفاتورة، ولو المستخدم غيّره بيظهر تحذير (مش منع: ساعات
 * المعمل بيتحمّل على حد تاني عن قصد).
 */
export async function findLabInvoiceDoctorAction(patientId: number, serviceId: number): Promise<{ doctorId: number; doctorName: string } | null> {
  const session = await canManageExpenses();
  if (!session) return null;
  if (!(patientId > 0) || !(serviceId > 0)) return null;
  const row = await db
    .selectFrom("invoices")
    .innerJoin("doctors", "doctors.id", "invoices.doctor_id")
    .select(["doctors.id as doctor_id", "doctors.full_name as doctor_name"])
    .where("invoices.patient_id", "=", patientId)
    .where("invoices.service_id", "=", serviceId)
    .where("invoices.doctor_id", "is not", null)
    .orderBy("invoices.invoice_date", "desc")
    .orderBy("invoices.id", "desc")
    .executeTakeFirst();
  return row ? { doctorId: row.doctor_id, doctorName: row.doctor_name } : null;
}

export async function addExpenseAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const category = text(formData, "category");
  const title = text(formData, "title");
  const amount = positiveAmount(formData, "amount");
  const expenseDate = text(formData, "expense_date");
  if (!isExpenseCategory(category) || category === "salary") expenseError("category");
  if (!title) expenseError("title");
  if (!amount) expenseError("amount");
  if (!validDate(expenseDate)) expenseError("date");
  const doctorIdValue = Number(formData.get("doctor_id"));
  const patientIdValue = Number(formData.get("patient_id"));
  const serviceIdValue = Number(formData.get("service_id"));
  const isLab = category === "lab";
  if (isLab && serviceIdValue > 0) {
    const service = await db
      .selectFrom("services")
      .select(["has_lab_cost", "lab_cost"])
      .where("id", "=", serviceIdValue)
      .executeTakeFirst();
    // يمنع خصم نفس تكلفة المعمل مرتين: تلقائيًا من الخدمة ويدويًا من المصروفات.
    if (!service) expenseError("service");
    if (service.has_lab_cost === 1 && service.lab_cost > 0) expenseError("labdouble");
  }
  await db
    .insertInto("expenses")
    .values({
      expense_date: expenseDate,
      category,
      title,
      payee: text(formData, "payee") || null,
      amount,
      payment_method: text(formData, "payment_method") || null,
      note: text(formData, "note") || null,
      source_type: "manual",
      source_id: null,
      template_id: null,
      doctor_id: isLab && doctorIdValue > 0 ? doctorIdValue : null,
      patient_id: isLab && patientIdValue > 0 ? patientIdValue : null,
      service_id: isLab && serviceIdValue > 0 ? serviceIdValue : null,
      affects_commission: isLab && doctorIdValue > 0 ? 1 : 0,
      created_by: session.userId,
    })
    .execute();
  refreshExpenses();
}

export async function addExpenseTemplateAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const category = text(formData, "category");
  const title = text(formData, "title");
  const amount = positiveAmount(formData, "default_amount");
  if (!isExpenseCategory(category) || category === "salary") expenseError("category");
  if (!title) expenseError("title");
  if (!amount) expenseError("amount");
  await db
    .insertInto("expense_templates")
    .values({
      title,
      category,
      payee: text(formData, "payee") || null,
      default_amount: amount,
      note: text(formData, "note") || null,
      effective_from: validDate(text(formData, "effective_from")) ? text(formData, "effective_from") : getClinicToday(),
      effective_to: validDate(text(formData, "effective_to")) ? text(formData, "effective_to") : null,
      created_by: session.userId,
    })
    .execute();
  refreshExpenses();
}

export async function updateExpenseTemplateAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const id = Number(formData.get("template_id"));
  const category = text(formData, "category");
  const title = text(formData, "title");
  const defaultAmount = positiveAmount(formData, "default_amount");
  const effectiveFrom = text(formData, "effective_from");
  const effectiveTo = text(formData, "effective_to") || null;
  if (!Number.isInteger(id) || id <= 0) expenseError("template");
  if (!isExpenseCategory(category) || category === "salary") expenseError("category");
  if (!title) expenseError("title");
  if (!defaultAmount) expenseError("amount");
  if (!validDate(effectiveFrom)) expenseError("date");
  if (effectiveTo && (!validDate(effectiveTo) || effectiveTo < effectiveFrom)) expenseError("daterange");
  await db.updateTable("expense_templates").set({ title, category, payee: text(formData, "payee") || null, default_amount: defaultAmount, note: text(formData, "note") || null, effective_from: effectiveFrom, effective_to: effectiveTo, active: 1 }).where("id", "=", id).execute();
  refreshExpenses();
}

export async function stopExpenseTemplateAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const id = Number(formData.get("template_id"));
  if (!Number.isInteger(id) || id <= 0) expenseError("template");
  await db.updateTable("expense_templates").set({ active: 0, effective_to: getClinicToday() }).where("id", "=", id).execute();
  refreshExpenses();
}

export async function deleteExpenseTemplateAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const id = Number(formData.get("template_id"));
  if (!Number.isInteger(id) || id <= 0) expenseError("template");
  const used = await db.selectFrom("expenses").select("id").where("template_id", "=", id).executeTakeFirst();
  if (used) await db.updateTable("expense_templates").set({ active: 0, effective_to: getClinicToday() }).where("id", "=", id).execute();
  else await db.deleteFrom("expense_templates").where("id", "=", id).execute();
  refreshExpenses();
}

export async function recordExpenseTemplateAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const templateId = Number(formData.get("template_id"));
  const expenseDate = text(formData, "expense_date");
  if (!Number.isInteger(templateId) || templateId <= 0) expenseError("template");
  if (!validDate(expenseDate)) expenseError("date");
  const [template, range] = await Promise.all([
    db.selectFrom("expense_templates").selectAll().where("id", "=", templateId).where("active", "=", 1).executeTakeFirst(),
    Promise.resolve(monthBounds(expenseDate.slice(0, 7))),
  ]);
  if (!template || !range) expenseError("template");
  const existing = await db
    .selectFrom("expenses")
    .select("id")
    .where("template_id", "=", template.id)
    .where("expense_date", ">=", range.from)
    .where("expense_date", "<=", range.to)
    .executeTakeFirst();
  if (existing) expenseError("already");
  await db
    .insertInto("expenses")
    .values({
      expense_date: expenseDate,
      category: template.category,
      title: template.title,
      payee: template.payee,
      amount: template.default_amount,
      payment_method: text(formData, "payment_method") || "cash",
      note: template.note,
      source_type: "template",
      source_id: null,
      template_id: template.id,
      doctor_id: null,
      patient_id: null,
      service_id: null,
      affects_commission: 0,
      created_by: session.userId,
    })
    .execute();
  refreshExpenses();
}

// دفعة 132: createOrRefreshHrPayrollRunAction و payHrPayrollRunAction و
// payAllHrPayrollRunsAction اتشالوا. الأول كان بيخزن snapshot للفلوس (سبب فرق
// الـ5,160)، والتانيين كانوا بيصرفوا كشف كل شخص على حدة — والصرف بقى على
// مستوى الشهر كله من hr_period_settlements. الكشوف المصروفة قديمًا وسجلات
// المصروفات بتاعتها زي ما هي، ومفيش أي حاجة اتلمست في البيانات.

// ---------------------------------------------------------------------------
// دفعة 132 — مدخلات الكشف وسداد الفترة.
//
// `createOrRefreshHrPayrollRunAction` القديم كان بيخزن snapshot كامل للفلوس
// (`total_amount`) وقت الضغط على «حفظ». ده بالظبط سبب فرق الـ5,160: الصف كان
// بيعيد الحساب لحظيًا من التحصيل الحالي، والمجموع بيقرا الـsnapshot القديم.
// دلوقتي بنخزن المدخلات بس؛ الفلوس بتتحسب من الأول في كل عرض فمستحيل تتعتّق.
// ---------------------------------------------------------------------------
export async function saveHrPayrollInputsAction(formData: FormData): Promise<{ ok: boolean; error?: string }> {
  // بترجّع نتيجة بدل ما تعمل redirect زي باقي أكشنات الشاشة: دي بتتنادى من
  // جافاسكربت كحفظ تلقائي في الخلفية وقت الكتابة، مش من <form action>. redirect
  // وسط الكتابة كان هيرمي المحاسب بره الصفحة. وخروج صامت كان أسوأ — كان هيكتب
  // رقم ويفتكره اتحفظ وهو مااتحفظش (نفس نوع الباج اللي دفعة 103 قفلته).
  const session = await canManageExpenses();
  if (!session) return { ok: false, error: "مفيش صلاحية لإدارة المصروفات." };
  const personType = text(formData, "person_type");
  const personId = Number(formData.get("person_id"));
  const from = text(formData, "period_from");
  const to = text(formData, "period_to");
  if (personType !== "doctor" && personType !== "staff") return { ok: false, error: "نوع الشخص غير صحيح." };
  if (!Number.isInteger(personId) || personId <= 0) return { ok: false, error: "الشخص غير صحيح." };
  if (!validDate(from) || !validDate(to) || to < from) return { ok: false, error: "فترة الكشف غير صحيحة." };

  // خانة فاضية = ارجع للعدد المحسوب من أيام الشيفت (NULL)، مش صفر. الفرق مهم:
  // NULL بتخلي الرقم يتحدّث لوحده كل شهر، وصفر تعديل يدوي معناه «مجاش خالص».
  const overrideRaw = text(formData, "shift_count_override");
  const parsedOverride = overrideRaw === "" ? null : Number(overrideRaw);
  const shiftCountOverride = parsedOverride == null || !Number.isFinite(parsedOverride) || parsedOverride < 0 ? null : Math.round(parsedOverride * 100) / 100;
  const incentives = Math.max(0, Number(formData.get("incentives")) || 0);
  const deductions = Math.max(0, Number(formData.get("deductions")) || 0);

  const rule = await db
    .selectFrom("hr_compensation_rules")
    .selectAll()
    .where("person_type", "=", personType)
    .where("person_id", "=", personId)
    .executeTakeFirst();
  if (!rule) return { ok: false, error: "مفيش قاعدة راتب معرّفة للشخص ده — عرّفها من شاشة HR أول." };
  const person = personType === "doctor"
    ? await db.selectFrom("doctors").select(["full_name"]).where("id", "=", personId).executeTakeFirst()
    : await db.selectFrom("hr_staff").select(["full_name"]).where("id", "=", personId).executeTakeFirst();
  if (!person) return { ok: false, error: "الشخص مش موجود أو اتوقف." };

  const existing = await db
    .selectFrom("hr_payroll_runs")
    .select(["id", "status"])
    .where("person_type", "=", personType)
    .where("person_id", "=", personId)
    .where("period_from", "=", from)
    .where("period_to", "=", to)
    .executeTakeFirst();

  if (existing) {
    await db
      .updateTable("hr_payroll_runs")
      .set({ shift_count_override: shiftCountOverride, incentives, deductions })
      .where("id", "=", existing.id)
      .execute();
  } else {
    await db
      .insertInto("hr_payroll_runs")
      .values({
        person_type: personType,
        person_id: personId,
        person_name: person.full_name,
        staff_group: rule.staff_group,
        period_from: from,
        period_to: to,
        shift_count: 0,
        shift_count_override: shiftCountOverride,
        fixed_amount: 0,
        percentage_basis: rule.percentage_basis,
        percentage_mode: rule.percentage_mode,
        percentage: rule.percentage,
        incentives,
        deductions,
        status: "draft",
        paid_date: null,
        expense_id: null,
        paid_by: null,
        created_by: session.userId,
      })
      .execute();
  }
  refreshExpenses();
  return { ok: true };
}


/**
 * سداد دفعة من رواتب/نسب فترة. الدفعة الواحدة ممكن تغطي الوعاءين مع بعض.
 *
 * التاريخان مقصودين ومختلفين:
 *  • `paid_date` = تاريخ السداد الفعلي (مثلاً 7 أكتوبر لنسب سبتمبر) — للتوثيق.
 *  • `expense_date` = آخر يوم في الشهر المستحق — القيد المحاسبي، عشان تقرير
 *    الشهر يطلع مكتمل ومصروفات الشهر اللي بعده ماتتلخبطش.
 *
 * سداد النسب بيتعلّم `excluded_from_commission_base` لأن وعاء «صافي النقدية»
 * بيتحسب بعد خصم المصروفات: لو النسبة دخلت المصروفات كانت هتقلل الوعاء اللي هي
 * نفسها متحسبة منه (معادلة دائرية). الرواتب الثابتة مافيهاش المشكلة دي لأنها
 * مبلغ ثابت مش بيعتمد على الوعاء، فبتتخصم عادي.
 */
export async function recordHrSettlementAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const from = text(formData, "period_from");
  const to = text(formData, "period_to");
  const paidDate = text(formData, "paid_date") || getClinicToday();
  const paymentMethod = text(formData, "payment_method") || "cash";
  if (!validDate(from) || !validDate(to)) expenseError("date");
  if (to < from) expenseError("daterange");
  if (!validDate(paidDate)) expenseError("date");

  const salaryAmount = positiveAmount(formData, "salary_amount");
  const commissionAmount = positiveAmount(formData, "commission_amount");
  if (salaryAmount == null && commissionAmount == null) expenseError("settlementamount");

  const entries = [
    { kind: "salary" as const, amount: salaryAmount, title: "سداد رواتب", excluded: 0 },
    { kind: "commission" as const, amount: commissionAmount, title: "سداد نسب", excluded: 1 },
  ].filter((entry) => entry.amount != null);

  await db.transaction().execute(async (trx) => {
    for (const entry of entries) {
      const settlement = await trx
        .insertInto("hr_period_settlements")
        .values({ kind: entry.kind, period_from: from, period_to: to, amount: entry.amount!, paid_date: paidDate, payment_method: paymentMethod, expense_id: null, created_by: session.userId })
        .executeTakeFirstOrThrow();
      const settlementId = Number(settlement.insertId);
      const inserted = await trx
        .insertInto("expenses")
        .values({
          expense_date: to,
          category: "salary",
          title: `${entry.title} — ${from} إلى ${to}`,
          payee: null,
          amount: entry.amount!,
          payment_method: paymentMethod,
          note: paidDate === to ? "سداد من كشف HR" : `سداد من كشف HR — تاريخ السداد الفعلي ${paidDate}`,
          source_type: "hr_settlement",
          source_id: settlementId,
          template_id: null,
          doctor_id: null,
          patient_id: null,
          service_id: null,
          affects_commission: 0,
          excluded_from_commission_base: entry.excluded,
          created_by: session.userId,
        })
        .executeTakeFirstOrThrow();
      await trx.updateTable("hr_period_settlements").set({ expense_id: Number(inserted.insertId) }).where("id", "=", settlementId).execute();
    }
  });
  refreshExpenses();
}

export async function deleteExpenseAction(formData: FormData): Promise<{ ok: boolean; reason?: string }> {
  const session = await canManageExpenses();
  if (!session) return { ok: false, reason: "مفيش صلاحية لإدارة المصروفات." };
  const id = Number(formData.get("expense_id"));
  if (!Number.isInteger(id) || id <= 0) return { ok: false, reason: "بيان المصروف غير صالح." };
  const expense = await db.selectFrom("expenses").select(["id", "source_type", "category", "amount", "expense_date"]).where("id", "=", id).executeTakeFirst();
  if (!expense) return { ok: false, reason: "المصروف غير موجود." };
  if (expense.source_type === "inventory_supply") {
    return { ok: false, reason: "هذا المصروف جاء من توريد مخزن؛ صحّح التوريد من المخزن حتى يظل الجرد والتقارير متطابقين." };
  }
  if (expense.source_type === "doctor_payroll") {
    return { ok: false, reason: "هذا المصروف جاء من كشف راتب طبيب؛ صحّح كشف الراتب حتى يظل الاستحقاق والمصروف متطابقين." };
  }
  if (expense.source_type === "hr_payroll") {
    return { ok: false, reason: "هذا المصروف جاء من كشف HR؛ صحّح كشف الراتب حتى يظل الاستحقاق والمصروف متطابقين." };
  }
  if (expense.source_type === "supplier_payment") {
    return { ok: false, reason: "هذا المصروف جاء من دفعة مورد؛ صحّح أو احذف الدفعة من قسم خامات بشاشة المصروفات حتى تظل المديونية والمصروف متطابقين." };
  }
  await db.deleteFrom("expenses").where("id", "=", id).execute();
  await logAdminEvent({
    entityType: "expense", entityId: id, event: "delete_expense",
    details: `حذف مصروف: ${expense.category} بمبلغ ${expense.amount} بتاريخ ${expense.expense_date}`,
    changedBy: session.userId,
  });
  refreshExpenses();
  return { ok: true };
}

function positiveId(formData: FormData, key: string) {
  const value = Number(formData.get(key));
  return Number.isInteger(value) && value > 0 ? value : null;
}

function refreshSuppliers() {
  revalidatePath("/expenses");
  revalidatePath("/reports");
}

async function canManageSuppliers() {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "manage_suppliers"))) return null;
  return session;
}

function normalizeSpecialty(value: string): "ortho" | "general" | null {
  return value === "ortho" || value === "general" ? value : null;
}

// المورد يتعرّف من المخزن — هنا فقط فواتيره ودفعاته. أي فاتورة لازم تتبع مورد
// موجود بالفعل في inventory_suppliers. لو المورد شغال في التخصصين مع بعض
// لازم تحدد تخصص الفاتورة نفسها؛ غير كده specialty بتتخزن NULL (تُشتق من علم
// المورد وقت العرض). "المدفوع" وقت الإنشاء (لو موجود) بيتسجل كدفعة أولى على
// نفس الفاتورة داخل نفس الترانزاكشن — مفيش مفهوم "دفعة عامة" منفصل.
export async function addSupplierInvoiceAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const supplierId = positiveId(formData, "supplier_id");
  const amount = positiveAmount(formData, "amount");
  const invoiceNumber = text(formData, "invoice_number") || null;
  const invoiceDate = text(formData, "invoice_date") || getClinicToday();
  const paidAmount = positiveAmount(formData, "paid_amount");
  if (!supplierId) expenseError("supplier");
  if (!amount) expenseError("amount");
  if (!validDate(invoiceDate)) expenseError("date");
  if (paidAmount && paidAmount > amount) expenseError("amount");
  const supplier = await db.selectFrom("inventory_suppliers").select(["id", "name", "is_ortho", "is_general"]).where("id", "=", supplierId).executeTakeFirst();
  if (!supplier) expenseError("supplier");
  const bothSpecialties = supplier.is_ortho === 1 && supplier.is_general === 1;
  const specialty = bothSpecialties ? normalizeSpecialty(text(formData, "specialty")) : null;
  if (bothSpecialties && !specialty) expenseError("specialty");
  // ملحوظة مهمة: logAdminEvent بيستخدم اتصال db العام، مش trx. نداءه من جوه
  // كولباك db.transaction().execute() بيعلّق السيرفر بالكامل (قفل ذاتي على
  // نفس الاتصال - الترانزاكشن الخارجية مستنية الكولباك يخلص، والكولباك
  // مستنى يمسك نفس الاتصال تاني من جوه logAdminEvent) - لأي طلب تاني يستخدم
  // قاعدة البيانات، لحد ما تعمل إعادة تشغيل يدوية للخدمة. الحل: نجمع بيانات
  // اللوج من جوه الترانزاكشن، ونستدعي logAdminEvent بعد ما الترانزاكشن تخلص
  // وتتقفل تمامًا.
  const { invoiceId, paymentId, expenseId } = await db.transaction().execute(async (trx) => {
    const inserted = await trx
      .insertInto("supplier_invoices")
      .values({
        supplier_id: supplierId,
        invoice_number: invoiceNumber,
        amount,
        invoice_date: invoiceDate,
        created_by: session.userId,
        specialty,
      })
      .executeTakeFirstOrThrow();
    const invoiceId = Number(inserted.insertId);
    let paymentId: number | null = null;
    let expenseId: number | null = null;
    if (paidAmount) {
      const payment = await trx
        .insertInto("supplier_payments")
        .values({ supplier_id: supplierId, invoice_id: invoiceId, amount: paidAmount, payment_date: invoiceDate, created_by: session.userId, notes: "دفعة عند إنشاء الفاتورة" })
        .executeTakeFirstOrThrow();
      const expense = await trx
        .insertInto("expenses")
        .values({
          expense_date: invoiceDate, category: "suppliers", title: `دفعة لمورد: ${supplier.name}`, payee: supplier.name,
          amount: paidAmount, payment_method: null, note: "دفعة عند إنشاء الفاتورة", source_type: "supplier_payment",
          source_id: Number(payment.insertId), template_id: null, doctor_id: null, patient_id: null, service_id: null,
          affects_commission: 0, created_by: session.userId,
        })
        .executeTakeFirstOrThrow();
      paymentId = Number(payment.insertId);
      expenseId = Number(expense.insertId);
    }
    return { invoiceId, paymentId, expenseId };
  });
  await logAdminEvent({
    entityType: "supplier_invoice",
    entityId: invoiceId,
    event: "supplier_invoice_created",
    details: `فاتورة مورد ${supplier.name} رقم ${invoiceNumber ?? "بدون رقم"} بمبلغ ${amount} بتاريخ ${invoiceDate}`,
    changedBy: session.userId,
  });
  if (paymentId) {
    await logAdminEvent({
      entityType: "supplier_payment", entityId: paymentId, event: "supplier_payment_recorded",
      details: `دفعة عند إنشاء فاتورة مورد رقم ${invoiceId} بمبلغ ${paidAmount} بتاريخ ${invoiceDate} (مصروف رقم ${expenseId})`,
      changedBy: session.userId,
    });
  }
  refreshSuppliers();
}

// دفعة مرتبطة بفاتورة مورد بعينها — لازم تظهر أيضًا كمصروف فعلي بند "موردين"
// حتى تدخل في إجمالي المصروفات والتقارير. تاريخ الدفعة هو تاريخ الإدخال اللي
// المستخدم كتبه في الصندوق (افتراضيًا اليوم، لكن ممكن يتغيّر لتسجيل بأثر رجعي).
export async function recordSupplierInvoicePaymentAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const supplierId = positiveId(formData, "supplier_id");
  const invoiceId = positiveId(formData, "invoice_id");
  const amount = positiveAmount(formData, "amount");
  const paymentDate = text(formData, "payment_date") || getClinicToday();
  if (!supplierId || !invoiceId) expenseError("supplier");
  if (!amount) expenseError("amount");
  if (!validDate(paymentDate)) expenseError("date");
  const invoice = await db.selectFrom("supplier_invoices").select("id").where("id", "=", invoiceId).where("supplier_id", "=", supplierId).executeTakeFirst();
  if (!invoice) expenseError("supplier");
  const notes = text(formData, "notes") || null;
  const supplier = await db.selectFrom("inventory_suppliers").select(["id", "name"]).where("id", "=", supplierId).executeTakeFirst();
  if (!supplier) expenseError("supplier");
  const { paymentId, expenseId } = await db.transaction().execute(async (trx) => {
    const inserted = await trx
      .insertInto("supplier_payments")
      .values({
        supplier_id: supplierId,
        invoice_id: invoiceId,
        amount,
        payment_date: paymentDate,
        created_by: session.userId,
        notes,
      })
      .executeTakeFirstOrThrow();
    const expense = await trx
      .insertInto("expenses")
      .values({
        expense_date: paymentDate,
        category: "suppliers",
        title: `دفعة لمورد: ${supplier.name}`,
        payee: supplier.name,
        amount,
        payment_method: null,
        note: notes,
        source_type: "supplier_payment",
        source_id: Number(inserted.insertId),
        template_id: null,
        doctor_id: null,
        patient_id: null,
        service_id: null,
        affects_commission: 0,
        created_by: session.userId,
      })
      .executeTakeFirstOrThrow();
    return { paymentId: Number(inserted.insertId), expenseId: Number(expense.insertId) };
  });
  // logAdminEvent بيتنادى بعد ما الترانزاكشن يقفل خالص - شوف الملحوظة في
  // addSupplierInvoiceAction فوق لسبب المشكلة اللي كانت بتعلّق السيرفر كله.
  await logAdminEvent({
    entityType: "supplier_payment",
    entityId: paymentId,
    event: "supplier_payment_recorded",
    details: `دفعة على فاتورة مورد رقم ${invoiceId} بمبلغ ${amount} بتاريخ ${paymentDate} (مصروف رقم ${expenseId})`,
    changedBy: session.userId,
  });
  refreshSuppliers();
}

// تعديل بيانات فاتورة مورد (رقمها/مبلغها/تخصصها/تاريخها) — بيحصل غلطة إدخال
// وعايزين نصححها، لكن بصلاحية أضيق من إضافة الفواتير العادية (manage_suppliers)
// حتى ما ينفعش أي حد يعدّل بيانات مالية بعد تسجيلها.
export async function editSupplierInvoiceAction(formData: FormData) {
  const session = await canManageSuppliers();
  if (!session) return;
  const invoiceId = positiveId(formData, "invoice_id");
  const amount = positiveAmount(formData, "amount");
  const invoiceNumber = text(formData, "invoice_number") || null;
  const invoiceDate = text(formData, "invoice_date");
  if (!invoiceId) expenseError("supplier");
  if (!amount) expenseError("amount");
  if (!validDate(invoiceDate)) expenseError("date");
  const invoice = await db.selectFrom("supplier_invoices").selectAll().where("id", "=", invoiceId).executeTakeFirst();
  if (!invoice) expenseError("supplier");
  const supplier = await db.selectFrom("inventory_suppliers").select(["id", "name", "is_ortho", "is_general"]).where("id", "=", invoice.supplier_id).executeTakeFirst();
  if (!supplier) expenseError("supplier");
  const bothSpecialties = supplier.is_ortho === 1 && supplier.is_general === 1;
  const specialty = bothSpecialties ? normalizeSpecialty(text(formData, "specialty")) : null;
  if (bothSpecialties && !specialty) expenseError("specialty");
  await db.updateTable("supplier_invoices").set({ amount, invoice_number: invoiceNumber, invoice_date: invoiceDate, specialty }).where("id", "=", invoiceId).execute();
  await logAdminEvent({
    entityType: "supplier_invoice", entityId: invoiceId, event: "supplier_invoice_edited",
    details: `تعديل فاتورة مورد ${supplier.name}: رقم ${invoiceNumber ?? "بدون رقم"}، مبلغ ${amount}، تاريخ ${invoiceDate} (كانت: ${invoice.amount} بتاريخ ${invoice.invoice_date})`,
    changedBy: session.userId,
  });
  refreshSuppliers();
}

// حذف فاتورة مورد بكل دفعاتها ومصروفاتها المرتبطة — ترانزاكشن واحد. بعكس
// deleteExpenseAction العام اللي بيرفض حذف مصروف مصدره supplier_payment، هنا
// دالة مخصصة تحذف الفاتورة والدفعات والمصروفات المرتبطة مع بعض بشكل متسق.
export async function deleteSupplierInvoiceAction(formData: FormData) {
  const session = await canManageSuppliers();
  if (!session) return;
  const invoiceId = positiveId(formData, "invoice_id");
  if (!invoiceId) expenseError("supplier");
  const { invoiceNumber, invoiceAmount, deletedPaymentsCount } = await db.transaction().execute(async (trx) => {
    const invoice = await trx.selectFrom("supplier_invoices").selectAll().where("id", "=", invoiceId).executeTakeFirst();
    if (!invoice) expenseError("supplier");
    const payments = await trx.selectFrom("supplier_payments").select("id").where("invoice_id", "=", invoiceId).execute();
    const paymentIds = payments.map((p) => p.id);
    if (paymentIds.length) {
      await trx.deleteFrom("expenses").where("source_type", "=", "supplier_payment").where("source_id", "in", paymentIds).execute();
      await trx.deleteFrom("supplier_payments").where("id", "in", paymentIds).execute();
    }
    await trx.deleteFrom("supplier_invoices").where("id", "=", invoiceId).execute();
    return { invoiceNumber: invoice.invoice_number, invoiceAmount: invoice.amount, deletedPaymentsCount: paymentIds.length };
  });
  // logAdminEvent بعد قفل الترانزاكشن - شوف الملحوظة في addSupplierInvoiceAction.
  await logAdminEvent({
    entityType: "supplier_invoice", entityId: invoiceId, event: "supplier_invoice_deleted",
    details: `حذف فاتورة مورد رقم ${invoiceNumber ?? "بدون رقم"} بمبلغ ${invoiceAmount} ومعها ${deletedPaymentsCount} دفعة`,
    changedBy: session.userId,
  });
  refreshSuppliers();
}

// تعديل دفعة موجودة — لازم يعدّل مصروفها المرتبط بنفس القيم حتى يفضل السجلين
// متطابقين (نفس منطق source_type/source_id بتاع الحذف).
export async function editSupplierPaymentAction(formData: FormData) {
  const session = await canManageSuppliers();
  if (!session) return;
  const paymentId = positiveId(formData, "payment_id");
  const amount = positiveAmount(formData, "amount");
  const paymentDate = text(formData, "payment_date");
  if (!paymentId) expenseError("supplier");
  if (!amount) expenseError("amount");
  if (!validDate(paymentDate)) expenseError("date");
  const { oldAmount, oldDate } = await db.transaction().execute(async (trx) => {
    const payment = await trx.selectFrom("supplier_payments").selectAll().where("id", "=", paymentId).executeTakeFirst();
    if (!payment) expenseError("supplier");
    await trx.updateTable("supplier_payments").set({ amount, payment_date: paymentDate }).where("id", "=", paymentId).execute();
    await trx.updateTable("expenses").set({ amount, expense_date: paymentDate }).where("source_type", "=", "supplier_payment").where("source_id", "=", paymentId).execute();
    return { oldAmount: payment.amount, oldDate: payment.payment_date };
  });
  // logAdminEvent بعد قفل الترانزاكشن - شوف الملحوظة في addSupplierInvoiceAction.
  await logAdminEvent({
    entityType: "supplier_payment", entityId: paymentId, event: "supplier_payment_edited",
    details: `تعديل دفعة مورد إلى ${amount} بتاريخ ${paymentDate} (كانت: ${oldAmount} بتاريخ ${oldDate})`,
    changedBy: session.userId,
  });
  refreshSuppliers();
}

// حذف دفعة موجودة ومصروفها المرتبط مع بعض — بديل مخصص لـdeleteExpenseAction
// العام اللي بيرفض حذف مصروف من نوع supplier_payment.
export async function deleteSupplierPaymentAction(formData: FormData) {
  const session = await canManageSuppliers();
  if (!session) return;
  const paymentId = positiveId(formData, "payment_id");
  if (!paymentId) expenseError("supplier");
  const { deletedAmount, deletedDate } = await db.transaction().execute(async (trx) => {
    const payment = await trx.selectFrom("supplier_payments").selectAll().where("id", "=", paymentId).executeTakeFirst();
    if (!payment) expenseError("supplier");
    await trx.deleteFrom("expenses").where("source_type", "=", "supplier_payment").where("source_id", "=", paymentId).execute();
    await trx.deleteFrom("supplier_payments").where("id", "=", paymentId).execute();
    return { deletedAmount: payment.amount, deletedDate: payment.payment_date };
  });
  // logAdminEvent بعد قفل الترانزاكشن - شوف الملحوظة في addSupplierInvoiceAction.
  await logAdminEvent({
    entityType: "supplier_payment", entityId: paymentId, event: "supplier_payment_deleted",
    details: `حذف دفعة مورد بمبلغ ${deletedAmount} بتاريخ ${deletedDate}`,
    changedBy: session.userId,
  });
  refreshSuppliers();
}

// مسح بيانات شاشة المصروفات (المصروفات وكشوف رواتب HR) لفترة محددة فقط —
// وليس كل تاريخ العيادة. صلاحية منفصلة عن manage_expenses لأنه إجراء غير قابل
// للتراجع؛ افتراضيًا للأدمن فقط، يُستخدم لتصفير بيانات تجريبية بفترة معينة.
// قواعد الرواتب في hr_compensation_rules والبنود المتكررة لا تُمسان هنا؛ لكل
// منهما زر حذف مستقل خاص به في نفس الشاشة.
export async function clearExpensesDataAction(formData: FormData): Promise<{ ok: boolean; reason?: string; deletedExpenses?: number; deletedPayrollRuns?: number }> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "clear_expenses_data"))) {
    return { ok: false, reason: "مفيش صلاحية عندك لمسح بيانات المصروفات." };
  }
  const from = text(formData, "from");
  const to = text(formData, "to");
  if (!validDate(from) || !validDate(to) || to < from) {
    return { ok: false, reason: "الفترة غير صحيحة." };
  }
  const { deletedExpenses, deletedPayrollRuns } = await db.transaction().execute(async (trx) => {
    const expenseRows = await trx.selectFrom("expenses").select("id").where("expense_date", ">=", from).where("expense_date", "<=", to).execute();
    const expenseIds = expenseRows.map((row) => row.id);
    // لازم نمسح أي hr_payroll_runs بتشاور على المصروفات دي أولاً (سواء كانت
    // فترة الكشف نفسها داخل from/to، أو كانت من فترة تانية بس اتصرفت فيها
    // بمصروف تاريخه داخل الفترة المختارة) حتى ما تنكسر قيود المفاتيح الأجنبية.
    const deletedRuns = await trx.deleteFrom("hr_payroll_runs").where((eb) => {
      const conditions = [eb.and([eb("period_from", ">=", from), eb("period_to", "<=", to)])];
      if (expenseIds.length) conditions.push(eb("expense_id", "in", expenseIds));
      return eb.or(conditions);
    }).executeTakeFirst();
    if (expenseIds.length) await trx.deleteFrom("expenses").where("id", "in", expenseIds).execute();
    return { deletedExpenses: expenseIds.length, deletedPayrollRuns: Number(deletedRuns?.numDeletedRows ?? 0) };
  });
  // مسح بيانات فعلي ولا يمكن التراجع عنه — لازم يفضل له أثر.
  await logAdminEvent({
    entityType: "expenses", entityId: 0, event: "clear_expenses_data",
    details: `مسح ${deletedExpenses} مصروف و${deletedPayrollRuns} كشف راتب للفترة ${from} → ${to}`,
    changedBy: session.userId,
  });
  refreshExpenses();
  return { ok: true, deletedExpenses, deletedPayrollRuns };
}
