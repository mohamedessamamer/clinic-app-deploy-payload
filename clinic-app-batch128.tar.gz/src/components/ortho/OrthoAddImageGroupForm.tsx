"use client";

// Upload widget for the v2 chart's Photos & X-rays section — same real
// addImageGroupAction as the patient file's AddImageGroupForm (real storage,
// real patient_image_groups/patient_images rows), styled to match the "+" tile
// from the v2 design, always English/LTR.
//
// Two-step staged flow (2026-08-27 review round), matching how the original
// system's AddImageGroupForm already behaves: picking files does NOT upload
// them immediately — they sit staged here as thumbnails first (with a second
// "+" tile next to them to add more, and an "x" to drop one before sending),
// and only the explicit "Upload" button actually calls the server action.
// Files are uploaded one at a time without browser-side image decoding or
// compression, so a group of large X-rays cannot exhaust browser/server RAM.

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { getClinicToday } from "@/lib/clinic-date";
import { uploadPatientFiles, type PatientUploadProgress } from "@/lib/patient-file-upload";
import ImageTemplateBoard from "@/components/ortho/ImageTemplateBoard";

// Batch 126: كل ملف مستنى الرفع بيتعرض بصورة مصغّرة حقيقية (preview) مش اسم
// الملف بس — الـobjectURL بيتعمله revoke وقت الشيل أو بعد الرفع عشان الذاكرة.
type StagedFile = { id: string; file: File; preview: string | null };

export default function OrthoAddImageGroupForm({ patientId, compact = false }: { patientId: number; compact?: boolean }) {
  const router = useRouter();
  const today = useMemo(() => getClinicToday(), []);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const [date, setDate] = useState(today);
  const [description, setDescription] = useState("");
  const [staged, setStaged] = useState<StagedFile[]>([]);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState<PatientUploadProgress | null>(null);
  const [error, setError] = useState("");
  // Batch 127: أسماء الملفات اللي اتكشفت مكررة (نفس صورة موجودة قبل كده لنفس
  // المريض) ومااترفعتش — بتتعرض كرسالة بعد الرفع، مش خطأ يوقف الباقي.
  const [duplicateNotice, setDuplicateNotice] = useState("");
  const [compactEditorOpen, setCompactEditorOpen] = useState(false);
  // Batch 124: بعد الرفع بنفتح شاشة مراجعة توزيع الصور على التمبلت.
  const [reviewGroupId, setReviewGroupId] = useState<number | null>(null);

  function stageFiles(files: FileList | File[] | null) {
    if (!files || files.length === 0) return;
    const list = Array.from(files);
    const selected = list.map((file) => ({
      id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      file,
      preview: file.type.startsWith("image/") ? URL.createObjectURL(file) : null,
    }));
    setStaged((prev) => [...prev, ...selected]);
    setError("");
    if (compact) setCompactEditorOpen(true);
  }

  function removeStaged(id: string) {
    setStaged((prev) => {
      const target = prev.find((item) => item.id === id);
      if (target?.preview) URL.revokeObjectURL(target.preview);
      return prev.filter((item) => item.id !== id);
    });
  }

  function clearStaged() {
    setStaged((prev) => {
      for (const item of prev) if (item.preview) URL.revokeObjectURL(item.preview);
      return [];
    });
  }

  // آخر تنظيف لما المكون يقفل.
  const stagedRef = useRef(staged);
  useEffect(() => { stagedRef.current = staged; }, [staged]);
  useEffect(() => () => { for (const item of stagedRef.current) if (item.preview) URL.revokeObjectURL(item.preview); }, []);

  async function upload() {
    if (staged.length === 0 || uploading) return;
    setUploading(true);
    setError("");
    setDuplicateNotice("");
    try {
      const result = await uploadPatientFiles({ patientId, takenAt: date, label: description, files: staged.map((item) => item.file), onProgress: setProgress });
      if (result.duplicates.length) {
        setDuplicateNotice(
          result.duplicates.length === 1
            ? `صورة "${result.duplicates[0]}" موجودة قبل كده لنفس المريض — مااترفعتش.`
            : `${result.duplicates.length} صور موجودة قبل كده لنفس المريض ومااترفعتش: ${result.duplicates.join("، ")}`
        );
      }
      router.refresh();
      clearStaged();
      setDescription("");
      setProgress(null);
      if (fileInputRef.current) fileInputRef.current.value = "";
      if (compact) setCompactEditorOpen(false);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Upload failed.");
    } finally {
      setUploading(false);
    }
  }

  const busy = uploading;

  if (compact) {
    return (
      <>
        <label
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            stageFiles(e.dataTransfer.files);
          }}
          className={`ortho-live-upload-tile ${dragOver ? "is-dragging" : ""} ${busy ? "opacity-60 pointer-events-none" : ""}`}
          title="Add photos"
        >
          +
          <span>Add photos</span>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*,.pdf"
            multiple
            className="hidden"
            onChange={(e) => {
              stageFiles(e.target.files);
              e.target.value = "";
            }}
          />
        </label>

        {compactEditorOpen && staged.length > 0 && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/45 p-4" role="dialog" aria-modal="true" aria-label="Upload photos">
            <div className="w-full max-w-xl rounded-xl bg-white p-4 shadow-2xl" dir="ltr">
              <div className="mb-3 flex items-center justify-between gap-3">
                <h3 className="font-semibold text-sm">Add photos &amp; X-rays</h3>
                <button type="button" onClick={() => setCompactEditorOpen(false)} className="text-muted hover:text-danger text-lg" aria-label="Close">×</button>
              </div>
              <div className="flex gap-2 overflow-x-auto pb-2">
                {staged.map((s) => (
                  <div key={s.id} className="relative h-20 w-20 shrink-0 overflow-hidden rounded-md border border-border bg-background group">
                    {s.preview ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={s.preview} alt={s.file.name} className="h-full w-full object-cover" />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center p-1 text-center text-[10px] text-muted break-all">{s.file.name}</div>
                    )}
                    <button type="button" onClick={() => removeStaged(s.id)} className="absolute right-0.5 top-0.5 grid h-5 w-5 place-items-center rounded-full bg-black/60 text-xs text-white hover:bg-red-600" aria-label="Remove">×</button>
                  </div>
                ))}
                <label className="grid h-20 w-20 shrink-0 cursor-pointer place-items-center rounded-md border-2 border-dashed border-border text-2xl text-muted hover:bg-primary-soft" title="Add more photos">
                  +
                  <input type="file" accept="image/*,.pdf" multiple className="hidden" onChange={(e) => { stageFiles(e.target.files); e.target.value = ""; }} />
                </label>
              </div>
              <div className="mt-3 flex flex-wrap items-end gap-3">
                <label className="text-[11px] text-muted">Date<input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="mt-1 block rounded-md border border-border bg-background px-2 py-1.5 text-xs text-foreground" /></label>
                <label className="min-w-[12rem] flex-1 text-[11px] text-muted">Description (Optional)<input type="text" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Eg.: Panorama" className="mt-1 block w-full rounded-md border border-border bg-background px-2 py-1.5 text-xs text-foreground" /></label>
                <button type="button" onClick={upload} disabled={busy} className="rounded-md btn-3d-primary px-3 py-2 text-xs font-medium disabled:opacity-60">{uploading ? "Uploading…" : `Upload (${staged.length})`}</button>
              </div>
              {uploading && progress && <p className="mt-2 text-xs text-primary">Uploading {progress.current}/{progress.total}: {progress.fileName}</p>}
              {error && <p className="mt-2 text-xs text-danger">{error}</p>}
              {duplicateNotice && <p className="mt-2 text-xs text-muted">{duplicateNotice}</p>}
            </div>
          </div>
        )}
        {reviewGroupId != null && <ImageTemplateBoard groupId={reviewGroupId} patientId={patientId} onClose={() => setReviewGroupId(null)} />}
      </>
    );
  }

  return (
    <div dir="ltr" className="space-y-2">
      <div className="flex gap-2 flex-wrap items-start">
        {staged.map((s) => (
          <div key={s.id} className="relative w-20 h-20 rounded-md overflow-hidden border border-border bg-background group">
            {s.preview ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={s.preview} alt={s.file.name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-[10px] text-muted p-1 text-center break-all">{s.file.name}</div>
            )}
            <button
              type="button"
              onClick={() => removeStaged(s.id)}
              className="absolute top-0.5 right-0.5 w-5 h-5 rounded-full bg-black/60 hover:bg-red-600 text-white text-xs leading-none flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
              title="Remove"
              aria-label="Remove"
            >
              ×
            </button>
          </div>
        ))}

        <label
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            stageFiles(e.dataTransfer.files);
          }}
          className={`w-20 h-20 rounded-md border-2 border-dashed flex items-center justify-center cursor-pointer text-2xl text-muted transition-colors ${
            dragOver ? "border-primary bg-primary-soft" : "border-border hover:bg-primary-soft"
          } ${busy ? "opacity-60 pointer-events-none" : ""}`}
          title="Add photos"
        >
          +
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*,.pdf"
            multiple
            className="hidden"
            onChange={(e) => {
              stageFiles(e.target.files);
              e.target.value = "";
            }}
          />
        </label>
      </div>

      <div className="flex gap-3 flex-wrap items-end max-w-md">
        <div>
          <div className="text-[11px] text-muted mb-1">Date</div>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="rounded-md border border-border bg-background px-2 py-1 text-xs"
          />
        </div>
        <div className="flex-1 min-w-[160px]">
          <div className="text-[11px] text-muted mb-1">Description (Optional)</div>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Eg.: Panorama"
            className="w-full rounded-md border border-border bg-background px-2 py-1 text-xs"
          />
        </div>
        {staged.length > 0 && (
          <button
            type="button"
            onClick={upload}
            disabled={busy}
            className="rounded-md btn-3d-primary px-3 py-1.5 text-xs font-medium disabled:opacity-60"
          >
            {uploading ? "Uploading…" : `Upload (${staged.length})`}
          </button>
        )}
      </div>
      {uploading && progress && <p className="text-xs text-primary">Uploading {progress.current}/{progress.total}: {progress.fileName}</p>}
      {error && <p className="text-xs text-danger">{error}</p>}
      {duplicateNotice && <p className="text-xs text-muted">{duplicateNotice}</p>}
      {reviewGroupId != null && <ImageTemplateBoard groupId={reviewGroupId} patientId={patientId} onClose={() => setReviewGroupId(null)} />}
    </div>
  );
}
