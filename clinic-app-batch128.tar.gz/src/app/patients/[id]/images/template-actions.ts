"use server";

import fs from "node:fs/promises";
import path from "node:path";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getAllSettings } from "@/lib/settings";
import { analyzeImage, assignTemplate, cropFaceThumbnail, extractFeatures, type AssignableImage } from "@/lib/images/classify";
import { isImageKind, type ImageKind } from "@/lib/images/kinds";
import { sortImagesByKind } from "@/lib/images/order";
import { parseImageTemplate, TEMPLATE_SETTING_KEY, type ImageTemplate } from "@/lib/images/template";

// Batch 124: توزيع صور المجموعة على خانات تمبلت التقويم + صورة ملف المريض.
// كل التحليل بيتعمل على السيرفر من الملفات المخزّنة، من غير أي خدمة خارجية.

const UPLOAD_ROOT = process.env.CLINIC_UPLOAD_DIR
  ? path.resolve(process.env.CLINIC_UPLOAD_DIR)
  : path.join(process.cwd(), "data", "uploads");

export type TemplateImage = {
  id: number;
  filePath: string;
  kind: ImageKind | null;
  confidence: number | null;
  slot: string | null;
  /** Batch 127 (الجولة التانية): درجة الدوران الحالية (0/90/180/270) — نفس
   * القيمة المستخدمة في شريط الصور، عشان التمبلت يعرض الصورة بنفس الاتجاه. */
  rotation: number;
};

export type TemplateSuggestion = {
  ok: boolean;
  error?: string;
  template?: ImageTemplate;
  images?: TemplateImage[];
  /** خانة التمبلت لكل صورة (الاقتراح التلقائي أو المحفوظ قبل كده). */
  assignments?: Record<string, number>;
  unassigned?: number[];
};

/** المسار الحقيقي على القرص من المسار العام المخزّن في قاعدة البيانات. */
function diskPathOf(publicPath: string): string | null {
  const prefix = "/patient-files/";
  if (!publicPath.startsWith(prefix)) return null;
  const relative = publicPath.slice(prefix.length);
  const resolved = path.resolve(UPLOAD_ROOT, relative);
  // حماية من أي محاولة خروج من مجلد الرفع.
  if (!resolved.startsWith(path.resolve(UPLOAD_ROOT) + path.sep)) return null;
  return resolved;
}

async function canManageImages(): Promise<{ userId: number; role: string } | null> {
  const session = await getSession();
  if (!session) return null;
  const allowed = ["doctor", "admin", "clinic_manager"].includes(session.role)
    || (await hasPermission(session.userId, session.role, "upload_ortho_photos"));
  return allowed ? { userId: session.userId, role: session.role } : null;
}

async function loadTemplate(): Promise<ImageTemplate> {
  const settings = await getAllSettings();
  return parseImageTemplate(settings[TEMPLATE_SETTING_KEY] as string | undefined);
}

/**
 * اقتراح توزيع صور المجموعة على خانات التمبلت. لو المجموعة اتراجعت قبل كده،
 * بيرجع التوزيع المحفوظ زي ما هو بدل ما يعيد التخمين.
 */
export async function suggestGroupTemplateAction(groupId: number): Promise<TemplateSuggestion> {
  const session = await canManageImages();
  if (!session) return { ok: false, error: "ليس لديك صلاحية على صور المرضى." };
  if (!Number.isInteger(groupId) || groupId <= 0) return { ok: false, error: "مجموعة الصور غير صحيحة." };

  const images = await db.selectFrom("patient_images")
    .select(["id", "file_path", "image_kind", "image_confidence", "template_slot", "rotation"])
    .where("group_id", "=", groupId)
    .orderBy("id")
    .execute();
  if (!images.length) return { ok: false, error: "لا توجد صور في هذه المجموعة." };

  const template = await loadTemplate();
  const templateImages: TemplateImage[] = images.map((image) => ({
    id: image.id,
    filePath: image.file_path,
    kind: isImageKind(image.image_kind) ? image.image_kind : null,
    confidence: image.image_confidence,
    slot: image.template_slot,
    rotation: image.rotation ?? 0,
  }));

  const saved = templateImages.filter((image) => image.slot);
  if (saved.length) {
    const assignments: Record<string, number> = {};
    for (const image of saved) if (image.slot) assignments[image.slot] = image.id;
    return {
      ok: true,
      template,
      images: templateImages,
      assignments,
      unassigned: templateImages.filter((image) => !image.slot).map((image) => image.id),
    };
  }

  // التوزيع بيتعمل بمقارنة صور نفس الدفعة ببعض (شوف assignTemplate).
  const assignable: AssignableImage[] = [];
  for (const image of templateImages) {
    const disk = diskPathOf(image.filePath);
    if (!disk) continue;
    const analysis = await analyzeImage(disk).catch(() => null);
    if (!analysis) continue;
    assignable.push({ id: image.id, analysis: { family: analysis.family, kind: analysis.kind, features: analysis.features } });
    if (!image.kind) image.kind = analysis.kind;
  }
  const { assignments, unassigned } = assignTemplate(template.slots, assignable);
  return { ok: true, template, images: templateImages, assignments, unassigned };
}

/**
 * حفظ التوزيع النهائي بعد مراجعة المستخدم، وتحديث نوع كل صورة حسب الخانة اللي
 * اتحطت فيها (ده كمان بيبني بيانات مسمّاة حقيقية لتحسين التعرف التلقائي بعدين).
 */
export async function saveGroupTemplateAction(
  groupId: number,
  assignments: Record<string, number>
): Promise<{ ok: boolean; error?: string }> {
  const session = await canManageImages();
  if (!session) return { ok: false, error: "ليس لديك صلاحية على صور المرضى." };
  if (!Number.isInteger(groupId) || groupId <= 0) return { ok: false, error: "مجموعة الصور غير صحيحة." };

  const group = await db.selectFrom("patient_image_groups").select(["id", "patient_id"]).where("id", "=", groupId).executeTakeFirst();
  if (!group) return { ok: false, error: "مجموعة الصور غير موجودة." };

  const template = await loadTemplate();
  const slotByKey = new Map(template.slots.map((slot) => [slot.key, slot]));
  const images = await db.selectFrom("patient_images").select(["id", "file_path"]).where("group_id", "=", groupId).execute();
  const imageIds = new Set(images.map((image) => image.id));

  const finalSlots = new Map<number, string>();
  for (const [slotKey, imageId] of Object.entries(assignments)) {
    if (!slotByKey.has(slotKey) || !imageIds.has(Number(imageId))) continue;
    // صورة واحدة في خانة واحدة بس.
    if ([...finalSlots.values()].includes(slotKey)) continue;
    finalSlots.set(Number(imageId), slotKey);
  }

  for (const image of images) {
    const slot = finalSlots.get(image.id) ?? null;
    const slotKind = slot ? slotByKey.get(slot)?.kind : null;
    await db.updateTable("patient_images")
      .set({
        template_slot: slot,
        ...(slotKind && slotKind !== "any" ? { image_kind: slotKind } : {}),
      })
      .where("id", "=", image.id)
      .execute();
  }

  await refreshPatientAvatar(group.patient_id);
  revalidatePath(`/patients/${group.patient_id}`);
  revalidatePath(`/patients/${group.patient_id}/orthodontics`);
  return { ok: true };
}

/**
 * صورة الملف: بتتحدد مرة واحدة بس (أول صورة وش أمامية مرفوعة)، وبعد كده
 * مابتتغيرش تلقائيًا — التغيير يدوي من setPatientAvatarAction.
 */
async function refreshPatientAvatar(patientId: number) {
  const patient = await db.selectFrom("patients").select(["id", "avatar_path"]).where("id", "=", patientId).executeTakeFirst();
  if (!patient || patient.avatar_path) return;
  const candidate = await db.selectFrom("patient_images")
    .innerJoin("patient_image_groups", "patient_image_groups.id", "patient_images.group_id")
    .select(["patient_images.id", "patient_images.file_path", "patient_images.image_kind"])
    .where("patient_image_groups.patient_id", "=", patientId)
    // صورة الملف بتتاخد من وش أمامي بس (الابتسامة الأول) — مش من صورة جانبية.
    .where("patient_images.image_kind", "in", ["face_smile", "face_frontal"])
        // الابتسامة مفضّلة لصورة الملف، وبعدها الوش الأمامي العادي.
    .orderBy((eb) => eb.case().when("patient_images.image_kind", "=", "face_smile").then(0).else(1).end())
    .orderBy("patient_images.id", "desc")
    .executeTakeFirst();
  if (!candidate) return;
  await writeAvatarFrom(patientId, candidate.file_path, candidate.id);
}

async function writeAvatarFrom(patientId: number, filePath: string, imageId: number | null): Promise<string | null> {
  const disk = diskPathOf(filePath);
  if (!disk) return null;
  const analysis = await analyzeImage(disk).catch(() => null);
  // نسخة صغيرة مستقلة (256px) — مش مرتبطة بملف الصورة الأصلية، فحذف الصورة
  // مايكسرش صورة الملف ولا يمنع الحذف.
  const thumbnail = await cropFaceThumbnail(disk, analysis?.faceBox ?? null, 256).catch(() => null);
  if (!thumbnail) return null;
  // الصورة القديمة بتتشال عشان مانسيبش نسخ قديمة على القرص.
  const previous = await db.selectFrom("patients").select(["avatar_path"]).where("id", "=", patientId).executeTakeFirst();
  if (previous?.avatar_path) {
    const previousDisk = diskPathOf(previous.avatar_path);
    if (previousDisk) await fs.unlink(previousDisk).catch(() => undefined);
  }
  const directory = path.join(UPLOAD_ROOT, "patients", String(patientId));
  await fs.mkdir(directory, { recursive: true });
  const name = `avatar-${Date.now()}.jpg`;
  await fs.writeFile(path.join(directory, name), thumbnail);
  const publicPath = `/patient-files/patients/${patientId}/${name}`;
  await db.updateTable("patients").set({ avatar_path: publicPath, avatar_image_id: imageId }).where("id", "=", patientId).execute();
  return publicPath;
}

/**
 * Batch 126: إعادة التعرف على صور مجموعة اتسجلت قبل كده من غير نوع (مثلاً لو
 * التحليل فشل على السيرفر وقت الرفع). بيحدّث النوع والترتيب، وبيحط صورة الملف
 * لو لسه مفيش واحدة.
 */
export async function reclassifyGroupAction(groupId: number): Promise<{ ok: boolean; error?: string; updated?: number; failed?: number }> {
  const session = await canManageImages();
  if (!session) return { ok: false, error: "ليس لديك صلاحية على صور المرضى." };
  if (!Number.isInteger(groupId) || groupId <= 0) return { ok: false, error: "مجموعة الصور غير صحيحة." };

  const group = await db.selectFrom("patient_image_groups").select(["id", "patient_id"]).where("id", "=", groupId).executeTakeFirst();
  if (!group) return { ok: false, error: "مجموعة الصور غير موجودة." };

  const images = await db.selectFrom("patient_images").select(["id", "file_path"]).where("group_id", "=", groupId).orderBy("id").execute();
  let updated = 0;
  let failed = 0;
  for (const image of images) {
    if (image.file_path.toLowerCase().endsWith(".pdf")) continue;
    const disk = diskPathOf(image.file_path);
    if (!disk) { failed += 1; continue; }
    const analysis = await analyzeImage(disk).catch(() => null);
    if (!analysis || analysis.confidence <= 0) { failed += 1; continue; }
    await db.updateTable("patient_images")
      .set({ image_kind: analysis.kind, image_confidence: analysis.confidence })
      .where("id", "=", image.id)
      .execute();
    updated += 1;
  }

  await refreshPatientAvatar(group.patient_id);
  revalidatePath(`/patients/${group.patient_id}`);
  revalidatePath(`/patients/${group.patient_id}/orthodontics`);
  return { ok: true, updated, failed };
}

/** صور المريض اللي تصلح تبقى صورة ملف (كل الصور، والوش الأمامي الأول). */
export async function listAvatarCandidatesAction(patientId: number): Promise<TemplateImage[]> {
  const session = await canManageImages();
  if (!session) return [];
  const images = await db.selectFrom("patient_images")
    .innerJoin("patient_image_groups", "patient_image_groups.id", "patient_images.group_id")
    .select(["patient_images.id", "patient_images.file_path", "patient_images.image_kind", "patient_images.image_confidence", "patient_images.template_slot", "patient_images.rotation"])
    .where("patient_image_groups.patient_id", "=", patientId)
    .orderBy("patient_images.id", "desc")
    .execute();
  return sortImagesByKind(images).map((image) => ({
    id: image.id,
    filePath: image.file_path,
    kind: isImageKind(image.image_kind) ? image.image_kind : null,
    confidence: image.image_confidence,
    slot: image.template_slot,
    rotation: image.rotation ?? 0,
  }));
}

/** شيل صورة الملف (بترجع الحروف الأولى زي الأول). */
export async function clearPatientAvatarAction(patientId: number): Promise<{ ok: boolean; error?: string }> {
  const session = await canManageImages();
  if (!session) return { ok: false, error: "ليس لديك صلاحية على صور المرضى." };
  const patient = await db.selectFrom("patients").select(["avatar_path"]).where("id", "=", patientId).executeTakeFirst();
  if (patient?.avatar_path) {
    const disk = diskPathOf(patient.avatar_path);
    if (disk) await fs.unlink(disk).catch(() => undefined);
  }
  await db.updateTable("patients").set({ avatar_path: null, avatar_image_id: null }).where("id", "=", patientId).execute();
  revalidatePath(`/patients/${patientId}`);
  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true };
}

/**
 * Batch 127: تصحيح يدوي لنوع صورة من التمبلت (الدوس على التعريف تحت الصورة
 * واختيار النوع الصحيح). بينقل الصورة لمكانها الصح فورًا، وبيسجّل التصحيح في
 * patient_image_corrections (النوع القديم/الجديد + بصمة خصائص الصورة) عشان
 * مراجعة بشرية لاحقًا لتحسين العتبات — من غير أي تغيير تلقائي على سلوك
 * التصنيف الحالي (log-only، زي ما اتفقنا).
 */
export async function setImageKindAction(imageId: number, newKind: string): Promise<{ ok: boolean; error?: string }> {
  const session = await canManageImages();
  if (!session) return { ok: false, error: "ليس لديك صلاحية على صور المرضى." };
  if (!isImageKind(newKind)) return { ok: false, error: "نوع صورة غير صحيح." };

  const image = await db.selectFrom("patient_images")
    .innerJoin("patient_image_groups", "patient_image_groups.id", "patient_images.group_id")
    .select([
      "patient_images.id",
      "patient_images.file_path",
      "patient_images.image_kind",
      "patient_images.image_confidence",
      "patient_image_groups.patient_id",
    ])
    .where("patient_images.id", "=", imageId)
    .executeTakeFirst();
  if (!image) return { ok: false, error: "الصورة غير موجودة." };

  // بصمة الخصائص وقت التصحيح — للمراجعة اليدوية بعدين، مش لأي تعلّم تلقائي.
  let featuresJson: string | null = null;
  const disk = diskPathOf(image.file_path);
  if (disk) {
    const extracted = await extractFeatures(disk).catch(() => null);
    if (extracted) featuresJson = JSON.stringify(extracted.features);
  }

  await db.insertInto("patient_image_corrections")
    .values({
      image_id: image.id,
      patient_id: image.patient_id,
      old_kind: image.image_kind,
      old_confidence: image.image_confidence,
      new_kind: newKind,
      features_json: featuresJson,
      corrected_by: session.userId,
    })
    .execute();

  // التصحيح اليدوي بيلغي أي خانة تمبلت متحطة قبل كده (لو موجودة) عشان توزيع
  // التمبلت يتحسب تاني على أساس النوع الصح، وبيرفع الثقة لأقصى درجة (تأكيد بشري).
  await db.updateTable("patient_images")
    .set({ image_kind: newKind, image_confidence: 1, template_slot: null })
    .where("id", "=", imageId)
    .execute();

  await refreshPatientAvatar(image.patient_id);
  revalidatePath(`/patients/${image.patient_id}`);
  revalidatePath(`/patients/${image.patient_id}/orthodontics`);
  return { ok: true };
}

/** تغيير صورة الملف يدويًا من أي صورة وش في معرض المريض. */
export async function setPatientAvatarAction(patientId: number, imageId: number): Promise<{ ok: boolean; error?: string }> {
  const session = await canManageImages();
  if (!session) return { ok: false, error: "ليس لديك صلاحية على صور المرضى." };
  const image = await db.selectFrom("patient_images")
    .innerJoin("patient_image_groups", "patient_image_groups.id", "patient_images.group_id")
    .select(["patient_images.file_path"])
    .where("patient_images.id", "=", imageId)
    .where("patient_image_groups.patient_id", "=", patientId)
    .executeTakeFirst();
  if (!image) return { ok: false, error: "الصورة غير موجودة." };
  const saved = await writeAvatarFrom(patientId, image.file_path, imageId);
  if (!saved) return { ok: false, error: "تعذر تجهيز صورة الملف." };
  revalidatePath(`/patients/${patientId}`);
  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true };
}
