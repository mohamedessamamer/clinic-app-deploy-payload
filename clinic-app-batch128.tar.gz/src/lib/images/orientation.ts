import sharp from "sharp";
import { extractFeatures, familyOf, type ImageFeatures } from "@/lib/images/classify";

// Batch 127 (الجولة التانية): تخمين اتجاه الصورة وقت الرفع، للصور اللي من غير
// EXIF بس (صور الوش الخارجية فقط — مش أشعة ولا صور جوه الفم، عشان مفيش عندنا
// معيار "تماثل/توازن" موثوق لغيرهم). الفكرة: نجرب الصورة في 4 اتجاهات
// (0/90/180/270)، نشغّل نفس دوال استخراج الخصائص (extractFeatures) على كل
// واحد، ونحسب نتيجة "شكل وش طبيعي" (تماثل + توازن + نسبة بشرة معقولة). لو
// اتجاه غير 0 درجة فاز بفارق واضح، بنعتبره تخمين ونطبّقه فعليًا على بايتات
// الملف (sharp) قبل ما نحفظه ونحلله التحليل النهائي.
//
// ده تخمين احتمالي مش يقين زي EXIF — دايمًا قابل للتصحيح يدويًا من زرار الدوران
// في الشريط/التمبلت لو غلط.

const CANDIDATE_ROTATIONS = [0, 90, 180, 270] as const;
type Rotation = (typeof CANDIDATE_ROTATIONS)[number];

/** نتيجة "شكل وش طبيعي" — كل ما زادت، كل ما الاتجاه ده أقرب للصح. */
function faceLikelinessScore(f: ImageFeatures): number {
  if (familyOf(f) !== "face") return -1;
  // تماثل + توازن هما أهم حاجة (وش مقلوب بيكسر التماثل بشكل واضح)، ونسبة
  // البشرة كعامل مساعد بسيط عشان نفضّل الاتجاه اللي الوش فيه واضح مش مقصوص.
  return f.symmetry * 2 + f.balance * 1.5 + Math.min(f.skinRatio, 0.4);
}

export type OrientationGuess = {
  /** الاتجاه اللي طلع أحسن نتيجة (بالنسبة للصورة زي ما اترفعت، 0 = زي ما هي). */
  rotation: Rotation;
  /** لو true يبقى فيه اتجاه غير 0 فاز بفارق واضح واتطبق فعليًا على البافر. */
  applied: boolean;
  /** البافر بعد تطبيق الدوران (أو نفس البافر الأصلي لو applied=false). */
  buffer: Buffer;
};

/**
 * بتتنفذ فقط لما نكون عارفين إن الصورة من غير EXIF orientation (فحص EXIF
 * بيحصل قبل النداء ده في upload/route.ts). بتحاول الـ4 اتجاهات، وبترجع أفضل
 * واحد لو فارق عن الوضع الأصلي (0 درجة) واضح بما فيه الكفاية إننا نطبقه
 * تلقائيًا من غير ما نخاطر بتخمين غلط أوضح من الوضع الأصلي.
 */
export async function guessAndBakeOrientation(buffer: Buffer): Promise<OrientationGuess> {
  const scores = new Map<Rotation, number>();
  const rotatedBuffers = new Map<Rotation, Buffer>();

  for (const rotation of CANDIDATE_ROTATIONS) {
    try {
      const candidate =
        rotation === 0 ? buffer : await sharp(buffer, { failOn: "none" }).rotate(rotation).toBuffer();
      rotatedBuffers.set(rotation, candidate);
      const { features } = await extractFeatures(candidate);
      scores.set(rotation, faceLikelinessScore(features));
    } catch (error) {
      console.error("[images] guessAndBakeOrientation: failed rotation", rotation, error);
      scores.set(rotation, -1);
    }
  }

  const baseScore = scores.get(0) ?? -1;
  // مش صورة وش أصلًا (أو فشل التحليل) — مفيش أساس نقيس عليه، منطبقش تخمين.
  if (baseScore < 0) {
    return { rotation: 0, applied: false, buffer };
  }

  let best: Rotation = 0;
  let bestScore = baseScore;
  for (const rotation of CANDIDATE_ROTATIONS) {
    const score = scores.get(rotation) ?? -1;
    if (score > bestScore) {
      bestScore = score;
      best = rotation;
    }
  }

  // هامش أمان: نطبّق التخمين بس لو فرق واضح، مش أي تحسّن بسيط ممكن يكون
  // ضوضاء قياس. 0.15 اتاخدت من فروق التماثل الحقيقية بين وش سليم ووش مقلوب
  // في صور العيادة (فرق تماثل نموذجي 0.25+ بين الاتجاه الصح والمقلوب).
  const MARGIN = 0.15;
  if (best === 0 || bestScore - baseScore < MARGIN) {
    return { rotation: 0, applied: false, buffer };
  }

  const bakedBuffer = await sharp(rotatedBuffers.get(best)!, { failOn: "none" }).rotate().toBuffer();
  return { rotation: best, applied: true, buffer: bakedBuffer };
}

// re-export مساعد بسيط للاستخدام في actions.ts (rotateImageAction) عشان محتاج
// نفس منطق "خد بافر وطبّق دوران محدد بالدرجة ثم رجّع بافر جديد" من غير ما
// نكرره.
export async function bakeRotation(buffer: Buffer, degrees: number): Promise<Buffer> {
  const normalized = ((degrees % 360) + 360) % 360;
  if (normalized === 0) {
    // لسه بنطبع rotate() من غير args عشان نصفّي أي EXIF orientation متبقي
    // ونضمن إن البايتات المحفوظة متطابقة مع اللي هيتعرض.
    return sharp(buffer, { failOn: "none" }).rotate().toBuffer();
  }
  return sharp(buffer, { failOn: "none" }).rotate().rotate(normalized).toBuffer();
}
