# Batch 128 — release correction and upgrade from published Batch 127

This release packages the later image-orientation/template update under its own release number instead of overwriting the already-published Batch 127.

Changes relative to the published Batch 127:
- Automatic orientation guessing for EXIF-less face photos at upload.
- Manual rotation baked into image bytes, with hash/classification refresh.
- Rotation-aware photo template and enlarged viewer with navigation, rotation and deletion.
- Shared image hash and orientation helpers.

Application files are preserved exactly as supplied in the newer update. Database schema and migrations are identical to the published Batch 127: migration `127_patient_image_dedupe_and_corrections` remains unchanged and must not be renamed or rerun as a new migration.

deploy128.sh validates source hashes against the owner's published Batch 127 before stopping the service. Backup, rollback, staging build, checksum checks and post-swap verification are retained. Do not replace the published Batch 127 artifacts on GitHub.
