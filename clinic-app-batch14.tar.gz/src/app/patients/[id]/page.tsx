import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db/client";
import AddVisitForm from "@/components/AddVisitForm";
import AddImageGroupForm from "@/components/AddImageGroupForm";
import PatientImageGallery from "@/components/PatientImageGallery";
import VisitsTable from "@/components/VisitsTable";
import DeletePatientButton from "@/components/DeletePatientButton";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";

// عدد شهور "محتاج صور جديدة" — لو المريض بيعمل متابعة ومفيش صور/أشعة اتسجلت له
// من أكتر من كذا شهر، بيظهر تنبيه في ملفه (شوف needsNewPhotos تحت).
const PHOTO_REMINDER_MONTHS = 6;

export default async function PatientDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const patientId = Number(id);
  if (!patientId) notFound();

  const patient = await db.selectFrom("patients").selectAll().where("id", "=", patientId).executeTakeFirst();
  if (!patient) notFound();

  const session = await getSession();
  const canOverrideDoctor = session ? await hasPermission(session.userId, session.role, "override_visit_doctor") : false;
  const canEditOldVisits = session ? await hasPermission(session.userId, session.role, "edit_old_visits") : false;
  const canDeleteVisits = session ? await hasPermission(session.userId, session.role, "delete_visits") : false;

  const [visits, doctors, services, serviceDoctorRows, imageGroups] = await Promise.all([
    db
      .selectFrom("visits")
      .leftJoin("services", "services.id", "visits.service_id")
      // بيعرض "مقدم الخدمة الفعلي" هنا (مش الطبيب الأساسي اللي بيتحسب له التحصيل
      // المالي) — القيمتين متساويين افتراضيًا، وبيختلفوا بس لو حد عنده صلاحية
      // "اختيار مقدم خدمة مختلف" حدد حد تاني وقت تسجيل الزيارة.
      .leftJoin("doctors", "doctors.id", "visits.performing_doctor_id")
      .select([
        "visits.id",
        "visits.visit_date",
        "visits.service_id",
        "visits.notes",
        "visits.created_at",
        "services.name as service_name",
        "services.code as service_code",
        "doctors.full_name as doctor_name",
      ])
      .where("visits.patient_id", "=", patientId)
      .orderBy("visits.visit_date", "desc")
      .execute(),
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).execute(),
    db.selectFrom("services").select(["id", "name", "code", "default_price"]).execute(),
    db.selectFrom("service_doctors").select(["service_id", "doctor_id"]).execute(),
    db
      .selectFrom("patient_image_groups")
      .selectAll()
      .where("patient_id", "=", patientId)
      .orderBy("taken_at", "desc")
      .execute(),
  ]);

  const imageGroupsWithFiles = await Promise.all(
    imageGroups.map(async (g) => ({
      ...g,
      images: await db.selectFrom("patient_images").selectAll().where("group_id", "=", g.id).execute(),
    }))
  );

  const serviceDoctorMap: Record<number, number[]> = {};
  for (const row of serviceDoctorRows) {
    (serviceDoctorMap[row.service_id] ??= []).push(row.doctor_id);
  }

  // تنبيه "محتاج صور جديدة": المريض بيعمل متابعة (خدمة كودها "0") من غير ما يكون
  // اتصورله حاجة جديدة من أكتر من PHOTO_REMINDER_MONTHS شهر (أو مالوش صور خالص).
  const hasFollowupVisit = visits.some((v) => v.service_code === "0");
  const lastPhotoTakenAt = imageGroups[0]?.taken_at ?? null; // imageGroups already ordered desc
  const reminderCutoff = new Date();
  reminderCutoff.setMonth(reminderCutoff.getMonth() - PHOTO_REMINDER_MONTHS);
  const reminderCutoffStr = reminderCutoff.toISOString().slice(0, 10);
  const needsNewPhotos = hasFollowupVisit && (!lastPhotoTakenAt || lastPhotoTakenAt < reminderCutoffStr);

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <div className="text-xs text-muted">ملف رقم {patient.file_number}</div>
          <h1 className="text-xl font-bold">{patient.full_name}</h1>
          <div className="text-sm text-muted mt-1 flex gap-4 flex-wrap">
            {patient.age && <span>السن: {patient.age}</span>}
            {patient.phone && <span>التليفون: {patient.phone}</span>}
            {patient.address && <span>العنوان: {patient.address}</span>}
          </div>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <Link
            href={`/patients/${patientId}/billing`}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-2 rounded-md border border-border text-sm hover:bg-primary-soft whitespace-nowrap"
          >
            الملف المالي
          </Link>
          {/* حذف حالة نهائيًا - للأدمن بس، أساسًا لتنظيف حالات تجربة (test) بعد الانتهاء منها. */}
          {session?.role === "admin" && (
            <DeletePatientButton patientId={patientId} patientName={patient.full_name} redirectTo="/patients" />
          )}
        </div>
      </div>

      {/* حجز الموعد القادم اتنقل من هنا لبوكس التحصيل في الجدول (يظهر للاستقبال
          بعد ما يختار الخدمة ويسجل الدفع وقت ما يحدد الموعد "تم") — اختياري هناك. */}
      {needsNewPhotos && (
        <div className="text-sm bg-amber-50 text-amber-800 border border-amber-300 rounded-md px-3 py-2">
          المريض ده بيعمل متابعة، ومفيش صور أو أشعة مسجلة له من أكتر من {PHOTO_REMINDER_MONTHS} شهور
          {lastPhotoTakenAt ? ` (آخر صورة بتاريخ ${lastPhotoTakenAt})` : " (مفيش صور اتسجلت له خالص)"} — يفضل تتاخد
          صور جديدة في زيارته الجاية.
        </div>
      )}

      {/* Image / X-ray gallery */}
      <section className="bg-surface border border-border rounded-xl p-5 space-y-3">
        <h2 className="font-semibold">الصور والأشعة</h2>

        <PatientImageGallery groups={imageGroupsWithFiles} patientId={patientId} />

        <AddImageGroupForm patientId={patientId} />
      </section>

      {/* Visits history table */}
      <section className="bg-surface border border-border rounded-xl p-5 space-y-4">
        <h2 className="font-semibold">سجل الزيارات</h2>

        <AddVisitForm
          patientId={patientId}
          services={services}
          doctors={doctors}
          serviceDoctorMap={serviceDoctorMap}
          currentDoctorId={session?.role === "doctor" ? session.doctorId ?? null : null}
          canOverrideDoctor={canOverrideDoctor}
        />

        {/* التعديل مسموح خلال أول 3 أيام من تسجيل الزيارة لأي حد، وبعد كده محتاج
            صلاحية "edit_old_visits" (شوف VisitsTable.tsx وactions.ts). */}
        <VisitsTable
          patientId={patientId}
          visits={visits}
          services={services}
          canEditOldVisits={canEditOldVisits}
          canDeleteVisits={canDeleteVisits}
        />
      </section>
    </div>
  );
}
