"use server";

import { revalidatePath } from "next/cache";
import path from "node:path";
import fs from "node:fs/promises";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";

// بيسجل زيارة يدوية (من ملف المريض، مش عن طريق موعد في الجدول). الطبيب الأساسي
// (اللي بيتحسب له التحصيل المالي) بيتحدد كالتالي:
// - لو المستخدم الحالي دكتور: هو نفسه دايمًا، حتى لو اتبعت حاجة تانية في الفورم
//   (الحماية دي في السيرفر مش بس في الواجهة).
// - غير كده (استقبال/محاسب/مدير عيادة/أدمن): اللي اتحدد في القايمة.
// "مقدم الخدمة الفعلي" (performing_doctor_id) ممكن يكون مختلف عن الطبيب الأساسي
// بس لو المستخدم عنده صلاحية override_visit_doctor — غير كده بيتساوى بيه دايمًا.
export async function addVisitAction(formData: FormData) {
  const patientId = Number(formData.get("patient_id"));
  const visit_date = String(formData.get("visit_date") || "").trim();
  const service_id = formData.get("service_id") ? Number(formData.get("service_id")) : null;
  const notes = String(formData.get("notes") || "").trim() || null;
  const session = await getSession();

  if (!patientId || !visit_date) return;

  const canOverrideDoctor = session ? await hasPermission(session.userId, session.role, "override_visit_doctor") : false;

  const primary_doctor_id =
    session?.role === "doctor" && session.doctorId
      ? session.doctorId
      : formData.get("doctor_id")
        ? Number(formData.get("doctor_id"))
        : null;

  const performingRaw = formData.get("performing_doctor_id");
  const performing_doctor_id = canOverrideDoctor && performingRaw ? Number(performingRaw) || primary_doctor_id : primary_doctor_id;

  const visitResult = await db
    .insertInto("visits")
    .values({
      patient_id: patientId,
      visit_date,
      service_id,
      notes,
      primary_doctor_id,
      performing_doctor_id,
      room_id: null,
      created_by: session?.userId ?? null,
    })
    .executeTakeFirst();

  // Every visit gets an invoice automatically, pre-filled with the service's
  // default price when a service was chosen (staff can adjust the amount later).
  if (visitResult.insertId) {
    let amount = 0;
    if (service_id) {
      const service = await db
        .selectFrom("services")
        .select("default_price")
        .where("id", "=", service_id)
        .executeTakeFirst();
      amount = service?.default_price ?? 0;
    }
    await db
      .insertInto("invoices")
      .values({ visit_id: Number(visitResult.insertId), amount, paid: 0 })
      .execute();
  }

  revalidatePath(`/patients/${patientId}`);
  revalidatePath("/invoices");
}

// عدد الأيام اللي أي حد يقدر يعدّل خلالها زيارة اتسجلت (تصحيح غلطة إدخال بسيطة).
// بعد الفترة دي، محتاج صلاحية "edit_old_visits" (دكتور معيّن أو مدير العيادة
// افتراضيًا — شوف permission-defs.ts). ده بيفرق عن primary/performing_doctor_id
// اللي التعديل ده مايلمسهاش خالص، عشان ميأثرش على التحصيل المالي المسجل بالفعل.
const VISIT_EDIT_WINDOW_DAYS = 3;

// بيعدّل تاريخ/خدمة/ملاحظات زيارة موجودة (مش الدكاترة المرتبطين بيها). لو الخدمة
// اتغيّرت وفاتورتها لسه من غير تحصيل ومن غير تعديل سعر يدوي، بيحدّث سعرها
// تلقائيًا على سعر الخدمة الجديدة (غير كده بيسيب الفاتورة زي ما هي، عشان ميأثرش
// على تحصيل مالي حصل بالفعل أو سعر اتعدل يدويًا).
export async function updateVisitAction(formData: FormData) {
  const session = await getSession();
  if (!session) return;

  const visitId = Number(formData.get("visit_id"));
  const patientId = Number(formData.get("patient_id"));
  const visit_date = String(formData.get("visit_date") || "").trim();
  const service_id = formData.get("service_id") ? Number(formData.get("service_id")) : null;
  const notes = String(formData.get("notes") || "").trim() || null;
  if (!visitId || !patientId || !visit_date) return;

  const visit = await db
    .selectFrom("visits")
    .select(["id", "created_at", "service_id"])
    .where("id", "=", visitId)
    .where("patient_id", "=", patientId)
    .executeTakeFirst();
  if (!visit) return;

  const createdAt = new Date(visit.created_at.replace(" ", "T") + "Z");
  const ageDays = (Date.now() - createdAt.getTime()) / (1000 * 60 * 60 * 24);
  if (ageDays > VISIT_EDIT_WINDOW_DAYS) {
    const canEditOld = await hasPermission(session.userId, session.role, "edit_old_visits");
    if (!canEditOld) return;
  }

  await db
    .updateTable("visits")
    .set({ visit_date, service_id, notes })
    .where("id", "=", visitId)
    .execute();

  // resync السعر بس لو الخدمة اتغيّرت، والفاتورة لسه من غير تحصيل ومن غير سعر
  // معدّل يدويًا (price_overridden) — أي حالة تانية بنسيبها زي ما هي عمدًا.
  if (service_id && service_id !== visit.service_id) {
    const invoice = await db
      .selectFrom("invoices")
      .select(["id", "paid", "price_overridden"])
      .where("visit_id", "=", visitId)
      .executeTakeFirst();
    if (invoice && Number(invoice.paid) === 0 && Number(invoice.price_overridden) === 0) {
      const service = await db
        .selectFrom("services")
        .select("default_price")
        .where("id", "=", service_id)
        .executeTakeFirst();
      if (service) {
        await db
          .updateTable("invoices")
          .set({ amount: service.default_price, original_price: service.default_price })
          .where("id", "=", invoice.id)
          .execute();
      }
    }
  }

  revalidatePath(`/patients/${patientId}`);
  revalidatePath("/invoices");
}

// بيمسح زيارة (وفاتورتها المرتبطة) نهائيًا من سجل الزيارات — لتصحيح إدخال مكرر
// أو غلط بالكامل (مش تعديل بسيط زي updateVisitAction فوق)، محصور بصلاحية
// "delete_visits" (الأدمن بس افتراضيًا — قابلة للمنح لغيره من الإعدادات لو
// المستخدم حابب). عملية لا رجعة فيها، والتأكيد بيحصل في الواجهة (window.confirm)
// قبل ما الأكشن ده يتستدعى أصلاً.
export async function deleteVisitAction(formData: FormData) {
  const session = await getSession();
  if (!session) return;
  const canDelete = await hasPermission(session.userId, session.role, "delete_visits");
  if (!canDelete) return;

  const visitId = Number(formData.get("visit_id"));
  const patientId = Number(formData.get("patient_id"));
  if (!visitId || !patientId) return;

  const visit = await db
    .selectFrom("visits")
    .select(["id"])
    .where("id", "=", visitId)
    .where("patient_id", "=", patientId)
    .executeTakeFirst();
  if (!visit) return;

  const visitInvoices = await db.selectFrom("invoices").select("id").where("visit_id", "=", visitId).execute();
  const invoiceIds = visitInvoices.map((inv) => inv.id);

  if (invoiceIds.length > 0) {
    // لو حد من فواتير الزيارة دي كان "فاتورة أصلية" لدفعات متابعة تانية بتخصم
    // منه (parent_invoice_id)، فك الإشارة دي الأول عشان قيد المفتاح الخارجي
    // مايمنعش الحذف.
    await db
      .updateTable("invoices")
      .set({ parent_invoice_id: null })
      .where("parent_invoice_id", "in", invoiceIds)
      .execute();
    await db.deleteFrom("invoices").where("visit_id", "=", visitId).execute();
  }

  await db.deleteFrom("visits").where("id", "=", visitId).execute();

  revalidatePath(`/patients/${patientId}`);
  revalidatePath(`/patients/${patientId}/billing`);
  revalidatePath("/invoices");
  revalidatePath("/front-desk");
}

// NOTE (image-upload-404 fix, v2): two separate bugs were found here.
// (1) process.cwd() under systemd isn't guaranteed to equal the app's source
//     root, so a file could get written to one absolute path while the
//     server resolved requests against a different one — fixed by pinning
//     an absolute root via CLINIC_UPLOAD_DIR (same pattern as CLINIC_DB_PATH).
// (2) more fundamentally: Next.js's "public" folder is only scanned ONCE at
//     server boot (a snapshot of filenames used to serve static assets), so
//     writing new files into "public/..." at runtime is invisible until the
//     next deploy/restart — any photo uploaded during normal clinic hours
//     would 404 forever until then. So uploads are stored OUTSIDE "public"
//     entirely (mirroring where the sqlite db already lives, under data/,
//     which the deploy process already backs up and never overwrites) and
//     served through a dynamic route (src/app/patient-files/[...path]/route.ts)
//     that reads the file from disk on every request — no snapshot involved.
const UPLOAD_ROOT = process.env.CLINIC_UPLOAD_DIR
  ? path.join(path.resolve(process.env.CLINIC_UPLOAD_DIR), "patients")
  : path.join(process.cwd(), "data", "uploads", "patients");

export async function addImageGroupAction(formData: FormData) {
  const patientId = Number(formData.get("patient_id"));
  const taken_at = String(formData.get("taken_at") || "").trim();
  const label = String(formData.get("label") || "").trim() || null;
  const files = formData.getAll("files") as File[];

  if (!patientId || !taken_at) return;

  const group = await db
    .insertInto("patient_image_groups")
    .values({ patient_id: patientId, taken_at, label })
    .executeTakeFirst();

  const groupId = Number(group.insertId);
  const dir = path.join(UPLOAD_ROOT, String(patientId));
  await fs.mkdir(dir, { recursive: true });

  for (const file of files) {
    if (!file || typeof file === "string" || !file.size) continue;
    const safeName = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
    const buffer = Buffer.from(await file.arrayBuffer());
    await fs.writeFile(path.join(dir, safeName), buffer);
    const publicPath = `/patient-files/patients/${patientId}/${safeName}`;
    await db.insertInto("patient_images").values({ group_id: groupId, file_path: publicPath }).execute();
  }

  revalidatePath(`/patients/${patientId}`);
}

// بيمسح صورة واحدة (صورة اترفعت غلط أو مكررة). التأكيد بيحصل في الطبقة
// العميلة (window.confirm) قبل ما الأكشن ده يتستدعى أصلاً، زي نفس النمط
// المتبع مع حذف المستخدمين/العيادات في الإعدادات.
export async function deleteImageAction(formData: FormData) {
  const session = await getSession();
  if (!session) return;

  const imageId = Number(formData.get("image_id"));
  const patientId = Number(formData.get("patient_id"));
  if (!imageId || !patientId) return;

  const image = await db
    .selectFrom("patient_images")
    .select(["id", "file_path", "group_id"])
    .where("id", "=", imageId)
    .executeTakeFirst();
  if (!image) return;

  await db.deleteFrom("patient_images").where("id", "=", imageId).execute();

  // الملف نفسه على القرص - نمسحه best-effort، لو مش موجود أصلاً (اتمسح قبل
  // كده يدويًا مثلاً) منسيبش الحذف كله يفشل بسبب كده.
  if (image.file_path.startsWith("/patient-files/")) {
    // UPLOAD_ROOT فوق already بينتهي بـ "/patients"، و file_path المخزّن شكله
    // "/patient-files/patients/<id>/<name>" — يعني dirname(UPLOAD_ROOT) هو
    // نفس القاعدة اللي راوت العرض (route.ts) بيبني منها المسار.
    const relative = image.file_path.replace(/^\/patient-files\//, "");
    const filePath = path.join(path.dirname(UPLOAD_ROOT), relative);
    await fs.unlink(filePath).catch(() => {});
  }

  // لو دي كانت آخر صورة في مجموعتها، امسح المجموعة (الكارت) نفسها كمان —
  // غير كده كانت هتفضل تظهر في المعرض كمربع فاضي "لا صور" من غير أي فايدة.
  const remaining = await db
    .selectFrom("patient_images")
    .select((eb) => eb.fn.countAll<number>().as("count"))
    .where("group_id", "=", image.group_id)
    .executeTakeFirst();
  if (!remaining || Number(remaining.count) === 0) {
    await db.deleteFrom("patient_image_groups").where("id", "=", image.group_id).execute();
  }

  revalidatePath(`/patients/${patientId}`);
}
