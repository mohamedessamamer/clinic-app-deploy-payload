import Link from "next/link";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import DeletePatientButton from "@/components/DeletePatientButton";

export default async function PatientsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q } = await searchParams;
  const session = await getSession();
  const isAdmin = session?.role === "admin";

  let query = db.selectFrom("patients").selectAll().orderBy("id", "desc").limit(50);
  if (q && q.trim()) {
    const term = `%${q.trim()}%`;
    query = query.where((eb) =>
      eb.or([
        eb("full_name", "like", term),
        eb("phone", "like", term),
        eb("file_number", "like", term),
      ])
    );
  }
  const patients = await query.execute();

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h1 className="text-xl font-bold">ملفات المرضى</h1>
        <Link href="/patients/new" className="px-3 py-2 rounded-md bg-primary text-white text-sm hover:bg-primary-dark">
          + مريض جديد
        </Link>
      </div>

      <form className="flex gap-2">
        <input
          type="text"
          name="q"
          defaultValue={q}
          placeholder="ابحث بالاسم أو رقم التليفون أو رقم الملف..."
          className="flex-1 rounded-md border border-border bg-surface px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
        <button className="px-4 py-2 rounded-md border border-border text-sm hover:bg-primary-soft">بحث</button>
      </form>

      <div className="bg-surface border border-border rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-primary-soft text-primary-dark">
            <tr>
              <th className="text-right px-4 py-2 font-medium">رقم الملف</th>
              <th className="text-right px-4 py-2 font-medium">الاسم</th>
              <th className="text-right px-4 py-2 font-medium">السن</th>
              <th className="text-right px-4 py-2 font-medium">التليفون</th>
              <th className="px-4 py-2"></th>
            </tr>
          </thead>
          <tbody>
            {patients.map((p) => (
              <tr key={p.id} className="border-t border-border hover:bg-background">
                <td className="px-4 py-2 text-muted">{p.file_number}</td>
                <td className="px-4 py-2 font-medium">
                  <Link href={`/patients/${p.id}`} target="_blank" rel="noopener noreferrer" className="hover:text-primary hover:underline">
                    {p.full_name}
                  </Link>
                </td>
                <td className="px-4 py-2">{p.age ?? "-"}</td>
                <td className="px-4 py-2">{p.phone ?? "-"}</td>
                <td className="px-4 py-2 text-left">
                  <div className="flex items-center justify-end gap-3">
                    <Link href={`/patients/${p.id}`} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                      فتح الملف (تبويب جديد)
                    </Link>
                    {/* حذف حالة نهائيًا - للأدمن بس، أساسًا لتنظيف حالات تجربة (test) بعد
                        الانتهاء منها. */}
                    {isAdmin && <DeletePatientButton patientId={p.id} patientName={p.full_name} />}
                  </div>
                </td>
              </tr>
            ))}
            {patients.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-muted">
                  لا يوجد مرضى مطابقين.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
