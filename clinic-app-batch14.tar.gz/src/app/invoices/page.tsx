import { db } from "@/lib/db/client";
import { updatePaymentAction } from "./actions";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import DateFilterForm from "@/components/DateFilterForm";
import { PAYMENT_METHODS, paymentMethodLabel } from "@/lib/payment-methods";

export default async function InvoicesPage({
  searchParams,
}: {
  searchParams: Promise<{ date?: string }>;
}) {
  const { date } = await searchParams;
  const day = date && /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : new Date().toISOString().slice(0, 10);

  const session = await getSession();
  // بمجرد ما مبلغ مدفوع يتسجل، مفروض يفضل ثابت — التعديل بعد كده محصور بالصلاحية
  // دي (مدير العيادة/المحاسب/الأدمن افتراضيًا) عشان تصحيح غلطة إدخال من الاستقبال.
  const canEditPayments = session ? await hasPermission(session.userId, session.role, "edit_invoice_payments") : false;
  // الإجماليات (الكروت فوق) والتفاصيل المالية الكاملة لكل فاتورة (السعر الأصلي/
  // الخصم/المبلغ) وتقرير "تعديلات اليوم" — محصورة بالصلاحية دي (مدير العيادة/
  // المحاسب/الأدمن افتراضيًا، قابلة للمنح لدكتور معيّن كمان من الإعدادات). غير
  // كده (زي الاستقبال) بيشوف بس المدفوع وطريقة الدفع والمتبقي لكل مريض.
  const canViewTotals = session ? await hasPermission(session.userId, session.role, "view_invoice_totals") : false;

  const invoices = await db
    .selectFrom("invoices")
    .innerJoin("visits", "visits.id", "invoices.visit_id")
    .innerJoin("patients", "patients.id", "visits.patient_id")
    .leftJoin("doctors", "doctors.id", "visits.primary_doctor_id")
    .leftJoin("services", "services.id", "visits.service_id")
    .select([
      "invoices.id",
      "invoices.amount",
      "invoices.paid",
      "invoices.original_price",
      "invoices.discount_percent",
      "invoices.payment_method",
      "visits.visit_date",
      "patients.full_name as patient_name",
      "doctors.full_name as doctor_name",
      "services.name as service_name",
    ])
    .where("visits.visit_date", "=", day)
    .orderBy("invoices.id", "desc")
    .execute();

  const totals = invoices.reduce(
    (acc, inv) => {
      acc.amount += inv.amount;
      acc.paid += inv.paid;
      return acc;
    },
    { amount: 0, paid: 0 }
  );

  // تقرير "تعديلات اليوم" بيكشف قيم مبالغ قديمة/جديدة — بيتعرض بس لمين عنده
  // view_invoice_totals (نفس منطق إخفاء التفاصيل المالية عن الاستقبال)، فمفيش داعي
  // نجيب البيانات دي أصلاً لو مش هتتعرض.
  const overrides = canViewTotals
    ? await db
        .selectFrom("audit_log")
        .leftJoin("users", "users.id", "audit_log.changed_by")
        .select([
          "audit_log.id",
          "audit_log.entity_type",
          "audit_log.field",
          "audit_log.old_value",
          "audit_log.new_value",
          "audit_log.reason",
          "audit_log.changed_at",
          "users.full_name as changed_by_name",
        ])
        .where("audit_log.changed_at", "like", `${day}%`)
        .orderBy("audit_log.id", "desc")
        .execute()
    : [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h1 className="text-xl font-bold">الفواتير</h1>
        <DateFilterForm day={day} />
      </div>

      {canViewTotals && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-surface border border-border rounded-xl p-4">
            <div className="text-xs text-muted">إجمالي فواتير اليوم</div>
            <div className="text-2xl font-bold">{totals.amount.toFixed(0)} ج.م</div>
          </div>
          <div className="bg-surface border border-border rounded-xl p-4">
            <div className="text-xs text-muted">المحصّل</div>
            <div className="text-2xl font-bold text-primary">{totals.paid.toFixed(0)} ج.م</div>
          </div>
          <div className="bg-surface border border-border rounded-xl p-4">
            <div className="text-xs text-muted">المتبقي</div>
            <div className="text-2xl font-bold text-danger">{(totals.amount - totals.paid).toFixed(0)} ج.م</div>
          </div>
        </div>
      )}

      <div className="bg-surface border border-border rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-primary-soft text-primary-dark">
            <tr>
              <th className="text-right px-3 py-2 font-medium">المريض</th>
              <th className="text-right px-3 py-2 font-medium">الخدمة</th>
              <th className="text-right px-3 py-2 font-medium">الدكتور</th>
              {canViewTotals && (
                <>
                  <th className="text-right px-3 py-2 font-medium">السعر الأصلي</th>
                  <th className="text-right px-3 py-2 font-medium">الخصم</th>
                  <th className="text-right px-3 py-2 font-medium">المبلغ</th>
                </>
              )}
              <th className="text-right px-3 py-2 font-medium">المدفوع</th>
              <th className="text-right px-3 py-2 font-medium">المتبقي</th>
              <th className="text-right px-3 py-2 font-medium">طريقة الدفع</th>
              <th className="text-right px-3 py-2 font-medium">{canEditPayments ? "تعديل" : ""}</th>
            </tr>
          </thead>
          <tbody>
            {invoices.map((inv) => (
              <tr key={inv.id} className="border-t border-border">
                <td className="px-3 py-2 font-medium">{inv.patient_name}</td>
                <td className="px-3 py-2">{inv.service_name ?? "-"}</td>
                <td className="px-3 py-2">{inv.doctor_name ?? "-"}</td>
                {canViewTotals && (
                  <>
                    <td className="px-3 py-2 text-muted">{inv.original_price != null ? inv.original_price.toFixed(0) : "-"}</td>
                    <td className="px-3 py-2">{inv.discount_percent ? `${inv.discount_percent}%` : "-"}</td>
                    <td className="px-3 py-2">{inv.amount.toFixed(0)}</td>
                  </>
                )}
                <td className="px-3 py-2">{inv.paid.toFixed(0)}</td>
                <td className="px-3 py-2 text-danger">{inv.amount > 0 ? (inv.amount - inv.paid).toFixed(0) : "-"}</td>
                <td className="px-3 py-2">{paymentMethodLabel(inv.payment_method)}</td>
                <td className="px-3 py-2">
                  {/* التعديل بعد التسجيل محصور بصلاحية edit_invoice_payments —
                      غير كده الخانة فاضية والقيم اللي في الأعمدة فوق هي المرجع الوحيد. */}
                  {canEditPayments ? (
                    <form action={updatePaymentAction} className="flex items-center gap-1">
                      <input type="hidden" name="id" value={inv.id} />
                      <input
                        type="number"
                        name="amount"
                        defaultValue={inv.amount}
                        step="0.01"
                        title="المبلغ"
                        className="w-16 rounded-md border border-border bg-background px-2 py-1 text-xs"
                      />
                      <input
                        type="number"
                        name="paid"
                        defaultValue={inv.paid}
                        step="0.01"
                        title="المدفوع"
                        className="w-16 rounded-md border border-border bg-background px-2 py-1 text-xs"
                      />
                      <select
                        name="payment_method"
                        defaultValue={inv.payment_method ?? ""}
                        title="طريقة الدفع"
                        className="rounded-md border border-border bg-background px-1.5 py-1 text-xs"
                      >
                        <option value="">-</option>
                        {PAYMENT_METHODS.map((m) => (
                          <option key={m.value} value={m.value}>
                            {m.label}
                          </option>
                        ))}
                      </select>
                      <button type="submit" className="text-xs px-2 py-1 rounded-md border border-border hover:bg-primary-soft">
                        تحديث
                      </button>
                    </form>
                  ) : (
                    <span className="text-xs text-muted">-</span>
                  )}
                </td>
              </tr>
            ))}
            {invoices.length === 0 && (
              <tr>
                <td colSpan={canViewTotals ? 10 : 7} className="px-3 py-6 text-center text-muted">
                  لا يوجد فواتير لليوم ده.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {overrides.length > 0 && (
        <section className="bg-surface border border-border rounded-xl p-5 space-y-3">
          <h2 className="font-semibold">تعديلات اليوم (تقرير آخر اليوم)</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-danger-soft text-danger">
                <tr>
                  <th className="text-right px-3 py-2 font-medium">الوقت</th>
                  <th className="text-right px-3 py-2 font-medium">التعديل</th>
                  <th className="text-right px-3 py-2 font-medium">من</th>
                  <th className="text-right px-3 py-2 font-medium">إلى</th>
                  <th className="text-right px-3 py-2 font-medium">بواسطة</th>
                </tr>
              </thead>
              <tbody>
                {overrides.map((o) => (
                  <tr key={o.id} className="border-t border-border">
                    <td className="px-3 py-2 text-muted whitespace-nowrap">{o.changed_at.slice(11, 16)}</td>
                    <td className="px-3 py-2">{o.reason ?? o.field}</td>
                    <td className="px-3 py-2">{o.old_value ?? "-"}</td>
                    <td className="px-3 py-2">{o.new_value ?? "-"}</td>
                    <td className="px-3 py-2">{o.changed_by_name ?? "-"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
}
