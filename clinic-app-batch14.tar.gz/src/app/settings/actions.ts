"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { setSetting } from "@/lib/settings";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hashPassword, verifyPassword } from "@/lib/auth";
import { PERMISSION_DEFS, setPermissionOverride } from "@/lib/permissions";

export async function saveSettingsAction(formData: FormData) {
  const slot_minutes = String(formData.get("slot_minutes") || "15");
  const day_start = String(formData.get("day_start") || "09:00");
  const day_end = String(formData.get("day_end") || "22:00");
  const holidayWeekdays = formData.getAll("holiday_weekdays").map(String).join(",");

  await setSetting("slot_minutes", slot_minutes);
  await setSetting("day_start", day_start);
  await setSetting("day_end", day_end);
  await setSetting("holiday_weekdays", holidayWeekdays);

  revalidatePath("/settings");
  revalidatePath("/front-desk");
}

// --- إعدادات العيادات (الغرف) -----------------------------------------------

export async function addRoomAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const name = String(formData.get("name") || "").trim();
  if (!name) return;

  await db.insertInto("rooms").values({ name }).execute();
  revalidatePath("/settings");
  revalidatePath("/front-desk");
}

// مينفعش نحذف عيادة/غرفة لسه مربوطة بشيفتات أو مواعيد أو زيارات — لازم الأدمن
// يشيلها من هناك الأول، عشان منكسرش أي بيانات تاريخية أو نخالف قيد الـ foreign key.
export async function deleteRoomAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const id = Number(formData.get("id"));
  if (!id) return;

  const [inShifts, inWeeklyShifts, inAppointments, inVisits] = await Promise.all([
    db.selectFrom("shifts").select("id").where("room_id", "=", id).executeTakeFirst(),
    db.selectFrom("doctor_weekly_shifts").select("id").where("room_id", "=", id).executeTakeFirst(),
    db.selectFrom("appointments").select("id").where("room_id", "=", id).executeTakeFirst(),
    db.selectFrom("visits").select("id").where("room_id", "=", id).executeTakeFirst(),
  ]);
  if (inShifts || inWeeklyShifts || inAppointments || inVisits) {
    redirect("/settings?roomerror=in_use");
  }

  await db.deleteFrom("rooms").where("id", "=", id).execute();
  revalidatePath("/settings");
  revalidatePath("/front-desk");
}

// --- إعدادات الصلاحيات ------------------------------------------------------

export async function saveDoctorReportMaxDaysAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const days = Number(formData.get("doctor_report_max_days") || 60);
  await setSetting("doctor_report_max_days", String(Math.max(1, days)));
  revalidatePath("/settings");
}

export async function updatePermissionsAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const userId = Number(formData.get("user_id"));
  if (!userId) return;

  for (const def of PERMISSION_DEFS) {
    const granted = formData.get(`perm_${def.key}`) === "on";
    await setPermissionOverride(userId, def.key, granted);
  }

  revalidatePath("/settings");
}

// --- إعدادات الخدمات ---------------------------------------------------

export async function addServiceAction(formData: FormData) {
  const name = String(formData.get("name") || "").trim();
  const name_en = String(formData.get("name_en") || "").trim() || null;
  const category = String(formData.get("category") || "").trim() || null;
  const default_price = Number(formData.get("default_price") || 0);
  const code = String(formData.get("code") || "").trim() || null;
  const price_note = String(formData.get("price_note") || "").trim() || null;
  const prepaid = formData.get("prepaid") ? 1 : 0;
  if (!name) return;

  await db
    .insertInto("services")
    .values({ name, name_en, category, default_price, code, price_note, prepaid })
    .execute();
  revalidatePath("/settings");
}

// السعر تحديدًا يحتاج تأكيد قبل الحفظ (اتفقنا عليه في الخطة) - الفرونت إند بيعرض
// window.confirm قبل استدعاء الأكشن ده لما يتغير السعر تحديدًا، فالتأكيد بيحصل
// في الطبقة العميلة قبل الوصول هنا أصلاً.
export async function updateServiceAction(formData: FormData) {
  const id = Number(formData.get("id"));
  const name = String(formData.get("name") || "").trim();
  const name_en = String(formData.get("name_en") || "").trim() || null;
  const category = String(formData.get("category") || "").trim() || null;
  const default_price = Number(formData.get("default_price") || 0);
  const code = String(formData.get("code") || "").trim() || null;
  const price_note = String(formData.get("price_note") || "").trim() || null;
  const prepaid = formData.get("prepaid") ? 1 : 0;
  if (!id || !name) return;

  await db
    .updateTable("services")
    .set({ name, name_en, category, default_price, code, price_note, prepaid })
    .where("id", "=", id)
    .execute();
  revalidatePath("/settings");
}

// --- شيفتات الأطباء الأسبوعية ------------------------------------------

export async function addWeeklyShiftAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const room_id = Number(formData.get("room_id"));
  const weekday = Number(formData.get("weekday"));
  const doctor_id = Number(formData.get("doctor_id"));
  const start_time = String(formData.get("start_time") || "");
  const end_time = String(formData.get("end_time") || "");

  if (!room_id || !doctor_id || !start_time || !end_time) return;
  if (!Number.isInteger(weekday) || weekday < 0 || weekday > 6) return;

  await db.insertInto("doctor_weekly_shifts").values({ room_id, weekday, doctor_id, start_time, end_time }).execute();
  revalidatePath("/settings");
  revalidatePath("/front-desk");
}

export async function deleteWeeklyShiftAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const id = Number(formData.get("id"));
  if (!id) return;

  await db.deleteFrom("doctor_weekly_shifts").where("id", "=", id).execute();
  revalidatePath("/settings");
  revalidatePath("/front-desk");
}

// --- إعدادات الأطباء ------------------------------------------------------

// خريطة تحويل تقريبية من الحروف العربية لحروف لاتينية، عشان اليوزرنيم يبقى
// مرتبط باسم الدكتور الحقيقي حتى لو الاسم مكتوب عربي بالكامل (الحالة الشائعة هنا).
const ARABIC_TRANSLITERATION: Record<string, string> = {
  ا: "a", أ: "a", إ: "e", آ: "a", ب: "b", ت: "t", ث: "th", ج: "g", ح: "h",
  خ: "kh", د: "d", ذ: "th", ر: "r", ز: "z", س: "s", ش: "sh", ص: "s", ض: "d",
  ط: "t", ظ: "z", ع: "a", غ: "gh", ف: "f", ق: "q", ك: "k", ل: "l", م: "m",
  ن: "n", ه: "h", و: "w", ي: "y", ى: "a", ة: "a", ء: "", ئ: "e", ؤ: "o",
};

function transliterateArabic(word: string): string {
  return word
    .split("")
    .map((ch) => (ch in ARABIC_TRANSLITERATION ? ARABIC_TRANSLITERATION[ch] : ""))
    .join("");
}

function generateUsername(fullName: string): string {
  // شيل الألقاب الشائعة (مذكر ومؤنث: "د."، "دكتور"، "دكتورة"، "الدكتور"، "الدكتورة")
  // عشان اليوزرنيم يتبني على الاسم الفعلي مش على اللقب.
  const withoutTitle = fullName
    .trim()
    .replace(/^(د\.?|الدكتورة|الدكتور|دكتورة|دكتور)\s+/u, "");
  const firstWord = withoutTitle.split(/\s+/)[0]?.replace(/[^ء-يa-zA-Z0-9]/g, "") || "";

  let base: string;
  if (/[a-zA-Z]/.test(firstWord)) {
    base = firstWord.toLowerCase();
  } else if (firstWord) {
    base = transliterateArabic(firstWord) || "dr";
  } else {
    base = "dr";
  }

  return `dr.${base}${Math.floor(100 + Math.random() * 900)}`;
}

function generatePassword(): string {
  const chars = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789";
  let out = "";
  for (let i = 0; i < 10; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}

// بيرجع بيانات الدخول الجديدة عشان تتعرض للأدمن مرة واحدة بس وقت الإنشاء
// (زي أي نظام - كلمة السر مش بتتخزن نص صريح، فلازم تتعرض دلوقتي أو متتعرفش تاني).
export async function addDoctorAction(
  _prevState: { username?: string; password?: string; error?: string } | null,
  formData: FormData
): Promise<{ username?: string; password?: string; error?: string }> {
  const session = await getSession();
  if (!session || session.role !== "admin") return { error: "unauthorized" };

  const full_name = String(formData.get("full_name") || "").trim();
  if (!full_name) return { error: "missing" };

  const doctorResult = await db.insertInto("doctors").values({ full_name }).executeTakeFirst();
  const doctorId = Number(doctorResult.insertId);

  const username = generateUsername(full_name);
  const password = generatePassword();
  const password_hash = await hashPassword(password);

  await db
    .insertInto("users")
    .values({ username, password_hash, full_name, role: "doctor", doctor_id: doctorId })
    .execute();

  revalidatePath("/settings");
  return { username, password };
}

// --- إعدادات المستخدمين (موظفين غير الأطباء) -------------------------------

const EMPLOYEE_ROLES = ["reception", "accountant", "clinic_manager"] as const;

export async function addEmployeeAction(
  _prevState: { username?: string; password?: string; error?: string } | null,
  formData: FormData
): Promise<{ username?: string; password?: string; error?: string }> {
  const session = await getSession();
  if (!session || session.role !== "admin") return { error: "unauthorized" };

  const full_name = String(formData.get("full_name") || "").trim();
  const role = String(formData.get("role") || "");
  if (!full_name || !EMPLOYEE_ROLES.includes(role as (typeof EMPLOYEE_ROLES)[number])) {
    return { error: "missing" };
  }

  const username = generateUsername(full_name);
  const password = generatePassword();
  const password_hash = await hashPassword(password);

  await db
    .insertInto("users")
    .values({ username, password_hash, full_name, role: role as (typeof EMPLOYEE_ROLES)[number], doctor_id: null })
    .execute();

  revalidatePath("/settings");
  return { username, password };
}

// حذف "منطقي" (active=0) مش حذف فعلي، عشان الصفوف القديمة (زيارات، سجل تعديلات..)
// اللي بتشاور على المستخدم ده متتكسرش. بيتفلتر تلقائيًا من كل الاستعلامات الحالية
// اللي بتحدد where active = 1.
export async function deleteUserAction(formData: FormData) {
  const session = await getSession();
  if (!session || session.role !== "admin") return;

  const id = Number(formData.get("id"));
  if (!id || id === session.userId) return; // ما ينفعش المستخدم يحذف نفسه

  const target = await db.selectFrom("users").select(["role"]).where("id", "=", id).executeTakeFirst();
  if (!target || target.role === "admin") return; // حماية حسابات الأدمن من الحذف عن طريق الواجهة

  await db.updateTable("users").set({ active: 0 }).where("id", "=", id).execute();
  revalidatePath("/settings");
}

export async function changePasswordAction(formData: FormData) {
  const session = await getSession();
  if (!session) {
    redirect("/login");
  }

  const currentPassword = String(formData.get("current_password") || "");
  const newPassword = String(formData.get("new_password") || "");
  const confirmPassword = String(formData.get("confirm_password") || "");

  if (!currentPassword || !newPassword || !confirmPassword) {
    redirect("/settings?pwerror=missing");
  }
  if (newPassword.length < 6) {
    redirect("/settings?pwerror=short");
  }
  if (newPassword !== confirmPassword) {
    redirect("/settings?pwerror=mismatch");
  }

  const user = await db
    .selectFrom("users")
    .selectAll()
    .where("id", "=", session.userId)
    .executeTakeFirst();

  if (!user || !(await verifyPassword(currentPassword, user.password_hash))) {
    redirect("/settings?pwerror=wrong");
  }

  const newHash = await hashPassword(newPassword);
  await db.updateTable("users").set({ password_hash: newHash }).where("id", "=", session.userId).execute();

  redirect("/settings?pwsuccess=1");
}
