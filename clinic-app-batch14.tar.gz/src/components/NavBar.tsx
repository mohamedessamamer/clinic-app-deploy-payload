import Link from "next/link";
import { ROLE_LABELS, type SessionPayload } from "@/lib/auth";
import LogoutButton from "./LogoutButton";

const LINKS: { href: string; label: string; roles?: SessionPayload["role"][] }[] = [
  { href: "/", label: "الرئيسية" },
  { href: "/patients", label: "المرضى" },
  { href: "/front-desk", label: "جدول الاستقبال", roles: ["admin", "reception"] },
  { href: "/invoices", label: "الفواتير", roles: ["admin", "reception", "accountant"] },
  { href: "/inventory", label: "المخزون", roles: ["admin", "reception"] },
  { href: "/settings", label: "الإعدادات", roles: ["admin"] },
];

export default function NavBar({ session }: { session: SessionPayload }) {
  const visibleLinks = LINKS.filter((l) => !l.roles || l.roles.includes(session.role));

  return (
    <header className="border-b border-border bg-surface">
      <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between gap-4">
        <div className="flex items-center gap-6">
          <span className="font-bold text-primary text-lg shrink-0">عيادتي</span>
          <nav className="flex items-center gap-1">
            {visibleLinks.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className="px-3 py-1.5 rounded-md text-sm text-foreground hover:bg-primary-soft hover:text-primary-dark transition-colors"
              >
                {l.label}
              </Link>
            ))}
          </nav>
        </div>
        <div className="flex items-center gap-3 text-sm text-muted shrink-0">
          <span>
            {session.fullName} · {ROLE_LABELS[session.role]}
          </span>
          <LogoutButton />
        </div>
      </div>
    </header>
  );
}
