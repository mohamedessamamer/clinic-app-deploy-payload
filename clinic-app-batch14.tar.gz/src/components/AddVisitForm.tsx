"use client";

import { useMemo, useState } from "react";
import { addVisitAction } from "@/app/patients/[id]/actions";
import ServiceCombobox from "@/components/ServiceCombobox";

type Service = { id: number; name: string; code?: string | null; default_price?: number | null };
type Doctor = { id: number; full_name: string };

export default function AddVisitForm({
  patientId,
  services,
  doctors,
  serviceDoctorMap,
  currentDoctorId = null,
  canOverrideDoctor = false,
}: {
  patientId: number;
  services: Service[];
  doctors: Doctor[];
  serviceDoctorMap: Record<number, number[]>;
  // لو المستخدم الحالي دكتور (داخل بأكونته هو)، بيبقى هو الطبيب الأساسي (اللي
  // بيتحسب له ماليًا) أوتوماتيك من غير ما يحتاج يختار نفسه من قايمة أصلًا.
  currentDoctorId?: number | null;
  // صلاحية "اختيار مقدم خدمة مختلف" — بتفتح حقل تاني اختياري لتحديد مين اللي نفّذ
  // الخدمة فعليًا لو مختلف عن الطبيب الأساسي (زي دكتور مساعد)، من غير ما ده يأثر
  // على مين بيتحسب له التحصيل المالي (ده بيفضل الطبيب الأساسي/صاحب الشيفت دايمًا).
  canOverrideDoctor?: boolean;
}) {
  const today = useMemo(() => new Date().toISOString().slice(0, 10), []);
  const [serviceId, setServiceId] = useState<string>("");

  const filteredDoctors = useMemo(() => {
    if (!serviceId) return doctors;
    const allowed = serviceDoctorMap[Number(serviceId)] || [];
    return doctors.filter((d) => allowed.includes(d.id));
  }, [serviceId, doctors, serviceDoctorMap]);

  const isDoctorAccount = currentDoctorId != null;

  return (
    <form action={addVisitAction} className="grid grid-cols-1 sm:grid-cols-5 gap-2 items-end">
      <input type="hidden" name="patient_id" value={patientId} />
      <div className="sm:col-span-1">
        <label className="block text-xs text-muted mb-1">التاريخ</label>
        <input
          type="date"
          name="visit_date"
          defaultValue={today}
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>
      <div className="sm:col-span-1">
        <label className="block text-xs text-muted mb-1">نوع الخدمة</label>
        {/* Combobox بدل select عادي: بيفتح كقايمة كاملة لو اتدوس عليه من غير كتابة،
            وبيدور بالاسم أو بالكود مع كل حرف/رقم بيتكتب — أسرع من السكرول في قايمة طويلة. */}
        <ServiceCombobox name="service_id" services={services} value={serviceId} onChange={setServiceId} />
      </div>
      <div className={isDoctorAccount && !canOverrideDoctor ? "sm:col-span-3" : "sm:col-span-2"}>
        <label className="block text-xs text-muted mb-1">المعالجة</label>
        {/* textarea مش input عشان Enter يعمل سطر جديد بس (زي أي محرر نصوص عادي)
            بدل ما يبعت الفورم على طول — الإرسال بقى بس من زرار "إضافة زيارة". */}
        <textarea
          name="notes"
          placeholder="تفاصيل اللي تم عمله..."
          rows={1}
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary resize-y"
        />
      </div>

      {/* دكتور حساب: اسمه بيتحدد أوتوماتيك (هو صاحب الشيفت/التحصيل المالي) من غير
          أي اختيار — إلا لو معاه صلاحية "مقدم خدمة مختلف" بيظهر له حقل اختياري تاني. */}
      {isDoctorAccount ? (
        <>
          <input type="hidden" name="doctor_id" value={currentDoctorId ?? ""} />
          {canOverrideDoctor && (
            <div className="sm:col-span-1">
              <label className="block text-xs text-muted mb-1">مقدم الخدمة الفعلي (لو مختلف)</label>
              <select
                name="performing_doctor_id"
                defaultValue=""
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="">نفس الطبيب الأساسي (أنا)</option>
                {filteredDoctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.full_name}
                  </option>
                ))}
              </select>
            </div>
          )}
        </>
      ) : (
        <>
          <div className="sm:col-span-1">
            <label className="block text-xs text-muted mb-1">الدكتور</label>
            <select
              name="doctor_id"
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="">اختر دكتور</option>
              {filteredDoctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.full_name}
                </option>
              ))}
            </select>
          </div>
          {canOverrideDoctor && (
            <div className="sm:col-span-1">
              <label className="block text-xs text-muted mb-1">مقدم الخدمة الفعلي (لو مختلف)</label>
              <select
                name="performing_doctor_id"
                defaultValue=""
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="">نفس الدكتور المختار فوق</option>
                {filteredDoctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.full_name}
                  </option>
                ))}
              </select>
            </div>
          )}
        </>
      )}

      <div className="sm:col-span-5">
        <button
          type="submit"
          className="rounded-md bg-primary text-white px-4 py-1.5 text-sm font-medium hover:bg-primary-dark transition-colors"
        >
          + إضافة زيارة
        </button>
      </div>
    </form>
  );
}
