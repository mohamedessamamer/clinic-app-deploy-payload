import Link from "next/link";
import { redirect } from "next/navigation";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { ROLE_LABELS } from "@/lib/auth";

const STATUS_LABELS: Record<string, string> = {
  booked: "محجوز",
  attended: "حضر",
  done: "تم",
  cancelled: "ملغي",
  no_show: "لم يحضر",
};

async function DoctorHome({ doctorId }: { doctorId: number }) {
  const today = new Date().toISOString().slice(0, 10);

  const queue = await db
    .selectFrom("appointments")
    .innerJoin("patients", "patients.id", "appointments.patient_id")
    .leftJoin("rooms", "rooms.id", "appointments.room_id")
    .select([
      "appointments.id",
      "appointments.patient_id",
      "appointments.start_time",
      "appointments.status",
      "appointments.notes",
      "patients.full_name as patient_name",
      "patients.file_number as file_number",
      "rooms.name as room_name",
    ])
    .where("appointments.doctor_id", "=", doctorId)
    .where("appointments.appointment_date", "=", today)
    .orderBy("appointments.start_time")
    .execute();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold">مواعيدك النهاردة</h1>
        <p className="text-muted text-sm mt-1">مواعيدك بالترتيب اللي حجزها الاستقبال.</p>
      </div>

      <div className="bg-surface border border-border rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-primary-soft text-primary-dark">
            <tr>
              <th className="text-right px-3 py-2 font-medium">الوقت</th>
              <th className="text-right px-3 py-2 font-medium">المريض</th>
              <th className="text-right px-3 py-2 font-medium">الغرفة</th>
              <th className="text-right px-3 py-2 font-medium">ملاحظات</th>
              <th className="text-right px-3 py-2 font-medium">الحالة</th>
              <th className="px-3 py-2"></th>
            </tr>
          </thead>
          <tbody>
            {queue.map((a) => (
              <tr key={a.id} className="border-t border-border">
                <td className="px-3 py-2 font-semibold whitespace-nowrap">{a.start_time}</td>
                <td className="px-3 py-2">
                  <Link
                    href={`/patients/${a.patient_id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-medium text-primary hover:underline"
                  >
                    {a.patient_name} <span className="text-muted text-xs">({a.file_number})</span>
                  </Link>
                </td>
                <td className="px-3 py-2">{a.room_name ?? "-"}</td>
                <td className="px-3 py-2 text-muted">{a.notes ?? "-"}</td>
                <td className="px-3 py-2">{STATUS_LABELS[a.status] ?? a.status}</td>
                <td className="px-3 py-2 text-left">
                  <Link
                    href={`/patients/${a.patient_id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs px-2 py-1 rounded-md border border-border hover:bg-primary-soft"
                  >
                    فتح الملف
                  </Link>
                </td>
              </tr>
            ))}
            {queue.length === 0 && (
              <tr>
                <td colSpan={6} className="px-3 py-6 text-center text-muted">
                  مفيش مواعيد محجوزة لك النهاردة.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

async function getStats() {
  const [{ count: patients } = { count: 0 }] = await db
    .selectFrom("patients")
    .select((eb) => eb.fn.countAll<number>().as("count"))
    .execute();

  const [{ count: todayAppointments } = { count: 0 }] = await db
    .selectFrom("appointments")
    .select((eb) => eb.fn.countAll<number>().as("count"))
    .where("appointment_date", "=", new Date().toISOString().slice(0, 10))
    .execute();

  const [{ count: todayVisits } = { count: 0 }] = await db
    .selectFrom("visits")
    .select((eb) => eb.fn.countAll<number>().as("count"))
    .where("visit_date", "=", new Date().toISOString().slice(0, 10))
    .execute();

  return { patients, todayAppointments, todayVisits };
}

export default async function HomePage() {
  const session = await getSession();

  if (session?.role === "doctor" && session.doctorId) {
    return <DoctorHome doctorId={session.doctorId} />;
  }

  // الاستقبال: صفحته الرئيسية هي الجدول المركزي مباشرة (مفيش داعي لصفحة إحصائيات
  // وسيطة قبله)، بدل ما يضطر يدوس "جدول الاستقبال" من القايمة كل مرة يسجل دخول.
  if (session?.role === "reception") {
    redirect("/front-desk");
  }

  const stats = await getStats();

  const cards = [
    { label: "إجمالي المرضى", value: stats.patients, href: "/patients" },
    { label: "مواعيد اليوم", value: stats.todayAppointments, href: "/appointments" },
    { label: "زيارات اليوم", value: stats.todayVisits, href: "/patients" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold">لوحة التحكم</h1>
        <p className="text-muted text-sm mt-1">
          نظرة سريعة على العيادة اليوم — {ROLE_LABELS[session!.role]}
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {cards.map((c) => (
          <Link
            key={c.label}
            href={c.href}
            className="bg-surface border border-border rounded-xl p-5 hover:border-primary transition-colors"
          >
            <div className="text-3xl font-bold text-primary">{c.value}</div>
            <div className="text-sm text-muted mt-1">{c.label}</div>
          </Link>
        ))}
      </div>

      <div className="bg-surface border border-border rounded-xl p-5">
        <h2 className="font-semibold mb-3">روابط سريعة</h2>
        <div className="flex flex-wrap gap-2">
          <Link href="/patients/new" className="px-3 py-2 rounded-md bg-primary text-white text-sm hover:bg-primary-dark">
            + مريض جديد
          </Link>
          <Link href="/front-desk" className="px-3 py-2 rounded-md border border-border text-sm hover:bg-primary-soft">
            جدول الاستقبال
          </Link>
          <Link href="/appointments" className="px-3 py-2 rounded-md border border-border text-sm hover:bg-primary-soft">
            حجز موعد
          </Link>
          <Link href="/invoices" className="px-3 py-2 rounded-md border border-border text-sm hover:bg-primary-soft">
            الفواتير
          </Link>
        </div>
      </div>
    </div>
  );
}
