import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  experimental: {
    serverActions: {
      // الافتراضي 1MB بس — قليل جدًا لصور مرضى/أشعة حقيقية (ممكن توصل لعدة
      // ميجابايت، خصوصًا لو الأدمن رفع أكتر من صورة مرة واحدة). لو الحد ده
      // فضل صغير، أي رفع صورة بجودة حقيقية كان هيفشل بصمت أو برسالة خطأ
      // غريبة، وده كان ممكن يخلي حد "يظن" إن النظام بيقلل جودة الصور وهو
      // في الحقيقة بيرفض الرفع من الأساس. الـ nginx على السيرفر مضبوط
      // بالفعل على client_max_body_size 20M، فبنخلي الحد هنا قريب منه.
      bodySizeLimit: "19mb",
    },
    // Next.js بيعمل buffer لجسم الطلب كمان في طبقة الـ proxy (src/proxy.ts، اللي
    // بيتشغل على كل الصفحات تقريبًا بما فيها رفع الصور) وله حد افتراضي منفصل
    // 10MB — لازم يتزود هو كمان، وإلا رفع صورة أكبر من 10MB كان هيتقطع في نص
    // الطريق ("Unexpected end of form") حتى لو serverActions.bodySizeLimit
    // مرفوع. اتأكد من الاتنين مع بعض عمليًا وقت الفحص المحلي.
    proxyClientMaxBodySize: "19mb",
  },
};

export default nextConfig;
