export const COUNTRY_CALLING_CODES = [
  { code: "+20", label: "🇪🇬 EG +20" },
  { code: "+966", label: "🇸🇦 SA +966" },
  { code: "+971", label: "🇦🇪 AE +971" },
  { code: "+965", label: "🇰🇼 KW +965" },
  { code: "+974", label: "🇶🇦 QA +974" },
  { code: "+973", label: "🇧🇭 BH +973" },
  { code: "+968", label: "🇴🇲 OM +968" },
  { code: "+962", label: "🇯🇴 JO +962" },
  { code: "+961", label: "🇱🇧 LB +961" },
  { code: "+964", label: "🇮🇶 IQ +964" },
  { code: "+218", label: "🇱🇾 LY +218" },
  { code: "+212", label: "🇲🇦 MA +212" },
  { code: "+216", label: "🇹🇳 TN +216" },
  { code: "+213", label: "🇩🇿 DZ +213" },
  { code: "+90", label: "🇹🇷 TR +90" },
  { code: "+44", label: "🇬🇧 GB +44" },
  { code: "+1", label: "🇺🇸 US +1" },
] as const;

export function normalizePhoneNumber(value: string): string {
  return value.replace(/\D/g, "");
}

export function formatPatientPhone(countryCode: string | null | undefined, phone: string | null | undefined): string | null {
  const digits = normalizePhoneNumber(phone ?? "");
  if (!digits) return null;
  return `${countryCode || "+20"} ${digits}`;
}

export function isValidCountryCallingCode(value: string): boolean {
  return /^\+\d{1,4}$/.test(value);
}

export function isValidPatientPhone(countryCode: string, phone: string): boolean {
  if (!isValidCountryCallingCode(countryCode)) return false;
  const digits = normalizePhoneNumber(phone);
  // الرقم المصري يُكتب محليًا كما يكتبه الاستقبال، بالصفر في البداية: 01xxxxxxxxx.
  if (countryCode === "+20") return /^01\d{9}$/.test(digits);
  // لا نفرض صيغة دولة بعينها على المرضى غير المصريين، لكن نقبل أرقامًا عملية
  // من 10 إلى 15 رقمًا مع الاحتفاظ بالصفر المحلي إن كتبه الموظف.
  return /^\d{10,15}$/.test(digits);
}

export function patientPhoneValidationMessage(countryCode: string, language: "ar" | "en" = "ar"): string {
  if (countryCode === "+20") {
    return language === "en"
      ? "Egyptian mobile numbers must be 11 digits and start with 01."
      : "رقم الموبايل المصري لازم يكون 11 رقم ويبدأ بـ 01.";
  }
  return language === "en"
    ? "Phone numbers for other countries must contain 10 to 15 digits."
    : "رقم الهاتف للدول الأخرى لازم يكون من 10 إلى 15 رقمًا.";
}
