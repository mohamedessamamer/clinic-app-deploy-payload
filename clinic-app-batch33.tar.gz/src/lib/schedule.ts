import "server-only";
import { db } from "./db/client";
import { weekdayOf } from "./settings";

// الغرف/العيادات اللي لدكتور معيّن شيفت فيها في يوم معيّن. الشيفت الاستثنائي
// يأخذ الأولوية على الأسبوعي: يظهر للطبيب الذي أُسنِد له الاستثناء جدول الغرفة
// كاملًا، ولا يظهر للطبيب الأسبوعي الأصلي في نفس الغرفة ذلك اليوم.
export async function getDoctorRoomIdsForDate(doctorId: number, date: string): Promise<number[]> {
  const weekday = weekdayOf(date);
  const [weeklyRows, exceptionalRows] = await Promise.all([
    db
      .selectFrom("doctor_weekly_shifts")
      .select("room_id")
      .where("doctor_id", "=", doctorId)
      .where("weekday", "=", weekday)
      .execute(),
    db
      .selectFrom("doctor_date_shifts")
      .select(["room_id", "doctor_id"])
      .where("shift_date", "=", date)
      .execute(),
  ]);

  const exceptionalDoctorByRoom = new Map(exceptionalRows.map((row) => [row.room_id, row.doctor_id]));
  const weeklyRoomsNotReassigned = weeklyRows
    .map((row) => row.room_id)
    .filter((roomId) => {
      const exceptionalDoctorId = exceptionalDoctorByRoom.get(roomId);
      return exceptionalDoctorId == null || exceptionalDoctorId === doctorId;
    });
  const exceptionalRoomsForDoctor = exceptionalRows.filter((row) => row.doctor_id === doctorId).map((row) => row.room_id);

  return [...new Set([...weeklyRoomsNotReassigned, ...exceptionalRoomsForDoctor])];
}
