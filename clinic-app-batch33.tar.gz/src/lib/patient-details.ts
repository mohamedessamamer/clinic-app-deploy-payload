export type PatientBasicDetails = {
  full_name?: string | null;
  birth_date?: string | null;
  phone?: string | null;
};

export type PatientMissingField = "full_name" | "birth_date" | "phone";

export const PATIENT_MISSING_FIELD_LABELS: Record<PatientMissingField, string> = {
  full_name: "الاسم الثلاثي",
  birth_date: "تاريخ الميلاد",
  phone: "رقم التليفون",
};

export const PATIENT_MISSING_FIELD_LABELS_EN: Record<PatientMissingField, string> = {
  full_name: "full name (3 parts)",
  birth_date: "date of birth",
  phone: "phone number",
};

export function isThreePartName(name: string | null | undefined): boolean {
  return (name ?? "").trim().split(/\s+/).filter(Boolean).length >= 3;
}

export function isValidBirthDate(value: string | null | undefined): boolean {
  if (!value) return false;
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return false;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  return year >= 1900 && year <= 2100 && month >= 1 && month <= 12 && day >= 1 && day <= 31 && new Date(year, month - 1, day).getMonth() === month - 1;
}

export function missingPatientDetails(patient: PatientBasicDetails): PatientMissingField[] {
  const missing: PatientMissingField[] = [];
  if (!isThreePartName(patient.full_name)) missing.push("full_name");
  if (!isValidBirthDate(patient.birth_date)) missing.push("birth_date");
  if (!(patient.phone ?? "").trim()) missing.push("phone");
  return missing;
}

export function patientDetailsAreComplete(patient: PatientBasicDetails): boolean {
  return missingPatientDetails(patient).length === 0;
}
