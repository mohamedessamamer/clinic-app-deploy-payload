import "server-only";

import { db } from "@/lib/db/client";

// الرصيد المدفوع مقدمًا يستهلك من أقدم رصيد متاح أولًا، ولا ينشئ فاتورة أو
// زيارة جديدة. يستدعى فقط بعد إنشاء فاتورة خدمة عادية.
export async function applyAvailableCredits(patientId: number, invoiceId: number) {
  const invoice = await db
    .selectFrom("invoices")
    .select(["amount", "paid"])
    .where("id", "=", invoiceId)
    .executeTakeFirst();
  if (!invoice) return;

  let remaining = Math.max(0, invoice.amount - invoice.paid);
  if (remaining <= 0) return;

  const credits = await db
    .selectFrom("patient_credits")
    .select(["id", "available_amount"])
    .where("patient_id", "=", patientId)
    .where("status", "=", "active")
    .where("available_amount", ">", 0)
    .orderBy("received_at")
    .execute();

  let applied = 0;
  for (const credit of credits) {
    if (remaining <= 0) break;
    const used = Math.min(remaining, credit.available_amount);
    const availableAmount = credit.available_amount - used;
    await db
      .updateTable("patient_credits")
      .set({ available_amount: availableAmount, status: availableAmount <= 0.01 ? "used" : "active" })
      .where("id", "=", credit.id)
      .execute();
    applied += used;
    remaining -= used;
  }

  if (applied > 0) {
    await db.updateTable("invoices").set({ paid: invoice.paid + applied }).where("id", "=", invoiceId).execute();
  }
}
