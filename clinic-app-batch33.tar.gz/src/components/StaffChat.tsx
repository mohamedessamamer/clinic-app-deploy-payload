"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { getChatDoctorsAction, getStaffChatAction, sendStaffChatAction } from "@/app/chat/actions";

type Message = { id: number; body: string; created_at: string; sender_user_id: number; sender_name: string; recipient_user_id: number | null; audience: "reception" | "doctor" | "all_doctors" };
type Doctor = { id: number; full_name: string };

export default function StaffChat({ currentUserId, role }: { currentUserId: number; role: string }) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [open, setOpen] = useState(false);
  const [popup, setPopup] = useState(false);
  const [draft, setDraft] = useState("");
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [recipient, setRecipient] = useState("");
  const [broadcast, setBroadcast] = useState(false);
  const [busy, startTransition] = useTransition();
  const initialized = useRef(false);
  const lastSeenId = useRef(0);
  const listRef = useRef<HTMLDivElement>(null);
  const isDoctor = role === "doctor";
  const isReceptionSide = ["reception", "admin", "clinic_manager"].includes(role);

  async function refreshMessages() {
    const rows = await getStaffChatAction();
    const newest = rows.at(-1);
    if (initialized.current && newest && newest.id > lastSeenId.current && newest.sender_user_id !== currentUserId) setPopup(true);
    if (newest) lastSeenId.current = newest.id;
    initialized.current = true;
    setMessages(rows);
  }

  useEffect(() => {
    refreshMessages().catch(() => undefined);
    const timer = window.setInterval(() => refreshMessages().catch(() => undefined), 2000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    if (open && isReceptionSide && !doctors.length) getChatDoctorsAction().then(setDoctors).catch(() => undefined);
  }, [open, isReceptionSide, doctors.length]);

  useEffect(() => {
    if (open) listRef.current?.scrollTo({ top: listRef.current.scrollHeight });
  }, [open, messages]);

  function showChat() {
    setOpen(true);
    setPopup(false);
  }

  function send() {
    startTransition(async () => {
      const form = new FormData();
      form.set("body", draft);
      if (broadcast) form.set("broadcast", "1");
      if (recipient) form.set("recipient_user_id", recipient);
      const result = await sendStaffChatAction(form);
      if (!result.ok) return window.alert(result.reason || "تعذر إرسال الرسالة.");
      setDraft("");
      await refreshMessages();
    });
  }

  return (
    <>
      <button type="button" onClick={showChat} className="relative h-9 w-9 rounded-full border border-border bg-background hover:bg-primary-soft text-base" title="الشات الداخلي" aria-label="الشات الداخلي">▣</button>
      {popup && !open && (
        <button type="button" onClick={showChat} className="fixed z-50 top-20 left-5 w-72 rounded-xl bg-primary text-white shadow-xl p-3 text-right text-sm">
          رسالة جديدة في الشات — اضغط لفتحها
        </button>
      )}
      {open && (
        <section className="fixed z-50 top-20 left-4 w-[min(25rem,calc(100vw-2rem))] h-[min(34rem,calc(100vh-6rem))] card-3d rounded-xl shadow-2xl flex flex-col overflow-hidden" dir="rtl">
          <header className="flex items-center justify-between px-3 py-2 border-b border-border bg-primary-soft">
            <div><strong>شات العيادة</strong><span className="text-xs text-muted mr-2">الرسائل تُحفظ 48 ساعة</span></div>
            <button type="button" onClick={() => setOpen(false)} className="text-lg leading-none" aria-label="إغلاق">×</button>
          </header>
          <div ref={listRef} className="flex-1 overflow-y-auto p-3 space-y-2 bg-background">
            {!messages.length && <p className="text-sm text-muted text-center py-8">ابدأ رسالة للاستقبال أو للأطباء.</p>}
            {messages.map((message) => {
              const mine = message.sender_user_id === currentUserId;
              return (
                <div key={message.id} className={`max-w-[85%] rounded-xl px-3 py-2 text-sm ${mine ? "bg-primary text-white mr-auto" : "bg-surface border border-border ml-auto"}`}>
                  <div className={`text-[10px] mb-1 ${mine ? "text-white/80" : "text-muted"}`}>{mine ? "أنت" : message.sender_name}{message.audience === "all_doctors" ? " — لكل الأطباء" : ""}</div>
                  <p className="whitespace-pre-wrap">{message.body}</p>
                </div>
              );
            })}
          </div>
          <div className="border-t border-border p-2 space-y-2">
            {isReceptionSide && (
              <div className="flex gap-2 text-xs">
                <select value={recipient} disabled={broadcast} onChange={(event) => setRecipient(event.target.value)} className="min-w-0 flex-1 rounded border border-border bg-background px-2 py-1.5">
                  <option value="">اختر طبيبًا للرد المباشر</option>
                  {doctors.map((doctor) => <option key={doctor.id} value={doctor.id}>{doctor.full_name}</option>)}
                </select>
                <label className="flex items-center gap-1 whitespace-nowrap"><input type="checkbox" checked={broadcast} onChange={(event) => setBroadcast(event.target.checked)} /> كل الأطباء</label>
              </div>
            )}
            {isDoctor && <p className="text-[11px] text-muted">رسالتك ستصل إلى الاستقبال.</p>}
            <div className="flex gap-2">
              <textarea value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => { if (event.key === "Escape") setOpen(false); if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); send(); } }} rows={2} placeholder="اكتب رسالة…" className="min-w-0 flex-1 rounded border border-border bg-background px-2 py-1.5 text-sm" />
              <button type="button" disabled={busy || !draft.trim()} onClick={send} className="rounded btn-3d-primary px-3 text-sm">إرسال</button>
            </div>
          </div>
        </section>
      )}
    </>
  );
}
