"use client";

import { useState } from "react";

// دفعة 22 (متابعة): تاريخ الميلاد لازم يتعرض ويتكتب بصيغة dd/mm/yyyy ثابتة —
// جربنا الأول <input type="date" lang="en-GB"> بس ده اتأكد إنه بيفشل فعليًا:
// شكل الـ input الأصلي (mm/dd/yyyy ولا dd/mm/yyyy) في Chrome بيتحدد حسب إعدادات
// نظام التشغيل مش خاصية lang في الـ HTML، وده مش موثوق فيه (ظهر على السيرفر
// الحي بصيغة mm/dd/yyyy رغم lang="en-GB"). فبدل ما نتعلق بسلوك المتصفح/النظام،
// بنعمل حقل نصي بصيغة ثابتة بنفسنا ونحوله لـ ISO (yyyy-mm-dd — الصيغة اللي
// قاعدة البيانات ودالة حساب السن ageFromBirthDate محتاجينها) قبل ما يتبعت.
export default function BirthDateInput({
  name,
  defaultValue, // ISO yyyy-mm-dd أو null/undefined
  required = false,
  language = "ar",
  inputClassName = "px-2 py-1.5 text-sm",
}: {
  name: string;
  defaultValue?: string | null;
  required?: boolean;
  language?: "en" | "ar";
  // مساحة الحقل (padding/text size) بتختلف شوية بين الأماكن المستخدمة فيها
  // (فورم مريض جديد أكبر شوية من فورم التعديل السريع جوه الملف) — اختياري.
  inputClassName?: string;
}) {
  const toDisplay = (iso: string | null | undefined) => {
    if (!iso) return "";
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
    if (!m) return "";
    return `${m[3]}/${m[2]}/${m[1]}`;
  };

  const [display, setDisplay] = useState(toDisplay(defaultValue));
  const [iso, setIso] = useState(defaultValue ?? "");
  const [error, setError] = useState(false);

  function handleChange(raw: string) {
    // مسموح بس بأرقام، وبنحط "/" تلقائي بعد اليوم والشهر — المستخدم يكتب أرقام
    // بس من غير ما يحتاج يدوس على "/" بنفسه.
    const digits = raw.replace(/[^\d]/g, "").slice(0, 8);
    let formatted = digits;
    if (digits.length > 4) formatted = `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4)}`;
    else if (digits.length > 2) formatted = `${digits.slice(0, 2)}/${digits.slice(2)}`;
    setDisplay(formatted);

    if (digits.length === 8) {
      const day = Number(digits.slice(0, 2));
      const month = Number(digits.slice(2, 4));
      const year = Number(digits.slice(4, 8));
      const valid =
        year >= 1900 &&
        year <= 2100 &&
        month >= 1 &&
        month <= 12 &&
        day >= 1 &&
        day <= 31 &&
        // تأكيد إضافي إن اليوم فعلاً موجود في الشهر ده (يمنع مثلاً 31/02)
        new Date(year, month - 1, day).getMonth() === month - 1;
      if (valid) {
        setIso(`${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`);
        setError(false);
        return;
      }
      setError(true);
      setIso("");
      return;
    }

    setError(false);
    setIso("");
  }

  return (
    <div>
      <input type="hidden" name={name} value={iso} />
      <input
        type="text"
        inputMode="numeric"
        placeholder="dd/mm/yyyy"
        value={display}
        onChange={(e) => handleChange(e.target.value)}
        maxLength={10}
        required={required}
        dir="ltr"
        className={`w-full rounded-md border ${
          error ? "border-danger" : "border-border"
        } bg-background ${inputClassName} focus:outline-none focus:ring-2 focus:ring-primary`}
      />
      {error && <p className="text-xs text-danger mt-1">{language === "en" ? "Invalid date — use dd/mm/yyyy" : "تاريخ غير صحيح — الصيغة dd/mm/yyyy"}</p>}
    </div>
  );
}
