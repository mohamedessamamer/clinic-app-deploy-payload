"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { recordAdvancePaymentAction } from "@/app/appointments/billing-actions";
import { PAYMENT_METHODS } from "@/lib/payment-methods";

export default function AdvancePaymentForm({ patientId }: { patientId: number }) {
  const router = useRouter();
  const [amount, setAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("cash");
  const [note, setNote] = useState("");
  const [pending, startTransition] = useTransition();

  function submit() {
    if (!(Number(amount) > 0)) return;
    const formData = new FormData();
    formData.set("patient_id", String(patientId));
    formData.set("amount", amount);
    formData.set("payment_method", paymentMethod);
    formData.set("note", note);
    startTransition(async () => {
      await recordAdvancePaymentAction(formData);
      setAmount("");
      setNote("");
      router.refresh();
    });
  }

  return (
    <section className="card-3d rounded-xl p-4 space-y-3">
      <div>
        <h2 className="font-semibold text-sm">دفعة مقدمة</h2>
        <p className="text-xs text-muted mt-1">تُحفظ كرصيد للمريض من غير تسجيل زيارة أو خدمة، وتُخصم تلقائيًا عند التحصيل.</p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
        <input
          type="number"
          min={0}
          step="0.01"
          value={amount}
          onChange={(event) => setAmount(event.target.value)}
          placeholder="المبلغ"
          className="rounded-md border border-border bg-background px-2 py-1.5 text-sm"
        />
        <select value={paymentMethod} onChange={(event) => setPaymentMethod(event.target.value)} className="rounded-md border border-border bg-background px-2 py-1.5 text-sm">
          {PAYMENT_METHODS.map((method) => <option key={method.value} value={method.value}>{method.label}</option>)}
        </select>
        <button type="button" onClick={submit} disabled={pending || !(Number(amount) > 0)} className="rounded-md btn-3d-primary px-3 py-1.5 text-sm disabled:opacity-50">
          تسجيل الرصيد
        </button>
      </div>
      <input value={note} onChange={(event) => setNote(event.target.value)} placeholder="ملاحظة اختيارية" className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
    </section>
  );
}
