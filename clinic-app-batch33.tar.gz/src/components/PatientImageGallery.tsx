"use client";

import { useCallback, useEffect, useState, useTransition } from "react";
import { deleteImageAction } from "@/app/patients/[id]/actions";

type GroupImage = { id: number; file_path: string };
type ImageGroup = {
  id: number;
  label: string | null;
  taken_at: string;
  images: GroupImage[];
};

type FlatImage = { id: number; file_path: string; label: string | null; taken_at: string };

function extensionOf(filePath: string): string {
  const match = /\.[a-zA-Z0-9]+$/.exec(filePath);
  return match ? match[0] : "";
}

export default function PatientImageGallery({ groups, patientId, language = "en" }: { groups: ImageGroup[]; patientId: number; language?: "en" | "ar" }) {
  // ليستة مسطحة بكل صور المريض بنفس ترتيب العرض، عشان أسهم اليمين/الشمال في الـ
  // lightbox تتنقل على كل الصور مش بس صور المجموعة الحالية.
  const flatImages: FlatImage[] = groups.flatMap((g) =>
    g.images.map((img) => ({ id: img.id, file_path: img.file_path, label: g.label, taken_at: g.taken_at }))
  );

  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [, startTransition] = useTransition();
  const en = language === "en";

  const close = useCallback(() => setOpenIndex(null), []);
  const prev = useCallback(() => {
    setOpenIndex((i) => (i === null || flatImages.length === 0 ? i : (i - 1 + flatImages.length) % flatImages.length));
  }, [flatImages.length]);
  const next = useCallback(() => {
    setOpenIndex((i) => (i === null || flatImages.length === 0 ? i : (i + 1) % flatImages.length));
  }, [flatImages.length]);

  useEffect(() => {
    if (openIndex === null) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") close();
      else if (e.key === "ArrowLeft") prev();
      else if (e.key === "ArrowRight") next();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [openIndex, close, prev, next]);

  function handleDelete(imageId: number, e: React.MouseEvent) {
    e.stopPropagation();
    const ok = window.confirm(en ? "Delete this photo permanently? This cannot be undone." : "متأكد إنك عايز تمسح الصورة دي؟ الإجراء ده مش ممكن يترجع.");
    if (!ok) return;
    const formData = new FormData();
    formData.set("image_id", String(imageId));
    formData.set("patient_id", String(patientId));
    startTransition(() => {
      deleteImageAction(formData);
    });
  }

  if (flatImages.length === 0) {
    return <p className="text-sm text-muted">{en ? "No photos or X-rays have been uploaded for this patient yet." : "لا يوجد صور أو أشعة مرفوعة لهذا المريض بعد."}</p>;
  }

  // مجموعة من غير صور خالص (اتمسحت كل صورها مثلاً) ملهاش أي داعي تتعرض —
  // بنعرض بس المجموعات اللي فيها صور فعلية، مفيش مربعات فاضية "لا صور".
  const nonEmptyGroups = groups.filter((g) => g.images.length > 0);

  let cursor = 0;

  return (
    <>
      <div className="flex gap-4 overflow-x-auto pb-2">
        {nonEmptyGroups.map((g) => {
          const startIndex = cursor;
          cursor += g.images.length;
          const shown = g.images.slice(0, 4);
          return (
            <div key={g.id} className="shrink-0 w-64 border border-border rounded-lg p-2 bg-background">
              <div className="grid grid-cols-2 gap-1.5">
                {shown.map((img, i) => {
                  // آخر صورة في عدد فردي (1 أو 3) بتاخد عرض الصفين مع بعض بدل ما
                  // تسيب نص الخانة اللي جنبها فاضي بصريًا.
                  const spansFull = shown.length % 2 === 1 && i === shown.length - 1;
                  return (
                    <div key={img.id} className={`relative ${spansFull ? "col-span-2" : ""}`}>
                      <button type="button" onClick={() => setOpenIndex(startIndex + i)} className="block w-full">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src={img.file_path}
                          alt={g.label || (en ? "Photo" : "صورة")}
                          className="w-full h-28 object-cover rounded hover:opacity-80 transition-opacity cursor-zoom-in"
                        />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => handleDelete(img.id, e)}
                        className="absolute top-1 right-1 w-5 h-5 rounded-full bg-black/60 hover:bg-red-600 text-white text-xs leading-none flex items-center justify-center"
                        title={en ? "Delete photo" : "حذف الصورة"}
                        aria-label={en ? "Delete photo" : "حذف الصورة"}
                      >
                        ×
                      </button>
                    </div>
                  );
                })}
              </div>
              <div className="text-xs text-muted mt-1">{g.taken_at}</div>
              {g.label && <div className="text-xs">{g.label}</div>}
            </div>
          );
        })}
      </div>

      {openIndex !== null && (
        <div
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          onClick={close}
        >
          {flatImages.length > 1 && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                prev();
              }}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-white/80 hover:text-white text-4xl px-3 py-2 select-none"
              aria-label="السابقة"
            >
              ‹
            </button>
          )}

          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={flatImages[openIndex].file_path}
            alt={flatImages[openIndex].label || (en ? "Photo" : "صورة")}
            className="max-w-[90vw] max-h-[85vh] object-contain rounded shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          />

          {flatImages.length > 1 && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                next();
              }}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-white/80 hover:text-white text-4xl px-3 py-2 select-none"
              aria-label="التالية"
            >
              ›
            </button>
          )}

          <a
            href={flatImages[openIndex].file_path}
            download={`${flatImages[openIndex].taken_at}-${openIndex + 1}${extensionOf(flatImages[openIndex].file_path)}`}
            onClick={(e) => e.stopPropagation()}
            className="absolute top-4 right-4 text-white/90 hover:text-white text-sm bg-black/40 hover:bg-black/60 rounded-md px-3 py-1.5 transition-colors"
          >
            {en ? "⬇ Download" : "⬇ تحميل"}
          </a>

          <div className="absolute bottom-4 inset-x-0 text-center text-white/70 text-xs">
            {openIndex + 1} / {flatImages.length}
            {flatImages[openIndex].taken_at ? ` · ${flatImages[openIndex].taken_at}` : ""}
          </div>
        </div>
      )}
    </>
  );
}
