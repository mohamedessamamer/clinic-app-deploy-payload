"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { deletePatientAction } from "@/app/patients/actions";

// زرار حذف حالة (مريض) نهائيًا — للأدمن بس (الصفحات اللي بتستخدمه أصلاً بتتأكد
// إن المستخدم أدمن قبل ما تعرضه، والأكشن نفسه بيتأكد تاني من الدور في السيرفر).
// بيمسح المريض وكل بياناته المرتبطة (زيارات/فواتير/مواعيد/صور) نهائيًا من غير رجعة —
// مصمم أساسًا لتنظيف حالات تجربة (test) اتعملت أثناء تجربة النظام.
export default function DeletePatientButton({
  patientId,
  patientName,
  className,
  redirectTo,
}: {
  patientId: number;
  patientName: string;
  className?: string;
  // لو الزرار ده في صفحة الملف الطبي بتاعة المريض نفسه، لازم نوديه لمكان تاني بعد
  // الحذف (الصفحة دي مش هتبقى موجودة أصلاً بعد الحذف) — من صفحة قايمة المرضى نفسها
  // مالوش داعي (البيانات بتتحدّث في مكانها).
  redirectTo?: string;
}) {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();

  function handleDelete() {
    const ok = window.confirm(
      `متأكد إنك عايز تمسح حالة "${patientName}" نهائيًا؟ ده هيمسح كل زياراته وفواتيره ومواعيده وصوره كمان — الإجراء ده مش ممكن يترجع.`
    );
    if (!ok) return;
    const formData = new FormData();
    formData.set("patient_id", String(patientId));
    startTransition(async () => {
      const result = await deletePatientAction(formData);
      if (!result.ok) {
        window.alert(result.reason ?? "لم يكتمل حذف المريض.");
        return;
      }
      if (redirectTo) router.push(redirectTo);
    });
  }

  return (
    <button
      type="button"
      onClick={handleDelete}
      disabled={isPending}
      className={className ?? "text-xs text-danger hover:underline disabled:opacity-60"}
    >
      {isPending ? "جاري الحذف..." : "حذف الحالة"}
    </button>
  );
}
