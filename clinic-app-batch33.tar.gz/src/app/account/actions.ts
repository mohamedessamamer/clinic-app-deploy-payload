"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";

export async function setMedicalUiLanguageAction(language: "en" | "ar") {
  const session = await getSession();
  if (!session || (language !== "en" && language !== "ar")) return;

  await db.updateTable("users").set({ medical_ui_language: language }).where("id", "=", session.userId).execute();
  revalidatePath("/", "layout");
  revalidatePath("/patients");
}
