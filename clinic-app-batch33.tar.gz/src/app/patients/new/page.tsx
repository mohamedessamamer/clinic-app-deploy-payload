import { createPatientAction } from "./actions";
import BirthDateInput from "@/components/BirthDateInput";
import CountryPhoneInput from "@/components/CountryPhoneInput";

export default async function NewPatientPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error } = await searchParams;

  return (
    <div className="max-w-lg mx-auto space-y-5">
      <h1 className="text-xl font-bold">مريض جديد</h1>

      {error && (
        <div className="rounded-md bg-danger-soft text-danger text-sm px-3 py-2">
          {error === "name"
            ? "من فضلك اكتب اسم المريض ثلاثيًا على الأقل."
            : error === "birth_date"
              ? "من فضلك أدخل تاريخ ميلاد صحيح."
              : "اكتب رقم موبايل صحيح: المصري 11 رقم ويبدأ بـ 01، والدول الأخرى من 10 إلى 15 رقمًا."}
        </div>
      )}

      <form action={createPatientAction} className="card-3d rounded-xl p-5 space-y-4">
        <div>
          <label className="block text-sm text-muted mb-1">الاسم الثلاثي *</label>
          <input
            name="full_name"
            required
            className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-4">
          <div className="sm:col-span-2">
            <label className="block text-sm text-muted mb-1">تاريخ الميلاد *</label>
            <BirthDateInput name="birth_date" required inputClassName="px-3 py-2 text-sm" />
            <p className="text-xs text-muted mt-1">السن بيتحسب منه تلقائي بالسنين. اكتب الأرقام بس (يوم/شهر/سنة) — الـ &quot;/&quot; بتتحط لوحدها.</p>
          </div>
          <div className="sm:col-span-3">
            <label className="block text-sm text-muted mb-1">رقم الموبايل *</label>
            <CountryPhoneInput required />
            <p className="text-xs text-muted mt-1">مصر افتراضيًا +20 — اكتب الرقم محليًا بالصفر، مثال: 01227166444.</p>
          </div>
        </div>
        <div>
          <label className="block text-sm text-muted mb-1">العنوان</label>
          <input
            name="address"
            className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
        <button
          type="submit"
          className="w-full rounded-md btn-3d-primary py-2 text-sm font-medium transition-colors"
        >
          حفظ
        </button>
      </form>
    </div>
  );
}
