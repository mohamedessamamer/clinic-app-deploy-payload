import type { Metadata } from "next";
import "./globals.css";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import NavBar from "@/components/NavBar";
import { db } from "@/lib/db/client";
import { getNotificationCenter } from "@/lib/notifications";

export const metadata: Metadata = {
  title: "نظام إدارة العيادة",
  description: "نظام إدارة عيادة بسيط وسريع",
};

export default async function RootLayout({ children }: LayoutProps<"/">) {
  const session = await getSession();
  // ظهور لينك "التقارير" مبني على صلاحية فعلية (reports_full/reports_own) مش
  // على الدور الثابت زي باقي اللينكات — عشان الصلاحيتين دول قابلين للمنح/السحب
  // لأي مستخدم لوحده من الإعدادات، مش مرتبطين بدور واحد بس.
  const canViewReports = session
    ? (await hasPermission(session.userId, session.role, "reports_full")) ||
      (await hasPermission(session.userId, session.role, "reports_own"))
    : false;
  // نفس الفكرة للينك "المخزن" — مبني على صلاحية manage_inventory القابلة للمنح،
  // مش على دور ثابت (كان قبل كده hardcoded لأدمن/استقبال بس، من غير أي تحقق
  // حقيقي في الصفحة نفسها).
  const canViewInventory = session ? await hasPermission(session.userId, session.role, "manage_inventory") : false;
  const [medicalLanguageValue, initialNotifications] = session
    ? await Promise.all([
        db.selectFrom("users").select("medical_ui_language").where("id", "=", session.userId).executeTakeFirst().then((row) => row?.medical_ui_language ?? "en"),
        getNotificationCenter(session.userId),
      ])
    : ["en", [] as Awaited<ReturnType<typeof getNotificationCenter>>];
  const medicalUiLanguage: "en" | "ar" = medicalLanguageValue === "ar" ? "ar" : "en";

  return (
    <html lang="ar" dir="rtl" className="h-full antialiased">
      <body className="min-h-full flex flex-col font-sans">
        {session && <NavBar session={session} canViewReports={canViewReports} canViewInventory={canViewInventory} medicalUiLanguage={medicalUiLanguage} initialNotifications={initialNotifications} />}
        <main className="flex-1 w-full max-w-6xl mx-auto px-4 py-6">{children}</main>
      </body>
    </html>
  );
}
