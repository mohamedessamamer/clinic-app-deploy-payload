"use server";

import { revalidatePath } from "next/cache";
import { sql } from "kysely";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { getNotificationCenter } from "@/lib/notifications";

export async function getNotificationCenterAction() {
  const session = await getSession();
  if (!session) return [];
  return getNotificationCenter(session.userId);
}

export async function markNotificationsReadAction() {
  const session = await getSession();
  if (!session) return;
  await db
    .updateTable("notifications")
    .set({ read_at: sql<string>`datetime('now')` })
    .where("recipient_user_id", "=", session.userId)
    .where("read_at", "is", null)
    .where(sql<boolean>`expires_at > datetime('now')`)
    .execute();
}

export async function updateFollowupCaseAction(formData: FormData): Promise<{ ok: boolean; reason?: string }> {
  const session = await getSession();
  if (!session || !["reception", "admin", "clinic_manager"].includes(session.role)) return { ok: false, reason: "هذه العملية متاحة للاستقبال أو المدير فقط." };

  const caseId = Number(formData.get("case_id"));
  const status = String(formData.get("status") || "") as "resolved" | "snoozed";
  const reason = String(formData.get("reason") || "").trim();
  const nextReview = String(formData.get("next_review_date") || "").trim() || null;
  if (!caseId || !["resolved", "snoozed"].includes(status) || !reason) return { ok: false, reason: "اختر الإجراء واكتب السبب." };
  if (status === "snoozed" && !nextReview) return { ok: false, reason: "أدخل تاريخ مراجعة جديدًا للمريض المسافر أو المؤجل." };

  await db
    .updateTable("notification_cases")
    .set({
      status,
      reason,
      next_review_date: nextReview,
      resolved_by: status === "resolved" ? session.userId : null,
      resolved_at: status === "resolved" ? sql<string>`datetime('now')` : null,
      updated_at: sql<string>`datetime('now')`,
    })
    .where("id", "=", caseId)
    .execute();
  revalidatePath("/");
  revalidatePath("/front-desk");
  return { ok: true };
}
