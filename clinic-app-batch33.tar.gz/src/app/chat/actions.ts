"use server";

import { sql } from "kysely";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";

type ChatMessage = { id: number; body: string; created_at: string; sender_user_id: number; sender_name: string; recipient_user_id: number | null; audience: "reception" | "doctor" | "all_doctors" };

async function cleanExpiredMessages() {
  // مدة الاحتفاظ 48 ساعة حسب طلب المستخدم. التنظيف يحصل مع استعمال الشات؛
  // لا نحتاج خدمة خارجية أو WebSocket لتنفيذه.
  await db.deleteFrom("chat_messages").where(sql<boolean>`created_at <= datetime('now', '-48 hours')`).execute();
}

export async function getStaffChatAction(): Promise<ChatMessage[]> {
  const session = await getSession();
  if (!session) return [];
  await cleanExpiredMessages();
  let query = db
    .selectFrom("chat_messages")
    .innerJoin("users as senders", "senders.id", "chat_messages.sender_user_id")
    .select([
      "chat_messages.id",
      "chat_messages.body",
      "chat_messages.created_at",
      "chat_messages.sender_user_id",
      "senders.full_name as sender_name",
      "chat_messages.recipient_user_id",
      "chat_messages.audience",
    ])
    .orderBy("chat_messages.id", "asc")
    .limit(250);

  if (session.role === "reception" || session.role === "admin" || session.role === "clinic_manager") {
    return query.execute();
  }
  // الطبيب يرى رسائله إلى الاستقبال، رد الاستقبال المباشر له، وأي رسالة لكل الأطباء.
  return query.where((eb) =>
    eb.or([
      eb("chat_messages.sender_user_id", "=", session.userId),
      eb("chat_messages.recipient_user_id", "=", session.userId),
      eb("chat_messages.audience", "=", "all_doctors"),
    ])
  ).execute();
}

export async function getChatDoctorsAction() {
  const session = await getSession();
  if (!session || !["reception", "admin", "clinic_manager"].includes(session.role)) return [];
  return db
    .selectFrom("users")
    .innerJoin("doctors", "doctors.id", "users.doctor_id")
    .select(["users.id", "users.full_name"])
    .where("users.active", "=", 1)
    .where("doctors.active", "=", 1)
    .orderBy("users.full_name")
    .execute();
}

export async function sendStaffChatAction(formData: FormData): Promise<{ ok: boolean; reason?: string }> {
  const session = await getSession();
  if (!session) return { ok: false, reason: "سجل الدخول أولًا." };
  const body = String(formData.get("body") || "").trim().slice(0, 2000);
  if (!body) return { ok: false, reason: "اكتب رسالة أولًا." };

  const broadcast = formData.get("broadcast") === "1";
  const recipientUserId = Number(formData.get("recipient_user_id")) || null;
  let audience: "reception" | "doctor" | "all_doctors" = "reception";
  let recipient_user_id: number | null = null;

  if (session.role === "doctor") {
    // رسالة الطبيب الافتراضية تذهب للاستقبال؛ لا يسمح له بإرسالها كإعلان للأطباء.
    audience = "reception";
  } else if (broadcast) {
    audience = "all_doctors";
  } else if (recipientUserId) {
    const recipient = await db.selectFrom("users").select(["id", "role", "active"]).where("id", "=", recipientUserId).executeTakeFirst();
    if (!recipient || !recipient.active || recipient.role !== "doctor") return { ok: false, reason: "اختر طبيبًا نشطًا." };
    audience = "doctor";
    recipient_user_id = recipient.id;
  } else {
    return { ok: false, reason: "اختر طبيبًا أو أرسل الرسالة لكل الأطباء." };
  }

  await cleanExpiredMessages();
  await db.insertInto("chat_messages").values({ sender_user_id: session.userId, recipient_user_id, audience, body }).execute();
  return { ok: true };
}
