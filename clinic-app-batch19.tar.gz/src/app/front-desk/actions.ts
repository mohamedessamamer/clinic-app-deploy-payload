"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { logOverride } from "@/lib/audit";

export async function addServiceEntryAction(formData: FormData) {
  const patient_id = Number(formData.get("patient_id"));
  const visit_date = String(formData.get("visit_date") || "");
  const service_id = formData.get("service_id") ? Number(formData.get("service_id")) : null;
  const price = Number(formData.get("price") || 0);
  const discount_percent = Math.min(100, Math.max(0, Number(formData.get("discount_percent") || 0)));
  const doctor_id = formData.get("doctor_id") ? Number(formData.get("doctor_id")) : null;
  const room_id = formData.get("room_id") ? Number(formData.get("room_id")) : null;
  const defaultDoctorId = formData.get("default_doctor_id") ? Number(formData.get("default_doctor_id")) : null;
  const appointmentIdRaw = formData.get("appointment_id");
  const appointment_id = appointmentIdRaw ? Number(appointmentIdRaw) : null;

  if (!patient_id || !visit_date || !doctor_id) return;

  const session = await getSession();

  // لو الخدمة دي جايه من موعد "تم" لسه محتاج تحصيل (شارة "محتاج تحصيل" في الجدول
  // المركزي — دكتور حدد "تم" من غير صلاحية تحصيل فسجّل بس "المطلوب دفعه")، نربط
  // الزيارة دي بالموعد (appointment_id) ونمسح بيانات "المطلوب دفعه" منه. من غير
  // الربط ده، الموعد كان بيفضل شايل شارة "محتاج تحصيل" للأبد (مفيش زيارة مرتبطة
  // بيه)، فلو حد بعدين عمل "تسجيل التحصيل" عليه من الجدول، الخدمة كانت بتتسجل تاني
  // — تسجيل مزدوج لنفس الحالة. نتأكد الموعد لسه فعلاً لنفس المريض و"تم" ومفيهوش
  // زيارة مرتبطة بيه أصلاً قبل الربط، عشان أي تعارض توقيت نادر (اتحصل من مكان تاني
  // في نفس اللحظة) ميعملش ربط غلط.
  let linkedAppointmentId: number | null = null;
  if (appointment_id) {
    const appt = await db
      .selectFrom("appointments")
      .select(["id", "patient_id", "status"])
      .where("id", "=", appointment_id)
      .executeTakeFirst();
    const alreadyBilled = appt
      ? await db.selectFrom("visits").select("id").where("appointment_id", "=", appointment_id).executeTakeFirst()
      : undefined;
    if (appt && appt.patient_id === patient_id && appt.status === "done" && !alreadyBilled) {
      linkedAppointmentId = appointment_id;
    }
  }

  const visitResult = await db
    .insertInto("visits")
    .values({
      patient_id,
      visit_date,
      service_id,
      notes: null,
      primary_doctor_id: doctor_id,
      performing_doctor_id: doctor_id,
      room_id,
      created_by: session?.userId ?? null,
      appointment_id: linkedAppointmentId,
    })
    .executeTakeFirst();
  const visitId = Number(visitResult.insertId);

  const amount = Math.max(0, price * (1 - discount_percent / 100));

  let service: { name: string; default_price: number } | undefined;
  if (service_id) {
    service = await db
      .selectFrom("services")
      .select(["name", "default_price"])
      .where("id", "=", service_id)
      .executeTakeFirst();
  }
  const priceOverridden = !!service && Math.round(service.default_price) !== Math.round(price);

  const invoiceResult = await db
    .insertInto("invoices")
    .values({
      visit_id: visitId,
      amount,
      paid: 0,
      discount_percent,
      price_overridden: priceOverridden ? 1 : 0,
      original_price: price,
    })
    .executeTakeFirst();

  if (priceOverridden && service) {
    await logOverride({
      entityType: "invoice_price",
      entityId: Number(invoiceResult.insertId),
      field: "السعر",
      oldValue: service.default_price,
      newValue: price,
      changedBy: session?.userId ?? null,
      reason: `تعديل سعر خدمة "${service.name}"`,
    });
  }

  if (defaultDoctorId && doctor_id !== defaultDoctorId) {
    const [defaultDoctor, actualDoctor] = await Promise.all([
      db.selectFrom("doctors").select("full_name").where("id", "=", defaultDoctorId).executeTakeFirst(),
      db.selectFrom("doctors").select("full_name").where("id", "=", doctor_id).executeTakeFirst(),
    ]);
    await logOverride({
      entityType: "visit_doctor",
      entityId: visitId,
      field: "الدكتور",
      oldValue: defaultDoctor?.full_name ?? String(defaultDoctorId),
      newValue: actualDoctor?.full_name ?? String(doctor_id),
      changedBy: session?.userId ?? null,
      reason: "تسجيل خدمة لدكتور غير صاحب الشيفت",
    });
  }

  if (linkedAppointmentId) {
    await db
      .updateTable("appointments")
      .set({ pending_service_id: null, pending_price: null, pending_discount_percent: null })
      .where("id", "=", linkedAppointmentId)
      .execute();
  }

  revalidatePath("/front-desk");
  revalidatePath("/invoices");
  revalidatePath("/");
}
