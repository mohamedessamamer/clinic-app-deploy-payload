"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";

export async function addAppointmentAction(formData: FormData) {
  const patient_id = Number(formData.get("patient_id"));
  const room_id = Number(formData.get("room_id"));
  const doctor_id = Number(formData.get("doctor_id"));
  const appointment_date = String(formData.get("appointment_date") || "");
  const start_time = String(formData.get("start_time") || "");
  const notes = String(formData.get("notes") || "").trim() || null;
  // بيوصل من الجدول المركزي كعدد دقايق (مضاعفات وحدة الزمن)؛ لو مبعوتش أو صفر
  // بيتعامل معاه كموعد بطول خانة واحدة بس (نفس السلوك القديم قبل ما الحقل ده يتضاف).
  const durationRaw = formData.get("duration_minutes");
  const duration_minutes = durationRaw ? Number(durationRaw) || null : null;

  if (!patient_id || !room_id || !doctor_id || !appointment_date || !start_time) return;

  await db
    .insertInto("appointments")
    .values({ patient_id, room_id, doctor_id, appointment_date, start_time, duration_minutes, notes })
    .execute();
  revalidatePath("/front-desk");
  revalidatePath("/");
}

// موعد "تم" نهائي — مايترجعش لحالة تانية خالص (اتفقنا على كده من دفعة 8). الجدول
// المركزي (CentralSchedule.tsx) أصلاً مايعرضش أي خيار تراجع لموعد "تم" في الواجهة،
// لكن ده كان بس قيد في الواجهة — السيرفر هنا كان بيقبل أي تغيير حالة من غير أي
// تحقق، وده اللي خلى صفحة "المواعيد والشيفتات" القديمة (كان فيها StatusSelect حر
// بيقدر يرجّع أي موعد "تم" لـ"محجوز"/"ملغي" بسهولة) تكسر الاتفاق ده فعليًا — الصفحة
// دي اتشالت بالكامل (كانت مكررة مع الجدول المركزي بالكامل)، وهنا كمان بقى فيه تحقق
// في السيرفر نفسه بغض النظر عن مين بيستدعي الأكشن.
export async function updateAppointmentStatusAction(formData: FormData) {
  const id = Number(formData.get("id"));
  const status = String(formData.get("status") || "") as "booked" | "attended" | "done" | "cancelled" | "no_show";
  if (!id || !status) return;

  const current = await db.selectFrom("appointments").select("status").where("id", "=", id).executeTakeFirst();
  if (!current) return;
  if (current.status === "done") return;

  await db.updateTable("appointments").set({ status }).where("id", "=", id).execute();
  revalidatePath("/front-desk");
  revalidatePath("/");
}
