"use client";

import { useMemo, useState, type Ref } from "react";

type Patient = { id: number; full_name: string; file_number: string };

// مربع اختيار مريض ببحث فوري (substring في الاسم أو رقم الملف) بدل قايمة
// `<select>` طويلة — نفس الشكل والمنطق المستخدم في بوكس الحجز بالجدول المركزي
// (CentralSchedule.tsx)، اتنقل هنا كمكوّن مشترك عشان يتستخدم في أي مكان تاني
// محتاج نفس الفكرة (زي بوكس "إضافة خدمة" تحت الجدول في /front-desk).
export default function PatientSearchSelect({
  patients,
  name = "patient_id",
  value,
  onChange,
  placeholder = "اكتب اسم المريض أو رقم الملف...",
  required,
  inputRef,
}: {
  patients: Patient[];
  name?: string;
  value: string; // معرّف المريض المختار كنص، "" يعني مفيش اختيار
  onChange: (id: string) => void;
  placeholder?: string;
  required?: boolean;
  inputRef?: Ref<HTMLInputElement>;
}) {
  const [query, setQuery] = useState("");
  const selected = useMemo(() => patients.find((p) => String(p.id) === value) ?? null, [patients, value]);

  const results = useMemo(() => {
    const q = query.trim();
    if (!q) return [];
    return patients.filter((p) => p.full_name.includes(q) || p.file_number.includes(q)).slice(0, 8);
  }, [query, patients]);

  return (
    <div className="relative">
      <input type="hidden" name={name} value={value} required={required} />
      {selected ? (
        <div className="flex items-center justify-between gap-2 rounded-md border border-border bg-background px-2 py-1.5 text-sm">
          <span className="truncate">
            {selected.full_name} ({selected.file_number})
          </span>
          <button
            type="button"
            onClick={() => {
              onChange("");
              setQuery("");
            }}
            className="text-xs text-primary hover:underline shrink-0"
          >
            تغيير
          </button>
        </div>
      ) : (
        <>
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={placeholder}
            className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          />
          {results.length > 0 && (
            <div className="absolute z-10 mt-1 w-full card-3d rounded-md shadow-lg overflow-hidden max-h-48 overflow-y-auto">
              {results.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => {
                    onChange(String(p.id));
                    setQuery("");
                  }}
                  className="w-full text-right px-3 py-1.5 text-sm hover:bg-primary-soft flex items-center justify-between gap-2"
                >
                  <span>{p.full_name}</span>
                  <span className="text-xs text-muted shrink-0">{p.file_number}</span>
                </button>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
