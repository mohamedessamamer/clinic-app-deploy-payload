"use client";

import { useMemo } from "react";
import { addAppointmentAction } from "@/app/appointments/actions";

type Room = { id: number; name: string };
type Doctor = { id: number; full_name: string };

export default function NextAppointmentForm({
  patientId,
  rooms,
  doctors,
  timeSlots,
}: {
  patientId: number;
  rooms: Room[];
  doctors: Doctor[];
  timeSlots: string[];
}) {
  const today = useMemo(() => new Date().toISOString().slice(0, 10), []);

  return (
    <form action={addAppointmentAction} className="grid grid-cols-1 sm:grid-cols-6 gap-2 items-end">
      <input type="hidden" name="patient_id" value={patientId} />
      <div className="sm:col-span-1">
        <label className="block text-xs text-muted mb-1">التاريخ</label>
        <input
          type="date"
          name="appointment_date"
          defaultValue={today}
          min={today}
          required
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>
      <div className="sm:col-span-1">
        <label className="block text-xs text-muted mb-1">الوقت</label>
        <select
          name="start_time"
          required
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        >
          {timeSlots.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
      </div>
      <div className="sm:col-span-1">
        <label className="block text-xs text-muted mb-1">العيادة/الغرفة</label>
        <select
          name="room_id"
          required
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        >
          {rooms.map((r) => (
            <option key={r.id} value={r.id}>
              {r.name}
            </option>
          ))}
        </select>
      </div>
      <div className="sm:col-span-1">
        <label className="block text-xs text-muted mb-1">الدكتور</label>
        <select
          name="doctor_id"
          required
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        >
          {doctors.map((d) => (
            <option key={d.id} value={d.id}>
              {d.full_name}
            </option>
          ))}
        </select>
      </div>
      <div className="sm:col-span-1">
        <label className="block text-xs text-muted mb-1">ملاحظة (اختياري)</label>
        <input
          name="notes"
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>
      <div className="sm:col-span-1">
        <button
          type="submit"
          className="w-full rounded-md btn-3d-primary px-3 py-1.5 text-sm font-medium transition-colors"
        >
          + حجز الموعد
        </button>
      </div>
    </form>
  );
}
