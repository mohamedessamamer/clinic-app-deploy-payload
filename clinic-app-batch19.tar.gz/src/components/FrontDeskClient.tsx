"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { addServiceEntryAction } from "@/app/front-desk/actions";
import PatientSearchSelect from "@/components/PatientSearchSelect";

type Patient = { id: number; full_name: string; file_number: string };
type Service = { id: number; name: string; default_price: number };
type Doctor = { id: number; full_name: string };
type PendingBilling = {
  apptId: number;
  serviceId: number | null;
  price: number | null;
  discountPercent: number | null;
  doctorId: number | null;
};
type Row = {
  id: number;
  visit_id: number;
  patient_id: number;
  patient_name: string;
  visit_date: string;
  service_name: string | null;
  discount_percent: number;
  original_price: number | null;
  amount: number;
  doctor_name: string | null;
  price_overridden: number;
};

export default function FrontDeskClient({
  date,
  roomId,
  patients,
  services,
  doctors,
  defaultDoctorId,
  rows,
  pendingBillingByPatient = {},
}: {
  date: string;
  roomId: number | null;
  patients: Patient[];
  services: Service[];
  doctors: Doctor[];
  defaultDoctorId: number | null;
  rows: Row[];
  // خريطة مريض → موعد "تم" لسه محتاج تحصيل بتاعه النهاردة (من الجدول المركزي).
  // لو المريض المختار هنا عليه موعد زي ده، الخدمة هتتربط بيه تلقائيًا (appointment_id)
  // بدل ما تتسجل زيارة مستقلة، عشان شارة "محتاج تحصيل" تقفل صح ومايحصلش تسجيل مزدوج
  // (مرة من الموعد ومرة من هنا) — شوف addServiceEntryAction.
  pendingBillingByPatient?: Record<number, PendingBilling>;
}) {
  const [patientId, setPatientId] = useState<string>("");
  const [serviceId, setServiceId] = useState<string>("");
  const [price, setPrice] = useState<string>("0");
  const [discount, setDiscount] = useState<string>("0");
  const [doctorId, setDoctorId] = useState<string>(defaultDoctorId ? String(defaultDoctorId) : "");
  const formRef = useRef<HTMLFormElement>(null);
  const patientSearchInputRef = useRef<HTMLInputElement>(null);
  const prevPatientIdRef = useRef<string>("");

  const servicePriceMap = useMemo(() => Object.fromEntries(services.map((s) => [s.id, s.default_price])), [services]);

  const selectedPending = patientId ? pendingBillingByPatient[Number(patientId)] : undefined;

  // لما يتغيّر المريض المختار، لو عليه موعد "محتاج تحصيل"، نعبّي الخدمة/السعر/الخصم/
  // الدكتور من بيانات الموعد تلقائيًا (تعديلها بعد كده لسه ممكن عادي).
  useEffect(() => {
    if (patientId === prevPatientIdRef.current) return;
    prevPatientIdRef.current = patientId;
    const pending = patientId ? pendingBillingByPatient[Number(patientId)] : undefined;
    if (pending && pending.serviceId) {
      setServiceId(String(pending.serviceId));
      setPrice(pending.price != null ? String(pending.price) : String(servicePriceMap[pending.serviceId] ?? 0));
      setDiscount(pending.discountPercent != null ? String(pending.discountPercent) : "0");
      if (pending.doctorId) setDoctorId(String(pending.doctorId));
    }
  }, [patientId, pendingBillingByPatient, servicePriceMap]);

  function onServiceChange(id: string) {
    setServiceId(id);
    if (id && servicePriceMap[Number(id)] !== undefined) {
      setPrice(String(servicePriceMap[Number(id)]));
    }
  }

  function duplicateRow(row: Row) {
    setPatientId(String(row.patient_id));
    setServiceId("");
    setPrice("0");
    setDiscount("0");
    setDoctorId(defaultDoctorId ? String(defaultDoctorId) : "");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    const messages: string[] = [];
    const defaultPrice = serviceId ? servicePriceMap[Number(serviceId)] : undefined;
    if (defaultPrice !== undefined && Number(price) !== defaultPrice) {
      messages.push(`السعر اللي داخلاه (${price}) مختلف عن سعر القائمة (${defaultPrice}). هيتسجل في تقرير آخر اليوم.`);
    }
    if (defaultDoctorId && doctorId && Number(doctorId) !== defaultDoctorId) {
      const defDoc = doctors.find((d) => d.id === defaultDoctorId)?.full_name;
      const newDoc = doctors.find((d) => d.id === Number(doctorId))?.full_name;
      messages.push(`الخدمة دي هتتسجل للدكتور "${newDoc}" مش "${defDoc}" صاحب الشيفت. هيتسجل في تقرير آخر اليوم.`);
    }
    if (messages.length > 0) {
      const ok = window.confirm(messages.join("\n") + "\n\nتأكيد الحفظ؟");
      if (!ok) {
        e.preventDefault();
        return;
      }
    }
    // Reset local state right after a confirmed submit so the next entry starts clean.
    setTimeout(() => {
      setPatientId("");
      setServiceId("");
      setPrice("0");
      setDiscount("0");
      setDoctorId(defaultDoctorId ? String(defaultDoctorId) : "");
    }, 50);
  }

  return (
    <div className="space-y-5">
      <form ref={formRef} action={addServiceEntryAction} onSubmit={handleSubmit} className="card-3d rounded-xl p-5 space-y-3">
        <h2 className="font-semibold">إضافة خدمة</h2>
        <input type="hidden" name="visit_date" value={date} />
        <input type="hidden" name="room_id" value={roomId ?? ""} />
        <input type="hidden" name="default_doctor_id" value={defaultDoctorId ?? ""} />
        <input type="hidden" name="appointment_id" value={selectedPending?.apptId ?? ""} />

        {selectedPending && (
          <div className="text-xs bg-amber-50 text-amber-800 border border-amber-200 rounded-md px-3 py-2">
            للمريض ده موعد &quot;تم&quot; لسه محتاج تحصيل من الجدول — هيتربط بيه تلقائيًا وهتقفل شارة &quot;محتاج تحصيل&quot; بتاعته بعد الحفظ
            {selectedPending.serviceId ? "، وعبّينالك الخدمة والسعر من بيانات الموعد (تقدر تعدلهم لو حابب)." : "."}
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-6 gap-2 items-end">
          <div className="sm:col-span-2">
            <label className="block text-xs text-muted mb-1">المريض</label>
            <PatientSearchSelect
              patients={patients}
              value={patientId}
              onChange={setPatientId}
              required
              inputRef={patientSearchInputRef}
            />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">الخدمة</label>
            <select
              name="service_id"
              value={serviceId}
              onChange={(e) => onServiceChange(e.target.value)}
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="">اختر خدمة</option>
              {services.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.default_price})
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">السعر</label>
            <input
              name="price"
              type="number"
              step="0.01"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">الخصم %</label>
            <input
              name="discount_percent"
              type="number"
              min="0"
              max="100"
              value={discount}
              onChange={(e) => setDiscount(e.target.value)}
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">الدكتور</label>
            <select
              name="doctor_id"
              required
              value={doctorId}
              onChange={(e) => setDoctorId(e.target.value)}
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="">اختر دكتور</option>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.full_name}
                  {defaultDoctorId === d.id ? " (صاحب الشيفت)" : ""}
                </option>
              ))}
            </select>
          </div>
        </div>
        <button
          type="submit"
          className="rounded-md btn-3d-primary px-4 py-1.5 text-sm font-medium transition-colors"
        >
          + إضافة للسجل
        </button>
      </form>

      <div className="card-3d rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-primary-soft text-primary-dark">
            <tr>
              <th className="text-right px-3 py-2 font-medium">التاريخ</th>
              <th className="text-right px-3 py-2 font-medium">المريض</th>
              <th className="text-right px-3 py-2 font-medium">الخدمة</th>
              <th className="text-right px-3 py-2 font-medium">السعر الأصلي</th>
              <th className="text-right px-3 py-2 font-medium">الخصم</th>
              <th className="text-right px-3 py-2 font-medium">المبلغ</th>
              <th className="text-right px-3 py-2 font-medium">الدكتور</th>
              <th className="px-3 py-2"></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t border-border">
                <td className="px-3 py-2 text-muted whitespace-nowrap">{r.visit_date}</td>
                <td className="px-3 py-2">
                  <Link
                    href={`/patients/${r.patient_id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-medium hover:text-primary hover:underline"
                  >
                    {r.patient_name}
                  </Link>
                </td>
                <td className="px-3 py-2">{r.service_name ?? "-"}</td>
                <td className="px-3 py-2 text-muted">{r.original_price != null ? r.original_price.toFixed(0) : "-"}</td>
                <td className="px-3 py-2">{r.discount_percent ? `${r.discount_percent}%` : "-"}</td>
                <td className="px-3 py-2">
                  {r.amount.toFixed(0)}
                  {r.price_overridden === 1 && (
                    <span className="ms-1 text-xs bg-danger-soft text-danger rounded-full px-2 py-0.5">سعر معدّل</span>
                  )}
                </td>
                <td className="px-3 py-2">{r.doctor_name ?? "-"}</td>
                <td className="px-3 py-2">
                  <button
                    type="button"
                    onClick={() => duplicateRow(r)}
                    className="text-xs px-2 py-1 rounded-md border border-border hover:bg-primary-soft"
                  >
                    نسخ لنفس المريض
                  </button>
                </td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr>
                <td colSpan={8} className="px-3 py-6 text-center text-muted">
                  لسه مفيش خدمات متسجلة النهاردة.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
