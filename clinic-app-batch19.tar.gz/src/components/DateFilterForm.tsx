"use client";

// فورم فلتر التاريخ ("اليوم: ...") المستخدم في أعلى صفحات الجدول/الفواتير/المواعيد.
// بيبعت (submit) نفسه تلقائيًا بمجرد اختيار تاريخ من الكاليندر — من غير ما يحتاج
// المستخدم يدوس زرار "عرض" بعدها. الزرار فاضل موجود برضه كحماية إضافية (لو ال
// onChange لأي سبب ما اتفعّلش، أو لكتابة تاريخ يدويًا بدل الكاليندر).
export default function DateFilterForm({ day }: { day: string }) {
  return (
    <form className="flex items-center gap-2 flex-wrap">
      <label className="text-sm text-muted">اليوم:</label>
      <input
        type="date"
        name="date"
        defaultValue={day}
        onChange={(e) => e.currentTarget.form?.requestSubmit()}
        className="rounded-md border border-border bg-surface px-2 py-1.5 text-sm"
      />
      <button type="submit" className="px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft">
        عرض
      </button>
    </form>
  );
}
