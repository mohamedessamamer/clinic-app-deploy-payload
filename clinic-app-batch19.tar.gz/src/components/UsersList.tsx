"use client";

import { ROLE_LABELS, type Role } from "@/lib/auth";
import { deleteUserAction } from "@/app/settings/actions";

type UserRow = {
  id: number;
  username: string;
  full_name: string;
  role: Role;
};

export default function UsersList({ users, currentUserId }: { users: UserRow[]; currentUserId: number }) {
  return (
    <div className="space-y-2">
      {users.map((u) => (
        <div key={u.id} className="flex items-center justify-between gap-3 border border-border rounded-md px-3 py-2 text-sm">
          <div>
            <span className="font-medium">{u.full_name}</span>{" "}
            <span className="text-xs text-muted">
              @{u.username} · {ROLE_LABELS[u.role]}
            </span>
          </div>
          {u.role !== "admin" && u.id !== currentUserId && (
            <form
              action={deleteUserAction}
              onSubmit={(e) => {
                if (!window.confirm(`متأكد إنك عايز تحذف "${u.full_name}"؟`)) {
                  e.preventDefault();
                }
              }}
            >
              <input type="hidden" name="id" value={u.id} />
              <button type="submit" className="text-xs text-red-600 hover:underline">
                حذف
              </button>
            </form>
          )}
        </div>
      ))}
      {users.length === 0 && <p className="text-sm text-muted">مفيش مستخدمين مسجلين.</p>}
    </div>
  );
}
