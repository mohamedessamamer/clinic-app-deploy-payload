"use client";

import { useMemo, useRef, useState } from "react";
import { addImageGroupAction } from "@/app/patients/[id]/actions";

export default function AddImageGroupForm({ patientId }: { patientId: number }) {
  const today = useMemo(() => new Date().toISOString().slice(0, 10), []);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fileNames, setFileNames] = useState<string[]>([]);
  const [isDragging, setIsDragging] = useState(false);

  // بيحط الملفات (من الاختيار العادي أو السحب والإفلات) على الـ input نفسه
  // عشان تتبعت مع الفورم عادي (زي ما لو المستخدم اختارها بالضغط "Choose Files").
  function setFilesOnInput(files: FileList | File[]) {
    if (!fileInputRef.current) return;
    const dt = new DataTransfer();
    for (const f of Array.from(files)) dt.items.add(f);
    fileInputRef.current.files = dt.files;
    setFileNames(Array.from(dt.files).map((f) => f.name));
  }

  function handleDrop(e: React.DragEvent<HTMLDivElement>) {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files?.length) setFilesOnInput(e.dataTransfer.files);
  }

  return (
    <form
      action={addImageGroupAction}
      encType="multipart/form-data"
      onSubmit={() => {
        // نصفّر معاينة الأسماء بعد ما الفورم يتبعت (بعد الحدث ده الـ browser
        // يبقى لسه قاري input.files الحالية عشان يبعتها، فالتصفير هنا آمن).
        setTimeout(() => setFileNames([]), 0);
      }}
      className="flex flex-wrap items-end gap-2 border-t border-dashed border-border pt-3 mt-1"
    >
      <input type="hidden" name="patient_id" value={patientId} />
      <div>
        <label className="block text-xs text-muted mb-1">التاريخ</label>
        <input
          type="date"
          name="taken_at"
          defaultValue={today}
          className="rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">وصف (اختياري)</label>
        <input
          name="label"
          placeholder="مثال: أشعة بانوراما"
          className="rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>
      <div className="flex-1 min-w-[240px]">
        <label className="block text-xs text-muted mb-1">الصور/الأشعة</label>
        <div
          role="button"
          tabIndex={0}
          onClick={() => fileInputRef.current?.click()}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") fileInputRef.current?.click();
          }}
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={`rounded-md border-2 border-dashed px-3 py-2.5 text-xs text-center cursor-pointer transition-colors ${
            isDragging ? "border-primary bg-primary-soft" : "border-border hover:bg-primary-soft/40"
          }`}
        >
          {fileNames.length > 0 ? (
            <span className="text-primary-dark font-medium">
              {fileNames.length} صورة/ملف محدد — {fileNames.slice(0, 2).join("، ")}
              {fileNames.length > 2 ? "..." : ""}
            </span>
          ) : (
            <span className="text-muted">اسحب الصور هنا وأفلتها، أو دوس هنا للاختيار — تقدر تختار أو تسحب أكتر من صورة مرة واحدة</span>
          )}
          <input
            ref={fileInputRef}
            type="file"
            name="files"
            multiple
            accept="image/*,.pdf"
            onChange={(e) => setFileNames(Array.from(e.target.files || []).map((f) => f.name))}
            className="hidden"
          />
        </div>
      </div>
      <button
        type="submit"
        className="rounded-md btn-3d-primary px-4 py-1.5 text-sm font-medium transition-colors"
      >
        + إضافة مجموعة
      </button>
    </form>
  );
}
