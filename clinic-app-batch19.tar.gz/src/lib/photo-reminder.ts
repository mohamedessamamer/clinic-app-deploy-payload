import { db } from "@/lib/db/client";

// عدد الشهور اللي لو المريض (بيعمل متابعة) عدى عليها من غير صور/أشعة جديدة،
// بيظهر تنبيه "محتاج صور جديدة" — في الجدول المركزي (schedule badge) وفي ملفه
// الطبي. نفس الرقم مستخدم في الاتنين، فلو اتغيّر لازم يتغيّر في المكانين
// (src/app/patients/[id]/page.tsx فيه نسخة تانية للثابت ده لنفس السبب).
const PHOTO_REMINDER_MONTHS = 6;

// بيرجع Map من patient_id لـ true/false (محتاج صور جديدة ولا لأ) — لمجموعة
// مرضى دفعة واحدة (مثلاً كل مرضى مواعيد اليوم في الجدول المركزي)، بدل ما نعمل
// كويري لكل مريض لوحده (N+1).
export async function computeNeedsNewPhotosMap(patientIds: number[]): Promise<Map<number, boolean>> {
  const map = new Map<number, boolean>();
  const uniqueIds = [...new Set(patientIds)].filter((id) => Number.isFinite(id) && id > 0);
  if (uniqueIds.length === 0) return map;

  // مين من دول بيعمل متابعة أصلاً (خدمة كودها "0") — التنبيه مايهمش غير الحالة دي.
  const followupRows = await db
    .selectFrom("visits")
    .innerJoin("services", "services.id", "visits.service_id")
    .select("visits.patient_id")
    .where("services.code", "=", "0")
    .where("visits.patient_id", "in", uniqueIds)
    .distinct()
    .execute();
  const followupSet = new Set(followupRows.map((r) => r.patient_id));

  if (followupSet.size === 0) {
    for (const id of uniqueIds) map.set(id, false);
    return map;
  }

  const photoRows = await db
    .selectFrom("patient_image_groups")
    .select(["patient_id", (eb) => eb.fn.max<string>("taken_at").as("last_taken_at")])
    .where("patient_id", "in", uniqueIds)
    .groupBy("patient_id")
    .execute();
  const lastPhotoMap = new Map(photoRows.map((r) => [r.patient_id, r.last_taken_at]));

  const cutoff = new Date();
  cutoff.setMonth(cutoff.getMonth() - PHOTO_REMINDER_MONTHS);
  const cutoffStr = cutoff.toISOString().slice(0, 10);

  for (const id of uniqueIds) {
    if (!followupSet.has(id)) {
      map.set(id, false);
      continue;
    }
    const last = lastPhotoMap.get(id);
    map.set(id, !last || last < cutoffStr);
  }
  return map;
}
