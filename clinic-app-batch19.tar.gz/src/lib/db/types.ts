import type { ColumnType, Generated } from "kysely";

export interface DoctorsTable {
  id: Generated<number>;
  full_name: string;
  active: Generated<number>;
  created_at: Generated<string>;
}

export interface UsersTable {
  id: Generated<number>;
  username: string;
  password_hash: string;
  full_name: string;
  role: "admin" | "doctor" | "reception" | "accountant" | "clinic_manager";
  doctor_id: number | null;
  active: Generated<number>;
  created_at: Generated<string>;
}

export interface RoomsTable {
  id: Generated<number>;
  name: string;
  created_at: Generated<string>;
}

export interface ShiftsTable {
  id: Generated<number>;
  room_id: number;
  doctor_id: number;
  shift_date: string;
  start_time: string;
  end_time: string;
  created_at: Generated<string>;
}

export interface DoctorWeeklyShiftsTable {
  id: Generated<number>;
  room_id: number;
  weekday: number;
  doctor_id: number;
  start_time: string;
  end_time: string;
  created_at: Generated<string>;
}

export interface ServicesTable {
  id: Generated<number>;
  name: string;
  name_en: string | null;
  category: string | null;
  default_price: Generated<number>;
  code: string | null;
  price_note: string | null;
  prepaid: Generated<number>;
  created_at: Generated<string>;
}

export interface ServiceDoctorsTable {
  service_id: number;
  doctor_id: number;
}

export interface PatientsTable {
  id: Generated<number>;
  file_number: string;
  full_name: string;
  age: number | null; // قديم — للمرضى اللي اتسجلوا قبل ما نبدأ نطلب تاريخ الميلاد.
  birth_date: string | null; // YYYY-MM-DD — المصدر الحالي لحساب السن، شوف src/lib/age.ts.
  phone: string | null;
  address: string | null;
  created_at: Generated<string>;
}

export interface AppointmentsTable {
  id: Generated<number>;
  patient_id: number;
  room_id: number;
  doctor_id: number;
  appointment_date: string;
  start_time: string;
  duration_minutes: number | null;
  status: Generated<"booked" | "attended" | "done" | "cancelled" | "no_show">;
  notes: string | null;
  pending_service_id: number | null;
  pending_price: number | null;
  pending_discount_percent: number | null;
  created_at: Generated<string>;
}

export interface VisitsTable {
  id: Generated<number>;
  patient_id: number;
  visit_date: ColumnType<string, string | undefined, string>;
  service_id: number | null;
  notes: string | null;
  primary_doctor_id: number | null;
  performing_doctor_id: number | null;
  room_id: number | null;
  created_by: number | null;
  appointment_id: number | null;
  created_at: Generated<string>;
}

export interface InvoicesTable {
  id: Generated<number>;
  visit_id: number;
  amount: Generated<number>;
  paid: Generated<number>;
  discount_percent: Generated<number>;
  price_overridden: Generated<number>;
  payment_method: string | null;
  parent_invoice_id: number | null;
  original_price: number | null;
  created_at: Generated<string>;
}

export interface ClinicSettingsTable {
  key: string;
  value: string;
}

export interface AuditLogTable {
  id: Generated<number>;
  entity_type: string;
  entity_id: number;
  field: string;
  old_value: string | null;
  new_value: string | null;
  reason: string | null;
  changed_by: number | null;
  changed_at: Generated<string>;
}

export interface PatientImageGroupsTable {
  id: Generated<number>;
  patient_id: number;
  label: string | null;
  taken_at: Generated<string>;
  created_at: Generated<string>;
}

export interface PatientImagesTable {
  id: Generated<number>;
  group_id: number;
  file_path: string;
  created_at: Generated<string>;
}

export interface InventoryItemsTable {
  id: Generated<number>;
  name: string;
  quantity: Generated<number>;
  unit: string | null;
  expiry_date: string | null;
  low_stock_threshold: Generated<number>;
  created_at: Generated<string>;
}

export interface UserPermissionsTable {
  user_id: number;
  permission_key: string;
  granted: number;
}

export interface Database {
  doctors: DoctorsTable;
  users: UsersTable;
  user_permissions: UserPermissionsTable;
  rooms: RoomsTable;
  shifts: ShiftsTable;
  doctor_weekly_shifts: DoctorWeeklyShiftsTable;
  services: ServicesTable;
  service_doctors: ServiceDoctorsTable;
  patients: PatientsTable;
  appointments: AppointmentsTable;
  visits: VisitsTable;
  invoices: InvoicesTable;
  patient_image_groups: PatientImageGroupsTable;
  patient_images: PatientImagesTable;
  inventory_items: InventoryItemsTable;
  clinic_settings: ClinicSettingsTable;
  audit_log: AuditLogTable;
}
