import type { Role } from "./auth";

// ثوابت الصلاحيات فقط — من غير أي استيراد لطبقة قاعدة البيانات، عشان يصلح
// للاستخدام في مكونات العميل (client components) زي PermissionsManager كمان.
// الدوال اللي بتلمس قاعدة البيانات (getPermissionOverrides..) موجودة في lib/permissions.ts.
export const PERMISSION_DEFS = [
  { key: "reports_full", label: "عرض كل التقارير (كل الأطباء وكل الفترات)" },
  { key: "reports_own", label: "عرض تقريره الشخصي بس (للدكتور) — بحد أقصى شهرين، إلا لو معاه صلاحية كل التقارير" },
  { key: "collect_payments", label: "تحصيل المدفوعات من الاستقبال" },
  { key: "manage_inventory", label: "إدارة المخزن" },
  {
    key: "view_patient_billing",
    label: "عرض الملف المالي للمريض — افتراضيًا مش متاح للدكتور، لازم تُمنح له لوحده لو محتاجها",
  },
  { key: "manage_expenses", label: "إدارة المصروفات والمرتبات" },
  { key: "manage_settings", label: "الوصول لصفحة الإعدادات" },
  { key: "schedule_all_rooms", label: "عرض الجدول المركزي لكل الغرف/العيادات (مش بس شيفته هو)" },
  { key: "schedule_edit", label: "التعديل في الجدول المركزي (حجز مواعيد وتغيير حالتها)" },
  {
    key: "override_visit_doctor",
    label: "اختيار مقدم خدمة مختلف في سجل الزيارات (لدكاترة مساعدين) — من غير ما يأثر على التحصيل المالي",
  },
  {
    key: "edit_old_visits",
    label: "تعديل زيارات قديمة في سجل الزيارات (أكتر من 3 أيام من إضافتها) — غير كده أي حد يقدر يعدّل بس خلال أول 3 أيام",
  },
  {
    key: "edit_invoice_payments",
    label: "تعديل المدفوع وسعر الخدمة في فاتورة اتسجلت بالفعل (تصحيح غلطة إدخال من الاستقبال)",
  },
  {
    key: "delete_visits",
    label: "حذف زيارة (وفاتورتها) من سجل الزيارات نهائيًا — لتصحيح إدخال مكرر أو غلط، للأدمن بس افتراضيًا",
  },
  {
    key: "view_invoice_totals",
    label:
      "عرض الإجماليات والتفاصيل المالية الكاملة في صفحة الفواتير (إجمالي الفواتير/المحصّل/المتبقي، والسعر الأصلي/الخصم/المبلغ لكل فاتورة، وتقرير تعديلات اليوم) — غير كده الاستقبال يشوف بس المدفوع وطريقة الدفع والمتبقي لكل مريض",
  },
] as const;

export type PermissionKey = (typeof PERMISSION_DEFS)[number]["key"];

export const ROLE_DEFAULT_PERMISSIONS: Record<Role, PermissionKey[]> = {
  admin: [
    "reports_full",
    "collect_payments",
    "manage_inventory",
    "manage_expenses",
    "manage_settings",
    "schedule_all_rooms",
    "schedule_edit",
    "override_visit_doctor",
    "edit_old_visits",
    "edit_invoice_payments",
    "delete_visits",
    "view_invoice_totals",
    "view_patient_billing",
  ],
  clinic_manager: [
    "reports_full",
    "manage_inventory",
    "schedule_all_rooms",
    "override_visit_doctor",
    "edit_old_visits",
    "edit_invoice_payments",
    "view_invoice_totals",
    "view_patient_billing",
  ],
  accountant: [
    "reports_full",
    "collect_payments",
    "manage_expenses",
    "edit_invoice_payments",
    "view_invoice_totals",
    "view_patient_billing",
  ],
  // manage_inventory ضمن الافتراضي هنا عشان الاستقبال كان عنده وصول للمخزون
  // أصلاً (رابط ثابت في القائمة قبل ما يبقى صلاحية) — عشان التحويل للنظام
  // الجديد ميقفلش حاجة كانت شغالة بالفعل. لسه ممكن تُسحب من مستخدم استقبال
  // معيّن من الإعدادات لو حابب.
  reception: ["collect_payments", "schedule_all_rooms", "schedule_edit", "view_patient_billing", "manage_inventory"],
  // الدكتور افتراضيًا يشوف الجدول المركزي لشيفته/غرفته بس النهاردة، وبشكل عرض فقط
  // (من غير حجز أو تغيير حالة) — الأدمن يقدر يوسّع الصلاحيات دي لدكتور معيّن من
  // صفحة الإعدادات لو حابب (schedule_all_rooms و/أو schedule_edit).
  doctor: ["reports_own"],
};
