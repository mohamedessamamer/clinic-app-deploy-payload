"use server";

import { hasPermission } from "@/lib/permissions";
import { getSession } from "@/lib/session";
import { issueAppointmentLink } from "@/lib/appointment-self-service";
import { db } from "@/lib/db/client";
import { formatArabicAppointmentDate, formatArabicAppointmentTime } from "@/lib/whatsapp/manual-templates";

export async function createAppointmentManageLinkAction(appointmentId: number) {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "schedule_edit"))) return { ok: false, error: "غير مصرح", url: null };
  try { const result = await issueAppointmentLink(appointmentId, "manual"); return { ok: true, url: result.url }; }
  catch (error) { return { ok: false, error: error instanceof Error ? error.message : "تعذر إنشاء الرابط", url: null }; }
}

export async function createManualWhatsappConfirmationAction(appointmentId: number) {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "schedule_edit"))) return { ok: false, error: "غير مصرح", whatsappUrl: null };
  const appointment = await db.selectFrom("appointments")
    .innerJoin("patients", "patients.id", "appointments.patient_id")
    .innerJoin("doctors", "doctors.id", "appointments.doctor_id")
    .select(["appointments.appointment_date", "appointments.start_time", "patients.full_name as patient_name", "patients.phone", "patients.phone_country_code", "doctors.full_name as doctor_name"])
    .where("appointments.id", "=", appointmentId).executeTakeFirst();
  if (!appointment?.phone) return { ok: false, error: "لا يوجد رقم واتساب مسجل للمريض.", whatsappUrl: null };
  try {
    const issued = await issueAppointmentLink(appointmentId, "manual");
    const phone = `${appointment.phone_country_code.replace(/\D/g, "")}${appointment.phone.replace(/\D/g, "").replace(/^0+/, "")}`;
    const user = await db.selectFrom("users").select(["full_name", "contact_name"]).where("id", "=", session.userId).executeTakeFirst();
    const contactName = user?.contact_name || user?.full_name || "";
    const message = `أهلًا ${appointment.patient_name}\nهذه الرسالة لتأكيد موعدك ${formatArabicAppointmentDate(appointment.appointment_date)} الساعة ${formatArabicAppointmentTime(appointment.start_time)} مع د. ${appointment.doctor_name}.\nبرجاء الضغط على الرابط لتأكيد الموعد أو تعديله:\n\n${issued.url}${contactName ? `\n\n${contactName}` : ""}`;
    return { ok: true, whatsappUrl: `https://wa.me/${phone}?text=${encodeURIComponent(message)}` };
  } catch (error) { return { ok: false, error: error instanceof Error ? error.message : "تعذر تجهيز الرسالة.", whatsappUrl: null }; }
}
