"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getAllSettings, setSetting } from "@/lib/settings";
import { getClinicToday } from "@/lib/clinic-date";

const validDate = (value: string) => /^\d{4}-\d{2}-\d{2}$/.test(value);
const offset = (date: string, days: number) => { const [y,m,d] = date.split("-").map(Number); return new Date(Date.UTC(y,m-1,d+days)).toISOString().slice(0,10); };
const daysBetween = (from: string, to: string) => Math.floor((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86400000);

export async function getWhatsAppOperationalReportAction(type: "ortho" | "referrals" | "unpaid", from: string, to: string) {
  const session = await getSession();
  if (!session || !validDate(from) || !validDate(to)) return { ok: false as const, error: "بيانات غير صحيحة", rows: [] };
  if (type === "ortho") {
    if (!(await hasPermission(session.userId, session.role, "view_ortho_followup_report"))) return { ok: false as const, error: "غير مصرح", rows: [] };
    const settings = await getAllSettings();
    const first = Number(settings.ortho_followup_first_days) || 45;
    const second = Number(settings.ortho_followup_second_days) || 90;
    const visits = await db.selectFrom("ortho_visits").innerJoin("patients", "patients.id", "ortho_visits.patient_id").leftJoin("doctors", "doctors.id", "ortho_visits.doctor_id").select(["ortho_visits.patient_id", "ortho_visits.visit_date", "patients.full_name as patient_name", "doctors.full_name as doctor_name"]).orderBy("ortho_visits.visit_date", "desc").execute();
    const latest = new Map<number, typeof visits[number]>();
    for (const visit of visits) if (!latest.has(visit.patient_id)) latest.set(visit.patient_id, visit);
    const today = getClinicToday();
    const rows = [...latest.values()].map((row) => ({ patientId: row.patient_id, patientName: row.patient_name, doctorName: row.doctor_name || "—", date: row.visit_date, days: daysBetween(row.visit_date, today) })).filter((row) => row.days >= first).map((row) => ({ ...row, stage: row.days >= second ? `${second} يوم أو أكثر` : `${first} يوم أو أكثر` })).sort((a,b) => b.days-a.days);
    return { ok: true as const, type, thresholds: { first, second }, rows };
  }
  if (type === "referrals") {
    if (!(await hasPermission(session.userId, session.role, "view_referral_report"))) return { ok: false as const, error: "غير مصرح", rows: [] };
    const rows = await db.selectFrom("patient_referrals").innerJoin("patients", "patients.id", "patient_referrals.patient_id").innerJoin("doctors as from_doctor", "from_doctor.id", "patient_referrals.from_doctor_id").innerJoin("doctors as to_doctor", "to_doctor.id", "patient_referrals.to_doctor_id").select(["patient_referrals.id", "patient_referrals.patient_id as patientId", "patients.full_name as patientName", "from_doctor.full_name as fromDoctor", "to_doctor.full_name as toDoctor", "patient_referrals.request_text as requestText", "patient_referrals.status", "patient_referrals.created_at as date"]).where("patient_referrals.created_at", ">=", `${from} 00:00:00`).where("patient_referrals.created_at", "<=", `${to} 23:59:59`).orderBy("patient_referrals.created_at", "desc").execute();
    return { ok: true as const, type, rows };
  }
  if (!(await hasPermission(session.userId, session.role, "view_whatsapp_reminder_report"))) return { ok: false as const, error: "غير مصرح", rows: [] };
  const rows = await db.selectFrom("appointments").innerJoin("patients", "patients.id", "appointments.patient_id").innerJoin("doctors", "doctors.id", "appointments.doctor_id").select(["appointments.id", "appointments.patient_id as patientId", "patients.full_name as patientName", "doctors.full_name as doctorName", "appointments.appointment_date as date", "appointments.debt_on_completion as debt"]).where("appointments.completed_without_payment", "=", 1).where("appointments.appointment_date", ">=", from).where("appointments.appointment_date", "<=", to).orderBy("appointments.appointment_date", "desc").execute();
  return { ok: true as const, type, rows };
}

export async function saveOrthoFollowupThresholdsAction(first: number, second: number) {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "configure_followup_thresholds"))) return { ok: false, error: "غير مصرح" };
  const safeFirst = Math.max(1, Math.min(365, Math.round(first)));
  const safeSecond = Math.max(safeFirst + 1, Math.min(730, Math.round(second)));
  await Promise.all([setSetting("ortho_followup_first_days", String(safeFirst)), setSetting("ortho_followup_second_days", String(safeSecond))]);
  revalidatePath("/whatsapp");
  return { ok: true };
}

export async function reportPresetDatesAction(preset: "tomorrow" | "week" | "month") {
  const today = getClinicToday();
  const from = offset(today, 1);
  return { from, to: preset === "tomorrow" ? from : offset(today, preset === "week" ? 7 : 30) };
}
