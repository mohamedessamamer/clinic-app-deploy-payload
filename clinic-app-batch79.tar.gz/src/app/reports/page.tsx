import Link from "next/link";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { paymentMethodLabel } from "@/lib/payment-methods";
import { getReportsData, type ReportsSearchParams } from "@/lib/reports-data";
import ReportsFilterForm from "@/components/ReportsFilterForm";
import { EXPENSE_CATEGORIES, EXPENSE_CATEGORY_LABELS, getExpenseSummary } from "@/lib/expenses";
import { cookies } from "next/headers";
import { DOCTOR_REPORT_ACCESS_COOKIE, verifyDoctorReportAccessToken } from "@/lib/report-access";

// تقرير الإيرادات — صفحة/صلاحية مستقلة (reports_full / reports_own، شوف
// permission-defs.ts) بتجمّع بيانات الفواتير الموجودة فعلاً (نفس مصدر بيانات
// /invoices والملف المالي لكل مريض) بفلاتر فترة/دكتور/خدمة، بدل ما تبقى صفحة
// منفصلة بمنطق حسابي مختلف. عمدًا بيربط رجوع لصفوف اليوم التفصيلية في /invoices
// (شوف "ربط الشاشات" في رابط عمود التاريخ تحت).
//
// منطق الجلب/التجميع الفعلي منقول لـ src/lib/reports-data.ts عشان يُستخدم هنا
// وفي تصدير الـ Excel (src/app/reports/export/route.ts) من غير تكرار.

export default async function ReportsPage({ searchParams }: { searchParams: Promise<ReportsSearchParams> }) {
  const session = await getSession();
  const sp = await searchParams;
  const data = await getReportsData(session, sp);

  if (!data.ok) {
    const message =
      data.reason === "no_session"
        ? "لازم تسجل دخول عشان توصل للتقارير."
        : data.reason === "no_permission"
          ? "مفيش صلاحية عندك لعرض التقارير — كلم الأدمن لو محتاج توصل للصفحة دي."
          : "الحساب ده مالوش دكتور مرتبط بيه، فمفيش تقرير شخصي نقدر نعرضه ليك.";
    return <div className="card-3d rounded-xl p-5 text-sm text-muted">{message}</div>;
  }

  const {
    reportsFull,
    from,
    to,
    dateRangeClamped,
    reportsOwnMinFrom,
    doctorId,
    serviceId,
    doctors,
    services,
    newAmount,
    collected,
    visitCount,
    byMethod,
    byDoctor,
    byService,
    byDay,
  } = data;
  const requiresPassword = session?.role === "doctor";
  const reportUnlocked = !requiresPassword || (
    sp.applied === "1" &&
    await verifyDoctorReportAccessToken((await cookies()).get(DOCTOR_REPORT_ACCESS_COOKIE)?.value, {
      userId: session!.userId,
      from,
      to,
      doctorId,
      serviceId,
    })
  );

  if (!reportUnlocked) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-xl font-bold">تقرير الإيرادات</h1>
          <p className="mt-1 text-xs text-muted">اختر الفترة ثم اضغط تطبيق لإظهار الإجماليات.</p>
        </div>
        <ReportsFilterForm
          from={from}
          to={to}
          minFrom={reportsOwnMinFrom}
          doctorId={reportsFull ? doctorId : null}
          serviceId={serviceId}
          doctors={doctors}
          services={services}
          showDoctorFilter={reportsFull}
          requirePassword
        />
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="card-3d rounded-xl p-4"><div className="text-xs text-muted">إجمالي الفواتير الجديدة في الفترة</div><div className="text-2xl font-bold">0 ج.م</div></div>
          <div className="card-3d rounded-xl p-4"><div className="text-xs text-muted">المحصّل في الفترة</div><div className="text-2xl font-bold text-primary">0 ج.م</div></div>
          <div className="card-3d rounded-xl p-4"><div className="text-xs text-muted">عدد الزيارات المفوترة</div><div className="text-2xl font-bold">0</div></div>
        </div>
        <div className="rounded-xl border border-border bg-primary-soft/40 px-4 py-5 text-center text-sm text-muted">الإجماليات مخفية حتى اختيار الفترة وتأكيد كلمة المرور.</div>
      </div>
    );
  }
  // المصروفات تخص العيادة ككل ولا يصح خلطها بتقرير طبيب أو خدمة واحدة؛ لذلك
  // تظهر فقط في التقرير العام لمن لديه صلاحية إدارة المصروفات.
  const canViewExpenseSummary = reportsFull && !doctorId && !serviceId && !!session && (await hasPermission(session.userId, session.role, "manage_expenses"));
  const expenseSummary = canViewExpenseSummary ? await getExpenseSummary(from, to) : null;


  const qs = (overrides: Record<string, string | null>) => {
    const params = new URLSearchParams();
    params.set("from", from);
    params.set("to", to);
    if (doctorId) params.set("doctor_id", String(doctorId));
    if (serviceId) params.set("service_id", String(serviceId));
    for (const [k, v] of Object.entries(overrides)) {
      if (v == null) params.delete(k);
      else params.set(k, v);
    }
    return params.toString();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-xl font-bold">تقرير الإيرادات</h1>
          {dateRangeClamped && (
            <p className="text-xs text-muted mt-1">الفترة اتقصّرت لآخر شهرين — الحد الأقصى للتقرير الشخصي.</p>
          )}
        </div>
        <div className="flex items-center gap-3">
          <a href={`/reports/export?${qs({})}`} className="text-sm px-3 py-1.5 rounded-md border border-border hover:bg-primary-soft">
            تصدير Excel
          </a>
          <Link href={`/invoices?date=${to}`} className="text-sm text-primary hover:underline">
            فتح فواتير يوم {to} بالتفصيل
          </Link>
        </div>
      </div>

      <ReportsFilterForm
        from={from}
        to={to}
        minFrom={reportsOwnMinFrom}
        doctorId={reportsFull ? doctorId : null}
        serviceId={serviceId}
        doctors={doctors}
        services={services}
        showDoctorFilter={reportsFull}
        requirePassword={requiresPassword}
      />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="card-3d rounded-xl p-4">
          <div className="text-xs text-muted">إجمالي الفواتير الجديدة في الفترة</div>
          <div className="text-2xl font-bold">{newAmount.toFixed(0)} ج.م</div>
        </div>
        <div className="card-3d rounded-xl p-4">
          <div className="text-xs text-muted">المحصّل في الفترة</div>
          <div className="text-2xl font-bold text-primary">{collected.toFixed(0)} ج.م</div>
          <div className="text-[10px] text-muted mt-0.5">شامل أي دفعات متابعة اتحصّلت في الفترة دي على فواتير أقدم</div>
        </div>
        <div className="card-3d rounded-xl p-4">
          <div className="text-xs text-muted">عدد الزيارات المفوترة</div>
          <div className="text-2xl font-bold">{visitCount}</div>
        </div>
      </div>

      {expenseSummary && (
        <section className="card-3d rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div>
              <h2 className="font-semibold text-sm">المصروفات وصافي النقدية</h2>
              <p className="text-xs text-muted mt-1">المصروفات هنا تخص العيادة بالكامل في الفترة المختارة، وتشمل توريدات المخزن المسجلة بتكلفة.</p>
            </div>
            <Link href={`/expenses?month=${to.slice(0, 7)}`} className="text-sm text-primary hover:underline">فتح المصروفات</Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div><span className="text-xs text-muted">إجمالي المصروفات</span><div className="text-2xl font-bold text-danger">{expenseSummary.total.toFixed(0)} ج.م</div></div>
            <div><span className="text-xs text-muted">صافي النقدية (المحصّل − المصروفات)</span><div className={`text-2xl font-bold ${collected - expenseSummary.total >= 0 ? "text-primary" : "text-danger"}`}>{(collected - expenseSummary.total).toFixed(0)} ج.م</div></div>
          </div>
          <div className="flex flex-wrap gap-x-5 gap-y-2 text-sm">
            {EXPENSE_CATEGORIES.map((category) => <div key={category}><span className="text-muted">{EXPENSE_CATEGORY_LABELS[category]}: </span><b>{(expenseSummary.byCategory.get(category) ?? 0).toFixed(0)} ج.م</b></div>)}
          </div>
        </section>
      )}

      {byMethod.length > 0 && (
        <div className="card-3d rounded-xl p-4">
          <div className="text-sm font-semibold mb-2">المحصّل حسب وسيلة الدفع</div>
          <div className="flex flex-wrap gap-4">
            {byMethod.map(([method, amount]) => (
              <div key={method} className="text-sm">
                <span className="text-muted">{paymentMethodLabel(method)}: </span>
                <span className="font-semibold">{amount.toFixed(0)} ج.م</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {byDoctor.length > 0 && (
        <div className="card-3d rounded-xl overflow-hidden">
          <div className="px-4 py-2 font-semibold text-sm bg-primary-soft text-primary-dark">حسب الدكتور</div>
          <table className="w-full text-sm">
            <thead className="bg-primary-soft/50 text-muted">
              <tr>
                <th className="text-right px-3 py-2 font-medium">الدكتور</th>
                <th className="text-right px-3 py-2 font-medium">عدد الزيارات</th>
                <th className="text-right px-3 py-2 font-medium">الفواتير الجديدة</th>
                <th className="text-right px-3 py-2 font-medium">المحصّل</th>
              </tr>
            </thead>
            <tbody>
              {byDoctor.map((row) => (
                <tr key={row.key} className="border-t border-border">
                  <td className="px-3 py-2 font-medium">
                    <Link href={`/reports?${qs({ doctor_id: String(row.key) })}`} className="text-primary hover:underline">
                      {row.label}
                    </Link>
                  </td>
                  <td className="px-3 py-2">{row.visits}</td>
                  <td className="px-3 py-2">{row.amount.toFixed(0)}</td>
                  <td className="px-3 py-2 text-primary">{row.paid.toFixed(0)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {byService.length > 0 && (
        <div className="card-3d rounded-xl overflow-hidden">
          <div className="px-4 py-2 font-semibold text-sm bg-primary-soft text-primary-dark">حسب الخدمة</div>
          <table className="w-full text-sm">
            <thead className="bg-primary-soft/50 text-muted">
              <tr>
                <th className="text-right px-3 py-2 font-medium">الخدمة</th>
                <th className="text-right px-3 py-2 font-medium">عدد الزيارات</th>
                <th className="text-right px-3 py-2 font-medium">الفواتير الجديدة</th>
                <th className="text-right px-3 py-2 font-medium">المحصّل</th>
              </tr>
            </thead>
            <tbody>
              {byService.map((row) => (
                <tr key={row.key} className="border-t border-border">
                  <td className="px-3 py-2 font-medium">
                    <Link href={`/reports?${qs({ service_id: String(row.key) })}`} className="text-primary hover:underline">
                      {row.label}
                    </Link>
                  </td>
                  <td className="px-3 py-2">{row.visits}</td>
                  <td className="px-3 py-2">{row.amount.toFixed(0)}</td>
                  <td className="px-3 py-2 text-primary">{row.paid.toFixed(0)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="card-3d rounded-xl overflow-hidden">
        <div className="px-4 py-2 font-semibold text-sm bg-primary-soft text-primary-dark">تفصيل يومي</div>
        <table className="w-full text-sm">
          <thead className="bg-primary-soft/50 text-muted">
            <tr>
              <th className="text-right px-3 py-2 font-medium">اليوم</th>
              <th className="text-right px-3 py-2 font-medium">عدد الزيارات</th>
              <th className="text-right px-3 py-2 font-medium">الفواتير الجديدة</th>
              <th className="text-right px-3 py-2 font-medium">المحصّل</th>
              <th className="text-right px-3 py-2 font-medium" />
            </tr>
          </thead>
          <tbody>
            {byDay.map((row) => (
              <tr key={row.date} className="border-t border-border">
                <td className="px-3 py-2 whitespace-nowrap">{row.date}</td>
                <td className="px-3 py-2">{row.visits}</td>
                <td className="px-3 py-2">{row.amount.toFixed(0)}</td>
                <td className="px-3 py-2 text-primary">{row.paid.toFixed(0)}</td>
                <td className="px-3 py-2">
                  <Link href={`/invoices?date=${row.date}`} className="text-xs text-primary hover:underline whitespace-nowrap">
                    تفاصيل الفواتير ←
                  </Link>
                </td>
              </tr>
            ))}
            {byDay.length === 0 && (
              <tr>
                <td colSpan={5} className="px-3 py-6 text-center text-muted">
                  لا يوجد بيانات في الفترة المختارة.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
