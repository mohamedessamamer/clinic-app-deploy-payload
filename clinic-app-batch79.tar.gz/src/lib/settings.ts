import { db } from "./db/client";

export const SETTINGS_DEFAULTS = {
  slot_minutes: "15", // وحدة الزمن الافتراضية للعيادة (طول فترة الموعد بالدقايق)
  day_start: "09:00",
  day_end: "22:00",
  // أرقام أيام الأسبوع اللي العيادة إجازة فيها، مفصولة بفاصلة (0=الأحد ... 6=السبت).
  holiday_weekdays: "",
  // أقصى عدد أيام رجوع بالتاريخ يقدر الدكتور (غير صاحب الصلاحية الكاملة) يشوف تقريره الشخصي فيها.
  // قابل للتغيير من "إعدادات الصلاحيات" بدل ما يكون رقم ثابت بالكود.
  doctor_report_max_days: "60",
  // إعدادات مركز الإشعارات قابلة للتعديل من لوحة الإعدادات، وليست أرقامًا ثابتة.
  notification_ortho_stages_days: "40,60,90",
  notification_ortho_final_repeat_days: "7",
  notification_photo_days: "180",
  notification_retention_hours: "48",
  chat_retention_hours: "48",
  // مكتبة أصوات الشات: soft_chime / gentle_bell / water_drop / off.
  chat_notification_sound: "gentle_bell",
  // مخزن: المستخدمون الذين يصلهم تنبيه نقص المخزون، مع ترك الاختيار للأدمن
  // بدلاً من افتراض كل الأطباء أو كل الموظفين.
  inventory_low_stock_recipient_ids: "",
  whatsapp_reminder_time: "18:00",
  whatsapp_reminder_valid_hours: "3",
  whatsapp_reminder_template_name: "appointment_reminder",
  whatsapp_confirmation_template_name: "appointment_reschedule_confirmed",
  whatsapp_template_language: "ar",
  ortho_followup_first_days: "45",
  ortho_followup_second_days: "90",
  clinic_public_url: "https://clinicsys.revereeg.com",
};

export const WEEKDAY_LABELS = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];

// ترتيب عرض أيام الأسبوع للمستخدم — عندنا الأسبوع بيبدأ السبت (مش الأحد زي
// الترتيب الافتراضي في JavaScript/Date). الأرقام نفسها (weekday: 0=الأحد..
// 6=السبت، زي ما محفوظة في قاعدة البيانات ومُرجعة من weekdayOf تحت) فاضلة
// زي ما هي من غير أي تغيير — ده بس بيتحكم في ترتيب العرض في أي مكان بيسرد كل
// أيام الأسبوع (إعدادات الشيفتات الأسبوعية، أيام الإجازة).
export const WEEKDAY_DISPLAY_ORDER = [6, 0, 1, 2, 3, 4, 5];

// بيرجع رقم يوم الأسبوع (0=الأحد .. 6=السبت) لتاريخ "YYYY-MM-DD"، بالاعتماد على أجزاء
// التاريخ نفسها (عبر Date.UTC) بدل new Date(dateStr) عشان النتيجة متتأثرش بالتايم زون
// بتاع السيرفر.
export function weekdayOf(dateStr: string): number {
  const [y, m, d] = dateStr.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d)).getUTCDay();
}

export type SettingKey = keyof typeof SETTINGS_DEFAULTS;

export async function getSetting(key: SettingKey): Promise<string> {
  const row = await db.selectFrom("clinic_settings").select("value").where("key", "=", key).executeTakeFirst();
  return row?.value ?? SETTINGS_DEFAULTS[key];
}

export async function getAllSettings(): Promise<Record<SettingKey, string>> {
  const rows = await db.selectFrom("clinic_settings").selectAll().execute();
  const map = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  return { ...SETTINGS_DEFAULTS, ...map } as Record<SettingKey, string>;
}

export async function setSetting(key: SettingKey, value: string) {
  await db
    .insertInto("clinic_settings")
    .values({ key, value })
    .onConflict((oc) => oc.column("key").doUpdateSet({ value }))
    .execute();
}

// Generates ["09:00", "09:15", "09:30", ...] between start/end using the clinic's configured slot length.
export function buildTimeSlots(startTime: string, endTime: string, slotMinutes: number): string[] {
  const slots: string[] = [];
  const [sh, sm] = startTime.split(":").map(Number);
  const [eh, em] = endTime.split(":").map(Number);
  let cursor = sh * 60 + sm;
  const end = eh * 60 + em;
  const step = Math.max(5, slotMinutes || 15);
  while (cursor <= end) {
    const h = String(Math.floor(cursor / 60)).padStart(2, "0");
    const m = String(cursor % 60).padStart(2, "0");
    slots.push(`${h}:${m}`);
    cursor += step;
  }
  return slots;
}
