import "server-only";
import { db } from "@/lib/db/client";
import { encryptSecret, decryptSecret } from "./crypto";

// كل تفاعل مع جداول whatsapp_* بيمر من هنا — عشان التوكن يتفك تشفيره في مكان
// واحد بس، وما ينزلش لمكونات تانية غلط. ما ترجعش decryptedAccessToken من هنا
// إلا لمن يحتاجها فعليًا (إرسال رسالة، إنشاء قالب) — ومتتبعتش لأي حاجة بتتسجل
// في logs أو بترجع للـclient.

export async function getActiveAccount() {
  return db
    .selectFrom("whatsapp_accounts")
    .selectAll()
    .where("connection_status", "=", "connected")
    .orderBy("id", "desc")
    .executeTakeFirst();
}

export async function getAccountAccessToken(accountId: number): Promise<string> {
  const row = await db
    .selectFrom("whatsapp_accounts")
    .select("access_token_encrypted")
    .where("id", "=", accountId)
    .executeTakeFirstOrThrow();
  return decryptSecret(row.access_token_encrypted);
}

export async function upsertAccountFromSignup(params: {
  wabaId: string;
  phoneNumberId: string;
  displayPhoneNumber?: string | null;
  verifiedName?: string | null;
  businessId?: string | null;
  accessToken: string;
  coexistence: boolean;
  environment: "test" | "production";
  connectedBy: number;
}) {
  const encrypted = encryptSecret(params.accessToken);
  const existing = await db
    .selectFrom("whatsapp_accounts")
    .select("id")
    .where("waba_id", "=", params.wabaId)
    .where("phone_number_id", "=", params.phoneNumberId)
    .executeTakeFirst();

  if (existing) {
    await db
      .updateTable("whatsapp_accounts")
      .set({
        access_token_encrypted: encrypted,
        display_phone_number: params.displayPhoneNumber ?? null,
        verified_name: params.verifiedName ?? null,
        business_id: params.businessId ?? null,
        coexistence_mode: params.coexistence ? 1 : 0,
        environment: params.environment,
        connection_status: "connected",
        last_error: null,
        connected_by: params.connectedBy,
        updated_at: new Date().toISOString(),
      })
      .where("id", "=", existing.id)
      .execute();
    return existing.id;
  }

  const inserted = await db
    .insertInto("whatsapp_accounts")
    .values({
      waba_id: params.wabaId,
      phone_number_id: params.phoneNumberId,
      display_phone_number: params.displayPhoneNumber ?? null,
      verified_name: params.verifiedName ?? null,
      business_id: params.businessId ?? null,
      access_token_encrypted: encrypted,
      token_type: "system_user",
      environment: params.environment,
      coexistence_mode: params.coexistence ? 1 : 0,
      connection_status: "connected",
      connected_by: params.connectedBy,
    })
    .executeTakeFirstOrThrow();
  return Number(inserted.insertId);
}

export async function markAccountError(accountId: number, message: string) {
  await db
    .updateTable("whatsapp_accounts")
    .set({ connection_status: "error", last_error: message.slice(0, 500), updated_at: new Date().toISOString() })
    .where("id", "=", accountId)
    .execute();
}

export async function upsertContact(accountId: number, waId: string, profileName: string | null) {
  const existing = await db
    .selectFrom("whatsapp_contacts")
    .select("id")
    .where("account_id", "=", accountId)
    .where("wa_id", "=", waId)
    .executeTakeFirst();
  if (existing) {
    if (profileName) {
      await db.updateTable("whatsapp_contacts").set({ profile_name: profileName }).where("id", "=", existing.id).execute();
    }
    return existing.id;
  }
  const inserted = await db
    .insertInto("whatsapp_contacts")
    .values({ account_id: accountId, wa_id: waId, profile_name: profileName })
    .executeTakeFirstOrThrow();
  return Number(inserted.insertId);
}

export async function touchContactLastMessage(contactId: number, whenIso: string) {
  await db.updateTable("whatsapp_contacts").set({ last_message_at: whenIso }).where("id", "=", contactId).execute();
}

// idempotency عام لأحداث webhook: بيرجع true لو الحدث ده *جديد فعلاً* (لسه ما
// اتسجلش)، وfalse لو اتسجل قبل كده (يبقى المعالجة تتجاهله). INSERT OR IGNORE
// آمن من الـrace بين طلبين متزامنين لنفس الحدث.
export async function claimWebhookEvent(eventKey: string, eventType: string): Promise<boolean> {
  const result = await db
    .insertInto("whatsapp_webhook_events")
    .values({ event_key: eventKey, event_type: eventType })
    .onConflict((oc) => oc.column("event_key").doNothing())
    .executeTakeFirst();
  return Number(result.numInsertedOrUpdatedRows ?? 0) > 0;
}

export async function recordInboundMessage(params: {
  accountId: number;
  contactId: number;
  wamid: string;
  messageType: string;
  body: string | null;
  waTimestamp: string;
  isEcho?: boolean;
}) {
  await db
    .insertInto("whatsapp_messages")
    .values({
      account_id: params.accountId,
      contact_id: params.contactId,
      wamid: params.wamid,
      direction: "inbound",
      message_type: params.messageType,
      body: params.body,
      status: "delivered",
      is_echo: params.isEcho ? 1 : 0,
      wa_timestamp: params.waTimestamp,
    })
    .onConflict((oc) => oc.column("wamid").doNothing())
    .execute();
}

export async function recordOutboundMessage(params: {
  accountId: number;
  contactId: number;
  wamid: string | null;
  body: string;
  sentBy: number | null;
  status: "pending" | "sent" | "failed";
  errorMessage?: string | null;
}) {
  const inserted = await db
    .insertInto("whatsapp_messages")
    .values({
      account_id: params.accountId,
      contact_id: params.contactId,
      wamid: params.wamid,
      direction: "outbound",
      message_type: "text",
      body: params.body,
      status: params.status,
      error_message: params.errorMessage ?? null,
      sent_by: params.sentBy,
      wa_timestamp: new Date().toISOString(),
    })
    .executeTakeFirstOrThrow();
  return Number(inserted.insertId);
}

// تحديث حالة رسالة outbound (sent/delivered/read/failed) — status webhook.
// idempotent بطبيعته: تحديث نفس القيمة أكتر من مرة مالوش أثر إضافي.
export async function updateMessageStatus(wamid: string, status: "sent" | "delivered" | "read" | "failed", errorMessage?: string) {
  await db
    .updateTable("whatsapp_messages")
    .set({ status, error_message: errorMessage ?? null })
    .where("wamid", "=", wamid)
    .execute();
}

export async function listConversations(accountId: number, limit = 50) {
  return db
    .selectFrom("whatsapp_contacts")
    .selectAll()
    .where("account_id", "=", accountId)
    .orderBy("last_message_at", "desc")
    .limit(limit)
    .execute();
}

export async function listMessagesForContact(contactId: number, limit = 100) {
  return db
    .selectFrom("whatsapp_messages")
    .selectAll()
    .where("contact_id", "=", contactId)
    .orderBy("created_at", "desc")
    .limit(limit)
    .execute()
    .then((rows) => rows.reverse());
}

export async function upsertTemplateRow(params: {
  accountId: number;
  metaTemplateId: string | null;
  name: string;
  language: string;
  category: string;
  bodyText: string;
  status: string;
  createdBy: number;
}) {
  await db
    .insertInto("whatsapp_message_templates")
    .values({
      account_id: params.accountId,
      meta_template_id: params.metaTemplateId,
      name: params.name,
      language: params.language,
      category: params.category,
      body_text: params.bodyText,
      status: params.status as never,
      created_by: params.createdBy,
    })
    .onConflict((oc) =>
      oc.columns(["account_id", "name", "language"]).doUpdateSet({
        meta_template_id: params.metaTemplateId,
        status: params.status as never,
        updated_at: new Date().toISOString(),
      })
    )
    .execute();
}

export async function listTemplateRows(accountId: number) {
  return db
    .selectFrom("whatsapp_message_templates")
    .selectAll()
    .where("account_id", "=", accountId)
    .orderBy("created_at", "desc")
    .execute();
}

export async function updateTemplateStatus(accountId: number, name: string, language: string, status: string, rejectedReason?: string | null) {
  await db
    .updateTable("whatsapp_message_templates")
    .set({ status: status as never, rejected_reason: rejectedReason ?? null, updated_at: new Date().toISOString() })
    .where("account_id", "=", accountId)
    .where("name", "=", name)
    .where("language", "=", language)
    .execute();
}

export async function removeTemplatesMissingFromMeta(accountId: number, remote: { name: string; language: string }[]) {
  const local = await db.selectFrom("whatsapp_message_templates").select(["id", "name", "language"]).where("account_id", "=", accountId).execute();
  const keys = new Set(remote.map((item) => `${item.name}\u0000${item.language}`));
  const missing = local.filter((item) => !keys.has(`${item.name}\u0000${item.language}`)).map((item) => item.id);
  if (missing.length) await db.deleteFrom("whatsapp_message_templates").where("id", "in", missing).execute();
}
