"use client";

import { useState, useTransition } from "react";
import { approveAppointmentRescheduleAction, listAppointmentReminderReportAction } from "@/app/appointment-reminders/report-actions";

type Row = Awaited<ReturnType<typeof listAppointmentReminderReportAction>>[number];
const labels: Record<Row["response_status"], string> = { pending: "لم يرد", confirmed: "أكد الموعد", reschedule_pending: "طلب تعديل — ينتظر الاعتماد", reschedule_approved: "تم اعتماد التعديل", send_failed: "فشل الإرسال" };
export default function WhatsAppAppointmentReport({ initialRows }: { initialRows: Row[] }) {
  const [rows, setRows] = useState(initialRows);
  const [shown, setShown] = useState(false);
  const [busy, startTransition] = useTransition();
  const load = () => startTransition(async () => { setRows(await listAppointmentReminderReportAction()); setShown(true); });
  return <details className="card-3d rounded-xl p-5" dir="rtl"><summary className="cursor-pointer font-semibold">تقرير مواعيد المرضى والردود</summary><div className="mt-4 space-y-3"><p className="text-xs text-muted">لا تظهر النتائج إلا عند الطلب، وتشمل التأكيد وعدم الرد وطلب التعديل في قائمة واحدة.</p><button disabled={busy} onClick={load} className="rounded-md btn-3d-primary px-4 py-2 text-sm">عرض التقرير</button>{shown && <div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="border-b text-right"><th className="p-2">المريض</th><th className="p-2">الطبيب</th><th className="p-2">الموعد</th><th className="p-2">الحالة</th><th className="p-2">التعديل</th><th className="p-2"></th></tr></thead><tbody>{rows.map((row) => <tr key={row.id} className="border-b border-border"><td className="p-2 font-medium">{row.patient_name}</td><td className="p-2">{row.doctor_name}</td><td className="p-2 whitespace-nowrap">{row.appointment_date} · {row.start_time.slice(0,5)}</td><td className="p-2">{labels[row.response_status]}</td><td className="p-2">{row.requested_date ? `${row.requested_date} · ${row.requested_time?.slice(0,5)}` : "—"}</td><td className="p-2">{row.response_status === "reschedule_pending" && <button disabled={busy} onClick={() => startTransition(async () => { const result = await approveAppointmentRescheduleAction(row.id); if (!result.ok) return alert(result.error); if (result.warning) alert(result.warning); setRows(await listAppointmentReminderReportAction()); })} className="rounded-md bg-emerald-700 px-3 py-1.5 text-white">اعتماد</button>}</td></tr>)}{!rows.length && <tr><td colSpan={6} className="p-8 text-center text-muted">لا توجد نتائج.</td></tr>}</tbody></table></div>}</div></details>;
}
