"use client";

import { useState, useTransition } from "react";
import { prepareTomorrowManualConfirmationsAction, sendTomorrowConfirmationsAction } from "@/app/appointment-reminders/report-actions";

type ManualRow = { appointmentId: number; patientName: string; time: string; status: string; whatsappUrl: string | null };
type TemplateChoice = { id: number; name: string; quick_slot: number | null };
const statusLabels: Record<string, string> = { not_sent: "لم تُرسل", confirmed: "مؤكد", no_response: "لم يرد", reschedule_pending: "طلب تعديل", no_phone: "لا يوجد هاتف" };

export default function WhatsAppTomorrowSender({ templates, canManualSend, canBulkSend, canAutomate }: { templates: TemplateChoice[]; canManualSend: boolean; canBulkSend: boolean; canAutomate: boolean }) {
  const [busy, startTransition] = useTransition();
  const [rows, setRows] = useState<ManualRow[]>([]);
  const [opened, setOpened] = useState<number[]>([]);
  const [templateId, setTemplateId] = useState(String(templates[0]?.id || ""));
  const prepare = () => startTransition(async () => { const result = await prepareTomorrowManualConfirmationsAction(Number(templateId)); if (!result.ok) return alert(result.error); setRows(result.rows); setOpened([]); });
  return <section className="rounded-xl border border-border bg-background p-4 space-y-3" dir="rtl">
    <div><h2 className="font-semibold">الإرسال السريع</h2><p className="mt-1 text-xs text-muted">اختر القالب أولًا؛ ستظهر قائمة واحدة بكل مرضى غدًا وحالة كل مريض لمنع تكرار رسالة التأكيد.</p></div>
    <div className="flex flex-wrap items-end gap-2"><label className="min-w-56 text-sm">نوع الرسالة<select value={templateId} onChange={(event) => setTemplateId(event.target.value)} className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2">{templates.map((template) => <option key={template.id} value={template.id}>{template.quick_slot ? `${template.quick_slot}. ` : ""}{template.name}</option>)}</select></label>
      {canManualSend && <button disabled={busy || !templateId} onClick={prepare} className="rounded-md border border-primary px-4 py-2 text-sm text-primary">عرض مرضى غدًا والإرسال اليدوي</button>}
      {canAutomate && canBulkSend && <button disabled={busy} onClick={() => startTransition(async () => { const result = await sendTomorrowConfirmationsAction(); if (!result.ok) return alert(result.error); alert(`تم إرسال ${result.sent} رسالة، وتخطي ${result.skipped}، وفشل ${result.failed}.`); window.location.reload(); })} className="btn-3d-primary rounded-md px-4 py-2 text-sm">إرسال تلقائي لمرضى غدًا</button>}
    </div>
    {rows.length > 0 && <div className="overflow-x-auto border-t border-border pt-3"><table className="w-full text-sm"><thead><tr className="border-b border-border text-right"><th className="p-2">المريض</th><th className="p-2">الموعد</th><th className="p-2">الحالة</th><th className="p-2">الإجراء</th></tr></thead><tbody>{rows.map((row) => <tr key={row.appointmentId} className="border-b border-border"><td className="p-2 font-medium">{row.patientName}</td><td className="p-2">{row.time}</td><td className="p-2"><span className={row.status === "confirmed" ? "text-emerald-700" : row.status === "reschedule_pending" ? "text-violet-700" : row.status === "not_sent" ? "text-primary" : "text-muted"}>{statusLabels[row.status] || row.status}</span></td><td className="p-2">{row.whatsappUrl ? <button onClick={() => { const popup = window.open(row.whatsappUrl!, "clinic_whatsapp"); popup?.focus(); setOpened((current) => current.includes(row.appointmentId) ? current : [...current, row.appointmentId]); }} className="rounded-md border border-primary px-3 py-1.5 text-primary">{opened.includes(row.appointmentId) ? "فُتح واتساب" : "فتح واتساب"}</button> : <span className="text-xs text-muted">لا يحتاج إرسالًا جديدًا</span>}</td></tr>)}</tbody></table></div>}
  </section>;
}
