import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";

const eslintConfig = defineConfig([
  ...nextVitals,
  ...nextTs,
  // Override default ignores of eslint-config-next.
  globalIgnores([
    // Default ignores of eslint-config-next:
    ".next/**",
    "out/**",
    "build/**",
    "next-env.d.ts",
  ]),
  // set-state-in-effect: قاعدة جديدة في React 19. عندنا 17 موضع بتقع تحتها،
  // وكلها أنماط شغالة فعليًا (مزامنة حالة من localStorage عند التحميل، أو
  // تصفير حالة مشتقة لما الـprops تتغير). إصلاحها الصح يحتاج إعادة هيكلة
  // للمكونات دي — وده تغيير سلوك في أكتر شاشات مستخدمة (الجدول المركزي، شات
  // الموظفين، شارت التقويم) مش مناسب يتحشر في دفعة أمنية. نزّلناها لتحذير
  // عشان `npm run lint` يفضل بوابة حقيقية لأي خطأ *جديد*، وهي فاضلة ظاهرة
  // كتحذير لحد ما تتصلح مكوّن مكوّن في دفعات لاحقة.
  {
    rules: { "react-hooks/set-state-in-effect": "warn" },
  },
  // سكربتات صيانة بتتشغّل بـnode مباشرة (CommonJS) — مش جزء من بناء التطبيق،
  // فقاعدة "مفيش require" الخاصة بوحدات ES مالهاش معنى هنا.
  {
    files: ["scripts/**/*.js"],
    rules: { "@typescript-eslint/no-require-imports": "off" },
  },
]);

export default eslintConfig;
