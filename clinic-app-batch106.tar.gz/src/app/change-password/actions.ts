"use server";

import { cookies, headers } from "next/headers";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import {
  DEFAULT_PASSWORD,
  MIN_PASSWORD_LENGTH,
  SESSION_COOKIE,
  createSessionToken,
  hashPassword,
  isWeakPassword,
  verifyPassword,
} from "@/lib/auth";
import { safeInternalRedirect } from "@/lib/safe-redirect";

export type ChangePasswordState = {
  error?: "missing" | "short" | "weak" | "same" | "mismatch" | "wrong" | "session";
  redirectTo?: string;
};

// زي loginAction بالظبط: مفيش redirect() من جوه السيرفر أكشن. Next بيحل الـ
// redirect عبر طلب داخلي وبيستبعد هيدر set-cookie وقت نسخ الرد — وده كان بيضيّع
// الكوكي الجديدة. بنرجّع الوجهة والعميل هو اللي بينقل.
export async function changeDefaultPasswordAction(
  _previous: ChangePasswordState,
  formData: FormData
): Promise<ChangePasswordState> {
  const session = await getSession();
  if (!session) return { error: "session" };

  const currentPassword = String(formData.get("current_password") || "");
  const newPassword = String(formData.get("new_password") || "");
  const confirmPassword = String(formData.get("confirm_password") || "");
  const rawNext = String(formData.get("next") || "/");
  const next = safeInternalRedirect(rawNext);

  if (!currentPassword || !newPassword || !confirmPassword) return { error: "missing" };
  if (newPassword.length < MIN_PASSWORD_LENGTH) return { error: "short" };
  if (newPassword === DEFAULT_PASSWORD) return { error: "same" };
  if (isWeakPassword(newPassword)) return { error: "weak" };
  if (newPassword !== confirmPassword) return { error: "mismatch" };

  const user = await db
    .selectFrom("users")
    .select(["id", "username", "full_name", "role", "doctor_id", "password_hash", "session_version"])
    .where("id", "=", session.userId)
    .where("active", "=", 1)
    .executeTakeFirst();
  if (!user || !(await verifyPassword(currentPassword, user.password_hash))) return { error: "wrong" };

  await db
    .updateTable("users")
    .set({
      password_hash: await hashPassword(newPassword),
      must_change_password: 0,
      session_version: user.session_version + 1,
    })
    .where("id", "=", user.id)
    .execute();

  // جلسة جديدة بعد تغيير كلمة السر — الجلسات القديمة على نفس المتصفح بتتبدل،
  // والمستخدم مبيتطردش لصفحة الدخول بعد ما غيّر كلمة سره بنجاح.
  const token = await createSessionToken({
    userId: user.id,
    username: user.username,
    fullName: user.full_name,
    role: user.role,
    doctorId: user.doctor_id,
    sessionVersion: user.session_version + 1,
  });
  const isHttps = (await headers()).get("x-forwarded-proto") === "https";
  (await cookies()).set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: isHttps,
    path: "/",
    maxAge: 60 * 60 * 12,
  });

  return { redirectTo: next };
}
