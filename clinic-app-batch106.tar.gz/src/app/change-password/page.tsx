import { redirect } from "next/navigation";
import { getSession } from "@/lib/session";
import { db } from "@/lib/db/client";
import { getClinicToday } from "@/lib/clinic-date";
import { DEFAULT_PASSWORD_DEADLINE, isDefaultPasswordDeadlinePassed } from "@/lib/auth";
import ChangePasswordForm from "./ChangePasswordForm";

// صفحة مستقلة عن /settings عن قصد: أي مستخدم — دكتور أو استقبال — لازم يقدر
// يوصلها ويغيّر كلمة سره من غير ما يحتاج صلاحية إعدادات. دي بقت المكان الوحيد
// لتغيير كلمة السر (قسم الإعدادات القديم بقى بيوصّل لهنا).
export default async function ChangePasswordPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string }>;
}) {
  const session = await getSession();
  if (!session) redirect("/login?next=/change-password");

  const { next: rawNext } = await searchParams;
  const next = rawNext && rawNext.startsWith("/") && !rawNext.startsWith("//") ? rawNext : "/";

  const user = await db
    .selectFrom("users")
    .select("must_change_password")
    .where("id", "=", session.userId)
    .executeTakeFirst();

  const onDefaultPassword = user?.must_change_password === 1;
  const deadlinePassed = isDefaultPasswordDeadlinePassed(getClinicToday());
  const canSkip = !onDefaultPassword || !deadlinePassed;

  return (
    <div className="mx-auto max-w-md p-4 sm:p-6">
      <div className="card-3d rounded-xl p-5 sm:p-6 space-y-4">
        <div className="space-y-2">
          <h1 className="text-lg font-bold">
            {onDefaultPassword ? "غيّر كلمة السر الافتراضية" : "تغيير كلمة السر"}
          </h1>
          {onDefaultPassword && (
            <p className="text-sm text-muted leading-relaxed">
              حسابك لسه شغال بكلمة السر الافتراضية <span className="font-semibold">123</span>.
              النظام متاح على الإنترنت وكلمة السر دي معروفة — أي حد يعرف اسم المستخدم بتاعك يقدر
              يدخل على ملفات المرضى وبيانات العيادة. اختار كلمة سر خاصة بيك دلوقتي.
            </p>
          )}
        </div>

        <ChangePasswordForm
          next={next}
          canSkip={canSkip}
          showDeadlineNote={onDefaultPassword}
          deadlinePassed={deadlinePassed}
          deadlineLabel={DEFAULT_PASSWORD_DEADLINE}
        />
      </div>
    </div>
  );
}
