"use client";

import { useActionState, useEffect } from "react";
import Link from "next/link";
import { changeDefaultPasswordAction, type ChangePasswordState } from "./actions";
import { MIN_PASSWORD_LENGTH } from "@/lib/auth";

const ERROR_LABELS: Record<string, string> = {
  missing: "لازم تملى كل الحقول.",
  short: `كلمة السر الجديدة لازم تكون ${MIN_PASSWORD_LENGTH} حروف/أرقام على الأقل.`,
  weak: "كلمة السر دي سهلة التخمين. اختار حاجة تانية.",
  same: "مينفعش تختار نفس كلمة السر الافتراضية. لازم كلمة سر جديدة.",
  mismatch: "كلمة السر الجديدة وتأكيدها مش متطابقين.",
  wrong: "كلمة السر الحالية غلط.",
  session: "انتهت الجلسة. سجل الدخول تاني.",
};

const initialState: ChangePasswordState = {};

export default function ChangePasswordForm({
  next,
  canSkip,
  showDeadlineNote,
  deadlinePassed,
  deadlineLabel,
}: {
  next: string;
  canSkip: boolean;
  showDeadlineNote: boolean;
  deadlinePassed: boolean;
  deadlineLabel: string;
}) {
  const [state, formAction, isPending] = useActionState(changeDefaultPasswordAction, initialState);

  useEffect(() => {
    // نفس أسلوب صفحة الدخول: انتقال كامل عشان المتصفح يطلب الوجهة بالكوكي
    // الجديدة اللي الأكشن لسه ضابطها.
    if (state.redirectTo) window.location.assign(state.redirectTo);
  }, [state.redirectTo]);

  return (
    <form action={formAction} className="space-y-4">
      <input type="hidden" name="next" value={next} />

      {state.error && (
        <p className="text-sm text-red-700 bg-red-50 border border-red-200 rounded-md px-3 py-2">
          {ERROR_LABELS[state.error] || "حصل خطأ، حاول تاني."}
        </p>
      )}

      <div>
        <label htmlFor="current_password" className="block text-sm text-muted mb-1">
          كلمة السر الحالية
        </label>
        <input
          id="current_password"
          type="password"
          name="current_password"
          autoComplete="current-password"
          required
          className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
        />
      </div>

      <div>
        <label htmlFor="new_password" className="block text-sm text-muted mb-1">
          كلمة السر الجديدة
        </label>
        <input
          id="new_password"
          type="password"
          name="new_password"
          autoComplete="new-password"
          required
          minLength={MIN_PASSWORD_LENGTH}
          className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
        />
        <p className="mt-1 text-xs text-muted">{MIN_PASSWORD_LENGTH} حروف/أرقام على الأقل.</p>
      </div>

      <div>
        <label htmlFor="confirm_password" className="block text-sm text-muted mb-1">
          تأكيد كلمة السر الجديدة
        </label>
        <input
          id="confirm_password"
          type="password"
          name="confirm_password"
          autoComplete="new-password"
          required
          minLength={MIN_PASSWORD_LENGTH}
          className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
        />
      </div>

      <div className="flex items-center gap-3 pt-1">
        <button
          type="submit"
          disabled={isPending}
          className="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
        >
          {isPending ? "جاري الحفظ..." : "حفظ كلمة السر"}
        </button>

        {canSkip && (
          <Link href={next} className="text-sm text-muted underline underline-offset-4">
            {showDeadlineNote ? "تخطي الآن" : "رجوع"}
          </Link>
        )}
      </div>

      {showDeadlineNote &&
        (deadlinePassed ? (
          <p className="text-xs text-red-700">
            الموعد النهائي ({deadlineLabel}) عدّى — لازم تغيّر كلمة السر عشان تكمّل.
          </p>
        ) : (
          <p className="text-xs text-muted">
            تقدر تأجّل لحد {deadlineLabel}. بعد التاريخ ده التغيير هيبقى إجباري قبل استخدام النظام.
          </p>
        ))}
    </form>
  );
}
