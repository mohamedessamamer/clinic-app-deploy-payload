import { NextRequest, NextResponse } from "next/server";
import { createWriteStream } from "node:fs";
import fs from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { ByteLimitTransform, UploadTooLargeError, assertContentLengthWithinLimit } from "@/lib/limited-upload";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const ROOT = process.env.CLINIC_UPLOAD_DIR ? path.join(path.resolve(process.env.CLINIC_UPLOAD_DIR), "hr-documents") : path.join(process.cwd(), "data", "uploads", "hr-documents");
const EXTENSIONS = new Set([".jpg", ".jpeg", ".png", ".webp", ".pdf"]);
// الراوت ده مستثنى من proxy.ts فمفيش حاجة تانية بتحد حجم الطلب — من غير الحد
// ده كان مستخدم واحد عنده manage_hr يقدر يملأ قرص السيرفر، واللي معناه توقف
// الخدمة واحتمال تلف ملف SQLite نفسه.
const MAX_DOCUMENT_BYTES = 25 * 1024 * 1024;

// نفس فحص التوقيع الثنائي المستخدم في رفع صور المرضى: الامتداد والـcontent-type
// الاتنين بيتبعتوا من العميل وينفع يتزوّروا، أول بايتات الملف لأ.
async function hasExpectedSignature(file: string, extension: string) {
  const handle = await fs.open(file, "r");
  try {
    const header = Buffer.alloc(12);
    const { bytesRead } = await handle.read(header, 0, header.length, 0);
    const bytes = header.subarray(0, bytesRead);
    if (extension === ".jpg" || extension === ".jpeg") return bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
    if (extension === ".png") return bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
    if (extension === ".webp") return bytes.subarray(0, 4).toString("ascii") === "RIFF" && bytes.subarray(8, 12).toString("ascii") === "WEBP";
    if (extension === ".pdf") return bytes.subarray(0, 5).toString("ascii") === "%PDF-";
    return false;
  } finally {
    await handle.close();
  }
}
function error(message: string, status: number) { return NextResponse.json({ ok: false, error: message }, { status }); }
function cleanName(raw: string | null) {
  let decoded = "document";
  try { decoded = decodeURIComponent(raw || "document"); } catch {}
  return path.basename(decoded).replace(/[^a-zA-Z0-9._-]/g, "_").slice(-160) || "document";
}

export async function POST(request: NextRequest) {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "manage_hr"))) return error("ليس لديك صلاحية إدارة HR.", 403);
  try {
    assertContentLengthWithinLimit(request.headers.get("content-length"), MAX_DOCUMENT_BYTES);
  } catch {
    return error(`أقصى حجم للمستند ${Math.round(MAX_DOCUMENT_BYTES / (1024 * 1024))} ميجابايت.`, 413);
  }
  const personType = request.nextUrl.searchParams.get("personType");
  const personId = Number(request.nextUrl.searchParams.get("personId"));
  const documentType = String(request.nextUrl.searchParams.get("documentType") || "other").slice(0, 80);
  const label = String(request.nextUrl.searchParams.get("label") || "").trim().slice(0, 160) || null;
  if (!["doctor", "staff"].includes(personType || "") || !Number.isInteger(personId) || personId <= 0 || !request.body) return error("بيانات المستند غير صحيحة.", 400);
  const exists = personType === "doctor"
    ? await db.selectFrom("doctors").select("id").where("id", "=", personId).executeTakeFirst()
    : await db.selectFrom("hr_staff").select("id").where("id", "=", personId).executeTakeFirst();
  if (!exists) return error("الشخص غير موجود.", 404);
  const originalName = cleanName(request.headers.get("x-file-name"));
  const extension = path.extname(originalName).toLowerCase();
  const contentType = request.headers.get("content-type")?.split(";", 1)[0].toLowerCase() || "";
  if (!EXTENSIONS.has(extension) || !(contentType.startsWith("image/") || contentType === "application/pdf")) return error("يسمح بالصور وPDF فقط.", 415);
  const folder = path.join(ROOT, personType!, String(personId));
  await fs.mkdir(folder, { recursive: true });
  const storedName = `${Date.now()}-${randomUUID()}-${originalName}`;
  const finalPath = path.join(folder, storedName);
  const temporaryPath = `${finalPath}.part`;
  try {
    await pipeline(
      Readable.fromWeb(request.body as import("node:stream/web").ReadableStream),
      new ByteLimitTransform(MAX_DOCUMENT_BYTES),
      createWriteStream(temporaryPath, { flags: "wx" }),
    );
    const written = await fs.stat(temporaryPath);
    if (written.size <= 0) throw new Error("empty document");
    if (written.size > MAX_DOCUMENT_BYTES) {
      await fs.unlink(temporaryPath).catch(() => {});
      return error(`أقصى حجم للمستند ${Math.round(MAX_DOCUMENT_BYTES / (1024 * 1024))} ميجابايت.`, 413);
    }
    if (!(await hasExpectedSignature(temporaryPath, extension))) {
      await fs.unlink(temporaryPath).catch(() => {});
      return error("محتوى الملف لا يطابق نوع الصورة أو PDF المحدد.", 415);
    }
    await fs.rename(temporaryPath, finalPath);
    await db.insertInto("hr_documents").values({
      person_type: personType as "doctor" | "staff", person_id: personId,
      document_type: documentType, label, original_name: originalName,
      file_path: `/patient-files/hr-documents/${personType}/${personId}/${storedName}`,
      uploaded_by: session.userId,
    }).execute();
    return NextResponse.json({ ok: true });
  } catch (cause) {
    await fs.unlink(temporaryPath).catch(() => {});
    await fs.unlink(finalPath).catch(() => {});
    if (cause instanceof UploadTooLargeError) {
      return error(`أقصى حجم للمستند ${Math.round(MAX_DOCUMENT_BYTES / (1024 * 1024))} ميجابايت.`, 413);
    }
    console.error("HR document upload failed", cause);
    return error("تعذر حفظ المستند.", 500);
  }
}
