import { NextRequest, NextResponse } from "next/server";
import { createReadStream, createWriteStream } from "node:fs";
import fs from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { ByteLimitTransform, UploadTooLargeError, assertContentLengthWithinLimit } from "@/lib/limited-upload";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const UPLOAD_ROOT = process.env.CLINIC_UPLOAD_DIR
  ? path.join(path.resolve(process.env.CLINIC_UPLOAD_DIR), "patients")
  : path.join(process.cwd(), "data", "uploads", "patients");

const ALLOWED_EXTENSIONS = new Set([".jpg", ".jpeg", ".png", ".gif", ".webp", ".pdf"]);
const MAX_CHUNK_BYTES = 768 * 1024;
const MAX_FILE_BYTES = 250 * 1024 * 1024;
const MAX_CHUNKS = 512;
const UPLOAD_ID_PATTERN = /^[a-f0-9-]{36}$/i;
const STALE_CHUNK_MS = 24 * 60 * 60 * 1000;

function jsonError(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

function safeOriginalName(encodedName: string | null) {
  let decoded = "file";
  try { decoded = decodeURIComponent(encodedName || "file"); } catch {}
  const clean = path.basename(decoded).replace(/[^a-zA-Z0-9._-]/g, "_").slice(-160) || "file";
  return clean;
}

async function hasExpectedSignature(file: string, extension: string) {
  const handle = await fs.open(file, "r");
  try {
    const header = Buffer.alloc(12);
    const { bytesRead } = await handle.read(header, 0, header.length, 0);
    const bytes = header.subarray(0, bytesRead);
    if (extension === ".jpg" || extension === ".jpeg") return bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
    if (extension === ".png") return bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
    if (extension === ".gif") return bytes.subarray(0, 6).toString("ascii") === "GIF87a" || bytes.subarray(0, 6).toString("ascii") === "GIF89a";
    if (extension === ".webp") return bytes.subarray(0, 4).toString("ascii") === "RIFF" && bytes.subarray(8, 12).toString("ascii") === "WEBP";
    if (extension === ".pdf") return bytes.subarray(0, 5).toString("ascii") === "%PDF-";
    return false;
  } finally {
    await handle.close();
  }
}

async function cleanupStaleChunks(patientId: number) {
  const patientChunkRoot = path.join(UPLOAD_ROOT, ".chunks", String(patientId));
  const entries = await fs.readdir(patientChunkRoot, { withFileTypes: true }).catch(() => []);
  const cutoff = Date.now() - STALE_CHUNK_MS;
  await Promise.all(entries.filter((entry) => entry.isDirectory()).map(async (entry) => {
    const directory = path.join(patientChunkRoot, entry.name);
    const stat = await fs.stat(directory).catch(() => null);
    if (stat && stat.mtimeMs < cutoff) await fs.rm(directory, { recursive: true, force: true });
  }));
}

export async function POST(request: NextRequest) {
  const session = await getSession();
  if (!session) return jsonError("انتهت الجلسة. سجل الدخول ثم حاول مرة أخرى.", 401);
  const canUpload = ["doctor", "admin", "clinic_manager"].includes(session.role)
    || await hasPermission(session.userId, session.role, "upload_ortho_photos");
  if (!canUpload) return jsonError("ليس لديك صلاحية رفع صور المرضى.", 403);
  try {
    assertContentLengthWithinLimit(request.headers.get("content-length"), MAX_CHUNK_BYTES);
  } catch {
    return jsonError("جزء الملف أكبر من الحد المسموح.", 413);
  }

  const patientId = Number(request.nextUrl.searchParams.get("patientId"));
  const requestedGroupId = Number(request.nextUrl.searchParams.get("groupId"));
  const takenAt = String(request.nextUrl.searchParams.get("takenAt") || "").trim();
  const label = String(request.nextUrl.searchParams.get("label") || "").trim().slice(0, 300) || null;
  const uploadId = String(request.nextUrl.searchParams.get("uploadId") || "").trim();
  const chunkIndex = Number(request.nextUrl.searchParams.get("chunkIndex"));
  const chunkCount = Number(request.nextUrl.searchParams.get("chunkCount"));
  const fileSize = Number(request.nextUrl.searchParams.get("fileSize"));
  if (!Number.isInteger(patientId) || patientId <= 0 || !/^\d{4}-\d{2}-\d{2}$/.test(takenAt)) {
    return jsonError("بيانات المريض أو التاريخ غير صحيحة.", 400);
  }
  if (!UPLOAD_ID_PATTERN.test(uploadId)
    || !Number.isInteger(chunkIndex) || chunkIndex < 0
    || !Number.isInteger(chunkCount) || chunkCount < 1 || chunkCount > MAX_CHUNKS
    || chunkIndex >= chunkCount
    || !Number.isInteger(fileSize) || fileSize < 1 || fileSize > MAX_FILE_BYTES) {
    return jsonError("بيانات أجزاء الملف غير صحيحة.", 400);
  }
  const patient = await db.selectFrom("patients").select("id").where("id", "=", patientId).executeTakeFirst();
  if (!patient) return jsonError("المريض غير موجود.", 404);

  let groupId: number | null = Number.isInteger(requestedGroupId) && requestedGroupId > 0 ? requestedGroupId : null;
  if (groupId != null) {
    const group = await db.selectFrom("patient_image_groups").select("id").where("id", "=", groupId).where("patient_id", "=", patientId).executeTakeFirst();
    if (!group) return jsonError("مجموعة الصور غير موجودة.", 404);
  }

  if (!request.body) return jsonError("الملف فارغ.", 400);
  const originalName = safeOriginalName(request.headers.get("x-file-name"));
  const extension = path.extname(originalName).toLowerCase();
  const contentType = request.headers.get("content-type")?.split(";", 1)[0].toLowerCase() || "";
  // بعض هواتف iOS/Android ترسل النوع فارغًا أو application/octet-stream؛
  // الامتداد المسموح وتوقيع أول جزء أدناه يظلان خط الدفاع الفعلي.
  const isAllowedType = contentType.startsWith("image/") || contentType === "application/pdf" || contentType === "application/octet-stream";
  if (!ALLOWED_EXTENSIONS.has(extension) || !isAllowedType) return jsonError("يسمح بالصور وملفات PDF فقط.", 415);

  const patientDir = path.join(UPLOAD_ROOT, String(patientId));
  await fs.mkdir(patientDir, { recursive: true });
  await cleanupStaleChunks(patientId);
  const finalName = `${uploadId}-${originalName}`;
  const finalPath = path.join(patientDir, finalName);
  const publicPath = `/patient-files/patients/${patientId}/${finalName}`;
  const chunkDir = path.join(UPLOAD_ROOT, ".chunks", String(patientId), uploadId);
  const chunkPath = path.join(chunkDir, `${String(chunkIndex).padStart(4, "0")}.part`);
  const receivingPath = `${chunkPath}.${randomUUID()}.receiving`;
  const assemblingPath = `${finalPath}.assembling`;

  let createdGroup = false;
  try {
    // إعادة إرسال آخر جزء بعد انقطاع الرد لا تنشئ صورة أو مجموعة مكررة.
    const existing = await db.selectFrom("patient_images")
      .innerJoin("patient_image_groups", "patient_image_groups.id", "patient_images.group_id")
      .select("patient_images.group_id")
      .where("patient_images.file_path", "=", publicPath)
      .where("patient_image_groups.patient_id", "=", patientId)
      .executeTakeFirst();
    if (existing) return NextResponse.json({ ok: true, complete: true, groupId: existing.group_id });

    await fs.mkdir(chunkDir, { recursive: true });
    await pipeline(
      Readable.fromWeb(request.body as import("node:stream/web").ReadableStream),
      new ByteLimitTransform(MAX_CHUNK_BYTES),
      createWriteStream(receivingPath, { flags: "wx" }),
    );
    const received = await fs.stat(receivingPath);
    if (received.size <= 0 || received.size > MAX_CHUNK_BYTES) throw new Error("invalid chunk size");
    if (chunkIndex === 0 && !await hasExpectedSignature(receivingPath, extension)) {
      await fs.unlink(receivingPath);
      return jsonError("محتوى الملف لا يطابق نوع الصورة أو PDF المحدد.", 415);
    }

    const saved = await fs.stat(chunkPath).catch(() => null);
    if (saved?.size !== received.size) {
      if (saved) await fs.unlink(chunkPath);
      await fs.rename(receivingPath, chunkPath);
    } else {
      await fs.unlink(receivingPath);
    }

    if (chunkIndex !== chunkCount - 1) {
      return NextResponse.json({ ok: true, complete: false });
    }

    const chunkPaths = Array.from({ length: chunkCount }, (_, index) => path.join(chunkDir, `${String(index).padStart(4, "0")}.part`));
    const stats = await Promise.all(chunkPaths.map((file) => fs.stat(file)));
    if (stats.some((stat) => stat.size <= 0 || stat.size > MAX_CHUNK_BYTES)
      || stats.reduce((total, stat) => total + stat.size, 0) !== fileSize) {
      throw new Error("incomplete upload");
    }

    await fs.unlink(assemblingPath).catch(() => {});
    for (let index = 0; index < chunkPaths.length; index += 1) {
      await pipeline(createReadStream(chunkPaths[index]), createWriteStream(assemblingPath, { flags: index === 0 ? "wx" : "a" }));
    }
    await fs.rename(assemblingPath, finalPath);

    if (groupId == null) {
      const group = await db.insertInto("patient_image_groups").values({ patient_id: patientId, taken_at: takenAt, label }).executeTakeFirstOrThrow();
      groupId = Number(group.insertId);
      createdGroup = true;
    }
    await db.insertInto("patient_images").values({ group_id: groupId, file_path: publicPath }).execute();
    await fs.rm(chunkDir, { recursive: true, force: true });
    return NextResponse.json({ ok: true, complete: true, groupId });
  } catch (error) {
    await fs.unlink(receivingPath).catch(() => {});
    await fs.unlink(assemblingPath).catch(() => {});
    // لو وصل الملف النهائي إلى القرص ثم فشل قيد قاعدة البيانات فقط، نحذفه؛
    // أما الأجزاء فتظل لإعادة المحاولة بدل بدء الملف الكبير من الصفر.
    await fs.unlink(finalPath).catch(() => {});
    if (createdGroup && groupId != null) {
      await db.deleteFrom("patient_image_groups").where("id", "=", groupId).execute().catch(() => {});
    }
    if (error instanceof UploadTooLargeError) return jsonError("جزء الملف أكبر من الحد المسموح.", 413);
    console.error("Patient file upload failed", error);
    return jsonError("تعذر حفظ الملف. لم يتوقف النظام ويمكنك إعادة المحاولة.", 500);
  }
}
