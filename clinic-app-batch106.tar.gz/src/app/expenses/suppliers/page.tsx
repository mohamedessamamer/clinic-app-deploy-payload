import Link from "next/link";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getClinicToday } from "@/lib/clinic-date";
import {
  addSupplierInvoiceAction,
  recordSupplierGeneralPaymentAction,
  recordSupplierInvoicePaymentAction,
} from "../actions";

const inputClass = "w-full rounded border border-border bg-background px-2 py-1.5 text-sm";

// نفس رسايل الفشل الصامتة اللي بترجع في ?err= من expenseError في actions.ts.
const SUPPLIER_ERRORS: Record<string, string> = {
  supplier: "المورد أو الفاتورة غير صحيحة.",
  amount: "المبلغ لازم يكون رقم أكبر من صفر.",
  date: "التاريخ غير صحيح.",
};

export default async function SuppliersPage({ searchParams }: { searchParams: Promise<{ err?: string }> }) {
  const session = await getSession();
  const canManage = session ? await hasPermission(session.userId, session.role, "manage_expenses") : false;
  if (!session || !canManage) return <div className="card-3d rounded-xl p-5 text-sm text-muted">مفيش صلاحية عندك لعرض الموردين.</div>;

  const params = await searchParams;
  const errorMessage = params.err ? SUPPLIER_ERRORS[params.err] || "البيانات غير مكتملة أو غير صحيحة." : null;
  const today = getClinicToday();

  const [suppliers, invoices, payments] = await Promise.all([
    db.selectFrom("inventory_suppliers").select(["id", "name", "is_ortho", "is_general"]).where("active", "=", 1).orderBy("name").execute(),
    db.selectFrom("supplier_invoices").selectAll().orderBy("invoice_date", "desc").orderBy("id", "desc").execute(),
    db.selectFrom("supplier_payments").selectAll().execute(),
  ]);

  const invoicesBySupplier = new Map<number, typeof invoices>();
  for (const invoice of invoices) {
    invoicesBySupplier.set(invoice.supplier_id, [...(invoicesBySupplier.get(invoice.supplier_id) ?? []), invoice]);
  }
  const paymentsByInvoice = new Map<number, number>();
  const paymentsBySupplier = new Map<number, number>();
  for (const payment of payments) {
    paymentsBySupplier.set(payment.supplier_id, Math.round(((paymentsBySupplier.get(payment.supplier_id) ?? 0) + payment.amount) * 100) / 100);
    if (payment.invoice_id != null) {
      paymentsByInvoice.set(payment.invoice_id, Math.round(((paymentsByInvoice.get(payment.invoice_id) ?? 0) + payment.amount) * 100) / 100);
    }
  }

  // المديونية = مجموع فواتير المورد - مجموع كل دفعاته (مرتبطة بفاتورة أو
  // عامة)، بنفس منطق حساب "الباقي" في الفواتير: تقريب لأقرب قرش في كل خطوة
  // حتى لا تتراكم فروق كسرية بين المبالغ.
  const debtBySupplier = new Map<number, number>();
  for (const supplier of suppliers) {
    const totalInvoices = Math.round((invoicesBySupplier.get(supplier.id) ?? []).reduce((sum, invoice) => sum + invoice.amount, 0) * 100) / 100;
    const totalPayments = paymentsBySupplier.get(supplier.id) ?? 0;
    debtBySupplier.set(supplier.id, Math.round((totalInvoices - totalPayments) * 100) / 100);
  }

  return <div className="space-y-6">
    {errorMessage && <p className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{errorMessage}</p>}
    <div className="flex items-start justify-between gap-4 flex-wrap">
      <div><h1 className="text-2xl font-bold">الموردين</h1><p className="mt-1 text-sm text-muted">فواتير ودفعات كل مورد. المورد نفسه يُعرَّف من شاشة المخزن.</p></div>
      <Link href="/expenses" className="rounded-md border border-border px-3 py-2 text-sm hover:bg-primary-soft">رجوع للمصروفات</Link>
    </div>

    {suppliers.length === 0 && <div className="card-3d rounded-xl p-5 text-sm text-muted">لا يوجد موردون بعد — عرّف موردًا من شاشة المخزن أولًا.</div>}

    <div className="space-y-4">
      {suppliers.map((supplier) => {
        const supplierInvoices = invoicesBySupplier.get(supplier.id) ?? [];
        const debt = debtBySupplier.get(supplier.id) ?? 0;
        const tags = [supplier.is_ortho ? "تقويم" : null, supplier.is_general ? "جينيرال" : null].filter(Boolean).join(" و ");
        return <section key={supplier.id} className="card-3d rounded-xl p-5 space-y-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h2 className="font-semibold">{supplier.name}{tags && <span className="text-xs text-muted"> ({tags})</span>}</h2>
            </div>
            <div className="text-right">
              <div className="text-xs text-muted">المديونية</div>
              <div className={`text-xl font-bold ${debt > 0 ? "text-danger" : "text-primary"}`}>{debt.toFixed(0)} ج.م</div>
            </div>
          </div>

          <details className="rounded-lg border border-border p-3">
            <summary className="cursor-pointer text-sm font-medium">إضافة فاتورة جديدة</summary>
            <form action={addSupplierInvoiceAction} className="mt-3 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-2 items-end">
              <input type="hidden" name="supplier_id" value={supplier.id} />
              <label><span className="block text-xs text-muted mb-1">رقم الفاتورة (اختياري)</span><input name="invoice_number" className={inputClass} /></label>
              <label><span className="block text-xs text-muted mb-1">قيمة الفاتورة *</span><input name="amount" type="number" min="0.01" step="0.01" required className={inputClass} /></label>
              <label><span className="block text-xs text-muted mb-1">التاريخ</span><input name="invoice_date" type="date" defaultValue={today} className={inputClass} /></label>
              <button className="rounded-md btn-3d-primary px-3 py-1.5 text-sm font-medium">حفظ الفاتورة</button>
            </form>
          </details>

          <details className="rounded-lg border border-border p-3">
            <summary className="cursor-pointer text-sm font-medium">تسجيل دفعة عامة (بدون ربط بفاتورة)</summary>
            <form action={recordSupplierGeneralPaymentAction} className="mt-3 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-2 items-end">
              <input type="hidden" name="supplier_id" value={supplier.id} />
              <label><span className="block text-xs text-muted mb-1">المبلغ *</span><input name="amount" type="number" min="0.01" step="0.01" required className={inputClass} /></label>
              <label><span className="block text-xs text-muted mb-1">التاريخ</span><input name="payment_date" type="date" defaultValue={today} className={inputClass} /></label>
              <label className="xl:col-span-2"><span className="block text-xs text-muted mb-1">ملاحظة</span><input name="notes" className={inputClass} /></label>
              <button className="rounded-md border border-primary px-3 py-1.5 text-sm text-primary hover:bg-primary-soft">تسجيل الدفعة (تُسجَّل أيضًا كمصروف)</button>
            </form>
          </details>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-primary-soft text-primary-dark">
                <tr>
                  <th className="px-3 py-2 text-right">التاريخ</th>
                  <th className="px-3 py-2 text-right">رقم الفاتورة</th>
                  <th className="px-3 py-2 text-right">القيمة</th>
                  <th className="px-3 py-2 text-right">المدفوع</th>
                  <th className="px-3 py-2 text-right">المتبقي</th>
                  <th className="px-3 py-2 text-right">تسجيل دفعة</th>
                </tr>
              </thead>
              <tbody>
                {supplierInvoices.map((invoice) => {
                  const paid = paymentsByInvoice.get(invoice.id) ?? 0;
                  const remaining = Math.round((invoice.amount - paid) * 100) / 100;
                  return <tr key={invoice.id} className="border-t border-border">
                    <td className="px-3 py-2 whitespace-nowrap">{invoice.invoice_date}</td>
                    <td className="px-3 py-2">{invoice.invoice_number ?? "-"}</td>
                    <td className="px-3 py-2">{invoice.amount.toFixed(0)} ج.م</td>
                    <td className="px-3 py-2">{paid.toFixed(0)} ج.م</td>
                    <td className={`px-3 py-2 ${remaining > 0 ? "text-danger" : "text-primary"}`}>{remaining.toFixed(0)} ج.م</td>
                    <td className="px-3 py-2">
                      {remaining > 0 && <form action={recordSupplierInvoicePaymentAction} className="flex flex-wrap gap-1 items-end">
                        <input type="hidden" name="supplier_id" value={supplier.id} />
                        <input type="hidden" name="invoice_id" value={invoice.id} />
                        <input name="amount" type="number" min="0.01" step="0.01" max={remaining} required placeholder="المبلغ" className="w-24 rounded border border-border bg-background px-2 py-1 text-xs" />
                        <input name="payment_date" type="date" defaultValue={today} className="rounded border border-border bg-background px-2 py-1 text-xs" />
                        <button className="rounded border border-border px-2 py-1 text-xs hover:bg-primary-soft">تسجيل دفعة</button>
                      </form>}
                    </td>
                  </tr>;
                })}
                {supplierInvoices.length === 0 && <tr><td colSpan={6} className="px-3 py-5 text-center text-muted">لا توجد فواتير لهذا المورد.</td></tr>}
              </tbody>
            </table>
          </div>
        </section>;
      })}
    </div>
  </div>;
}
