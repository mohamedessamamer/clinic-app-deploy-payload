"use server";

import { redirect } from "next/navigation";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { isThreePartName, isValidBirthDate } from "@/lib/patient-details";
import { isValidPatientPhone, normalizePhoneNumber } from "@/lib/phone";

async function nextFileNumber(executor: typeof db = db) {
  const last = await executor
    .selectFrom("patients")
    .select("file_number")
    .orderBy("id", "desc")
    .limit(1)
    .executeTakeFirst();
  const lastNum = last ? parseInt(last.file_number.replace(/\D/g, ""), 10) || 0 : 0;
  return `P-${String(lastNum + 1).padStart(4, "0")}`;
}

export type CreatePatientState = { error?: "name" | "birth_date" | "phone" | "unauthorized" | "duplicate" };

export async function createPatientAction(_previous: CreatePatientState, formData: FormData): Promise<CreatePatientState> {
  // كل server action لازم يتحقق بنفسه: Next بينادي الأكشن برقم معرّفه مش
  // بالمسار، فمينفعش نعتمد على حماية proxy.ts للصفحة اللي فيها الفورم.
  const session = await getSession();
  if (!session) return { error: "unauthorized" };

  const full_name = String(formData.get("full_name") || "").trim();
  const birth_date = String(formData.get("birth_date") || "").trim() || null;
  const phone_country_code = String(formData.get("phone_country_code") || "+20").trim();
  const phone = normalizePhoneNumber(String(formData.get("phone") || "")) || null;
  const address = String(formData.get("address") || "").trim() || null;

  // نعيد الخطأ داخل نفس الفورم بدلاً من redirect. بهذه الطريقة تظل كل البيانات
  // التي كتبها الموظف كما هي ولا يضطر لإعادة الاسم أو تاريخ الميلاد.
  if (!isThreePartName(full_name)) return { error: "name" };
  if (!isValidBirthDate(birth_date)) return { error: "birth_date" };
  if (!phone || !isValidPatientPhone(phone_country_code, phone)) return { error: "phone" };

  // رقم الملف بيتحسب من آخر صف، و patients.file_number عليه قيد UNIQUE — يعني
  // موظفين استقبال بيسجّلوا مريضين في نفس اللحظة كانوا ممكن يقروا نفس الرقم
  // فيفشل واحد فيهم بخطأ قاعدة بيانات خام والبيانات المكتوبة تضيع. القراءة
  // والإدراج بقوا في معاملة واحدة، مع إعادة محاولة محدودة لو حصل تضارب برضه.
  let insertId: number | bigint | undefined;
  for (let attempt = 0; attempt < 5; attempt += 1) {
    try {
      insertId = await db.transaction().execute(async (trx) => {
        const file_number = await nextFileNumber(trx as typeof db);
        // age القديم بيفضل null للمرضى الجداد كلهم — السن دلوقتي بيتحسب من
        // birth_date وقت العرض (شوف src/lib/age.ts)، مش بيتخزن كرقم ثابت.
        const inserted = await trx
          .insertInto("patients")
          .values({ file_number, full_name, age: null, birth_date, phone_country_code, phone, address })
          .executeTakeFirst();
        return inserted.insertId;
      });
      break;
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (!message.includes("UNIQUE") || attempt === 4) throw error;
    }
  }

  if (insertId == null) return { error: "duplicate" };

  redirect(`/patients/${insertId}`);
}
