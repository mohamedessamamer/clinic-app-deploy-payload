"use server";

import { revalidatePath } from "next/cache";
import path from "node:path";
import fs from "node:fs/promises";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { logAdminEvent } from "@/lib/audit";
import { returnInventoryItem } from "@/lib/inventory-stock";

// نفس مسار الرفع المستخدم في src/app/patients/[id]/actions.ts (لازم يتطابق بالظبط
// عشان مسح ملفات الصور من على القرص يشتغل صح).
const UPLOAD_ROOT = process.env.CLINIC_UPLOAD_DIR
  ? path.join(path.resolve(process.env.CLINIC_UPLOAD_DIR), "patients")
  : path.join(process.cwd(), "data", "uploads", "patients");

// بيمسح مريض (حالة) نهائيًا من النظام مع كل بياناته المرتبطة (زيارات، فواتيرها،
// مواعيد، مجموعات الصور/الأشعة والملفات نفسها على القرص) — للأدمن بس (فحص مباشر
// على الدور، مش عن طريق نظام الصلاحيات المرن العادي، لأن ده تحديدًا مطلوب يفضل
// حكرًا على الأدمن دايمًا من غير إمكانية منحه لحد تاني بالغلط). الهدف الأساسي:
// تنظيف حالات تجربة (test) اتعملت أثناء تجربة النظام. عملية لا رجعة فيها خالص —
// التأكيد بيحصل في الواجهة (window.confirm) قبل ما الأكشن ده يتستدعى أصلاً.
export async function deletePatientAction(formData: FormData): Promise<{ ok: boolean; reason?: string }> {
  const session = await getSession();
  if (!session || session.role !== "admin") return { ok: false, reason: "الحذف متاح للأدمن فقط." };

  const patientId = Number(formData.get("patient_id"));
  if (!patientId) return { ok: false, reason: "بيانات المريض غير صالحة." };

  // حذف المريض عملية لا رجعة فيها بالكامل: بتمسح المريض ومواعيده وزياراته
  // وفواتيره وصوره (ومن على القرص كمان) وشارتات التقويم وأرصدته. لازم نقرا
  // بياناته ونعدّ اللي هيتمسح *قبل* المعاملة — بعدها مفيش منين نجيبهم، وكان
  // بيحصل من غير ما يفضل أي أثر يقول إنه حصل أصلاً.
  const patientRow = await db
    .selectFrom("patients")
    .select(["file_number", "full_name", "phone"])
    .where("id", "=", patientId)
    .executeTakeFirst();
  if (!patientRow) return { ok: false, reason: "المريض ده مش موجود." };

  const [visitCount, invoiceCount, appointmentCount] = await Promise.all([
    db.selectFrom("visits").select(db.fn.countAll<number>().as("count")).where("patient_id", "=", patientId).executeTakeFirst(),
    db.selectFrom("invoices").select(db.fn.countAll<number>().as("count")).where("patient_id", "=", patientId).executeTakeFirst(),
    db.selectFrom("appointments").select(db.fn.countAll<number>().as("count")).where("patient_id", "=", patientId).executeTakeFirst(),
  ]);

  // لازم نجيب مسارات ملفات الصور من قاعدة البيانات قبل ما نمسح صفوفها، عشان نقدر
  // نمسح الملفات نفسها من على القرص بعد كده.
  const imageRows = await db
    .selectFrom("patient_images")
    .innerJoin("patient_image_groups", "patient_image_groups.id", "patient_images.group_id")
    .select(["patient_images.file_path"])
    .where("patient_image_groups.patient_id", "=", patientId)
    .execute();

  await db.transaction().execute(async (trx) => {
    const patientVisits = await trx.selectFrom("visits").select("id").where("patient_id", "=", patientId).execute();
    const visitIds = patientVisits.map((v) => v.id);
    const patientInvoices = await trx.selectFrom("invoices").select("id").where("patient_id", "=", patientId).execute();
    const invoiceIds = patientInvoices.map((invoice) => invoice.id);
    const patientAppointments = await trx.selectFrom("appointments").select("id").where("patient_id", "=", patientId).execute();
    const appointmentIds = patientAppointments.map((a) => a.id);

    const patientImageGroups = await trx
      .selectFrom("patient_image_groups")
      .select("id")
      .where("patient_id", "=", patientId)
      .execute();
    const groupIds = patientImageGroups.map((g) => g.id);
    // حالات الإشعارات باقية عمدًا بعد اختفاء إشعار الجرس 48 ساعة، ولذلك يجب
    // حذفها مع الإشعارات المرتبطة أولًا عند حذف ملف المريض. غياب الخطوتين دول
    // كان يخلّي SQLite يرفض حذف بعض المرضى رغم تنظيف المواعيد والفواتير.
    const notificationCases = await trx
      .selectFrom("notification_cases")
      .select("id")
      .where("patient_id", "=", patientId)
      .execute();
    const notificationCaseIds = notificationCases.map((row) => row.id);

    await trx.deleteFrom("notifications").where("patient_id", "=", patientId).execute();
    if (notificationCaseIds.length > 0) {
      await trx.deleteFrom("notifications").where("notification_case_id", "in", notificationCaseIds).execute();
      await trx.deleteFrom("notification_cases").where("id", "in", notificationCaseIds).execute();
    }

    // دفتر حركة البراكتس (orthodontic_bracket_stock_movements) له مفتاح خارجي
    // مستقل على المريض نفسه وعلى ortho_visits — من غير حذفه هنا كان الحذف يفشل
    // بـ FOREIGN KEY constraint (وده اللي كان بيكرش السيرفر) لأي حالة تقويم
    // استُخدم فيها براكتس. قبل ما نمسح سطور الدفتر، نرجّع أي كمية اتخصمت
    // فعليًا (ortho_use) للرصيد الحالي — حذف ملف المريض إداريًا متأخر مايعملش
    // نقص وهمي دائم في مخزون البراكتس.
    const bracketConsumption = await trx
      .selectFrom("orthodontic_bracket_stock_movements")
      .select(["brand", "fdi", (eb) => eb.fn.sum<number>("quantity").as("total")])
      .where("patient_id", "=", patientId)
      .where("movement_type", "=", "ortho_use")
      .groupBy(["brand", "fdi"])
      .execute();
    for (const row of bracketConsumption) {
      const total = Number(row.total ?? 0); // سالب (كل استخدام مسجل بـ -1)
      if (total < 0) {
        await trx
          .updateTable("orthodontic_bracket_stock")
          .set((eb) => ({ quantity: eb("quantity", "-", total), updated_at: new Date().toISOString() }))
          .where("brand", "=", row.brand as string)
          .where("fdi", "=", row.fdi as number)
          .execute();
      }
    }
    await trx.deleteFrom("orthodontic_bracket_stock_movements").where("patient_id", "=", patientId).execute();

    // نفس المبدأ لدفتر حركة المخزن العام (inventory_stock_movements) المربوط
    // بالموعد (appointment_id) — كان برضه بيفشل الحذف لنفس السبب لأي موعد
    // "تم" اتسجل عليه استهلاك مخزن. نرجّع الكمية المستهلكة قبل الحذف بنفس
    // منطق زرار "إرجاع للمخزون" العادي (returnInventoryItem) عشان دفاتر
    // التوريد (batches) تفضل متطابقة مع رصيد الصنف.
    if (appointmentIds.length > 0) {
      const inventoryConsumption = await trx
        .selectFrom("inventory_stock_movements")
        .innerJoin("inventory_items", "inventory_items.id", "inventory_stock_movements.item_id")
        .select([
          "inventory_stock_movements.item_id",
          "inventory_items.name",
          (eb) => eb.fn.sum<number>("inventory_stock_movements.quantity").as("total"),
        ])
        .where("inventory_stock_movements.appointment_id", "in", appointmentIds)
        .where("inventory_stock_movements.movement_type", "in", ["ortho_use", "general_consumption"])
        .groupBy(["inventory_stock_movements.item_id", "inventory_items.name"])
        .execute();
      for (const row of inventoryConsumption) {
        const total = Number(row.total ?? 0); // سالب
        if (total < 0) {
          await returnInventoryItem(trx, {
            itemId: row.item_id,
            quantity: -total,
            note: `إرجاع تلقائي بعد حذف حالة المريض #${patientId} (${row.name})`,
            createdBy: session.userId,
          });
        }
      }
      await trx.deleteFrom("inventory_stock_movements").where("appointment_id", "in", appointmentIds).execute();
    }

    // بيانات التقويم لها مفاتيح خارجية مستقلة عن visits العادي؛ من غير حذفها
    // الأول كانت بعض الحالات (مثل عائشة حسن/عماد السيد) تفشل عند حذف المريض.
    await trx.deleteFrom("ortho_inventory_deductions").where("patient_id", "=", patientId).execute();
    await trx.deleteFrom("ortho_visits").where("patient_id", "=", patientId).execute();
    await trx.deleteFrom("orthodontic_charts").where("patient_id", "=", patientId).execute();
    await trx.deleteFrom("collection_requests").where("patient_id", "=", patientId).execute();
    await trx.deleteFrom("patient_credits").where("patient_id", "=", patientId).execute();

    // فك أي إشارة "دفعة متابعة" قبل حذف الفواتير. مهم أن يشمل ذلك أي سجل قديم
    // لمريض آخر اتربط بالخطأ بفاتورة هذا المريض؛ وإلا تمنع FK حذف الحالة كلها.
    if (invoiceIds.length > 0) {
      await trx.updateTable("invoices").set({ parent_invoice_id: null }).where("parent_invoice_id", "in", invoiceIds).execute();
      await trx.updateTable("appointments").set({ purpose_linked_invoice_id: null }).where("purpose_linked_invoice_id", "in", invoiceIds).execute();
    }
    if (visitIds.length > 0) {
      await trx.updateTable("invoices").set({ parent_invoice_id: null }).where("visit_id", "in", visitIds).execute();
    }
    await trx.updateTable("invoices").set({ parent_invoice_id: null }).where("patient_id", "=", patientId).execute();

    if (groupIds.length > 0) {
      await trx.deleteFrom("patient_images").where("group_id", "in", groupIds).execute();
    }
    await trx.deleteFrom("patient_image_groups").where("patient_id", "=", patientId).execute();

    if (visitIds.length > 0) {
      await trx.deleteFrom("invoices").where("visit_id", "in", visitIds).execute();
    }
    await trx.deleteFrom("invoices").where("patient_id", "=", patientId).execute();
    await trx.deleteFrom("visits").where("patient_id", "=", patientId).execute();
    await trx.deleteFrom("appointments").where("patient_id", "=", patientId).execute();
    await trx.deleteFrom("patients").where("id", "=", patientId).execute();
  });

  await logAdminEvent({
    entityType: "patient",
    entityId: patientId,
    event: "delete_patient",
    details: `حذف نهائي للمريض ${patientRow.full_name} (ملف ${patientRow.file_number}${patientRow.phone ? ` — ${patientRow.phone}` : ""}) ومعه ${Number(visitCount?.count ?? 0)} زيارة و${Number(invoiceCount?.count ?? 0)} فاتورة و${Number(appointmentCount?.count ?? 0)} موعد و${imageRows.length} صورة`,
    changedBy: session.userId,
  });

  // مسح ملفات الصور نفسها من على القرص - best-effort زي deleteImageAction، لو فايل
  // مش موجود أصلاً منسيبش الحذف كله يفشل بسبب كده.
  for (const row of imageRows) {
    if (!row.file_path.startsWith("/patient-files/")) continue;
    const relative = row.file_path.replace(/^\/patient-files\//, "");
    const filePath = path.join(path.dirname(UPLOAD_ROOT), relative);
    await fs.unlink(filePath).catch(() => {});
  }

  revalidatePath("/patients");
  revalidatePath("/front-desk");
  revalidatePath("/invoices");
  revalidatePath("/");
  return { ok: true };
}
