"use server";

import fs from "node:fs/promises";
import path from "node:path";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getClinicToday } from "@/lib/clinic-date";
import { logAdminEvent } from "@/lib/audit";
import { redirect } from "next/navigation";

// الفشل الصامت كان أكتر شكوى متكررة: المستخدم بيملا الفورم، يدوس حفظ، ومفيش
// أي حاجة تحصل ولا رسالة. الأكشنات دي بتتنادى من <form action={...}> مباشرة،
// والفورم مبيقدرش يستقبل قيمة راجعة — فبنحوّل لصفحة /hr ومعاها كود الخطأ،
// والصفحة بتعرض الرسالة. نفس الأسلوب المستخدم في الإعدادات (roomerror).
function hrError(code: string): never {
  redirect(`/hr?err=${code}`);
}

function value(formData: FormData, key: string) { return String(formData.get(key) ?? "").trim(); }
function amount(formData: FormData, key: string) {
  const number = Number(formData.get(key));
  return Number.isFinite(number) && number >= 0 ? Math.round(number * 100) / 100 : null;
}
function validDate(date: string) { return /^\d{4}-\d{2}-\d{2}$/.test(date); }

async function canManageHr() {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "manage_hr"))) return null;
  return session;
}

export type HrActionResult = { ok: boolean; reason?: string };

function refresh() { revalidatePath("/hr"); revalidatePath("/expenses"); }

export async function addHrStaffAction(formData: FormData) {
  const session = await canManageHr();
  if (!session) return;
  const fullName = value(formData, "full_name");
  const staffGroup = value(formData, "staff_group");
  if (!fullName) hrError("name");

  // طبيب مضاف من هنا مباشرة لجدول doctors، بدون حساب دخول ولا بيانات توظيف
  // (دي مخصوصة للموظف/التمريض في hr_staff). لو عايز تربطه بحساب دخول كمان،
  // استخدم "إضافة طبيب" من الإعدادات — ده بيعمل الاتنين مع بعض.
  if (staffGroup === "doctor") {
    await db.insertInto("doctors").values({ full_name: fullName, active: 1 }).execute();
    refresh();
    return;
  }

  const employmentStart = value(formData, "employment_start");
  const linkedRaw = Number(formData.get("linked_user_id"));
  const linkedUserId = Number.isInteger(linkedRaw) && linkedRaw > 0 ? linkedRaw : null;
  if (!["employee", "nursing"].includes(staffGroup)) hrError("group");
  if (!validDate(employmentStart)) hrError("startdate");
  if (linkedUserId && !await db.selectFrom("users").select("id").where("id", "=", linkedUserId).executeTakeFirst()) hrError("user");
  await db.insertInto("hr_staff").values({
    full_name: fullName, staff_group: staffGroup as "employee" | "nursing",
    linked_user_id: linkedUserId, employment_start: employmentStart, employment_end: null,
    notes: value(formData, "notes") || null, active: 1, created_by: session.userId,
  }).execute();
  refresh();
}

export async function updateHrStaffAction(formData: FormData) {
  const session = await canManageHr();
  if (!session) return;
  const staffId = Number(formData.get("staff_id"));
  const fullName = value(formData, "full_name");
  const staffGroup = value(formData, "staff_group");
  const employmentStart = value(formData, "employment_start");
  const linkedRaw = Number(formData.get("linked_user_id"));
  const linkedUserId = Number.isInteger(linkedRaw) && linkedRaw > 0 ? linkedRaw : null;
  if (!Number.isInteger(staffId) || staffId <= 0) hrError("person");
  if (!fullName) hrError("name");
  if (!["employee", "nursing"].includes(staffGroup)) hrError("group");
  if (!validDate(employmentStart)) hrError("startdate");
  await db.updateTable("hr_staff").set({
    full_name: fullName, staff_group: staffGroup as "employee" | "nursing", linked_user_id: linkedUserId,
    employment_start: employmentStart, notes: value(formData, "notes") || null, updated_at: new Date().toISOString(),
  }).where("id", "=", staffId).execute();
  await db.updateTable("hr_compensation_rules").set({ staff_group: staffGroup as "employee" | "nursing", updated_at: new Date().toISOString() }).where("person_type", "=", "staff").where("person_id", "=", staffId).execute();
  refresh();
}

export async function endHrStaffAction(formData: FormData) {
  const session = await canManageHr();
  if (!session) return;
  const staffId = Number(formData.get("staff_id"));
  const endDate = value(formData, "employment_end") || getClinicToday();
  if (!Number.isInteger(staffId) || staffId <= 0) hrError("person");
  if (!validDate(endDate)) hrError("enddate");
  await db.transaction().execute(async (trx) => {
    await trx.updateTable("hr_staff").set({ active: 0, employment_end: endDate, updated_at: new Date().toISOString() }).where("id", "=", staffId).execute();
    await trx.updateTable("hr_compensation_rules").set({ active: 0, effective_to: endDate, updated_at: new Date().toISOString() }).where("person_type", "=", "staff").where("person_id", "=", staffId).execute();
  });
  await logAdminEvent({ entityType: "hr_staff", entityId: staffId, event: "end_employment", details: `إنهاء خدمة الموظف بتاريخ ${endDate} وإيقاف قاعدة راتبه`, changedBy: session.userId });
  refresh();
}

export async function saveHrCompensationRuleAction(formData: FormData) {
  const session = await canManageHr();
  if (!session) return;
  const personType = value(formData, "person_type");
  const personId = Number(formData.get("person_id"));
  const staffGroup = personType === "doctor" ? "doctor" : value(formData, "staff_group");
  const compensationType = value(formData, "compensation_type");
  const fixedBasis = value(formData, "fixed_basis");
  const fixedAmount = amount(formData, "fixed_amount");
  const percentageBasis = value(formData, "percentage_basis");
  let percentageMode = value(formData, "percentage_mode");
  const percentage = amount(formData, "percentage");
  const effectiveFrom = value(formData, "effective_from");
  const effectiveTo = value(formData, "effective_to") || null;
  if (!Number.isInteger(personId) || personId <= 0 || !["doctor", "staff"].includes(personType)) hrError("person");
  if (!["doctor", "employee", "nursing"].includes(staffGroup)) hrError("group");
  if (!["fixed", "percentage", "mixed"].includes(compensationType)) hrError("comptype");
  if (!["monthly", "shift"].includes(fixedBasis) || !["personal", "clinic"].includes(percentageBasis) || !["fixed", "progressive"].includes(percentageMode)) hrError("basis");
  if (fixedAmount == null) hrError("amount");
  if (percentage == null || percentage > 100) hrError("percent");
  if (!validDate(effectiveFrom) || (effectiveTo && !validDate(effectiveTo))) hrError("ruledate");
  if (effectiveTo && effectiveTo < effectiveFrom) hrError("daterange");
  if (personType !== "doctor" && percentageBasis === "personal") hrError("personalbasis");
  if (personType !== "doctor" && percentageMode === "progressive") percentageMode = "fixed";
  if (compensationType === "fixed" && fixedAmount <= 0) hrError("fixedzero");
  if (compensationType !== "fixed" && percentageMode === "fixed" && percentage <= 0) hrError("percentzero");
  if (compensationType === "mixed" && fixedAmount <= 0) hrError("mixedzero");
  const exists = personType === "doctor"
    ? await db.selectFrom("doctors").select("id").where("id", "=", personId).where("active", "=", 1).executeTakeFirst()
    : await db.selectFrom("hr_staff").select("id").where("id", "=", personId).where("active", "=", 1).executeTakeFirst();
  if (!exists) hrError("notfound");
  await db.insertInto("hr_compensation_rules").values({
    person_type: personType as "doctor" | "staff", person_id: personId,
    staff_group: staffGroup as "doctor" | "employee" | "nursing",
    compensation_type: compensationType as "fixed" | "percentage" | "mixed",
    fixed_basis: fixedBasis as "monthly" | "shift", fixed_amount: compensationType === "percentage" ? 0 : fixedAmount,
    percentage_basis: percentageBasis as "personal" | "clinic", percentage_mode: percentageMode as "fixed" | "progressive",
    percentage: compensationType === "fixed" || percentageMode === "progressive" ? 0 : percentage,
    effective_from: effectiveFrom, effective_to: effectiveTo, active: 1, created_by: session.userId,
  }).onConflict((oc) => oc.columns(["person_type", "person_id"]).doUpdateSet({
    staff_group: staffGroup as "doctor" | "employee" | "nursing",
    compensation_type: compensationType as "fixed" | "percentage" | "mixed",
    fixed_basis: fixedBasis as "monthly" | "shift", fixed_amount: compensationType === "percentage" ? 0 : fixedAmount,
    percentage_basis: percentageBasis as "personal" | "clinic", percentage_mode: percentageMode as "fixed" | "progressive",
    percentage: compensationType === "fixed" || percentageMode === "progressive" ? 0 : percentage,
    effective_from: effectiveFrom, effective_to: effectiveTo, active: 1, created_by: session.userId, updated_at: new Date().toISOString(),
  })).execute();
  await logAdminEvent({
    entityType: personType === "doctor" ? "doctor" : "hr_staff", entityId: personId, event: "save_compensation_rule",
    details: `قاعدة راتب: نوع=${compensationType} ثابت=${fixedAmount} نسبة=${percentage}% أساس=${percentageBasis} من ${effectiveFrom}${effectiveTo ? ` إلى ${effectiveTo}` : ""}`,
    changedBy: session.userId,
  });
  refresh();
}

export async function stopHrCompensationRuleAction(formData: FormData): Promise<HrActionResult> {
  const session = await canManageHr();
  if (!session) return { ok: false, reason: "مفيش صلاحية عندك لإدارة HR." };
  const id = Number(formData.get("rule_id"));
  if (!Number.isInteger(id) || id <= 0) return { ok: false, reason: "القاعدة دي مش موجودة." };
  await db.updateTable("hr_compensation_rules").set({ active: 0, effective_to: getClinicToday(), updated_at: new Date().toISOString() }).where("id", "=", id).execute();
  await logAdminEvent({ entityType: "hr_compensation_rule", entityId: id, event: "stop_compensation_rule", details: `إيقاف قاعدة الراتب بتاريخ ${getClinicToday()}`, changedBy: session.userId });
  refresh();
  return { ok: true };
}

// حذف نهائي لقاعدة راتب (وليس إيقاف فقط) — يُستخدم لتصحيح قاعدة أُدخلت غلط
// أو كتجربة، بدل ما تفضل محفوظة كتاريخ متوقف. الكشوف السابقة في
// hr_payroll_runs مستقلة (بتحتفظ بلقطتها الخاصة) ومش بتتأثر بحذف القاعدة.
export async function deleteHrCompensationRuleAction(formData: FormData): Promise<HrActionResult> {
  const session = await canManageHr();
  if (!session) return { ok: false, reason: "مفيش صلاحية عندك لإدارة HR." };
  const id = Number(formData.get("rule_id"));
  if (!Number.isInteger(id) || id <= 0) return { ok: false, reason: "القاعدة دي مش موجودة." };
  // بنقرا القاعدة قبل الحذف عشان الأثر يحتفظ بمحتواها — بعد الحذف مفيش أي وسيلة نعرف بيها كانت إيه.
  const rule = await db.selectFrom("hr_compensation_rules")
    .select(["person_type", "person_id", "compensation_type", "fixed_amount", "percentage", "effective_from"])
    .where("id", "=", id).executeTakeFirst();
  await db.deleteFrom("hr_compensation_rules").where("id", "=", id).execute();
  await logAdminEvent({
    entityType: "hr_compensation_rule", entityId: id, event: "delete_compensation_rule",
    details: rule ? `حذف نهائي: ${rule.person_type}#${rule.person_id} نوع=${rule.compensation_type} ثابت=${rule.fixed_amount} نسبة=${rule.percentage}% من ${rule.effective_from}` : "حذف نهائي لقاعدة راتب",
    changedBy: session.userId,
  });
  refresh();
  return { ok: true };
}

export async function deleteHrDocumentAction(formData: FormData) {
  const session = await canManageHr();
  if (!session) return;
  const id = Number(formData.get("document_id"));
  if (!Number.isInteger(id) || id <= 0) hrError("document");
  const document = await db.selectFrom("hr_documents").select(["id", "file_path"]).where("id", "=", id).executeTakeFirst();
  if (!document || !document.file_path.startsWith("/patient-files/hr-documents/")) hrError("document");
  const relative = document.file_path.slice("/patient-files/".length).split("/").filter(Boolean);
  const root = process.env.CLINIC_UPLOAD_DIR ? path.resolve(process.env.CLINIC_UPLOAD_DIR) : path.join(process.cwd(), "data", "uploads");
  const filePath = path.resolve(root, ...relative);
  if (!filePath.startsWith(`${path.resolve(root)}${path.sep}`)) hrError("document");
  await db.deleteFrom("hr_documents").where("id", "=", id).execute();
  await fs.unlink(filePath).catch(() => {});
  await logAdminEvent({ entityType: "hr_document", entityId: id, event: "delete_document", details: `حذف مستند HR: ${document.file_path}`, changedBy: session.userId });
  refresh();
}
