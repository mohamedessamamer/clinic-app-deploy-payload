import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getClinicToday } from "@/lib/clinic-date";
import HrWorkspace from "@/components/HrWorkspace";

// رسايل الفشل اللي كانت صامتة. المفتاح بيوصل في ?err= من الأكشن (شوف hrError
// في actions.ts) والصفحة بتعرضه فوق الشاشة بدل ما المستخدم يدوس ومايحصلش حاجة.
const HR_ERRORS: Record<string, string> = {
  name: "لازم تكتب الاسم كامل.",
  group: "اختار الفئة: موظف أو تمريض.",
  startdate: "تاريخ بداية العمل غير صحيح.",
  enddate: "تاريخ آخر يوم عمل غير صحيح.",
  person: "الشخص ده مش موجود أو مش متحدد.",
  user: "حساب الدخول المختار مش موجود.",
  comptype: "اختار نوع الاستحقاق: ثابت أو نسبة أو مختلط.",
  basis: "أساس الحساب أو نوع النسبة غير صحيح.",
  amount: "المبلغ الثابت لازم يكون رقم صحيح مش سالب.",
  percent: "النسبة لازم تكون بين 0 و100.",
  ruledate: "تاريخ سريان القاعدة غير صحيح.",
  daterange: "تاريخ النهاية لازم يكون بعد تاريخ البداية.",
  personalbasis: "أساس \"نسبة شخصية\" للأطباء فقط — للموظفين اختار أساس العيادة.",
  fixedzero: "الاستحقاق الثابت لازم يكون أكبر من صفر.",
  percentzero: "النسبة لازم تكون أكبر من صفر مع نوع النسبة الثابتة.",
  mixedzero: "الاستحقاق المختلط لازم يكون فيه مبلغ ثابت أكبر من صفر.",
  notfound: "الشخص ده مش موجود أو موقوف.",
  document: "المستند ده مش موجود أو مساره غير صالح.",
};

export default async function HrPage({ searchParams }: { searchParams: Promise<{ err?: string }> }) {
  const { err } = await searchParams;
  const errorMessage = err ? HR_ERRORS[err] || "البيانات غير مكتملة أو غير صحيحة." : null;
  const session = await getSession();
  const allowed = session ? await hasPermission(session.userId, session.role, "manage_hr") : false;
  if (!allowed) return <div className="card-3d rounded-xl p-5 text-sm text-muted">مفيش صلاحية عندك لإدارة HR.</div>;
  const [doctors, staff, users, rules, documents, formerPaid] = await Promise.all([
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).orderBy("full_name").execute(),
    db.selectFrom("hr_staff").selectAll().orderBy("active", "desc").orderBy("full_name").execute(),
    db.selectFrom("users").select(["id", "full_name", "username"]).where("active", "=", 1).orderBy("full_name").execute(),
    db.selectFrom("hr_compensation_rules").selectAll().execute(),
    db.selectFrom("hr_documents").selectAll().orderBy("created_at", "desc").execute(),
    db.selectFrom("hr_payroll_runs").select(["person_id", "total_amount", "fixed_amount"]).where("person_type", "=", "staff").where("status", "=", "paid").execute(),
  ]);
  const ruleMap = new Map(rules.map((rule) => [`${rule.person_type}-${rule.person_id}`, rule]));
  const people = [
    ...doctors.map((doctor) => ({ key: `doctor-${doctor.id}`, personType: "doctor" as const, id: doctor.id, name: doctor.full_name, group: "doctor" as const, employmentStart: getClinicToday(), linkedUserId: null, notes: null, rule: ruleMap.get(`doctor-${doctor.id}`) ?? null })),
    ...staff.filter((person) => person.active === 1).map((person) => ({ key: `staff-${person.id}`, personType: "staff" as const, id: person.id, name: person.full_name, group: person.staff_group, employmentStart: person.employment_start, linkedUserId: person.linked_user_id, notes: person.notes, rule: ruleMap.get(`staff-${person.id}`) ?? null })),
  ];
  const paidMap = new Map<number, { total: number; lastSalary: number }>();
  for (const run of formerPaid) { const current = paidMap.get(run.person_id) ?? { total: 0, lastSalary: 0 }; current.total += run.total_amount; current.lastSalary = run.fixed_amount; paidMap.set(run.person_id, current); }
  const former = staff.filter((person) => person.active === 0).map((person) => {
    const staffDocuments = documents.filter((document) => document.person_type === "staff" && document.person_id === person.id);
    return { id: person.id, name: person.full_name, group: person.staff_group, start: person.employment_start, end: person.employment_end, totalPaid: paidMap.get(person.id)?.total ?? 0, lastSalary: paidMap.get(person.id)?.lastSalary ?? ruleMap.get(`staff-${person.id}`)?.fixed_amount ?? 0, documents: staffDocuments.length, documentLinks: staffDocuments.map((document) => ({ id: document.id, label: document.label || document.original_name, path: document.file_path })) };
  });
  return <div className="space-y-6">{errorMessage && <p className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{errorMessage}</p>}<div><h1 className="text-2xl font-bold">HR وقواعد الرواتب</h1><p className="mt-1 text-sm text-muted">سجل الموظفين مستقل عن حسابات الدخول. اختر شخصًا واحدًا لتعديل قاعدته ومستنداته.</p></div><div className="rounded-xl border border-primary/20 bg-primary-soft/30 p-4 text-sm leading-7"><b>قاعدة نسبة الطبيب:</b> النسبة تُحسب على ما دفعه المرضى فعليًا بعد خصم تكلفة المعمل. الدفع الجزئي يخصم الجزء المقابل فقط من تكلفة المعمل.</div><HrWorkspace people={people} former={former} documents={documents} users={users} today={getClinicToday()} /></div>;
}
