import Link from "next/link";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import InvoicesFilterForm from "@/components/InvoicesFilterForm";
import InvoiceRow, { type InvoiceRowData } from "@/components/InvoiceRow";
import { getClinicToday } from "@/lib/clinic-date";

export default async function InvoicesPage({
  searchParams,
}: {
  searchParams: Promise<{ date?: string; doctor_id?: string; payment_method?: string }>;
}) {
  const { date, doctor_id, payment_method } = await searchParams;
  const session = await getSession();
  // الطبيب يفتح صفحة الفواتير كتقرير شخصي سريع: فواتيره هو فقط في يوم العمل
  // الحالي. بنثبت الشرط هنا على السيرفر، مش في الواجهة فقط، عشان تغيير الرابط
  // يدويًا ما يفتحش فواتير يوم أو دكتور آخر.
  const isDoctorInvoiceView = session?.role === "doctor";
  const day = isDoctorInvoiceView
    ? getClinicToday()
    : date && /^\d{4}-\d{2}-\d{2}$/.test(date)
      ? date
      : getClinicToday();
  const requestedDoctorFilter = doctor_id ? Number(doctor_id) : null;
  const doctorFilter = isDoctorInvoiceView ? session?.doctorId ?? null : requestedDoctorFilter;
  const paymentMethodFilter = payment_method || null;
  // بمجرد ما مبلغ مدفوع يتسجل، مفروض يفضل ثابت — التعديل بعد كده محصور بالصلاحية
  // دي (مدير العيادة/المحاسب/الأدمن افتراضيًا) عشان تصحيح غلطة إدخال من الاستقبال.
  // نفس الصلاحية دي كمان بتتحكم في إمكانية تسجيل خدمة بتاريخ غير النهاردة من
  // الملف المالي للمريض (شوف src/app/patients/[id]/billing/actions.ts).
  const canEditPayments = session ? await hasPermission(session.userId, session.role, "edit_invoice_payments") : false;
  // الإجماليات (الكروت فوق) — محصورة بالصلاحية دي (مدير
  // العيادة/المحاسب/الأدمن افتراضيًا، قابلة للمنح لدكتور معيّن كمان من الإعدادات).
  // سعر/مدفوع/متبقي كل فاتورة على حدة بقى ظاهر للكل (دفعة 20) — بس الأرقام
  // الإجمالية على مستوى اليوم كله لسه محجوبة عن الاستقبال.
  const canViewTotals = session ? await hasPermission(session.userId, session.role, "view_invoice_totals") : false;
  // لينك "عرض في التقارير" — بيوصّل صفحة الفواتير اليومية دي بتقرير الإيرادات
  // (فترة مقفولة على نفس اليوم المعروض هنا)، بس لمين عنده صلاحية توصل للتقارير أصلاً.
  const canViewReports = session
    ? (await hasPermission(session.userId, session.role, "reports_full")) ||
      (await hasPermission(session.userId, session.role, "reports_own"))
    : false;
  // حذف فاتورة/خدمة اتسجلت غلط، مباشرة من صفحة الفواتير — بنفس صلاحية "حذف
  // زيارة" الموجودة أصلاً في سجل الزيارات بالملف الطبي (delete_visits، الأدمن
  // بس افتراضيًا)، مش صلاحية جديدة، لأنها فعليًا نفس العملية (مسح الزيارة
  // وفاتورتها سوا) بس متاحة من هنا كمان للراحة.
  const canDelete = session ? await hasPermission(session.userId, session.role, "delete_visits") : false;

  const doctors = await db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).execute();

  const invoices = await db
    .selectFrom("invoices")
    .innerJoin("patients", "patients.id", "invoices.patient_id")
    .leftJoin("doctors", "doctors.id", "invoices.doctor_id")
    .leftJoin("services", "services.id", "invoices.service_id")
    .select([
      "invoices.id",
      "invoices.amount",
      "invoices.paid",
      "invoices.original_price",
      "invoices.discount_percent",
      "invoices.price_overridden",
      "invoices.payment_method",
      "invoices.parent_invoice_id",
      "invoices.visit_id",
      "invoices.invoice_date",
      "invoices.patient_id",
      "patients.full_name as patient_name",
      "doctors.full_name as doctor_name",
      "services.name as service_name",
    ])
    .where("invoices.invoice_date", "=", day)
    .$if(isDoctorInvoiceView, (qb) =>
      doctorFilter != null ? qb.where("invoices.doctor_id", "=", doctorFilter) : qb.where("invoices.id", "=", -1)
    )
    .$if(!isDoctorInvoiceView && !!doctorFilter, (qb) => qb.where("invoices.doctor_id", "=", doctorFilter!))
    .$if(!!paymentMethodFilter, (qb) => qb.where("invoices.payment_method", "=", paymentMethodFilter!))
    .orderBy("invoices.id", "desc")
    .execute();

  // صفوف "↳ دفعة متابعة" (parent_invoice_id مش فاضي) مالهاش سعر أصلي أو رصيد خاص
  // بيها (amount بتاعتها صفر دايمًا — شوف تعليق schema.sql) — لوحدها كده بتظهر
  // فاضية تمامًا وميعرفش حد يشوف الدفعة دي كانت بتقفل رصيد أي خدمة ولا قد إيه
  // باقي عليها. بنجيب هنا بيانات الفاتورة الأصلية (اسم الخدمة) ورصيدها الحالي
  // الكامل (بعد خصم كل دفعات المتابعة عليها من أي يوم، مش بس اللي حصلت النهاردة).
  const parentIds = [
    ...new Set(invoices.map((i) => i.parent_invoice_id).filter((id): id is number => id != null)),
  ];

  const parentInfoById = new Map<number, { service_name: string | null; remaining: number }>();
  if (parentIds.length > 0) {
    const parents = await db
      .selectFrom("invoices")
      .leftJoin("services", "services.id", "invoices.service_id")
      .select(["invoices.id", "invoices.amount", "invoices.paid", "services.name as service_name"])
      .where("invoices.id", "in", parentIds)
      .execute();

    const allFollowups = await db
      .selectFrom("invoices")
      .select(["parent_invoice_id", "paid"])
      .where("parent_invoice_id", "in", parentIds)
      .execute();

    const followupSumByParent = new Map<number, number>();
    for (const f of allFollowups) {
      if (f.parent_invoice_id == null) continue;
      followupSumByParent.set(f.parent_invoice_id, (followupSumByParent.get(f.parent_invoice_id) ?? 0) + f.paid);
    }

    for (const p of parents) {
      parentInfoById.set(p.id, {
        service_name: p.service_name,
        remaining: Math.round((p.amount - p.paid - (followupSumByParent.get(p.id) ?? 0)) * 100) / 100,
      });
    }
  }

  // "إجمالي فواتير اليوم" و"المتبقي" بيتحسبوا من الفواتير الأصلية بس (اللي
  // parent_invoice_id بتاعها فاضي) — استحقاق جديد اتسجل النهاردة فعلاً. دفعات
  // المتابعة (amount=0 دايمًا) بتتحسب في "المحصّل" فقط (كاش اتحصّل النهاردة فعلاً)
  // لكن متتحسبش في "المتبقي" لأنها مش استحقاق جديد — هي تحصيل على فاتورة قديمة
  // مش ظاهرة في جدول اليوم ده أصلاً، فطرحها من استحقاق اليوم كان بيدي رقم مضلل
  // (مبيتطابقش مع أي رقم ظاهر فعليًا في الجدول تحت).
  const totals = invoices.reduce(
    (acc, inv) => {
      acc.collected += inv.paid;
      if (inv.parent_invoice_id == null) {
        acc.newAmount += inv.amount;
        acc.newRemaining += inv.amount - inv.paid;
      }
      return acc;
    },
    { newAmount: 0, collected: 0, newRemaining: 0 }
  );

  const rows: InvoiceRowData[] = invoices.map((inv) => {
    const parentInfo = inv.parent_invoice_id != null ? parentInfoById.get(inv.parent_invoice_id) : undefined;
    return {
      id: inv.id,
      visit_id: inv.visit_id,
      // هذا الاستعلام مرتبط بـ patients بـ inner join، فالفاتورة المعروضة
      // هنا مضمونة الارتباط بمريض حتى لو كان الحقل يقبل null للتوافق القديم.
      patient_id: inv.patient_id!,
      patient_name: inv.patient_name,
      service_name: inv.service_name,
      doctor_name: inv.doctor_name,
      amount: inv.amount,
      paid: inv.paid,
      discount_percent: inv.discount_percent,
      price_overridden: inv.price_overridden,
      payment_method: inv.payment_method,
      isFollowup: parentInfo != null,
      followupOfServiceName: parentInfo?.service_name,
      remaining: parentInfo ? `${parentInfo.remaining.toFixed(0)} (على الفاتورة الأصلية)` : inv.amount > 0 ? inv.amount - inv.paid : "-",
    };
  });

  // سجل التعديلات كان معروضًا هنا ليوم واحد بس، واتنقل (دفعة 98) لتبويب
  // "تقارير النظام" في صفحة التقارير بفلتر فترة كاملة ونوع حدث ومستخدم.
  // البيانات نفسها زي ما هي في جدول سجل التدقيق ومش بتتمسح أبدًا.

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h1 className="text-xl font-bold">الفواتير</h1>
        <div className="flex items-center gap-3 flex-wrap">
          {canViewReports && (
            <Link href={`/reports?from=${day}&to=${day}`} className="text-sm text-primary hover:underline">
              عرض في التقارير
            </Link>
          )}
          <InvoicesFilterForm
            day={day}
            doctors={doctors}
            doctorId={isDoctorInvoiceView ? String(doctorFilter ?? "") : doctor_id ?? ""}
            paymentMethod={payment_method ?? ""}
            lockedToToday={isDoctorInvoiceView}
          />
        </div>
      </div>

      {canViewTotals && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="card-3d rounded-xl p-4">
            <div className="text-xs text-muted">إجمالي فواتير اليوم</div>
            <div className="text-2xl font-bold">{totals.newAmount.toFixed(0)} ج.م</div>
          </div>
          <div className="card-3d rounded-xl p-4">
            <div className="text-xs text-muted">المحصّل</div>
            <div className="text-2xl font-bold text-primary">{totals.collected.toFixed(0)} ج.م</div>
            <div className="text-[10px] text-muted mt-0.5">شامل أي دفعات متابعة على فواتير قديمة</div>
          </div>
          <div className="card-3d rounded-xl p-4">
            <div className="text-xs text-muted">المتبقي على فواتير اليوم</div>
            <div className="text-2xl font-bold text-danger">{totals.newRemaining.toFixed(0)} ج.م</div>
          </div>
        </div>
      )}

      <div className="card-3d rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-primary-soft text-primary-dark">
            <tr>
              <th className="text-right px-3 py-2 font-medium">المريض</th>
              <th className="text-right px-3 py-2 font-medium">الخدمة</th>
              <th className="text-right px-3 py-2 font-medium">السعر</th>
              <th className="text-right px-3 py-2 font-medium">المدفوع</th>
              <th className="text-right px-3 py-2 font-medium">المتبقي</th>
              <th className="text-right px-3 py-2 font-medium">طريقة الدفع</th>
              <th className="text-right px-3 py-2 font-medium">الدكتور</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((inv) => (
              <InvoiceRow key={inv.id} inv={inv} canEdit={canEditPayments} canDelete={canDelete} />
            ))}
            {rows.length === 0 && (
              <tr>
                <td colSpan={7} className="px-3 py-6 text-center text-muted">
                  لا يوجد فواتير لليوم ده.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

    </div>
  );
}
