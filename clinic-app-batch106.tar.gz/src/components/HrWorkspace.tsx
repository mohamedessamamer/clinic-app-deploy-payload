"use client";

import { useMemo, useState, useTransition } from "react";
import { addHrStaffAction, deleteHrCompensationRuleAction, deleteHrDocumentAction, endHrStaffAction, saveHrCompensationRuleAction, stopHrCompensationRuleAction, updateHrStaffAction } from "@/app/hr/actions";
import HrDocumentUploader from "@/components/HrDocumentUploader";

type Rule = { id: number; person_type: "doctor" | "staff"; person_id: number; staff_group: "doctor" | "employee" | "nursing"; compensation_type: "fixed" | "percentage" | "mixed"; fixed_basis: "monthly" | "shift"; fixed_amount: number; percentage_basis: "personal" | "clinic"; percentage_mode: "fixed" | "progressive"; percentage: number; effective_from: string; effective_to: string | null; active: number; updated_at: string };
type Person = { key: string; personType: "doctor" | "staff"; id: number; name: string; group: "doctor" | "employee" | "nursing"; employmentStart: string; linkedUserId: number | null; notes: string | null; rule: Rule | null };
type Former = { id: number; name: string; group: "employee" | "nursing"; start: string; end: string | null; totalPaid: number; lastSalary: number; documents: number; documentLinks: Array<{ id: number; label: string; path: string }> };
type Document = { id: number; person_type: "doctor" | "staff"; person_id: number; document_type: string; label: string | null; file_path: string; original_name: string };
type UserOption = { id: number; full_name: string; username: string };

const labels = { doctor: "الأطباء", employee: "الموظفون", nursing: "التمريض" } as const;
const docLabels: Record<string, string> = { id: "بطاقة شخصية", graduation: "شهادة تخرج", license: "مزاولة المهنة", contract: "عقد", other: "مستند آخر" };

export default function HrWorkspace({ people, former, documents, users, today }: { people: Person[]; former: Former[]; documents: Document[]; users: UserOption[]; today: string }) {
  const [newPersonGroup, setNewPersonGroup] = useState<"employee" | "nursing" | "doctor">("employee");
  const [selectedKey, setSelectedKey] = useState(people[0]?.key ?? "");
  const selected = people.find((person) => person.key === selectedKey) ?? null;
  const [isPending, startTransition] = useTransition();
  // قاعدة متوقفة (active=0) أو محذوفة معتبرة "مفيش قاعدة نشطة"، فبيانات
  // النموذج تبدأ من الصفر بدل ما تفضل معبّية بأرقام القاعدة القديمة — عشان
  // الضغط على "حفظ القاعدة" بعد الإيقاف من غير تعديل حقيقي ميرجّعش يفعّلها.
  const activeRule = selected?.rule?.active ? selected.rule : null;
  const [type, setType] = useState(activeRule?.compensation_type ?? "fixed");
  const [fixedBasis, setFixedBasis] = useState(activeRule?.fixed_basis ?? "monthly");
  const [percentageMode, setPercentageMode] = useState(activeRule?.percentage_mode ?? "fixed");
  const personDocuments = useMemo(() => selected ? documents.filter((document) => document.person_type === selected.personType && document.person_id === selected.id) : [], [documents, selected]);
  function choose(key: string) {
    const person = people.find((item) => item.key === key);
    const rule = person?.rule?.active ? person.rule : null;
    setSelectedKey(key); setType(rule?.compensation_type ?? "fixed"); setFixedBasis(rule?.fixed_basis ?? "monthly"); setPercentageMode(rule?.percentage_mode ?? "fixed");
  }
  const input = "h-9 rounded border border-border bg-background px-2 text-sm";
  return <div className="space-y-5">
    <section className="card-3d rounded-xl p-4 space-y-3">
      <div><h2 className="font-semibold">إضافة موظف إلى HR</h2><p className="mt-1 text-xs text-muted">حساب الدخول اختياري. موظف HR لا يحتاج يوزر، واليوزر وحده لا يجعله موظفًا. لو اخترت &quot;طبيب&quot; هيتضاف كطبيب بدون حساب دخول — لإضافة طبيب بحساب دخول استخدم &quot;إضافة طبيب&quot; من الإعدادات.</p></div>
      <form action={addHrStaffAction} className="flex flex-wrap items-end gap-2">
        <label className="text-xs text-muted">الاسم<input name="full_name" required className={`${input} mt-1 block w-48`} /></label>
        <label className="text-xs text-muted">القسم<select name="staff_group" value={newPersonGroup} onChange={(e) => setNewPersonGroup(e.target.value as "employee" | "nursing" | "doctor")} className={`${input} mt-1 block w-32`}><option value="employee">موظف</option><option value="nursing">تمريض</option><option value="doctor">طبيب</option></select></label>
        {newPersonGroup !== "doctor" && <>
          <label className="text-xs text-muted">بداية العمل<input name="employment_start" type="date" defaultValue={today} required className={`${input} mt-1 block w-40`} /></label>
          <label className="text-xs text-muted">ربط بحساب (اختياري)<select name="linked_user_id" className={`${input} mt-1 block w-52`}><option value="">بدون حساب</option>{users.map((user) => <option key={user.id} value={user.id}>{user.full_name} — {user.username}</option>)}</select></label>
          <label className="text-xs text-muted">ملاحظة<input name="notes" className={`${input} mt-1 block w-44`} /></label>
        </>}
        <button className="h-9 rounded btn-3d-primary px-4 text-sm">إضافة</button>
      </form>
    </section>

    <section className="card-3d rounded-xl p-4 space-y-4">
      <div className="flex flex-wrap items-end gap-3"><label className="text-xs text-muted">اختر الشخص لتعديل بياناته وقاعدة راتبه<select value={selectedKey} onChange={(event) => choose(event.target.value)} className={`${input} mt-1 block w-64`}><option value="">اختر</option>{(["doctor", "employee", "nursing"] as const).map((group) => <optgroup key={group} label={labels[group]}>{people.filter((person) => person.group === group).map((person) => <option key={person.key} value={person.key}>{person.name}</option>)}</optgroup>)}</select></label>{selected && <span className="rounded-full bg-primary-soft px-3 py-1 text-xs text-primary-dark">{labels[selected.group]}</span>}</div>
      {!selected && <p className="text-sm text-muted">أضف موظفًا أو اختر طبيبًا لبدء التعريف.</p>}
      {selected && <div key={selected.key} className="space-y-4">
        {selected.personType === "staff" && <details className="rounded-lg border border-border p-3"><summary className="cursor-pointer text-sm font-medium">بيانات الموظف وإنهاء الخدمة</summary><div className="mt-3 space-y-3"><form action={updateHrStaffAction} className="flex flex-wrap items-end gap-2"><input type="hidden" name="staff_id" value={selected.id} /><input name="full_name" defaultValue={selected.name} required className={`${input} w-48`} /><select name="staff_group" defaultValue={selected.group} className={`${input} w-32`}><option value="employee">موظف</option><option value="nursing">تمريض</option></select><input name="employment_start" type="date" defaultValue={selected.employmentStart} required className={`${input} w-40`} /><select name="linked_user_id" defaultValue={selected.linkedUserId ?? ""} className={`${input} w-52`}><option value="">بدون حساب</option>{users.map((user) => <option key={user.id} value={user.id}>{user.full_name} — {user.username}</option>)}</select><input name="notes" defaultValue={selected.notes ?? ""} placeholder="ملاحظة" className={`${input} w-44`} /><button className="h-9 rounded border border-border px-3 text-sm">حفظ البيانات</button></form><form action={endHrStaffAction} className="flex items-end gap-2"><input type="hidden" name="staff_id" value={selected.id} /><label className="text-xs text-muted">آخر يوم عمل<input name="employment_end" type="date" defaultValue={today} className={`${input} mt-1 block w-40`} /></label><button className="h-9 text-xs text-danger hover:underline">نقل إلى الموظفين السابقين</button></form></div></details>}
        <form key={`${selected.key}-${selected.rule?.updated_at ?? "new"}`} action={saveHrCompensationRuleAction} className="rounded-lg border border-border p-3 space-y-3">
          <div className="flex items-center justify-between gap-3">
            <h3 className="text-sm font-semibold">قاعدة الراتب</h3>
            <div className="flex items-center gap-3">
              {activeRule ? <button
                type="button"
                disabled={isPending}
                className="text-xs text-danger hover:underline disabled:opacity-50"
                onClick={() => {
                  const ruleId = activeRule.id;
                  const formData = new FormData();
                  formData.set("rule_id", String(ruleId));
                  startTransition(async () => { const result = await stopHrCompensationRuleAction(formData); if (!result.ok) window.alert(result.reason || "تعذر إيقاف القاعدة."); });
                }}
              >{isPending ? "..." : "إيقاف القاعدة"}</button> : <span className="text-xs text-muted">لا توجد قاعدة نشطة</span>}
              {selected.rule && <button
                type="button"
                disabled={isPending}
                className="text-xs text-danger hover:underline disabled:opacity-50"
                onClick={() => {
                  if (!window.confirm(`حذف قاعدة راتب ${selected.name} نهائيًا؟ ده مختلف عن الإيقاف — القاعدة هتشال بالكامل، وهيختفي من جدول الاستحقاقات في المصروفات فورًا.`)) return;
                  const ruleId = selected.rule!.id;
                  const formData = new FormData();
                  formData.set("rule_id", String(ruleId));
                  startTransition(async () => { const result = await deleteHrCompensationRuleAction(formData); if (!result.ok) window.alert(result.reason || "تعذر حذف القاعدة."); });
                }}
              >{isPending ? "..." : "حذف القاعدة نهائيًا"}</button>}
            </div>
          </div>
          {selected.rule && !activeRule && <p className="text-xs text-amber-700">القاعدة الحالية متوقفة. القيم تحت دي فاضية/افتراضية — أدخل قيم القاعدة الجديدة قبل الحفظ.</p>}
          <input type="hidden" name="person_type" value={selected.personType} /><input type="hidden" name="person_id" value={selected.id} /><input type="hidden" name="staff_group" value={selected.group} />
          <div className="flex flex-wrap items-end gap-2">
            <label className="text-xs text-muted">الاستحقاق<select name="compensation_type" value={type} onChange={(e) => setType(e.target.value as "fixed" | "percentage" | "mixed")} className={`${input} mt-1 block w-36`}><option value="fixed">ثابت</option><option value="percentage">نسبة</option><option value="mixed">ثابت + نسبة</option></select></label>
            {type !== "percentage" ? <><label className="text-xs text-muted">قاعدة الثابت<select name="fixed_basis" value={fixedBasis} onChange={(e) => setFixedBasis(e.target.value as "monthly" | "shift")} className={`${input} mt-1 block w-32`}><option value="monthly">شهري</option><option value="shift">بالشيفت</option></select></label><label className="text-xs text-muted">{fixedBasis === "shift" ? "قيمة الشيفت" : "الراتب"}<input name="fixed_amount" type="number" min="0" step="0.01" defaultValue={activeRule?.fixed_amount ?? 0} required className={`${input} mt-1 block w-32`} /></label></> : <><input type="hidden" name="fixed_basis" value="monthly" /><input type="hidden" name="fixed_amount" value="0" /></>}
            {type !== "fixed" ? <><label className="text-xs text-muted">أساس النسبة<select name="percentage_basis" defaultValue={activeRule?.percentage_basis ?? (selected.personType === "doctor" ? "personal" : "clinic")} className={`${input} mt-1 block w-52`}>{selected.personType === "doctor" && <option value="personal">تحصيله بعد المعمل</option>}<option value="clinic">تحصيل العيادة بعد المعمل</option></select></label><label className="text-xs text-muted">نوع النسبة<select name="percentage_mode" value={percentageMode} onChange={(e) => setPercentageMode(e.target.value as "fixed" | "progressive")} className={`${input} mt-1 block w-44`}><option value="fixed">نسبة ثابتة</option>{selected.personType === "doctor" && <option value="progressive">تصاعدية حتى 30%</option>}</select></label>{percentageMode === "fixed" ? <label className="text-xs text-muted">النسبة %<input name="percentage" type="number" min="0" max="100" step="0.01" defaultValue={activeRule?.percentage ?? 0} required className={`${input} mt-1 block w-24`} /></label> : <input type="hidden" name="percentage" value="0" />}</> : <><input type="hidden" name="percentage_basis" value={selected.personType === "doctor" ? "personal" : "clinic"} /><input type="hidden" name="percentage_mode" value="fixed" /><input type="hidden" name="percentage" value="0" /></>}
            <label className="text-xs text-muted">من<input name="effective_from" type="date" defaultValue={activeRule?.effective_from ?? today} required className={`${input} mt-1 block w-40`} /></label><label className="text-xs text-muted">إلى (اختياري)<input name="effective_to" type="date" defaultValue={activeRule?.effective_to ?? ""} className={`${input} mt-1 block w-40`} /></label><button className="h-9 rounded btn-3d-primary px-4 text-sm">حفظ القاعدة</button>
          </div>
        </form>
        <div className="rounded-lg border border-border p-3 space-y-3"><h3 className="text-sm font-semibold">مستندات {selected.name}</h3><HrDocumentUploader personType={selected.personType} personId={selected.id} /><div className="flex flex-wrap gap-2">{personDocuments.map((document) => <span key={document.id} className="inline-flex items-center gap-2 rounded border border-border px-2 py-1 text-xs"><a href={document.file_path} target="_blank" rel="noreferrer" className="text-primary hover:underline">{document.label || docLabels[document.document_type] || document.original_name}</a><form action={deleteHrDocumentAction}><button name="document_id" value={document.id} className="text-danger">حذف</button></form></span>)}{!personDocuments.length && <span className="text-xs text-muted">لا توجد مستندات.</span>}</div></div>
      </div>}
    </section>

    <section className="grid gap-3 md:grid-cols-3">{(["doctor", "employee", "nursing"] as const).map((group) => <div key={group} className="card-3d rounded-xl p-3"><div className="mb-2 flex justify-between"><b>{labels[group]}</b><span className="text-xs text-muted">{people.filter((person) => person.group === group).length}</span></div><div className="space-y-1">{people.filter((person) => person.group === group).map((person) => <button key={person.key} onClick={() => choose(person.key)} className="flex w-full justify-between rounded px-2 py-1.5 text-right text-sm hover:bg-primary-soft"><span>{person.name}</span><span className={person.rule?.active ? "text-primary" : "text-muted"}>{person.rule?.active ? "قاعدة نشطة" : "بدون قاعدة"}</span></button>)}</div></div>)}</section>

    <details className="card-3d rounded-xl p-4"><summary className="cursor-pointer font-semibold">الموظفون السابقون ({former.length})</summary><div className="mt-3 overflow-x-auto"><table className="w-full text-sm"><thead className="bg-primary-soft"><tr><th className="p-2 text-right">الاسم</th><th className="p-2 text-right">القسم</th><th className="p-2 text-right">الفترة</th><th className="p-2 text-right">آخر راتب معرف</th><th className="p-2 text-right">إجمالي المصروف</th><th className="p-2 text-right">المستندات</th></tr></thead><tbody>{former.map((person) => <tr key={person.id} className="border-t border-border"><td className="p-2 font-medium">{person.name}</td><td className="p-2">{labels[person.group]}</td><td className="p-2">{person.start} — {person.end ?? "-"}</td><td className="p-2">{person.lastSalary.toFixed(0)} ج.م</td><td className="p-2">{person.totalPaid.toFixed(0)} ج.م</td><td className="p-2"><div className="flex flex-wrap gap-2">{person.documentLinks.map((document) => <a key={document.id} href={document.path} target="_blank" rel="noreferrer" className="text-primary hover:underline">{document.label}</a>)}{!person.documentLinks.length && "لا يوجد"}</div></td></tr>)}{!former.length && <tr><td colSpan={6} className="p-5 text-center text-muted">لا يوجد موظفون سابقون.</td></tr>}</tbody></table></div></details>
  </div>;
}
