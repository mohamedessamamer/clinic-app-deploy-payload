import { addInventorySupplierAction, updateInventorySupplierAction } from "@/app/inventory/actions";

type Supplier = {
  id: number;
  name: string;
  phone_country_code: string | null;
  phone: string | null;
  notes: string | null;
  is_ortho: number;
  is_general: number;
};

const inputClass = "w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm";
const buttonClass = "rounded-md btn-3d-primary px-3 py-1.5 text-sm font-medium";

// المورد يتعرّف من المخزن (وليس من شاشة الموردين بالمصروفات) — نفس مبدأ
// InventoryCatalogManager. عضوية التخصص (تقويم/جينيرال) علمان مستقلان لأن
// مورد واحد ممكن يورّد للتخصصين معاً؛ نفس تقسيمة الأصناف (specialty_name).
export default function InventorySupplierManager({ suppliers }: { suppliers: Supplier[] }) {
  return <section className="card-3d rounded-xl p-5 space-y-4">
    <div><h2 className="font-semibold">الموردون</h2><p className="text-xs text-muted mt-1">حدّد تخصص المورد (تقويم و/أو جينيرال) هنا؛ فواتيره ودفعاته تُسجَّل من شاشة &quot;الموردين&quot; تحت المصروفات.</p></div>

    <form action={addInventorySupplierAction} className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-2 items-end">
      <input name="name" required placeholder="اسم المورد" className={inputClass} />
      <input name="phone_country_code" defaultValue="+20" placeholder="كود الدولة" className={inputClass} />
      <input name="phone" placeholder="رقم الموبايل" className={inputClass} />
      <div className="flex gap-3 items-center text-sm">
        <label className="flex items-center gap-1"><input type="checkbox" name="is_ortho" value="1" /> تقويم</label>
        <label className="flex items-center gap-1"><input type="checkbox" name="is_general" value="1" /> جينيرال</label>
      </div>
      <input name="notes" placeholder="ملاحظة اختيارية" className={`${inputClass} sm:col-span-3`} />
      <button className={buttonClass}>إضافة مورد</button>
    </form>

    <div className="space-y-2">
      {suppliers.map((supplier) => <details key={supplier.id} className="rounded-lg border border-border p-3">
        <summary className="cursor-pointer text-sm"><b>{supplier.name}</b>{supplier.phone ? ` — ${supplier.phone_country_code ?? "+20"}${supplier.phone}` : ""} <span className="text-muted">({[supplier.is_ortho ? "تقويم" : null, supplier.is_general ? "جينيرال" : null].filter(Boolean).join(" و ") || "بدون تخصص محدد"})</span></summary>
        <form action={updateInventorySupplierAction} className="mt-3 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-2 items-end">
          <input type="hidden" name="supplier_id" value={supplier.id} />
          <input name="name" defaultValue={supplier.name} required className={inputClass} />
          <input name="phone_country_code" defaultValue={supplier.phone_country_code ?? "+20"} className={inputClass} />
          <input name="phone" defaultValue={supplier.phone ?? ""} className={inputClass} />
          <div className="flex gap-3 items-center text-sm">
            <label className="flex items-center gap-1"><input type="checkbox" name="is_ortho" value="1" defaultChecked={supplier.is_ortho === 1} /> تقويم</label>
            <label className="flex items-center gap-1"><input type="checkbox" name="is_general" value="1" defaultChecked={supplier.is_general === 1} /> جينيرال</label>
          </div>
          <input name="notes" defaultValue={supplier.notes ?? ""} placeholder="ملاحظة" className={`${inputClass} sm:col-span-3`} />
          <button className="rounded border border-border px-3 py-1.5 text-sm hover:bg-primary-soft">حفظ التعديل</button>
        </form>
      </details>)}
      {!suppliers.length && <p className="text-sm text-muted">لا يوجد موردون بعد.</p>}
    </div>
  </section>;
}
