"use client";

import { useEffect, useMemo, useState, useTransition } from "react";
import {
  getPatientDurationReportAction,
  getPatientDurationDoctorsAction,
  getPatientDurationPatientsAction,
  type PatientDurationResult,
} from "@/app/reports/patient-duration-actions";
import { CLINIC_TIMEZONE } from "@/lib/clinic-date";

// "النهاردة" بتوقيت العيادة (مصر) مش UTC — نفس سبب باج دفعة 28 الموثّق في
// clinic-date.ts بالظبط: `new Date().toISOString()` بيرجع تاريخ UTC، والسيرفر
// في ألمانيا. من نص الليل لحد الساعة 2-3 صباحًا بتوقيت مصر، UTC لسه "امبارح"،
// فأي حد جرّب "كل الفترة" في الفترة دي كان هيفوّت مواعيد النهاردة نفسه.
const clinicTodayFormatter = new Intl.DateTimeFormat("en-CA", {
  timeZone: CLINIC_TIMEZONE,
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});

const input = "rounded border border-border bg-background px-2 py-1.5 text-sm";

function formatMinutes(total: number) {
  const hours = Math.floor(total / 60);
  const minutes = total % 60;
  if (hours <= 0) return `${minutes} د`;
  return `${hours} س ${minutes} د`;
}

function formatTime(iso: string) {
  return iso.slice(11, 16) || iso;
}

export default function PatientDurationReport() {
  const [range, setRange] = useState({ from: "", to: "" });
  const [doctorId, setDoctorId] = useState("");
  const [patientQuery, setPatientQuery] = useState("");
  // اسم آخر مريض اتم اختياره من قايمة الاقتراحات — بيقفل القايمة بعد الاختيار
  // (المكتوب بقى بيطابق الاقتراح نفسه)، وبيتصفّر أول ما المستخدم يكتب حرف
  // جديد فيفتح الاقتراحات تاني.
  const [pickedPatientName, setPickedPatientName] = useState<string | null>(null);
  const [doctors, setDoctors] = useState<{ id: number; full_name: string }[]>([]);
  const [patients, setPatients] = useState<{ id: number; full_name: string; file_number: string }[]>([]);
  const [result, setResult] = useState<PatientDurationResult | null>(null);
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    let cancelled = false;
    getPatientDurationDoctorsAction().then((rows) => {
      if (!cancelled) setDoctors(rows);
    });
    getPatientDurationPatientsAction().then((rows) => {
      if (!cancelled) setPatients(rows);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  // نفس منطق بحث المريض في بوكس الحجز بالجدول المركزي — فلترة في المتصفح مع
  // كل حرف، من غير طلب سيرفر لكل كبسة.
  const patientSuggestions = useMemo(() => {
    const q = patientQuery.trim();
    if (q.length < 2 || q === pickedPatientName) return [];
    return patients.filter((p) => p.full_name.includes(q) || p.file_number.includes(q)).slice(0, 8);
  }, [patientQuery, patients, pickedPatientName]);

  function run() {
    startTransition(async () => {
      const data = await getPatientDurationReportAction({
        from: range.from,
        to: range.to,
        doctorId: doctorId ? Number(doctorId) : undefined,
        patientQuery: patientQuery.trim() || undefined,
      });
      setResult(data);
    });
  }

  function preset(days: number) {
    const end = new Date();
    const start = new Date(end.getTime() - days * 86_400_000);
    setRange({ from: clinicTodayFormatter.format(start), to: clinicTodayFormatter.format(end) });
  }

  // لو بتدور على مريض بعينه، غالبًا محتاج كل تاريخه مش بس آخر أسبوع/شهر —
  // تاريخ بعيد كفاية يغطي أول يوم للعيادة عمليًا. الحد الأقصى مش "النهاردة"
  // عمدًا: موعد ممكن يتحدد "تم" بتاريخ مستقبلي (اختبار، أو تصحيح بأثر رجعي)،
  // و"كل الفترة" المفروض تعني كل حاجة فعلاً من غير أي استثناء مخفي.
  function allTime() {
    setRange({ from: "2000-01-01", to: "2100-01-01" });
  }

  return (
    <section className="card-3d rounded-xl p-5 space-y-4">
      <div>
        <h2 className="font-semibold">مدة المريض في العيادة</h2>
        <p className="mt-1 text-xs text-muted">
          المدة من وقت وصول المريض لحد ما الموعد اتسجل &quot;تم&quot;، بمتوسط لكل طبيب. ابحث باسم مريض بعينه عشان تشوف كل زياراته في الفترة.
        </p>
      </div>

      <div className="flex flex-wrap items-end gap-2">
        <label className="relative text-xs text-muted">
          اسم المريض أو رقم الملف
          <input
            id="duration-patient"
            type="text"
            value={patientQuery}
            onChange={(e) => {
              setPatientQuery(e.target.value);
              setPickedPatientName(null);
            }}
            placeholder="اختياري — سيب فاضي لكل المرضى"
            className={`${input} mt-1 block w-52`}
            autoComplete="off"
          />
          {patientSuggestions.length > 0 && (
            <div className="absolute z-10 mt-1 w-64 card-3d rounded-md shadow-lg overflow-hidden max-h-48 overflow-y-auto">
              {patientSuggestions.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => {
                    setPatientQuery(p.full_name);
                    setPickedPatientName(p.full_name);
                  }}
                  className="w-full text-right px-3 py-1.5 text-sm hover:bg-primary-soft flex items-center justify-between gap-2"
                >
                  <span>{p.full_name}</span>
                  <span className="text-xs text-muted shrink-0">{p.file_number}</span>
                </button>
              ))}
            </div>
          )}
        </label>
        <label className="text-xs text-muted">
          من
          <input
            id="duration-from"
            type="date"
            value={range.from}
            onChange={(e) => setRange((current) => ({ ...current, from: e.target.value }))}
            className={`${input} mt-1 block w-40`}
          />
        </label>
        <label className="text-xs text-muted">
          إلى
          <input
            id="duration-to"
            type="date"
            value={range.to}
            onChange={(e) => setRange((current) => ({ ...current, to: e.target.value }))}
            className={`${input} mt-1 block w-40`}
          />
        </label>
        <label className="text-xs text-muted">
          الطبيب
          <select
            id="duration-doctor"
            value={doctorId}
            onChange={(e) => setDoctorId(e.target.value)}
            className={`${input} mt-1 block w-44`}
          >
            <option value="">كل الأطباء</option>
            {doctors.map((doctor) => (
              <option key={doctor.id} value={doctor.id}>{doctor.full_name}</option>
            ))}
          </select>
        </label>
        <button
          type="button"
          onClick={run}
          disabled={isPending || !range.from || !range.to}
          className="h-9 rounded-md btn-3d-primary px-4 text-sm font-medium disabled:opacity-50"
        >
          {isPending ? "..." : "عرض التقرير"}
        </button>
        <div className="flex gap-1">
          <button type="button" onClick={() => preset(7)} className="h-9 rounded border border-border px-2 text-xs">آخر أسبوع</button>
          <button type="button" onClick={() => preset(30)} className="h-9 rounded border border-border px-2 text-xs">آخر شهر</button>
          <button type="button" onClick={() => preset(90)} className="h-9 rounded border border-border px-2 text-xs">آخر 3 شهور</button>
          <button type="button" onClick={allTime} className="h-9 rounded border border-border px-2 text-xs">كل الفترة</button>
        </div>
      </div>

      {result && !result.ok && (
        <p className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{result.error}</p>
      )}

      {result?.ok && (
        <div className="space-y-4">
          <div className="flex flex-wrap gap-4 text-sm">
            <div className="rounded-md border border-border px-3 py-2">
              <div className="text-xs text-muted">متوسط المدة (كل المواعيد المحسوبة)</div>
              <div className="text-lg font-bold text-primary">{result.rows.length ? formatMinutes(result.overallAverageMinutes) : "—"}</div>
            </div>
            <div className="rounded-md border border-border px-3 py-2">
              <div className="text-xs text-muted">إجمالي مواعيد &quot;تم&quot; في الفترة</div>
              <div className="text-lg font-bold">{result.totalDone}</div>
            </div>
            <div className="rounded-md border border-border px-3 py-2">
              <div className="text-xs text-muted">مواعيد بدون وقت وصول مسجَّل</div>
              <div className="text-lg font-bold text-amber-600">{result.missingAttendedAt}</div>
            </div>
          </div>

          {result.missingAttendedAt > 0 && (
            <p className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
              {result.missingAttendedAt} من أصل {result.totalDone} موعد &quot;تم&quot; في الفترة دي اتسجل بدون وقت وصول (attended_at) — غالبًا لأن الموعد اتقفل &quot;تم&quot; من غير ما يعدّي بحالة &quot;حضر&quot; الأول. المتوسط محسوب من غير المواعيد دي، فلو العدد كبير المتوسط ممكن يكون مش ممثل لكل الزيارات.
            </p>
          )}

          {result.truncated && (
            <p className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
              الفترة دي فيها مواعيد محسوبة أكتر من الحد المعروض (500) في الجدول التفصيلي تحت — المتوسطات والإجماليات فوق محسوبة على كل المواعيد برضه، مش بس المعروض.
            </p>
          )}

          {result.byDoctor.length > 0 && (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border text-right">
                    <th className="p-2">الطبيب</th>
                    <th className="p-2 whitespace-nowrap">عدد المواعيد المحسوبة</th>
                    <th className="p-2 whitespace-nowrap">متوسط المدة</th>
                    <th className="p-2 whitespace-nowrap">بدون وقت وصول</th>
                  </tr>
                </thead>
                <tbody>
                  {result.byDoctor.map((row) => (
                    <tr key={row.doctorId} className="border-b border-border">
                      <td className="p-2 font-medium">{row.doctorName}</td>
                      <td className="p-2">{row.count}</td>
                      <td className="p-2">{row.count ? formatMinutes(row.averageMinutes) : "—"}</td>
                      <td className="p-2 text-amber-700">{row.missingAttendedAt || "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-right">
                  <th className="p-2">المريض</th>
                  <th className="p-2">الطبيب</th>
                  <th className="p-2 whitespace-nowrap">التاريخ</th>
                  <th className="p-2 whitespace-nowrap">وقت الوصول</th>
                  <th className="p-2 whitespace-nowrap">وقت الانتهاء</th>
                  <th className="p-2 whitespace-nowrap">المدة</th>
                </tr>
              </thead>
              <tbody>
                {result.rows.map((row) => (
                  <tr key={row.appointmentId} className="border-b border-border">
                    <td className="p-2">{row.patientName}</td>
                    <td className="p-2">{row.doctorName}</td>
                    <td className="p-2 whitespace-nowrap text-xs text-muted">{row.appointmentDate}</td>
                    <td className="p-2 whitespace-nowrap">{formatTime(row.attendedAt)}</td>
                    <td className="p-2 whitespace-nowrap">{formatTime(row.completedAt)}</td>
                    <td className="p-2 font-medium">{formatMinutes(row.durationMinutes)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!result.rows.length && <p className="py-6 text-center text-sm text-muted">لا توجد مواعيد محسوبة في الفترة المختارة.</p>}
          </div>
        </div>
      )}
    </section>
  );
}
