"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

// مربع البحث فوق صفحة "ملفات المرضى" — كان بيحتاج دوسة على زرار "بحث" (GET
// form عادي). هنا بيبقى فلترة فورية: بمجرد ما المستخدم يكتب، بعد وقفة بسيطة
// (300ms) بيتحدّث الـ URL (?q=...) والصفحة (Server Component) بتجيب النتايج
// من غير أي إعادة تحميل كاملة أو الحاجة لدوسة زرار. بيرجّع لصفحة 1 مع أي بحث
// جديد (نتيجة البحث القديمة مش مضمون يكون فيها نفس عدد الصفحات).
export default function PatientsSearchBar({ initialQuery }: { initialQuery: string }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [value, setValue] = useState(initialQuery);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    setValue(initialQuery);
  }, [initialQuery]);

  useEffect(() => {
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, []);

  function handleChange(next: string) {
    setValue(next);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      const params = new URLSearchParams(searchParams.toString());
      if (next.trim()) params.set("q", next.trim());
      else params.delete("q");
      params.delete("page");
      router.replace(`/patients?${params.toString()}`);
    }, 300);
  }

  return (
    <input
      type="text"
      value={value}
      onChange={(e) => handleChange(e.target.value)}
      placeholder="ابحث بالاسم أو رقم التليفون أو رقم الملف..."
      className="min-w-[16rem] flex-1 rounded-md border border-border bg-surface px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
    />
  );
}
