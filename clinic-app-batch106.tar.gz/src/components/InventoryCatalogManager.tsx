import {
  addInventorySpecialtyAction,
  addInventoryCategoryAction,
  addInventorySupplierAction,
} from "@/app/inventory/actions";

type Specialty = { id: number; name: string; parent_id: number | null };
type Supplier = { id: number; name: string; phone_country_code: string | null; phone: string | null };
type Category = { id: number; specialty_id: number; name: string };

const inputClass = "w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm";
const buttonClass = "rounded-md btn-3d-primary px-3 py-1.5 text-sm font-medium";

// واجهة الإعدادات متعمدة أن تكون صغيرة: التخصص والمورد فقط. تعريف الخامة
// والتوريد والجرد مكانهم الطبيعي صفحة المخزن نفسها، فلا يضطر الموظف للتنقل
// في شجرة كتالوج كبيرة قبل إدخال أول رصيد.
export default function InventoryCatalogManager({
  specialties,
  categories,
  suppliers,
}: {
  specialties: Specialty[];
  categories: Category[];
  products: unknown[];
  attributeGroups: unknown[];
  attributeValues: unknown[];
  units: unknown[];
  suppliers: Supplier[];
}) {
  return <div className="space-y-6">
    <p className="text-sm text-muted">هنا نضبط فقط القوائم العامة. أمّا الخامة ورصيدها وتوريداتها فتُسجّل مباشرة من صفحة المخزن.</p>

    <section className="rounded-xl border border-border p-4 space-y-3">
      <h3 className="font-semibold">التخصصات</h3>
      <form action={addInventorySpecialtyAction} className="grid grid-cols-1 sm:grid-cols-3 gap-2">
        <input name="name" required placeholder="مثال: تقويم أو جينرال" className={inputClass} />
        <select name="parent_id" className={inputClass} defaultValue=""><option value="">تخصص رئيسي</option>{specialties.map((entry) => <option key={entry.id} value={entry.id}>{entry.name}</option>)}</select>
        <button className={buttonClass}>إضافة تخصص</button>
      </form>
      <div className="text-xs text-muted">{specialties.map((entry) => `${entry.parent_id ? `${specialties.find((x) => x.id === entry.parent_id)?.name ?? ""} ← ` : ""}${entry.name}`).join(" · ") || "لا توجد تخصصات بعد"}</div>
    </section>

    <section className="rounded-xl border border-border p-4 space-y-3">
      <h3 className="font-semibold">فئات الخامات</h3>
      <p className="text-xs text-muted">مثال: TADS وBRACKETS وWIRES. الفئة للتنظيم فقط؛ الجرد والخصم يظلان على الخامة نفسها.</p>
      <form action={addInventoryCategoryAction} className="grid grid-cols-1 sm:grid-cols-3 gap-2">
        <select name="specialty_id" required className={inputClass}><option value="">اختر التخصص</option>{specialties.map((entry) => <option key={entry.id} value={entry.id}>{entry.name}</option>)}</select>
        <input name="name" required placeholder="اسم الفئة" className={inputClass} />
        <button className={buttonClass}>إضافة فئة</button>
      </form>
      <div className="text-xs text-muted">{categories.map((entry) => `${specialties.find((x) => x.id === entry.specialty_id)?.name ?? ""}: ${entry.name}`).join(" · ") || "لا توجد فئات بعد"}</div>
    </section>

    <section className="rounded-xl border border-border p-4 space-y-3">
      <h3 className="font-semibold">الموردون</h3>
      <form action={addInventorySupplierAction} className="grid grid-cols-1 sm:grid-cols-4 gap-2">
        <input name="name" required placeholder="اسم المورد" className={inputClass} />
        <input name="phone_country_code" defaultValue="+20" placeholder="كود الدولة" className={inputClass} />
        <input name="phone" placeholder="رقم الموبايل" className={inputClass} />
        <button className={buttonClass}>إضافة مورد</button>
        <input name="notes" placeholder="ملاحظة اختيارية" className={`${inputClass} sm:col-span-4`} />
      </form>
      <div className="text-xs text-muted space-y-1">{suppliers.map((supplier) => <div key={supplier.id}>{supplier.name}{supplier.phone ? ` — ${supplier.phone_country_code ?? "+20"}${supplier.phone}` : ""}</div>)}{!suppliers.length && <div>لا يوجد موردون بعد.</div>}</div>
    </section>

    <p className="text-xs text-muted">
      مَن يستقبل تنبيهات نقص المخزون يُحدد الآن من قسم إعدادات الصلاحيات
      (صلاحية &quot;استقبال تنبيهات نقص المخزون&quot;) بدل قائمة مستلمين منفصلة هنا.
    </p>
  </div>;
}
