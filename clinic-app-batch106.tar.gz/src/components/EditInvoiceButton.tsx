"use client";

import { useState, useTransition } from "react";
import { editPatientBillingEntryAction } from "@/app/patients/[id]/billing/actions";
import { PAYMENT_METHODS } from "@/lib/payment-methods";

type Service = { id: number; name: string };
type Doctor = { id: number; full_name: string };
type BillableInvoice = { id: number; service_name: string; visit_date: string; balance: number };

// زرار "تعديل" جنب "حذف" في جدول الملف المالي — دفعة 106. بيفتح فورم صغير
// يعدل كل حاجة في الصف (المبلغ/الخصم/طريقة الدفع/الدكتور/التاريخ/الخدمة
// المرتبطة) من غير ما يحتاج المستخدم يحذف الصف ويسجله تاني. محصور بصلاحية
// edit_patient_billing_entry (التحقق الحقيقي في الأكشن على السيرفر).
export default function EditInvoiceButton({
  invoiceId,
  patientId,
  isFollowupRow,
  initial,
  services,
  doctors,
  billableInvoices,
}: {
  invoiceId: number;
  patientId: number;
  isFollowupRow: boolean;
  initial: {
    doctorId: number | null;
    invoiceDate: string;
    paymentMethod: string | null;
    paid: number;
    serviceId: number | null;
    originalPrice: number | null;
    discountPercent: number;
    parentInvoiceId: number | null;
  };
  services: Service[];
  doctors: Doctor[];
  billableInvoices: BillableInvoice[];
}) {
  const [open, setOpen] = useState(false);
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  const [doctorId, setDoctorId] = useState(String(initial.doctorId ?? ""));
  const [invoiceDate, setInvoiceDate] = useState(initial.invoiceDate);
  const [paymentMethod, setPaymentMethod] = useState(initial.paymentMethod ?? "cash");
  const [paid, setPaid] = useState(String(initial.paid));
  const [serviceId, setServiceId] = useState(String(initial.serviceId ?? ""));
  const [price, setPrice] = useState(String(initial.originalPrice ?? 0));
  const [discountPercent, setDiscountPercent] = useState(String(initial.discountPercent ?? 0));
  const [targetInvoiceId, setTargetInvoiceId] = useState(String(initial.parentInvoiceId ?? ""));

  function submit() {
    setError(null);
    const fd = new FormData();
    fd.set("invoice_id", String(invoiceId));
    fd.set("patient_id", String(patientId));
    fd.set("doctor_id", doctorId);
    fd.set("invoice_date", invoiceDate);
    fd.set("payment_method", paymentMethod);
    fd.set("paid", paid);
    if (isFollowupRow) {
      fd.set("target_invoice_id", targetInvoiceId);
    } else {
      fd.set("service_id", serviceId);
      fd.set("price", price);
      fd.set("discount_percent", discountPercent);
    }
    startTransition(async () => {
      const result = await editPatientBillingEntryAction(fd);
      if (!result.ok) {
        setError(result.reason ?? "معرفناش نحفظ التعديل.");
        return;
      }
      setOpen(false);
    });
  }

  if (!open) {
    return (
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          setOpen(true);
        }}
        className="text-xs text-primary hover:underline ms-2"
      >
        تعديل
      </button>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={() => setOpen(false)}>
      <div
        className="card-3d rounded-xl p-5 space-y-3 w-full max-w-md bg-background"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="font-semibold">تعديل صف الملف المالي</h3>

        {isFollowupRow ? (
          <div>
            <label className="block text-xs text-muted mb-1">الخدمة الأصلية (اللي مربوطة بيها الدفعة)</label>
            <select
              value={targetInvoiceId}
              onChange={(e) => setTargetInvoiceId(e.target.value)}
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
            >
              <option value="">اختر خدمة</option>
              {billableInvoices.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.service_name} — {b.visit_date}
                </option>
              ))}
            </select>
          </div>
        ) : (
          <>
            <div>
              <label className="block text-xs text-muted mb-1">الخدمة</label>
              <select
                value={serviceId}
                onChange={(e) => setServiceId(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              >
                <option value="">اختر خدمة</option>
                {services.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-muted mb-1">السعر الأصلي</label>
                <input
                  type="number"
                  step="0.01"
                  min={0}
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs text-muted mb-1">خصم (%)</label>
                <input
                  type="number"
                  step="1"
                  min={0}
                  max={100}
                  value={discountPercent}
                  onChange={(e) => setDiscountPercent(e.target.value)}
                  className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                />
              </div>
            </div>
          </>
        )}

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs text-muted mb-1">المدفوع</label>
            <input
              type="number"
              step="0.01"
              min={0}
              value={paid}
              onChange={(e) => setPaid(e.target.value)}
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">طريقة الدفع</label>
            <select
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value)}
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
            >
              {PAYMENT_METHODS.map((m) => (
                <option key={m.value} value={m.value}>
                  {m.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs text-muted mb-1">التاريخ</label>
            <input
              type="date"
              value={invoiceDate}
              onChange={(e) => setInvoiceDate(e.target.value)}
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">الدكتور</label>
            <select
              value={doctorId}
              onChange={(e) => setDoctorId(e.target.value)}
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
            >
              <option value="">اختر دكتور</option>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.full_name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {error && <div className="text-xs text-danger">{error}</div>}

        <div className="flex gap-2 justify-end">
          <button
            type="button"
            onClick={() => setOpen(false)}
            className="rounded-md border border-border px-3 py-1.5 text-sm"
          >
            إلغاء
          </button>
          <button
            type="button"
            disabled={isPending}
            onClick={submit}
            className="rounded-md btn-3d-primary px-3 py-1.5 text-sm font-medium disabled:opacity-60"
          >
            {isPending ? "جاري الحفظ..." : "حفظ"}
          </button>
        </div>
      </div>
    </div>
  );
}
