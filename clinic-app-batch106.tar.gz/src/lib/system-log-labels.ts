// أسماء عربية لأنواع أحداث سجل النظام.
//
// الملف ده مستقل عن system-log-actions.ts عن قصد: ملف فيه "use server" مسموح
// يصدّر دوال async **بس**. تصدير ثابت زي الكائن ده من ملف سيرفر بيعدّي البناء
// لكنه بيكسر الصفحة وقت التشغيل أول ما مكوّن عميل يستورده — وده اللي حصل فعلاً
// في دفعة 98 قبل الإصلاح. نفس السبب اللي خلى permission-defs.ts منفصل عن
// permissions.ts في المشروع من الأصل.
//
// أي حدث جديد مش في القايمة بيتعرض بمفتاحه الخام بدل ما يختفي، فإضافة حدث في
// الكود متحتاجش تعديل هنا عشان يبان في التقرير.
export const EVENT_LABELS: Record<string, string> = {
  delete_patient: "حذف مريض",
  update_patient: "تعديل بيانات مريض",
  delete_visit: "حذف زيارة",
  delete_expense: "حذف مصروف",
  clear_expenses_data: "مسح بيانات المصروفات",
  save_compensation_rule: "حفظ قاعدة راتب",
  stop_compensation_rule: "إيقاف قاعدة راتب",
  delete_compensation_rule: "حذف قاعدة راتب",
  end_employment: "إنهاء خدمة موظف",
  delete_document: "حذف مستند HR",
  deactivate_user: "إيقاف مستخدم",
  create_user: "إنشاء مستخدم",
  reset_password: "تصفير كلمة سر",
  update_permissions: "تغيير صلاحيات",
  appointment_status: "تغيير حالة موعد",
  collect_payment: "تحصيل دفعة",
};

export function eventLabel(event: string) {
  return EVENT_LABELS[event] || event;
}
