import "server-only";
import { sql } from "kysely";
import { db } from "./db/client";

// قفل بسيط ضد تجربة كلمات السر: 5 محاولات فاشلة لنفس اسم المستخدم خلال 15
// دقيقة = قفل 15 دقيقة. مقصود يكون بسيط — مفيش قفل دائم يحتاج تدخل الأدمن
// (ده كان هيخلي أي حد يقدر يقفل حساب أي حد تاني بمحاولات غلط متعمدة).
export const MAX_FAILED_ATTEMPTS = 5;
export const LOCK_WINDOW_MINUTES = 15;

export type LoginLockState = { locked: boolean; minutesLeft: number };

export async function getLoginLockState(username: string): Promise<LoginLockState> {
  const key = username.toLowerCase();

  // آخر نجاح بيصفّر العدّاد: اللي دخل بنجاح مش مفروض تتحسب عليه محاولاته القديمة.
  const lastSuccess = await db
    .selectFrom("login_attempts")
    .select("attempted_at")
    .where("username", "=", key)
    .where("succeeded", "=", 1)
    .orderBy("id", "desc")
    .executeTakeFirst();

  let query = db
    .selectFrom("login_attempts")
    .select(["attempted_at"])
    .where("username", "=", key)
    .where("succeeded", "=", 0)
    .where(sql<boolean>`attempted_at > datetime('now', '-${sql.raw(String(LOCK_WINDOW_MINUTES))} minutes')`);
  if (lastSuccess) query = query.where("attempted_at", ">", lastSuccess.attempted_at);

  const failures = await query.orderBy("id", "desc").execute();
  if (failures.length < MAX_FAILED_ATTEMPTS) return { locked: false, minutesLeft: 0 };

  const newest = failures[0].attempted_at;
  const unlockAt = new Date(`${newest.replace(" ", "T")}Z`).getTime() + LOCK_WINDOW_MINUTES * 60_000;
  const minutesLeft = Math.max(1, Math.ceil((unlockAt - Date.now()) / 60_000));
  return { locked: true, minutesLeft };
}

export async function recordLoginAttempt(username: string, succeeded: boolean) {
  await db
    .insertInto("login_attempts")
    .values({ username: username.toLowerCase(), succeeded: succeeded ? 1 : 0 })
    .execute();

  // تنظيف خفيف: السجل ده للحماية مش للأرشيف، فمفيش داعي يكبر بلا حد.
  await db
    .deleteFrom("login_attempts")
    .where(sql<boolean>`attempted_at <= datetime('now', '-7 days')`)
    .execute();
}
