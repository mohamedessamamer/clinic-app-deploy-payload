import "server-only";

import { db } from "@/lib/db/client";
import { getAllSettings } from "@/lib/settings";
import { getUsersWithPermission } from "@/lib/permissions";

function sqlNow() {
  return new Date().toISOString().replace("T", " ").slice(0, 19);
}

function notificationExpiry(hours: number) {
  return new Date(Date.now() + Math.max(1, hours) * 3_600_000).toISOString().replace("T", " ").slice(0, 19);
}

function suggestedQuantity(item: { reorder_quantity: number; low_stock_threshold: number; quantity: number }): number {
  if (item.reorder_quantity > 0) return item.reorder_quantity;
  // Fallback معقول لو لم يحدد المستخدم كمية الطلب: نصل إلى ضعف حد التنبيه على
  // الأقل، وبحد أدنى قطعة/وحدة واحدة. يستطيع تعديل الكمية لاحقاً قبل الإرسال.
  return Math.max(1, Math.ceil(Math.max(item.low_stock_threshold * 2 - item.quantity, 1)));
}

async function openDraftForSupplier(supplierId: number): Promise<number> {
  const existing = await db
    .selectFrom("inventory_purchase_drafts")
    .select("id")
    .where("supplier_id", "=", supplierId)
    .where("status", "=", "open")
    .orderBy("id", "desc")
    .executeTakeFirst();
  if (existing) return existing.id;
  const inserted = await db
    .insertInto("inventory_purchase_drafts")
    .values({ supplier_id: supplierId, status: "open", updated_at: sqlNow() })
    .executeTakeFirstOrThrow();
  return Number(inserted.insertId);
}

async function addToSupplierDraft(item: {
  id: number;
  supplier_id: number | null;
  reorder_quantity: number;
  low_stock_threshold: number;
  quantity: number;
}) {
  if (!item.supplier_id) return;
  const draftId = await openDraftForSupplier(item.supplier_id);
  await db
    .insertInto("inventory_purchase_draft_items")
    .values({ draft_id: draftId, item_id: item.id, suggested_quantity: suggestedQuantity(item) })
    .onConflict((oc) => oc.columns(["draft_id", "item_id"]).doUpdateSet({ suggested_quantity: suggestedQuantity(item) }))
    .execute();
  await db.updateTable("inventory_purchase_drafts").set({ updated_at: sqlNow() }).where("id", "=", draftId).execute();
}

async function sendInventoryNotification(input: {
  recipients: number[];
  itemId: number;
  cycle: number;
  level: "low" | "critical";
  itemName: string;
  quantity: number;
  unit: string | null;
  supplierName: string | null;
  retentionHours: number;
}) {
  if (!input.recipients.length) return;
  const title = input.level === "critical" ? "نقص مخزون حرج" : "صنف قرب من حد الطلب";
  const amount = `${input.quantity} ${input.unit ?? ""}`.trim();
  const supplierText = input.supplierName ? ` أُضيف لمسودة طلب ${input.supplierName}.` : " لم يُحدد له مورد بعد.";
  await db
    .insertInto("notifications")
    .values(
      input.recipients.map((recipient_user_id) => ({
        recipient_user_id,
        type: "inventory_low_stock",
        title,
        body: `${input.itemName}: الرصيد الحالي ${amount}.${supplierText}`,
        patient_id: null,
        notification_case_id: null,
        dedupe_key: `inventory_stock:${input.itemId}:${input.cycle}:${input.level}`,
        expires_at: notificationExpiry(input.retentionHours),
      }))
    )
    .onConflict((oc) => oc.columns(["recipient_user_id", "dedupe_key"]).doNothing())
    .execute();
}

// تستدعى بعد تعديل رصيد، وأيضاً عند فتح مركز الإشعارات. لا تنشئ طلب شراء إلا
// عند أول وصول للحد أو عند العودة إليه بعد توريد جديد؛ لذلك لا تتكرر المسودات.
export async function evaluateInventoryReorderNeeds() {
  const [settings, recipients, items] = await Promise.all([
    getAllSettings(),
    getUsersWithPermission("receive_low_stock_alerts"),
    db
      .selectFrom("inventory_items")
      .leftJoin("inventory_suppliers", "inventory_suppliers.id", "inventory_items.supplier_id")
      .select([
        "inventory_items.id",
        "inventory_items.name",
        "inventory_items.quantity",
        "inventory_items.unit",
        "inventory_items.low_stock_threshold",
        "inventory_items.critical_stock_threshold",
        "inventory_items.reorder_quantity",
        "inventory_items.supplier_id",
        "inventory_suppliers.name as supplier_name",
      ])
      .where("inventory_items.low_stock_threshold", ">", 0)
      .execute(),
  ]);
  const retentionHours = Math.max(1, Number(settings.notification_retention_hours) || 48);

  for (const item of items) {
    const alert = await db.selectFrom("inventory_stock_alerts").selectAll().where("item_id", "=", item.id).executeTakeFirst();
    const belowThreshold = item.quantity <= item.low_stock_threshold;
    if (!belowThreshold) {
      if (alert && !alert.resolved_at) {
        await db
          .updateTable("inventory_stock_alerts")
          .set({ resolved_at: sqlNow(), updated_at: sqlNow() })
          .where("item_id", "=", item.id)
          .execute();
      }
      // لو تم توريد الصنف قبل إرسال الطلب، نحذفه من كل مسودة ما زالت مفتوحة؛
      // بذلك لا يبقى في رسالة المورد صنف لم يعد محتاجًا للشراء.
      await db
        .deleteFrom("inventory_purchase_draft_items")
        .where("item_id", "=", item.id)
        .where("draft_id", "in", (query) => query.selectFrom("inventory_purchase_drafts").select("id").where("status", "=", "open"))
        .execute();
      continue;
    }

    const level: "low" | "critical" = item.quantity <= item.critical_stock_threshold ? "critical" : "low";
    const isNewCycle = !alert || alert.resolved_at != null;
    const isLevelUpgrade = Boolean(alert && alert.resolved_at == null && alert.level !== "critical" && level === "critical");
    let cycle = alert?.cycle ?? 1;

    if (isNewCycle) {
      cycle = alert ? alert.cycle + 1 : 1;
      await db
        .insertInto("inventory_stock_alerts")
        .values({ item_id: item.id, level, cycle, resolved_at: null, updated_at: sqlNow() })
        .onConflict((oc) =>
          oc.column("item_id").doUpdateSet({ level, cycle, resolved_at: null, updated_at: sqlNow() })
        )
        .execute();
      await addToSupplierDraft(item);
    } else if (isLevelUpgrade) {
      await db.updateTable("inventory_stock_alerts").set({ level, updated_at: sqlNow() }).where("item_id", "=", item.id).execute();
      await addToSupplierDraft(item);
    }

    if (isNewCycle || isLevelUpgrade) {
      await sendInventoryNotification({
        recipients,
        itemId: item.id,
        cycle,
        level,
        itemName: item.name,
        quantity: item.quantity,
        unit: item.unit,
        supplierName: item.supplier_name,
        retentionHours,
      });
    }
  }
}

export function supplierWhatsAppUrl(phoneCountryCode: string | null, localPhone: string | null, message: string): string | null {
  if (!localPhone) return null;
  const country = (phoneCountryCode ?? "+20").replace(/\D/g, "");
  const local = localPhone.replace(/\D/g, "").replace(/^0+/, "");
  if (!country || !local) return null;
  return `https://wa.me/${country}${local}?text=${encodeURIComponent(message)}`;
}

export function supplierOrderMessage(supplierName: string, items: Array<{ name: string; quantity: number; unit: string | null }>): string {
  const lines = items.map((item) => `- ${item.name}: ${item.quantity} ${item.unit ?? ""}`.trim());
  return [`السلام عليكم، نحتاج طلب الأصناف التالية من ${supplierName}:`, ...lines].join("\n");
}
