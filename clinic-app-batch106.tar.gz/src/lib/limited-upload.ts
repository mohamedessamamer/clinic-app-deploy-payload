import { Transform, type TransformCallback } from "node:stream";

export class UploadTooLargeError extends Error {
  readonly maximumBytes: number;

  constructor(maximumBytes: number) {
    super(`Upload exceeds ${maximumBytes} bytes`);
    this.name = "UploadTooLargeError";
    this.maximumBytes = maximumBytes;
  }
}

export function assertContentLengthWithinLimit(contentLength: string | null, maximumBytes: number) {
  if (contentLength == null) return;
  const parsed = Number(contentLength);
  if (!Number.isFinite(parsed) || parsed < 0 || parsed > maximumBytes) {
    throw new UploadTooLargeError(maximumBytes);
  }
}

export class ByteLimitTransform extends Transform {
  private receivedBytes = 0;
  private readonly maximumBytes: number;

  constructor(maximumBytes: number) {
    super();
    this.maximumBytes = maximumBytes;
  }

  override _transform(chunk: Buffer, _encoding: BufferEncoding, callback: TransformCallback) {
    this.receivedBytes += chunk.length;
    if (this.receivedBytes > this.maximumBytes) {
      callback(new UploadTooLargeError(this.maximumBytes));
      return;
    }
    callback(null, chunk);
  }
}
