const INTERNAL_ORIGIN = "https://clinic.internal";

/** Returns a same-origin path, never a scheme-relative or backslash URL. */
export function safeInternalRedirect(candidate: string, fallback = "/") {
  if (!candidate.startsWith("/") || candidate.startsWith("//") || candidate.includes("\\")) {
    return fallback;
  }

  try {
    const parsed = new URL(candidate, INTERNAL_ORIGIN);
    if (parsed.origin !== INTERNAL_ORIGIN) return fallback;
    return `${parsed.pathname}${parsed.search}${parsed.hash}`;
  } catch {
    return fallback;
  }
}
