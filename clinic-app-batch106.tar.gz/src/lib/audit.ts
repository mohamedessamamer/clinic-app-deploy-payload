import { db } from "./db/client";

// تسجيل حدث إداري حساس (حذف/مسح بيانات، تغيير صلاحية أو دور، تعديل راتب).
// بيستخدم نفس جدول audit_log بتاع تعديلات الأسعار — العمود field بياخد اسم
// الحدث والـnew_value بياخد وصفه، عشان منضيفش جدول جديد بلا داعي.
export async function logAdminEvent(params: {
  entityType: string;
  entityId: number;
  event: string;
  details: string;
  changedBy: number | null;
}) {
  await db
    .insertInto("audit_log")
    .values({
      entity_type: params.entityType,
      entity_id: params.entityId,
      field: params.event,
      old_value: null,
      new_value: params.details,
      changed_by: params.changedBy,
      reason: null,
    })
    .execute();
}

export async function logOverride(params: {
  entityType: string;
  entityId: number;
  field: string;
  oldValue: string | number | null;
  newValue: string | number | null;
  changedBy: number | null;
  reason?: string | null;
}) {
  await db
    .insertInto("audit_log")
    .values({
      entity_type: params.entityType,
      entity_id: params.entityId,
      field: params.field,
      old_value: params.oldValue === null ? null : String(params.oldValue),
      new_value: params.newValue === null ? null : String(params.newValue),
      changed_by: params.changedBy,
      reason: params.reason ?? null,
    })
    .execute();
}
