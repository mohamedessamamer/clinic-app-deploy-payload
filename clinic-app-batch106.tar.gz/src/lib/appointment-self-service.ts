import "server-only";

import { createHash, randomBytes } from "node:crypto";
import { db } from "@/lib/db/client";
import { buildTimeSlots, getAllSettings, weekdayOf } from "@/lib/settings";
import { getClinicToday } from "@/lib/clinic-date";
import { createNotifications } from "@/lib/notifications";

export const hashAppointmentToken = (token: string) => createHash("sha256").update(token).digest("hex");
const sqlNow = () => new Date().toISOString().replace("T", " ").slice(0, 19);
const addHours = (hours: number) => new Date(Date.now() + hours * 3_600_000).toISOString().replace("T", " ").slice(0, 19);
const minutes = (time: string) => { const [h, m] = time.slice(0, 5).split(":").map(Number); return h * 60 + m; };
const addDays = (date: string, days: number) => { const [y, m, d] = date.split("-").map(Number); const value = new Date(Date.UTC(y, m - 1, d + days)); return value.toISOString().slice(0, 10); };

export async function issueAppointmentLink(appointmentId: number, deliveryMethod: "automatic" | "manual") {
  const appointment = await db.selectFrom("appointments").select(["id", "patient_id", "appointment_date"]).where("id", "=", appointmentId).where("status", "=", "booked").where("reschedule_pending", "=", 0).executeTakeFirst();
  if (!appointment?.patient_id) throw new Error("الموعد غير متاح لإنشاء رابط.");
  const settings = await getAllSettings();
  const rawToken = randomBytes(32).toString("base64url");
  const tokenHash = hashAppointmentToken(rawToken);
  const expiresAt = addHours(Math.max(1, Number(settings.whatsapp_reminder_valid_hours) || 3));
  const now = sqlNow();
  await db.insertInto("appointment_reminders").values({
    appointment_id: appointment.id, patient_id: appointment.patient_id, token_hash: tokenHash,
    delivery_method: deliveryMethod, appointment_date: appointment.appointment_date, expires_at: expiresAt,
    sent_at: deliveryMethod === "manual" ? now : null, updated_at: now,
  }).onConflict((oc) => oc.columns(["appointment_id", "appointment_date"]).doUpdateSet({
    token_hash: tokenHash, delivery_method: deliveryMethod, expires_at: expiresAt,
    sent_at: deliveryMethod === "manual" ? now : null, response_status: "pending", responded_at: null,
    requested_date: null, requested_time: null, requested_room_id: null, approved_by: null, approved_at: null,
    error_message: null, updated_at: now,
  })).execute();
  return { rawToken, url: `${settings.clinic_public_url.replace(/\/$/, "")}/appointment/manage/${rawToken}`, expiresAt };
}

async function lookup(token: string, requireValid = true) {
  if (!token || token.length < 24 || token.length > 200) return null;
  let query = db.selectFrom("appointment_reminders")
    .innerJoin("appointments", "appointments.id", "appointment_reminders.appointment_id")
    .innerJoin("doctors", "doctors.id", "appointments.doctor_id")
    .innerJoin("rooms", "rooms.id", "appointments.room_id")
    .innerJoin("patients", "patients.id", "appointments.patient_id")
    .select(["appointment_reminders.id as reminder_id", "appointment_reminders.response_status", "appointment_reminders.expires_at", "appointments.id as appointment_id", "appointments.patient_id", "appointments.doctor_id", "appointments.room_id", "appointments.appointment_date", "appointments.start_time", "appointments.duration_minutes", "appointments.status", "appointments.reschedule_pending", "doctors.full_name as doctor_name", "rooms.name as room_name", "patients.full_name as patient_name"])
    .where("appointment_reminders.token_hash", "=", hashAppointmentToken(token));
  if (requireValid) query = query.where("appointment_reminders.expires_at", ">", sqlNow());
  return query.executeTakeFirst();
}

export async function getAppointmentManageState(token: string) {
  const row = await lookup(token, false);
  if (!row) return { state: "invalid" as const };
  // فحص الانتهاء بيتطبق على كل الحالات مش على "pending" بس — قبل كده كان أي
  // توكن اتأكد عليه المريض يفضل بيعرض اسمه واسم دكتوره وتاريخ موعده للأبد
  // لأي حد معاه الرابط القديم من واتساب.
  if (row.expires_at <= sqlNow()) return { state: "expired" as const };
  return { state: "ok" as const, appointment: {
    patientName: row.patient_name, doctorName: row.doctor_name, roomName: row.room_name, date: row.appointment_date,
    time: row.start_time.slice(0, 5), responseStatus: row.response_status,
  }};
}

export async function confirmAppointmentByToken(token: string) {
  const row = await lookup(token);
  if (!row || row.status !== "booked" || row.response_status !== "pending") return { ok: false, error: "الرابط منتهي أو تم استخدامه." };
  const now = sqlNow();
  await db.transaction().execute(async (trx) => {
    await trx.updateTable("appointment_reminders").set({ response_status: "confirmed", responded_at: now, updated_at: now }).where("id", "=", row.reminder_id).execute();
    await trx.updateTable("appointments").set({ confirmed_at: now }).where("id", "=", row.appointment_id).execute();
  });
  return { ok: true };
}

async function shiftWindows(doctorId: number, date: string) {
  const settings = await getAllSettings();
  const [weekly, exceptions] = await Promise.all([
    db.selectFrom("doctor_weekly_shifts").select(["room_id", "start_time", "end_time"]).where("doctor_id", "=", doctorId).where("weekday", "=", weekdayOf(date)).execute(),
    db.selectFrom("doctor_date_shifts").select(["room_id", "doctor_id"]).where("shift_date", "=", date).execute(),
  ]);
  const exceptionByRoom = new Map(exceptions.map((row) => [row.room_id, row.doctor_id]));
  const result = weekly.filter((row) => !exceptionByRoom.has(row.room_id) || exceptionByRoom.get(row.room_id) === doctorId);
  for (const exception of exceptions.filter((row) => row.doctor_id === doctorId)) {
    if (!result.some((row) => row.room_id === exception.room_id)) result.push({ room_id: exception.room_id, start_time: settings.day_start, end_time: settings.day_end });
  }
  return result;
}

async function slotIsFree(executor: typeof db, appointmentId: number, roomId: number, date: string, time: string, duration: number) {
  const rows = await executor.selectFrom("appointments").select(["id", "start_time", "duration_minutes"])
    .where("room_id", "=", roomId).where("appointment_date", "=", date)
    .where("status", "not in", ["cancelled", "no_show"]).where("id", "!=", appointmentId).execute();
  const start = minutes(time), end = start + duration;
  return !rows.some((row) => { const otherStart = minutes(row.start_time); const otherEnd = otherStart + (row.duration_minutes || 15); return start < otherEnd && end > otherStart; });
}

// كانت بتنفّذ استعلام منفصل لكل خانة زمنية (30 يوم × شيفتات × خانات ≈ 1500
// استعلام متتابع في تحميل صفحة واحدة عامة، من غير تسجيل دخول). دلوقتي كل
// البيانات بتتقرا في 3 استعلامات ثابتة والحساب بيتم في الذاكرة — نفس المنطق
// بالحرف، بس من غير الدور على قاعدة البيانات جوه الحلقات.
export async function getAvailableAppointmentSlots(token: string) {
  const row = await lookup(token);
  if (!row || row.status !== "booked" || row.response_status !== "pending") return { ok: false, error: "الرابط منتهي أو تم استخدامه.", days: [] };
  const settings = await getAllSettings();
  const today = getClinicToday();
  const lastDate = addDays(today, 30);
  const duration = row.duration_minutes || Number(settings.slot_minutes) || 15;
  const slotMinutes = Number(settings.slot_minutes) || 15;

  const [weeklyShifts, dateShifts, bookedAppointments] = await Promise.all([
    db.selectFrom("doctor_weekly_shifts").select(["weekday", "room_id", "start_time", "end_time"]).where("doctor_id", "=", row.doctor_id).execute(),
    db.selectFrom("doctor_date_shifts").select(["shift_date", "room_id", "doctor_id"]).where("shift_date", ">=", today).where("shift_date", "<=", lastDate).execute(),
    db.selectFrom("appointments").select(["room_id", "appointment_date", "start_time", "duration_minutes"])
      .where("appointment_date", ">=", today).where("appointment_date", "<=", lastDate)
      .where("status", "not in", ["cancelled", "no_show"]).where("id", "!=", row.appointment_id).execute(),
  ]);

  const weeklyByWeekday = new Map<number, typeof weeklyShifts>();
  for (const shift of weeklyShifts) {
    const list = weeklyByWeekday.get(shift.weekday) ?? [];
    list.push(shift);
    weeklyByWeekday.set(shift.weekday, list);
  }
  const dateShiftsByDate = new Map<string, typeof dateShifts>();
  for (const shift of dateShifts) {
    const list = dateShiftsByDate.get(shift.shift_date) ?? [];
    list.push(shift);
    dateShiftsByDate.set(shift.shift_date, list);
  }
  // مفتاح "التاريخ|الغرفة" — نفس تقسيمة الاستعلام القديم بالظبط.
  const busyByDateRoom = new Map<string, { start: number; end: number }[]>();
  for (const appointment of bookedAppointments) {
    const key = `${appointment.appointment_date}|${appointment.room_id}`;
    const start = minutes(appointment.start_time);
    const list = busyByDateRoom.get(key) ?? [];
    list.push({ start, end: start + (appointment.duration_minutes || 15) });
    busyByDateRoom.set(key, list);
  }

  const days: { date: string; slots: { time: string; roomId: number; available: boolean }[] }[] = [];
  for (let offset = 0; offset <= 30; offset++) {
    const date = addDays(today, offset);
    const weekly = weeklyByWeekday.get(weekdayOf(date)) ?? [];
    const exceptions = dateShiftsByDate.get(date) ?? [];
    const exceptionByRoom = new Map(exceptions.map((item) => [item.room_id, item.doctor_id]));
    const windows = weekly
      .filter((item) => !exceptionByRoom.has(item.room_id) || exceptionByRoom.get(item.room_id) === row.doctor_id)
      .map((item) => ({ room_id: item.room_id, start_time: item.start_time, end_time: item.end_time }));
    for (const exception of exceptions.filter((item) => item.doctor_id === row.doctor_id)) {
      if (!windows.some((item) => item.room_id === exception.room_id)) {
        windows.push({ room_id: exception.room_id, start_time: settings.day_start, end_time: settings.day_end });
      }
    }
    if (!windows.length) continue;

    const slots: { time: string; roomId: number; available: boolean }[] = [];
    for (const window of windows) {
      const busy = busyByDateRoom.get(`${date}|${window.room_id}`) ?? [];
      for (const time of buildTimeSlots(window.start_time, window.end_time, slotMinutes)) {
        if (minutes(time) + duration > minutes(window.end_time)) continue;
        const start = minutes(time);
        const end = start + duration;
        slots.push({ time, roomId: window.room_id, available: !busy.some((item) => start < item.end && end > item.start) });
      }
    }
    days.push({ date, slots: slots.sort((a, b) => a.time.localeCompare(b.time)) });
  }
  return { ok: true, days };
}

export async function reserveRescheduleByToken(token: string, date: string, time: string, roomId: number) {
  const row = await lookup(token);
  if (!row || row.status !== "booked" || row.response_status !== "pending") return { ok: false, error: "الرابط منتهي أو تم استخدامه." };
  const today = getClinicToday();
  if (date < today || date > addDays(today, 30)) return { ok: false, error: "التاريخ خارج الشهر المتاح." };
  const settings = await getAllSettings();
  const duration = row.duration_minutes || Number(settings.slot_minutes) || 15;
  const windows = await shiftWindows(row.doctor_id, date);
  const window = windows.find((item) => item.room_id === roomId && minutes(time) >= minutes(item.start_time) && minutes(time) + duration <= minutes(item.end_time));
  if (!window) return { ok: false, error: "هذا الموعد ليس ضمن شيفت الطبيب." };
  const result = await db.transaction().execute(async (trx) => {
    if (!(await slotIsFree(trx as typeof db, row.appointment_id, roomId, date, time, duration))) return { ok: false, error: "الخانة حُجزت للتو. اختر خانة أخرى." };
    const now = sqlNow();
    await trx.updateTable("appointments").set({ appointment_date: date, start_time: time, room_id: roomId, reschedule_pending: 1, confirmed_at: null, attended_at: null }).where("id", "=", row.appointment_id).execute();
    await trx.updateTable("appointment_reminders").set({ response_status: "reschedule_pending", responded_at: now, requested_date: date, requested_time: time, requested_room_id: roomId, updated_at: now }).where("id", "=", row.reminder_id).execute();
    return { ok: true };
  });
  if (result.ok) {
    const recipients = await db.selectFrom("users").select("id").where("active", "=", 1).where("role", "in", ["reception", "admin", "clinic_manager"]).execute();
    await createNotifications({
      recipientUserIds: recipients.map((user) => user.id),
      type: "appointment_reschedule_pending",
      title: "موعد معدل ينتظر الاعتماد",
      body: `${row.patient_name}: طلب تغيير الموعد إلى ${date} الساعة ${time.slice(0, 5)}.`,
      patientId: row.patient_id,
      dedupeKey: `appointment-reschedule:${row.reminder_id}:${date}:${time}`,
    });
  }
  return result;
}
