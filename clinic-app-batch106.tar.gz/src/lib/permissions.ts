import "server-only";
import { db } from "./db/client";
import type { Role } from "./auth";
import { PERMISSION_DEFS, ROLE_DEFAULT_PERMISSIONS, type PermissionKey } from "./permission-defs";

// نظام صلاحيات مرن: كل مفتاح صلاحية له قيمة افتراضية حسب دور المستخدم (role)،
// وأي صف في user_permissions بيبقى "استثناء" (override) فوق الافتراضي ده.
// غياب الصف = استخدم افتراضي الدور. الأدمن مينفعش تتغيّر صلاحياته (دايمًا كل حاجة).
// الثوابت (PERMISSION_DEFS, ROLE_DEFAULT_PERMISSIONS) منقولة لـ permission-defs.ts
// عشان يصلحوا للاستيراد من مكونات العميل من غير ما يجروا db/client.ts (server-only) معاهم.
export { PERMISSION_DEFS, ROLE_DEFAULT_PERMISSIONS, type PermissionKey };

export async function getPermissionOverrides(userId: number): Promise<Record<string, boolean>> {
  const rows = await db
    .selectFrom("user_permissions")
    .select(["permission_key", "granted"])
    .where("user_id", "=", userId)
    .execute();
  return Object.fromEntries(rows.map((r) => [r.permission_key, r.granted === 1]));
}

export async function hasPermission(userId: number, role: Role, key: PermissionKey): Promise<boolean> {
  if (role === "admin") return true; // الأدمن دايمًا عنده كل الصلاحيات، مش قابل للتقييد.
  const row = await db
    .selectFrom("user_permissions")
    .select("granted")
    .where("user_id", "=", userId)
    .where("permission_key", "=", key)
    .executeTakeFirst();
  if (row) return row.granted === 1;
  return ROLE_DEFAULT_PERMISSIONS[role]?.includes(key) ?? false;
}

export async function setPermissionOverride(userId: number, key: string, granted: boolean) {
  await db
    .insertInto("user_permissions")
    .values({ user_id: userId, permission_key: key, granted: granted ? 1 : 0 })
    .onConflict((oc) => oc.columns(["user_id", "permission_key"]).doUpdateSet({ granted: granted ? 1 : 0 }))
    .execute();
}

// رجوع الصلاحية لوضعها الافتراضي (حسب الدور) بحذف الاستثناء.
export async function clearPermissionOverride(userId: number, key: string) {
  await db.deleteFrom("user_permissions").where("user_id", "=", userId).where("permission_key", "=", key).execute();
}

// كل المستخدمين اللي فعليًا عندهم صلاحية معينة (سواء بافتراضي الدور أو باستثناء
// صريح)، مفيدة لأي مكان محتاج "مين يوصله كذا" بدل إعداد مستلمين منفصل. الأدمن
// دايمًا معدود (زي hasPermission بالظبط).
export async function getUsersWithPermission(key: PermissionKey): Promise<number[]> {
  const users = await db.selectFrom("users").select(["id", "role"]).execute();
  const results = await Promise.all(
    users.map(async (user) => ((await hasPermission(user.id, user.role as Role, key)) ? user.id : null))
  );
  return results.filter((id): id is number => id !== null);
}
