export const MAX_MONEY_AMOUNT = 1_000_000_000;

export function parseMoney(value: FormDataEntryValue | null): number | null {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < 0 || parsed > MAX_MONEY_AMOUNT) return null;
  return Math.round(parsed * 100) / 100;
}

export function parsePercent(value: FormDataEntryValue | null): number | null {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < 0 || parsed > 100) return null;
  return Math.round(parsed * 100) / 100;
}
