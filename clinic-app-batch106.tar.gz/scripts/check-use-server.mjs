// ملف فيه "use server" مسموح يصدّر **دوال async بس**. أي تصدير تاني (ثابت،
// كائن، دالة عادية) بيعدّي من `next build` بنجاح، وبعدين بيكسر الصفحة وقت
// التشغيل عند المستخدم برسالة:
//   Error: A "use server" file can only export async functions, found object.
//
// ده حصل فعلاً في دفعة 98 (تصدير EVENT_LABELS من system-log-actions.ts):
// البناء نجح، وكل الفحوصات عدّت، وشاشة التقارير وقعت عند العميل.
// الفحص ده بيمنع تكرارها.
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";

const files = [];
(function walk(dir) {
  for (const name of readdirSync(dir)) {
    if (name === "node_modules" || name === ".next" || name.startsWith(".")) continue;
    const full = join(dir, name);
    if (statSync(full).isDirectory()) walk(full);
    else if (/\.(ts|tsx)$/.test(name)) files.push(full);
  }
})(process.argv[2] ?? "src"); // ممكن نمرّر مسار المجلد عشان نشغّله على نسخة الإصدار قبل النشر

const problems = [];
for (const file of files) {
  const text = readFileSync(file, "utf8");
  if (!/^\s*(["'])use server\1/m.test(text.split("\n").slice(0, 5).join("\n"))) continue;
  text.split("\n").forEach((line, index) => {
    const trimmed = line.trim();
    if (!trimmed.startsWith("export")) return;
    if (/^export\s+(type|interface)\b/.test(trimmed)) return;          // أنواع — بتتشال وقت البناء
    if (/^export\s+async\s+function\b/.test(trimmed)) return;          // المسموح الوحيد
    if (/^export\s*\{[^}]*\}\s*from\s*["']/.test(trimmed)) return;     // re-export
    problems.push(`${file}:${index + 1}  ${trimmed.slice(0, 90)}`);
  });
}

if (problems.length) {
  console.error('❌ ملفات "use server" فيها تصديرات غير مسموحة (دوال async فقط):\n');
  for (const problem of problems) console.error("   " + problem);
  console.error("\nالحل: انقل الثابت أو الدالة لملف مستقل خارج ملف الـactions.");
  process.exit(1);
}
console.log('✅ كل ملفات "use server" بتصدّر دوال async بس');
