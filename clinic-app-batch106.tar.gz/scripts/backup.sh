#!/usr/bin/env bash
# نسخة احتياطية يومية لقاعدة بيانات العيادة + الملفات المرفوعة.
#
# التركيب على السيرفر (مرة واحدة):
#   1) sudo cp scripts/backup.sh /opt/clinic-backup.sh && sudo chmod +x /opt/clinic-backup.sh
#   2) sudo apt install -y sqlite3 rclone
#   3) rclone config          # اختر: n (new) → اسم: gdrive → نوع: drive → اتبع الرابط للتفويض
#      لو السيرفر من غير متصفح، rclone هيديك أمر تشغّله على جهازك وترجّع الناتج.
#   4) اختبار يدوي:  sudo /opt/clinic-backup.sh
#   5) جدولة يومية 2:30 صباحًا بتوقيت مصر (= 23:30 UTC اليوم اللي قبله):
#      sudo crontab -e   ثم أضف السطر:
#      30 23 * * * /opt/clinic-backup.sh >> /var/log/clinic-backup.log 2>&1
#
# مهم: لا تنسخ clinic.db بـ cp أبدًا. قاعدة البيانات شغالة بوضع WAL، ونسخة cp
# وقت وجود كتابة جارية بتطلع ناقصة أو تالفة من غير أي رسالة خطأ. الأمر
# ".backup" تحت بيعمل نسخة متسقة والتطبيق شغال عادي.

set -Eeuo pipefail

DB_PATH="${CLINIC_DB_PATH:-/opt/clinic-app/data/clinic.db}"
UPLOADS_DIR="${CLINIC_UPLOAD_DIR:-/opt/clinic-app/data/uploads}"
LOCAL_DIR="${CLINIC_BACKUP_DIR:-/opt/clinic-backups}"
REMOTE="${CLINIC_BACKUP_REMOTE:-gdrive:clinic-backups}"
KEEP_LOCAL_DAYS="${CLINIC_BACKUP_KEEP_DAYS:-14}"
# الصور والأشعة مشمولة افتراضيًا لأنها جزء من السجل الطبي. يمكن تعطيلها مؤقتًا
# فقط بقرار واعٍ عبر CLINIC_BACKUP_UPLOADS=0، مع بقاء التحذير ظاهرًا في السجل.
BACKUP_UPLOADS="${CLINIC_BACKUP_UPLOADS:-1}"
REQUIRE_REMOTE="${CLINIC_BACKUP_REQUIRE_REMOTE:-1}"
STAMP="$(date -u +%Y%m%d-%H%M%S)"
DB_OUT="$LOCAL_DIR/clinic-$STAMP.db"

fail() { echo "[backup] ERROR: $*" >&2; exit 1; }

command -v sqlite3 >/dev/null 2>&1 || fail "sqlite3 غير مثبت (apt install sqlite3)."
[[ -f "$DB_PATH" ]] || fail "ملف قاعدة البيانات غير موجود: $DB_PATH"
mkdir -p "$LOCAL_DIR"

echo "[backup] $(date -u +%FT%TZ) — بدء النسخ"

# 1) نسخة متسقة من قاعدة البيانات (بتشتغل والتطبيق شغال).
sqlite3 "$DB_PATH" ".backup '$DB_OUT'" || fail "فشل sqlite3 .backup"

# 2) تحقق إن النسخة سليمة فعلاً قبل ما نعتمد عليها — نسخة تالفة أسوأ من نسخة ناقصة
#    لأنها بتديك إحساس زائف بالأمان.
INTEGRITY="$(sqlite3 "$DB_OUT" "PRAGMA integrity_check;" | head -1)"
[[ "$INTEGRITY" == "ok" ]] || fail "النسخة الناتجة تالفة (integrity_check: $INTEGRITY)"

gzip -f "$DB_OUT"
DB_GZ="$DB_OUT.gz"
echo "[backup] قاعدة البيانات: $(du -h "$DB_GZ" | cut -f1) → $DB_GZ"

# 3) رفع خارجي. لو rclone مش متظبط، بنكمّل بالنسخة المحلية وبنحذّر بصوت عالي
#    بدل ما السكريبت يفشل صامت ويسيبك فاكر إن النسخ شغال.
if command -v rclone >/dev/null 2>&1 && rclone listremotes 2>/dev/null | grep -q "^${REMOTE%%:*}:"; then
  rclone copy "$DB_GZ" "$REMOTE/db/" --transfers 2 || fail "فشل رفع قاعدة البيانات إلى $REMOTE"
  echo "[backup] اترفعت لـ $REMOTE/db/"

  # الصور والأشعة: مزامنة تزايدية (اللي اترفع قبل كده مبيتبعتش تاني).
  if [[ "$BACKUP_UPLOADS" == "1" && -d "$UPLOADS_DIR" ]]; then
    # copy is intentional: a local deletion must not delete the last remote
    # copy of a medical file. This is backup retention, not mirroring.
    rclone copy "$UPLOADS_DIR" "$REMOTE/uploads/" --transfers 4 --fast-list \
      || fail "فشل نسخ الملفات الطبية المرفوعة إلى $REMOTE/uploads/"
    echo "[backup] الملفات المرفوعة اتزامنت مع $REMOTE/uploads/"
  else
    echo "[backup] الصور والأشعة مش متضمّنة (CLINIC_BACKUP_UPLOADS=0). قاعدة البيانات بس."
  fi

  # حذف النسخ الأقدم من 30 يومًا من على Drive عشان المساحة ما تمتلئش.
  rclone delete "$REMOTE/db/" --min-age 30d 2>/dev/null || true
else
  if [[ "$REQUIRE_REMOTE" == "1" ]]; then
    fail "rclone مش متظبط (remote: ${REMOTE%%:*}) — النسخة المحلية على نفس السيرفر لا تكفي كنسخة احتياطية. اضبط remote أو استخدم CLINIC_BACKUP_REQUIRE_REMOTE=0 مؤقتًا وبشكل واعٍ."
  fi
  echo "[backup] تحذير: النسخ الخارجي معطل صراحةً؛ النسخة محلية فقط على نفس السيرفر." >&2
fi

# 4) تنظيف النسخ المحلية القديمة.
find "$LOCAL_DIR" -name 'clinic-*.db.gz' -mtime "+$KEEP_LOCAL_DAYS" -delete 2>/dev/null || true

echo "[backup] تم. النسخ المحلية الحالية: $(find "$LOCAL_DIR" -name 'clinic-*.db.gz' | wc -l)"
