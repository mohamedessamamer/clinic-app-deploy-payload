#!/usr/bin/env node
// دفعة 105: استيراد بيانات الزيارات والحركات المالية التاريخية (حتى 8-9)
// من ملف الإكسل المدمج «بيانات الزيارات والحركات المالية حتى 8-9.xlsx».
//
// الاستخدام:
//   node scripts/import-legacy-visits.mjs <path-to-xlsx> --report                (افتراضي: تقرير فقط، بدون كتابة)
//   node scripts/import-legacy-visits.mjs <path-to-xlsx> --apply --sample 50     (عينة صغيرة فعلية)
//   node scripts/import-legacy-visits.mjs <path-to-xlsx> --apply                 (الرفع الكامل)
//
// قواعد ثابتة، متفق عليها مع العيادة قبل الكتابة:
//   - رقم الحجز هو مفتاح منع التكرار للمواعيد، رقم الحركة هو مفتاح منع التكرار
//     للحركة المالية (فاتورة). كلاهما مسجل في import_external_refs، فإعادة
//     تشغيل السكريبت بأمان (idempotent) - أي صف اتسجل قبل كده يتخطى.
//   - كود المريض هو مفتاح الربط الأساسي (يليه الهاتف، ثم الاسم كمطابقة أخيرة).
//   - أي اسم يحتوي "Chat" (بأي شكل: نقط/مسافات) بيتم استبعاده دايمًا.
//   - أي خدمة/طبيب/غرفة ما اتعرفش (مش موجود في السيستم) بيوقّف الصف ده بس
//     ويتسجل في unresolved.json - مايتحطش تخمين ولا يتنشأ تلقائي.
//   - المبالغ (السعر/الخصم/المدفوع) بتتكتب زي ما هي بالظبط - فاتورة واحدة
//     مجمّعة لكل حجز (الإكسل بيديها كإجمالي للزيارة أصلاً، مفيش تفصيل لكل
//     حركة نقدر نقسّم عليه من غير افتراضات) وأرقام الحركات الأصلية بتتسجل في
//     ملاحظة الفاتورة + import_external_refs لكل رقم حركة على حدة (تتبّع
//     وضمان عدم التكرار حتى لو كانت الفاتورة صف واحد).
//   - أقساط التقويم: أول حجز فيه كود خدمة تقويم (101) لمريض هو "الأب" -
//     original_price = مبلغه. أي حجز بعد كده لنفس المريض فيه كود متابعة
//     (0 أو 112) بيتربط بيه عن طريق parent_invoice_id، زي نظام العيادة
//     بالظبط. كل ربط من دول بيتسجل في تقرير linked-installments.json
//     للمراجعة اليدوية.

import fs from "node:fs";
import path from "node:path";
import Database from "better-sqlite3";
import ExcelJS from "exceljs";

// ---------------------------------------------------------------------------
// إعدادات وخرائط ثابتة (اتفقنا عليها في المحادثة)
// ---------------------------------------------------------------------------

const SOURCE = "legacy_excel_0809";

// الأطباء مكتوبين بالعربي في الإكسل، ومسمّين بالإنجليزي في جدول doctors.
// المفتاح: النص العربي بعد إزالة "د." والمسافات الزايدة (lower-trim).
const DOCTOR_NAME_MAP = {
  "محمد عامر": "Mohamed Amer",
  "كريم": "Karim Mohamed",
  "كريم محمد": "Karim Mohamed",
  "محمود جميل": "Mahmoud Jamil",
  "محمد جودة": "Mohamed Gouda",
};

const STATUS_MAP = {
  "مكتمل": "done",
  "ملغي": "cancelled",
  "وصل ولم يُسجل الانتهاء": "attended",
  "لا توجد بيانات حضور": "booked",
};

// أكواد الخدمات اللي تدخل في سلسلة أقساط التقويم (الأب/الأبناء).
const ORTHO_START_CODES = new Set(["101"]);
const ORTHO_FOLLOWUP_CODES = new Set(["0", "112"]);

// ---------------------------------------------------------------------------
// أدوات مساعدة
// ---------------------------------------------------------------------------

function normCode(v) {
  if (v === null || v === undefined) return null;
  const s = String(v).trim();
  if (!s) return null;
  // إزالة الأصفار البادئة فقط للمقارنة - القيمة المخزنة تفضل زي ما هي.
  return s.replace(/^0+(?=\d)/, "");
}

function normName(v) {
  return String(v || "")
    .replace(/[.\s،,]+/g, " ")
    .trim()
    .toLowerCase();
}

function isChatName(name) {
  const n = normName(name);
  return n.includes("chat");
}

function normDoctor(v) {
  return String(v || "")
    .replace(/^د\.?\s*/u, "")
    .trim();
}

function splitList(v) {
  if (v === null || v === undefined) return [];
  return String(v)
    .split(/[،,]/)
    .map((s) => s.trim())
    .filter(Boolean);
}

function toCairoDateStr(d) {
  if (!d) return null;
  const dt = d instanceof Date ? d : new Date(d);
  if (isNaN(dt.getTime())) return null;
  // القيم بالفعل مسجّلة بتوقيت القاهرة في الإكسل (حسب توصيف الملف)؛
  // نأخذ مكوّنات UTC من كائن Date اللي بيرجعه exceljs زي ما هي بدون تحويل مناطق زمنية إضافي.
  const y = dt.getUTCFullYear();
  const m = String(dt.getUTCMonth() + 1).padStart(2, "0");
  const day = String(dt.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function toTimeStr(d) {
  if (!d) return null;
  const dt = d instanceof Date ? d : new Date(d);
  if (isNaN(dt.getTime())) return null;
  const h = String(dt.getUTCHours()).padStart(2, "0");
  const mi = String(dt.getUTCMinutes()).padStart(2, "0");
  return `${h}:${mi}`;
}

function toDateTimeStr(d) {
  if (!d) return null;
  const dt = d instanceof Date ? d : new Date(d);
  if (isNaN(dt.getTime())) return null;
  const date = toCairoDateStr(dt);
  const time = toTimeStr(dt);
  return `${date} ${time}:00`;
}

function num(v) {
  if (v === null || v === undefined || v === "") return null;
  const n = typeof v === "number" ? v : Number(v);
  return isNaN(n) ? null : n;
}

// ---------------------------------------------------------------------------
// CLI args
// ---------------------------------------------------------------------------

const args = process.argv.slice(2);
const xlsxPath = args.find((a) => !a.startsWith("--"));
const APPLY = args.includes("--apply");
const sampleIdx = args.indexOf("--sample");
const SAMPLE = sampleIdx >= 0 ? Number(args[sampleIdx + 1]) : null;
const OUT_DIR = path.join(process.cwd(), "import-report-batch105");

if (!xlsxPath) {
  console.error("الاستخدام: node scripts/import-legacy-visits.mjs <path-to-xlsx> [--apply] [--sample N]");
  process.exit(1);
}
if (!fs.existsSync(xlsxPath)) {
  console.error(`الملف غير موجود: ${xlsxPath}`);
  process.exit(1);
}

fs.mkdirSync(OUT_DIR, { recursive: true });

const DB_PATH = process.env.CLINIC_DB_PATH || path.join(process.cwd(), "data", "clinic.db");
if (!fs.existsSync(DB_PATH)) {
  console.error(`قاعدة البيانات غير موجودة: ${DB_PATH} (اضبط CLINIC_DB_PATH لو لازم)`);
  process.exit(1);
}

console.log(`== وضع التشغيل: ${APPLY ? "كتابة فعلية (--apply)" : "تقرير فقط (dry-run)"}${SAMPLE ? ` - عينة ${SAMPLE} حجز` : ""} ==`);
console.log(`DB: ${DB_PATH}`);
console.log(`Excel: ${xlsxPath}`);

// ---------------------------------------------------------------------------
// تحميل قاعدة البيانات وبناء فهارس المطابقة
// ---------------------------------------------------------------------------

const sqlite = new Database(DB_PATH);
sqlite.pragma("journal_mode = WAL");
sqlite.pragma("foreign_keys = ON");

const hasRefsTable = sqlite
  .prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='import_external_refs'")
  .get();
if (!hasRefsTable) {
  console.error(
    "جدول import_external_refs غير موجود - شغّل السيرفر مرة واحدة الأول عشان الميجريشن 105 تتنفذ (بتتنفذ تلقائي عند تشغيل التطبيق)."
  );
  process.exit(1);
}

const doctorsAll = sqlite.prepare("SELECT id, full_name FROM doctors").all();
const doctorByEnName = new Map(doctorsAll.map((d) => [d.full_name.trim().toLowerCase(), d.id]));

const roomsAll = sqlite.prepare("SELECT id, name FROM rooms").all();
const roomByName = new Map(roomsAll.map((r) => [r.name.trim(), r.id]));

const servicesAll = sqlite.prepare("SELECT id, name, name_en, code FROM services").all();
const serviceByCode = new Map();
for (const s of servicesAll) {
  if (s.code) serviceByCode.set(String(s.code).trim(), s.id);
}

function resolveDoctor(arabicName) {
  const clean = normDoctor(arabicName);
  const en = DOCTOR_NAME_MAP[clean];
  if (!en) return { id: null, reason: `اسم طبيب غير معروف في الخريطة: "${arabicName}"` };
  const id = doctorByEnName.get(en.trim().toLowerCase());
  if (!id) return { id: null, reason: `الطبيب "${en}" غير موجود في جدول doctors` };
  return { id, reason: null };
}

function resolveRoom(roomName) {
  const clean = String(roomName || "").trim();
  if (!clean) return { id: null, reason: "بدون اسم غرفة" };
  const id = roomByName.get(clean);
  if (!id) return { id: null, reason: `الغرفة "${clean}" غير موجودة في جدول rooms` };
  return { id, reason: null };
}

function resolveService(code, nameEn, nameAr) {
  const c = String(code || "").trim();
  if (c && serviceByCode.has(c)) return { id: serviceByCode.get(c), reason: null };
  return { id: null, reason: `كود خدمة غير موجود في services: "${c}" (${nameEn || nameAr || ""})` };
}

// فهرس المرضى الموجودين، مبني مرة واحدة ومحدّث فوريًا مع كل مريض جديد بيتعمل.
const patientsByFileNumber = new Map();
const patientsByPhone = new Map();
for (const p of sqlite.prepare("SELECT id, file_number, phone, full_name FROM patients").all()) {
  const nc = normCode(p.file_number);
  if (nc) patientsByFileNumber.set(nc, p.id);
  if (p.phone) {
    const ph = String(p.phone).trim();
    if (ph) {
      if (!patientsByPhone.has(ph)) patientsByPhone.set(ph, []);
      patientsByPhone.get(ph).push(p.id);
    }
  }
}

const insertPatient = sqlite.prepare(
  `INSERT INTO patients (file_number, full_name, phone_country_code, phone) VALUES (?, ?, '+20', ?)`
);

function resolvePatient({ code, phone, name }) {
  const nc = normCode(code);
  if (nc && patientsByFileNumber.has(nc)) {
    return { id: patientsByFileNumber.get(nc), created: false, matchedBy: "code" };
  }
  const ph = String(phone || "").trim();
  if (ph && patientsByPhone.has(ph) && patientsByPhone.get(ph).length === 1) {
    return { id: patientsByPhone.get(ph)[0], created: false, matchedBy: "phone" };
  }
  // لم يوجد - يتعمل مريض جديد فقط لو عندنا كود مريض صريح من الإكسل.
  if (!code) return { id: null, created: false, matchedBy: null, reason: "بدون كود مريض ولا تطابق هاتف" };
  if (APPLY) {
    const info = insertPatient.run(String(code).trim(), name || "غير معروف", ph || null);
    const id = info.lastInsertRowid;
    patientsByFileNumber.set(nc, id);
    if (ph) {
      if (!patientsByPhone.has(ph)) patientsByPhone.set(ph, []);
      patientsByPhone.get(ph).push(id);
    }
    return { id, created: true, matchedBy: "new" };
  }
  return { id: -1, created: true, matchedBy: "new-dryrun" };
}

// ---------------------------------------------------------------------------
// تسجيل/فحص import_external_refs
// ---------------------------------------------------------------------------

const findRef = sqlite.prepare(
  "SELECT entity_id FROM import_external_refs WHERE source = ? AND external_kind = ? AND external_id = ?"
);
const insertRef = sqlite.prepare(
  "INSERT INTO import_external_refs (source, external_kind, external_id, entity_type, entity_id) VALUES (?, ?, ?, ?, ?)"
);

function alreadyImported(kind, externalId) {
  const row = findRef.get(SOURCE, kind, String(externalId));
  return row ? row.entity_id : null;
}

// ---------------------------------------------------------------------------
// قراءة الإكسل
// ---------------------------------------------------------------------------

const wb = new ExcelJS.Workbook();
await wb.xlsx.readFile(xlsxPath);

const wsVisits = wb.getWorksheet("الزيارات المجمعة");
const wsUnlinked = wb.getWorksheet("حركات بدون حجز");
if (!wsVisits) {
  console.error('شيت "الزيارات المجمعة" غير موجود في الملف.');
  process.exit(1);
}

function rowsOf(ws) {
  const header = ws.getRow(1).values.slice(1); // exceljs 1-indexed, index 0 فاضي
  const out = [];
  ws.eachRow((row, rowNumber) => {
    if (rowNumber === 1) return;
    const values = row.values.slice(1);
    const obj = {};
    header.forEach((h, i) => (obj[h] = values[i] ?? null));
    out.push(obj);
  });
  return out;
}

const visitRows = rowsOf(wsVisits);
const unlinkedRows = wsUnlinked ? rowsOf(wsUnlinked) : [];

console.log(`صفوف "الزيارات المجمعة": ${visitRows.length}`);
console.log(`صفوف "حركات بدون حجز": ${unlinkedRows.length}`);

// ---------------------------------------------------------------------------
// معالجة شيت الزيارات
// ---------------------------------------------------------------------------

const insertAppointment = sqlite.prepare(`
  INSERT INTO appointments
    (patient_id, room_id, doctor_id, appointment_date, start_time, duration_minutes,
     status, attended_at, notes)
  VALUES (@patient_id, @room_id, @doctor_id, @appointment_date, @start_time, @duration_minutes,
     @status, @attended_at, @notes)
`);

const insertVisit = sqlite.prepare(`
  INSERT INTO visits
    (patient_id, visit_date, service_id, primary_doctor_id, performing_doctor_id, room_id, appointment_id, notes)
  VALUES (@patient_id, @visit_date, @service_id, @primary_doctor_id, @performing_doctor_id, @room_id, @appointment_id, @notes)
`);

const insertInvoice = sqlite.prepare(`
  INSERT INTO invoices
    (visit_id, patient_id, doctor_id, appointment_id, service_id, invoice_date,
     amount, paid, discount_percent, payment_method, parent_invoice_id, original_price)
  VALUES (@visit_id, @patient_id, @doctor_id, @appointment_id, @service_id, @invoice_date,
     @amount, @paid, @discount_percent, @payment_method, @parent_invoice_id, @original_price)
`);

const skippedRows = [];
const unresolvedServices = new Map();
const conflicts = [];
const createdPatients = [];
const importedAppointments = [];
const importedInvoices = [];
const duplicatesSkipped = [];

// لسلسلة أقساط التقويم: patientId -> { parentInvoiceId, parentAmount }
const orthoParentByPatient = new Map();
// نحتاج الحجوزات مرتبة بالتاريخ لكل مريض عشان "الأب" يتحدد صح (أقدم حجز فيه كود تقويم).
const rowsSorted = visitRows
  .filter((r) => r["رقم الحجز"] != null)
  .sort((a, b) => new Date(a["تاريخ الزيارة"] || 0) - new Date(b["تاريخ الزيارة"] || 0));

const rowsToProcess = SAMPLE ? rowsSorted.slice(0, SAMPLE) : rowsSorted;

const runOne = sqlite.transaction((row) => {
  const bookingId = String(row["رقم الحجز"]);
  const patientName = row["اسم المريض"];

  if (isChatName(patientName)) {
    skippedRows.push({ bookingId, reason: "مريض Chat مستبعد" });
    return;
  }

  const existingApptId = alreadyImported("appointment", bookingId);
  if (existingApptId) {
    duplicatesSkipped.push({ bookingId, entityId: existingApptId });
    return;
  }

  const status = STATUS_MAP[row["حالة الحجز"]];
  if (!status) {
    skippedRows.push({ bookingId, reason: `حالة حجز غير معروفة: "${row["حالة الحجز"]}"` });
    return;
  }

  const { id: patientId, created, matchedBy, reason: patientReason } = resolvePatient({
    code: row["كود المريض"],
    phone: row["موبايل"],
    name: patientName,
  });
  if (!patientId || patientId === -1) {
    if (patientId !== -1) {
      skippedRows.push({ bookingId, reason: `تعذر تحديد المريض: ${patientReason}` });
      return;
    }
  }
  if (created) createdPatients.push({ bookingId, code: row["كود المريض"], name: patientName, matchedBy });

  const { id: roomId, reason: roomReason } = resolveRoom(row["الغرفة"]);
  if (!roomId && APPLY) {
    skippedRows.push({ bookingId, reason: roomReason });
    return;
  }

  const { id: doctorId, reason: doctorReason } = resolveDoctor(row["الطبيب (الحجز)"]);
  if (!doctorId && APPLY) {
    skippedRows.push({ bookingId, reason: doctorReason });
    return;
  }

  const appointmentDate = toCairoDateStr(row["تاريخ الزيارة"]);
  const startTime = toTimeStr(row["موعد البداية"]);
  if (!appointmentDate || !startTime) {
    skippedRows.push({ bookingId, reason: "تاريخ/وقت الموعد غير صالح" });
    return;
  }

  const durationPlanned = num(row["مدة الزيارة المخطط لها (دقيقة)"]);
  const attendedAt =
    status === "done" || status === "attended" ? toDateTimeStr(row["توقيت الوصول"]) : null;

  const notes = `استيراد بيانات تاريخية (دفعة 105) - رقم الحجز الأصلي: ${bookingId}`;

  if (!APPLY) {
    importedAppointments.push({ bookingId, status, patientId: patientId ?? "(جديد)", dryRun: true });
    return;
  }

  const apptInfo = insertAppointment.run({
    patient_id: patientId,
    room_id: roomId,
    doctor_id: doctorId,
    appointment_date: appointmentDate,
    start_time: startTime,
    duration_minutes: durationPlanned,
    status,
    attended_at: attendedAt,
    notes,
  });
  const appointmentId = apptInfo.lastInsertRowid;
  insertRef.run(SOURCE, "appointment", bookingId, "appointments", appointmentId);
  importedAppointments.push({ bookingId, appointmentId, status });

  // لا فاتورة ولا زيارة للحجوزات الملغاة أو بدون حركة مالية مرتبطة.
  const txnCount = num(row["عدد الحركات المالية"]) || 0;
  if (status === "cancelled" || txnCount <= 0) return;

  const txnNumbers = splitList(row["أرقام الحركات"]);
  const svcCodes = splitList(row["أكواد الخدمات"]);
  const svcNamesEn = splitList(row["الخدمات بالإنجليزي"]);
  const svcNamesAr = splitList(row["الخدمات بالعربي"]);

  // خدمة الزيارة الأساسية = أول كود قابل للحل، للـvisits.service_id (اختياري).
  let visitServiceId = null;
  let anyUnresolvedService = false;
  for (let i = 0; i < svcCodes.length; i++) {
    const { id, reason } = resolveService(svcCodes[i], svcNamesEn[i], svcNamesAr[i]);
    if (id && visitServiceId == null) visitServiceId = id;
    if (!id) {
      anyUnresolvedService = true;
      const key = `${svcCodes[i]}|${svcNamesEn[i] || svcNamesAr[i] || ""}`;
      unresolvedServices.set(key, (unresolvedServices.get(key) || 0) + 1);
    }
  }

  const { id: financeDoctorId } = resolveDoctor(
    String(row["الطبيب (المالية)"] || "").split(/[،,]/)[0]
  );

  const visitInfo = insertVisit.run({
    patient_id: patientId,
    visit_date: appointmentDate,
    service_id: visitServiceId,
    primary_doctor_id: doctorId,
    performing_doctor_id: financeDoctorId || doctorId,
    room_id: roomId,
    appointment_id: appointmentId,
    notes: anyUnresolvedService
      ? `${notes} - تحذير: خدمة/أكثر غير معروفة، راجع unresolved-services.json`
      : notes,
  });
  const visitId = visitInfo.lastInsertRowid;

  const amount = num(row["إجمالي السعر بعد الخصم"]) ?? 0;
  const discountPercent = (() => {
    const total = num(row["إجمالي السعر"]);
    const disc = num(row["إجمالي الخصم"]);
    if (total && disc != null && total > 0) return Math.round((disc / total) * 10000) / 100;
    return 0;
  })();
  const paid = num(row["إجمالي المدفوع"]) ?? 0;
  const paymentMethods = row["طرق الدفع"] ? String(row["طرق الدفع"]) : null;

  // سلسلة أقساط التقويم: هل الحجز ده يحتوي كود بداية تقويم أو متابعة؟
  const hasOrthoStart = svcCodes.some((c) => ORTHO_START_CODES.has(String(c).trim()));
  const hasFollowup = svcCodes.some((c) => ORTHO_FOLLOWUP_CODES.has(String(c).trim()));
  let parentInvoiceId = null;
  let originalPrice = null;
  if (hasOrthoStart) {
    originalPrice = amount;
  } else if (hasFollowup && orthoParentByPatient.has(patientId)) {
    parentInvoiceId = orthoParentByPatient.get(patientId).parentInvoiceId;
  }

  const invInfo = insertInvoice.run({
    visit_id: visitId,
    patient_id: patientId,
    doctor_id: financeDoctorId || doctorId,
    appointment_id: appointmentId,
    service_id: visitServiceId,
    invoice_date: appointmentDate,
    amount,
    paid,
    discount_percent: discountPercent,
    payment_method: paymentMethods,
    parent_invoice_id: parentInvoiceId,
    original_price: originalPrice,
  });
  const invoiceId = invInfo.lastInsertRowid;

  if (hasOrthoStart && !orthoParentByPatient.has(patientId)) {
    orthoParentByPatient.set(patientId, { parentInvoiceId: invoiceId, parentAmount: amount });
  }

  for (const txn of txnNumbers) {
    insertRef.run(SOURCE, "invoice", txn, "invoices", invoiceId);
  }
  importedInvoices.push({
    bookingId,
    invoiceId,
    amount,
    paid,
    txnNumbers,
    parentInvoiceId,
    originalPrice,
  });
});

for (const row of rowsToProcess) {
  try {
    runOne(row);
  } catch (err) {
    skippedRows.push({ bookingId: String(row["رقم الحجز"]), reason: `خطأ: ${err.message}` });
  }
}

// ---------------------------------------------------------------------------
// شيت "حركات بدون حجز" - تقرير مطابقة مرشحة فقط، بدون أي كتابة تلقائية
// ---------------------------------------------------------------------------

const unlinkedCandidates = [];
for (const row of unlinkedRows) {
  const txnNumber = String(row["رقم الحركة"]);
  if (isChatName(row["اسم المريض"])) continue;
  const already = alreadyImported("invoice", txnNumber);
  if (already) continue;

  const nc = normCode(row["كود المريض"]);
  const patientId = nc ? patientsByFileNumber.get(nc) : null;
  const hasPhone = !!String(row["موبايل"] || "").trim();

  unlinkedCandidates.push({
    txnNumber,
    patientCode: row["كود المريض"],
    patientMatched: !!patientId,
    patientId: patientId || null,
    hasPhone,
    canCreateStandaloneInvoice: !!patientId || hasPhone,
    name: row["اسم المريض"],
    amount: num(row["المدفوع"]),
    date: toCairoDateStr(row["تاريخ الحركة"]),
    note: !patientId && !hasPhone ? "لا كود مريض معروف ولا رقم هاتف - لا يُنشأ تلقائيًا" : null,
  });
}

// ---------------------------------------------------------------------------
// تقرير المطابقة النهائي
// ---------------------------------------------------------------------------

const totalPaidImported = importedInvoices.reduce((s, i) => s + (i.paid || 0), 0);

const report = {
  mode: APPLY ? "apply" : "dry-run",
  sample: SAMPLE,
  totals: {
    visitRowsInFile: visitRows.length,
    processedRows: rowsToProcess.length,
    appointmentsImported: importedAppointments.length,
    invoicesImported: importedInvoices.length,
    totalPaidImported,
    duplicatesSkipped: duplicatesSkipped.length,
    rowsSkipped: skippedRows.length,
    newPatientsCreated: createdPatients.filter((p) => p.matchedBy !== "new-dryrun").length,
    newPatientsWouldBeCreated: createdPatients.filter((p) => p.matchedBy === "new-dryrun").length,
    orthoParentChainsBuilt: orthoParentByPatient.size,
  },
  unresolvedServices: Array.from(unresolvedServices.entries()).map(([k, count]) => {
    const [code, label] = k.split("|");
    return { code, label, occurrences: count };
  }),
  skippedRows,
  duplicatesSkipped,
  createdPatients,
  unlinkedTransactionsReport: {
    total: unlinkedRows.length,
    matchedToExistingPatientByCode: unlinkedCandidates.filter((c) => c.patientMatched).length,
    noPhoneNoPatient: unlinkedCandidates.filter((c) => !c.canCreateStandaloneInvoice).length,
    items: unlinkedCandidates,
  },
};

fs.writeFileSync(path.join(OUT_DIR, "report.json"), JSON.stringify(report, null, 2), "utf8");
fs.writeFileSync(
  path.join(OUT_DIR, "unresolved-services.json"),
  JSON.stringify(report.unresolvedServices, null, 2),
  "utf8"
);
fs.writeFileSync(
  path.join(OUT_DIR, "unlinked-transactions.json"),
  JSON.stringify(unlinkedCandidates, null, 2),
  "utf8"
);

console.log("\n== ملخص ==");
console.log(JSON.stringify(report.totals, null, 2));
console.log(`\nتقرير كامل: ${path.join(OUT_DIR, "report.json")}`);
console.log(`خدمات غير معروفة: ${path.join(OUT_DIR, "unresolved-services.json")}`);
console.log(`حركات بدون حجز (للمراجعة اليدوية): ${path.join(OUT_DIR, "unlinked-transactions.json")}`);

if (!APPLY) {
  console.log("\nده تقرير dry-run فقط - لم يتم كتابة أي صف في القاعدة.");
} else {
  console.log(
    `\nتم تنفيذ الكتابة فعليًا${SAMPLE ? ` (عينة ${SAMPLE} حجز فقط)` : ""}. للتراجع: node scripts/rollback-legacy-visits.mjs`
  );
}

sqlite.close();
