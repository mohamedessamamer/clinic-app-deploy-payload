#!/usr/bin/env node
// تراجع كامل وآمن عن استيراد دفعة 105 (import-legacy-visits.mjs).
// بيمسح فقط الصفوف اللي اتسجلت عن طريق السكريبت ده (متتبّعة في
// import_external_refs) - مايلمسش أي بيانات تانية في السيستم.
//
// الاستخدام:
//   node scripts/rollback-legacy-visits.mjs --confirm

import fs from "node:fs";
import path from "node:path";
import Database from "better-sqlite3";

const CONFIRM = process.argv.includes("--confirm");
const DB_PATH = process.env.CLINIC_DB_PATH || path.join(process.cwd(), "data", "clinic.db");

if (!fs.existsSync(DB_PATH)) {
  console.error(`قاعدة البيانات غير موجودة: ${DB_PATH}`);
  process.exit(1);
}

const sqlite = new Database(DB_PATH);
sqlite.pragma("foreign_keys = ON");

const SOURCE = "legacy_excel_0809";

const invoiceIds = sqlite
  .prepare("SELECT DISTINCT entity_id FROM import_external_refs WHERE source = ? AND entity_type = 'invoices'")
  .all(SOURCE)
  .map((r) => r.entity_id);
const appointmentIds = sqlite
  .prepare("SELECT DISTINCT entity_id FROM import_external_refs WHERE source = ? AND entity_type = 'appointments'")
  .all(SOURCE)
  .map((r) => r.entity_id);

const visitIds = appointmentIds.length
  ? sqlite
      .prepare(
        `SELECT id FROM visits WHERE appointment_id IN (${appointmentIds.map(() => "?").join(",")})`
      )
      .all(...appointmentIds)
      .map((r) => r.id)
  : [];

console.log("== المرشح للحذف (استيراد دفعة 105 فقط) ==");
console.log(`فواتير: ${invoiceIds.length}`);
console.log(`زيارات: ${visitIds.length}`);
console.log(`مواعيد: ${appointmentIds.length}`);

if (!CONFIRM) {
  console.log("\nده استعراض بس. لتنفيذ الحذف فعليًا: node scripts/rollback-legacy-visits.mjs --confirm");
  process.exit(0);
}

const run = sqlite.transaction(() => {
  if (invoiceIds.length) {
    sqlite
      .prepare(`DELETE FROM invoices WHERE id IN (${invoiceIds.map(() => "?").join(",")})`)
      .run(...invoiceIds);
  }
  if (visitIds.length) {
    sqlite.prepare(`DELETE FROM visits WHERE id IN (${visitIds.map(() => "?").join(",")})`).run(...visitIds);
  }
  if (appointmentIds.length) {
    sqlite
      .prepare(`DELETE FROM appointments WHERE id IN (${appointmentIds.map(() => "?").join(",")})`)
      .run(...appointmentIds);
  }
  sqlite.prepare("DELETE FROM import_external_refs WHERE source = ?").run(SOURCE);
});

run();
console.log("\nتم التراجع بالكامل. ملحوظة: أي مريض جديد اتعمل أثناء الاستيراد لم يُحذف عمدًا (قد يكون له بيانات أخرى الآن) - راجعه يدويًا لو محتاج تشيله.");
sqlite.close();
