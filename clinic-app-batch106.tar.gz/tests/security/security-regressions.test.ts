import test from "node:test";
import assert from "node:assert/strict";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { ByteLimitTransform, UploadTooLargeError, assertContentLengthWithinLimit } from "../../src/lib/limited-upload.ts";
import { parseMoney, parsePercent } from "../../src/lib/money.ts";
import { safeInternalRedirect } from "../../src/lib/safe-redirect.ts";

test("redirects remain on the clinic origin", () => {
  assert.equal(safeInternalRedirect("/patients?x=1"), "/patients?x=1");
  assert.equal(safeInternalRedirect("//evil.example"), "/");
  assert.equal(safeInternalRedirect("/\\evil.example"), "/");
  assert.equal(safeInternalRedirect("https://evil.example"), "/");
});

test("money validation rejects negative and non-finite values", () => {
  assert.equal(parseMoney("12.345"), 12.35);
  assert.equal(parseMoney("-1"), null);
  assert.equal(parseMoney("Infinity"), null);
  assert.equal(parseMoney("not-a-number"), null);
  assert.equal(parsePercent("101"), null);
});

test("content-length and streaming limits reject oversized uploads", async () => {
  assert.throws(() => assertContentLengthWithinLimit("11", 10), UploadTooLargeError);
  await assert.rejects(
    pipeline(Readable.from([Buffer.alloc(6), Buffer.alloc(6)]), new ByteLimitTransform(10)),
    UploadTooLargeError,
  );
});
