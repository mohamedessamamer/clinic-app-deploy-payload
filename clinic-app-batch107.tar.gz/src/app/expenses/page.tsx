import Link from "next/link";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getClinicToday } from "@/lib/clinic-date";
import { EXPENSE_CATEGORIES, EXPENSE_CATEGORY_LABELS, ensureRecurringExpensesForMonth, getExpenseSummary, monthBounds } from "@/lib/expenses";
import { calculateHrPayroll, getCollectedAfterLab } from "@/lib/hr-payroll";
import { PAYMENT_METHODS, paymentMethodLabel } from "@/lib/payment-methods";
import {
  addExpenseAction, addExpenseTemplateAction, deleteExpenseTemplateAction, stopExpenseTemplateAction, updateExpenseTemplateAction,
  addSupplierInvoiceAction, recordSupplierInvoicePaymentAction, editSupplierInvoiceAction, deleteSupplierInvoiceAction, editSupplierPaymentAction, deleteSupplierPaymentAction,
} from "./actions";
import DeleteExpenseButton from "@/components/DeleteExpenseButton";
import HrPayrollTable from "@/components/HrPayrollTable";
import ClearExpensesDataButton from "@/components/ClearExpensesDataButton";

const inputClass = "w-full rounded border border-border bg-background px-2 py-1.5 text-sm";
function validDate(value?: string) { return !!value && /^\d{4}-\d{2}-\d{2}$/.test(value); }
function previousMonth(month: string) {
  const [year, monthNumber] = month.split("-").map(Number);
  const date = new Date(Date.UTC(year, monthNumber - 2, 1));
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;
}

// رسايل الفشل اللي كانت صامتة — بتوصل في ?err= من expenseError في actions.ts.
const EXPENSE_ERRORS: Record<string, string> = {
  category: "اختار بند مصروف صحيح (بند المرتبات بيتسجل من شاشة HR).",
  title: "لازم تكتب اسم/بيان المصروف.",
  amount: "المبلغ لازم يكون رقم أكبر من صفر.",
  date: "التاريخ غير صحيح.",
  daterange: "تاريخ النهاية لازم يكون بعد تاريخ البداية.",
  service: "الخدمة المختارة مش موجودة.",
  labdouble: "الخدمة دي تكلفة معملها بتتخصم تلقائيًا — تسجيلها هنا كمان هيخصمها مرتين.",
  template: "البند المتكرر ده مش موجود.",
  already: "البند ده متسجل بالفعل للفترة دي.",
  person: "اختار الشخص الأول.",
  norule: "مفيش قاعدة راتب معرّفة للشخص ده — عرّفها من شاشة HR أول.",
  alreadypaid: "الكشف ده مدفوع بالفعل ومينفعش يتعدل.",
  run: "الكشف ده مش موجود.",
  zerorun: "الكشف قيمته صفر — راجع قاعدة الراتب أو الفترة قبل الصرف.",
  supplier: "المورد أو الفاتورة غير صحيحة.",
  specialty: "لازم تحدد تخصص الفاتورة (تقويم أو جينيرال) لأن المورد ده شغال في الاتنين.",
};

export default async function ExpensesPage({ searchParams }: { searchParams: Promise<{ month?: string; from?: string; to?: string; err?: string; specialty?: string }> }) {
  const session = await getSession();
  const canManage = session ? await hasPermission(session.userId, session.role, "manage_expenses") : false;
  if (!session || !canManage) return <div className="card-3d rounded-xl p-5 text-sm text-muted">مفيش صلاحية عندك لعرض المصروفات.</div>;
  const canClearData = await hasPermission(session.userId, session.role, "clear_expenses_data");
  const canManageSuppliers = await hasPermission(session.userId, session.role, "manage_suppliers");

  const params = await searchParams;
  const errorMessage = params.err ? EXPENSE_ERRORS[params.err] || "البيانات غير مكتملة أو غير صحيحة." : null;
  const today = getClinicToday();
  const currentMonth = today.slice(0, 7);
  const selectedMonth = monthBounds(params.month ?? "") ? params.month! : null;
  const customFrom = validDate(params.from) ? params.from! : null;
  const customTo = validDate(params.to) ? params.to! : null;
  const monthlyRange = monthBounds(selectedMonth ?? currentMonth)!;
  const from = customFrom && customTo && customFrom <= customTo ? customFrom : monthlyRange.from;
  const to = customFrom && customTo && customFrom <= customTo ? customTo : monthlyRange.to;
  const fullMonth = !customFrom && !customTo;
  const activeMonth = fullMonth ? (selectedMonth ?? currentMonth) : null;
  if (activeMonth) await ensureRecurringExpensesForMonth(activeMonth, session.userId);
  const currentMonthRange = monthBounds(currentMonth)!;
  const previousMonthRange = monthBounds(previousMonth(currentMonth))!;

  const [expenses, templates, summary, doctors, staff, patients, services, rules, runs, suppliers, allInvoices, allPayments] = await Promise.all([
    db.selectFrom("expenses").selectAll().where("expense_date", ">=", from).where("expense_date", "<=", to).orderBy("expense_date", "desc").orderBy("id", "desc").execute(),
    db.selectFrom("expense_templates").selectAll().orderBy("active", "desc").orderBy("category").orderBy("title").execute(),
    getExpenseSummary(from, to),
    db.selectFrom("doctors").select(["id", "full_name", "active"]).orderBy("full_name").execute(),
    db.selectFrom("hr_staff").select(["id", "full_name", "active"]).orderBy("full_name").execute(),
    db.selectFrom("patients").select(["id", "full_name", "file_number"]).orderBy("full_name").execute(),
    db.selectFrom("services").select(["id", "name", "code", "has_lab_cost", "lab_cost"]).orderBy("name").execute(),
    db.selectFrom("hr_compensation_rules").selectAll().where("active", "=", 1).where("effective_from", "<=", to).where((eb) => eb.or([eb("effective_to", "is", null), eb("effective_to", ">=", from)])).execute(),
    db.selectFrom("hr_payroll_runs").selectAll().where("period_from", "=", from).where("period_to", "=", to).execute(),
    db.selectFrom("inventory_suppliers").select(["id", "name", "is_ortho", "is_general"]).where("active", "=", 1).orderBy("name").execute(),
    db.selectFrom("supplier_invoices").selectAll().orderBy("invoice_date", "desc").orderBy("id", "desc").execute(),
    db.selectFrom("supplier_payments").selectAll().execute(),
  ]);

  // خامات: المديونية (المتبقي) قيمة تراكمية دايمًا — بتُحسب من كل الفواتير
  // وكل الدفعات بغض النظر عن from/to (توضيح صاحب العيادة: "المديونية الكاملة
  // للمورد ده مجموع المتبقي علينا ليه"). الفلترة بالفترة بتتحكم بس في عرض
  // الفواتير المسجّلة داخلها؛ فلتر التخصص مستقل تمامًا وخاص بهذا القسم فقط.
  const paymentsByInvoice = new Map<number, number>();
  const legacyGeneralPaymentsBySupplier = new Map<number, number>();
  for (const payment of allPayments) {
    if (payment.invoice_id != null) {
      paymentsByInvoice.set(payment.invoice_id, Math.round(((paymentsByInvoice.get(payment.invoice_id) ?? 0) + payment.amount) * 100) / 100);
    } else {
      // دفعات قديمة من قبل دفعة 107 بدون فاتورة (مفهوم "الدفعة العامة" اللي
      // اتلغى) — تفضل محسوبة في مديونية المورد لكن مش معروضة على أي فاتورة.
      legacyGeneralPaymentsBySupplier.set(payment.supplier_id, Math.round(((legacyGeneralPaymentsBySupplier.get(payment.supplier_id) ?? 0) + payment.amount) * 100) / 100);
    }
  }
  const invoiceRemaining = new Map<number, number>();
  for (const invoice of allInvoices) invoiceRemaining.set(invoice.id, Math.round((invoice.amount - (paymentsByInvoice.get(invoice.id) ?? 0)) * 100) / 100);
  const invoicesBySupplier = new Map<number, typeof allInvoices>();
  for (const invoice of allInvoices) invoicesBySupplier.set(invoice.supplier_id, [...(invoicesBySupplier.get(invoice.supplier_id) ?? []), invoice]);
  const debtBySupplier = new Map<number, number>();
  for (const supplier of suppliers) {
    const invoiceDebt = (invoicesBySupplier.get(supplier.id) ?? []).reduce((sum, invoice) => sum + (invoiceRemaining.get(invoice.id) ?? 0), 0);
    debtBySupplier.set(supplier.id, Math.round((invoiceDebt - (legacyGeneralPaymentsBySupplier.get(supplier.id) ?? 0)) * 100) / 100);
  }
  const totalSuppliersDebt = Math.round([...debtBySupplier.values()].reduce((sum, debt) => sum + debt, 0) * 100) / 100;
  const specialtyFilter = ["ortho", "general"].includes(params.specialty ?? "") ? (params.specialty as "ortho" | "general") : "all";
  function invoiceSpecialty(invoice: (typeof allInvoices)[number], supplier: { is_ortho: number; is_general: number }): "ortho" | "general" | null {
    if (invoice.specialty === "ortho" || invoice.specialty === "general") return invoice.specialty;
    if (supplier.is_ortho === 1 && supplier.is_general !== 1) return "ortho";
    if (supplier.is_general === 1 && supplier.is_ortho !== 1) return "general";
    return null;
  }
  // استحقاقات الأطباء/الموظفين المعروضة تقتصر على النشط منهم فقط. مين بقى غير
  // نشط (تم إيقافه من الإعدادات أو من HR) يختفي من هذا الجدول، حتى لو كانت
  // قاعدته لسه active=1 من فترة عمله؛ مصروفاته المصروفة فعليًا محفوظة في
  // سجل expenses بشكل منفصل ومش بتتأثر بده.
  const doctorNames = new Map(doctors.filter((person) => person.active === 1).map((person) => [person.id, person.full_name]));
  const staffNames = new Map(staff.filter((person) => person.active === 1).map((person) => [person.id, person.full_name]));
  const runMap = new Map(runs.map((run) => [`${run.person_type}-${run.person_id}`, run]));
  let clinicCollection: Awaited<ReturnType<typeof getCollectedAfterLab>> | null = null;
  const payrollRows = await Promise.all(rules.map(async (rule) => {
    const key = `${rule.person_type}-${rule.person_id}`;
    const name = rule.person_type === "doctor" ? doctorNames.get(rule.person_id) : staffNames.get(rule.person_id);
    if (!name) return null;
    const run = runMap.get(key);
    let collection;
    if (rule.percentage_basis === "personal" && rule.person_type === "doctor") collection = await getCollectedAfterLab(from, to, rule.person_id);
    else { clinicCollection ??= await getCollectedAfterLab(from, to, null); collection = clinicCollection; }
    const preview = calculateHrPayroll(rule, collection.netCollected, run?.shift_count ?? 0);
    return { key, name, rule, run, collection, preview, personType: rule.person_type, personId: rule.person_id, group: rule.staff_group, gross: collection.grossCollected, lab: collection.labCost, net: collection.netCollected };
  }));
  const visiblePayrollRows = payrollRows.filter((row): row is NonNullable<typeof row> => !!row);
  const payrollTotal = visiblePayrollRows.reduce((sum, row) => sum + (row.run?.total_amount ?? row.preview.totalAmount), 0);

  return <div className="space-y-6">{errorMessage && <p className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{errorMessage}</p>}
    <style>{`select[name="category"] option[value="salary"]{display:none}`}</style>
    <div className="flex items-start justify-between gap-4 flex-wrap"><div><h1 className="text-2xl font-bold">المصروفات والرواتب</h1><p className="mt-1 text-sm text-muted">من {from} إلى {to}. البنود المتكررة غير الخاصة بالرواتب تُضاف تلقائيًا عند فتح الشهر.</p></div><div className="flex flex-wrap gap-2"><Link href={`/expenses?month=${currentMonth}`} className="rounded-md btn-3d-primary px-3 py-2 text-sm">الشهر الحالي</Link><Link href={`/expenses?month=${previousMonth(currentMonth)}`} className="rounded-md border border-border px-3 py-2 text-sm hover:bg-primary-soft">الشهر الماضي</Link>{canClearData && <ClearExpensesDataButton currentRange={{ from, to }} currentMonthRange={currentMonthRange} previousMonthRange={previousMonthRange} />}</div></div>

    <form className="card-3d rounded-xl p-4 flex flex-wrap items-end gap-3"><label><span className="block text-xs text-muted mb-1">من</span><input name="from" type="date" defaultValue={from} className="rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">إلى</span><input name="to" type="date" defaultValue={to} className="rounded border border-border bg-background px-2 py-2 text-sm" /></label><button className="rounded-md border border-primary px-4 py-2 text-sm text-primary hover:bg-primary-soft">عرض الفترة</button></form>

    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-4"><div className="card-3d rounded-xl p-4"><div className="text-xs text-muted">المصروفات المسجلة</div><div className="text-2xl font-bold text-danger">{summary.total.toFixed(0)} ج.م</div></div><div className="card-3d rounded-xl p-4"><div className="text-xs text-muted">استحقاقات العاملين</div><div className="text-2xl font-bold">{payrollTotal.toFixed(0)} ج.م</div></div><div className="card-3d rounded-xl p-4"><div className="text-xs text-muted">موردين</div><div className="text-2xl font-bold">{(summary.byCategory.get("suppliers") ?? 0).toFixed(0)} ج.م</div></div><div className="card-3d rounded-xl p-4"><div className="text-xs text-muted">معامل</div><div className="text-2xl font-bold">{(summary.byCategory.get("lab") ?? 0).toFixed(0)} ج.م</div></div><div className="card-3d rounded-xl p-4"><div className="text-xs text-muted">أخرى</div><div className="text-2xl font-bold">{(summary.byCategory.get("other") ?? 0).toFixed(0)} ج.م</div></div><div className="card-3d rounded-xl p-4"><div className="text-xs text-muted">مديونية</div><div className="text-2xl font-bold text-danger">{totalSuppliersDebt.toFixed(0)} ج.م</div></div></div>

    <HrPayrollTable rows={visiblePayrollRows.map(({ key, name, rule, run, gross, lab, net, personType, personId, group }) => ({ key, name, rule, run: run ? { id: run.id, shift_count: run.shift_count, fixed_amount: run.fixed_amount, percentage_amount: run.percentage_amount, incentives: run.incentives, deductions: run.deductions, total_amount: run.total_amount, status: run.status, paid_date: run.paid_date } : null, gross, lab, net, personType, personId, group }))} from={from} to={to} today={today} />

    <section className="card-3d rounded-xl p-5 space-y-4"><div><h2 className="font-semibold">مصروف معمل يدوي</h2><p className="mt-1 text-xs text-muted">استخدمه فقط عندما لا تكون تكلفة المعمل معرّفة داخل الخدمة. ربطه بالطبيب يجعله يُخصم من تحصيله قبل حساب النسبة.</p></div><form action={addExpenseAction} className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 items-end"><input type="hidden" name="category" value="lab" /><label><span className="block text-xs text-muted mb-1">التاريخ</span><input name="expense_date" type="date" required defaultValue={today} className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">الطبيب *</span><select name="doctor_id" required className="w-full rounded border border-border bg-background px-2 py-2 text-sm"><option value="">اختر الطبيب</option>{doctors.filter((doctor) => doctor.active === 1).map((doctor) => <option key={doctor.id} value={doctor.id}>{doctor.full_name}</option>)}</select></label><label><span className="block text-xs text-muted mb-1">المريض (اختياري)</span><select name="patient_id" className="w-full rounded border border-border bg-background px-2 py-2 text-sm"><option value="">غير محدد</option>{patients.map((patient) => <option key={patient.id} value={patient.id}>{patient.full_name} — {patient.file_number}</option>)}</select></label><label><span className="block text-xs text-muted mb-1">الخدمة (اختياري)</span><select name="service_id" className="w-full rounded border border-border bg-background px-2 py-2 text-sm"><option value="">غير معرفة</option>{services.map((service) => <option key={service.id} value={service.id}>{service.name}{service.has_lab_cost ? ` — معرفة ${service.lab_cost} ج.م` : ""}</option>)}</select></label><label><span className="block text-xs text-muted mb-1">البيان *</span><input name="title" required placeholder="مثال: معمل كراون زيركون" className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">التكلفة *</span><input name="amount" type="number" min="0.01" step="0.01" required className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">المعمل</span><input name="payee" placeholder="اسم المعمل" className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">ملاحظة</span><input name="note" className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><button className="rounded-md btn-3d-primary px-4 py-2 text-sm">حفظ تكلفة المعمل</button></form></section>

    <section className="card-3d rounded-xl p-5 space-y-4"><div><h2 className="font-semibold">البنود المتكررة</h2><p className="mt-1 text-xs text-muted">الإيجار والمصاريف الثابتة تُضاف تلقائيًا أول الشهر. مرتبات الأشخاص تُدار من HR لمنع التكرار.</p></div><form action={addExpenseTemplateAction} className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-3 items-end"><label><span className="block text-xs text-muted mb-1">البند</span><input name="title" required className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">التصنيف</span><select name="category" defaultValue="fixed" className="w-full rounded border border-border bg-background px-2 py-2 text-sm">{["fixed", "other"].map((category) => <option key={category} value={category}>{EXPENSE_CATEGORY_LABELS[category as keyof typeof EXPENSE_CATEGORY_LABELS]}</option>)}</select></label><label><span className="block text-xs text-muted mb-1">القيمة</span><input name="default_amount" type="number" min="0.01" step="0.01" required className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">المدفوع له</span><input name="payee" className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">تسري من</span><input name="effective_from" type="date" required defaultValue={today} className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><button className="rounded border border-primary px-4 py-2 text-sm text-primary">إضافة بند متكرر</button></form><div className="space-y-2">{templates.map((template) => <details key={template.id} className="rounded-lg border border-border p-3" open={false}><summary className="cursor-pointer text-sm"><b>{template.title}</b> — {template.default_amount.toFixed(0)} ج.م <span className={template.active ? "text-primary" : "text-muted"}>({template.active ? "نشط" : "متوقف"})</span></summary><form action={updateExpenseTemplateAction} className="mt-3 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-6 gap-2 items-end"><input type="hidden" name="template_id" value={template.id} /><input name="title" defaultValue={template.title} required className="rounded border border-border bg-background px-2 py-1.5 text-sm" /><select name="category" defaultValue={template.category} className="rounded border border-border bg-background px-2 py-1.5 text-sm">{["fixed", "other", "salary"].map((category) => <option key={category} value={category}>{EXPENSE_CATEGORY_LABELS[category as keyof typeof EXPENSE_CATEGORY_LABELS]}</option>)}</select><input name="default_amount" type="number" min="0.01" step="0.01" defaultValue={template.default_amount} required className="rounded border border-border bg-background px-2 py-1.5 text-sm" /><input name="payee" defaultValue={template.payee ?? ""} placeholder="المدفوع له" className="rounded border border-border bg-background px-2 py-1.5 text-sm" /><input name="effective_from" type="date" required defaultValue={template.effective_from ?? today} className="rounded border border-border bg-background px-2 py-1.5 text-sm" /><input name="effective_to" type="date" defaultValue={template.effective_to ?? ""} className="rounded border border-border bg-background px-2 py-1.5 text-sm" /><button className="rounded border border-border px-3 py-1.5 text-sm">حفظ التعديل</button></form><div className="mt-2 flex gap-3">{template.active === 1 && <form action={stopExpenseTemplateAction}><input type="hidden" name="template_id" value={template.id} /><button className="text-xs text-amber-700 hover:underline">إيقاف من الآن</button></form>}<form action={deleteExpenseTemplateAction}><input type="hidden" name="template_id" value={template.id} /><button className="text-xs text-danger hover:underline">حذف{template.active ? " / إيقاف مع حفظ القديم" : ""}</button></form></div></details>)}{templates.length === 0 && <p className="text-sm text-muted">لا توجد بنود متكررة.</p>}</div></section>

    <section className="card-3d rounded-xl p-5 space-y-4">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div><h2 className="font-semibold">خامات</h2><p className="mt-1 text-xs text-muted">فاتورة توريد لكل صف؛ المورد نفسه يُعرَّف من شاشة المخزن. المتبقي والمديونية قيم تراكمية (كل الفواتير والدفعات)، بينما عمود التاريخ هنا مقيّد بالفترة المختارة فوق.</p></div>
        <form className="flex items-end gap-2"><input type="hidden" name="from" value={from} /><input type="hidden" name="to" value={to} /><label><span className="block text-xs text-muted mb-1">التخصص</span><select name="specialty" defaultValue={specialtyFilter} className="rounded border border-border bg-background px-2 py-2 text-sm"><option value="all">الكل</option><option value="ortho">تقويم</option><option value="general">جينيرال</option></select></label><button className="rounded-md border border-border px-3 py-2 text-sm hover:bg-primary-soft">تصفية</button></form>
      </div>

      {suppliers.length === 0 && <p className="text-sm text-muted">لا يوجد موردون بعد — عرّف موردًا من شاشة المخزن أولًا.</p>}

      <details className="rounded-lg border border-border p-3">
        <summary className="cursor-pointer text-sm font-medium">إضافة فاتورة جديدة</summary>
        <form action={addSupplierInvoiceAction} className="mt-3 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-6 gap-2 items-end">
          <label><span className="block text-xs text-muted mb-1">المورد *</span><select name="supplier_id" required className={inputClass}><option value="">اختر المورد</option>{suppliers.map((supplier) => <option key={supplier.id} value={supplier.id}>{supplier.name}</option>)}</select></label>
          <label><span className="block text-xs text-muted mb-1">التخصص (لو مورد عام)</span><select name="specialty" className={inputClass}><option value="">—</option><option value="ortho">تقويم</option><option value="general">جينيرال</option></select></label>
          <label><span className="block text-xs text-muted mb-1">رقم الفاتورة</span><input name="invoice_number" className={inputClass} /></label>
          <label><span className="block text-xs text-muted mb-1">قيمة الفاتورة *</span><input name="amount" type="number" min="0.01" step="0.01" required className={inputClass} /></label>
          <label><span className="block text-xs text-muted mb-1">المدفوع الآن (اختياري)</span><input name="paid_amount" type="number" min="0" step="0.01" className={inputClass} /></label>
          <label><span className="block text-xs text-muted mb-1">التاريخ</span><input name="invoice_date" type="date" defaultValue={today} className={inputClass} /></label>
          <button className="rounded-md btn-3d-primary px-3 py-1.5 text-sm font-medium">حفظ الفاتورة</button>
        </form>
      </details>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-primary-soft text-primary-dark">
            <tr>
              <th className="px-3 py-2 text-right">المورد</th>
              <th className="px-3 py-2 text-right">التخصص</th>
              <th className="px-3 py-2 text-right">رقم الفاتورة</th>
              <th className="px-3 py-2 text-right">قيمة الفاتورة</th>
              <th className="px-3 py-2 text-right">المتبقي</th>
              <th className="px-3 py-2 text-right">مديونية المورد</th>
              <th className="px-3 py-2 text-right">تسجيل دفعة</th>
              {canManageSuppliers && <th className="px-3 py-2 text-right">إدارة</th>}
            </tr>
          </thead>
          <tbody>
            {suppliers.flatMap((supplier) => {
              const bothSpecialties = supplier.is_ortho === 1 && supplier.is_general === 1;
              const supplierInvoices = (invoicesBySupplier.get(supplier.id) ?? [])
                .filter((invoice) => invoice.invoice_date >= from && invoice.invoice_date <= to)
                .filter((invoice) => {
                  if (specialtyFilter === "all") return true;
                  return invoiceSpecialty(invoice, supplier) === specialtyFilter;
                });
              if (supplierInvoices.length === 0) return [];
              const debt = debtBySupplier.get(supplier.id) ?? 0;
              return supplierInvoices.map((invoice, index) => {
                const remaining = invoiceRemaining.get(invoice.id) ?? 0;
                const specialtyLabel = bothSpecialties
                  ? (invoice.specialty === "ortho" ? "تقويم" : invoice.specialty === "general" ? "جينيرال" : "-")
                  : (invoiceSpecialty(invoice, supplier) === "ortho" ? "تقويم" : invoiceSpecialty(invoice, supplier) === "general" ? "جينيرال" : "-");
                return <tr key={invoice.id} className="border-t border-border align-top">
                  <td className="px-3 py-2 font-medium whitespace-nowrap">{supplier.name}</td>
                  <td className="px-3 py-2 whitespace-nowrap">{specialtyLabel}</td>
                  <td className="px-3 py-2">{invoice.invoice_number ?? "-"}</td>
                  <td className="px-3 py-2 whitespace-nowrap">{invoice.amount.toFixed(0)} ج.م</td>
                  <td className={`px-3 py-2 whitespace-nowrap ${remaining > 0 ? "text-danger" : "text-primary"}`}>{remaining.toFixed(0)} ج.م</td>
                  <td className={`px-3 py-2 whitespace-nowrap ${debt > 0 ? "text-danger" : "text-primary"}`}>{index === 0 ? `${debt.toFixed(0)} ج.م` : ""}</td>
                  <td className="px-3 py-2">
                    <form action={recordSupplierInvoicePaymentAction} className="flex flex-wrap gap-1 items-end">
                      <input type="hidden" name="supplier_id" value={supplier.id} />
                      <input type="hidden" name="invoice_id" value={invoice.id} />
                      <input name="amount" type="number" min="0.01" step="0.01" required placeholder="المبلغ" className="w-24 rounded border border-border bg-background px-2 py-1 text-xs" />
                      <input name="payment_date" type="date" defaultValue={today} className="rounded border border-border bg-background px-2 py-1 text-xs" />
                      <button className="rounded border border-border px-2 py-1 text-xs hover:bg-primary-soft">تسجيل دفعة</button>
                    </form>
                  </td>
                  {canManageSuppliers && <td className="px-3 py-2">
                    <details><summary className="cursor-pointer text-xs text-primary">تعديل</summary>
                      <form action={editSupplierInvoiceAction} className="mt-2 flex flex-col gap-1 min-w-[9rem]">
                        <input type="hidden" name="invoice_id" value={invoice.id} />
                        <input name="invoice_number" defaultValue={invoice.invoice_number ?? ""} placeholder="رقم الفاتورة" className="rounded border border-border bg-background px-2 py-1 text-xs" />
                        <input name="amount" type="number" min="0.01" step="0.01" defaultValue={invoice.amount} required className="rounded border border-border bg-background px-2 py-1 text-xs" />
                        <input name="invoice_date" type="date" defaultValue={invoice.invoice_date} required className="rounded border border-border bg-background px-2 py-1 text-xs" />
                        {bothSpecialties && <select name="specialty" defaultValue={invoice.specialty ?? ""} className="rounded border border-border bg-background px-2 py-1 text-xs"><option value="">—</option><option value="ortho">تقويم</option><option value="general">جينيرال</option></select>}
                        <button className="rounded border border-border px-2 py-1 text-xs hover:bg-primary-soft">حفظ</button>
                      </form>
                    </details>
                    <form action={deleteSupplierInvoiceAction} className="mt-1"><input type="hidden" name="invoice_id" value={invoice.id} /><button className="text-xs text-danger hover:underline">حذف الفاتورة</button></form>
                  </td>}
                </tr>;
              });
            })}
            {suppliers.every((supplier) => (invoicesBySupplier.get(supplier.id) ?? []).filter((invoice) => invoice.invoice_date >= from && invoice.invoice_date <= to && (specialtyFilter === "all" || invoiceSpecialty(invoice, supplier) === specialtyFilter)).length === 0) && (
              <tr><td colSpan={canManageSuppliers ? 8 : 7} className="px-3 py-7 text-center text-muted">لا توجد فواتير في هذه الفترة/التصفية.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {allPayments.some((payment) => payment.invoice_id == null) && canManageSuppliers && (
        <details className="rounded-lg border border-border p-3">
          <summary className="cursor-pointer text-xs text-muted">دفعات قديمة بدون فاتورة محددة (من قبل تحديث خامات) — محسوبة في المديونية فقط</summary>
          <div className="mt-2 space-y-1">
            {allPayments.filter((payment) => payment.invoice_id == null).map((payment) => {
              const supplierName = suppliers.find((s) => s.id === payment.supplier_id)?.name ?? `مورد #${payment.supplier_id}`;
              return <div key={payment.id} className="flex flex-wrap items-center gap-2 text-xs">
                <span>{supplierName} — {payment.amount.toFixed(0)} ج.م بتاريخ {payment.payment_date}</span>
                <details><summary className="cursor-pointer text-primary">تعديل</summary>
                  <form action={editSupplierPaymentAction} className="mt-1 flex gap-1 items-end">
                    <input type="hidden" name="payment_id" value={payment.id} />
                    <input name="amount" type="number" min="0.01" step="0.01" defaultValue={payment.amount} required className="w-24 rounded border border-border bg-background px-2 py-1 text-xs" />
                    <input name="payment_date" type="date" defaultValue={payment.payment_date} required className="rounded border border-border bg-background px-2 py-1 text-xs" />
                    <button className="rounded border border-border px-2 py-1 text-xs hover:bg-primary-soft">حفظ</button>
                  </form>
                </details>
                <form action={deleteSupplierPaymentAction}><input type="hidden" name="payment_id" value={payment.id} /><button className="text-danger hover:underline">حذف</button></form>
              </div>;
            })}
          </div>
        </details>
      )}
    </section>

    <section className="card-3d rounded-xl p-5 space-y-3"><h2 className="font-semibold">تسجيل مصروف آخر</h2><form action={addExpenseAction} className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 items-end"><label><span className="block text-xs text-muted mb-1">التاريخ</span><input name="expense_date" type="date" required defaultValue={today} className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">التصنيف</span><select name="category" defaultValue="petty" className="w-full rounded border border-border bg-background px-2 py-2 text-sm">{EXPENSE_CATEGORIES.filter((category) => category !== "lab" && category !== "suppliers").map((category) => <option key={category} value={category}>{EXPENSE_CATEGORY_LABELS[category]}</option>)}</select></label><label><span className="block text-xs text-muted mb-1">البند</span><input name="title" required className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">المبلغ</span><input name="amount" type="number" min="0.01" step="0.01" required className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">المدفوع له</span><input name="payee" className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><label><span className="block text-xs text-muted mb-1">وسيلة الدفع</span><select name="payment_method" defaultValue="cash" className="w-full rounded border border-border bg-background px-2 py-2 text-sm">{PAYMENT_METHODS.map((method) => <option key={method.value} value={method.value}>{method.label}</option>)}</select></label><label className="sm:col-span-2"><span className="block text-xs text-muted mb-1">ملاحظة</span><input name="note" className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label><button className="rounded-md btn-3d-primary px-4 py-2 text-sm">حفظ المصروف</button></form></section>

    <section className="card-3d rounded-xl overflow-hidden"><div className="px-4 py-3 font-semibold">مصروفات الفترة</div><div className="overflow-x-auto"><table className="w-full text-sm"><thead className="bg-primary-soft text-primary-dark"><tr><th className="px-3 py-2 text-right">التاريخ</th><th className="px-3 py-2 text-right">التصنيف</th><th className="px-3 py-2 text-right">البند</th><th className="px-3 py-2 text-right">المدفوع له</th><th className="px-3 py-2 text-right">المبلغ</th><th className="px-3 py-2 text-right">الدفع</th><th className="px-3 py-2 text-right">ملاحظة</th><th /></tr></thead><tbody>{expenses.map((expense) => <tr key={expense.id} className="border-t border-border"><td className="px-3 py-2 whitespace-nowrap">{expense.expense_date}</td><td className="px-3 py-2">{EXPENSE_CATEGORY_LABELS[expense.category as keyof typeof EXPENSE_CATEGORY_LABELS] ?? expense.category}</td><td className="px-3 py-2 font-medium">{expense.title}</td><td className="px-3 py-2">{expense.payee ?? "-"}</td><td className="px-3 py-2 text-danger">{expense.amount.toFixed(0)} ج.م</td><td className="px-3 py-2">{paymentMethodLabel(expense.payment_method)}</td><td className="px-3 py-2 text-muted">{expense.note ?? "-"}</td><td className="px-3 py-2">{["manual", "template"].includes(expense.source_type) && <DeleteExpenseButton expenseId={expense.id} label={expense.title} />}</td></tr>)}{expenses.length === 0 && <tr><td colSpan={8} className="px-3 py-7 text-center text-muted">لا توجد مصروفات في الفترة.</td></tr>}</tbody></table></div></section>
  </div>;
}
