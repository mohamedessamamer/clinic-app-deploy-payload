"use client";

// رابط بسيط بيفتح <details> بالـ id المحدد ويعمل scroll ليها — مستخدم في زرار
// "إدارة الموردين والتخصصات" أعلى صفحة المخزن عشان يودي المستخدم لقسم
// "إعدادات المخزن" اللي بقى details جوه نفس الصفحة بدل تحويلة لصفحة الإعدادات.
export default function OpenDetailsLink({
  targetId,
  className,
  children,
}: {
  targetId: string;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <a
      href={`#${targetId}`}
      className={className}
      onClick={(e) => {
        const el = document.getElementById(targetId);
        if (el instanceof HTMLDetailsElement) {
          e.preventDefault();
          el.open = true;
          el.scrollIntoView({ behavior: "smooth", block: "start" });
          history.replaceState(null, "", `#${targetId}`);
        }
      }}
    >
      {children}
    </a>
  );
}
