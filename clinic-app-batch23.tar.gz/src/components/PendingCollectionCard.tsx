"use client";

import { useEffect, useMemo, useState } from "react";
import { useFormStatus } from "react-dom";
import ServiceCombobox from "./ServiceCombobox";
import { PAYMENT_METHODS } from "@/lib/payment-methods";
import { recordAppointmentBillingAction } from "@/app/appointments/billing-actions";

type Service = { id: number; name: string; code?: string | null; default_price?: number | null };
type Doctor = { id: number; full_name: string };
type BillableInvoice = { id: number; service_name: string; visit_date: string; balance: number };

const FOLLOWUP_SERVICE_CODE = "0";

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      disabled={pending}
      className="rounded-md btn-3d-primary px-4 py-1.5 text-sm font-medium transition-colors disabled:opacity-60"
    >
      {pending ? "جاري التحصيل..." : "تسجيل التحصيل"}
    </button>
  );
}

// كارت "تحصيل معلّق" (دفعة 21) — بيظهر لما يكون فيه موعد "تم" لسه محتاج تحصيل
// لهذا المريض بالذات (اتعمل من دكتور معهوش صلاحية collect_payments، أو من
// الاستقبال وأجّل التحصيل). بيعرض كل تفاصيل الموعد المعلّق (امتى اتعمل، مع
// مين دكتور، وأي خدمة/سعر متوقع حدده الدكتور لو حدد) عشان الاستقبال ميتلخبطش،
// وبيسجل التحصيل (كامل أو جزئي) عن طريق نفس recordAppointmentBillingAction
// المستخدم في بوكس التحصيل بالجدول المركزي — بس مستقل تمامًا عن بوكس "إضافة
// خدمة جديدة" اللي تحته: لو المريض جه يعمل خدمة تانية خالص، الكارت ده بيفضل
// ظاهر بكل تفاصيله لحد ما حد يحصّل الموعد المعلّق ده هو نفسه بالتحديد (حتى لو
// جزء بسيط من المبلغ)، فمينفعش الدين القديم يضيع أو يتقفل من غير قصد.
export default function PendingCollectionCard({
  appointmentId,
  appointmentDate,
  doctorName,
  serviceId,
  serviceName,
  price: initialPrice,
  discountPercent: initialDiscountPercent,
  services,
  doctors = [],
  canEditAssistantDoctor = false,
  billableInvoices,
}: {
  patientId: number;
  appointmentId: number;
  appointmentDate: string;
  doctorName: string | null;
  serviceId: number | null;
  serviceName: string | null;
  price: number | null;
  discountPercent: number | null;
  services: Service[];
  // دفعة 22: نفس صلاحية "الطبيب المساعد" المستخدمة في سجل الزيارات وباقي أماكن
  // التحصيل — الاستقبال يقدر يحددها هنا كمان لو محتاجة.
  doctors?: Doctor[];
  canEditAssistantDoctor?: boolean;
  billableInvoices: BillableInvoice[];
  canBackdate: boolean;
  today: string;
}) {
  const [svcId, setSvcId] = useState<string>(serviceId ? String(serviceId) : "");
  const [price, setPrice] = useState<string>(initialPrice != null ? String(initialPrice) : "0");
  const [discountPercent, setDiscountPercent] = useState<string>(
    initialDiscountPercent != null ? String(initialDiscountPercent) : "0"
  );
  const [amountNow, setAmountNow] = useState<string>("0");
  const [amountTouched, setAmountTouched] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<string>("cash");
  const [targetInvoiceId, setTargetInvoiceId] = useState<string>("");
  const [serviceChangedByUser, setServiceChangedByUser] = useState(false);
  const [performingDoctorId, setPerformingDoctorId] = useState<string>("");

  const selectedService = useMemo(() => services.find((s) => String(s.id) === svcId) ?? null, [services, svcId]);
  const isFollowup = selectedService?.code === FOLLOWUP_SERVICE_CODE;

  const computedTotal = useMemo(() => {
    const p = Number(price) || 0;
    const d = Math.min(100, Math.max(0, Number(discountPercent) || 0));
    return Math.max(0, p * (1 - d / 100));
  }, [price, discountPercent]);

  // لو الاستقبال غيّر الخدمة يدويًا لخدمة غير اللي حددها الدكتور أصلًا، السعر
  // والخصم بيترجعوا لقيمة الخدمة الجديدة الافتراضية — زي بالظبط سلوك بوكس
  // "إضافة خدمة جديدة". أول ما الكارت بيفتح، السعر/الخصم بيفضلوا زي ما حددهم
  // الدكتور بالظبط (لو حددهم) من غير أي تعديل تلقائي.
  useEffect(() => {
    if (!serviceChangedByUser || !selectedService || isFollowup) return;
    setPrice(String(selectedService.default_price ?? 0));
    setDiscountPercent("0");
    setAmountTouched(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedService?.id]);

  useEffect(() => {
    if (!selectedService || isFollowup || amountTouched) return;
    setAmountNow(String(Math.round(computedTotal * 100) / 100));
  }, [computedTotal, selectedService, isFollowup, amountTouched]);

  const selectedTargetBalance = useMemo(
    () => billableInvoices.find((b) => String(b.id) === targetInvoiceId) ?? null,
    [billableInvoices, targetInvoiceId]
  );

  return (
    <div className="card-3d rounded-xl p-5 space-y-3 border-2 border-amber-400/60 bg-amber-50/40 dark:bg-amber-900/10">
      <h2 className="font-semibold text-amber-700 dark:text-amber-400">
        ⏳ تحصيل معلّق — موعد &quot;تم&quot; لسه محتاج تحصيل
      </h2>

      <div className="text-sm space-y-1 bg-background/60 rounded-md p-3 border border-border">
        <div>
          <span className="text-muted">تاريخ الموعد: </span>
          <span className="font-medium">{appointmentDate}</span>
        </div>
        <div>
          <span className="text-muted">الدكتور: </span>
          <span className="font-medium">{doctorName ?? "-"}</span>
        </div>
        {serviceName ? (
          <div>
            <span className="text-muted">الخدمة اللي حددها الدكتور: </span>
            <span className="font-medium">{serviceName}</span>
            {initialPrice != null && (
              <span className="text-muted">
                {" "}
                — سعر متوقع {initialPrice.toFixed(0)} ج.م
                {initialDiscountPercent ? ` (خصم ${initialDiscountPercent}%)` : ""}
              </span>
            )}
          </div>
        ) : (
          <div className="text-muted">الدكتور مايحددش خدمة معينة وقت ما دوس &quot;تم&quot; — اختار الخدمة تحت.</div>
        )}
      </div>

      <form action={recordAppointmentBillingAction} className="space-y-3">
        <input type="hidden" name="appointment_id" value={appointmentId} />
        <input type="hidden" name="payment_method" value={paymentMethod} />
        {isFollowup ? (
          <input type="hidden" name="target_invoice_id" value={targetInvoiceId} />
        ) : (
          <>
            <input type="hidden" name="price" value={price} />
            <input type="hidden" name="discount_percent" value={discountPercent} />
            {performingDoctorId && <input type="hidden" name="performing_doctor_id" value={performingDoctorId} />}
          </>
        )}
        <input type="hidden" name="amount_now" value={amountNow} />

        <div>
          <label className="block text-xs text-muted mb-1">الخدمة</label>
          <ServiceCombobox
            name="service_id"
            services={services}
            value={svcId}
            onChange={(v) => {
              setServiceChangedByUser(true);
              setSvcId(v);
            }}
          />
        </div>

        {selectedService && isFollowup && (
          <div>
            <label className="block text-xs text-muted mb-1">الخدمة الأصلية (اللي هتتخصم منها الدفعة)</label>
            {billableInvoices.length > 0 ? (
              <select
                value={targetInvoiceId}
                onChange={(e) => setTargetInvoiceId(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              >
                <option value="">اختر خدمة</option>
                {billableInvoices.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.service_name} — {b.visit_date} — الباقي {b.balance.toFixed(0)} ج.م
                  </option>
                ))}
              </select>
            ) : (
              <div className="text-xs text-danger">مفيش فواتير سابقة لسه عليها مبلغ مستحق لهذا المريض.</div>
            )}
            {selectedTargetBalance && (
              <div className="text-sm mt-1">
                الباقي المستحق: <span className="text-danger font-semibold">{selectedTargetBalance.balance.toFixed(0)} ج.م</span>
              </div>
            )}
          </div>
        )}

        {selectedService && !isFollowup && (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-muted mb-1">السعر</label>
              <input
                type="number"
                step="0.01"
                min={0}
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-muted mb-1">خصم (%)</label>
              <input
                type="number"
                step="1"
                min={0}
                max={100}
                value={discountPercent}
                onChange={(e) => setDiscountPercent(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              />
            </div>
            <div className="col-span-2 text-sm">
              المطلوب دفعه: <span className="font-semibold">{computedTotal.toFixed(0)} ج.م</span>
            </div>
            {canEditAssistantDoctor && (
              <div className="col-span-2">
                <label className="block text-xs text-muted mb-1">الطبيب المساعد (لو مختلف)</label>
                <select
                  value={performingDoctorId}
                  onChange={(e) => setPerformingDoctorId(e.target.value)}
                  className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                >
                  <option value="">نفس دكتور الموعد</option>
                  {doctors.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.full_name}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>
        )}

        {selectedService && (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-muted mb-1">المبلغ المدفوع دلوقتي</label>
              <input
                type="number"
                step="0.01"
                min={0}
                value={amountNow}
                onChange={(e) => {
                  setAmountTouched(true);
                  setAmountNow(e.target.value);
                }}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-muted mb-1">وسيلة الدفع</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              >
                {PAYMENT_METHODS.map((m) => (
                  <option key={m.value} value={m.value}>
                    {m.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        )}

        <SubmitButton />
      </form>
    </div>
  );
}
