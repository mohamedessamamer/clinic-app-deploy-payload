import Link from "next/link";
import { redirect } from "next/navigation";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { ROLE_LABELS } from "@/lib/auth";
import { getAllSettings, buildTimeSlots, weekdayOf } from "@/lib/settings";
import { hasPermission } from "@/lib/permissions";
import { getDoctorRoomIdsForDate } from "@/lib/schedule";
import { computeNeedsNewPhotosMap } from "@/lib/photo-reminder";
import CentralSchedule from "@/components/CentralSchedule";

async function DoctorHome({ userId, doctorId }: { userId: number; doctorId: number }) {
  const today = new Date().toISOString().slice(0, 10);
  const weekday = weekdayOf(today);

  const [canEditSchedule, canSeeAllRooms, canCollectPayments, canViewReports, canEditAssistantDoctor] = await Promise.all([
    hasPermission(userId, "doctor", "schedule_edit"),
    hasPermission(userId, "doctor", "schedule_all_rooms"),
    hasPermission(userId, "doctor", "collect_payments"),
    hasPermission(userId, "doctor", "reports_own"),
    // دفعة 22: حقل "الطبيب المساعد" الاختياري جوه بوكس التحصيل — نفس صلاحية
    // سجل الزيارات بالملف الطبي.
    hasPermission(userId, "doctor", "edit_visit_assistant_doctor").then(
      async (v) => v || (await hasPermission(userId, "doctor", "override_visit_doctor"))
    ),
  ]);

  const allRooms = await db.selectFrom("rooms").selectAll().execute();
  const myRoomIds = canSeeAllRooms ? null : await getDoctorRoomIdsForDate(doctorId, today);
  const visibleRooms = myRoomIds ? allRooms.filter((r) => myRoomIds.includes(r.id)) : allRooms;

  const [appointmentsRaw, patients, doctors, services, billedApptRows, settings, roomShiftsToday] = await Promise.all([
    db
      .selectFrom("appointments")
      .innerJoin("patients", "patients.id", "appointments.patient_id")
      .leftJoin("doctors", "doctors.id", "appointments.doctor_id")
      .leftJoin("services", "services.id", "appointments.pending_service_id")
      .select([
        "appointments.id",
        "appointments.patient_id",
        "patients.full_name as patient_name",
        "appointments.doctor_id",
        "doctors.full_name as doctor_name",
        "appointments.room_id",
        "appointments.start_time",
        "appointments.duration_minutes",
        "appointments.status",
        "appointments.notes",
        "appointments.pending_service_id",
        "appointments.pending_price",
        "appointments.pending_discount_percent",
        "services.name as pending_service_name",
      ])
      .where("appointment_date", "=", today)
      .where("status", "!=", "cancelled")
      .orderBy("appointments.start_time")
      .execute(),
    db.selectFrom("patients").select(["id", "full_name", "file_number"]).orderBy("id", "desc").limit(500).execute(),
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).execute(),
    db.selectFrom("services").select(["id", "name", "default_price", "code"]).execute(),
    db
      .selectFrom("visits")
      .select("appointment_id")
      .where("visit_date", "=", today)
      .where("appointment_id", "is not", null)
      .execute(),
    getAllSettings(),
    // نفس فكرة roomShiftDoctorIds في front-desk/page.tsx — عشان بوكس الحجز هنا كمان
    // يحدد صاحب شيفت الغرفة افتراضيًا (الجدول المركزي مدموج هنا كصفحة رئيسية للدكتور).
    visibleRooms.length > 0
      ? db
          .selectFrom("doctor_weekly_shifts")
          .select(["room_id", "doctor_id", "start_time"])
          .where(
            "room_id",
            "in",
            visibleRooms.map((r) => r.id)
          )
          .where("weekday", "=", weekday)
          .orderBy("start_time")
          .execute()
      : Promise.resolve([]),
  ]);

  const slotMinutes = Number(settings.slot_minutes);
  const timeSlots = buildTimeSlots(settings.day_start, settings.day_end, slotMinutes);

  const roomShiftDoctorIds: Record<number, number> = {};
  for (const s of roomShiftsToday) {
    if (!(s.room_id in roomShiftDoctorIds)) roomShiftDoctorIds[s.room_id] = s.doctor_id;
  }

  const billedApptIds = new Set(billedApptRows.map((r) => r.appointment_id).filter((id): id is number => id != null));
  const needsPhotosMap = await computeNeedsNewPhotosMap(appointmentsRaw.map((a) => a.patient_id));

  const appointments = appointmentsRaw.map((a) => ({
    id: a.id,
    patient_id: a.patient_id,
    patient_name: a.patient_name,
    doctor_id: a.doctor_id,
    doctor_name: a.doctor_name ?? "-",
    room_id: a.room_id,
    start_time: a.start_time,
    duration_minutes: a.duration_minutes,
    status: a.status as "booked" | "attended" | "done" | "cancelled" | "no_show",
    notes: a.notes,
    needs_billing: a.status === "done" && !billedApptIds.has(a.id),
    pending_service_id: a.pending_service_id,
    pending_service_name: a.pending_service_name,
    pending_price: a.pending_price,
    pending_discount_percent: a.pending_discount_percent,
    needs_new_photos: needsPhotosMap.get(a.patient_id) ?? false,
  }));

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-xl font-bold">جدول اليوم</h1>
          <p className="text-muted text-sm mt-1">
            {canSeeAllRooms ? "الجدول المركزي لكل العيادات — بيتزامن أوتوماتيك مع الاستقبال." : "جدول شيفتك النهاردة — بيتزامن أوتوماتيك مع الاستقبال."}
          </p>
        </div>
        {canViewReports && (
          <Link href="/reports" className="px-3 py-2 rounded-md border border-border text-sm hover:bg-primary-soft whitespace-nowrap">
            تقريري
          </Link>
        )}
      </div>

      {visibleRooms.length === 0 ? (
        <div className="text-sm bg-danger-soft text-danger rounded-md px-3 py-2">
          مفيش شيفت أسبوعي مسجل ليك في يوم النهاردة — كلم الأدمن لو محتاج تتأكد من شيفتاتك.
        </div>
      ) : (
        <CentralSchedule
          date={today}
          rooms={visibleRooms}
          timeSlots={timeSlots}
          slotMinutes={slotMinutes}
          appointments={appointments}
          patients={patients}
          doctors={doctors}
          services={services}
          canEdit={canEditSchedule}
          canCollectPayments={canCollectPayments}
          canEditAssistantDoctor={canEditAssistantDoctor}
          isDoctorView
          roomShiftDoctorIds={roomShiftDoctorIds}
        />
      )}
    </div>
  );
}

async function getStats() {
  const [{ count: patients } = { count: 0 }] = await db
    .selectFrom("patients")
    .select((eb) => eb.fn.countAll<number>().as("count"))
    .execute();

  const [{ count: todayAppointments } = { count: 0 }] = await db
    .selectFrom("appointments")
    .select((eb) => eb.fn.countAll<number>().as("count"))
    .where("appointment_date", "=", new Date().toISOString().slice(0, 10))
    .execute();

  const [{ count: todayVisits } = { count: 0 }] = await db
    .selectFrom("visits")
    .select((eb) => eb.fn.countAll<number>().as("count"))
    .where("visit_date", "=", new Date().toISOString().slice(0, 10))
    .execute();

  return { patients, todayAppointments, todayVisits };
}

export default async function HomePage() {
  const session = await getSession();

  if (session?.role === "doctor" && session.doctorId) {
    return <DoctorHome userId={session.userId} doctorId={session.doctorId} />;
  }

  // الاستقبال: صفحته الرئيسية هي الجدول المركزي مباشرة (مفيش داعي لصفحة إحصائيات
  // وسيطة قبله)، بدل ما يضطر يدوس "جدول الاستقبال" من القايمة كل مرة يسجل دخول.
  if (session?.role === "reception") {
    redirect("/front-desk");
  }

  const stats = await getStats();

  const cards = [
    { label: "إجمالي المرضى", value: stats.patients, href: "/patients" },
    { label: "مواعيد اليوم", value: stats.todayAppointments, href: "/front-desk" },
    { label: "زيارات اليوم", value: stats.todayVisits, href: "/patients" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold">لوحة التحكم</h1>
        <p className="text-muted text-sm mt-1">
          نظرة سريعة على العيادة اليوم — {ROLE_LABELS[session!.role]}
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {cards.map((c) => (
          <Link
            key={c.label}
            href={c.href}
            className="card-3d rounded-xl p-5 hover:border-primary transition-colors"
          >
            <div className="text-3xl font-bold text-primary">{c.value}</div>
            <div className="text-sm text-muted mt-1">{c.label}</div>
          </Link>
        ))}
      </div>

      <div className="card-3d rounded-xl p-5">
        <h2 className="font-semibold mb-3">روابط سريعة</h2>
        <div className="flex flex-wrap gap-2">
          <Link href="/patients/new" className="px-3 py-2 rounded-md btn-3d-primary text-sm">
            + مريض جديد
          </Link>
          <Link href="/front-desk" className="px-3 py-2 rounded-md border border-border text-sm hover:bg-primary-soft">
            الاستقبال
          </Link>
          <Link href="/invoices" className="px-3 py-2 rounded-md border border-border text-sm hover:bg-primary-soft">
            الفواتير
          </Link>
        </div>
      </div>
    </div>
  );
}
