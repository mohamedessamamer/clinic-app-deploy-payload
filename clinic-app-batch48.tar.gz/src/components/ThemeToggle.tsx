"use client";

import { useEffect, useState } from "react";

export default function ThemeToggle() {
  const [dark, setDark] = useState(false);

  useEffect(() => {
    const saved = window.localStorage.getItem("clinic-theme");
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    const useDark = saved ? saved === "dark" : prefersDark;
    document.body.dataset.theme = useDark ? "dark" : "light";
    setDark(useDark);
  }, []);

  function toggle() {
    const next = !dark;
    setDark(next);
    document.body.dataset.theme = next ? "dark" : "light";
    window.localStorage.setItem("clinic-theme", next ? "dark" : "light");
  }

  return (
    <button type="button" onClick={toggle} className="clinic-theme-toggle" aria-label={dark ? "تفعيل الوضع الفاتح" : "تفعيل الوضع الداكن"} title={dark ? "الوضع الفاتح" : "الوضع الداكن"}>
      {dark ? "☀" : "☾"}
    </button>
  );
}
