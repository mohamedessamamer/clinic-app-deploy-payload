import Database from "better-sqlite3";
import { ELASTOMERIC_COLORS, elastomericItemName } from "@/lib/ortho/elastomeric-colors";

type ClinicalItem = {
  name: string;
  category: string;
  unit: string;
  orthoUsage: string | null;
  group: string | null;
  autoDeductionKey?: string | null;
  legacyName?: string;
};

// مصدر واحد لكتالوج التقويم. يُشغَّل مع النشر تلقائياً، وليس محتاجاً أن
// يعرّف الموظف Wire أو لون أو مقاس يدوياً. لا يلمس الكميات أو الموردين أو
// حالة إتاحة الصنف التي ضبطها المستخدم؛ يضيف الناقص وينظم الموجود فقط.
export function seedOrthodonticInventoryCatalog(sqlite: InstanceType<typeof Database>) {
  const categories = ["TADS", "BRACKETS", "BANDS", "WIRES", "AUXILIARIES", "ELASTICS", "ADHESIVES"];
  sqlite.prepare("INSERT INTO inventory_specialties (name) VALUES (?) ON CONFLICT(name) DO NOTHING").run("تقويم");
  const specialty = sqlite.prepare("SELECT id FROM inventory_specialties WHERE name = ?").get("تقويم") as { id: number };
  const addCategory = sqlite.prepare("INSERT INTO inventory_categories (specialty_id, name) VALUES (?, ?) ON CONFLICT(specialty_id, name) DO NOTHING");
  categories.forEach((name) => addCategory.run(specialty.id, name));
  const categoryRows = sqlite.prepare("SELECT id, name FROM inventory_categories WHERE specialty_id = ?").all(specialty.id) as Array<{ id: number; name: string }>;
  const categoryIds = new Map(categoryRows.map((row) => [row.name, row.id]));

  const brackets = [
    "American Roth 0.018", "American Roth 0.022", "American MBT 0.018", "American MBT 0.022",
    "Ormco Roth 0.018", "Ormco Roth 0.022", "Ormco MBT 0.018", "Ormco MBT 0.022",
  ];
  const items: ClinicalItem[] = [
    { name: "TAD 1.6 × 8", category: "TADS", unit: "screw", orthoUsage: "anchorage_device", group: "TAD" },
    { name: "TAD 1.6 × 10", category: "TADS", unit: "screw", orthoUsage: "anchorage_device", group: "TAD" },
    ...brackets.map((name) => ({ name, category: "BRACKETS", unit: "bracket", orthoUsage: "bracket", group: name.replace(/ 0\.\d+$/, "") })),
    ...brackets.map((name) => ({ name: `${name} — Tube`, category: "BRACKETS", unit: "tube", orthoUsage: "tube", group: `${name.replace(/ 0\.\d+$/, "")} Tubes` })),
    ...["0.012", "0.014", "0.016", "0.016 × 0.022", "0.017 × 0.025", "0.019 × 0.025"].map((size) => ({ name: `NiTi ${size}`, category: "WIRES", unit: "wire", orthoUsage: "wire", group: "NiTi" })),
    ...["0.012", "0.016", "0.018", "0.016 × 0.022", "0.017 × 0.025", "0.019 × 0.025"].map((size) => ({ name: `St.St ${size}`, category: "WIRES", unit: "wire", orthoUsage: "wire", group: "St.St" })),
    { name: "Elastic 1/8", category: "ELASTICS", unit: "packet", orthoUsage: "elastic", group: "Elastics" },
    { name: "Elastic 3/16", category: "ELASTICS", unit: "packet", orthoUsage: "elastic", group: "Elastics" },
    { name: "Elastic 5/16", category: "ELASTICS", unit: "packet", orthoUsage: "elastic", group: "Elastics" },
    ...ELASTOMERIC_COLORS.flatMap(([code, name, hex]) => {
      const color = { code, name, hex };
      return [
        { name: elastomericItemName("O-tie", color), legacyName: `O-tie — ${name}`, category: "ELASTICS", unit: "piece", orthoUsage: "otie", group: "O-tie" },
        { name: elastomericItemName("Power chain", color), legacyName: `Power chain — ${name}`, category: "ELASTICS", unit: "piece", orthoUsage: "power_chain", group: "Power chain" },
      ];
    }),
    { name: "Compressed coil", category: "AUXILIARIES", unit: "mm", orthoUsage: "compressed_coil", group: "Coils" },
    { name: "Button", category: "AUXILIARIES", unit: "piece", orthoUsage: "button", group: "Buttons" },
    { name: "Stripping paper", category: "AUXILIARIES", unit: "mm", orthoUsage: null, group: "Stripping" },
    { name: "Ligature wire", category: "AUXILIARIES", unit: "piece", orthoUsage: null, group: "Ligature wire" },
    { name: "Orthodontic composite", category: "ADHESIVES", unit: "mg", orthoUsage: null, group: "Composite", autoDeductionKey: "orthodontic_composite" },
  ];

  const byName = sqlite.prepare("SELECT id FROM inventory_items WHERE name = ?");
  const insert = sqlite.prepare(`INSERT INTO inventory_items (name, quantity, unit, specialty_id, category_id, catalog_group, ortho_usage, auto_deduction_key)
    VALUES (?, 0, ?, ?, ?, ?, ?, ?)`);
  const update = sqlite.prepare("UPDATE inventory_items SET name = ?, unit = ?, specialty_id = ?, category_id = ?, catalog_group = ?, ortho_usage = ?, auto_deduction_key = ? WHERE id = ?");
  for (const item of items) {
    const existing = byName.get(item.name) as { id: number } | undefined;
    const legacy = !existing && item.legacyName ? byName.get(item.legacyName) as { id: number } | undefined : undefined;
    const categoryId = categoryIds.get(item.category);
    if (!categoryId) continue;
    if (existing || legacy) {
      update.run(item.name, item.unit, specialty.id, categoryId, item.group, item.orthoUsage, item.autoDeductionKey ?? null, (existing ?? legacy)!.id);
    } else {
      insert.run(item.name, item.unit, specialty.id, categoryId, item.group, item.orthoUsage, item.autoDeductionKey ?? null);
    }
  }

  // مستهلكات عامة: لا ترتبط بخدمة تقويم بعينها، لكنها جاهزة لتحديد متوسط
  // الاستهلاك لكل مريض «تم» من صفحة المخزن (Gloves مثلاً = 2 pair).
  sqlite.prepare("INSERT INTO inventory_specialties (name) VALUES (?) ON CONFLICT(name) DO NOTHING").run("مستهلكات عامة");
  const consumablesSpecialty = sqlite.prepare("SELECT id FROM inventory_specialties WHERE name = ?").get("مستهلكات عامة") as { id: number };
  sqlite.prepare("INSERT INTO inventory_categories (specialty_id, name) VALUES (?, ?) ON CONFLICT(specialty_id, name) DO NOTHING").run(consumablesSpecialty.id, "GENERAL CONSUMABLES");
  const consumablesCategory = sqlite.prepare("SELECT id FROM inventory_categories WHERE specialty_id = ? AND name = ?").get(consumablesSpecialty.id, "GENERAL CONSUMABLES") as { id: number };
  const consumables = [
    ["Gloves", "pair"], ["Napkins", "piece"], ["Suction tips", "piece"], ["Air tips", "piece"],
    ["Cups", "piece"], ["Over gloves", "pair"], ["Tissues", "piece"], ["Sleeves", "piece"],
  ] as const;
  const findGeneral = sqlite.prepare("SELECT id FROM inventory_items WHERE name = ?");
  const insertGeneral = sqlite.prepare(`INSERT INTO inventory_items (name, quantity, unit, specialty_id, category_id, catalog_group, is_general_consumable)
    VALUES (?, 0, ?, ?, ?, 'General consumables', 1)`);
  const updateGeneral = sqlite.prepare("UPDATE inventory_items SET unit = ?, specialty_id = ?, category_id = ?, catalog_group = 'General consumables', is_general_consumable = 1 WHERE id = ?");
  for (const [name, unit] of consumables) {
    const existing = findGeneral.get(name) as { id: number } | undefined;
    if (existing) updateGeneral.run(unit, consumablesSpecialty.id, consumablesCategory.id, existing.id);
    else insertGeneral.run(name, unit, consumablesSpecialty.id, consumablesCategory.id);
  }
}
