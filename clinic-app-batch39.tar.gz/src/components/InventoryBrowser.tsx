"use client";

import { useMemo, useState } from "react";
import { receiveInventorySupplyAction, saveInventoryItemUsageSettingsAction } from "@/app/inventory/actions";

type Specialty = { id: number; name: string };
type Category = { id: number; specialty_id: number; name: string };
type Item = {
  id: number;
  name: string;
  quantity: number;
  unit: string | null;
  specialty_id: number | null;
  category_id: number | null;
  catalog_group: string | null;
  critical_stock_threshold: number;
};

const inputClass = "w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm";

// نقطة الدخول اليومية للمخزن: التخصص ثم الفئة ثم المجموعة الفرعية. لا تُظهر
// شاشة التوريد الكاملة إلا عند الحاجة؛ الشراء المعتاد يتسجل بجوار الصنف نفسه.
export default function InventoryBrowser({ specialties, categories, items }: {
  specialties: Specialty[];
  categories: Category[];
  items: Item[];
}) {
  const [specialtyId, setSpecialtyId] = useState<number | null>(null);
  const [categoryId, setCategoryId] = useState<number | null>(null);
  const visibleCategories = useMemo(() => categories.filter((category) => category.specialty_id === specialtyId), [categories, specialtyId]);
  const visibleItems = useMemo(() => items.filter((item) => item.category_id === categoryId), [items, categoryId]);
  const groups = useMemo(() => {
    const map = new Map<string, Item[]>();
    for (const item of visibleItems) {
      const group = item.catalog_group || "أصناف أخرى";
      map.set(group, [...(map.get(group) ?? []), item]);
    }
    return Array.from(map.entries()).sort(([a], [b]) => a.localeCompare(b));
  }, [visibleItems]);

  return <section className="card-3d rounded-xl p-5 space-y-4">
    <div>
      <h2 className="font-semibold">تصفح المخزن والجرد السريع</h2>
      <p className="text-xs text-muted mt-1">اختر التخصص، ثم الفئة. بجوار كل صنف يظهر الرصيد الحالي وخانة لإضافة شراء جديد مباشرة.</p>
    </div>

    <div className="max-w-sm">
      <label className="block text-xs text-muted mb-1">التخصص</label>
      <select value={specialtyId ?? ""} onChange={(event) => { setSpecialtyId(event.target.value ? Number(event.target.value) : null); setCategoryId(null); }} className={inputClass}>
        <option value="">اختر التخصص</option>
        {specialties.map((specialty) => <option key={specialty.id} value={specialty.id}>{specialty.name}</option>)}
      </select>
    </div>

    {specialtyId && <div className="flex flex-wrap gap-2">
      {visibleCategories.map((category) => {
        const count = items.filter((item) => item.category_id === category.id).length;
        return <button key={category.id} type="button" onClick={() => setCategoryId(category.id)} className={`rounded-lg border px-3 py-2 text-sm transition ${categoryId === category.id ? "border-primary bg-primary-soft text-primary-dark font-semibold" : "border-border hover:bg-primary-soft"}`}>
          {category.name} <span className="text-xs opacity-70">({count})</span>
        </button>;
      })}
      {visibleCategories.length === 0 && <span className="text-sm text-muted">لا توجد فئات تحت هذا التخصص بعد.</span>}
    </div>}

    {categoryId && <div className="space-y-4">
      {groups.map(([group, groupItems]) => <div key={group} className="rounded-lg border border-border overflow-hidden">
        <div className="bg-primary-soft px-4 py-2 text-sm font-semibold">{group}</div>
        <div className="divide-y divide-border">
          {groupItems.map((item) => <div key={item.id} className="grid grid-cols-1 xl:grid-cols-[minmax(180px,1fr)_auto_auto_auto] gap-3 items-center px-4 py-3">
            <div className="font-medium text-sm">{item.name}</div>
            <div className="rounded-md border border-primary/30 bg-primary-soft px-3 py-1.5 text-sm whitespace-nowrap">المخزون: <b>{item.quantity}</b> {item.unit ?? ""}</div>
            <form action={receiveInventorySupplyAction} className="flex items-center gap-1.5">
              <input type="hidden" name="item_id" value={item.id} />
              <input name="quantity_received" type="number" min="0.01" step="0.01" required placeholder="شراء جديد" aria-label={`إضافة شراء جديد لـ ${item.name}`} className="w-28 rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
              <button className="rounded-md btn-3d-primary px-3 py-1.5 text-xs whitespace-nowrap">إضافة</button>
            </form>
            <form action={saveInventoryItemUsageSettingsAction} className="flex items-center gap-1.5 flex-wrap">
              <input type="hidden" name="item_id" value={item.id} />
              <input name="unit" required defaultValue={item.unit ?? ""} placeholder="وحدة الاستعمال" aria-label={`وحدة استعمال ${item.name}`} className="w-28 rounded-md border border-border bg-background px-2 py-1.5 text-xs" />
              <input name="critical_stock_threshold" type="number" min="0" step="0.01" defaultValue={item.critical_stock_threshold || ""} placeholder="الحد الحرج" aria-label={`الحد الحرج لـ ${item.name}`} className="w-24 rounded-md border border-border bg-background px-2 py-1.5 text-xs" />
              <button className="rounded-md border border-border px-2 py-1.5 text-xs hover:bg-primary-soft">حفظ</button>
            </form>
          </div>)}
        </div>
      </div>)}
      {groups.length === 0 && <div className="rounded-lg border border-dashed border-border p-5 text-sm text-muted">لا توجد أصناف داخل هذه الفئة بعد. يمكنك إضافتها من قسم «تعريف خامة» بالأسفل.</div>}
    </div>}
  </section>;
}
