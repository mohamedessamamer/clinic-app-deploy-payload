import Database from "better-sqlite3";
import { Kysely, SqliteDialect } from "kysely";
import fs from "node:fs";
import path from "node:path";
import type { Database as DB } from "./types";
import { REAL_SERVICES_SEED } from "./seed-services";
import { seedOrthodonticInventoryCatalog } from "./seed-orthodontic-inventory";

const DB_PATH = process.env.CLINIC_DB_PATH || path.join(process.cwd(), "data", "clinic.db");

// Ensure the data directory exists (works for local disk in dev; a real deployment
// on the VPS would point CLINIC_DB_PATH at a persistent volume).
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

// Next.js/Turbopack can evaluate this module more than once inside the SAME
// process — dev-mode Fast Refresh, or (as happened in production right after
// the 2026-08-27 orthodontics-v2 deploy) a Server Action living in its own
// chunk importing this file for the first time moments after the page chunk
// already did. Each fresh module evaluation used to open its OWN better-sqlite3
// connection to the same file and re-run the full migration pass below inside
// its own "BEGIN IMMEDIATE". Two such connections racing for that write lock
// used to be tolerable (the second just waits out busy_timeout), but once the
// migration list below grew, several connections piling up around one restart
// compounded into 30+ seconds of every request site-wide stalling waiting on
// the SQLite write lock — this is what caused the outage right after this same
// deploy. Caching the connection AND a "migrations already ran" flag on
// `globalThis` (per OS process, unlike this module's own top-level scope,
// which is per module-instance) guarantees both happen exactly once per
// running server no matter how many separate chunks import this file.
const globalForDb = globalThis as unknown as {
  __clinicSqlite?: InstanceType<typeof Database>;
  __clinicMigrated?: boolean;
};

const sqlite = globalForDb.__clinicSqlite ?? new Database(DB_PATH);
if (!globalForDb.__clinicSqlite) {
  globalForDb.__clinicSqlite = sqlite;
  sqlite.pragma("journal_mode = WAL");
  sqlite.pragma("foreign_keys = ON");
  // Kept as a second line of defense (e.g. an external process touching the
  // same file), even though the globalThis cache above removes the main
  // source of same-process contention.
  // Production builds evaluate several route workers in parallel. A longer wait
  // lets the remaining workers reuse the freshly migrated schema instead of
  // failing the build with SQLITE_BUSY on the first deployment of a release.
  sqlite.pragma("busy_timeout = 60000");
}

// Lightweight migrations for columns added after the initial CREATE TABLE.
// SQLite has no "ADD COLUMN IF NOT EXISTS", so we just swallow the duplicate-column error.
function tryAddColumn(table: string, ddl: string) {
  try {
    sqlite.exec(`ALTER TABLE ${table} ADD COLUMN ${ddl}`);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    if (!message.includes("duplicate column name")) throw err;
  }
}

// سجل الترحيلات: كل الترحيلات القديمة فوق (tryAddColumn وإعادة بناء الجداول)
// فضلت زي ما هي من غير لمس — هي أصلاً محمية بنفسها (duplicate column
// / فحص sqlite_master) فمافيش خطر إنها تتكرر، وإعادة كتابتها كلها دلوقتي
// كانت هتبقى تغيير كبير وخطير على حاجة شغالة من غير أي فايدة حقيقية.
// اللي كان ناقص فعلاً هو: مفيش سجل تقدر تشوفه (مباشرة من الـSQL) يقولك
// إيه اللي اتنفذ وإمتى. runMigration() بتحل المشكلة دي لأي ترحيل جديد من
// دلوقتي فصاعدًا: بتاخد اسم واحد فريد لكل ترحيل، تشيك هل اتسجل قبل كده في
// جدول schema_migrations، ولو لأ تنفذه وتسجله. النتيجة: أي حد يقدر يشغّل
// SELECT * FROM schema_migrations ORDER BY applied_at DESC على السيرفر
// ويشوف تاريخ كل ترحيل جديد بالظبط.
function runMigration(name: string, run: () => void) {
  const already = sqlite.prepare("SELECT 1 FROM schema_migrations WHERE name = ?").get(name);
  if (already) return;
  run();
  sqlite.prepare("INSERT INTO schema_migrations (name) VALUES (?)").run(name);
}

// Rebuilds `table` from `createFixedTableSql` (which must CREATE TABLE `${table}_fixed`)
// if and only if its current schema still references the now-nonexistent "users_old"
// table (see the long comment on the users-table rebuild below for how that happens).
// Same "build under a new name, drop the old, rename into place" pattern — safe even
// if this table is itself referenced elsewhere, since we never rename the live table away.
function repairDanglingUsersOldReference(table: string, createFixedTableSql: string) {
  const row = sqlite.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name=?").get(table) as
    | { sql: string }
    | undefined;
  if (!row || !row.sql.includes("users_old")) return;

  sqlite.exec(`DROP TABLE IF EXISTS ${table}_fixed;`);
  sqlite.exec(createFixedTableSql);
  sqlite.exec(`
    INSERT INTO ${table}_fixed SELECT * FROM ${table};
    DROP TABLE ${table};
    ALTER TABLE ${table}_fixed RENAME TO ${table};
  `);
}

// All startup migrations run inside a single BEGIN IMMEDIATE transaction so that
// if two connections (e.g. two route chunks initializing concurrently on first
// request) reach this code at the same time, the second one blocks until the
// first commits, then re-checks conditions against the now-migrated schema
// instead of racing on multi-statement DDL like the users-table rebuild below.
function runStartupMigrations() {
  // The users-table rebuild below drops and recreates "users" (see the comment further
  // down). SQLite refuses to drop a table that other tables have *live rows* referencing
  // via foreign key (visits.created_by, audit_log.changed_by, user_permissions.user_id) —
  // not just a schema check, an actual data check — so once the clinic has any real visits/
  // audit/permission rows this would otherwise hard-fail (and crash-loop on every restart,
  // since the migration never completes). FK enforcement can only be toggled outside a
  // transaction, so it's off for this whole function and restored in the finally below.
  sqlite.pragma("foreign_keys = OFF");
  sqlite.exec("BEGIN IMMEDIATE");
  try {
    // Run schema.sql once at startup — idempotent (CREATE TABLE IF NOT EXISTS).
    const schemaPath = path.join(process.cwd(), "src", "lib", "db", "schema.sql");
    if (fs.existsSync(schemaPath)) {
      sqlite.exec(fs.readFileSync(schemaPath, "utf-8"));
    }

    // لازم توجد قبل أول استخدام لـrunMigration() تحت.
    sqlite.exec(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        applied_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `);

    tryAddColumn("invoices", "discount_percent REAL NOT NULL DEFAULT 0");
    tryAddColumn("invoices", "price_overridden INTEGER NOT NULL DEFAULT 0");
    tryAddColumn("services", "code TEXT");
    tryAddColumn("services", "prepaid INTEGER NOT NULL DEFAULT 0");
    tryAddColumn("services", "name_en TEXT");
    tryAddColumn("services", "category TEXT");
    tryAddColumn("services", "price_note TEXT");
    tryAddColumn("services", "has_lab_cost INTEGER NOT NULL DEFAULT 0");
    tryAddColumn("services", "lab_cost REAL NOT NULL DEFAULT 0");
    tryAddColumn("appointments", "duration_minutes INTEGER");
    tryAddColumn("expense_templates", "effective_from TEXT");
    tryAddColumn("expense_templates", "effective_to TEXT");
    tryAddColumn("expenses", "doctor_id INTEGER REFERENCES doctors(id)");
    tryAddColumn("expenses", "patient_id INTEGER REFERENCES patients(id)");
    tryAddColumn("expenses", "service_id INTEGER REFERENCES services(id)");
    tryAddColumn("expenses", "affects_commission INTEGER NOT NULL DEFAULT 0");
    // نقل قواعد نسب الأطباء القديمة إلى شاشة HR الجديدة مرة واحدة مع الحفاظ
    // على الجدول القديم لقراءة أي كشوف سابقة بدون تغييرها.
    sqlite.exec(`
      INSERT OR IGNORE INTO hr_compensation_rules (
        person_type, person_id, staff_group, compensation_type, fixed_basis,
        fixed_amount, percentage_basis, percentage_mode, percentage,
        effective_from, active, created_by
      )
      SELECT 'doctor', doctor_id, 'doctor', compensation_type, 'monthly',
        fixed_amount, 'personal', 'fixed', percentage, effective_from, active, created_by
      FROM doctor_compensation_rules;
    `);
    // دفعة 83: نفصل سجل الموظفين عن حسابات الدخول. الموظف القديم الذي سبق
    // تعريف راتب له يُحفظ كسجل HR مستقل ومربوط بحسابه؛ باقي الحسابات الخدمية
    // لا تظهر تلقائيًا داخل HR.
    const oldHrRulesSchema = sqlite.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='hr_compensation_rules'").get() as { sql?: string } | undefined;
    const oldHrRunsSchema = sqlite.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='hr_payroll_runs'").get() as { sql?: string } | undefined;
    if (oldHrRulesSchema?.sql?.includes("'user'") || oldHrRunsSchema?.sql?.includes("'user'")) {
      sqlite.exec(`
        INSERT OR IGNORE INTO hr_staff (full_name, staff_group, linked_user_id, employment_start, active, created_by)
        SELECT u.full_name,
          CASE WHEN r.staff_group='nursing' THEN 'nursing' ELSE 'employee' END,
          u.id, r.effective_from, u.active, r.created_by
        FROM hr_compensation_rules r JOIN users u ON u.id=r.person_id
        WHERE r.person_type='user';
        INSERT OR IGNORE INTO hr_staff (full_name, staff_group, linked_user_id, employment_start, active, created_by)
        SELECT u.full_name,
          CASE WHEN p.staff_group='nursing' THEN 'nursing' ELSE 'employee' END,
          u.id, MIN(p.period_from), u.active, p.created_by
        FROM hr_payroll_runs p JOIN users u ON u.id=p.person_id
        WHERE p.person_type='user' GROUP BY u.id;
      `);
    }
    if (oldHrRulesSchema?.sql?.includes("'user'")) {
      sqlite.exec(`
        DROP TABLE IF EXISTS hr_compensation_rules_v83;
        CREATE TABLE hr_compensation_rules_v83 (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          person_type TEXT NOT NULL CHECK (person_type IN ('doctor','staff')),
          person_id INTEGER NOT NULL,
          staff_group TEXT NOT NULL CHECK (staff_group IN ('doctor','employee','nursing')),
          compensation_type TEXT NOT NULL CHECK (compensation_type IN ('fixed','percentage','mixed')),
          fixed_basis TEXT NOT NULL DEFAULT 'monthly' CHECK (fixed_basis IN ('monthly','shift')),
          fixed_amount REAL NOT NULL DEFAULT 0 CHECK (fixed_amount >= 0),
          percentage_basis TEXT NOT NULL DEFAULT 'personal' CHECK (percentage_basis IN ('personal','clinic')),
          percentage_mode TEXT NOT NULL DEFAULT 'fixed' CHECK (percentage_mode IN ('fixed','progressive')),
          percentage REAL NOT NULL DEFAULT 0 CHECK (percentage >= 0 AND percentage <= 100),
          effective_from TEXT NOT NULL, effective_to TEXT, active INTEGER NOT NULL DEFAULT 1,
          created_by INTEGER REFERENCES users(id), updated_at TEXT NOT NULL DEFAULT (datetime('now')),
          UNIQUE(person_type, person_id)
        );
        INSERT INTO hr_compensation_rules_v83
        SELECT id,
          CASE WHEN person_type='user' THEN 'staff' ELSE person_type END,
          CASE WHEN person_type='user' THEN (SELECT id FROM hr_staff WHERE linked_user_id=hr_compensation_rules.person_id) ELSE person_id END,
          staff_group, compensation_type, fixed_basis, fixed_amount, percentage_basis,
          percentage_mode, percentage, effective_from, effective_to, active, created_by, updated_at
        FROM hr_compensation_rules;
        DROP TABLE hr_compensation_rules;
        ALTER TABLE hr_compensation_rules_v83 RENAME TO hr_compensation_rules;
      `);
    }
    if (oldHrRunsSchema?.sql?.includes("'user'")) {
      sqlite.exec(`
        DROP TABLE IF EXISTS hr_payroll_runs_v83;
        CREATE TABLE hr_payroll_runs_v83 (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          person_type TEXT NOT NULL CHECK (person_type IN ('doctor','staff')),
          person_id INTEGER NOT NULL, person_name TEXT NOT NULL,
          staff_group TEXT NOT NULL CHECK (staff_group IN ('doctor','employee','nursing')),
          period_from TEXT NOT NULL, period_to TEXT NOT NULL, shift_count REAL NOT NULL DEFAULT 0,
          fixed_amount REAL NOT NULL DEFAULT 0, percentage_basis TEXT NOT NULL,
          percentage_mode TEXT NOT NULL, percentage REAL NOT NULL DEFAULT 0,
          gross_collected REAL NOT NULL DEFAULT 0, lab_cost REAL NOT NULL DEFAULT 0,
          net_collected REAL NOT NULL DEFAULT 0, percentage_amount REAL NOT NULL DEFAULT 0,
          incentives REAL NOT NULL DEFAULT 0, deductions REAL NOT NULL DEFAULT 0,
          total_amount REAL NOT NULL DEFAULT 0,
          status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','paid')),
          paid_date TEXT, expense_id INTEGER UNIQUE REFERENCES expenses(id),
          created_by INTEGER REFERENCES users(id), paid_by INTEGER REFERENCES users(id),
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          UNIQUE(person_type, person_id, period_from, period_to)
        );
        INSERT INTO hr_payroll_runs_v83 (
          id, person_type, person_id, person_name, staff_group, period_from, period_to,
          shift_count, fixed_amount, percentage_basis, percentage_mode, percentage,
          gross_collected, lab_cost, net_collected, percentage_amount, incentives,
          deductions, total_amount, status, paid_date, expense_id, created_by, paid_by, created_at
        ) SELECT id,
          CASE WHEN person_type='user' THEN 'staff' ELSE person_type END,
          CASE WHEN person_type='user' THEN (SELECT id FROM hr_staff WHERE linked_user_id=hr_payroll_runs.person_id) ELSE person_id END,
          person_name, staff_group, period_from, period_to, shift_count, fixed_amount,
          percentage_basis, percentage_mode, percentage, gross_collected, lab_cost,
          net_collected, percentage_amount, 0, 0, total_amount, status, paid_date,
          expense_id, created_by, paid_by, created_at
        FROM hr_payroll_runs;
        DROP TABLE hr_payroll_runs;
        ALTER TABLE hr_payroll_runs_v83 RENAME TO hr_payroll_runs;
        CREATE INDEX IF NOT EXISTS idx_hr_payroll_period ON hr_payroll_runs(period_from, period_to, person_type, person_id);
      `);
    }
    tryAddColumn("hr_payroll_runs", "incentives REAL NOT NULL DEFAULT 0");
    tryAddColumn("hr_payroll_runs", "deductions REAL NOT NULL DEFAULT 0");
    // وقت ضغط الاستقبال على «حضر» هو مصدر ترتيب قائمة انتظار كل عيادة.
    // يظل NULL للمواعيد القديمة وتعرضها القائمة بترتيب الموعد كـfallback.
    tryAddColumn("appointments", "attended_at TEXT");
    tryAddColumn("appointments", "completed_at TEXT");
    tryAddColumn("appointments", "confirmed_at TEXT");
    tryAddColumn("appointments", "reschedule_pending INTEGER NOT NULL DEFAULT 0");
    tryAddColumn("visits", "appointment_id INTEGER REFERENCES appointments(id)");
    // SQLite لا يسمح بإضافة UNIQUE مباشرة عبر ALTER TABLE؛ يكفي العمود هنا
    // (الربط يضبطه التطبيق)، والجداول الجديدة تأخذه UNIQUE من schema.sql.
    tryAddColumn("visits", "ortho_visit_id INTEGER");
    tryAddColumn("invoices", "payment_method TEXT");
    tryAddColumn("invoices", "parent_invoice_id INTEGER REFERENCES invoices(id)");
    tryAddColumn("invoices", "original_price REAL");
    tryAddColumn("appointments", "pending_service_id INTEGER REFERENCES services(id)");
    tryAddColumn("appointments", "pending_price REAL");
    tryAddColumn("appointments", "pending_discount_percent REAL");
    tryAddColumn("appointments", "completed_without_payment INTEGER NOT NULL DEFAULT 0");
    tryAddColumn("appointments", "debt_on_completion REAL");
    // السن بقى بيتحسب من تاريخ الميلاد بالسنين بس (مش رقم سن ثابت بيقدّم). عمود
    // patients.age القديم فاضل زي ما هو لمرضى مسجلين قبل كده من غير تاريخ ميلاد —
    // شوف src/lib/age.ts لمنطق الحساب وترتيب الأولوية (birth_date لو موجود، وإلا age).
    tryAddColumn("patients", "birth_date TEXT");
    tryAddColumn("patients", "phone_country_code TEXT NOT NULL DEFAULT '+20'");
    // لغة واجهة الملف الطبي اختيار مستقل لكل مستخدم. الافتراضي English حتى تكون
    // مصطلحات الخدمات الطبية والبحث عنها متسقين للأطباء، من غير تغيير الاستقبال
    // أو الملف المالي العربي.
    tryAddColumn("users", "medical_ui_language TEXT NOT NULL DEFAULT 'en'");
    // دفعة 93: اختيار ألوان النظام محفوظ لكل حساب، ومستقل تمامًا عن وضع الليل.
    tryAddColumn("users", "color_theme TEXT NOT NULL DEFAULT 'revere'");
    // دفعة 94: الحسابات الحالية كلها اتعملت بكلمة السر الافتراضية "123"، فالقيمة
    // الابتدائية 1 للجميع. مين غيّرها فعلاً بيترجع لـ0 أول مرة يسجّل دخول
    // بكلمة سره الحقيقية — من غير ما نحتاج نعرف حالته دلوقتي.
    tryAddColumn("users", "must_change_password INTEGER NOT NULL DEFAULT 1");
    tryAddColumn("users", "session_version INTEGER NOT NULL DEFAULT 0");
    tryAddColumn("users", "contact_name TEXT");
    // دفعة 22: هل الدكتور استشاري (عنده دكاترة مساعدين معرفين تحته — شوف جدول
    // consultant_assistants في schema.sql).
    tryAddColumn("doctors", "is_consultant INTEGER NOT NULL DEFAULT 0");
    // المخزن المرن (تخصصات/أصناف فعلية/موردون). الأعمدة الجديدة تظل اختيارية
    // حتى تبقى الأصناف القديمة وخصم شارت التقويم شغالين من غير ترحيل يدوي.
    tryAddColumn("inventory_items", "product_id INTEGER REFERENCES inventory_products(id)");
    tryAddColumn("inventory_items", "supplier_id INTEGER REFERENCES inventory_suppliers(id)");
    tryAddColumn("inventory_items", "attribute_value_ids TEXT");
    tryAddColumn("inventory_items", "item_code TEXT");
    tryAddColumn("inventory_items", "ortho_usage TEXT");
    tryAddColumn("inventory_items", "reorder_quantity REAL NOT NULL DEFAULT 0");
    tryAddColumn("inventory_items", "critical_stock_threshold REAL NOT NULL DEFAULT 0");
    tryAddColumn("inventory_items", "specialty_id INTEGER REFERENCES inventory_specialties(id)");
    tryAddColumn("inventory_items", "category_id INTEGER REFERENCES inventory_categories(id)");
    tryAddColumn("inventory_items", "catalog_group TEXT");
    tryAddColumn("inventory_items", "auto_deduction_key TEXT");
    tryAddColumn("inventory_items", "auto_deduction_per_attachment REAL NOT NULL DEFAULT 0");
    tryAddColumn("inventory_items", "available_in_clinical_selection INTEGER NOT NULL DEFAULT 1");
    tryAddColumn("inventory_items", "active INTEGER NOT NULL DEFAULT 1");
    tryAddColumn("inventory_items", "is_general_consumable INTEGER NOT NULL DEFAULT 0");
    // دفعة 106: عضوية المورد في تخصص/أكثر (تقويم و/أو جينيرال) — نفس تقسيمة
    // الأصناف (specialty_name === 'تقويم' ⇔ ortho)، لكن كعلمين مستقلين على
    // المورد نفسه لأن مورد واحد ممكن يورّد للتخصصين معاً.
    tryAddColumn("inventory_suppliers", "is_ortho INTEGER NOT NULL DEFAULT 0");
    tryAddColumn("inventory_suppliers", "is_general INTEGER NOT NULL DEFAULT 0");
    tryAddColumn("inventory_supply_batches", "purchase_unit_label TEXT");
    tryAddColumn("inventory_supply_batches", "package_count REAL");
    tryAddColumn("inventory_supply_batches", "units_per_package REAL");
    tryAddColumn("ortho_visits", "upper_wire_item_id INTEGER REFERENCES inventory_items(id)");
    tryAddColumn("ortho_visits", "lower_wire_item_id INTEGER REFERENCES inventory_items(id)");
    tryAddColumn("ortho_visits", "elastic_item_id INTEGER REFERENCES inventory_items(id)");
    tryAddColumn("ortho_visits", "otie_item_id INTEGER REFERENCES inventory_items(id)");
    tryAddColumn("ortho_visits", "power_chain_item_id INTEGER REFERENCES inventory_items(id)");
    tryAddColumn("ortho_visits", "buttons_item_id INTEGER REFERENCES inventory_items(id)");
    tryAddColumn("ortho_visits", "compressed_coil_item_id INTEGER REFERENCES inventory_items(id)");
    tryAddColumn("ortho_visits", "bonding_bracket_item_id INTEGER REFERENCES inventory_items(id)");
    tryAddColumn("ortho_visits", "bonding_bracket_brand TEXT");
    tryAddColumn("ortho_visits", "bonding_tube_item_id INTEGER REFERENCES inventory_items(id)");
    tryAddColumn("ortho_visits", "seen_by_consultant INTEGER NOT NULL DEFAULT 0");
    tryAddColumn("ortho_visits", "consultant_doctor_id INTEGER REFERENCES doctors(id)");
    tryAddColumn("orthodontic_bracket_stock_movements", "movement_date TEXT");

    // دفعة 25 (تكملة شارت التقويم): تركيب التقويم (bonding) والريبوندينج —
    // أعمدة اتضافت بعد إنشاء الجدول الأول، شوف التعليق في schema.sql فوق
    // CREATE TABLE orthodontic_charts للتفاصيل الكاملة.
    tryAddColumn("orthodontic_charts", "prescription TEXT");
    tryAddColumn("orthodontic_charts", "bonding_upper_bracket_item_id INTEGER REFERENCES inventory_items(id)");
    tryAddColumn("orthodontic_charts", "bonding_upper_bracket_qty REAL");
    tryAddColumn("orthodontic_charts", "bonding_upper_tube_item_id INTEGER REFERENCES inventory_items(id)");
    tryAddColumn("orthodontic_charts", "bonding_upper_tube_qty REAL");
    tryAddColumn("orthodontic_charts", "bonding_upper_date TEXT");
    tryAddColumn("orthodontic_charts", "bonding_upper_not_bonded_teeth TEXT");
    tryAddColumn("orthodontic_charts", "bonding_lower_bracket_item_id INTEGER REFERENCES inventory_items(id)");
    tryAddColumn("orthodontic_charts", "bonding_lower_bracket_qty REAL");
    tryAddColumn("orthodontic_charts", "bonding_lower_tube_item_id INTEGER REFERENCES inventory_items(id)");
    tryAddColumn("orthodontic_charts", "bonding_lower_tube_qty REAL");
    tryAddColumn("orthodontic_charts", "bonding_lower_date TEXT");
    tryAddColumn("orthodontic_charts", "bonding_lower_not_bonded_teeth TEXT");
    tryAddColumn("orthodontic_charts", "broken_teeth TEXT");
    tryAddColumn("orthodontic_charts", "rebonding_counts TEXT");
    tryAddColumn("orthodontic_charts", "tooth_comments TEXT");

    // شارت التقويم v2 (دمج البروتوتايب مع السيستم الحقيقي، 2026-08-27): تتبع
    // حالة كل سن لوحده (bracket/extracted/تواريخ) — أدق من bonding_upper/lower_*
    // اللي بتاعة الفك ككل. tooth_states بقى مصدر الحقيقة لحالة كل سن في الشارت
    // التفاعلي؛ broken_teeth/rebonding_counts فاضلين زي ما هما (لسه مستخدمين).
    // strip_counts/miniscrews: JSON object {gapId: ...} لعلامات الـStripping
    // (عدد) والـMiniscrew (بوليان) بين كل سنين متجاورين.
    tryAddColumn("orthodontic_charts", "tooth_states TEXT");
    tryAddColumn("orthodontic_charts", "strip_counts TEXT");
    tryAddColumn("orthodontic_charts", "miniscrews TEXT");

    // شارت التقويم v2 — حقول أعلى الصفحة الجديدة اللي مالهاش نظير في الشارت
    // القديم (مفاهيم جديدة كليًا في تصميم الـv2، مش بديل لحاجة قديمة):
    // - bracket_type/slot: بجانب prescription الموجود بالفعل فوق.
    // - extraction_quadrants: الشكل الجديد لل Extraction (صليب 4 خانات
    //   UR/UL/LR/LL) — مختلف تمامًا عن extraction_choice/extraction_teeth
    //   القديمين (كانوا اختيار "extraction/non_extraction" + قايمة أسنان حرة)،
    //   فضلنا القديم زي ما هو من غير لمس وأضفنا عمود جديد لشكل الـv2.
    // - anchorage_device: نوع جهاز الـAnchorage (Mini-screw, Headgear, ...) —
    //   مفهوم مختلف عن anchorage القديم (كان "minimal/moderate/maximum" كمية
    //   مش نوع جهاز)، فضلنا القديم زي ما هو برضه وأضفنا عمود جديد.
    // - treatment_note: ملاحظة حرة تحت Treatment Plan في الـv2 — مختلفة عن
    //   hints القديم (استخدام مختلف)، فعمود جديد مستقل.
    tryAddColumn("orthodontic_charts", "bracket_type TEXT");
    tryAddColumn("orthodontic_charts", "slot TEXT");
    tryAddColumn("orthodontic_charts", "extraction_quadrants TEXT");
    tryAddColumn("orthodontic_charts", "anchorage_device TEXT");
    tryAddColumn("orthodontic_charts", "treatment_note TEXT");
    tryAddColumn("orthodontic_charts", "diagnosis_summary TEXT");

    // audit_log.event_date: تاريخ الحدث الفعلي (زي تاريخ الزيارة اللي ممكن
    // يتسجل بأثر رجعي)، مختلف عن changed_at (وقت الحفظ الفعلي في قاعدة البيانات).
    // اختياري — لو NULL، أي كود بيعرض الـaudit_log يرجع لـchanged_at بدلاً منه.
    tryAddColumn("audit_log", "event_date TEXT");

    // users.role was created with CHECK (role IN ('admin','doctor','reception','accountant')).
    // SQLite can't ALTER a CHECK constraint in place, so adding 'clinic_manager' requires a
    // table rebuild. Done once, guarded by checking sqlite_master for the old constraint text
    // — re-checked here, inside the write lock, so a second concurrent connection sees the
    // already-migrated schema and skips this block instead of racing on it.
    //
    // IMPORTANT: we build the replacement under a fresh name (users_new), copy into it, drop
    // the old "users" table, then rename the replacement into place — we never rename the
    // still-referenced "users" table away. SQLite's ALTER TABLE RENAME auto-rewrites *other*
    // tables' foreign-key definitions to point at the new name (e.g. visits.created_by
    // REFERENCES users(id) silently becomes REFERENCES "users_old"(id)), and that rewrite
    // sticks permanently even after users_old is dropped and "users" exists again — a real
    // bug we hit and verified locally with visits/audit_log/user_permissions. Renaming the
    // *new* table into place instead avoids ever touching the name other tables reference.
    const usersTableSql = sqlite
      .prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='users'")
      .get() as { sql: string } | undefined;
    if (usersTableSql && usersTableSql.sql.includes("'admin','doctor','reception','accountant'")) {
      sqlite.exec(`DROP TABLE IF EXISTS users_new;`);
      sqlite.exec(`
        CREATE TABLE users_new (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT NOT NULL UNIQUE,
          password_hash TEXT NOT NULL,
          full_name TEXT NOT NULL,
          role TEXT NOT NULL CHECK (role IN ('admin','doctor','reception','accountant','clinic_manager')),
          doctor_id INTEGER REFERENCES doctors(id),
          active INTEGER NOT NULL DEFAULT 1,
          medical_ui_language TEXT NOT NULL DEFAULT 'en' CHECK (medical_ui_language IN ('en', 'ar')),
          color_theme TEXT NOT NULL DEFAULT 'revere' CHECK (color_theme IN ('revere', 'medical')),
          contact_name TEXT,
          must_change_password INTEGER NOT NULL DEFAULT 1,
          session_version INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        INSERT INTO users_new (id, username, password_hash, full_name, role, doctor_id, active, medical_ui_language, color_theme, contact_name, must_change_password, session_version, created_at)
          SELECT id, username, password_hash, full_name, role, doctor_id, active, COALESCE(medical_ui_language, 'en'), COALESCE(color_theme, 'revere'), contact_name, COALESCE(must_change_password, 1), COALESCE(session_version, 0), created_at FROM users;
        DROP TABLE users;
        ALTER TABLE users_new RENAME TO users;
      `);
    }

    // appointments.status was created with CHECK (status IN ('booked','done','cancelled','no_show')).
    // Added 'attended' (المريض وصل ومستني) so the central schedule grid can show a check-in step
    // separate from "done" — SQLite can't ALTER a CHECK constraint in place, so this needs the
    // same guarded table-rebuild pattern as the users-table migration above. Nothing else has a
    // foreign key into appointments.id, so this rebuild is simpler (no FK-dangling risk).
    const appointmentsTableSql = sqlite
      .prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='appointments'")
      .get() as { sql: string } | undefined;
    if (appointmentsTableSql && appointmentsTableSql.sql.includes("'booked','done','cancelled','no_show'")) {
      sqlite.exec(`DROP TABLE IF EXISTS appointments_new;`);
      sqlite.exec(`
        CREATE TABLE appointments_new (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          patient_id INTEGER REFERENCES patients(id),
          room_id INTEGER NOT NULL REFERENCES rooms(id),
          doctor_id INTEGER NOT NULL REFERENCES doctors(id),
          appointment_date TEXT NOT NULL,
          start_time TEXT NOT NULL,
          duration_minutes INTEGER,
          status TEXT NOT NULL DEFAULT 'booked' CHECK (status IN ('booked','attended','done','cancelled','no_show')),
          attended_at TEXT,
          completed_at TEXT,
          confirmed_at TEXT,
          reschedule_pending INTEGER NOT NULL DEFAULT 0,
          notes TEXT,
          pending_service_id INTEGER REFERENCES services(id),
          pending_price REAL,
          pending_discount_percent REAL,
          completed_without_payment INTEGER NOT NULL DEFAULT 0,
          debt_on_completion REAL,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        INSERT INTO appointments_new (id, patient_id, room_id, doctor_id, appointment_date, start_time, duration_minutes, status, attended_at, completed_at, confirmed_at, reschedule_pending, notes, pending_service_id, pending_price, pending_discount_percent, completed_without_payment, debt_on_completion, created_at)
          SELECT id, patient_id, room_id, doctor_id, appointment_date, start_time, duration_minutes, status, attended_at, completed_at, confirmed_at, reschedule_pending, notes, pending_service_id, pending_price, pending_discount_percent, completed_without_payment, debt_on_completion, created_at FROM appointments;
        DROP TABLE appointments;
        ALTER TABLE appointments_new RENAME TO appointments;
        CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(appointment_date, room_id);
      `);
    }

    // One-time repair for databases that already went through the old (buggy) RENAME-based
    // migration above and got their FK text silently corrupted to reference "users_old".
    // Safe/no-op once repaired: each check only fires if the dangling reference is still there.
    repairDanglingUsersOldReference("visits", `
      CREATE TABLE visits_fixed (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_id INTEGER NOT NULL REFERENCES patients(id),
        visit_date TEXT NOT NULL DEFAULT (date('now')),
        service_id INTEGER REFERENCES services(id),
        notes TEXT,
        primary_doctor_id INTEGER REFERENCES doctors(id),
        performing_doctor_id INTEGER REFERENCES doctors(id),
        room_id INTEGER REFERENCES rooms(id),
        created_by INTEGER REFERENCES users(id),
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `);
    repairDanglingUsersOldReference("audit_log", `
      CREATE TABLE audit_log_fixed (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entity_type TEXT NOT NULL,
        entity_id INTEGER NOT NULL,
        field TEXT NOT NULL,
        old_value TEXT,
        new_value TEXT,
        reason TEXT,
        changed_by INTEGER REFERENCES users(id),
        changed_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `);
    repairDanglingUsersOldReference("user_permissions", `
      CREATE TABLE user_permissions_fixed (
        user_id INTEGER NOT NULL REFERENCES users(id),
        permission_key TEXT NOT NULL,
        granted INTEGER NOT NULL,
        PRIMARY KEY (user_id, permission_key)
      );
    `);

    // زرع قائمة الأسعار الحقيقية (من الإكسيل اللي رفعه الأدمن) مرة واحدة بس عند أول
    // تشغيل بعد النشر. مربوط بعلامة في clinic_settings عشان محدش يتكرر أو يتكرر
    // إدراجه لو الأدمن عدّل/مسح خدمات بنفسه بعد كده. بيتفادى تكرار الكود لو كان
    // موجود أصلاً (مثلاً لو اتزرعت قبل كده بطريقة تانية).
    const seedMarker = sqlite
      .prepare("SELECT value FROM clinic_settings WHERE key = 'services_seeded_v1'")
      .get() as { value: string } | undefined;
    if (!seedMarker) {
      const insertService = sqlite.prepare(`
        INSERT INTO services (name, name_en, category, code, default_price, price_note, prepaid)
        SELECT ?, ?, ?, ?, ?, ?, 0
        WHERE NOT EXISTS (SELECT 1 FROM services WHERE code = ?)
      `);
      for (const s of REAL_SERVICES_SEED) {
        insertService.run(s.name, s.name_en, s.category, s.code, s.price, s.priceNote, s.code);
      }
      sqlite.exec(`
        INSERT INTO clinic_settings (key, value) VALUES ('services_seeded_v1', '1')
        ON CONFLICT(key) DO UPDATE SET value = '1';
      `);
    }

    const manualTemplateCount = sqlite.prepare("SELECT COUNT(*) AS count FROM whatsapp_manual_templates").get() as { count: number };
    if (manualTemplateCount.count === 0) {
      const insertManualTemplate = sqlite.prepare(`INSERT INTO whatsapp_manual_templates
        (name, header_text, body_text, recipient_type, variable_map, quick_slot)
        VALUES (?, ?, ?, 'patient', ?, ?)`);
      insertManualTemplate.run("تأكيد الموعد", "تأكيد موعدك", "أهلًا {{1}}\nهذه الرسالة لتأكيد موعدك يوم {{2}} الساعة {{3}} مع د. {{4}}.\nبرجاء الضغط على الرابط لتأكيد الموعد أو تعديله:\n{{5}}", JSON.stringify({ 1: "patient_name", 2: "appointment_date", 3: "appointment_time", 4: "doctor_name", 5: "appointment_link" }), 1);
      insertManualTemplate.run("تذكير بالموعد", "تذكير بالموعد", "أهلًا {{1}}\nنذكرك بموعدك يوم {{2}} الساعة {{3}} مع د. {{4}}.", JSON.stringify({ 1: "patient_name", 2: "appointment_date", 3: "appointment_time", 4: "doctor_name" }), 2);
      insertManualTemplate.run("تقييم الزيارة", "رأيك يهمنا", "أهلًا {{1}}\nنتمنى أن تكون زيارتك مريحة. يسعدنا معرفة تقييمك للخدمة.", JSON.stringify({ 1: "patient_name" }), 3);
      insertManualTemplate.run("متابعة التحويل", "متابعة الحالة", "أهلًا {{1}}\nنتابع معك الإجراء المطلوب لدى د. {{4}}. برجاء التواصل معنا إذا احتجت للمساعدة.", JSON.stringify({ 1: "patient_name", 4: "doctor_name" }), 4);
      insertManualTemplate.run("تذكير مالي", "تذكير مالي", "أهلًا {{1}}\nنذكرك بأن الرصيد المتبقي على ملفك هو {{6}} ج.م. شكرًا لتعاونك.", JSON.stringify({ 1: "patient_name", 6: "patient_debt" }), 5);
    }

    // دفعة 26: "المريض جاي يعمل إيه" — لابل تحت اسم المريض في خانة الموعد بالجدول
    // المركزي. purpose_type: 'bonding_upper' (تركيب أول تقويم) / 'bonding_lower'
    // (تركيب تاني تقويم) / 'service' (أي خدمة تانية من القايمة العادية، بما فيها
    // "متابعة تقويم" الموجودة بالفعل في قايمة الخدمات — مفيش قيمة enum مخصوصة ليها).
    // purpose_service_id بيتملى بس لو purpose_type = 'service'. الاتنين اختياريين
    // (NULL = لسه محدّدش)، بيتحددوا وقت الحجز أو بعدين من نفس خانة الموعد بالجدول.
    tryAddColumn("appointments", "purpose_type TEXT");
    tryAddColumn("appointments", "purpose_service_id INTEGER REFERENCES services(id)");

    // دفعة 27 (P2.4): مزامنة تفاصيل المعالجة من شارت التقويم لحقل notes بتاع
    // الزيارة المقابلة في الملف الطبي العادي. العلم ده بيسجل إن آخر قيمة في
    // notes جاية من المزامنة التلقائية (مش كتابة يدوية من الطبيب في الملف
    // الطبي نفسه) — عشان المزامنة تقدر تحدّث/تمسح القيمة دي بأمان لو الزيارة
    // في شارت التقويم اتعدّلت أو اتمسحت، من غير ما تلمس أي نص كتبه الطبيب يدويًا.
    tryAddColumn("visits", "notes_synced_from_ortho INTEGER NOT NULL DEFAULT 0");

    // دفعة 27 (P3.2): ربط اختيار "المريض جاي يعمل إيه" بفاتورة مفتوحة فعلية —
    // لما الاستقبال يحدد إن الموعد ده "متابعة" (تقويم أو عام) لخدمة سبق فتحها
    // (من "إضافة خدمة للتحصيل")، بيتسجل هنا id الفاتورة الأصلية المفتوحة دي.
    // بيتستخدم وقت التحصيل الفعلي (بوكس الفوترة بيتعبى تلقائيًا بيها بدل ما
    // الاستقبال يتسأل تاني عن نفس الخدمة) ووقت عرض السياق للدكتور. NULL = مفيش
    // ربط (اختيار عادي أو خدمة جديدة أول مرة).
    tryAddColumn("appointments", "purpose_linked_invoice_id INTEGER REFERENCES invoices(id)");

    // شارت التقويم v2 — دفعة المراجعة التانية (2026-08-27): تدوير الصورة (0/90/180/270)
    // بيتحفظ لكل صورة على حدة عشان لو الدكتور دوّرها مايرجعش يشوفها غلط تاني مرة يفتحها.
    tryAddColumn("patient_images", "rotation INTEGER NOT NULL DEFAULT 0");

    // فصل الملف المالي عن الزيارة الطبية: كانت invoices.visit_id إجبارية، فكان
    // أي تحصيل من الاستقبال ينشئ زيارة فارغة في الملف الطبي. إعادة البناء دي
    // تحفظ كل الفواتير القديمة وتملأ حقولها المالية من الزيارة المرتبطة، ثم تجعل
    // الزيارة اختيارية للفواتير الجديدة.
    const invoiceColumns = sqlite.prepare("PRAGMA table_info(invoices)").all() as { name: string; notnull: number }[];
    const oldInvoiceVisit = invoiceColumns.find((column) => column.name === "visit_id");
    if (!invoiceColumns.some((column) => column.name === "patient_id") || oldInvoiceVisit?.notnull === 1) {
      sqlite.exec("DROP TABLE IF EXISTS invoices_finance_new;");
      sqlite.exec(`
        CREATE TABLE invoices_finance_new (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          visit_id INTEGER REFERENCES visits(id),
          patient_id INTEGER NOT NULL REFERENCES patients(id),
          doctor_id INTEGER REFERENCES doctors(id),
          appointment_id INTEGER REFERENCES appointments(id),
          service_id INTEGER REFERENCES services(id),
          invoice_date TEXT NOT NULL DEFAULT (date('now')),
          amount REAL NOT NULL DEFAULT 0,
          paid REAL NOT NULL DEFAULT 0,
          discount_percent REAL NOT NULL DEFAULT 0,
          price_overridden INTEGER NOT NULL DEFAULT 0,
          payment_method TEXT,
          parent_invoice_id INTEGER REFERENCES invoices_finance_new(id),
          original_price REAL,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        INSERT INTO invoices_finance_new (
          id, visit_id, patient_id, doctor_id, appointment_id, service_id, invoice_date,
          amount, paid, discount_percent, price_overridden, payment_method,
          parent_invoice_id, original_price, created_at
        )
        SELECT
          invoices.id, invoices.visit_id, visits.patient_id, visits.primary_doctor_id,
          visits.appointment_id, visits.service_id, visits.visit_date,
          invoices.amount, invoices.paid, invoices.discount_percent, invoices.price_overridden,
          invoices.payment_method, invoices.parent_invoice_id, invoices.original_price, invoices.created_at
        FROM invoices
        INNER JOIN visits ON visits.id = invoices.visit_id;
        DROP TABLE invoices;
        ALTER TABLE invoices_finance_new RENAME TO invoices;
      `);
    }

    sqlite.exec(`
      CREATE TABLE IF NOT EXISTS collection_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        appointment_id INTEGER NOT NULL UNIQUE REFERENCES appointments(id),
        patient_id INTEGER NOT NULL REFERENCES patients(id),
        doctor_id INTEGER NOT NULL REFERENCES doctors(id),
        service_id INTEGER REFERENCES services(id),
        requested_amount REAL,
        status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','settled','cancelled')),
        requested_by INTEGER NOT NULL REFERENCES users(id),
        requested_at TEXT NOT NULL DEFAULT (datetime('now')),
        settled_by INTEGER REFERENCES users(id),
        settled_at TEXT,
        cancelled_by INTEGER REFERENCES users(id),
        cancelled_at TEXT
      );
      CREATE TABLE IF NOT EXISTS patient_credits (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_id INTEGER NOT NULL REFERENCES patients(id),
        appointment_id INTEGER REFERENCES appointments(id),
        original_amount REAL NOT NULL CHECK (original_amount > 0),
        available_amount REAL NOT NULL CHECK (available_amount >= 0),
        payment_method TEXT,
        received_by INTEGER NOT NULL REFERENCES users(id),
        received_at TEXT NOT NULL DEFAULT (datetime('now')),
        note TEXT,
        status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','used','refunded'))
      );
      CREATE INDEX IF NOT EXISTS idx_invoices_patient_date ON invoices(patient_id, invoice_date);
      CREATE INDEX IF NOT EXISTS idx_invoices_appointment ON invoices(appointment_id);
      CREATE INDEX IF NOT EXISTS idx_collection_requests_patient_status ON collection_requests(patient_id, status);
      CREATE INDEX IF NOT EXISTS idx_patient_credits_patient_status ON patient_credits(patient_id, status);
    `);

    // خدمة "متابعة" بكود "0" — مستخدمة في بوكس الفوترة من الجدول المركزي: اختيارها بيفتح
    // قايمة بفواتير المريض السابقة اللي لسه عليها مبلغ مستحق، عشان أي دفعة تتسجل تتخصم من
    // رصيد الفاتورة الأصلية المحددة بس. زرعها هنا مستقل عن علامة services_seeded_v1 اللي
    // فوق (ممكن تكون خدت شغلها قبل ما الخدمة دي تتضاف)، ومحمي بنفسه بـ WHERE NOT EXISTS
    // عشان يصلح يتشغل أي عدد مرات.
    sqlite.exec(`
      INSERT INTO services (name, name_en, category, code, default_price, price_note, prepaid)
      SELECT 'متابعة', 'Follow-up', 'General', '0', 0, NULL, 0
      WHERE NOT EXISTS (SELECT 1 FROM services WHERE code = '0')
    `);

    // شارت التقويم v2 (دمج 2026-08-27): قوايم اختيارات ابتدائية للمقاسات/الألوان
    // (بنفس القيم اللي كانت placeholders في البروتوتايب المعزول) — الأدمن يقدر
    // يضيف/يعدّل/يمسح منها بعد كده من صفحة الإعدادات. تتزرع مرة واحدة بس، محمية
    // بعلامة زي services_seeded_v1 فوق (مش WHERE NOT EXISTS لكل قيمة، عشان لو
    // الأدمن مسح كل القيم قصدًا منقدرش نرجعها تاني بالغلط).
    const orthoListsSeedMarker = sqlite
      .prepare("SELECT value FROM clinic_settings WHERE key = 'ortho_option_lists_seeded_v1'")
      .get() as { value: string } | undefined;
    if (!orthoListsSeedMarker) {
      const insertOrthoOption = sqlite.prepare(
        `INSERT INTO ortho_option_lists (category, value, sort_order) VALUES (?, ?, ?)`
      );
      const seedLists: Record<string, string[]> = {
        wire_size: ["12", "14", "16", "16x22", "17x25", "19x25"],
        wire_type: ["NiTi", "SS", "TMA"],
        otie_color: ["Clear", "Silver", "Blue", "Red", "Green", "Yellow", "Pink", "Purple", "Orange", "Black", "White", "Gold"],
        elastic_size: ["3/16", "1/8", "5/16"],
        anchorage_device: ["Mini-screw", "Headgear", "Nance appliance", "TPA", "Lingual arch", "Class II elastics", "Class III elastics"],
      };
      for (const [category, values] of Object.entries(seedLists)) {
        values.forEach((value, idx) => insertOrthoOption.run(category, value, idx));
      }
      sqlite.exec(`
        INSERT INTO clinic_settings (key, value) VALUES ('ortho_option_lists_seeded_v1', '1')
        ON CONFLICT(key) DO UPDATE SET value = '1';
      `);
    }

    // كتالوج مخزن التقويم: خامات ومقاسات وألوان الملف المرفق. يضاف تلقائياً
    // عند أول تشغيل بعد النشر، فلا نترك إنشاءه كخطوة يدوية على المستخدم.
    seedOrthodonticInventoryCatalog(sqlite);
    // ترحيل الكومبوزيت الموجود قبل إضافة الإعداد المرن. الصفر غير صالح لهذه
    // الخامة (لا يوجد سبب لاستهلاك صفر عند تركيب سن)، لذلك يظل 30 هو الافتراضي
    // لمرة الترقية فقط؛ أي قيمة موجبة يكتبها المستخدم في المخزن تبقى كما هي.
    sqlite.prepare("UPDATE inventory_items SET auto_deduction_per_attachment = 30 WHERE auto_deduction_key = 'orthodontic_composite' AND auto_deduction_per_attachment <= 0").run();

    // دفعة 103: أول استخدام فعلي لـrunMigration() — بيسجل في schema_migrations
    // إمتى بدأ سجل الترحيلات نفسه يشتغل على قاعدة البيانات دي. أي ترحيل جديد
    // من دلوقتي (عمود جديد، إعادة بناء جدول، ...) يتلف بنفس الطريقة بدل ما
    // يتحط كـtryAddColumn سايب من غير أي أثر مسجل.
    runMigration("103_migrations_ledger_introduced", () => {
      // لا حاجة تتنفذ هنا - مجرد أول تسجيل في السجل نفسه.
    });

    runMigration("104_invoice_integrity_guards", () => {
      sqlite.exec(`
        CREATE UNIQUE INDEX IF NOT EXISTS idx_invoices_one_original_per_appointment
          ON invoices(appointment_id)
          WHERE appointment_id IS NOT NULL AND parent_invoice_id IS NULL;

        CREATE TRIGGER IF NOT EXISTS invoices_money_guard_insert
        BEFORE INSERT ON invoices
        WHEN typeof(NEW.amount) NOT IN ('integer','real')
          OR typeof(NEW.paid) NOT IN ('integer','real')
          OR NEW.amount < 0 OR NEW.amount > 1000000000
          OR NEW.paid < 0 OR NEW.paid > 1000000000
          OR NEW.discount_percent < 0 OR NEW.discount_percent > 100
        BEGIN
          SELECT RAISE(ABORT, 'invalid invoice amount');
        END;

        CREATE TRIGGER IF NOT EXISTS invoices_money_guard_update
        BEFORE UPDATE OF amount, paid, discount_percent ON invoices
        WHEN typeof(NEW.amount) NOT IN ('integer','real')
          OR typeof(NEW.paid) NOT IN ('integer','real')
          OR NEW.amount < 0 OR NEW.amount > 1000000000
          OR NEW.paid < 0 OR NEW.paid > 1000000000
          OR NEW.discount_percent < 0 OR NEW.discount_percent > 100
        BEGIN
          SELECT RAISE(ABORT, 'invalid invoice amount');
        END;
      `);
    });

    // دفعة 105: استيراد بيانات الزيارات والحركات المالية التاريخية (حتى 8-9)
    // من ملف الإكسل المدمج. الجدول ده مجرد "إيصال استلام" داخلي لسكريبت
    // الاستيراد (scripts/import-legacy-visits.mjs) — بيربط رقم الحجز/رقم
    // الحركة الأصلي من الإكسل بالصف اللي اتعمل بيه فعليًا، عشان لو السكريبت
    // اتشغل تاني (بعد وقفة أو فشل في النص) يعرف يتخطى اللي اتسجل فعلاً بدل
    // ما يكرره. مش بيتعرض في أي شاشة أو تقرير للمستخدم، وممكن يتمسح بأمان بعد
    // التأكد من نجاح الاستيراد ومطابقة الأرقام (مسحه ما بيأثرش على أي بيانات
    // في appointments/visits/invoices).
    runMigration("105_legacy_import_refs", () => {
      sqlite.exec(`
        CREATE TABLE IF NOT EXISTS import_external_refs (
          source TEXT NOT NULL,
          external_kind TEXT NOT NULL,
          external_id TEXT NOT NULL,
          entity_type TEXT NOT NULL,
          entity_id INTEGER NOT NULL,
          imported_at TEXT NOT NULL DEFAULT (datetime('now')),
          PRIMARY KEY (source, external_kind, external_id)
        );
        CREATE INDEX IF NOT EXISTS idx_import_external_refs_entity
          ON import_external_refs(entity_type, entity_id);
      `);
    });

    // دفعة 106: صفحة "الموردين" تحت المصروفات — فاتورة توريد لكل مورد
    // ودفعة قد تكون مرتبطة بفاتورة بعينها أو دفعة عامة على مديونيته الكلية
    // (invoice_id = NULL). المديونية نفسها لا تُخزَّن؛ تُحسب دائمًا SUM(فواتير)
    // - SUM(دفعات) وقت العرض، بنفس منطق "الباقي" في الفواتير حتى تبقى متسقة
    // مع أي تعديل لاحق على فاتورة أو دفعة.
    runMigration("106_supplier_invoices_payments", () => {
      sqlite.exec(`
        CREATE TABLE IF NOT EXISTS supplier_invoices (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          supplier_id INTEGER NOT NULL REFERENCES inventory_suppliers(id),
          invoice_number TEXT,
          amount REAL NOT NULL CHECK (amount > 0),
          invoice_date TEXT NOT NULL DEFAULT (date('now')),
          created_by INTEGER REFERENCES users(id),
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        CREATE INDEX IF NOT EXISTS idx_supplier_invoices_supplier ON supplier_invoices(supplier_id);

        CREATE TABLE IF NOT EXISTS supplier_payments (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          supplier_id INTEGER NOT NULL REFERENCES inventory_suppliers(id),
          invoice_id INTEGER REFERENCES supplier_invoices(id),
          amount REAL NOT NULL CHECK (amount > 0),
          payment_date TEXT NOT NULL DEFAULT (date('now')),
          created_by INTEGER REFERENCES users(id),
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          notes TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_supplier_payments_supplier ON supplier_payments(supplier_id);
        CREATE INDEX IF NOT EXISTS idx_supplier_payments_invoice ON supplier_payments(invoice_id);
      `);
    });

    // دفعة 107: التخصص بقى بيتحدد على مستوى الفاتورة (مش المورد) في حالة المورد
    // اللي شغال في التخصصين مع بعض؛ NULL يعني "خُد تخصص المورد نفسه" (مورد بتخصص
    // واحد بس). عمود جديد بسيط بدون إعادة بناء الجدول.
    runMigration("107_supplier_invoice_specialty", () => {
      tryAddColumn("supplier_invoices", "specialty TEXT");
    });

    runMigration("111_tasks_inventory_switch_tube_stock", () => {
      sqlite.exec(`
        INSERT INTO clinic_settings (key, value) VALUES ('inventory_deductions_enabled', '0')
        ON CONFLICT(key) DO UPDATE SET value = '0';

        CREATE TABLE IF NOT EXISTS tasks (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          patient_id INTEGER REFERENCES patients(id) ON DELETE CASCADE,
          created_by INTEGER NOT NULL REFERENCES users(id),
          recipient_type TEXT NOT NULL CHECK (recipient_type IN ('user','reception')),
          recipient_user_id INTEGER REFERENCES users(id),
          task_text TEXT NOT NULL,
          source_type TEXT NOT NULL DEFAULT 'manual' CHECK (source_type IN ('manual','referral')),
          referral_id INTEGER UNIQUE REFERENCES patient_referrals(id) ON DELETE CASCADE,
          status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','completed','closed')),
          completed_by INTEGER REFERENCES users(id),
          completed_at TEXT,
          closed_by INTEGER REFERENCES users(id),
          closed_at TEXT,
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          updated_at TEXT NOT NULL DEFAULT (datetime('now')),
          CHECK ((recipient_type = 'reception' AND recipient_user_id IS NULL) OR (recipient_type = 'user' AND recipient_user_id IS NOT NULL))
        );
        CREATE INDEX IF NOT EXISTS idx_tasks_recipient ON tasks(recipient_type, recipient_user_id, status, created_at);
        CREATE INDEX IF NOT EXISTS idx_tasks_creator ON tasks(created_by, status, created_at);

        CREATE TABLE IF NOT EXISTS orthodontic_tube_stock (
          fdi INTEGER PRIMARY KEY CHECK (fdi IN (16,17,26,27,36,37,46,47)),
          quantity INTEGER NOT NULL DEFAULT 0,
          updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS orthodontic_tube_stock_movements (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          fdi INTEGER NOT NULL REFERENCES orthodontic_tube_stock(fdi),
          quantity INTEGER NOT NULL,
          movement_type TEXT NOT NULL CHECK (movement_type IN ('case_purchase','refill_purchase','manual_count','ortho_use','return')),
          patient_id INTEGER REFERENCES patients(id) ON DELETE CASCADE,
          visit_id INTEGER REFERENCES ortho_visits(id) ON DELETE SET NULL,
          movement_date TEXT,
          note TEXT,
          created_by INTEGER REFERENCES users(id),
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          undone_by INTEGER REFERENCES users(id),
          undone_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_orthodontic_tube_stock_movements_patient ON orthodontic_tube_stock_movements(patient_id, fdi, created_at);
        INSERT OR IGNORE INTO orthodontic_tube_stock (fdi) VALUES (16),(17),(26),(27),(36),(37),(46),(47);

        INSERT OR IGNORE INTO inventory_categories (specialty_id, name)
        SELECT id, 'TUBES' FROM inventory_specialties WHERE name = 'تقويم' AND active = 1;

        INSERT OR IGNORE INTO tasks (patient_id, created_by, recipient_type, recipient_user_id, task_text, source_type, referral_id, created_at, updated_at)
        SELECT r.patient_id, r.created_by, 'user',
          (SELECT u.id FROM users u WHERE u.doctor_id = r.to_doctor_id AND u.active = 1 ORDER BY u.id LIMIT 1),
          r.request_text, 'referral', r.id, r.created_at, r.created_at
        FROM patient_referrals r
        WHERE r.status = 'pending'
          AND EXISTS (SELECT 1 FROM users u WHERE u.doctor_id = r.to_doctor_id AND u.active = 1);

        UPDATE notifications SET expires_at = datetime('now')
        WHERE type IN ('patient_referral','patient_referral_completed') AND expires_at > datetime('now');
      `);
    });

    sqlite.exec("COMMIT");
  } catch (err) {
    sqlite.exec("ROLLBACK");
    throw err;
  } finally {
    sqlite.pragma("foreign_keys = ON");
    // Belt-and-suspenders: confirm the rebuild above didn't actually leave any dangling
    // FK references (it shouldn't, but this is cheap and this data matters).
    const violations = sqlite.pragma("foreign_key_check");
    if (Array.isArray(violations) && violations.length > 0) {
      throw new Error(`Startup migration left dangling foreign keys: ${JSON.stringify(violations)}`);
    }
  }
}
if (!globalForDb.__clinicMigrated) {
  globalForDb.__clinicMigrated = true;
  runStartupMigrations();
}

export const db = new Kysely<DB>({
  dialect: new SqliteDialect({ database: sqlite }),
});

export const rawSqlite = sqlite;
