"use server";

import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";

// تقرير "مديونيات المرضى": نفس منطق حساب المديونية المستخدم بالظبط في صفحة
// فواتير المريض (patients/[id]/billing) — فاتورة أصلية (parent_invoice_id
// فاضي) زائد كل "دفعات المتابعة" المربوطة بيها (amount=0 دايمًا، بس بيحملوا
// paid) بيكوّنوا effectivePaid الحقيقي، والمديونية = amount - effectivePaid
// لو أكبر من صفر. بنجمع المديونية دي على مستوى المريض مش الفاتورة، ونحسب
// "أقدم مديونية" كأقدم تاريخ فاتورة أصلية لسه مديونة ليها.
//
// التخصص (تقويم/عام) مالوش عمود مباشر على الفاتورة — بنجيبه من فئة الخدمة
// المرتبطة (services.category) بنفس المنطق المستخدم في توجيه شارت التقويم
// (src/lib/appointment-purpose.ts: isOrthodonticCategory). فاتورة من غير
// خدمة مرتبطة (service_id فاضي) بتتحسب "عام" افتراضيًا.

function isOrthodonticCategory(value: string | null | undefined): boolean {
  const category = (value ?? "").trim().toLowerCase();
  return category === "orthodontics" || category === "تقويم" || category.includes("orthodont");
}

export type PatientDebtRow = {
  patientId: number;
  patientName: string;
  fileNumber: string;
  phone: string | null;
  phoneCountryCode: string;
  totalDebt: number;
  oldestInvoiceDate: string;
  doctorName: string;
  invoiceCount: number;
  whatsappUrl: string | null;
};

export type PatientDebtsResult =
  | { ok: false; error: string }
  | {
      ok: true;
      rows: PatientDebtRow[];
      page: number;
      pageSize: number;
      totalPages: number;
      // دفعة 143: null لو المستخدم مالوش صلاحية view_patient_debts_totals —
      // الإجمالي وعدد المرضى مابيتبعتوش للمتصفح أصلًا.
      totals: { totalRows: number; totalDebtSum: number } | null;
    };

const PAGE_SIZE = 50;

function buildDebtWhatsAppUrl(row: { patientName: string; phone: string | null; phoneCountryCode: string; totalDebt: number }): string | null {
  if (!row.phone) return null;
  const phone = `${row.phoneCountryCode.replace(/\D/g, "")}${row.phone.replace(/\D/g, "").replace(/^0+/, "")}`;
  if (!phone) return null;
  const message = `أهلًا ${row.patientName}\nبنذكّرك إن في مبلغ متبقي عليك في العيادة قيمته ${row.totalDebt.toFixed(0)} ج.م.\nياريت تتواصل معانا لتسوية المديونية في أقرب فرصة، شكرًا.`;
  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}

export async function getPatientDebtsReportAction(params: {
  specialty?: "all" | "ortho" | "general";
  sort?: "amount_desc" | "oldest_first";
  minDebt?: number;
  // فلتر بفترة نشأة المديونية (تاريخ الفاتورة الأصلية اللي لسه مديونة) —
  // مثلاً "مرضى مديونين من سنة 2023" = fromDate: "2023-01-01". السلاسل
  // بصيغة YYYY-MM-DD فبتتقارن نصيًا زي باقي الكود (reports-data.ts وغيره).
  fromDate?: string | null;
  toDate?: string | null;
  page?: number;
}): Promise<PatientDebtsResult> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "view_patient_debts_report"))) {
    return { ok: false, error: "مفيش صلاحية عندك لعرض تقرير مديونيات المرضى." };
  }
  const specialty = params.specialty ?? "all";
  const sort = params.sort ?? "amount_desc";
  const minDebt = Number.isFinite(params.minDebt) ? Math.max(0, params.minDebt!) : 0;
  const fromDate = params.fromDate || null;
  const toDate = params.toDate || null;
  const page = Math.max(1, Math.floor(params.page ?? 1));

  const [rootInvoices, followupInvoices] = await Promise.all([
    db
      .selectFrom("invoices")
      .leftJoin("patients", "patients.id", "invoices.patient_id")
      .leftJoin("doctors", "doctors.id", "invoices.doctor_id")
      .leftJoin("services", "services.id", "invoices.service_id")
      .select([
        "invoices.id",
        "invoices.patient_id",
        "invoices.invoice_date",
        "invoices.amount",
        "invoices.paid",
        "patients.full_name as patient_name",
        "patients.file_number",
        "patients.phone",
        "patients.phone_country_code",
        "doctors.full_name as doctor_name",
        "services.category as service_category",
      ])
      .where("invoices.parent_invoice_id", "is", null)
      .$if(!!fromDate, (qb) => qb.where("invoices.invoice_date", ">=", fromDate!))
      .$if(!!toDate, (qb) => qb.where("invoices.invoice_date", "<=", toDate!))
      .execute(),
    db.selectFrom("invoices").select(["parent_invoice_id", "paid"]).where("invoices.parent_invoice_id", "is not", null).execute(),
  ]);

  const followupPaidByParent = new Map<number, number>();
  for (const followup of followupInvoices) {
    if (followup.parent_invoice_id == null) continue;
    followupPaidByParent.set(followup.parent_invoice_id, (followupPaidByParent.get(followup.parent_invoice_id) ?? 0) + followup.paid);
  }

  type Aggregate = {
    patientId: number;
    patientName: string;
    fileNumber: string;
    phone: string | null;
    phoneCountryCode: string;
    totalDebt: number;
    oldestInvoiceDate: string;
    doctorName: string;
    invoiceCount: number;
  };
  const byPatient = new Map<number, Aggregate>();

  for (const invoice of rootInvoices) {
    if (invoice.patient_id == null) continue;
    const effectivePaid = invoice.paid + (followupPaidByParent.get(invoice.id) ?? 0);
    const balance = Math.round((invoice.amount - effectivePaid) * 100) / 100;
    if (balance <= 0.01) continue;

    const invoiceIsOrtho = isOrthodonticCategory(invoice.service_category);
    if (specialty === "ortho" && !invoiceIsOrtho) continue;
    if (specialty === "general" && invoiceIsOrtho) continue;

    const existing = byPatient.get(invoice.patient_id);
    if (!existing) {
      byPatient.set(invoice.patient_id, {
        patientId: invoice.patient_id,
        patientName: invoice.patient_name ?? "—",
        fileNumber: invoice.file_number ?? "—",
        phone: invoice.phone,
        phoneCountryCode: invoice.phone_country_code || "+20",
        totalDebt: balance,
        oldestInvoiceDate: invoice.invoice_date,
        doctorName: invoice.doctor_name || "—",
        invoiceCount: 1,
      });
    } else {
      existing.totalDebt = Math.round((existing.totalDebt + balance) * 100) / 100;
      existing.invoiceCount += 1;
      if (invoice.invoice_date < existing.oldestInvoiceDate) {
        existing.oldestInvoiceDate = invoice.invoice_date;
        existing.doctorName = invoice.doctor_name || "—";
      }
    }
  }

  const rows = [...byPatient.values()].filter((row) => row.totalDebt >= minDebt);
  const totalDebtSum = Math.round(rows.reduce((sum, row) => sum + row.totalDebt, 0) * 100) / 100;

  rows.sort((a, b) =>
    sort === "oldest_first" ? a.oldestInvoiceDate.localeCompare(b.oldestInvoiceDate) : b.totalDebt - a.totalDebt
  );

  const totalRows = rows.length;
  const totalPages = Math.max(1, Math.ceil(totalRows / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const pageRows = rows.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE).map((row) => ({
    ...row,
    whatsappUrl: buildDebtWhatsAppUrl(row),
  }));

  return {
    ok: true,
    rows: pageRows,
    page: safePage,
    pageSize: PAGE_SIZE,
    totalPages,
    totals: (await hasPermission(session.userId, session.role, "view_patient_debts_totals")) ? { totalRows, totalDebtSum } : null,
  };
}
