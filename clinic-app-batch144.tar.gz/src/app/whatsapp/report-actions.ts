"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getAllSettings, setSetting } from "@/lib/settings";
import { getClinicToday } from "@/lib/clinic-date";
import { getActiveOrthoStops, isOrthoService } from "@/lib/ortho-treatment-stops";

const validDate = (value: string) => /^\d{4}-\d{2}-\d{2}$/.test(value);
const offset = (date: string, days: number) => { const [y,m,d] = date.split("-").map(Number); return new Date(Date.UTC(y,m-1,d+days)).toISOString().slice(0,10); };
const daysBetween = (from: string, to: string) => Math.floor((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86400000);

export async function getWhatsAppOperationalReportAction(type: "appointments" | "ortho" | "referrals" | "unpaid", from: string, to: string) {
  const session = await getSession();
  if (!session || !validDate(from) || !validDate(to)) return { ok: false as const, error: "بيانات غير صحيحة", rows: [] };
  if (type === "appointments") {
    if (!(await hasPermission(session.userId, session.role, "view_whatsapp_reminder_report"))) return { ok: false as const, error: "غير مصرح", rows: [] };
    const [appointments, reminders] = await Promise.all([
      db.selectFrom("appointments").innerJoin("patients", "patients.id", "appointments.patient_id").innerJoin("doctors", "doctors.id", "appointments.doctor_id").select(["appointments.id", "appointments.appointment_date as date", "appointments.start_time as time", "appointments.confirmed_at", "appointments.reschedule_pending", "patients.full_name as patientName", "doctors.full_name as doctorName"]).where("appointments.appointment_date", ">=", from).where("appointments.appointment_date", "<=", to).where("appointments.status", "=", "booked").orderBy("appointments.appointment_date").orderBy("appointments.start_time").execute(),
      db.selectFrom("appointment_reminders").select(["id", "appointment_id", "response_status", "sent_at", "requested_date", "requested_time"]).where("appointment_date", ">=", from).where("appointment_date", "<=", to).orderBy("id", "desc").execute(),
    ]);
    const latestReminder = new Map<number, typeof reminders[number]>();
    for (const reminder of reminders) if (!latestReminder.has(reminder.appointment_id)) latestReminder.set(reminder.appointment_id, reminder);
    const rows = appointments.map((appointment) => {
      const reminder = latestReminder.get(appointment.id);
      const status = appointment.confirmed_at || reminder?.response_status === "confirmed" || reminder?.response_status === "reschedule_approved"
        ? "confirmed"
        : appointment.reschedule_pending === 1 || reminder?.response_status === "reschedule_pending"
          ? "reschedule_pending"
          : reminder?.response_status === "send_failed"
            ? "send_failed"
            : reminder?.sent_at
              ? "no_response"
              : "not_sent";
      return { id: appointment.id, patientName: appointment.patientName, doctorName: appointment.doctorName, date: appointment.date, time: appointment.time, status, requestedDate: reminder?.requested_date ?? null, requestedTime: reminder?.requested_time ?? null };
    });
    return { ok: true as const, type, rows };
  }
  if (type === "ortho") {
    if (!(await hasPermission(session.userId, session.role, "view_ortho_late_report"))) return { ok: false as const, error: "غير مصرح", rows: [] };
    const settings = await getAllSettings();
    const first = Number(settings.ortho_followup_first_days) || 45;
    const second = Number(settings.ortho_followup_second_days) || 90;
    const report = await buildOrthoFollowupReport(first, second);
    // دفعة 143: الأعداد مابتتبعتش للمتصفح أصلًا من غير صلاحية الإجماليات.
    const canTotals = await hasPermission(session.userId, session.role, "view_ortho_late_totals");
    return { ok: true as const, type, thresholds: report.thresholds, rows: report.rows, totals: canTotals ? report.totals : null };
  }
  if (type === "referrals") {
    if (!(await hasPermission(session.userId, session.role, "view_referrals_report"))) return { ok: false as const, error: "غير مصرح", rows: [] };
    const rows = await db.selectFrom("patient_referrals").innerJoin("patients", "patients.id", "patient_referrals.patient_id").innerJoin("doctors as from_doctor", "from_doctor.id", "patient_referrals.from_doctor_id").innerJoin("doctors as to_doctor", "to_doctor.id", "patient_referrals.to_doctor_id").select(["patient_referrals.id", "patient_referrals.patient_id as patientId", "patients.full_name as patientName", "from_doctor.full_name as fromDoctor", "to_doctor.full_name as toDoctor", "patient_referrals.request_text as requestText", "patient_referrals.status", "patient_referrals.created_at as date"]).where("patient_referrals.created_at", ">=", `${from} 00:00:00`).where("patient_referrals.created_at", "<=", `${to} 23:59:59`).orderBy("patient_referrals.created_at", "desc").execute();
    return { ok: true as const, type, rows };
  }
  if (!(await hasPermission(session.userId, session.role, "view_unpaid_report"))) return { ok: false as const, error: "غير مصرح", rows: [] };
  const rows = await db.selectFrom("appointments").innerJoin("patients", "patients.id", "appointments.patient_id").innerJoin("doctors", "doctors.id", "appointments.doctor_id").select(["appointments.id", "appointments.patient_id as patientId", "patients.full_name as patientName", "doctors.full_name as doctorName", "appointments.appointment_date as date", "appointments.debt_on_completion as debt"]).where("appointments.completed_without_payment", "=", 1).where("appointments.appointment_date", ">=", from).where("appointments.appointment_date", "<=", to).orderBy("appointments.appointment_date", "desc").execute();
  const canTotals = await hasPermission(session.userId, session.role, "view_unpaid_totals");
  const unpaidTotals = canTotals ? { count: rows.length, debt: Math.round(rows.reduce((sum, row) => sum + Number(row.debt || 0), 0)) } : null;
  return { ok: true as const, type, rows, unpaidTotals };
}

export async function saveOrthoFollowupThresholdsAction(first: number, second: number) {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "configure_followup_thresholds"))) return { ok: false, error: "غير مصرح" };
  const safeFirst = Math.max(1, Math.min(365, Math.round(first)));
  const safeSecond = Math.max(safeFirst + 1, Math.min(730, Math.round(second)));
  await Promise.all([setSetting("ortho_followup_first_days", String(safeFirst)), setSetting("ortho_followup_second_days", String(safeSecond))]);
  revalidatePath("/reports");
  return { ok: true };
}

export async function reportPresetDatesAction(preset: "tomorrow" | "week" | "month") {
  const today = getClinicToday();
  const from = offset(today, 1);
  return { from, to: preset === "tomorrow" ? from : offset(today, preset === "week" ? 7 : 30) };
}

// دفعة 142 — "متابعة تقويم متأخرة".
// قبل كده "آخر زيارة" كانت آخر صف في ortho_visits (متابعات شارت التقويم) بس.
// بيانات السيستم القديم وأغلب التحصيل اليومي بيتسجلوا "متابعة" في الملف المالي
// أو زيارة طبية أو موعد تم — فمريض جه في 2026 كان بيظهر متأخر من 2023.
// دلوقتي آخر حضور = أحدث تاريخ من أي مصدر من دول:
//   زيارة تقويم (ortho_visits) / زيارة طبية (visits) / فاتورة أو دفعة (invoices)
//   / موعد حالته حضر أو تم (appointments).
// ومرضى التقويم اللي خلّصوا مش بيظهروا — دول مش متأخرين، دول خلّصوا علاجهم:
//   - الشارت مفيهوش ولا سنة متركّبة وفيه فك مسجّل، أو
//   - عنده فاتورة بخدمة متعلّم عليها "انتهاء تقويم" (إعدادات الخدمات) ومفيش
//     بعدها فاتورة تقويم جديدة (مريض رجع يعمل تقويم تاني = فاتورة جديدة بتاريخ أحدث).
type OrthoSource = "ortho" | "visit" | "invoice" | "appointment";
const ORTHO_SOURCE_LABELS: Record<OrthoSource, string> = { ortho: "زيارة تقويم", visit: "زيارة طبية", invoice: "دفعة/فاتورة", appointment: "موعد" };

function orthoTreatmentFinished(raw: string | null | undefined): boolean {
  if (!raw) return false;
  try {
    const states = Object.values(JSON.parse(raw) as Record<string, { bracket?: string; debondDate?: string | null }>);
    return !states.some((s) => s?.bracket === "bonded") && states.some((s) => !!s?.debondDate);
  } catch {
    return false;
  }
}


async function buildOrthoFollowupReport(first: number, second: number) {
  const today = getClinicToday();
  const [orthoVisits, charts, medical, invoices, appointments, serviceInvoices, stops] = await Promise.all([
    db.selectFrom("ortho_visits").innerJoin("patients", "patients.id", "ortho_visits.patient_id").leftJoin("doctors", "doctors.id", "ortho_visits.doctor_id")
      .select(["ortho_visits.patient_id", "ortho_visits.visit_date", "patients.full_name as patient_name", "patients.file_number", "doctors.full_name as doctor_name"])
      .orderBy("ortho_visits.visit_date", "desc").execute(),
    db.selectFrom("orthodontic_charts").select(["patient_id", "tooth_states"]).execute(),
    db.selectFrom("visits").select(["patient_id", (eb) => eb.fn.max("visit_date").as("last")]).groupBy("patient_id").execute(),
    db.selectFrom("invoices").select(["patient_id", (eb) => eb.fn.max("invoice_date").as("last")]).groupBy("patient_id").execute(),
    db.selectFrom("appointments").select(["patient_id", (eb) => eb.fn.max("appointment_date").as("last")]).where("status", "in", ["attended", "done"]).groupBy("patient_id").execute(),
    db.selectFrom("invoices").innerJoin("services", "services.id", "invoices.service_id")
      .select(["invoices.patient_id", "invoices.invoice_date", "services.ends_ortho", "services.category", "services.name", "services.code"])
      .where("invoices.parent_invoice_id", "is", null)
      .execute(),
    // دفعة 144: الموقوف علاجهم (والإيقاف لسه فعّال) مابيظهروش في المتأخرين.
    getActiveOrthoStops(),
  ]);

  const latestOrtho = new Map<number, typeof orthoVisits[number]>();
  for (const visit of orthoVisits) if (!latestOrtho.has(visit.patient_id)) latestOrtho.set(visit.patient_id, visit);
  const finished = new Set(charts.filter((c) => orthoTreatmentFinished(c.tooth_states)).map((c) => c.patient_id));
  const lastEnd = new Map<number, string>(), lastStart = new Map<number, string>();
  const keepMax = (map: Map<number, string>, id: number, date: string) => { if (!map.has(id) || date > map.get(id)!) map.set(id, date); };
  for (const inv of serviceInvoices) {
    if (inv.patient_id == null) continue;
    const date = String(inv.invoice_date).slice(0, 10);
    if (inv.ends_ortho === 1) keepMax(lastEnd, inv.patient_id, date);
    else if (inv.code !== "0" && isOrthoService(inv.category, inv.name)) keepMax(lastStart, inv.patient_id, date);
  }
  for (const [patientId, end] of lastEnd) {
    const start = lastStart.get(patientId);
    if (!start || start <= end) finished.add(patientId);
  }
  const lastBy = (rows: { patient_id: number | null; last: string | null }[]) => new Map(rows.filter((r) => r.patient_id != null).map((r) => [r.patient_id as number, r.last ? String(r.last).slice(0, 10) : null]));
  const medicalLast = lastBy(medical), invoiceLast = lastBy(invoices), appointmentLast = lastBy(appointments);

  let finishedCount = 0;
  let stoppedCount = 0;
  const rows: { patientId: number; patientName: string; fileNumber: string; doctorName: string; date: string; source: string; days: number; stage: string; stageKey: "first" | "second" }[] = [];
  for (const [patientId, visit] of latestOrtho) {
    if (finished.has(patientId)) { finishedCount++; continue; }
    if (stops.has(patientId)) { stoppedCount++; continue; }
    const candidates: [string | null | undefined, OrthoSource][] = [
      [visit.visit_date, "ortho"], [medicalLast.get(patientId), "visit"], [invoiceLast.get(patientId), "invoice"], [appointmentLast.get(patientId), "appointment"],
    ];
    let best: [string, OrthoSource] = [visit.visit_date, "ortho"];
    for (const [date, source] of candidates) if (date && date <= today && date > best[0]) best = [date, source];
    const days = daysBetween(best[0], today);
    if (days < first) continue;
    const stageKey = days >= second ? "second" as const : "first" as const;
    rows.push({
      patientId, patientName: visit.patient_name, fileNumber: visit.file_number, doctorName: visit.doctor_name || "—",
      date: best[0], source: ORTHO_SOURCE_LABELS[best[1]], days, stageKey,
      stage: stageKey === "second" ? `${second} يوم أو أكثر` : `${first} يوم أو أكثر`,
    });
  }
  rows.sort((a, b) => b.days - a.days);
  return {
    thresholds: { first, second },
    rows,
    totals: {
      total: rows.length,
      firstStage: rows.filter((r) => r.stageKey === "first").length,
      secondStage: rows.filter((r) => r.stageKey === "second").length,
      finished: finishedCount,
      stopped: stoppedCount,
    },
  };
}
