"use client";

import { useState, useTransition } from "react";
import { confirmPublicAppointmentAction, listPublicAppointmentSlotsAction, reservePublicAppointmentAction } from "@/app/appointment/manage/[token]/actions";

type Day = { date: string; slots: { time: string; roomId: number; available: boolean }[] };
type SelectedSlot = { date: string; time: string; roomId: number };
export default function AppointmentManageClient({ token, doctorName }: { token: string; doctorName: string }) {
  const [mode, setMode] = useState<"choice" | "slots" | "done">("choice");
  const [message, setMessage] = useState("");
  const [days, setDays] = useState<Day[]>([]);
  const [selectedSlot, setSelectedSlot] = useState<SelectedSlot | null>(null);
  const [busy, startTransition] = useTransition();
  const finish = (text: string) => { setMessage(text); setMode("done"); };
  if (mode === "done") return <div className="rounded-xl bg-emerald-50 p-5 text-center text-emerald-800">{message}</div>;
  if (mode === "choice") return <div className="space-y-4">
    <button disabled={busy} onClick={() => startTransition(async () => { const result = await confirmPublicAppointmentAction(token); if (result.ok) finish("تم تأكيد موعدك. شكرًا لك."); else setMessage(result.error || "تعذر التأكيد."); })} className="w-full rounded-xl bg-emerald-700 px-5 py-4 font-semibold text-white">تأكيد الموعد</button>
    <button disabled={busy} onClick={() => startTransition(async () => { const result = await listPublicAppointmentSlotsAction(token); if (!result.ok) return setMessage(result.error || "تعذر تحميل المواعيد."); setDays(result.days); setMode("slots"); })} className="w-full rounded-xl border border-primary px-5 py-4 font-semibold text-primary">تعديل الموعد</button>
    {message && <p className="text-center text-sm text-red-700">{message}</p>}
  </div>;
  const confirmChange = () => {
    if (!selectedSlot) return;
    const slot = selectedSlot;
    setSelectedSlot(null);
    startTransition(async () => {
      const result = await reservePublicAppointmentAction(token, slot.date, slot.time, slot.roomId);
      if (result.ok) finish("تم حجز الموعد الجديد لك. برجاء التأكد من تفاصيل الموعد.");
      else setMessage(result.error || "تعذر حجز الموعد.");
    });
  };
  return <div className="space-y-4">
    <div className="rounded-lg bg-amber-50 p-3 text-sm text-amber-900">برجاء التأكد من الموعد قبل التأكيد. عند الاختيار سيتم حجز الموعد الجديد لك ولن يأخذه مريض آخر.</div>
    {!days.length && <p className="text-center text-muted">لا توجد مواعيد متاحة ضمن شيفتات الطبيب خلال الشهر القادم.</p>}
    <div className="max-h-[60vh] space-y-4 overflow-y-auto">{days.map((day) => <section key={day.date}><h3 className="mb-2 font-semibold">{day.date}</h3><div className="grid grid-cols-3 gap-2 sm:grid-cols-5">{day.slots.map((slot, index) => <button key={`${slot.roomId}-${slot.time}-${index}`} disabled={!slot.available || busy} onClick={() => setSelectedSlot({ date: day.date, time: slot.time, roomId: slot.roomId })} className={`rounded-md px-2 py-2 text-sm ${slot.available ? "bg-emerald-100 text-emerald-900 hover:bg-emerald-200" : "cursor-not-allowed bg-slate-100 text-slate-400 line-through"}`}>{slot.time}</button>)}</div></section>)}</div>
    {message && <p className="text-center text-sm text-red-700">{message}</p>}
    {selectedSlot && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 p-4" role="dialog" aria-modal="true"><div className="w-full max-w-md rounded-2xl bg-white p-5 text-center shadow-2xl"><h3 className="text-lg font-bold">تأكيد تغيير الموعد</h3><p className="mt-3 text-sm text-slate-700">هل ترغب في تغيير موعدك إلى يوم <strong>{selectedSlot.date}</strong> الساعة <strong>{selectedSlot.time}</strong> مع د. <strong>{doctorName}</strong>؟</p><div className="mt-5 grid grid-cols-2 gap-3"><button type="button" disabled={busy} onClick={confirmChange} className="rounded-lg bg-emerald-700 px-4 py-3 font-semibold text-white">تأكيد التغيير</button><button type="button" disabled={busy} onClick={() => setSelectedSlot(null)} className="rounded-lg border border-slate-300 px-4 py-3 font-semibold text-slate-700">تراجع</button></div></div></div>}
  </div>;
}
