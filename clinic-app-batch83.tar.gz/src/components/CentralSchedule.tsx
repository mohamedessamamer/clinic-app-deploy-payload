"use client";

import { useEffect, useLayoutEffect, useMemo, useRef, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { addAppointmentAction, updateAppointmentStatusAction, setAppointmentPurposeAction } from "@/app/appointments/actions";
import {
  getPatientBillableInvoicesAction,
  getBookedSlotsForRoomDateAction,
  getLastAppointmentTimeAction,
  recordAppointmentBillingAction,
  recordPendingBillingAction,
  markAppointmentDoneWithoutPaymentAction,
  getPatientOpenServicesForPurposeAction,
  type PurposeOpenService,
} from "@/app/appointments/billing-actions";
import { addPatientServiceAction } from "@/app/patients/[id]/billing/actions";
import { PAYMENT_METHODS } from "@/lib/payment-methods";
import { getClinicToday } from "@/lib/clinic-date";
import ServiceCombobox from "@/components/ServiceCombobox";
import { missingPatientDetails, PATIENT_MISSING_FIELD_LABELS } from "@/lib/patient-details";
import { isOrthodonticAppointmentPurpose } from "@/lib/appointment-purpose";
import ReferralModal from "@/components/ReferralModal";
import { createManualWhatsappConfirmationAction } from "@/app/appointment-reminders/actions";
import { approveAppointmentRescheduleByAppointmentAction } from "@/app/appointment-reminders/report-actions";
import { listManualTemplatesAction, prepareManualTemplateForAppointmentAction } from "@/app/whatsapp/actions";
import { navigateWhatsAppWindow, reserveWhatsAppWindow } from "@/lib/whatsapp/client-url";

type Room = { id: number; name: string };
type Patient = {
  id: number;
  full_name: string;
  file_number: string;
  birth_date?: string | null;
  phone?: string | null;
  needs_new_photos?: boolean;
  needs_consultant_visit?: boolean;
  consultant_name?: string | null;
};
type Doctor = { id: number; full_name: string };
type Service = { id: number; name: string; code: string | null; default_price: number };
type BillableInvoice = { id: number; service_name: string; visit_date: string; balance: number };
type Appt = {
  id: number;
  patient_id: number;
  patient_name: string;
  doctor_id: number;
  doctor_name: string;
  room_id: number;
  start_time: string;
  duration_minutes: number | null;
  status: "booked" | "attended" | "done" | "cancelled" | "no_show";
  notes: string | null;
  // true لو الموعد "تم" بس لسه ملوش فاتورة/زيارة مسجلة (حصل "تم" من غير بوكس تحصيل —
  // إما لأن اللي حددها معهوش صلاحية تحصيل المدفوعات، أو دوس "تخطي"). بيستخدم عشان
  // الاستقبال يقدر يفتح بوكس التحصيل لاحقًا لموعد "تم" أصلاً من غير رجوعه لحالة تانية.
  needs_billing?: boolean;
  // لو اللي حدد "تم" معهوش صلاحية تحصيل المدفوعات (زي الدكتور)، بيقدر يحدد هنا الخدمة
  // والسعر المتوقع "المطلوب دفعه" من غير ما يسجل دفع فعلي — بتظهر جنب "محتاج تحصيل"
  // في الجدول عشان الاستقبال يشوفها على طول، وبتتملى تلقائي في بوكس التحصيل بتاعه.
  pending_service_id?: number | null;
  pending_service_name?: string | null;
  pending_price?: number | null;
  pending_discount_percent?: number | null;
  // لو الطلب صدر في زيارة سابقة، يبقى التنبيه ظاهرًا على الموعد الجديد لكن
  // التحصيل يظل مرتبطًا بالزيارة الأصلية التي أنشأ فيها الطبيب الطلب.
  collection_request_appointment_id?: number | null;
  // true لو المريض بيعمل متابعة (خدمة كودها "0") ومفيش صور/أشعة اتسجلت له من
  // أكتر من 6 شهور (أو مالوش صور خالص) — تنبيه بصري بس، مش بيمنع أي إجراء.
  needs_new_photos?: boolean;
  needs_consultant_visit?: boolean;
  consultant_name?: string | null;
  // "المريض جاي يعمل إيه" (دفعة 26) — لابل تحت اسم المريض، تتحدد وقت الحجز أو
  // بعدين من قايمة الزر اليمين على الخانة. bonding_upper/bonding_lower = تركيب
  // أول/تاني تقويم (بيودّي لشارت التقويم مباشرة لمين معاه صلاحية تعديل الملف
  // الطبي)، service = أي خدمة عادية تانية من القايمة (بما فيها "متابعة تقويم"
  // الموجودة أصلاً في قايمة الخدمات — مفيش نوع مخصوص ليها).
  purpose_type?: "bonding_upper" | "bonding_lower" | "service" | null;
  purpose_service_id?: number | null;
  purpose_service_name?: string | null;
  // الاسم الإنجليزي اختياري؛ يظهر للطبيب في الجدول فقط، بينما يظل الاسم العربي
  // هو المعروض للاستقبال والحسابات. لا يدخل الاسم في أي ربط أو مزامنة.
  purpose_service_name_en?: string | null;
  purpose_service_category?: string | null;
  purpose_linked_service_category?: string | null;
  // دفعة 27 (P3.2): لو الغرض ده اتربط بفاتورة مفتوحة فعلية (متابعة/تركيب تقويم
  // لخدمة سبق فتحها) — بيستخدم لتعبئة بوكس التحصيل تلقائيًا (onMarkDone) ولعرض
  // سياق "متابعة: <اسم الخدمة>" للدكتور.
  purpose_linked_invoice_id?: number | null;
  // دفعة 27 (P2.4): موعد "تم" ولسه الدكتور مدخلش معالجة (لا زيارة بملاحظة في
  // الملف الطبي ولا متابعة في شارت التقويم) — عكس needs_billing تمامًا (ده
  // للدكتور مش للاستقبال). بيوصل من السيرفر بـ false دايمًا لمين معهوش صلاحية
  // view_needs_treatment_reminder (مش مجرد إخفاء في الواجهة).
  needs_treatment?: boolean;
  reschedule_pending?: number;
  confirmed_at?: string | null;
};

const PURPOSE_LABELS: Record<"bonding_upper" | "bonding_lower", string> = {
  bonding_upper: "تركيب أول تقويم",
  bonding_lower: "تركيب تاني تقويم",
};

const isConfirmationTemplateName = (name: string) => /تأكيد.*موعد|موعد.*تأكيد/.test(name);

function purposeLabelOf(appt: Appt, preferEnglish = false): string | null {
  if (appt.purpose_type === "bonding_upper" || appt.purpose_type === "bonding_lower") return PURPOSE_LABELS[appt.purpose_type];
  if (appt.purpose_type === "service") {
    return (preferEnglish ? appt.purpose_service_name_en : null) ?? appt.purpose_service_name ?? null;
  }
  return null;
}

function isOrthoAppt(appt: Appt): boolean {
  return isOrthodonticAppointmentPurpose(appt);
}

// وجهة الدوسة على لابل "المريض جاي يعمل إيه": من أكونت الطبيب بتوديك لملف
// العلاج المناسب (شارت التقويم لو المريض ده مريض تقويم بأي شكل من الأشكال
// فوق، الملف الطبي العام لأي حاجة تانية) — من أي أكونت تاني (استقبال/محاسب/
// أدمن...) بتوديك للملف المالي دايمًا.
function purposeHrefOf(appt: Appt, isDoctorView: boolean): string {
  if (!isDoctorView) return `/patients/${appt.patient_id}/billing`;
  if (isOrthoAppt(appt)) return `/patients/${appt.patient_id}/orthodontics`;
  return `/patients/${appt.patient_id}`;
}

// تفاصيل الطلب التي كتبها الطبيب تظهر كما هي، من غير اختراع سعر خدمة عندما
// يختار الطبيب الخدمة فقط. الاستقبال تكمل الخدمة/المبلغ الفعلي عند التحصيل.
function requestedCollectionLabel(appt: Appt): string {
  // شاشة المواعيد تشغيلية وليست مالية: نعرض الخدمة المطلوبة فقط، بينما يبقى
  // المبلغ داخل نافذة التحصيل للموظف المخوّل.
  if (appt.pending_service_name) return `— ${appt.pending_service_name}`;
  return "— افتح الطلب لإتمام التحصيل";
}

const STATUS_LABELS: Record<Appt["status"], string> = {
  booked: "محجوز",
  attended: "حضر",
  done: "تم",
  cancelled: "ملغي",
  no_show: "لم يحضر",
};

function statusClasses(status: Appt["status"]): string {
  switch (status) {
    case "booked":
      return "bg-sky-100 text-sky-900 border-sky-300";
    case "attended":
      return "bg-amber-100 text-amber-900 border-amber-300";
    case "done":
      return "bg-emerald-100 text-emerald-900 border-emerald-300";
    case "no_show":
      return "bg-danger-soft text-danger border-danger/40";
    default:
      return "bg-background text-foreground border-border";
  }
}

type CellPlan = { kind: "empty" } | { kind: "skip" } | { kind: "start"; appt: Appt; span: number };

export default function CentralSchedule({
  date,
  rooms,
  timeSlots,
  slotMinutes,
  appointments,
  patients,
  doctors,
  services = [],
  canEdit = true,
  canMarkDone = false,
  canCollectPayments = false,
  canEditAssistantDoctor = false,
  isDoctorView = false,
  showReceptionAlerts = false,
  roomShiftDoctorIds = {},
  canQuickAddService = false,
  canBackdateInvoice = false,
  showPatientSearch = false,
  showStatusSummary = true,
}: {
  date: string;
  rooms: Room[];
  timeSlots: string[];
  slotMinutes: number;
  appointments: Appt[];
  patients: Patient[];
  doctors: Doctor[];
  services?: Service[];
  // لو false، الجدول بيبقى عرض بس — من غير حجز خانة فاضية أو تغيير حالة موعد
  // بالزر اليمين (حسب صلاحية "schedule_edit"). التزامن التلقائي بيفضل شغال زي ما هو.
  canEdit?: boolean;
  // صلاحية مستقلة عن تعديل الجدول والتحصيل: تسمح للطبيب بإنهاء موعده اليوم فقط.
  canMarkDone?: boolean;
  // صلاحية التحصيل مستقلة عن حالة "تم"؛ تستخدم فقط في شاشة تسجيل المدفوعات.
  canCollectPayments?: boolean;
  // دفعة 22: إظهار حقل "الطبيب المساعد" الاختياري جوه بوكس التحصيل — نفس صلاحية
  // سجل الزيارات بالملف الطبي (edit_visit_assistant_doctor أو override_visit_doctor).
  canEditAssistantDoctor?: boolean;
  // بيحدد وجهة الضغط على اسم المريض في خانة الجدول: من أكونت الطبيب (true) بيفتح
  // الملف الطبي للمريض، ومن أي أكونت تاني (استقبال/محاسب/أدمن...) بيفتح ملفه المالي.
  isDoctorView?: boolean;
  // تنبيه التحصيل خاص بالاستقبال، بينما الصور والاستشاري يظهران أيضًا للطبيب.
  showReceptionAlerts?: boolean;
  // خريطة غرفة → دكتور صاحب الشيفت فيها النهاردة (حسب doctor_weekly_shifts). بتتحدد
  // كـ"الخيار الأول" (المحدد افتراضيًا) في قايمة اختيار الدكتور وقت الحجز — والتحصيل
  // بعد كده بيوَرّث نفس الدكتور ده أوتوماتيك من غير ما يحتاج اختيار تاني، إلا لو حد
  // غيّره وقت الحجز نفسه لحالة مريض جاي فجأة لدكتور تاني (زي ما اتفقنا).
  roomShiftDoctorIds?: Record<number, number>;
  // دفعة 27 (P3.1): كليك يمين على اسم المريض في الخانة بيفتح بوكس "إضافة خدمة
  // للتحصيل" السريع (بديل الدخول من الملف المالي كل مرة) — نفس صلاحية
  // view_patient_billing اللي بتتحكم في صفحة الملف المالي نفسها.
  canQuickAddService?: boolean;
  // تسجيل خدمة بتاريخ غير النهاردة من نفس البوكس ده — نفس صلاحية
  // edit_invoice_payments المستخدمة في الملف المالي (AddPatientServiceForm).
  canBackdateInvoice?: boolean;
  showPatientSearch?: boolean;
  showStatusSummary?: boolean;
}) {
  const router = useRouter();
  const [, startTransition] = useTransition();
  const [contextMenu, setContextMenu] = useState<{
    apptId: number;
    x: number;
    y: number;
    patientName: string;
    status: Appt["status"];
    needsBilling: boolean;
  } | null>(null);
  const [whatsappMenuOpen, setWhatsappMenuOpen] = useState(false);
  const [referralModal, setReferralModal] = useState<{ appointmentId: number; patientName: string; doctorId: number } | null>(null);
  const [bookingModal, setBookingModal] = useState<{ roomId: number; roomName: string; startTime: string } | null>(null);
  // بحث المريض جوه بوكس الحجز — نفس فكرة البحث الفوري اللي فوق الجدول، بس بيرجع
  // بالمريض المختار كـ patient_id مخفي بدل select عادي طويل.
  const [bookingPatientSearch, setBookingPatientSearch] = useState("");
  const [bookingSelectedPatient, setBookingSelectedPatient] = useState<Patient | null>(null);
  // "المريض جاي يعمل إيه؟" (اختياري) جوه بوكس الحجز نفسه — نفس الحقول بتتبعت مع
  // فورم الحجز العادي لـ addAppointmentAction. purposeType فاضي = بدون تحديد.
  const [bookingPurposeType, setBookingPurposeType] = useState<"" | "bonding_upper" | "bonding_lower" | "service">("");
  const [bookingPurposeServiceId, setBookingPurposeServiceId] = useState("");

  // قايمة تعديل "المريض جاي يعمل إيه؟" لموعد موجود بالفعل — بتتفتح من عنصر جديد
  // جوه قايمة الزر اليمين على الخانة، متاحة في أي وقت (وقت الحجز أو بعده) زي ما
  // المستخدم طلب. بتتملى بالقيمة الحالية للموعد لما تتفتح.
  const [purposeModal, setPurposeModal] = useState<{ apptId: number; patientName: string; patientId: number } | null>(null);
  const [purposeModalType, setPurposeModalType] = useState<"" | "bonding_upper" | "bonding_lower" | "service">("");
  const [purposeModalServiceId, setPurposeModalServiceId] = useState("");
  const [purposeModalPending, startPurposeModalTransition] = useTransition();

  // دفعة 27 (P3.2): طبقة "الربط بخدمة مفتوحة" فوق قائمة "المريض جاي يعمل إيه؟"
  // الموجودة أصلاً (فوق) — مشتركة بين بوكس الحجز وبوكس تعديل موعد موجود، لأن
  // الاتنين مايتفتحوش مع بعض أبدًا. purposeQuickCategory بيحدد أي زرار سريع
  // متفعّل دلوقتي، وpurposeLinkedInvoiceId هو الفاتورة المفتوحة المختارة
  // (لو موجودة) اللي هتتسجل في appointments.purpose_linked_invoice_id.
  const [purposeQuickCategory, setPurposeQuickCategory] = useState<"" | "ortho" | "general" | "search">("");
  const [purposeLinkedInvoiceId, setPurposeLinkedInvoiceId] = useState("");
  const [purposeOpenServices, setPurposeOpenServices] = useState<PurposeOpenService[] | null>(null);
  const [loadingPurposeOpenServices, setLoadingPurposeOpenServices] = useState(false);

  function openPurposeModal(appt: Appt) {
    setContextMenu(null);
    const type = appt.purpose_type === "bonding_upper" || appt.purpose_type === "bonding_lower" ? appt.purpose_type : appt.purpose_type === "service" ? "service" : "";
    setPurposeModalType(type);
    setPurposeModalServiceId(appt.purpose_service_id ? String(appt.purpose_service_id) : "");
    setPurposeLinkedInvoiceId(appt.purpose_linked_invoice_id ? String(appt.purpose_linked_invoice_id) : "");
    setPurposeOpenServices(null);
    // دفعة 27 (P3.2): تخمين أقرب زرار سريع كان مستخدم بناءً على القيمة المسجلة
    // بالفعل، عشان لو الاستقبال بيعدّل اختيار سابق يلاقي نفس السياق ظاهر —
    // تخمين استرشادي بس، مش قيد (المستخدم يقدر يغيّره بحرية).
    if (type === "bonding_upper" || type === "bonding_lower") setPurposeQuickCategory("ortho");
    else if (type === "service" && appt.purpose_linked_invoice_id) setPurposeQuickCategory(isOrthoAppt(appt) ? "ortho" : "general");
    else if (type === "service") setPurposeQuickCategory("search");
    else setPurposeQuickCategory("");
    setPurposeModal({ apptId: appt.id, patientName: appt.patient_name, patientId: appt.patient_id });
  }

  function closePurposeModal() {
    setPurposeModal(null);
    setPurposeModalType("");
    setPurposeModalServiceId("");
    setPurposeQuickCategory("");
    setPurposeLinkedInvoiceId("");
    setPurposeOpenServices(null);
  }

  function savePurposeModal() {
    if (!purposeModal) return;
    const fd = new FormData();
    fd.set("appointment_id", String(purposeModal.apptId));
    fd.set("purpose_type", purposeModalType);
    if (purposeModalType === "service" && purposeModalServiceId) fd.set("purpose_service_id", purposeModalServiceId);
    if (purposeLinkedInvoiceId) fd.set("purpose_linked_invoice_id", purposeLinkedInvoiceId);
    startPurposeModalTransition(async () => {
      await setAppointmentPurposeAction(fd);
      router.refresh();
    });
    closePurposeModal();
  }
  // mode "collect": بوكس التحصيل الكامل (لصلاحية collect_payments) — بيسجل دفع فعلي.
  // mode "pending": بوكس "المطلوب دفعه" بس (لمين معهوش الصلاحية، زي الدكتور) — بيحدد
  // خدمة وسعر متوقع من غير أي تسجيل مالي فعلي.
  const [billingModal, setBillingModal] = useState<{
    apptId: number;
    patientId: number;
    patientName: string;
    mode: "collect" | "pending";
    roomId: number;
    doctorId: number;
  } | null>(null);
  // دفعة 27 (P3.1): بوكس "إضافة خدمة للتحصيل" السريع — بيتفتح بكليك يمين على
  // اسم المريض في الخانة، مستقل تمامًا عن حالة/وجود موعد (بعكس billingModal
  // اللي مرتبط بموعد معيّن). بيستخدم نفس حقول اختيار الخدمة/السعر/الخصم/الدفع
  // فوق (selectedService, price, discountPercent, amountNow...) لأن الاتنين
  // (billingModal وquickAddModal) مايتفتحوش مع بعض أبدًا.
  const [quickAddModal, setQuickAddModal] = useState<{ patientId: number; patientName: string } | null>(null);
  const [quickWhatsappTemplates, setQuickWhatsappTemplates] = useState<{ id: number; name: string; quick_slot: number | null }[]>([]);
  const [quickAddDoctorId, setQuickAddDoctorId] = useState("");
  const [quickAddVisitDate, setQuickAddVisitDate] = useState("");
  // دفعة 28: قبل كده، اختصار "+ افتح خدمة للتحصيل دلوقتي" (لما القائمة فاضية
  // وقت اختيار "الغرض من الزيارة") كان بيقفل بوكس الحجز/تعديل الغرض بالكامل
  // (كل الحقول المختارة بتتمسح)، والمستخدم كان لازم يبدأ الحجز من الأول تاني
  // بعد ما يسجل الخدمة. دلوقتي بس بيتخبى مؤقتًا (الحالة فاضلة كاملة) وبيرجع
  // يظهر تلقائيًا لما بوكس "إضافة خدمة للتحصيل" يتقفل (نجاح أو إلغاء) — والخدمة
  // الجديدة بتبقى متاحة على طول في قائمة الربط (شوف purposeOpenServicesRefreshKey).
  const [hideForQuickAdd, setHideForQuickAdd] = useState(false);
  const [purposeOpenServicesRefreshKey, setPurposeOpenServicesRefreshKey] = useState(0);
  const [highlightApptId, setHighlightApptId] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const menuRef = useRef<HTMLDivElement>(null);
  // دوسة طويلة (long-press) على موبايل/تابلت = نفس تأثير الزر اليمين على
  // ديسكتوب (فتح قايمة تغيير حالة الموعد) — تاتش مالوش زر يمين خالص. تايمر
  // واحد مشترك كفاية لأن لمسة واحدة بس بتكون فعّالة في أي لحظة، وبيتلغي لو
  // المستخدم حرّك إصبعه (يعني بيسكرول الجدول، مش بيعمل long-press).
  const touchLongPressRef = useRef<{ timer: ReturnType<typeof setTimeout>; startX: number; startY: number } | null>(null);
  const LONG_PRESS_MS = 550;
  const LONG_PRESS_MOVE_CANCEL_PX = 10;

  useEffect(() => {
    if (isDoctorView) return;
    listManualTemplatesAction().then((rows) => setQuickWhatsappTemplates(rows.filter((row) => row.quick_slot).slice(0, 5))).catch(() => undefined);
  }, [isDoctorView]);

  // حالة بوكس التحصيل
  const [serviceNameSearch, setServiceNameSearch] = useState("");
  const [serviceCodeSearch, setServiceCodeSearch] = useState("");
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [price, setPrice] = useState("");
  const [discountPercent, setDiscountPercent] = useState("0");
  const [amountNow, setAmountNow] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("cash");
  const [followupOptions, setFollowupOptions] = useState<BillableInvoice[] | null>(null);
  const [loadingFollowups, setLoadingFollowups] = useState(false);
  const [targetInvoiceId, setTargetInvoiceId] = useState("");
  const [performingDoctorId, setPerformingDoctorId] = useState("");

  // حجز الموعد القادم (اختياري) — بيظهر جوه بوكس التحصيل (mode "collect") بعد
  // اختيار الخدمة، بنفس الغرفة والدكتور بتوع الموعد الحالي. مربع الوقت بيعرض بس
  // الفترات المتاحة فعلًا لليوم المختار (getBookedSlotsForRoomDateAction).
  const today = useMemo(() => getClinicToday(), []);
  const [nextApptDate, setNextApptDate] = useState("");
  const [nextApptTime, setNextApptTime] = useState("");
  const [nextApptDuration, setNextApptDuration] = useState(String(slotMinutes));
  const [lastAppointmentTime, setLastAppointmentTime] = useState<string | null>(null);
  const [nextAppointmentError, setNextAppointmentError] = useState("");
  const [bookedSlotsForNextAppt, setBookedSlotsForNextAppt] = useState<Set<string>>(new Set());
  const [loadingNextApptSlots, setLoadingNextApptSlots] = useState(false);

  function resetNextAppt() {
    setNextApptDate("");
    setNextApptTime("");
    setNextApptDuration(String(slotMinutes));
    setBookedSlotsForNextAppt(new Set());
    setLastAppointmentTime(null);
    setNextAppointmentError("");
  }

  useEffect(() => {
    if (!billingModal || billingModal.mode !== "collect" || !nextApptDate) {
      setBookedSlotsForNextAppt(new Set());
      return;
    }
    let cancelled = false;
    setLoadingNextApptSlots(true);
    getBookedSlotsForRoomDateAction(billingModal.roomId, nextApptDate).then((slots) => {
      if (cancelled) return;
      setBookedSlotsForNextAppt(new Set(slots));
      setLoadingNextApptSlots(false);
    });
    return () => {
      cancelled = true;
    };
  }, [billingModal, nextApptDate]);

  const nextApptAvailableTimes = useMemo(
    () => timeSlots.filter((t) => !bookedSlotsForNextAppt.has(t)),
    [timeSlots, bookedSlotsForNextAppt]
  );

  // لو الوقت المختار بقى محجوز (بعد ما اليوم اتغيّر مثلًا)، امسحه بدل ما يفضل
  // متحدد بقيمة بقت غير متاحة.
  useEffect(() => {
    if (nextApptTime && bookedSlotsForNextAppt.has(nextApptTime)) setNextApptTime("");
  }, [bookedSlotsForNextAppt, nextApptTime]);

  useEffect(() => {
    if (!billingModal) return;
    let cancelled = false;
    getLastAppointmentTimeAction(billingModal.patientId).then((time) => {
      if (cancelled) return;
      setLastAppointmentTime(time);
      if (time) setNextApptTime(time);
    });
    return () => { cancelled = true; };
  }, [billingModal]);

  // تزامن الجدول بين أكتر من جهاز/شاشة في الاستقبال — كل 4.5 ثانية، وطالما مفيش
  // مودال حجز أو قايمة يمين مفتوحة (عشان مايقطعش حد وهو بيدخل بيانات)، وطالما
  // التاب ده ظاهر فعليًا (مش تاب تاني مفتوح في الخلفية).
  useEffect(() => {
    const interval = setInterval(() => {
      if (document.visibilityState !== "visible") return;
      if (contextMenu || bookingModal || billingModal || quickAddModal || referralModal) return;
      router.refresh();
    }, 4500);
    return () => clearInterval(interval);
  }, [router, contextMenu, bookingModal, billingModal, quickAddModal, referralModal]);

  // لما يتم اختيار خدمة "متابعة" (كود 0) في بوكس التحصيل أو بوكس "إضافة خدمة
  // للتحصيل" السريع، بيتجاب فواتير المريض السابقة اللي لسه عليها مبلغ مستحق،
  // عشان تظهر في الـ drop list يتم الاختيار منها. الاتنين مايتفتحوش مع بعض
  // أبدًا، فـpatientId واحد بس بيتحدد فعليًا في أي وقت.
  const followupPatientId = billingModal?.patientId ?? quickAddModal?.patientId ?? null;
  useEffect(() => {
    if (!followupPatientId || selectedService?.code !== "0") {
      setFollowupOptions(null);
      return;
    }
    let cancelled = false;
    setLoadingFollowups(true);
    getPatientBillableInvoicesAction(followupPatientId).then((rows) => {
      if (cancelled) return;
      setFollowupOptions(rows);
      setLoadingFollowups(false);
    });
    return () => {
      cancelled = true;
    };
  }, [followupPatientId, selectedService]);

  useEffect(() => {
    if (!contextMenu) return;
    function onClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setContextMenu(null);
    }
    window.addEventListener("click", onClickOutside);
    return () => window.removeEventListener("click", onClickOutside);
  }, [contextMenu]);

  useEffect(() => { if (!contextMenu) setWhatsappMenuOpen(false); }, [contextMenu]);

  useLayoutEffect(() => {
    if (!contextMenu || !menuRef.current) return;
    const padding = 8;
    const rect = menuRef.current.getBoundingClientRect();
    const x = Math.max(padding, Math.min(contextMenu.x, window.innerWidth - rect.width - padding));
    const y = Math.max(padding, Math.min(contextMenu.y, window.innerHeight - rect.height - padding));
    if (x !== contextMenu.x || y !== contextMenu.y) setContextMenu((current) => current ? { ...current, x, y } : current);
  }, [contextMenu, quickWhatsappTemplates.length, whatsappMenuOpen]);

  useEffect(() => {
    if (highlightApptId === null) return;
    const t = setTimeout(() => setHighlightApptId(null), 2500);
    return () => clearTimeout(t);
  }, [highlightApptId]);

  const liveAppointments = useMemo(() => appointments.filter((a) => a.status !== "cancelled"), [appointments]);

  // خطة كل خانة لكل غرفة: تبدأ موعد (وبتاخد rowSpan) أو خانة اتغطت بموعد فوقها (skip،
  // ملهاش <td> خالص) أو خانة فاضية قابلة للحجز.
  const plans = useMemo(() => {
    const result: Record<number, CellPlan[]> = {};
    for (const room of rooms) {
      const cells: CellPlan[] = timeSlots.map(() => ({ kind: "empty" }));
      const roomAppts = liveAppointments
        .filter((a) => a.room_id === room.id)
        .sort((a, b) => a.start_time.localeCompare(b.start_time));
      for (const appt of roomAppts) {
        const startIdx = timeSlots.indexOf(appt.start_time);
        if (startIdx === -1) continue;
        const span = Math.max(1, Math.round((appt.duration_minutes || slotMinutes) / slotMinutes));
        cells[startIdx] = { kind: "start", appt, span };
        for (let i = startIdx + 1; i < Math.min(startIdx + span, timeSlots.length); i++) {
          cells[i] = { kind: "skip" };
        }
      }
      result[room.id] = cells;
    }
    return result;
  }, [rooms, timeSlots, liveAppointments, slotMinutes]);

  const apptByPatient = useMemo(() => {
    const map = new Map<number, Appt[]>();
    for (const a of liveAppointments) {
      if (!map.has(a.patient_id)) map.set(a.patient_id, []);
      map.get(a.patient_id)!.push(a);
    }
    return map;
  }, [liveAppointments]);

  const searchResults = useMemo(() => {
    const q = search.trim();
    if (!q) return [];
    return patients
      .filter((p) => p.full_name.includes(q) || p.file_number.includes(q))
      .slice(0, 8);
  }, [search, patients]);

  function jumpToAppointment(apptId: number) {
    setHighlightApptId(apptId);
    setSearch("");
    setTimeout(() => {
      document.getElementById(`appt-cell-${apptId}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 50);
  }

  function openBookingModal(roomId: number, roomName: string, startTime: string) {
    setBookingPatientSearch("");
    setBookingSelectedPatient(null);
    setBookingPurposeType("");
    setBookingPurposeServiceId("");
    setPurposeQuickCategory("");
    setPurposeLinkedInvoiceId("");
    setPurposeOpenServices(null);
    setBookingModal({ roomId, roomName, startTime });
  }

  function closeBookingModal() {
    setBookingModal(null);
    setBookingPatientSearch("");
    setBookingSelectedPatient(null);
    setBookingPurposeType("");
    setBookingPurposeServiceId("");
    setPurposeQuickCategory("");
    setPurposeLinkedInvoiceId("");
    setPurposeOpenServices(null);
  }

  // بحث المريض في بوكس الحجز: بيدور في أي جزء من الاسم (مش أول الاسم بس) — كتابة
  // "عزت" في "أحمد عزت" بترجعه من غير ما تحتاج تكتب "أحمد" الأول. نفس منطق
  // البحث الرئيسي فوق (searchResults) ونفس منطق صفحة "المرضى" (بحث %term%) —
  // موحّد في كل مربعات البحث عن مريض في النظام.
  const bookingPatientResults = useMemo(() => {
    const q = bookingPatientSearch.trim();
    if (!q) return [];
    return patients.filter((p) => p.full_name.includes(q) || p.file_number.includes(q)).slice(0, 8);
  }, [bookingPatientSearch, patients]);

  function submitBooking(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!bookingModal || !bookingSelectedPatient) return;
    const fd = new FormData(e.currentTarget);
    // دفعة 28: كانت await/router.refresh() ناقصة هنا — الموعد الجديد كان
    // بيتسجل صح في القاعدة، بس مكانش بيظهر في الجدول فورًا (لحد الـpolling
    // التلقائي كل 4.5 ثانية، أو لحد ما المستخدم يعمل حاجة تانية تعمل refresh
    // بالصدفة). نفس النمط المستخدم فعليًا في savePurposeModal فوق.
    startTransition(async () => {
      await addAppointmentAction(fd);
      router.refresh();
    });
    closeBookingModal();
  }

  // دفعة 27 (P3.2): قيم مشتركة بين بوكس الحجز وبوكس تعديل الغرض — مايتفتحوش مع
  // بعض أبدًا، فمفيش تعارض. followupService = خدمة "متابعة" العامة (كود "0")
  // نفسها المستخدمة في بوكس التحصيل، وهي اللي بتتسجل كـpurpose_service_id لأي
  // اختيار "متابعة" (تقويم أو عام) — السياق (تقويم/عام) بييجي من فئة الفاتورة
  // المربوطة (purpose_linked_invoice_id) مش من خدمة مخصوصة.
  const followupService = useMemo(() => services.find((s) => s.code === "0") ?? null, [services]);
  const purposeActivePatientId = bookingModal ? bookingSelectedPatient?.id ?? null : purposeModal ? purposeModal.patientId : null;
  const purposeActiveType = bookingModal ? bookingPurposeType : purposeModal ? purposeModalType : "";
  const purposeActiveServiceId = bookingModal ? bookingPurposeServiceId : purposeModal ? purposeModalServiceId : "";

  // نطاق جلب "الخدمات المفتوحة" المناسب للحالة الحالية: تقويم/عام من الأزرار
  // السريعة، أو "الكل" لو دخل عن طريق البحث الحر ولقى خدمة "متابعة" بالذات
  // (كود "0") — أي حالة تانية (خدمة عادية من البحث الحر) مش محتاجة ربط أصلاً.
  const purposeOpenScope: "ortho" | "general" | "all" | null =
    purposeQuickCategory === "ortho"
      ? "ortho"
      : purposeQuickCategory === "general"
        ? "general"
        : purposeQuickCategory === "search" && purposeActiveType === "service" && purposeActiveServiceId === String(followupService?.id ?? "")
          ? "all"
          : null;

  useEffect(() => {
    if (!purposeOpenScope || !purposeActivePatientId) {
      setPurposeOpenServices(null);
      return;
    }
    let cancelled = false;
    setLoadingPurposeOpenServices(true);
    getPatientOpenServicesForPurposeAction(purposeActivePatientId, purposeOpenScope).then((rows) => {
      if (cancelled) return;
      setPurposeOpenServices(rows);
      setLoadingPurposeOpenServices(false);
    });
    return () => {
      cancelled = true;
    };
  }, [purposeOpenScope, purposeActivePatientId, purposeOpenServicesRefreshKey]);

  // لازم يكون في ربط بفاتورة مفتوحة قبل الحفظ لأي اختيار "تقويم"/"عام" — إلا
  // لو أصلاً مفيش خدمة مفتوحة يتربط بيها (حالة القائمة الفاضية، هيظهر بدلها
  // اختصار "إضافة خدمة للتحصيل" مباشرة تحت). البحث الحر مش إجباري خالص.
  const purposeLinkRequiredButMissing =
    (purposeQuickCategory === "ortho" || purposeQuickCategory === "general") &&
    !purposeLinkedInvoiceId &&
    !loadingPurposeOpenServices &&
    (purposeOpenServices?.length ?? 0) > 0;

  // قايمة اختيار الفاتورة المفتوحة المرتبطة (تقويم/عام/بحث حر) — مشتركة بين كل
  // السياقات، وبتعرض اختصار "إضافة خدمة للتحصيل" (P3.1) لو مفيش خدمة مفتوحة
  // مطابقة أصلاً، بدل ما تسيب الاستقبال عالقة.
  function renderPurposeOpenServicesLinker(patientId: number, patientName: string) {
    return (
      <div className="mt-1.5">
        <label className="block text-[11px] text-muted mb-1">الخدمة المفتوحة المرتبطة</label>
        {loadingPurposeOpenServices ? (
          <div className="text-xs text-muted">جاري التحميل...</div>
        ) : purposeOpenServices && purposeOpenServices.length > 0 ? (
          <select
            value={purposeLinkedInvoiceId}
            onChange={(e) => setPurposeLinkedInvoiceId(e.target.value)}
            className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
          >
            <option value="">اختر خدمة مفتوحة</option>
            {purposeOpenServices.map((o) => (
              <option key={o.id} value={o.id}>
                {o.service_name} — {o.visit_date} — الباقي {o.balance.toFixed(0)} ج.م
              </option>
            ))}
          </select>
        ) : (
          <div className="text-xs text-danger space-y-1">
            <div>مفيش خدمة مفتوحة مطابقة لهذا المريض لسه.</div>
            <button
              type="button"
              onClick={() => {
                // دفعة 28: بس نخبي بوكس الحجز/تعديل الغرض مؤقتًا (من غير ما نمسح
                // أي حقل) — بيرجع يظهر تلقائيًا بمجرد ما بوكس "إضافة خدمة
                // للتحصيل" ده يتقفل، بدل ما نضيع كل الاختيارات ونرجع نبدأ من الأول.
                setHideForQuickAdd(true);
                openQuickAddModal(patientId, patientName);
              }}
              className="text-primary hover:underline"
            >
              + افتح خدمة للتحصيل دلوقتي
            </button>
          </div>
        )}
      </div>
    );
  }

  // قائمة "المريض جاي يعمل إيه؟" الكاملة (دفعة 27، P3.2) — مشتركة بين بوكس الحجز
  // وبوكس تعديل موعد موجود. ctx بيحمل الحقول اللي بتختلف بين السياقين بس
  // (النوع/الخدمة المختارة والـsetters بتوعهم ومعرّف/اسم المريض)؛ الباقي
  // (purposeQuickCategory, purposeLinkedInvoiceId, purposeOpenServices) مشترك
  // فعليًا لأن بوكس الحجز وبوكس التعديل مايتفتحوش مع بعض أبدًا.
  function renderPurposePicker(ctx: {
    type: "" | "bonding_upper" | "bonding_lower" | "service";
    setType: (v: "" | "bonding_upper" | "bonding_lower" | "service") => void;
    serviceId: string;
    setServiceId: (v: string) => void;
    patientId: number | null;
    patientName: string;
    closeCurrent: () => void;
  }) {
    const orthoSubActive =
      purposeQuickCategory === "ortho"
        ? ctx.type === "bonding_upper"
          ? "bonding_upper"
          : ctx.type === "bonding_lower"
            ? "bonding_lower"
            : followupService && ctx.serviceId === String(followupService.id)
              ? "followup"
              : ""
        : "";

    function chooseNone() {
      ctx.setType("");
      ctx.setServiceId("");
      setPurposeQuickCategory("");
      setPurposeLinkedInvoiceId("");
    }
    function chooseOrtho() {
      setPurposeQuickCategory("ortho");
      setPurposeLinkedInvoiceId("");
      ctx.setType("");
      ctx.setServiceId("");
    }
    function chooseOrthoSub(sub: "bonding_upper" | "bonding_lower" | "followup") {
      setPurposeLinkedInvoiceId("");
      if (sub === "followup") {
        ctx.setType("service");
        ctx.setServiceId(followupService ? String(followupService.id) : "");
      } else {
        ctx.setType(sub);
        ctx.setServiceId("");
      }
    }
    function chooseGeneral() {
      setPurposeQuickCategory("general");
      setPurposeLinkedInvoiceId("");
      ctx.setType("service");
      ctx.setServiceId(followupService ? String(followupService.id) : "");
    }
    function chooseSearch() {
      setPurposeQuickCategory("search");
      setPurposeLinkedInvoiceId("");
      ctx.setType("service");
      ctx.setServiceId("");
    }

    return (
      <div>
        <label className="block text-xs text-muted mb-1">المريض جاي يعمل إيه؟ (اختياري)</label>
        <div className="flex flex-wrap gap-1.5">
          <button
            type="button"
            onClick={chooseNone}
            className={`px-2.5 py-1 rounded-md border text-xs ${purposeQuickCategory === "" && ctx.type === "" ? "btn-3d-primary border-transparent" : "border-border hover:bg-primary-soft"}`}
          >
            بدون تحديد
          </button>
          <button
            type="button"
            onClick={chooseOrtho}
            className={`px-2.5 py-1 rounded-md border text-xs ${purposeQuickCategory === "ortho" ? "btn-3d-primary border-transparent" : "border-border hover:bg-primary-soft"}`}
          >
            تقويم
          </button>
          <button
            type="button"
            onClick={chooseGeneral}
            className={`px-2.5 py-1 rounded-md border text-xs ${purposeQuickCategory === "general" ? "btn-3d-primary border-transparent" : "border-border hover:bg-primary-soft"}`}
          >
            عام (متابعة)
          </button>
          <button
            type="button"
            onClick={chooseSearch}
            className={`px-2.5 py-1 rounded-md border text-xs ${purposeQuickCategory === "search" ? "btn-3d-primary border-transparent" : "border-border hover:bg-primary-soft"}`}
          >
            خدمة تانية (بحث)
          </button>
        </div>

        {purposeQuickCategory === "ortho" && (
          <div className="mt-1.5 space-y-1.5">
            <div className="flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={() => chooseOrthoSub("bonding_upper")}
                className={`px-2.5 py-1 rounded-md border text-xs ${orthoSubActive === "bonding_upper" ? "btn-3d-primary border-transparent" : "border-border hover:bg-primary-soft"}`}
              >
                تركيب أول تقويم
              </button>
              <button
                type="button"
                onClick={() => chooseOrthoSub("bonding_lower")}
                className={`px-2.5 py-1 rounded-md border text-xs ${orthoSubActive === "bonding_lower" ? "btn-3d-primary border-transparent" : "border-border hover:bg-primary-soft"}`}
              >
                تركيب تاني تقويم
              </button>
              <button
                type="button"
                onClick={() => chooseOrthoSub("followup")}
                className={`px-2.5 py-1 rounded-md border text-xs ${orthoSubActive === "followup" ? "btn-3d-primary border-transparent" : "border-border hover:bg-primary-soft"}`}
              >
                متابعة تقويم
              </button>
            </div>
            {orthoSubActive && ctx.patientId && renderPurposeOpenServicesLinker(ctx.patientId, ctx.patientName)}
            {orthoSubActive && !ctx.patientId && <div className="text-[11px] text-muted">اختر المريض الأول عشان تربط بخدمة مفتوحة.</div>}
          </div>
        )}

        {purposeQuickCategory === "general" &&
          (ctx.patientId ? (
            renderPurposeOpenServicesLinker(ctx.patientId, ctx.patientName)
          ) : (
            <div className="mt-1.5 text-[11px] text-muted">اختر المريض الأول عشان تربط بخدمة مفتوحة.</div>
          ))}

        {purposeQuickCategory === "search" && (
          <div className="mt-1.5 space-y-1.5">
            {/* الاسم مختلف عمدًا عن الـhidden input المستقل فوق (بوكس الحجز) — عشان
                مايتكررش نفس name جوه فورم واحد؛ الـinput المستقل هو اللي بيتقرا
                فعليًا وقت الإرسال، مش ده. */}
            <ServiceCombobox name="purpose_service_id_picker" services={services} value={ctx.serviceId} onChange={ctx.setServiceId} />
            {followupService && ctx.serviceId === String(followupService.id) && ctx.patientId && (
              <>
                <div className="text-[11px] text-amber-700">
                  دي خدمة "متابعة" — اختر الخدمة المفتوحة اللي الدفعة دي هتترحّل منها (من كل الخدمات، من غير فلترة).
                </div>
                {renderPurposeOpenServicesLinker(ctx.patientId, ctx.patientName)}
              </>
            )}
          </div>
        )}
      </div>
    );
  }

  function setStatus(id: number, status: string) {
    const fd = new FormData();
    fd.set("id", String(id));
    fd.set("status", status);
    startTransition(async () => {
      await updateAppointmentStatusAction(fd);
      router.refresh();
    });
    setContextMenu(null);
  }

  // "تم": لو المستخدم عنده صلاحية تحصيل المدفوعات، بيفتح بوكس الفوترة الكامل (السعر
  // بيتحدد وبعدين يتحدد الموعد "تم" لما البوكس يتقفل، والدفع الفعلي بيتسجل). لو معهوش
  // الصلاحية (زي الدكتور)، بيفتحله بوكس "المطلوب دفعه" بس — يحدد الخدمة والسعر المتوقع
  // من غير ما يقدر يسجل دفع فعلي؛ الاستقبال بيشوفها على طول جنب "محتاج تحصيل" في
  // الجدول، وبتتملى تلقائي لما يفتح بوكس التحصيل الحقيقي بأثر رجعي (تسجيل التحصيل).
  function onMarkDone(appt: Appt) {
    setContextMenu(null);
    setServiceNameSearch("");
    setServiceCodeSearch("");
    setTargetInvoiceId("");
    setFollowupOptions(null);
    setPaymentMethod("cash");
    setPerformingDoctorId("");
    resetNextAppt();

    if (!canCollectPayments) {
      setSelectedService(null);
      setPrice("");
      setDiscountPercent("0");
      setAmountNow("");
      setBillingModal({
        apptId: appt.collection_request_appointment_id ?? appt.id,
        patientId: appt.patient_id,
        patientName: appt.patient_name,
        mode: "pending",
        roomId: appt.room_id,
        doctorId: appt.doctor_id,
      });
      return;
    }

    // فتح بوكس التحصيل بأثر رجعي لموعد "تم" أصلاً وحدد له الدكتور "المطلوب دفعه" —
    // نملي بيانات الخدمة/السعر من هناك تلقائيًا عشان الاستقبال ميحتاجش يدخلها تاني.
    if (appt.needs_billing && (appt.pending_service_id || appt.pending_price != null)) {
      const svc = services.find((s) => s.id === appt.pending_service_id) ?? null;
      setSelectedService(svc);
      setPrice(appt.pending_price != null ? String(appt.pending_price) : svc ? String(svc.default_price) : "");
      setDiscountPercent(appt.pending_discount_percent != null ? String(appt.pending_discount_percent) : "0");
      setAmountNow("");
    } else if (appt.purpose_linked_invoice_id) {
      // دفعة 27 (P3.2): الموعد ده اتحدد وقت الغرض/الحجز إنه "متابعة" لخدمة
      // مفتوحة بعينها (appt.purpose_linked_invoice_id) — بوكس التحصيل بيتفتح
      // على طول على خدمة "متابعة" مع الفاتورة المستهدفة محددة مسبقًا، بدل ما
      // الاستقبال يتسأل عنها تاني وقت التحصيل الفعلي.
      setSelectedService(followupService);
      setPrice("0");
      setDiscountPercent("0");
      setAmountNow("");
      if (followupService) setTargetInvoiceId(String(appt.purpose_linked_invoice_id));
    } else {
      setSelectedService(null);
      setPrice("");
      setDiscountPercent("0");
      setAmountNow("");
    }
    setBillingModal({
      apptId: appt.collection_request_appointment_id ?? appt.id,
      patientId: appt.patient_id,
      patientName: appt.patient_name,
      mode: "collect",
      roomId: appt.room_id,
      doctorId: appt.doctor_id,
    });
  }

  function closeBillingModal() {
    setBillingModal(null);
    setSelectedService(null);
    resetNextAppt();
  }

  // دفعة 27 (P3.1): بوكس "إضافة خدمة للتحصيل" السريع — بيتفتح بكليك يمين على
  // اسم المريض، بغض النظر عن حالة أي موعد. مستقل عن onMarkDone/billingModal
  // تمامًا (مفيش appointment_id هنا خالص)، وبيستخدم addPatientServiceAction
  // نفسه المستخدم في الملف المالي للمريض (AddPatientServiceForm) — نفس
  // المنطق بالظبط، بس من غير ما تحتاج تروح لصفحة الملف المالي الأول.
  function openQuickAddModal(patientId: number, patientName: string) {
    setContextMenu(null);
    setServiceNameSearch("");
    setServiceCodeSearch("");
    setTargetInvoiceId("");
    setFollowupOptions(null);
    setPaymentMethod("cash");
    setPerformingDoctorId("");
    setSelectedService(null);
    setPrice("");
    setDiscountPercent("0");
    setAmountNow("");
    setQuickAddDoctorId("");
    setQuickAddVisitDate(today);
    setQuickAddModal({ patientId, patientName });
  }

  function closeQuickAddModal() {
    setQuickAddModal(null);
    setSelectedService(null);
    // دفعة 28: لو كنا جايين من اختصار "افتح خدمة للتحصيل" جوه بوكس حجز/تعديل
    // غرض متخبي، يرجع يظهر تاني بكل حقوله زي ما كانت (شوف hideForQuickAdd فوق).
    setHideForQuickAdd(false);
  }

  function submitQuickAdd() {
    if (!quickAddModal || !selectedService || !quickAddDoctorId) return;
    const isFollowup = selectedService.code === "0";
    if (isFollowup && !targetInvoiceId) return;
    if (!amountNow.trim()) return;

    const fd = new FormData();
    fd.set("patient_id", String(quickAddModal.patientId));
    fd.set("service_id", String(selectedService.id));
    fd.set("doctor_id", quickAddDoctorId);
    fd.set("visit_date", quickAddVisitDate || today);
    fd.set("payment_method", paymentMethod);
    fd.set("amount_now", String(Number(amountNow) || 0));
    if (isFollowup) {
      fd.set("target_invoice_id", targetInvoiceId);
    } else {
      fd.set("price", String(Number(price) || 0));
      fd.set("discount_percent", String(Number(discountPercent) || 0));
    }
    if (performingDoctorId) fd.set("performing_doctor_id", performingDoctorId);

    startTransition(async () => {
      await addPatientServiceAction(fd);
      router.refresh();
      // لو بوكس الحجز/تعديل الغرض هيرجع يظهر (اختصار القائمة الفاضية)، لازم
      // قائمة "الخدمة المفتوحة المرتبطة" تتحدّث عشان الخدمة اللي اتسجلت دلوقتي
      // تظهر فيها على طول من غير ما نستنى أي تغيير تاني يشغّل الـfetch.
      setPurposeOpenServicesRefreshKey((k) => k + 1);
    });
    closeQuickAddModal();
  }

  function selectService(s: Service) {
    setSelectedService(s);
    setServiceNameSearch("");
    setServiceCodeSearch("");
    setTargetInvoiceId("");
    if (s.code === "0") {
      // خدمة متابعة: مفيش سعر/خصم — البوكس بيبان فاضي علشان يتكتب فيه اللي هيتدفع دلوقتي.
      setPrice("0");
      setDiscountPercent("0");
      setAmountNow("");
    } else {
      setPrice(String(s.default_price));
      setDiscountPercent("0");
      setAmountNow("");
    }
  }

  const computedTotal = useMemo(() => {
    const p = Number(price) || 0;
    const d = Math.min(100, Math.max(0, Number(discountPercent) || 0));
    return Math.max(0, p * (1 - d / 100));
  }, [price, discountPercent]);

  // مربوطين بمربعين منفصلين: البحث بالاسم بيدور على أي جزء من الاسم (substring)، لكن
  // البحث بالكود لازم يكون تطابق تام للرقم بالظبط — عشان كتابة "0" متجيبش أي خدمة
  // كودها فيه صفر زي "100" أو "120" أو "160"، تجيب بس اللي كودها "0" نفسه.
  const filteredServices = useMemo(() => {
    const nameQ = serviceNameSearch.trim();
    const codeQ = serviceCodeSearch.trim();
    if (!nameQ && !codeQ) return [];
    const byName = nameQ ? services.filter((s) => s.name.includes(nameQ)) : [];
    const byCode = codeQ ? services.filter((s) => s.code === codeQ) : [];
    const merged = new Map<number, Service>();
    for (const s of [...byName, ...byCode]) merged.set(s.id, s);
    return [...merged.values()].slice(0, 8);
  }, [serviceNameSearch, serviceCodeSearch, services]);

  const selectedTargetBalance = useMemo(() => {
    if (!targetInvoiceId || !followupOptions) return null;
    return followupOptions.find((f) => String(f.id) === targetInvoiceId) ?? null;
  }, [targetInvoiceId, followupOptions]);

  function submitBilling() {
    if (!billingModal || !selectedService) return;
    const isFollowup = selectedService.code === "0";
    if (isFollowup && !targetInvoiceId) return;
    if (!amountNow.trim()) return;

    const fd = new FormData();
    fd.set("appointment_id", String(billingModal.apptId));
    fd.set("service_id", String(selectedService.id));
    fd.set("payment_method", paymentMethod);
    fd.set("amount_now", String(Number(amountNow) || 0));
    if (isFollowup) {
      fd.set("target_invoice_id", targetInvoiceId);
    } else {
      fd.set("price", String(Number(price) || 0));
      fd.set("discount_percent", String(Number(discountPercent) || 0));
    }
    // دفعة 24: الطبيب المساعد بقى بيتبعت في الحالتين (متابعة وغير متابعة) — كان
    // قبل كده محصور بس على غير المتابعة.
    if (performingDoctorId) fd.set("performing_doctor_id", performingDoctorId);

    // حجز الموعد القادم اختياري — بيتسجل بس لو الاستقبال حدد تاريخ ووقت فعلًا،
    // بنفس غرفة ودكتور الموعد الحالي.
    if (nextApptDate && !nextApptTime) {
      setNextAppointmentError("لازم تختار ساعة للموعد القادم قبل الحفظ.");
      return;
    }
    const shouldBookNext = !!(nextApptDate && nextApptTime);
    const nextApptFd = shouldBookNext ? new FormData() : null;
    if (nextApptFd) {
      nextApptFd.set("patient_id", String(billingModal.patientId));
      nextApptFd.set("room_id", String(billingModal.roomId));
      nextApptFd.set("doctor_id", String(billingModal.doctorId));
      nextApptFd.set("appointment_date", nextApptDate);
      nextApptFd.set("start_time", nextApptTime);
      nextApptFd.set("duration_minutes", nextApptDuration);
    }

    startTransition(async () => {
      await recordAppointmentBillingAction(fd);
      if (nextApptFd) await addAppointmentAction(nextApptFd);
      router.refresh();
    });
    closeBillingModal();
  }

  // بوكس "المطلوب دفعه" (لمين معهوش صلاحية تحصيل المدفوعات) — بيسجل الخدمة والسعر
  // المتوقع كـ pending_* على الموعد نفسه من غير أي زيارة/فاتورة أو دفع فعلي.
  function submitPending() {
    if (!billingModal || (!selectedService && !(Number(price) > 0))) return;
    const fd = new FormData();
    fd.set("appointment_id", String(billingModal.apptId));
    if (selectedService) fd.set("service_id", String(selectedService.id));
    fd.set("requested_amount", String(Number(price) || 0));
    startTransition(async () => {
      await recordPendingBillingAction(fd);
      router.refresh();
    });
    closeBillingModal();
  }

  const durationOptions = [1, 2, 3, 4].map((n) => n * slotMinutes);
  const statusSummary = liveAppointments.reduce(
    (summary, appointment) => {
      summary[appointment.status] += 1;
      return summary;
    },
    { booked: 0, attended: 0, done: 0, cancelled: 0, no_show: 0 } as Record<Appt["status"], number>
  );

  return (
    <div className="schedule-workspace">
      {/* بحث فوري عن مريض */}
      {showPatientSearch && <div className="relative max-w-sm">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="بحث عن مريض بالاسم أو رقم الملف..."
          className="w-full rounded-md border border-border bg-background px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
        {searchResults.length > 0 && (
          <div className="absolute z-20 mt-1 w-full card-3d rounded-md shadow-lg overflow-hidden">
            {searchResults.map((p) => {
              const todays = apptByPatient.get(p.id) ?? [];
              return (
                <div key={p.id} className="flex items-center justify-between gap-2 px-3 py-2 text-sm border-b border-border last:border-b-0 hover:bg-primary-soft">
                  <div>
                    <div className="font-medium">{p.full_name}</div>
                    <div className="text-xs text-muted">ملف {p.file_number}</div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    {todays.map((a) => (
                      <button
                        key={a.id}
                        type="button"
                        onClick={() => jumpToAppointment(a.id)}
                        className="text-xs px-2 py-1 rounded-md bg-primary-soft text-primary-dark hover:bg-primary hover:text-white"
                        title="روح لموعده في الجدول"
                      >
                        {a.start_time}
                      </button>
                    ))}
                    <Link
                      href={isDoctorView ? `/patients/${p.id}` : `/patients/${p.id}/billing`}
                      className="text-xs px-2 py-1 rounded-md border border-border hover:bg-primary-soft whitespace-nowrap"
                    >
                      فتح الملف
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>}

      {/* ملخص يومي صغير: أرقام تشغيلية فقط، بلا أي مبالغ مالية. */}
      {showStatusSummary && <div className="schedule-status-row text-[11px] text-muted">
        <div className="flex flex-wrap items-center gap-2" aria-label="ملخص حالات المواعيد">
          <span className="schedule-status-summary"><i className="bg-sky-500" />مؤكد {statusSummary.booked}</span>
          <span className="schedule-status-summary"><i className="bg-amber-400" />حضر {statusSummary.attended}</span>
          <span className="schedule-status-summary"><i className="bg-emerald-500" />تم {statusSummary.done}</span>
          <span className="schedule-status-summary"><i className="bg-rose-500" />لم يحضر {statusSummary.no_show}</span>
        </div>
        <span className="whitespace-nowrap">الإجمالي {liveAppointments.length}</span>
      </div>}
      <div className="schedule-legend" aria-hidden="true">
        {(["booked", "attended", "done", "no_show"] as const).map((s) => (
          <span key={s} className="flex items-center gap-1">
            <span className={`inline-block w-3 h-3 rounded-sm border ${statusClasses(s)}`} />
            {STATUS_LABELS[s]}
          </span>
        ))}
        {canEdit ? (
          <span className="text-muted">
            دوس على خانة فاضية للحجز، أو دوس بالزر اليمين (أو دوسة طويلة على الموبايل/التابلت) على موعد لتغيير حالته. الموعد اللي "تم" مبيترجعش أو يتلغي.
            {" "}
            <span className="text-danger font-semibold">محتاج تحصيل</span> يعني "تم" بس لسه من غير فوترة
            {canCollectPayments ? " — دوس بالزر اليمين عليه لتسجيل التحصيل." : "."}
            {" "}
            <span className="text-amber-700 font-semibold">محتاج صور جديدة</span> يعني المريض بيعمل متابعة ومفيش
            صور/أشعة اتسجلت له من أكتر من 6 شهور.
          </span>
        ) : (
          <span className="text-muted">عرض فقط — التعديل في الجدول (حجز/تغيير حالة) مقصور على الاستقبال.</span>
        )}
      </div>

      {/* central grid */}
      <div className="schedule-grid-shell">
        <table className="schedule-grid-table">
          <thead className="sticky top-0 z-10">
            <tr className="bg-primary-soft text-primary-dark">
              <th className="sticky right-0 z-20 bg-primary-soft px-1 py-1.5 font-medium whitespace-nowrap w-[48px] min-w-[48px]">الوقت</th>
              {rooms.map((r, roomIndex) => {
                const shiftDoctor = doctors.find((doctor) => doctor.id === roomShiftDoctorIds[r.id]);
                const roomAppointments = liveAppointments.filter((appointment) => appointment.room_id === r.id).length;
                const completedAppointments = liveAppointments.filter((appointment) => appointment.room_id === r.id && appointment.status === "done").length;
                const completion = roomAppointments ? `${Math.round((completedAppointments / roomAppointments) * 100)}%` : "0%";
                return <th key={r.id} className="schedule-clinic-head">
                  <div className="schedule-clinic-head-inner">
                    <div className="schedule-clinic-doctor-wrap">
                      {shiftDoctor && <><span className="schedule-clinic-avatar">{shiftDoctor.full_name.trim().split(/\s+/).slice(0, 2).map((part) => part[0]).join("")}</span><span className="schedule-clinic-doctor">{shiftDoctor.full_name}</span></>}
                    </div>
                    <span className="schedule-clinic-title">Clinic {roomIndex + 1}</span>
                    <span className="schedule-clinic-capacity" style={{ "--completion": completion } as React.CSSProperties}>{completedAppointments} / {roomAppointments} تم</span>
                  </div>
                </th>
              })}
            </tr>
          </thead>
          <tbody>
            {timeSlots.map((time, rowIdx) => (
              <tr key={time}>
                <td className="sticky right-0 bg-surface z-10 px-1 py-0.5 text-muted whitespace-nowrap border-e border-border text-center tabular-nums">{time}</td>
                {rooms.map((room) => {
                  const plan = plans[room.id]?.[rowIdx] ?? { kind: "empty" as const };
                  if (plan.kind === "skip") return null;
                  if (plan.kind === "start") {
                    const appt = plan.appt;
                    const appointmentAlerts = [
                      showReceptionAlerts && appt.needs_billing ? "مطلوب تحصيل" : null,
                      (showReceptionAlerts || isDoctorView) && appt.needs_consultant_visit ? "زيارة استشاري" : null,
                      (showReceptionAlerts || isDoctorView) && appt.needs_new_photos ? "يحتاج إلى صور" : null,
                      isDoctorView && appt.needs_treatment ? "محتاج إدخال معالجة" : null,
                    ].filter((alert): alert is string => alert != null);
                    const highlighted = highlightApptId === appt.id;
                    // موعد "تم" وليه فاتورة/زيارة مسجلة بقى سجل نهائي — مينفعش يتلغى أو تتغير
                    // حالته تاني. لو "تم" بس لسه محتاج تحصيل (حصل "تم" من غير بوكس)، بس
                    // اللي عنده صلاحية تحصيل المدفوعات هو اللي يقدر يفتحله قايمة (لتسجيل
                    // التحصيل بأثر رجعي) — أي حد تاني (زي الدكتور اللي حدده) مش هيقدر يعمل
                    // حاجة تانية بيه.
                    // الطبيب يقدر يضع موعده اليوم «تم» بصلاحية مستقلة، من غير فتح
                    // التحصيل. طلب التحصيل يظل إجراءً منفصلاً له، بينما «تم» من حساب
                    // الاستقبال يحتفظ بمسار التحصيل المعتاد.
                    const canActOnAppt =
                      ((canEdit || canMarkDone) && appt.status !== "done") ||
                      (canEdit && !!appt.needs_billing && canCollectPayments) ||
                      // الطبيب يقدر يضيف/يعدل طلب تحصيل لموعد اليوم حتى بعد
                      // وضع «تم»، لكن لا تتاح له أي تعديلات على الأيام السابقة.
                      (isDoctorView && date === getClinicToday());
                    return (
                      <td
                        key={room.id}
                        id={`appt-cell-${appt.id}`}
                        rowSpan={plan.span}
                        onContextMenu={(e) => {
                          if (!canActOnAppt) return;
                          e.preventDefault();
                          setContextMenu({
                            apptId: appt.id,
                            x: e.clientX,
                            y: e.clientY,
                            patientName: appt.patient_name,
                            status: appt.status,
                            needsBilling: !!appt.needs_billing,
                          });
                        }}
                        onTouchStart={(e) => {
                          if (!canActOnAppt) return;
                          const touch = e.touches[0];
                          const startX = touch.clientX;
                          const startY = touch.clientY;
                          const timer = setTimeout(() => {
                            touchLongPressRef.current = null;
                            setContextMenu({
                              apptId: appt.id,
                              x: startX,
                              y: startY,
                              patientName: appt.patient_name,
                              status: appt.status,
                              needsBilling: !!appt.needs_billing,
                            });
                          }, LONG_PRESS_MS);
                          touchLongPressRef.current = { timer, startX, startY };
                        }}
                        onTouchMove={(e) => {
                          const state = touchLongPressRef.current;
                          if (!state) return;
                          const touch = e.touches[0];
                          if (
                            Math.abs(touch.clientX - state.startX) > LONG_PRESS_MOVE_CANCEL_PX ||
                            Math.abs(touch.clientY - state.startY) > LONG_PRESS_MOVE_CANCEL_PX
                          ) {
                            clearTimeout(state.timer);
                            touchLongPressRef.current = null;
                          }
                        }}
                        onTouchEnd={() => {
                          const state = touchLongPressRef.current;
                          if (state) {
                            clearTimeout(state.timer);
                            touchLongPressRef.current = null;
                          }
                        }}
                        onTouchCancel={() => {
                          const state = touchLongPressRef.current;
                          if (state) {
                            clearTimeout(state.timer);
                            touchLongPressRef.current = null;
                          }
                        }}
                        className={`schedule-appointment-cell ${appt.status === "done" ? "schedule-appointment-cell--done" : ""} align-top p-1 border border-border transition-shadow ${
                          canActOnAppt ? "cursor-context-menu [-webkit-touch-callout:none] select-none" : "cursor-default"
                        } ${highlighted ? "ring-2 ring-primary ring-offset-1" : ""}`}
                      >
                        <div className={`schedule-appointment-card ${statusClasses(appt.status)}`}>
                          <div className="schedule-card-clinical">
                            <Link
                              href={
                                isDoctorView
                                  ? isOrthoAppt(appt)
                                    ? `/patients/${appt.patient_id}/orthodontics`
                                    : `/patients/${appt.patient_id}`
                                  : `/patients/${appt.patient_id}/billing`
                              }
                              onClick={(e) => e.stopPropagation()}
                              onContextMenu={(e) => {
                                // كليك يمين على الاسم فقط يفتح إضافة خدمة للتحصيل السريع.
                                if (isDoctorView || !canQuickAddService) return;
                                e.preventDefault();
                                e.stopPropagation();
                                openQuickAddModal(appt.patient_id, appt.patient_name);
                              }}
                              className="schedule-card-name font-semibold block hover:underline"
                              title={isDoctorView ? (isOrthoAppt(appt) ? "فتح شارت التقويم" : "فتح الملف الطبي") : "فتح الملف المالي"}
                            >
                              {appt.patient_name}
                            </Link>
                            {appointmentAlerts.length > 0 && <div className="schedule-card-alerts">{appointmentAlerts.join(" - ")}</div>}
                            {purposeLabelOf(appt, isDoctorView) ? (
                              <Link href={purposeHrefOf(appt, isDoctorView)} onClick={(e) => e.stopPropagation()} className="schedule-card-service block" title={isDoctorView ? "فتح الملف المرتبط بالخدمة" : "فتح الملف المالي"}>{purposeLabelOf(appt, isDoctorView)}</Link>
                            ) : <div className="schedule-card-service">{appt.notes || "زيارة عيادة"}</div>}
                          </div>
                          <div className="schedule-card-meta">
                            <span className={`schedule-card-status schedule-card-status--${appt.status}`}>{appt.status === "booked" && appt.confirmed_at ? "مؤكد" : STATUS_LABELS[appt.status]}</span>
                            {appt.reschedule_pending === 1 && <span className="schedule-card-status bg-violet-100 text-violet-800">بانتظار اعتماد التعديل</span>}
                            <span className="schedule-card-doctor">{appt.doctor_name}</span>
                          </div>
                        </div>
                      </td>
                    );
                  }
                  return (
                    <td
                      key={room.id}
                      onClick={canEdit ? () => openBookingModal(room.id, room.name, time) : undefined}
                      className={`schedule-empty-cell border border-border ${canEdit ? "cursor-pointer hover:bg-primary-soft/50" : ""}`}
                      title={canEdit ? "دوس للحجز" : undefined}
                    />
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <footer className="schedule-bottom-bar" aria-label="ملخص اليوم">
        <span><b>{liveAppointments.length}</b> إجمالي المواعيد</span>
        <span className="is-booked"><b>{statusSummary.booked}</b> مؤكد</span>
        <span className="is-attended"><b>{statusSummary.attended}</b> حضر</span>
        <span className="is-done"><b>{statusSummary.done}</b> مكتمل</span>
        <span className="is-no-show"><b>{statusSummary.no_show}</b> لم يحضر</span>
      </footer>

      {/* right-click context menu */}
      {contextMenu && (
        <div
          ref={menuRef}
          style={{ position: "fixed", top: contextMenu.y, left: contextMenu.x, maxHeight: "calc(100vh - 16px)" }}
          className="z-50 card-3d rounded-md shadow-lg py-1 text-sm min-w-[180px] max-w-[calc(100vw-16px)] overflow-y-auto"
        >
          <div className="px-3 py-1.5 text-xs text-muted border-b border-border truncate">{contextMenu.patientName}</div>
          {contextMenu.status === "done" ? (
            // بيوصل هنا بس لو الموعد "تم" ومحتاج تحصيل ومعاه صلاحية التحصيل (اتفحص قبل
            // فتح القايمة أصلاً) — الخيار الوحيد المتاح هو تسجيل التحصيل بأثر رجعي، من غير
            // أي إمكانية للرجوع لحالة تانية أو الإلغاء.
            <button
              type="button"
              onClick={() => {
                const appt = liveAppointments.find((a) => a.id === contextMenu.apptId);
                if (!appt) return;
                onMarkDone(appt);
              }}
              className="w-full text-right px-3 py-1.5 hover:bg-primary-soft"
            >
              {canCollectPayments ? "تسجيل التحصيل" : "طلب تحصيل للاستقبال"}
            </button>
          ) : (
            <>
              {canEdit && (
                <button type="button" onClick={() => setStatus(contextMenu.apptId, "attended")} className="w-full text-right px-3 py-1.5 hover:bg-primary-soft">
                  حضر
                </button>
              )}
              {(canEdit || canMarkDone) && (
                <button
                  type="button"
                  onClick={() => {
                    if (isDoctorView) {
                      setStatus(contextMenu.apptId, "done");
                      return;
                    }
                    const appt = liveAppointments.find((a) => a.id === contextMenu.apptId);
                    if (appt) onMarkDone(appt);
                  }}
                  className="w-full text-right px-3 py-1.5 hover:bg-primary-soft"
                >
                  تم
                </button>
              )}
              {canEdit && (
                <>
                  <button
                    type="button"
                    onClick={() => setStatus(contextMenu.apptId, "cancelled")}
                    className="w-full text-right px-3 py-1.5 hover:bg-danger-soft text-danger"
                  >
                    إلغاء (تفضية الخانة)
                  </button>
                </>
              )}
              {isDoctorView && (
                <button
                  type="button"
                  onClick={() => {
                    const appt = liveAppointments.find((a) => a.id === contextMenu.apptId);
                    if (!appt) return;
                    onMarkDone(appt);
                  }}
                  className="w-full text-right px-3 py-1.5 hover:bg-primary-soft"
                >
                  طلب تحصيل للاستقبال
                </button>
              )}
            </>
          )}
          <button
            type="button"
            onClick={() => {
              const appt = liveAppointments.find((a) => a.id === contextMenu.apptId);
              if (!appt) return;
              openPurposeModal(appt);
            }}
            className="w-full text-right px-3 py-1.5 hover:bg-primary-soft border-t border-border"
          >
            تحديد/تغيير الخدمة
          </button>
          {isDoctorView && (
            <button type="button" onClick={() => {
              const appt = liveAppointments.find((a) => a.id === contextMenu.apptId);
              if (!appt) return;
              setContextMenu(null);
              setReferralModal({ appointmentId: appt.id, patientName: appt.patient_name, doctorId: appt.doctor_id });
            }} className="w-full text-right px-3 py-1.5 hover:bg-primary-soft border-t border-border">
              تحويل لطبيب (Refer)
            </button>
          )}
          {!isDoctorView && canEdit && liveAppointments.find((item) => item.id === contextMenu.apptId)?.reschedule_pending === 1 && (
            <button type="button" onClick={() => {
              const appointmentId = contextMenu.apptId;
              const appointment = liveAppointments.find((item) => item.id === appointmentId);
              setContextMenu(null);
              startTransition(async () => {
                if (!appointment) return;
                const result = await approveAppointmentRescheduleByAppointmentAction(appointmentId);
                if (!result.ok) return window.alert(result.error || "تعذر اعتماد الموعد.");
                if (result.warning) window.alert(result.warning); else window.alert("تم تأكيد الموعد المعدل.");
                router.refresh();
              });
            }} className="w-full text-right px-3 py-1.5 hover:bg-primary-soft border-t border-border">
              اعتماد الموعد المعدل
            </button>
          )}
          {!isDoctorView && canEdit && (quickWhatsappTemplates.length > 0 || !quickWhatsappTemplates.some((template) => isConfirmationTemplateName(template.name))) && (
            <div className="border-t border-border py-1">
              <button type="button" onClick={() => setWhatsappMenuOpen((open) => !open)} className="flex w-full items-center justify-between px-3 py-1.5 text-right font-medium hover:bg-primary-soft"><span>رسائل واتساب</span><span>{whatsappMenuOpen ? "▴" : "◂"}</span></button>
              {whatsappMenuOpen && <div className="border-t border-border bg-background py-1">
              {!quickWhatsappTemplates.some((template) => isConfirmationTemplateName(template.name)) && liveAppointments.find((item) => item.id === contextMenu.apptId)?.reschedule_pending !== 1 && <button type="button" onClick={() => {
                const appointmentId = contextMenu.apptId; const popup = reserveWhatsAppWindow(); setContextMenu(null);
                startTransition(async () => { const result = await createManualWhatsappConfirmationAction(appointmentId); if (!result.ok || !result.whatsappUrl) { popup?.close(); return window.alert(result.error || "تعذر تجهيز رسالة واتساب."); } navigateWhatsAppWindow(popup, result.whatsappUrl); });
              }} className="w-full px-5 py-1.5 text-right hover:bg-primary-soft">إرسال تأكيد الموعد</button>}
              {quickWhatsappTemplates.filter((template) => liveAppointments.find((item) => item.id === contextMenu.apptId)?.reschedule_pending !== 1 || !isConfirmationTemplateName(template.name)).map((template) => (
                <button key={template.id} type="button" onClick={() => {
                  const appointmentId = contextMenu.apptId;
                  const popup = reserveWhatsAppWindow();
                  setContextMenu(null);
                  startTransition(async () => {
                    const result = await prepareManualTemplateForAppointmentAction(appointmentId, template.id);
                    if (!result.ok || !result.whatsappUrl) { popup?.close(); return window.alert(result.error || "تعذر تجهيز الرسالة"); }
                    navigateWhatsAppWindow(popup, result.whatsappUrl);
                  });
                }} className="w-full px-3 py-1.5 text-right hover:bg-primary-soft">{template.name}</button>
              ))}
              <Link href="/whatsapp" className="block px-3 py-1.5 text-right text-xs text-primary hover:bg-primary-soft">كل القوالب…</Link>
              </div>}
            </div>
          )}
        </div>
      )}

      {referralModal && <ReferralModal appointmentId={referralModal.appointmentId} patientName={referralModal.patientName} doctors={doctors} currentDoctorId={referralModal.doctorId} onClose={() => setReferralModal(null)} />}

      {/* booking modal */}
      {bookingModal && !hideForQuickAdd && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={closeBookingModal}>
          <form
            onClick={(e) => e.stopPropagation()}
            onSubmit={submitBooking}
            className="card-3d rounded-xl p-5 w-full max-w-sm space-y-3"
          >
            <h3 className="font-semibold">
              حجز — {bookingModal.roomName} · {bookingModal.startTime}
            </h3>
            <input type="hidden" name="appointment_date" value={date} />
            <input type="hidden" name="room_id" value={bookingModal.roomId} />
            <input type="hidden" name="start_time" value={bookingModal.startTime} />

            <div className="relative">
              <label className="block text-xs text-muted mb-1">المريض</label>
              <input type="hidden" name="patient_id" value={bookingSelectedPatient?.id ?? ""} />
              {bookingSelectedPatient ? (
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2 rounded-md border border-border bg-background px-2 py-1.5 text-sm">
                    <span>
                      {bookingSelectedPatient.full_name} ({bookingSelectedPatient.file_number})
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setBookingSelectedPatient(null);
                        setBookingPatientSearch("");
                      }}
                      className="text-xs text-primary hover:underline shrink-0"
                    >
                      تغيير
                    </button>
                  </div>
                  {missingPatientDetails(bookingSelectedPatient).length > 0 && (
                    <div className="rounded-md border border-amber-300 bg-amber-50 px-2 py-1.5 text-xs text-amber-800">
                      بيانات المريض ناقصة: {missingPatientDetails(bookingSelectedPatient).map((field) => PATIENT_MISSING_FIELD_LABELS[field]).join("، ")}. يفضّل استكمالها من ملف المريض.
                    </div>
                  )}
                  {showReceptionAlerts && (bookingSelectedPatient.needs_consultant_visit || bookingSelectedPatient.needs_new_photos) && (
                    <div className="space-y-1.5">
                      {bookingSelectedPatient.needs_consultant_visit && (
                        <div className="rounded-md border border-orange-300 bg-orange-50 px-2 py-1.5 text-xs font-medium text-orange-800">
                          تنبيه: {bookingSelectedPatient.consultant_name ? `د. ${bookingSelectedPatient.consultant_name}` : "الاستشاري"} لم يشاهد المريض منذ 3 أشهر — يحتاج إلى زيارة استشاري.
                        </div>
                      )}
                      {bookingSelectedPatient.needs_new_photos && (
                        <div className="rounded-md border border-amber-300 bg-amber-50 px-2 py-1.5 text-xs font-medium text-amber-800">
                          تنبيه: المريض يحتاج إلى صور جديدة.
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ) : (
                <>
                  <input
                    type="text"
                    autoFocus
                    value={bookingPatientSearch}
                    onChange={(e) => setBookingPatientSearch(e.target.value)}
                    placeholder="اكتب اسم المريض أو رقم الملف..."
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                  {bookingPatientResults.length > 0 && (
                    <div className="absolute z-10 mt-1 w-full card-3d rounded-md shadow-lg overflow-hidden max-h-48 overflow-y-auto">
                      {bookingPatientResults.map((p) => (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => {
                            setBookingSelectedPatient(p);
                            setBookingPatientSearch("");
                          }}
                          className="w-full text-right px-3 py-1.5 text-sm hover:bg-primary-soft flex items-center justify-between gap-2"
                        >
                          <span>{p.full_name}</span>
                          <span className="text-xs text-muted shrink-0">{p.file_number}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>

            <div>
              <label className="block text-xs text-muted mb-1">الدكتور</label>
              {/* افتراضيًا بيبقى محدد صاحب شيفت الغرفة دي النهاردة (لو موجود) — التحصيل
                  بعد كده هيورّث نفس الدكتور ده تلقائيًا. التغيير هنا وقت الحجز بس هو
                  الطريقة الوحيدة (لحالة مريض جاي فجأة لدكتور تاني غير صاحب الشيفت). */}
              <select
                name="doctor_id"
                required
                defaultValue={roomShiftDoctorIds[bookingModal.roomId] ?? ""}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              >
                <option value="">اختر دكتور</option>
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.full_name}
                    {roomShiftDoctorIds[bookingModal.roomId] === d.id ? " (صاحب الشيفت)" : ""}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-muted mb-1">المدة</label>
              <select name="duration_minutes" defaultValue={slotMinutes} className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm">
                {durationOptions.map((m) => (
                  <option key={m} value={m}>
                    {m} دقيقة
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-muted mb-1">ملاحظات (اختياري)</label>
              <input name="notes" className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
            </div>

            <div>
              <input type="hidden" name="purpose_type" value={bookingPurposeType} />
              {/* دفعة 27 (P3.2): لازم input مستقل هنا (مش بس اللي جوه ServiceCombobox
                  في مسار "خدمة تانية") — الأزرار السريعة "تقويم"/"عام" بتحدد
                  bookingPurposeServiceId (لخدمة "متابعة" العامة) من غير ما تعرض
                  ServiceCombobox خالص، فمن غير الـinput ده الفورم كان بيتبعت من
                  غير purpose_service_id أصلاً في المسارين دول. */}
              <input type="hidden" name="purpose_service_id" value={bookingPurposeServiceId} />
              <input type="hidden" name="purpose_linked_invoice_id" value={purposeLinkedInvoiceId} />
              {renderPurposePicker({
                type: bookingPurposeType,
                setType: setBookingPurposeType,
                serviceId: bookingPurposeServiceId,
                setServiceId: setBookingPurposeServiceId,
                patientId: bookingSelectedPatient?.id ?? null,
                patientName: bookingSelectedPatient?.full_name ?? "",
                closeCurrent: closeBookingModal,
              })}
            </div>

            {purposeLinkRequiredButMissing && (
              <div className="text-[11px] text-danger">لازم تختار الخدمة المفتوحة المرتبطة قبل الحجز (أو تفتح واحدة جديدة).</div>
            )}

            <div className="flex gap-2 justify-end pt-1">
              <button type="button" onClick={closeBookingModal} className="px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft">
                إلغاء
              </button>
              <button
                type="submit"
                disabled={!bookingSelectedPatient || purposeLinkRequiredButMissing}
                className="px-3 py-1.5 rounded-md btn-3d-primary text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
              >
                + حجز
              </button>
            </div>
          </form>
        </div>
      )}

      {/* بوكس "المريض جاي يعمل إيه" — تحديد/تغيير الخدمة لموعد موجود بالفعل، بيتفتح من
          قايمة كليك يمين/دوسة طويلة على خانة الموعد (دفعة 26). */}
      {purposeModal && !hideForQuickAdd && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={closePurposeModal}>
          <div onClick={(e) => e.stopPropagation()} className="card-3d rounded-xl p-5 w-full max-w-sm space-y-3">
            <h3 className="font-semibold">المريض جاي يعمل إيه؟ — {purposeModal.patientName}</h3>
            {renderPurposePicker({
              type: purposeModalType,
              setType: setPurposeModalType,
              serviceId: purposeModalServiceId,
              setServiceId: setPurposeModalServiceId,
              patientId: purposeModal.patientId,
              patientName: purposeModal.patientName,
              closeCurrent: closePurposeModal,
            })}
            {purposeLinkRequiredButMissing && (
              <div className="text-[11px] text-danger">لازم تختار الخدمة المفتوحة المرتبطة قبل الحفظ (أو تفتح واحدة جديدة).</div>
            )}
            <div className="flex gap-2 justify-end pt-1">
              <button type="button" onClick={closePurposeModal} className="px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft">
                إلغاء
              </button>
              <button
                type="button"
                onClick={savePurposeModal}
                disabled={purposeModalPending || purposeLinkRequiredButMissing}
                className="px-3 py-1.5 rounded-md btn-3d-primary text-sm font-medium disabled:opacity-50"
              >
                حفظ
              </button>
            </div>
          </div>
        </div>
      )}

      {/* بوكس التحصيل — بيتفتح لما يتم اختيار "تم" (لو المستخدم عنده صلاحية تحصيل المدفوعات) */}
      {billingModal && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={closeBillingModal}>
          <div onClick={(e) => e.stopPropagation()} className="card-3d rounded-xl p-5 w-full max-w-sm space-y-3 max-h-[90vh] overflow-y-auto">
            <h3 className="font-semibold">
              {billingModal.mode === "collect" ? "تحصيل" : "طلب تحصيل للاستقبال"} — {billingModal.patientName}
            </h3>
            {billingModal.mode === "collect" && (() => {
              const requested = liveAppointments.find((appt) => appt.id === billingModal.apptId);
              return requested?.needs_billing ? (
                <div className="rounded-md border border-danger/30 bg-danger-soft px-3 py-2 text-xs text-danger">
                  طلب الطبيب {requestedCollectionLabel(requested)}. أكمل الخدمة إن لم تُحدد، ثم اكتب المبلغ الذي دُفع فعليًا.
                </div>
              ) : null;
            })()}
            {billingModal.mode === "pending" && (
              <p className="text-xs text-muted -mt-2">
                اختر خدمة أو اكتب مبلغًا مطلوبًا (واحد منهما على الأقل). لا يتم تسجيل زيارة أو فاتورة أو دفع في هذه الخطوة.
              </p>
            )}

            {/* اختيار الخدمة بالبحث بالاسم أو الكود */}
            <div className="relative">
              <label className="block text-xs text-muted mb-1">الخدمة {billingModal.mode === "pending" ? "(اختياري)" : ""}</label>
              {selectedService ? (
                <div className="flex items-center justify-between gap-2 rounded-md border border-border bg-background px-2 py-1.5 text-sm">
                  <span>
                    {selectedService.name} {selectedService.code ? `(${selectedService.code})` : ""}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedService(null);
                      setFollowupOptions(null);
                      setTargetInvoiceId("");
                      setServiceNameSearch("");
                      setServiceCodeSearch("");
                    }}
                    className="text-xs text-primary hover:underline shrink-0"
                  >
                    تغيير
                  </button>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      autoFocus
                      value={serviceNameSearch}
                      onChange={(e) => setServiceNameSearch(e.target.value)}
                      placeholder="بحث بالاسم..."
                      className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                    <input
                      type="text"
                      value={serviceCodeSearch}
                      onChange={(e) => setServiceCodeSearch(e.target.value)}
                      placeholder="بحث بالكود (بالظبط)..."
                      className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  {filteredServices.length > 0 && (
                    <div className="absolute z-10 mt-1 w-full card-3d rounded-md shadow-lg overflow-hidden max-h-48 overflow-y-auto">
                      {filteredServices.map((s) => (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => selectService(s)}
                          className="w-full text-right px-3 py-1.5 text-sm hover:bg-primary-soft flex items-center justify-between gap-2"
                        >
                          <span>{s.name}</span>
                          <span className="text-xs text-muted shrink-0">
                            {s.code ? `#${s.code}` : ""} {s.code !== "0" ? `— ${s.default_price} ج.م` : ""}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>

            {billingModal.mode === "pending" && (
              <div>
                <label className="block text-xs text-muted mb-1">المبلغ المطلوب تحصيله (اختياري)</label>
                <input
                  type="number"
                  step="0.01"
                  min={0}
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="مثال: 400"
                  className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                />
              </div>
            )}

            {selectedService && billingModal.mode === "collect" && selectedService.code === "0" && (
              <>
                <div>
                  <label className="block text-xs text-muted mb-1">الخدمة الأصلية (اللي هتتخصم منها الدفعة)</label>
                  {loadingFollowups ? (
                    <div className="text-xs text-muted">جاري التحميل...</div>
                  ) : followupOptions && followupOptions.length > 0 ? (
                    <select
                      value={targetInvoiceId}
                      onChange={(e) => setTargetInvoiceId(e.target.value)}
                      className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                    >
                      <option value="">اختر خدمة</option>
                      {followupOptions.map((f) => (
                        <option key={f.id} value={f.id}>
                          {f.service_name} — {f.visit_date} — الباقي {f.balance.toFixed(0)} ج.م
                        </option>
                      ))}
                    </select>
                  ) : (
                    <div className="text-xs text-danger">مفيش فواتير سابقة لسه عليها مبلغ مستحق لهذا المريض.</div>
                  )}
                </div>

                {selectedTargetBalance && (
                  <div className="text-sm">
                    الباقي المستحق: <span className="text-danger font-semibold">{selectedTargetBalance.balance.toFixed(0)} ج.م</span>
                  </div>
                )}

                <div>
                  <label className="block text-xs text-emerald-700 font-medium mb-1">المبلغ المدفوع دلوقتي *</label>
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    required
                    value={amountNow}
                    onChange={(e) => setAmountNow(e.target.value)}
                    placeholder="0"
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
              </>
            )}

            {selectedService && billingModal.mode === "collect" && selectedService.code !== "0" && (
              <>
                <div>
                  <label className="block text-xs text-muted mb-1">السعر</label>
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs text-muted mb-1">خصم (%)</label>
                  <input
                    type="number"
                    step="1"
                    min={0}
                    max={100}
                    value={discountPercent}
                    onChange={(e) => setDiscountPercent(e.target.value)}
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
                <div className="text-sm">
                  المطلوب دفعه: <span className="font-semibold">{computedTotal.toFixed(0)} ج.م</span>
                </div>
                <div>
                  <label className="block text-xs text-emerald-700 font-medium mb-1">المبلغ المدفوع دلوقتي *</label>
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    required
                    value={amountNow}
                    onChange={(e) => {
                      setAmountNow(e.target.value);
                    }}
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
              </>
            )}

            {selectedService && billingModal.mode === "collect" && (
              <div>
                <label className="block text-xs text-muted mb-1">وسيلة الدفع</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                >
                  {PAYMENT_METHODS.map((m) => (
                    <option key={m.value} value={m.value}>
                      {m.label}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* حجز الموعد القادم — اختياري، بيظهر بعد اختيار الخدمة والدفع في بوكس
                التحصيل الحقيقي بس (مش بوكس "المطلوب دفعه"). نفس غرفة ودكتور الموعد
                الحالي؛ مربع الوقت بيعرض بس الفترات المتاحة فعلًا لليوم المختار. */}
            {selectedService && billingModal.mode === "collect" && (
              <div className="border-t border-dashed border-border pt-3 space-y-2">
                <label className="block text-xs font-medium">حجز الموعد القادم (اختياري)</label>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[10px] text-muted mb-1">التاريخ</label>
                    <input
                      type="date"
                      value={nextApptDate}
                      min={today}
                      onChange={(e) => {
                        setNextApptDate(e.target.value);
                        setNextApptTime("");
                      }}
                      className="w-full rounded-md border border-border bg-background px-1.5 py-1.5 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-muted mb-1">الوقت</label>
                    <select
                      value={nextApptTime}
                      onChange={(e) => {
                        setNextApptTime(e.target.value);
                        setNextAppointmentError("");
                      }}
                      disabled={!nextApptDate || loadingNextApptSlots}
                      className="w-full rounded-md border border-border bg-background px-1.5 py-1.5 text-xs disabled:opacity-50"
                    >
                      <option value="">
                        {!nextApptDate ? "اختر تاريخ الأول" : loadingNextApptSlots ? "جاري التحميل..." : "اختر وقت"}
                      </option>
                      {nextApptAvailableTimes.map((t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      ))}
                    </select>
                    {lastAppointmentTime && (
                      <p className="text-[10px] text-muted mt-1">مقترح تلقائيًا: نفس ساعة آخر زيارة ({lastAppointmentTime}). يمكنك تغييرها.</p>
                    )}
                  </div>
                  <div>
                    <label className="block text-[10px] text-muted mb-1">عدد الفترات</label>
                    <select
                      value={nextApptDuration}
                      onChange={(e) => setNextApptDuration(e.target.value)}
                      className="w-full rounded-md border border-border bg-background px-1.5 py-1.5 text-xs"
                    >
                      {durationOptions.map((m) => (
                        <option key={m} value={m}>
                          {m} د
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                {nextApptDate && !loadingNextApptSlots && nextApptAvailableTimes.length === 0 && (
                  <div className="text-[10px] text-danger">مفيش فترات متاحة في اليوم ده لنفس الغرفة.</div>
                )}
                {nextAppointmentError && <div className="text-[10px] text-danger">{nextAppointmentError}</div>}
              </div>
            )}

            <div className="flex items-center justify-between gap-2 pt-1 flex-wrap">
              <button type="button" onClick={() => {
                if (billingModal.mode === "collect") startTransition(async () => { const result = await markAppointmentDoneWithoutPaymentAction(billingModal.apptId); if (!result.ok) return alert(result.error); closeBillingModal(); router.refresh(); });
                else { setStatus(billingModal.apptId, "done"); closeBillingModal(); }
              }} className="text-xs font-medium text-danger hover:underline">
                {billingModal.mode === "collect" ? "تم بدون دفع" : "تم بدون طلب تحصيل"}
              </button>
              <div className="flex gap-2">
                <button type="button" onClick={closeBillingModal} className="px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft">
                  إلغاء
                </button>
                {billingModal.mode === "pending" ? (
                  <button
                    type="button"
                    disabled={!selectedService && !(Number(price) > 0)}
                    onClick={submitPending}
                    className="px-3 py-1.5 rounded-md btn-3d-primary text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    إرسال طلب التحصيل
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={!selectedService || !amountNow.trim() || (selectedService.code === "0" && !targetInvoiceId)}
                    onClick={submitBilling}
                    className="px-3 py-1.5 rounded-md btn-3d-primary text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    تسجيل وإنهاء
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* بوكس "إضافة خدمة للتحصيل" السريع (دفعة 27، P3.1) — بيتفتح بكليك يمين على
          اسم المريض، مستقل تمامًا عن أي موعد. نفس منطق AddPatientServiceForm
          (الملف المالي للمريض) بالظبط، بس كمودال سريع من غير تنقل لصفحة تانية. */}
      {quickAddModal && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={closeQuickAddModal}>
          <div onClick={(e) => e.stopPropagation()} className="card-3d rounded-xl p-5 w-full max-w-sm space-y-3 max-h-[90vh] overflow-y-auto">
            <h3 className="font-semibold">إضافة خدمة للتحصيل — {quickAddModal.patientName}</h3>

            <div>
              <label className="block text-xs text-muted mb-1">تاريخ الزيارة</label>
              {canBackdateInvoice ? (
                <input
                  type="date"
                  value={quickAddVisitDate}
                  max={today}
                  onChange={(e) => setQuickAddVisitDate(e.target.value)}
                  className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                />
              ) : (
                <div className="rounded-md border border-border bg-background px-2 py-1.5 text-sm text-muted">{today} (النهاردة بس)</div>
              )}
            </div>

            <div>
              <label className="block text-xs text-muted mb-1">الدكتور</label>
              <select
                value={quickAddDoctorId}
                onChange={(e) => setQuickAddDoctorId(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              >
                <option value="">اختر دكتور</option>
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.full_name}
                  </option>
                ))}
              </select>
            </div>

            {/* اختيار الخدمة بالبحث بالاسم أو الكود — نفس بوكس التحصيل بالظبط */}
            <div className="relative">
              <label className="block text-xs text-muted mb-1">الخدمة</label>
              {selectedService ? (
                <div className="flex items-center justify-between gap-2 rounded-md border border-border bg-background px-2 py-1.5 text-sm">
                  <span>
                    {selectedService.name} {selectedService.code ? `(${selectedService.code})` : ""}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedService(null);
                      setFollowupOptions(null);
                      setTargetInvoiceId("");
                      setServiceNameSearch("");
                      setServiceCodeSearch("");
                    }}
                    className="text-xs text-primary hover:underline shrink-0"
                  >
                    تغيير
                  </button>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      autoFocus
                      value={serviceNameSearch}
                      onChange={(e) => setServiceNameSearch(e.target.value)}
                      placeholder="بحث بالاسم..."
                      className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                    <input
                      type="text"
                      value={serviceCodeSearch}
                      onChange={(e) => setServiceCodeSearch(e.target.value)}
                      placeholder="بحث بالكود (بالظبط)..."
                      className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  {filteredServices.length > 0 && (
                    <div className="absolute z-10 mt-1 w-full card-3d rounded-md shadow-lg overflow-hidden max-h-48 overflow-y-auto">
                      {filteredServices.map((s) => (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => selectService(s)}
                          className="w-full text-right px-3 py-1.5 text-sm hover:bg-primary-soft flex items-center justify-between gap-2"
                        >
                          <span>{s.name}</span>
                          <span className="text-xs text-muted shrink-0">
                            {s.code ? `#${s.code}` : ""} {s.code !== "0" ? `— ${s.default_price} ج.م` : ""}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>

            {selectedService && selectedService.code === "0" && (
              <>
                <div>
                  <label className="block text-xs text-muted mb-1">الخدمة الأصلية (اللي هتتخصم منها الدفعة)</label>
                  {loadingFollowups ? (
                    <div className="text-xs text-muted">جاري التحميل...</div>
                  ) : followupOptions && followupOptions.length > 0 ? (
                    <select
                      value={targetInvoiceId}
                      onChange={(e) => setTargetInvoiceId(e.target.value)}
                      className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                    >
                      <option value="">اختر خدمة</option>
                      {followupOptions.map((f) => (
                        <option key={f.id} value={f.id}>
                          {f.service_name} — {f.visit_date} — الباقي {f.balance.toFixed(0)} ج.م
                        </option>
                      ))}
                    </select>
                  ) : (
                    <div className="text-xs text-danger">مفيش فواتير سابقة لسه عليها مبلغ مستحق لهذا المريض.</div>
                  )}
                </div>

                {selectedTargetBalance && (
                  <div className="text-sm">
                    الباقي المستحق: <span className="text-danger font-semibold">{selectedTargetBalance.balance.toFixed(0)} ج.م</span>
                  </div>
                )}

                <div>
                  <label className="block text-xs text-emerald-700 font-medium mb-1">المبلغ المدفوع دلوقتي *</label>
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    required
                    value={amountNow}
                    onChange={(e) => setAmountNow(e.target.value)}
                    placeholder="0"
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
              </>
            )}

            {selectedService && selectedService.code !== "0" && (
              <>
                <div>
                  <label className="block text-xs text-muted mb-1">السعر</label>
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs text-muted mb-1">خصم (%)</label>
                  <input
                    type="number"
                    step="1"
                    min={0}
                    max={100}
                    value={discountPercent}
                    onChange={(e) => setDiscountPercent(e.target.value)}
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
                <div className="text-sm">
                  المطلوب دفعه: <span className="font-semibold">{computedTotal.toFixed(0)} ج.م</span>
                </div>
                <div>
                  <label className="block text-xs text-emerald-700 font-medium mb-1">المبلغ المدفوع دلوقتي *</label>
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    required
                    value={amountNow}
                    onChange={(e) => {
                      setAmountNow(e.target.value);
                    }}
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
              </>
            )}

            {selectedService && (
              <div>
                <label className="block text-xs text-muted mb-1">وسيلة الدفع</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                >
                  {PAYMENT_METHODS.map((m) => (
                    <option key={m.value} value={m.value}>
                      {m.label}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="flex gap-2 justify-end pt-1">
              <button type="button" onClick={closeQuickAddModal} className="px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft">
                إلغاء
              </button>
              <button
                type="button"
                disabled={!selectedService || !quickAddDoctorId || !amountNow.trim() || (selectedService.code === "0" && !targetInvoiceId)}
                onClick={submitQuickAdd}
                className="px-3 py-1.5 rounded-md btn-3d-primary text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
              >
                تسجيل
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
