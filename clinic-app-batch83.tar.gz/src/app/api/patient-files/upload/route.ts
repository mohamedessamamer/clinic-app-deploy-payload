import { NextRequest, NextResponse } from "next/server";
import { createWriteStream } from "node:fs";
import fs from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const UPLOAD_ROOT = process.env.CLINIC_UPLOAD_DIR
  ? path.join(path.resolve(process.env.CLINIC_UPLOAD_DIR), "patients")
  : path.join(process.cwd(), "data", "uploads", "patients");

const ALLOWED_EXTENSIONS = new Set([".jpg", ".jpeg", ".png", ".gif", ".webp", ".pdf"]);

function jsonError(error: string, status: number) {
  return NextResponse.json({ ok: false, error }, { status });
}

function safeOriginalName(encodedName: string | null) {
  let decoded = "file";
  try { decoded = decodeURIComponent(encodedName || "file"); } catch {}
  const clean = path.basename(decoded).replace(/[^a-zA-Z0-9._-]/g, "_").slice(-160) || "file";
  return clean;
}

export async function POST(request: NextRequest) {
  const session = await getSession();
  if (!session) return jsonError("انتهت الجلسة. سجل الدخول ثم حاول مرة أخرى.", 401);
  const canUpload = ["doctor", "admin", "clinic_manager"].includes(session.role)
    || await hasPermission(session.userId, session.role, "upload_ortho_photos");
  if (!canUpload) return jsonError("ليس لديك صلاحية رفع صور المرضى.", 403);

  const patientId = Number(request.nextUrl.searchParams.get("patientId"));
  const requestedGroupId = Number(request.nextUrl.searchParams.get("groupId"));
  const takenAt = String(request.nextUrl.searchParams.get("takenAt") || "").trim();
  const label = String(request.nextUrl.searchParams.get("label") || "").trim().slice(0, 300) || null;
  if (!Number.isInteger(patientId) || patientId <= 0 || !/^\d{4}-\d{2}-\d{2}$/.test(takenAt)) {
    return jsonError("بيانات المريض أو التاريخ غير صحيحة.", 400);
  }
  const patient = await db.selectFrom("patients").select("id").where("id", "=", patientId).executeTakeFirst();
  if (!patient) return jsonError("المريض غير موجود.", 404);

  let groupId: number | null = Number.isInteger(requestedGroupId) && requestedGroupId > 0 ? requestedGroupId : null;
  if (groupId != null) {
    const group = await db.selectFrom("patient_image_groups").select("id").where("id", "=", groupId).where("patient_id", "=", patientId).executeTakeFirst();
    if (!group) return jsonError("مجموعة الصور غير موجودة.", 404);
  }

  if (!request.body) return jsonError("الملف فارغ.", 400);
  const originalName = safeOriginalName(request.headers.get("x-file-name"));
  const extension = path.extname(originalName).toLowerCase();
  const contentType = request.headers.get("content-type")?.split(";", 1)[0].toLowerCase() || "";
  const isAllowedType = contentType.startsWith("image/") || contentType === "application/pdf";
  if (!ALLOWED_EXTENSIONS.has(extension) || !isAllowedType) return jsonError("يسمح بالصور وملفات PDF فقط.", 415);

  const patientDir = path.join(UPLOAD_ROOT, String(patientId));
  await fs.mkdir(patientDir, { recursive: true });
  const finalName = `${Date.now()}-${randomUUID()}-${originalName}`;
  const finalPath = path.join(patientDir, finalName);
  const temporaryPath = `${finalPath}.part`;

  let createdGroup = false;
  try {
    // تحويل Web stream إلى Node stream ثم الكتابة المباشرة على القرص؛ لا يوجد
    // file.arrayBuffer ولا نسخة كاملة من الملف داخل RAM.
    await pipeline(Readable.fromWeb(request.body as import("node:stream/web").ReadableStream), createWriteStream(temporaryPath, { flags: "wx" }));
    const stat = await fs.stat(temporaryPath);
    if (stat.size <= 0) throw new Error("empty upload");
    await fs.rename(temporaryPath, finalPath);

    if (groupId == null) {
      const group = await db.insertInto("patient_image_groups").values({ patient_id: patientId, taken_at: takenAt, label }).executeTakeFirstOrThrow();
      groupId = Number(group.insertId);
      createdGroup = true;
    }
    await db.insertInto("patient_images").values({ group_id: groupId, file_path: `/patient-files/patients/${patientId}/${finalName}` }).execute();
    return NextResponse.json({ ok: true, groupId });
  } catch (error) {
    await fs.unlink(temporaryPath).catch(() => {});
    await fs.unlink(finalPath).catch(() => {});
    if (createdGroup && groupId != null) {
      await db.deleteFrom("patient_image_groups").where("id", "=", groupId).execute().catch(() => {});
    }
    console.error("Patient file upload failed", error);
    return jsonError("تعذر حفظ الملف. لم يتوقف النظام ويمكنك إعادة المحاولة.", 500);
  }
}
