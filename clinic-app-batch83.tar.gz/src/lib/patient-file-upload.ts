export type PatientUploadProgress = {
  current: number;
  total: number;
  fileName: string;
};

type UploadOptions = {
  patientId: number;
  takenAt: string;
  label: string;
  files: File[];
  onProgress?: (progress: PatientUploadProgress) => void;
};

// كل ملف يُرفع في طلب منفرد وبالتتابع. بهذا لا يتم تجميع كل الصور أو ملفات
// الأشعة في ذاكرة المتصفح أو السيرفر مرة واحدة، وتظل كلها داخل مجموعة واحدة.
export async function uploadPatientFiles({ patientId, takenAt, label, files, onProgress }: UploadOptions) {
  let groupId: number | null = null;
  for (let index = 0; index < files.length; index += 1) {
    const file = files[index];
    onProgress?.({ current: index + 1, total: files.length, fileName: file.name });
    const params = new URLSearchParams({ patientId: String(patientId), takenAt, label });
    if (groupId != null) params.set("groupId", String(groupId));
    const response = await fetch(`/api/patient-files/upload?${params.toString()}`, {
      method: "POST",
      headers: {
        "Content-Type": file.type || "application/octet-stream",
        "X-File-Name": encodeURIComponent(file.name),
      },
      body: file,
      credentials: "same-origin",
    });
    const result = await response.json().catch(() => null) as { ok?: boolean; groupId?: number; error?: string } | null;
    if (!response.ok || !result?.ok || !result.groupId) {
      throw new Error(result?.error || `تعذر رفع الملف: ${file.name}`);
    }
    groupId = result.groupId;
  }
  return groupId;
}
