"use client";

import { useState, useTransition } from "react";
import { clearExpensesDataAction } from "@/app/expenses/actions";

const CONFIRM_WORD = "مسح";

type Range = { from: string; to: string };

export default function ClearExpensesDataButton({
  currentRange,
  currentMonthRange,
  previousMonthRange,
}: {
  currentRange: Range;
  currentMonthRange: Range;
  previousMonthRange: Range;
}) {
  const [isPending, startTransition] = useTransition();
  const [open, setOpen] = useState(false);
  const [confirmText, setConfirmText] = useState("");
  const [from, setFrom] = useState(currentRange.from);
  const [to, setTo] = useState(currentRange.to);

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="rounded-md border border-danger px-3 py-2 text-sm text-danger hover:bg-danger/10"
      >
        مسح بيانات المصروفات لفترة
      </button>
    );
  }

  const presetBtn = "rounded border border-border px-2 py-1 text-xs hover:bg-primary-soft";

  return (
    <div className="card-3d rounded-xl border border-danger/40 p-4 space-y-3 w-full sm:w-auto">
      <p className="text-sm text-danger">
        هذا الإجراء يحذف نهائيًا كل المصروفات وكشوف رواتب HR (مسجَّلة أو مصروفة) في الفترة المحددة فقط، ولا يمكن التراجع عنه. قواعد الرواتب والبنود المتكررة لا تتأثر.
      </p>
      <div className="flex flex-wrap items-end gap-2">
        <label className="text-xs text-muted">من<input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="mt-1 block h-9 rounded border border-border bg-background px-2 text-sm" /></label>
        <label className="text-xs text-muted">إلى<input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="mt-1 block h-9 rounded border border-border bg-background px-2 text-sm" /></label>
        <button type="button" className={presetBtn} onClick={() => { setFrom(currentMonthRange.from); setTo(currentMonthRange.to); }}>الشهر الحالي</button>
        <button type="button" className={presetBtn} onClick={() => { setFrom(previousMonthRange.from); setTo(previousMonthRange.to); }}>الشهر الماضي</button>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <input
          value={confirmText}
          onChange={(e) => setConfirmText(e.target.value)}
          placeholder={CONFIRM_WORD}
          className="rounded border border-border bg-background px-2 py-2 text-sm"
        />
        <button
          type="button"
          disabled={isPending || confirmText.trim() !== CONFIRM_WORD || !from || !to || to < from}
          className="rounded-md bg-danger px-3 py-2 text-sm text-white disabled:opacity-50"
          onClick={() => {
            const formData = new FormData();
            formData.set("from", from);
            formData.set("to", to);
            startTransition(async () => {
              const result = await clearExpensesDataAction(formData);
              if (!result.ok) {
                window.alert(result.reason ?? "لم يتم مسح البيانات.");
                return;
              }
              setOpen(false);
              setConfirmText("");
            });
          }}
        >
          {isPending ? "جاري المسح..." : `تأكيد مسح ${from} إلى ${to}`}
        </button>
        <button
          type="button"
          disabled={isPending}
          className="rounded-md border border-border px-3 py-2 text-sm hover:bg-primary-soft"
          onClick={() => {
            setOpen(false);
            setConfirmText("");
          }}
        >
          إلغاء
        </button>
      </div>
    </div>
  );
}
