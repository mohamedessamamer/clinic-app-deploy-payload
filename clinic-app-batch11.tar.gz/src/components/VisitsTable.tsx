"use client";

import { useState, useTransition } from "react";
import { updateVisitAction } from "@/app/patients/[id]/actions";

type Visit = {
  id: number;
  visit_date: string;
  service_id: number | null;
  service_name: string | null;
  notes: string | null;
  doctor_name: string | null;
  created_at: string;
};

type Service = { id: number; name: string };

const VISIT_EDIT_WINDOW_DAYS = 3;

// بيتحقق هل الزيارة لسه جوه فترة الـ 3 أيام (تعديل حر) — نفس الحد المطبق في
// السيرفر (actions.ts)، هنا بس لعرض/إخفاء زرار "تعديل" في الواجهة؛ التحقق
// الحقيقي والملزم بيحصل في السيرفر بغض النظر عن ساعة جهاز المستخدم.
function isWithinEditWindow(createdAt: string): boolean {
  const created = new Date(createdAt.replace(" ", "T") + "Z");
  const ageDays = (Date.now() - created.getTime()) / (1000 * 60 * 60 * 24);
  return ageDays <= VISIT_EDIT_WINDOW_DAYS;
}

export default function VisitsTable({
  patientId,
  visits,
  services,
  canEditOldVisits,
}: {
  patientId: number;
  visits: Visit[];
  services: Service[];
  canEditOldVisits: boolean;
}) {
  const [editingId, setEditingId] = useState<number | null>(null);
  const [isPending, startTransition] = useTransition();

  if (visits.length === 0) {
    return (
      <div className="overflow-x-auto">
        <table className="w-full text-sm mt-2 table-fixed">
          <thead className="bg-primary-soft text-primary-dark">
            <tr>
              <th className="text-right px-3 py-2 font-medium">التاريخ</th>
              <th className="text-right px-3 py-2 font-medium">نوع الخدمة</th>
              <th className="text-right px-3 py-2 font-medium">المعالجة</th>
              <th className="text-right px-3 py-2 font-medium">الدكتور</th>
              <th className="w-[10%]" />
            </tr>
          </thead>
          <tbody>
            <tr>
              <td colSpan={5} className="px-3 py-6 text-center text-muted">
                لا يوجد زيارات مسجلة بعد.
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm mt-2 table-fixed">
        <colgroup>
          <col className="w-[14%]" />
          <col className="w-[18%]" />
          <col />
          <col className="w-[16%]" />
          <col className="w-[10%]" />
        </colgroup>
        <thead className="bg-primary-soft text-primary-dark">
          <tr>
            <th className="text-right px-3 py-2 font-medium">التاريخ</th>
            <th className="text-right px-3 py-2 font-medium">نوع الخدمة</th>
            <th className="text-right px-3 py-2 font-medium">المعالجة</th>
            <th className="text-right px-3 py-2 font-medium">الدكتور</th>
            <th className="text-right px-3 py-2 font-medium" />
          </tr>
        </thead>
        <tbody>
          {visits.map((v) => {
            const editable = canEditOldVisits || isWithinEditWindow(v.created_at);
            const isEditing = editingId === v.id;

            if (isEditing) {
              return (
                <tr key={v.id} className="border-t border-border align-top bg-primary-soft/40">
                  <td colSpan={5} className="px-3 py-3">
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        const formData = new FormData(e.currentTarget);
                        startTransition(async () => {
                          await updateVisitAction(formData);
                          setEditingId(null);
                        });
                      }}
                      className="grid grid-cols-1 sm:grid-cols-4 gap-2 items-end"
                    >
                      <input type="hidden" name="visit_id" value={v.id} />
                      <input type="hidden" name="patient_id" value={patientId} />
                      <div>
                        <label className="block text-xs text-muted mb-1">التاريخ</label>
                        <input
                          type="date"
                          name="visit_date"
                          defaultValue={v.visit_date}
                          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-muted mb-1">نوع الخدمة</label>
                        <select
                          name="service_id"
                          defaultValue={v.service_id ?? ""}
                          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                        >
                          <option value="">اختر خدمة</option>
                          {services.map((s) => (
                            <option key={s.id} value={s.id}>
                              {s.name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="sm:col-span-1">
                        <label className="block text-xs text-muted mb-1">المعالجة</label>
                        <textarea
                          name="notes"
                          defaultValue={v.notes ?? ""}
                          rows={2}
                          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary resize-y"
                        />
                      </div>
                      <div className="flex gap-2">
                        <button
                          type="submit"
                          disabled={isPending}
                          className="rounded-md bg-primary text-white px-3 py-1.5 text-sm font-medium hover:bg-primary-dark disabled:opacity-60"
                        >
                          حفظ
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingId(null)}
                          disabled={isPending}
                          className="rounded-md border border-border px-3 py-1.5 text-sm hover:bg-primary-soft disabled:opacity-60"
                        >
                          إلغاء
                        </button>
                      </div>
                    </form>
                  </td>
                </tr>
              );
            }

            return (
              <tr key={v.id} className="border-t border-border align-top">
                <td className="px-3 py-2 text-muted whitespace-nowrap">{v.visit_date}</td>
                <td className="px-3 py-2 break-words">{v.service_name ?? "-"}</td>
                <td className="px-3 py-2 break-words whitespace-pre-wrap">{v.notes ?? "-"}</td>
                <td className="px-3 py-2 break-words">{v.doctor_name ?? "-"}</td>
                <td className="px-3 py-2 whitespace-nowrap">
                  {editable && (
                    <button
                      type="button"
                      onClick={() => setEditingId(v.id)}
                      className="text-xs text-primary hover:underline"
                    >
                      تعديل
                    </button>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
