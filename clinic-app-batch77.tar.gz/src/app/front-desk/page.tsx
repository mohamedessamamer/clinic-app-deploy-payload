import Link from "next/link";
import { db } from "@/lib/db/client";
import DateFilterForm from "@/components/DateFilterForm";
import ExceptionalShiftButton from "@/components/ExceptionalShiftButton";
import CentralSchedule from "@/components/CentralSchedule";
import { getAllSettings, buildTimeSlots, weekdayOf } from "@/lib/settings";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getDoctorRoomIdsForDate } from "@/lib/schedule";
import { computeNeedsNewPhotosMap } from "@/lib/photo-reminder";
import { computeNeedsTreatmentMap } from "@/lib/needs-treatment";
import { getClinicToday } from "@/lib/clinic-date";
import QuickPatientSearch from "@/components/QuickPatientSearch";
import { computeConsultantReminderMap } from "@/lib/consultant-reminder";

export default async function FrontDeskPage({
  searchParams,
}: {
  searchParams: Promise<{ date?: string }>;
}) {
  const { date } = await searchParams;
  const day = date && /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : getClinicToday();
  const weekday = weekdayOf(day);

  const session = await getSession();
  const [canEditSchedule, canMarkDone, canSeeAllRooms, canCollectPayments, canEditAssistantDoctor, canSeeNeedsTreatment, canQuickAddService, canBackdateInvoice] = session
    ? await Promise.all([
        hasPermission(session.userId, session.role, "schedule_edit"),
        hasPermission(session.userId, session.role, "mark_appointment_done"),
        hasPermission(session.userId, session.role, "schedule_all_rooms"),
        hasPermission(session.userId, session.role, "collect_payments"),
        // دفعة 22: حقل "الطبيب المساعد" الاختياري جوه بوكس التحصيل — نفس صلاحية
        // سجل الزيارات بالملف الطبي.
        hasPermission(session.userId, session.role, "edit_visit_assistant_doctor").then(
          async (v) => v || (await hasPermission(session.userId, session.role, "override_visit_doctor"))
        ),
        // دفعة 27 (P2.4): تنبيه "محتاج إدخال معالجة" — للدكتور افتراضيًا.
        hasPermission(session.userId, session.role, "view_needs_treatment_reminder"),
        // دفعة 27 (P3.1): بوكس "إضافة خدمة للتحصيل" السريع (كليك يمين على اسم
        // المريض) — نفس صلاحية عرض الملف المالي نفسه.
        hasPermission(session.userId, session.role, "view_patient_billing"),
        hasPermission(session.userId, session.role, "edit_invoice_payments"),
      ])
    : [false, false, false, false, false, false, false, false];

  const rooms = await db.selectFrom("rooms").selectAll().execute();

  // لو المستخدم معهوش صلاحية "كل الغرف" وهو دكتور، الجدول المركزي بيتقيد على
  // الغرفة/الغرف اللي شيفته فيها النهاردة بس. أي دور تاني (استقبال/محاسب...) من
  // غير الصلاحية دي حالة نادرة (الأدمن يقدر يقيّدها يدويًا) فبيشوف كل الغرف برضه
  // لعدم وجود مفهوم "شيفت" له.
  const doctorRoomIds =
    !canSeeAllRooms && session?.doctorId ? await getDoctorRoomIdsForDate(session.doctorId, day) : null;
  const visibleRooms = doctorRoomIds ? rooms.filter((r) => doctorRoomIds.includes(r.id)) : rooms;

  const [patients, services, doctors, roomShiftsToday, appointmentsRaw, pendingCollectionRows, settings, exceptionalShiftsToday] = await Promise.all([
    db.selectFrom("patients").select(["id", "full_name", "file_number", "birth_date", "phone"]).orderBy("id", "desc").limit(500).execute(),
    db.selectFrom("services").select(["id", "name", "default_price", "code"]).execute(),
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).execute(),
    // أول شيفت (بالوقت) لكل غرفة ظاهرة النهاردة — عشان بوكس الحجز في الجدول
    // المركزي (CentralSchedule) يقدر يحدد صاحب شيفت أي غرفة فيها تلقائيًا.
    visibleRooms.length > 0
      ? db
          .selectFrom("doctor_weekly_shifts")
          .select(["room_id", "doctor_id", "start_time"])
          .where(
            "room_id",
            "in",
            visibleRooms.map((r) => r.id)
          )
          .where("weekday", "=", weekday)
          .orderBy("start_time")
          .execute()
      : Promise.resolve([]),
    db
      .selectFrom("appointments")
      .innerJoin("patients", "patients.id", "appointments.patient_id")
      .leftJoin("doctors", "doctors.id", "appointments.doctor_id")
      .leftJoin("services", "services.id", "appointments.pending_service_id")
      .leftJoin("services as purpose_services", "purpose_services.id", "appointments.purpose_service_id")
      .leftJoin("invoices as purpose_invoices", "purpose_invoices.id", "appointments.purpose_linked_invoice_id")
      .leftJoin("services as linked_purpose_services", "linked_purpose_services.id", "purpose_invoices.service_id")
      .select([
        "appointments.id",
        "appointments.patient_id",
        "patients.full_name as patient_name",
        "appointments.doctor_id",
        "doctors.full_name as doctor_name",
        "appointments.room_id",
        "appointments.start_time",
        "appointments.duration_minutes",
        "appointments.status",
        "appointments.reschedule_pending",
        "appointments.notes",
        "appointments.pending_service_id",
        "appointments.pending_price",
        "appointments.pending_discount_percent",
        "services.name as pending_service_name",
        "appointments.purpose_type",
        "appointments.purpose_service_id",
        "purpose_services.name as purpose_service_name",
        "purpose_services.name_en as purpose_service_name_en",
        "purpose_services.category as purpose_service_category",
        "appointments.purpose_linked_invoice_id",
        "linked_purpose_services.category as purpose_linked_service_category",
      ])
      .where("appointment_date", "=", day)
      .where("status", "!=", "cancelled")
      .orderBy("appointments.start_time")
      .execute(),
    db
      .selectFrom("collection_requests")
      .leftJoin("services", "services.id", "collection_requests.service_id")
      .select([
        "collection_requests.appointment_id",
        "collection_requests.patient_id",
        "collection_requests.service_id",
        "collection_requests.requested_amount",
        "collection_requests.requested_at",
        "services.name as service_name",
      ])
      .where("collection_requests.status", "=", "pending")
      .orderBy("collection_requests.requested_at", "desc")
      .execute(),
    getAllSettings(),
    // شفت استثنائي مسجّل لليوم/الغرف الظاهرة دي — دفعة 27. بياخد أولوية على
    // الشيفت الأسبوعي العادي في تحديد الدكتور المقترح افتراضيًا (تحت).
    visibleRooms.length > 0
      ? db
          .selectFrom("doctor_date_shifts")
          .innerJoin("doctors", "doctors.id", "doctor_date_shifts.doctor_id")
          .select(["doctor_date_shifts.room_id", "doctor_date_shifts.doctor_id", "doctors.full_name as doctor_name"])
          .where(
            "doctor_date_shifts.room_id",
            "in",
            visibleRooms.map((r) => r.id)
          )
          .where("doctor_date_shifts.shift_date", "=", day)
          .execute()
      : Promise.resolve([]),
  ]);

  // أول شيفت (بالوقت) لكل غرفة النهاردة — بيحدد صاحب الشيفت المقترح افتراضيًا
  // وقت الحجز من الجدول المركزي. الشفت الاستثنائي (لو موجود لنفس الغرفة/اليوم)
  // بياخد أولوية عليه — طلب صريح من المستخدم.
  const roomShiftDoctorIds: Record<number, number> = {};
  for (const s of roomShiftsToday) {
    if (!(s.room_id in roomShiftDoctorIds)) roomShiftDoctorIds[s.room_id] = s.doctor_id;
  }
  const exceptionalShifts: Record<number, { doctorId: number; doctorName: string }> = {};
  for (const s of exceptionalShiftsToday) {
    exceptionalShifts[s.room_id] = { doctorId: s.doctor_id, doctorName: s.doctor_name };
    roomShiftDoctorIds[s.room_id] = s.doctor_id;
  }
  const slotMinutes = Number(settings.slot_minutes);
  const timeSlots = buildTimeSlots(settings.day_start, settings.day_end, slotMinutes);

  // أي فاتورة مربوطة بالموعد (فاتورة عادية أو دفعة متابعة مرتبطة بالفاتورة الأصلية)
  // معناها أن الجانب المالي اتسجل بالفعل. لا نفلتر بالفاتورة الأصلية هنا، وإلا
  // دفعة المتابعة تظهر بالخطأ كأنها "محتاج تحصيل" مرة ثانية.
  // الموعد "تم" من غير أي فاتورة مرتبطة فقط هو المحتاج تحصيل (شوف needs_billing تحت).
  // تسجيل التحصيل
  // نفسه بقى إما من الجدول المركزي (كليك يمين/دوسة طويلة على الموعد) أو من "إضافة
  // خدمة" جوه الملف المالي للمريض (دفعة 20).
  const pendingCollectionByAppointment = new Map(pendingCollectionRows.map((row) => [row.appointment_id, row]));
  // الاحتفاظ بطلب التحصيل مع حساب المريض، لذلك يظهر على موعده التالي فقط إذا
  // كان هناك طلب صريح من الطبيب — لا علاقة له بالفواتير أو الخدمات العادية.
  const pendingCollectionByPatient = new Map<number, (typeof pendingCollectionRows)[number]>();
  for (const request of pendingCollectionRows) {
    if (!pendingCollectionByPatient.has(request.patient_id)) pendingCollectionByPatient.set(request.patient_id, request);
  }
  const reminderPatientIds = patients.map((patient) => patient.id);
  const [needsPhotosMap, consultantReminderMap] = await Promise.all([
    computeNeedsNewPhotosMap(reminderPatientIds),
    computeConsultantReminderMap(reminderPatientIds),
  ]);
  // دفعة 27 (P2.4): تنبيه "محتاج إدخال معالجة" — بيتحسب دايمًا (رخيص) لكن
  // بيوصل للواجهة بـfalse لمين معهوش صلاحية view_needs_treatment_reminder،
  // تحقق حقيقي هنا مش مجرد إخفاء في الواجهة.
  const needsTreatmentMap = canSeeNeedsTreatment
    ? await computeNeedsTreatmentMap(
        appointmentsRaw.map((a) => ({ id: a.id, patient_id: a.patient_id, appointment_date: day, status: a.status }))
      )
    : new Map<number, boolean>();

  const appointments = appointmentsRaw.map((a) => {
    const collectionRequest = pendingCollectionByAppointment.get(a.id) ?? pendingCollectionByPatient.get(a.patient_id);
    return {
    id: a.id,
    patient_id: a.patient_id,
    patient_name: a.patient_name,
    doctor_id: a.doctor_id,
    doctor_name: a.doctor_name ?? "-",
    room_id: a.room_id,
    start_time: a.start_time,
    duration_minutes: a.duration_minutes,
    status: a.status as "booked" | "attended" | "done" | "cancelled" | "no_show",
    reschedule_pending: a.reschedule_pending,
    notes: a.notes,
    // «محتاج تحصيل» هنا مخصوص لطلب الطبيب المعلّق، وليس فاتورة عادية أو
    // مجرد موعد تم من غير فاتورة.
    needs_billing: !!collectionRequest,
    pending_service_id: collectionRequest?.service_id ?? a.pending_service_id,
    pending_service_name: collectionRequest?.service_name ?? a.pending_service_name,
    pending_price: collectionRequest?.requested_amount ?? a.pending_price,
    pending_discount_percent: a.pending_discount_percent,
    collection_request_appointment_id: collectionRequest?.appointment_id ?? null,
    needs_new_photos: needsPhotosMap.get(a.patient_id) ?? false,
    needs_consultant_visit: consultantReminderMap.get(a.patient_id)?.needsConsultantVisit ?? false,
    consultant_name: consultantReminderMap.get(a.patient_id)?.consultantName ?? null,
    needs_treatment: needsTreatmentMap.get(a.id) ?? false,
    purpose_type: a.purpose_type,
    purpose_service_id: a.purpose_service_id,
    purpose_service_name: a.purpose_service_name,
    purpose_service_name_en: a.purpose_service_name_en,
    purpose_service_category: a.purpose_service_category,
    purpose_linked_invoice_id: a.purpose_linked_invoice_id,
    purpose_linked_service_category: a.purpose_linked_service_category,
  };
  });
  const statusCounts = appointments.reduce((counts, appointment) => {
    if (appointment.status !== "cancelled") counts[appointment.status] += 1;
    return counts;
  }, { booked: 0, attended: 0, done: 0, no_show: 0 } as Record<"booked" | "attended" | "done" | "no_show", number>);

  return (
    <div className="front-desk-page space-y-3">
      <div className="reception-toolbar">
        <div className="reception-toolbar-actions">
          <div className="reception-toolbar-actions-right">
            {/* أسرع طريق لتسجيل مريض جديد من نفس شاشة الاستقبال الرئيسية، من غير ما
                يحتاج يروح لصفحة "ملفات المرضى" الأول. من دفعة 21: التنقل بقى في نفس
                التاب (طلب المستخدم صراحة إن السيستم كله تاب واحد) — بعد الحفظ بيرجّع
                لملف المريض، وممكن الرجوع لجدول الاستقبال بزرار الرجوع في المتصفح أو
                لينك "الاستقبال" في القايمة العلوية. */}
            <Link
              href="/patients/new"
              className="px-2.5 py-1.5 rounded-md btn-3d-primary text-sm whitespace-nowrap"
            >
              + مريض جديد
            </Link>
            {canEditSchedule && visibleRooms.length > 0 && (
              <ExceptionalShiftButton date={day} rooms={visibleRooms} doctors={doctors} existing={exceptionalShifts} />
            )}
          </div>
          <div className="reception-toolbar-date"><DateFilterForm day={day} /></div>
          <div className="reception-toolbar-actions-left">
            <div className="reception-status-pills" aria-label="ملخص حالات اليوم">
              <span><i className="bg-sky-500" />مؤكد {statusCounts.booked}</span>
              <span><i className="bg-amber-400" />حضر {statusCounts.attended}</span>
              <span><i className="bg-emerald-500" />تم {statusCounts.done}</span>
              <span><i className="bg-rose-500" />لم يحضر {statusCounts.no_show}</span>
              <span className="reception-total-pill">الإجمالي {appointments.length}</span>
            </div>
            <QuickPatientSearch patients={patients.map((p) => ({ id:p.id, full_name:p.full_name, file_number:p.file_number }))} />
          </div>
        </div>
      </div>

      {/* الجدول المركزي: كل الغرف/العيادات في مكان واحد، بيتزامن أوتوماتيك بين أي شاشات استقبال تانية مفتوحة */}
      <section className="space-y-2">
        {visibleRooms.length === 0 ? (
          <div className="text-sm bg-danger-soft text-danger rounded-md px-3 py-2">
            مفيش شيفت أسبوعي مسجل ليك في يوم النهاردة — كلم الأدمن لو محتاج تشوف الجدول برضه.
          </div>
        ) : (
          <CentralSchedule
            date={day}
            rooms={visibleRooms}
            timeSlots={timeSlots}
            slotMinutes={slotMinutes}
            appointments={appointments}
            patients={patients.map((patient) => ({
              ...patient,
              needs_new_photos: needsPhotosMap.get(patient.id) ?? false,
              needs_consultant_visit: consultantReminderMap.get(patient.id)?.needsConsultantVisit ?? false,
              consultant_name: consultantReminderMap.get(patient.id)?.consultantName ?? null,
            }))}
            doctors={doctors}
            services={services}
            canEdit={canEditSchedule}
            canMarkDone={canMarkDone}
            canCollectPayments={canCollectPayments}
            canEditAssistantDoctor={canEditAssistantDoctor}
            isDoctorView={session?.role === "doctor"}
            showReceptionAlerts={session?.role === "reception"}
            roomShiftDoctorIds={roomShiftDoctorIds}
            canQuickAddService={canQuickAddService}
            canBackdateInvoice={canBackdateInvoice}
            showPatientSearch={false}
            showStatusSummary={false}
          />
        )}
      </section>
    </div>
  );
}
