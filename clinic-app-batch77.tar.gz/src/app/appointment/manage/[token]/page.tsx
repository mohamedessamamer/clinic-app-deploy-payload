import { getAppointmentManageState } from "@/lib/appointment-self-service";
import AppointmentManageClient from "@/components/AppointmentManageClient";

export const metadata = { title: "إدارة موعد العيادة", robots: { index: false, follow: false }, referrer: "no-referrer" as const };

export default async function AppointmentManagePage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const state = await getAppointmentManageState(token);
  return <main className="min-h-screen bg-slate-50 p-4" dir="rtl"><div className="mx-auto mt-10 max-w-xl rounded-2xl bg-white p-6 shadow-lg">
    <h1 className="mb-5 text-center text-xl font-bold">إدارة موعدك</h1>
    {state.state !== "ok" ? <p className="rounded-lg bg-red-50 p-4 text-center text-red-800">{state.state === "expired" ? "انتهت صلاحية هذا الرابط. تواصل مع الاستقبال للحصول على رابط جديد." : "الرابط غير صحيح."}</p> : <>
      <div className="mb-5 rounded-xl bg-slate-50 p-4 text-sm"><p><strong>الطبيب:</strong> {state.appointment.doctorName}</p><p><strong>الموعد الحالي:</strong> {state.appointment.date} — {state.appointment.time}</p></div>
      {state.appointment.responseStatus === "pending" ? <AppointmentManageClient token={token} /> : <p className="rounded-lg bg-emerald-50 p-4 text-center text-emerald-800">{state.appointment.responseStatus === "confirmed" ? "تم تأكيد هذا الموعد." : state.appointment.responseStatus === "reschedule_pending" ? "تم حجز الموعد الجديد مبدئيًا وهو بانتظار اعتماد الاستقبال." : "تم اعتماد الموعد المعدل."}</p>}
    </>}
  </div></main>;
}
