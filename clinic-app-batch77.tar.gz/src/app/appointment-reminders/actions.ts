"use server";

import { hasPermission } from "@/lib/permissions";
import { getSession } from "@/lib/session";
import { issueAppointmentLink } from "@/lib/appointment-self-service";

export async function createAppointmentManageLinkAction(appointmentId: number) {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "schedule_edit"))) return { ok: false, error: "غير مصرح", url: null };
  try { const result = await issueAppointmentLink(appointmentId, "manual"); return { ok: true, url: result.url }; }
  catch (error) { return { ok: false, error: error instanceof Error ? error.message : "تعذر إنشاء الرابط", url: null }; }
}
