"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getAllSettings, setSetting } from "@/lib/settings";
import { getActiveAccount, getAccountAccessToken } from "@/lib/whatsapp/store";
import { sendRescheduleConfirmationTemplate } from "@/lib/whatsapp/graph";
import { createAppointmentReminderTemplates } from "@/lib/whatsapp/graph";

const sqlNow = () => new Date().toISOString().replace("T", " ").slice(0, 19);
const waNumber = (country: string, local: string) => `${country.replace(/\D/g, "")}${local.replace(/\D/g, "").replace(/^0+/, "")}`;
async function canView() { const session = await getSession(); return session && (await hasPermission(session.userId, session.role, "view_whatsapp_reminder_report")) ? session : null; }

export async function listAppointmentReminderReportAction() {
  if (!(await canView())) return [];
  return db.selectFrom("appointment_reminders")
    .innerJoin("appointments", "appointments.id", "appointment_reminders.appointment_id")
    .innerJoin("patients", "patients.id", "appointment_reminders.patient_id")
    .innerJoin("doctors", "doctors.id", "appointments.doctor_id")
    .select(["appointment_reminders.id", "appointment_reminders.appointment_date", "appointment_reminders.response_status", "appointment_reminders.sent_at", "appointment_reminders.responded_at", "appointment_reminders.requested_date", "appointment_reminders.requested_time", "appointment_reminders.error_message", "patients.full_name as patient_name", "doctors.full_name as doctor_name", "appointments.start_time"])
    .orderBy("appointment_reminders.appointment_date", "desc").orderBy("appointments.start_time", "asc").limit(300).execute();
}

export async function getReminderSettingsAction() {
  if (!(await canView())) return null;
  const settings = await getAllSettings();
  return { time: settings.whatsapp_reminder_time, validHours: settings.whatsapp_reminder_valid_hours };
}

export async function saveReminderSettingsAction(time: string) {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "manage_whatsapp"))) return { ok: false, error: "غير مصرح" };
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) return { ok: false, error: "الوقت غير صحيح" };
  await setSetting("whatsapp_reminder_time", time);
  revalidatePath("/whatsapp");
  return { ok: true };
}

export async function createAppointmentTemplatesAction() {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "manage_whatsapp"))) return { ok: false, error: "غير مصرح" };
  const [account, settings] = await Promise.all([getActiveAccount(), getAllSettings()]);
  if (!account) return { ok: false, error: "اربط حساب واتساب أولًا." };
  try {
    await createAppointmentReminderTemplates(account.waba_id, await getAccountAccessToken(account.id), settings.clinic_public_url);
    return { ok: true };
  } catch (error) { return { ok: false, error: error instanceof Error ? error.message : "تعذر إنشاء القوالب" }; }
}

export async function approveAppointmentRescheduleAction(reminderId: number) {
  const session = await canView();
  if (!session) return { ok: false, error: "غير مصرح" };
  const reminder = await db.selectFrom("appointment_reminders")
    .innerJoin("appointments", "appointments.id", "appointment_reminders.appointment_id")
    .innerJoin("patients", "patients.id", "appointment_reminders.patient_id")
    .innerJoin("doctors", "doctors.id", "appointments.doctor_id")
    .select(["appointment_reminders.id", "appointment_reminders.response_status", "appointments.id as appointment_id", "appointments.appointment_date", "appointments.start_time", "patients.phone", "patients.phone_country_code", "doctors.full_name as doctor_name"])
    .where("appointment_reminders.id", "=", reminderId).executeTakeFirst();
  if (!reminder || reminder.response_status !== "reschedule_pending") return { ok: false, error: "طلب التعديل غير متاح." };
  const now = sqlNow();
  await db.transaction().execute(async (trx) => {
    await trx.updateTable("appointments").set({ reschedule_pending: 0 }).where("id", "=", reminder.appointment_id).execute();
    await trx.updateTable("appointment_reminders").set({ response_status: "reschedule_approved", approved_by: session.userId, approved_at: now, updated_at: now }).where("id", "=", reminder.id).execute();
  });
  let warning: string | undefined;
  if (reminder.phone) {
    try {
      const [account, settings] = await Promise.all([getActiveAccount(), getAllSettings()]);
      if (!account) throw new Error("لا يوجد حساب واتساب متصل");
      await sendRescheduleConfirmationTemplate({ phoneNumberId: account.phone_number_id, accessToken: await getAccountAccessToken(account.id), to: waNumber(reminder.phone_country_code, reminder.phone), templateName: settings.whatsapp_confirmation_template_name, language: settings.whatsapp_template_language, date: reminder.appointment_date, time: reminder.start_time.slice(0, 5), doctorName: reminder.doctor_name });
    } catch (error) { warning = `تم الاعتماد لكن تعذر إرسال رسالة التأكيد: ${error instanceof Error ? error.message : "خطأ إرسال"}`; }
  }
  revalidatePath("/whatsapp");
  return { ok: true, warning };
}
