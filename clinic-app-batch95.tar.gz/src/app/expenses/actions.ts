"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { logAdminEvent } from "@/lib/audit";
import { isExpenseCategory, monthBounds } from "@/lib/expenses";
import { getClinicToday } from "@/lib/clinic-date";
import { calculateHrPayroll, getCollectedAfterLab } from "@/lib/hr-payroll";

function text(formData: FormData, key: string) {
  return String(formData.get(key) ?? "").trim();
}

function positiveAmount(formData: FormData, key: string) {
  const value = Number(formData.get(key));
  return Number.isFinite(value) && value > 0 ? Math.round(value * 100) / 100 : null;
}

function validDate(value: string) {
  return /^\d{4}-\d{2}-\d{2}$/.test(value);
}

async function canManageExpenses() {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "manage_expenses"))) return null;
  return session;
}

function refreshExpenses() {
  revalidatePath("/expenses");
  revalidatePath("/reports");
}

export async function addExpenseAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const category = text(formData, "category");
  const title = text(formData, "title");
  const amount = positiveAmount(formData, "amount");
  const expenseDate = text(formData, "expense_date");
  if (!isExpenseCategory(category) || category === "salary" || !title || !amount || !validDate(expenseDate)) return;
  const doctorIdValue = Number(formData.get("doctor_id"));
  const patientIdValue = Number(formData.get("patient_id"));
  const serviceIdValue = Number(formData.get("service_id"));
  const isLab = category === "lab";
  if (isLab && serviceIdValue > 0) {
    const service = await db
      .selectFrom("services")
      .select(["has_lab_cost", "lab_cost"])
      .where("id", "=", serviceIdValue)
      .executeTakeFirst();
    // يمنع خصم نفس تكلفة المعمل مرتين: تلقائيًا من الخدمة ويدويًا من المصروفات.
    if (!service || (service.has_lab_cost === 1 && service.lab_cost > 0)) return;
  }
  await db
    .insertInto("expenses")
    .values({
      expense_date: expenseDate,
      category,
      title,
      payee: text(formData, "payee") || null,
      amount,
      payment_method: text(formData, "payment_method") || null,
      note: text(formData, "note") || null,
      source_type: "manual",
      source_id: null,
      template_id: null,
      doctor_id: isLab && doctorIdValue > 0 ? doctorIdValue : null,
      patient_id: isLab && patientIdValue > 0 ? patientIdValue : null,
      service_id: isLab && serviceIdValue > 0 ? serviceIdValue : null,
      affects_commission: isLab && doctorIdValue > 0 ? 1 : 0,
      created_by: session.userId,
    })
    .execute();
  refreshExpenses();
}

export async function addExpenseTemplateAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const category = text(formData, "category");
  const title = text(formData, "title");
  const amount = positiveAmount(formData, "default_amount");
  if (!isExpenseCategory(category) || category === "salary" || !title || !amount) return;
  await db
    .insertInto("expense_templates")
    .values({
      title,
      category,
      payee: text(formData, "payee") || null,
      default_amount: amount,
      note: text(formData, "note") || null,
      effective_from: validDate(text(formData, "effective_from")) ? text(formData, "effective_from") : getClinicToday(),
      effective_to: validDate(text(formData, "effective_to")) ? text(formData, "effective_to") : null,
      created_by: session.userId,
    })
    .execute();
  refreshExpenses();
}

export async function updateExpenseTemplateAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const id = Number(formData.get("template_id"));
  const category = text(formData, "category");
  const title = text(formData, "title");
  const defaultAmount = positiveAmount(formData, "default_amount");
  const effectiveFrom = text(formData, "effective_from");
  const effectiveTo = text(formData, "effective_to") || null;
  if (!Number.isInteger(id) || id <= 0 || !isExpenseCategory(category) || category === "salary" || !title || !defaultAmount || !validDate(effectiveFrom) || (effectiveTo && (!validDate(effectiveTo) || effectiveTo < effectiveFrom))) return;
  await db.updateTable("expense_templates").set({ title, category, payee: text(formData, "payee") || null, default_amount: defaultAmount, note: text(formData, "note") || null, effective_from: effectiveFrom, effective_to: effectiveTo, active: 1 }).where("id", "=", id).execute();
  refreshExpenses();
}

export async function stopExpenseTemplateAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const id = Number(formData.get("template_id"));
  if (!Number.isInteger(id) || id <= 0) return;
  await db.updateTable("expense_templates").set({ active: 0, effective_to: getClinicToday() }).where("id", "=", id).execute();
  refreshExpenses();
}

export async function deleteExpenseTemplateAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const id = Number(formData.get("template_id"));
  if (!Number.isInteger(id) || id <= 0) return;
  const used = await db.selectFrom("expenses").select("id").where("template_id", "=", id).executeTakeFirst();
  if (used) await db.updateTable("expense_templates").set({ active: 0, effective_to: getClinicToday() }).where("id", "=", id).execute();
  else await db.deleteFrom("expense_templates").where("id", "=", id).execute();
  refreshExpenses();
}

export async function recordExpenseTemplateAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const templateId = Number(formData.get("template_id"));
  const expenseDate = text(formData, "expense_date");
  if (!Number.isInteger(templateId) || templateId <= 0 || !validDate(expenseDate)) return;
  const [template, range] = await Promise.all([
    db.selectFrom("expense_templates").selectAll().where("id", "=", templateId).where("active", "=", 1).executeTakeFirst(),
    Promise.resolve(monthBounds(expenseDate.slice(0, 7))),
  ]);
  if (!template || !range) return;
  const existing = await db
    .selectFrom("expenses")
    .select("id")
    .where("template_id", "=", template.id)
    .where("expense_date", ">=", range.from)
    .where("expense_date", "<=", range.to)
    .executeTakeFirst();
  if (existing) return;
  await db
    .insertInto("expenses")
    .values({
      expense_date: expenseDate,
      category: template.category,
      title: template.title,
      payee: template.payee,
      amount: template.default_amount,
      payment_method: text(formData, "payment_method") || "cash",
      note: template.note,
      source_type: "template",
      source_id: null,
      template_id: template.id,
      doctor_id: null,
      patient_id: null,
      service_id: null,
      affects_commission: 0,
      created_by: session.userId,
    })
    .execute();
  refreshExpenses();
}

async function hrRuleAndPerson(personType: "doctor" | "staff", personId: number) {
  const rule = await db.selectFrom("hr_compensation_rules").selectAll().where("person_type", "=", personType).where("person_id", "=", personId).where("active", "=", 1).executeTakeFirst();
  if (!rule) return null;
  const person = personType === "doctor"
    ? await db.selectFrom("doctors").select("full_name").where("id", "=", personId).executeTakeFirst()
    : await db.selectFrom("hr_staff").select("full_name").where("id", "=", personId).executeTakeFirst();
  return person ? { rule, personName: person.full_name } : null;
}

async function calculateHrValues(personType: "doctor" | "staff", personId: number, from: string, to: string, shiftCount: number) {
  const data = await hrRuleAndPerson(personType, personId);
  if (!data || data.rule.effective_from > to || (data.rule.effective_to && data.rule.effective_to < from)) return null;
  const doctorId = data.rule.percentage_basis === "personal" && personType === "doctor" ? personId : null;
  const collected = await getCollectedAfterLab(from, to, doctorId);
  return { ...data, collected, payroll: calculateHrPayroll(data.rule, collected.netCollected, shiftCount) };
}

export async function createOrRefreshHrPayrollRunAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const personType = text(formData, "person_type") as "doctor" | "staff";
  const personId = Number(formData.get("person_id"));
  const from = text(formData, "period_from");
  const to = text(formData, "period_to");
  const shiftCount = nonNegativeAmount(formData, "shift_count") ?? 0;
  const incentives = nonNegativeAmount(formData, "incentives") ?? 0;
  const deductions = nonNegativeAmount(formData, "deductions") ?? 0;
  if (!["doctor", "staff"].includes(personType) || !Number.isInteger(personId) || personId <= 0 || !validDate(from) || !validDate(to) || to < from) return;
  const values = await calculateHrValues(personType, personId, from, to, shiftCount);
  if (!values) return;
  const existing = await db.selectFrom("hr_payroll_runs").select(["id", "status"]).where("person_type", "=", personType).where("person_id", "=", personId).where("period_from", "=", from).where("period_to", "=", to).executeTakeFirst();
  if (existing?.status === "paid") return;
  const snapshot = {
    person_name: values.personName, staff_group: values.rule.staff_group, shift_count: shiftCount,
    fixed_amount: values.payroll.baseAmount, percentage_basis: values.rule.percentage_basis,
    percentage_mode: values.rule.percentage_mode, percentage: values.rule.percentage,
    gross_collected: values.collected.grossCollected, lab_cost: values.collected.labCost,
    net_collected: values.collected.netCollected, percentage_amount: values.payroll.percentageAmount,
    incentives, deductions, total_amount: Math.max(0, Math.round((values.payroll.totalAmount + incentives - deductions) * 100) / 100), status: "draft" as const, created_by: session.userId,
  };
  if (existing) await db.updateTable("hr_payroll_runs").set(snapshot).where("id", "=", existing.id).execute();
  else await db.insertInto("hr_payroll_runs").values({ person_type: personType, person_id: personId, period_from: from, period_to: to, paid_date: null, expense_id: null, paid_by: null, ...snapshot }).execute();
  refreshExpenses();
}

export async function payHrPayrollRunAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const runId = Number(formData.get("payroll_run_id"));
  const paidDate = text(formData, "paid_date") || getClinicToday();
  if (!Number.isInteger(runId) || runId <= 0 || !validDate(paidDate)) return;
  await db.transaction().execute(async (trx) => {
    const run = await trx.selectFrom("hr_payroll_runs").selectAll().where("id", "=", runId).executeTakeFirst();
    if (!run || run.status === "paid" || run.total_amount <= 0) return;
    const inserted = await trx.insertInto("expenses").values({ expense_date: paidDate, category: "salary", title: `استحقاق ${run.person_name} — ${run.period_from} إلى ${run.period_to}`, payee: run.person_name, amount: run.total_amount, payment_method: text(formData, "payment_method") || "cash", note: "تم إنشاؤه من كشف HR", source_type: "hr_payroll", source_id: run.id, template_id: null, doctor_id: run.person_type === "doctor" ? run.person_id : null, patient_id: null, service_id: null, affects_commission: 0, created_by: session.userId }).executeTakeFirstOrThrow();
    await trx.updateTable("hr_payroll_runs").set({ status: "paid", paid_date: paidDate, expense_id: Number(inserted.insertId), paid_by: session.userId }).where("id", "=", run.id).execute();
  });
  refreshExpenses();
}

export async function payAllHrPayrollRunsAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const from = text(formData, "period_from");
  const to = text(formData, "period_to");
  const paidDate = text(formData, "paid_date") || getClinicToday();
  const paymentMethod = text(formData, "payment_method") || "cash";
  if (!validDate(from) || !validDate(to) || !validDate(paidDate) || to < from) return;
  await db.transaction().execute(async (trx) => {
    const runs = await trx.selectFrom("hr_payroll_runs").selectAll().where("period_from", "=", from).where("period_to", "=", to).where("status", "=", "draft").execute();
    for (const run of runs) {
      if (run.total_amount <= 0) continue;
      const inserted = await trx.insertInto("expenses").values({ expense_date: paidDate, category: "salary", title: `استحقاق ${run.person_name} — ${run.period_from} إلى ${run.period_to}`, payee: run.person_name, amount: run.total_amount, payment_method: paymentMethod, note: "تم إنشاؤه من كشف HR", source_type: "hr_payroll", source_id: run.id, template_id: null, doctor_id: run.person_type === "doctor" ? run.person_id : null, patient_id: null, service_id: null, affects_commission: 0, created_by: session.userId }).executeTakeFirstOrThrow();
      await trx.updateTable("hr_payroll_runs").set({ status: "paid", paid_date: paidDate, expense_id: Number(inserted.insertId), paid_by: session.userId }).where("id", "=", run.id).execute();
    }
  });
  refreshExpenses();
}

export async function deleteExpenseAction(formData: FormData): Promise<{ ok: boolean; reason?: string }> {
  const session = await canManageExpenses();
  if (!session) return { ok: false, reason: "مفيش صلاحية لإدارة المصروفات." };
  const id = Number(formData.get("expense_id"));
  if (!Number.isInteger(id) || id <= 0) return { ok: false, reason: "بيان المصروف غير صالح." };
  const expense = await db.selectFrom("expenses").select(["id", "source_type", "category", "amount", "expense_date"]).where("id", "=", id).executeTakeFirst();
  if (!expense) return { ok: false, reason: "المصروف غير موجود." };
  if (expense.source_type === "inventory_supply") {
    return { ok: false, reason: "هذا المصروف جاء من توريد مخزن؛ صحّح التوريد من المخزن حتى يظل الجرد والتقارير متطابقين." };
  }
  if (expense.source_type === "doctor_payroll") {
    return { ok: false, reason: "هذا المصروف جاء من كشف راتب طبيب؛ صحّح كشف الراتب حتى يظل الاستحقاق والمصروف متطابقين." };
  }
  if (expense.source_type === "hr_payroll") {
    return { ok: false, reason: "هذا المصروف جاء من كشف HR؛ صحّح كشف الراتب حتى يظل الاستحقاق والمصروف متطابقين." };
  }
  await db.deleteFrom("expenses").where("id", "=", id).execute();
  await logAdminEvent({
    entityType: "expense", entityId: id, event: "delete_expense",
    details: `حذف مصروف: ${expense.category} بمبلغ ${expense.amount} بتاريخ ${expense.expense_date}`,
    changedBy: session.userId,
  });
  refreshExpenses();
  return { ok: true };
}

function nonNegativeAmount(formData: FormData, key: string) {
  const value = Number(formData.get(key));
  return Number.isFinite(value) && value >= 0 ? Math.round(value * 100) / 100 : null;
}

// مسح بيانات شاشة المصروفات (المصروفات وكشوف رواتب HR) لفترة محددة فقط —
// وليس كل تاريخ العيادة. صلاحية منفصلة عن manage_expenses لأنه إجراء غير قابل
// للتراجع؛ افتراضيًا للأدمن فقط، يُستخدم لتصفير بيانات تجريبية بفترة معينة.
// قواعد الرواتب في hr_compensation_rules والبنود المتكررة لا تُمسان هنا؛ لكل
// منهما زر حذف مستقل خاص به في نفس الشاشة.
export async function clearExpensesDataAction(formData: FormData): Promise<{ ok: boolean; reason?: string; deletedExpenses?: number; deletedPayrollRuns?: number }> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "clear_expenses_data"))) {
    return { ok: false, reason: "مفيش صلاحية عندك لمسح بيانات المصروفات." };
  }
  const from = text(formData, "from");
  const to = text(formData, "to");
  if (!validDate(from) || !validDate(to) || to < from) {
    return { ok: false, reason: "الفترة غير صحيحة." };
  }
  const { deletedExpenses, deletedPayrollRuns } = await db.transaction().execute(async (trx) => {
    const expenseRows = await trx.selectFrom("expenses").select("id").where("expense_date", ">=", from).where("expense_date", "<=", to).execute();
    const expenseIds = expenseRows.map((row) => row.id);
    // لازم نمسح أي hr_payroll_runs بتشاور على المصروفات دي أولاً (سواء كانت
    // فترة الكشف نفسها داخل from/to، أو كانت من فترة تانية بس اتصرفت فيها
    // بمصروف تاريخه داخل الفترة المختارة) حتى ما تنكسر قيود المفاتيح الأجنبية.
    const deletedRuns = await trx.deleteFrom("hr_payroll_runs").where((eb) => {
      const conditions = [eb.and([eb("period_from", ">=", from), eb("period_to", "<=", to)])];
      if (expenseIds.length) conditions.push(eb("expense_id", "in", expenseIds));
      return eb.or(conditions);
    }).executeTakeFirst();
    if (expenseIds.length) await trx.deleteFrom("expenses").where("id", "in", expenseIds).execute();
    return { deletedExpenses: expenseIds.length, deletedPayrollRuns: Number(deletedRuns?.numDeletedRows ?? 0) };
  });
  // مسح بيانات فعلي ولا يمكن التراجع عنه — لازم يفضل له أثر.
  await logAdminEvent({
    entityType: "expenses", entityId: 0, event: "clear_expenses_data",
    details: `مسح ${deletedExpenses} مصروف و${deletedPayrollRuns} كشف راتب للفترة ${from} → ${to}`,
    changedBy: session.userId,
  });
  refreshExpenses();
  return { ok: true, deletedExpenses, deletedPayrollRuns };
}
