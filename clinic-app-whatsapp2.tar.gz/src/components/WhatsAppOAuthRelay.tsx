"use client";

import { useEffect } from "react";

// نافذة الـEmbedded Signup بترجع فعليًا لهذا الدومين (redirect_uri المسجّل في
// Meta هو https://clinicsys.revereeg.com/ — الصفحة الرئيسية بالظبط)، محمّلة بـ
// ?code=...&state=... في الرابط. المكوّن ده بيتحمّل في كل صفحات السيستم (شوف
// layout.tsx) وبيتأكد أول حاجة: هل النافذة دي مفتوحة من نافذة تانية (popup) ومعاها
// state بادئته wa_signup_ (شوف WhatsAppConnectButton.tsx) — لو أيوة، يبعت الكود
// لنافذة الأب عن طريق postMessage ويقفل نفسه فورًا، من غير ما يأثر على أي استخدام
// عادي تاني للصفحة الرئيسية.
export default function WhatsAppOAuthRelay() {
  useEffect(() => {
    if (!window.opener) return;
    const params = new URLSearchParams(window.location.search);
    const code = params.get("code");
    const state = params.get("state");
    if (!code || !state || !state.startsWith("wa_signup_")) return;

    window.opener.postMessage({ type: "WA_SIGNUP_OAUTH_CODE", code, state }, window.location.origin);
    window.close();
  }, []);

  return null;
}
