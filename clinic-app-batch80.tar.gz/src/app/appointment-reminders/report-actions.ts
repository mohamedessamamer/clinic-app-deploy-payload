"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getAllSettings, setSetting } from "@/lib/settings";
import { getActiveAccount, getAccountAccessToken } from "@/lib/whatsapp/store";
import { sendRescheduleConfirmationTemplate } from "@/lib/whatsapp/graph";
import { createAppointmentReminderTemplates } from "@/lib/whatsapp/graph";
import { sendAppointmentReminderTemplate } from "@/lib/whatsapp/graph";
import { hashAppointmentToken, issueAppointmentLink } from "@/lib/appointment-self-service";
import { getClinicToday } from "@/lib/clinic-date";
import { formatArabicAppointmentDate, formatArabicAppointmentTime } from "@/lib/whatsapp/manual-templates";
import { prepareManualTemplateForAppointmentAction } from "@/app/whatsapp/actions";

const sqlNow = () => new Date().toISOString().replace("T", " ").slice(0, 19);
const waNumber = (country: string, local: string) => `${country.replace(/\D/g, "")}${local.replace(/\D/g, "").replace(/^0+/, "")}`;
type ManualTomorrowRow = { appointmentId: number; reminderId: number | null; patientName: string; doctorName: string; date: string; time: string; status: string; requestedDate: string | null; requestedTime: string | null; whatsappUrl: string | null };
async function canView() { const session = await getSession(); return session && (await hasPermission(session.userId, session.role, "view_whatsapp_reminder_report")) ? session : null; }
async function canUse(permission: Parameters<typeof hasPermission>[2]) {
  const session = await getSession();
  return session && (await hasPermission(session.userId, session.role, permission)) ? session : null;
}
const nextDay = (date: string) => { const [year, month, day] = date.split("-").map(Number); return new Date(Date.UTC(year, month - 1, day + 1)).toISOString().slice(0, 10); };

export async function listAppointmentReminderReportAction() {
  if (!(await canView())) return [];
  const tomorrow = nextDay(getClinicToday());
  return db.selectFrom("appointment_reminders")
    .innerJoin("appointments", "appointments.id", "appointment_reminders.appointment_id")
    .innerJoin("patients", "patients.id", "appointment_reminders.patient_id")
    .innerJoin("doctors", "doctors.id", "appointments.doctor_id")
    .select(["appointment_reminders.id", "appointment_reminders.appointment_date", "appointment_reminders.response_status", "appointment_reminders.sent_at", "appointment_reminders.responded_at", "appointment_reminders.requested_date", "appointment_reminders.requested_time", "appointment_reminders.error_message", "patients.full_name as patient_name", "doctors.full_name as doctor_name", "appointments.start_time"])
    .where("appointment_reminders.appointment_date", "=", tomorrow)
    .orderBy("appointments.start_time", "asc").limit(300).execute();
}

export async function getReminderSettingsAction() {
  if (!(await canUse("whatsapp_automation"))) return null;
  const settings = await getAllSettings();
  return { time: settings.whatsapp_reminder_time, validHours: settings.whatsapp_reminder_valid_hours };
}

export async function saveReminderSettingsAction(time: string) {
  const session = await canUse("whatsapp_automation");
  if (!session) return { ok: false, error: "غير مصرح" };
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) return { ok: false, error: "الوقت غير صحيح" };
  await setSetting("whatsapp_reminder_time", time);
  revalidatePath("/whatsapp");
  return { ok: true };
}

export async function createAppointmentTemplatesAction() {
  const session = await canUse("whatsapp_meta_templates");
  if (!session) return { ok: false, error: "غير مصرح" };
  const [account, settings] = await Promise.all([getActiveAccount(), getAllSettings()]);
  if (!account) return { ok: false, error: "اربط حساب واتساب أولًا." };
  try {
    await createAppointmentReminderTemplates(account.waba_id, await getAccountAccessToken(account.id), settings.clinic_public_url);
    return { ok: true };
  } catch (error) { return { ok: false, error: error instanceof Error ? error.message : "تعذر إنشاء القوالب" }; }
}

export async function approveAppointmentRescheduleAction(reminderId: number) {
  const session = await canView();
  if (!session) return { ok: false, error: "غير مصرح" };
  const reminder = await db.selectFrom("appointment_reminders")
    .innerJoin("appointments", "appointments.id", "appointment_reminders.appointment_id")
    .innerJoin("patients", "patients.id", "appointment_reminders.patient_id")
    .innerJoin("doctors", "doctors.id", "appointments.doctor_id")
    .select(["appointment_reminders.id", "appointment_reminders.response_status", "appointments.id as appointment_id", "appointments.appointment_date", "appointments.start_time", "patients.phone", "patients.phone_country_code", "doctors.full_name as doctor_name"])
    .where("appointment_reminders.id", "=", reminderId).executeTakeFirst();
  if (!reminder || reminder.response_status !== "reschedule_pending") return { ok: false, error: "طلب التعديل غير متاح." };
  const now = sqlNow();
  await db.transaction().execute(async (trx) => {
    await trx.updateTable("appointments").set({ reschedule_pending: 0, confirmed_at: now }).where("id", "=", reminder.appointment_id).execute();
    await trx.updateTable("appointment_reminders").set({ response_status: "reschedule_approved", approved_by: session.userId, approved_at: now, updated_at: now }).where("id", "=", reminder.id).execute();
  });
  let warning: string | undefined;
  if (reminder.phone) {
    try {
      const [account, settings] = await Promise.all([getActiveAccount(), getAllSettings()]);
      if (!account) throw new Error("لا يوجد حساب واتساب متصل");
      await sendRescheduleConfirmationTemplate({ phoneNumberId: account.phone_number_id, accessToken: await getAccountAccessToken(account.id), to: waNumber(reminder.phone_country_code, reminder.phone), templateName: settings.whatsapp_confirmation_template_name, language: settings.whatsapp_template_language, date: formatArabicAppointmentDate(reminder.appointment_date), time: formatArabicAppointmentTime(reminder.start_time), doctorName: reminder.doctor_name });
    } catch (error) { warning = `تم الاعتماد لكن تعذر إرسال رسالة التأكيد: ${error instanceof Error ? error.message : "خطأ إرسال"}`; }
  }
  revalidatePath("/whatsapp");
  return { ok: true, warning };
}

export async function approveAppointmentRescheduleByAppointmentAction(appointmentId: number) {
  const session = await canView();
  if (!session) return { ok: false, error: "غير مصرح" };
  const reminder = await db.selectFrom("appointment_reminders").select("id").where("appointment_id", "=", appointmentId).where("response_status", "=", "reschedule_pending").orderBy("id", "desc").executeTakeFirst();
  if (!reminder) return { ok: false, error: "لا يوجد تعديل ينتظر الاعتماد." };
  return approveAppointmentRescheduleAction(reminder.id);
}

export async function sendTomorrowConfirmationsAction() {
  const session = await canUse("whatsapp_automation");
  if (!session) return { ok: false, error: "غير مصرح", sent: 0, skipped: 0, failed: 0 };
  const [account, settings] = await Promise.all([getActiveAccount(), getAllSettings()]);
  if (!account) return { ok: false, error: "لا يوجد حساب واتساب متصل. استخدم الإرسال اليدوي.", sent: 0, skipped: 0, failed: 0 };
  const date = nextDay(getClinicToday());
  const appointments = await db.selectFrom("appointments")
    .innerJoin("patients", "patients.id", "appointments.patient_id")
    .innerJoin("doctors", "doctors.id", "appointments.doctor_id")
    .select(["appointments.id", "appointments.start_time", "appointments.confirmed_at", "appointments.reschedule_pending", "patients.full_name as patient_name", "patients.phone", "patients.phone_country_code", "doctors.full_name as doctor_name"])
    .where("appointments.appointment_date", "=", date).where("appointments.status", "=", "booked").where("appointments.reschedule_pending", "=", 0).orderBy("appointments.start_time").execute();
  const accessToken = await getAccountAccessToken(account.id);
  let sent = 0, skipped = 0, failed = 0;
  for (const appointment of appointments) {
    const existing = await db.selectFrom("appointment_reminders").select(["response_status", "sent_at"]).where("appointment_id", "=", appointment.id).where("appointment_date", "=", date).executeTakeFirst();
    if (appointment.confirmed_at || existing?.response_status === "confirmed" || existing?.response_status === "reschedule_approved" || (existing?.response_status === "pending" && existing.sent_at)) { skipped++; continue; }
    const issued = await issueAppointmentLink(appointment.id, "automatic");
    const tokenHash = hashAppointmentToken(issued.rawToken);
    if (!appointment.phone) {
      failed++;
      await db.updateTable("appointment_reminders").set({ response_status: "send_failed", send_attempts: 1, last_attempt_at: sqlNow(), error_message: "لا يوجد رقم هاتف مسجل للمريض", updated_at: sqlNow() }).where("token_hash", "=", tokenHash).execute();
      continue;
    }
    try {
      await sendAppointmentReminderTemplate({ phoneNumberId: account.phone_number_id, accessToken, to: waNumber(appointment.phone_country_code, appointment.phone), templateName: settings.whatsapp_reminder_template_name, language: settings.whatsapp_template_language, patientName: appointment.patient_name, date: formatArabicAppointmentDate(date), time: formatArabicAppointmentTime(appointment.start_time), doctorName: appointment.doctor_name, token: issued.rawToken });
      sent++;
      await db.updateTable("appointment_reminders").set({ response_status: "pending", sent_at: sqlNow(), send_attempts: 1, last_attempt_at: sqlNow(), error_message: null, updated_at: sqlNow() }).where("token_hash", "=", tokenHash).execute();
    } catch (error) {
      failed++;
      await db.updateTable("appointment_reminders").set({ response_status: "send_failed", send_attempts: 1, last_attempt_at: sqlNow(), error_message: error instanceof Error ? error.message.slice(0, 500) : "فشل الإرسال", updated_at: sqlNow() }).where("token_hash", "=", tokenHash).execute();
    }
  }
  revalidatePath("/whatsapp");
  return { ok: true, sent, skipped, failed };
}

export async function prepareTomorrowManualConfirmationsAction(templateId?: number) {
  const session = await canUse("whatsapp_manual_send");
  if (!session) return { ok: false, error: "غير مصرح", rows: [] as ManualTomorrowRow[] };
  const date = nextDay(getClinicToday());
  const appointments = await db.selectFrom("appointments")
    .innerJoin("patients", "patients.id", "appointments.patient_id")
    .innerJoin("doctors", "doctors.id", "appointments.doctor_id")
    .select(["appointments.id", "appointments.start_time", "appointments.confirmed_at", "appointments.reschedule_pending", "patients.full_name as patient_name", "patients.phone", "patients.phone_country_code", "doctors.full_name as doctor_name"])
    .where("appointments.appointment_date", "=", date).where("appointments.status", "=", "booked").orderBy("appointments.start_time").execute();
  const selectedTemplate = templateId
    ? await db.selectFrom("whatsapp_manual_templates").select(["id", "name", "quick_slot"]).where("id", "=", templateId).where("active", "=", 1).executeTakeFirst()
    : await db.selectFrom("whatsapp_manual_templates").select(["id", "name", "quick_slot"]).where("active", "=", 1).orderBy("quick_slot", "asc").executeTakeFirst();
  const isConfirmationTemplate = selectedTemplate?.quick_slot === 1 || /تأكيد.*موعد|موعد.*تأكيد/.test(selectedTemplate?.name || "");
  const rows: ManualTomorrowRow[] = [];
  for (const appointment of appointments) {
    const reminder = await db.selectFrom("appointment_reminders").select(["id", "response_status", "sent_at", "requested_date", "requested_time"]).where("appointment_id", "=", appointment.id).where("appointment_date", "=", date).orderBy("id", "desc").executeTakeFirst();
    const status = appointment.confirmed_at || reminder?.response_status === "confirmed" || reminder?.response_status === "reschedule_approved" ? "confirmed" : appointment.reschedule_pending === 1 || reminder?.response_status === "reschedule_pending" ? "reschedule_pending" : reminder?.response_status === "send_failed" ? "send_failed" : reminder?.sent_at ? "no_response" : !appointment.phone ? "no_phone" : "not_sent";
    const canPrepare = !!appointment.phone && !!selectedTemplate?.id && (!isConfirmationTemplate || status === "not_sent");
    const prepared = canPrepare ? await prepareManualTemplateForAppointmentAction(appointment.id, selectedTemplate.id) : null;
    rows.push({ appointmentId: appointment.id, reminderId: reminder?.id ?? null, patientName: appointment.patient_name, doctorName: appointment.doctor_name, date, time: formatArabicAppointmentTime(appointment.start_time), status, requestedDate: reminder?.requested_date ?? null, requestedTime: reminder?.requested_time ? formatArabicAppointmentTime(reminder.requested_time) : null, whatsappUrl: prepared?.ok && prepared.whatsappUrl ? prepared.whatsappUrl : null });
  }
  return { ok: true, rows };
}
