"use server";

import { revalidatePath } from "next/cache";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import * as graph from "@/lib/whatsapp/graph";
import * as store from "@/lib/whatsapp/store";
import { db } from "@/lib/db/client";
import type { PermissionKey } from "@/lib/permission-defs";
import { issueAppointmentLink } from "@/lib/appointment-self-service";
import { renderManualTemplate } from "@/lib/whatsapp/manual-templates";

async function requireWhatsappAccess() {
  const session = await getSession();
  if (!session) return null;
  if (!(await hasPermission(session.userId, session.role, "manage_whatsapp"))) return null;
  return session;
}

async function requireAnyPermission(keys: PermissionKey[]) {
  const session = await getSession();
  if (!session) return null;
  for (const key of keys) if (await hasPermission(session.userId, session.role, key)) return session;
  return null;
}

// خطوة إكمال Embedded Signup: الـfrontend (WhatsAppConnectButton) بيستقبل
// { code, wabaId, phoneNumberId, businessId } من نافذة واتساب (postMessage) وبيبعتهم
// هنا. السيرفر بس هو اللي بيعمل تبادل الـcode بتوكن فعلي (client secret لازم
// يفضل سيرفر بس)، ثم يشترك في أحداث الـWABA، ثم يخزّن الحساب مشفّرًا.
//
// coexistence: true لو ده رقم العيادة الحقيقي متصل عن طريق WhatsApp Business
// App Coexistence (المستخدم أكّد صراحة إنه عايز كده)، false لو رقم Meta
// التجريبي وقت التطوير/المراجعة. الـcaller (الزرار في الواجهة) هو اللي بيحدد
// القيمة دي بناءً على اختيار واضح للمستخدم — مفيش تخمين هنا.
export async function completeEmbeddedSignupAction(params: {
  code: string;
  wabaId: string;
  phoneNumberId: string;
  businessId?: string;
  coexistence: boolean;
  environment: "test" | "production";
}) {
  const session = await requireAnyPermission(["whatsapp_meta_connection", "manage_whatsapp"]);
  if (!session) return { ok: false, error: "غير مصرح" };

  try {
    const tokenResult = await graph.exchangeCodeForToken(params.code);
    const accessToken = tokenResult.access_token;

    await graph.subscribeAppToWaba(params.wabaId, accessToken);

    let displayNumber: string | null = null;
    let verifiedName: string | null = null;
    try {
      const phones = await graph.getWabaPhoneNumbers(params.wabaId, accessToken);
      const match = phones.data.find((p) => p.id === params.phoneNumberId);
      displayNumber = match?.display_phone_number ?? null;
      verifiedName = match?.verified_name ?? null;
    } catch {
      // مش حرج — الربط نجح والاشتراك في الأحداث حصل، بيانات العرض دي تجميلية بس.
    }

    await store.upsertAccountFromSignup({
      wabaId: params.wabaId,
      phoneNumberId: params.phoneNumberId,
      displayPhoneNumber: displayNumber,
      verifiedName,
      businessId: params.businessId ?? null,
      accessToken,
      coexistence: params.coexistence,
      environment: params.environment,
      connectedBy: session.userId,
    });

    revalidatePath("/whatsapp");
    return { ok: true };
  } catch (err) {
    // رسالة الخطأ بترجع للواجهة (مفيدة للمستخدم) لكن أي حاجة شبه توكن اتفلترت
    // فعليًا من رسائل graph.ts نفسها (بترجع رسالة Meta المنظمة بس، مش أي header).
    const message = err instanceof Error ? err.message : "فشل ربط واتساب";
    return { ok: false, error: message };
  }
}

// ربط يدوي لرقم Meta التجريبي — بلاش Embedded Signup خالص هنا: رقم الاختبار
// (+1 555...) مش رقم حقيقي أصلاً، مبيقدرش يستقبل SMS تحقق، فخطوة "Verify your
// phone number" في نافذة الـsignup هتفشل معاه دايمًا (ده اللي حصل). لكن Meta
// أصلاً بتديك WABA ID وPhone Number ID وaccess token مباشرة من صفحة
// "API Setup > Try it out" — مفيش داعي لأي OAuth؛ بس نخزنهم إحنا هنا.
// ملحوظة: التوكن اللي بييجي من "Generate token" في الصفحة دي بيكون مؤقت
// (24 ساعة عادةً) — يكفي تمامًا لاختبار الإرسال/الاستقبال والويبهوك دلوقتي.
export async function connectTestAccountManuallyAction(formData: FormData) {
  const session = await requireAnyPermission(["whatsapp_meta_connection", "manage_whatsapp"]);
  if (!session) return { ok: false, error: "غير مصرح" };
  const wabaId = String(formData.get("waba_id") ?? "").trim();
  const phoneNumberId = String(formData.get("phone_number_id") ?? "").trim();
  const accessToken = String(formData.get("access_token") ?? "").trim();
  if (!wabaId || !phoneNumberId || !accessToken) {
    return { ok: false, error: "لازم تدخل WABA ID وPhone Number ID وAccess token" };
  }

  try {
    // بنتأكد إن التوكن شغال فعلاً قبل ما نخزنه، عن طريق محاولة الاشتراك في
    // أحداث الويبهوك لنفس الـWABA (نفس اللي بيحصل بعد Embedded Signup عادي).
    await graph.subscribeAppToWaba(wabaId, accessToken);

    let displayNumber: string | null = null;
    let verifiedName: string | null = null;
    try {
      const phones = await graph.getWabaPhoneNumbers(wabaId, accessToken);
      const match = phones.data.find((p) => p.id === phoneNumberId);
      displayNumber = match?.display_phone_number ?? null;
      verifiedName = match?.verified_name ?? null;
    } catch {
      // تجميلي بس.
    }

    await store.upsertAccountFromSignup({
      wabaId,
      phoneNumberId,
      displayPhoneNumber: displayNumber,
      verifiedName,
      businessId: null,
      accessToken,
      coexistence: false,
      environment: "test",
      connectedBy: session.userId,
    });

    revalidatePath("/whatsapp");
    return { ok: true };
  } catch (err) {
    const message = err instanceof Error ? err.message : "فشل الربط اليدوي";
    return { ok: false, error: message };
  }
}

export async function getAccountStatusAction() {
  const session = await requireAnyPermission(["whatsapp_meta_connection", "whatsapp_meta_conversations", "whatsapp_meta_templates", "whatsapp_meta_sync", "manage_whatsapp"]);
  if (!session) return null;
  const account = await store.getActiveAccount();
  if (!account) return null;
  return {
    id: account.id,
    displayPhoneNumber: account.display_phone_number,
    verifiedName: account.verified_name,
    environment: account.environment,
    coexistenceMode: account.coexistence_mode === 1,
    connectionStatus: account.connection_status,
    connectedAt: account.connected_at,
  };
}

export async function listConversationsAction() {
  const session = await requireAnyPermission(["whatsapp_meta_conversations", "manage_whatsapp"]);
  if (!session) return [];
  const account = await store.getActiveAccount();
  if (!account) return [];
  const rows = await store.listConversations(account.id);
  return rows.map((r) => ({ id: r.id, waId: r.wa_id, profileName: r.profile_name, lastMessageAt: r.last_message_at }));
}

export async function listMessagesAction(contactId: number) {
  const session = await requireAnyPermission(["whatsapp_meta_conversations", "manage_whatsapp"]);
  if (!session) return [];
  const rows = await store.listMessagesForContact(contactId);
  return rows.map((r) => ({
    id: r.id,
    direction: r.direction,
    body: r.body,
    status: r.status,
    isEcho: r.is_echo === 1,
    createdAt: r.created_at,
  }));
}

export async function sendMessageAction(formData: FormData) {
  const session = await requireAnyPermission(["whatsapp_meta_conversations", "manage_whatsapp"]);
  if (!session) return { ok: false, error: "غير مصرح" };
  const contactId = Number(formData.get("contact_id"));
  const body = String(formData.get("body") ?? "").trim();
  if (!contactId || !body) return { ok: false, error: "بيانات ناقصة" };

  const account = await store.getActiveAccount();
  if (!account) return { ok: false, error: "لا يوجد حساب واتساب متصل" };

  const contact = (await store.listConversations(account.id)).find((c) => c.id === contactId);
  if (!contact) return { ok: false, error: "المحادثة غير موجودة" };

  try {
    const accessToken = await store.getAccountAccessToken(account.id);
    const result = await graph.sendTextMessage(account.phone_number_id, accessToken, contact.wa_id, body);
    await store.recordOutboundMessage({
      accountId: account.id,
      contactId,
      wamid: result.messages?.[0]?.id ?? null,
      body,
      sentBy: session.userId,
      status: "sent",
    });
    await store.touchContactLastMessage(contactId, new Date().toISOString());
    revalidatePath("/whatsapp");
    return { ok: true };
  } catch (err) {
    const message = err instanceof Error ? err.message : "فشل الإرسال";
    await store.recordOutboundMessage({
      accountId: account.id,
      contactId,
      wamid: null,
      body,
      sentBy: session.userId,
      status: "failed",
      errorMessage: message,
    });
    revalidatePath("/whatsapp");
    return { ok: false, error: message };
  }
}

export async function listTemplatesAction() {
  const session = await requireAnyPermission(["whatsapp_meta_templates", "whatsapp_meta_sync", "manage_whatsapp"]);
  if (!session) return [];
  const account = await store.getActiveAccount();
  if (!account) return [];
  const rows = await store.listTemplateRows(account.id);
  return rows.map((r) => ({
    id: r.id,
    name: r.name,
    language: r.language,
    category: r.category,
    bodyText: r.body_text,
    status: r.status,
    rejectedReason: r.rejected_reason,
  }));
}

export async function createTemplateAction(formData: FormData) {
  const session = await requireAnyPermission(["whatsapp_meta_templates", "manage_whatsapp"]);
  if (!session) return { ok: false, error: "غير مصرح" };
  const name = String(formData.get("name") ?? "").trim().toLowerCase().replace(/[^a-z0-9_]/g, "_");
  const language = String(formData.get("language") ?? "ar");
  const category = String(formData.get("category") ?? "UTILITY");
  const bodyText = String(formData.get("body_text") ?? "").trim();
  if (!name || !bodyText) return { ok: false, error: "بيانات ناقصة" };

  const account = await store.getActiveAccount();
  if (!account) return { ok: false, error: "لا يوجد حساب واتساب متصل" };

  try {
    const accessToken = await store.getAccountAccessToken(account.id);
    const result = await graph.createMessageTemplate(account.waba_id, accessToken, { name, language, category, bodyText });
    await store.upsertTemplateRow({
      accountId: account.id,
      metaTemplateId: result.id,
      name,
      language,
      category,
      bodyText,
      status: result.status?.toLowerCase() || "pending",
      createdBy: session.userId,
    });
    revalidatePath("/whatsapp");
    return { ok: true };
  } catch (err) {
    const message = err instanceof Error ? err.message : "فشل إنشاء القالب";
    return { ok: false, error: message };
  }
}

// تحديث حالات القوالب من Meta (Approved/Rejected بتتحدد بعد المراجعة، مش وقت
// الإنشاء) — زرار "تحديث الحالة" في الواجهة بينادي عليها.
export async function refreshTemplateStatusesAction() {
  const session = await requireAnyPermission(["whatsapp_meta_sync", "manage_whatsapp"]);
  if (!session) return { ok: false, error: "غير مصرح" };
  const account = await store.getActiveAccount();
  if (!account) return { ok: false, error: "لا يوجد حساب واتساب متصل" };
  try {
    const accessToken = await store.getAccountAccessToken(account.id);
    const remote = await graph.listTemplates(account.waba_id, accessToken);
    for (const t of remote.data) {
      await store.updateTemplateStatus(account.id, t.name, t.language, t.status.toLowerCase(), t.rejected_reason);
    }
    await store.removeTemplatesMissingFromMeta(account.id, remote.data.map((t) => ({ name: t.name, language: t.language })));
    revalidatePath("/whatsapp");
    return { ok: true };
  } catch (err) {
    const message = err instanceof Error ? err.message : "فشل تحديث حالة القوالب";
    return { ok: false, error: message };
  }
}

export async function listManualTemplatesAction() {
  if (!(await requireAnyPermission(["whatsapp_manual_send", "whatsapp_manual_templates", "manage_whatsapp"]))) return [];
  return db.selectFrom("whatsapp_manual_templates").selectAll().where("active", "=", 1).orderBy("quick_slot", "asc").orderBy("name", "asc").execute();
}

export async function saveManualTemplateAction(formData: FormData) {
  const session = await requireAnyPermission(["whatsapp_manual_templates"]);
  if (!session) return { ok: false, error: "غير مصرح" };
  const id = Number(formData.get("id")) || null;
  const name = String(formData.get("name") || "").trim().slice(0, 80);
  const headerText = String(formData.get("header_text") || "").trim().slice(0, 200) || null;
  const bodyText = String(formData.get("body_text") || "").trim().slice(0, 4000);
  const recipientType = String(formData.get("recipient_type") || "patient").trim().slice(0, 50);
  const quickRaw = Number(formData.get("quick_slot"));
  const quickSlot = quickRaw >= 1 && quickRaw <= 5 ? quickRaw : null;
  const variableMap: Record<string, string> = {};
  for (let index = 1; index <= 8; index++) {
    const value = String(formData.get(`variable_${index}`) || "").trim();
    if (value) variableMap[String(index)] = value;
  }
  if (!name || !bodyText) return { ok: false, error: "اسم القالب ونص الرسالة مطلوبان" };
  await db.transaction().execute(async (trx) => {
    if (quickSlot) await trx.updateTable("whatsapp_manual_templates").set({ quick_slot: null }).where("quick_slot", "=", quickSlot).execute();
    if (id) {
      await trx.updateTable("whatsapp_manual_templates").set({ name, header_text: headerText, body_text: bodyText, recipient_type: recipientType, variable_map: JSON.stringify(variableMap), quick_slot: quickSlot, updated_at: new Date().toISOString() }).where("id", "=", id).execute();
    } else {
      await trx.insertInto("whatsapp_manual_templates").values({ name, header_text: headerText, body_text: bodyText, recipient_type: recipientType, variable_map: JSON.stringify(variableMap), quick_slot: quickSlot, created_by: session.userId }).execute();
    }
  });
  revalidatePath("/whatsapp");
  return { ok: true };
}

export async function archiveManualTemplateAction(templateId: number) {
  if (!(await requireAnyPermission(["whatsapp_manual_templates"]))) return { ok: false, error: "غير مصرح" };
  await db.updateTable("whatsapp_manual_templates").set({ active: 0, quick_slot: null, updated_at: new Date().toISOString() }).where("id", "=", templateId).execute();
  revalidatePath("/whatsapp");
  return { ok: true };
}

export async function prepareManualTemplateForAppointmentAction(appointmentId: number, templateId: number) {
  const session = await requireAnyPermission(["whatsapp_manual_send", "manage_whatsapp"]);
  if (!session) return { ok: false, error: "غير مصرح" };
  const [appointment, template, user] = await Promise.all([
    db.selectFrom("appointments").innerJoin("patients", "patients.id", "appointments.patient_id").innerJoin("doctors", "doctors.id", "appointments.doctor_id").select(["appointments.id", "appointments.appointment_date", "appointments.start_time", "patients.id as patient_id", "patients.full_name as patient_name", "patients.phone", "patients.phone_country_code", "doctors.full_name as doctor_name"]).where("appointments.id", "=", appointmentId).executeTakeFirst(),
    db.selectFrom("whatsapp_manual_templates").selectAll().where("id", "=", templateId).where("active", "=", 1).executeTakeFirst(),
    db.selectFrom("users").select(["full_name", "contact_name"]).where("id", "=", session.userId).executeTakeFirst(),
  ]);
  if (!appointment || !template) return { ok: false, error: "الموعد أو القالب غير موجود" };
  if (!appointment.phone) return { ok: false, error: "لا يوجد رقم هاتف للمريض" };
  const issued = await issueAppointmentLink(appointment.id, "manual");
  const debtRow = await db.selectFrom("invoices").select((eb) => eb.fn.sum<number>(eb("amount", "-", eb.ref("paid"))).as("debt")).where("patient_id", "=", appointment.patient_id).executeTakeFirst();
  const message = renderManualTemplate(template.header_text, template.body_text, template.variable_map, { patientName: appointment.patient_name, appointmentDate: appointment.appointment_date, appointmentTime: appointment.start_time, doctorName: appointment.doctor_name, appointmentLink: issued.url, patientDebt: Math.max(0, Number(debtRow?.debt ?? 0)), contactName: user?.contact_name || "" });
  const phone = `${appointment.phone_country_code.replace(/\D/g, "")}${appointment.phone.replace(/\D/g, "").replace(/^0+/, "")}`;
  return { ok: true, whatsappUrl: `https://wa.me/${phone}?text=${encodeURIComponent(message)}`, message };
}
