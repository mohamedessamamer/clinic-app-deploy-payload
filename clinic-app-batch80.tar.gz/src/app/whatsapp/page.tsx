import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getAccountStatusAction, listConversationsAction, listManualTemplatesAction, listTemplatesAction } from "./actions";
import WhatsAppConnectButton from "@/components/WhatsAppConnectButton";
import WhatsAppChat from "@/components/WhatsAppChat";
import WhatsAppTemplateManager from "@/components/WhatsAppTemplateManager";
import WhatsAppManualTemplates from "@/components/WhatsAppManualTemplates";
import WhatsAppReconnectToken from "@/components/WhatsAppReconnectToken";
import WhatsAppReminderSettings from "@/components/WhatsAppReminderSettings";
import { getReminderSettingsAction } from "@/app/appointment-reminders/report-actions";
import WhatsAppTomorrowSender from "@/components/WhatsAppTomorrowSender";

export default async function WhatsAppPage() {
  const session = await getSession();
  if (!session) return <div className="card-3d rounded-xl p-5 text-sm text-muted">لازم تسجل دخول عشان توصل لصفحة واتساب.</div>;
  const [canManualSend, canManualTemplates, canBulkSend, canAutomate, canMetaConnection, canMetaConversations, canMetaTemplates, canMetaSync] = await Promise.all([
    hasPermission(session.userId, session.role, "whatsapp_manual_send"), hasPermission(session.userId, session.role, "whatsapp_manual_templates"), hasPermission(session.userId, session.role, "whatsapp_bulk_send"), hasPermission(session.userId, session.role, "whatsapp_automation"), hasPermission(session.userId, session.role, "whatsapp_meta_connection"), hasPermission(session.userId, session.role, "whatsapp_meta_conversations"), hasPermission(session.userId, session.role, "whatsapp_meta_templates"), hasPermission(session.userId, session.role, "whatsapp_meta_sync"),
  ]);
  if (![canManualSend, canManualTemplates, canAutomate, canMetaConnection, canMetaConversations, canMetaTemplates, canMetaSync].some(Boolean)) return <div className="card-3d rounded-xl p-5 text-sm text-muted">مفيش صلاحية عندك لصفحة واتساب.</div>;
  const showConnection = canMetaConnection;
  const account = showConnection || canMetaConversations || canMetaTemplates ? await getAccountStatusAction() : null;
  const [conversations, metaTemplates, manualTemplates, reminderSettings] = await Promise.all([
    account && canMetaConversations ? listConversationsAction() : Promise.resolve([]),
    account && (canMetaTemplates || canMetaSync) ? listTemplatesAction() : Promise.resolve([]),
    canManualSend || canManualTemplates ? listManualTemplatesAction() : Promise.resolve([]),
    canAutomate ? getReminderSettingsAction() : Promise.resolve(null),
  ]);
  return <div className="mx-auto max-w-7xl space-y-5 p-4" dir="rtl">
    <div><h1 className="text-xl font-bold">مركز واتساب</h1><p className="mt-1 text-sm text-muted">إرسال سريع وقوالب — التقارير التشغيلية موجودة في شاشة التقارير.</p></div>
    {canManualSend && <WhatsAppTomorrowSender templates={manualTemplates.map((item) => ({ id: item.id, name: item.name, quick_slot: item.quick_slot }))} canManualSend={canManualSend} canBulkSend={canBulkSend} canAutomate={canAutomate} />}
    {(canManualSend || canManualTemplates) && <WhatsAppManualTemplates templates={manualTemplates} canManage={canManualTemplates} />}
    {canAutomate && reminderSettings && <div className="card-3d rounded-xl p-5"><h2 className="mb-3 font-semibold">الإرسال التلقائي</h2><WhatsAppReminderSettings initialTime={reminderSettings.time} canCreateMetaTemplates={canMetaTemplates} /></div>}
    {showConnection && <section className="card-3d rounded-xl p-5"><h2 className="font-semibold">Meta — اتصال واتساب العيادة</h2>{!account ? <div className="mt-3 space-y-3 text-sm"><p className="text-muted">لا يوجد حساب Meta متصل.</p><WhatsAppConnectButton /></div> : <div className="mt-3 space-y-3 text-sm"><div>الرقم: <strong>{account.displayPhoneNumber ?? "—"}</strong>{account.verifiedName ? ` (${account.verifiedName})` : ""}</div><div>الحالة: <span className={account.connectionStatus === "connected" ? "text-emerald-700" : "text-red-700"}>{account.connectionStatus}</span></div><WhatsAppReconnectToken /></div>}</section>}
    {account && canMetaConversations && <section className="card-3d rounded-xl p-5"><h2 className="mb-3 font-semibold">Meta — المحادثات</h2><WhatsAppChat conversations={conversations} /></section>}
    {account && (canMetaTemplates || canMetaSync) && <section className="card-3d rounded-xl p-5"><h2 className="mb-3 font-semibold">Meta — قوالب الرسائل</h2><WhatsAppTemplateManager templates={metaTemplates} canCreate={canMetaTemplates} canSync={canMetaSync} /></section>}
  </div>;
}
