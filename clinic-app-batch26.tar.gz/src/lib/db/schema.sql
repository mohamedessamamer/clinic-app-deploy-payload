-- Clinic Management System — SQLite schema (dev). Portable design, will map to Postgres for production.

CREATE TABLE IF NOT EXISTS doctors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- دفعة 22: ربط دكتور استشاري بدكاترة مساعدين (many-to-many) — استشاري واحد
-- ممكن يكون عنده أكتر من مساعد. doctors.is_consultant بيتضاف عن طريق
-- tryAddColumn في client.ts (عمود جديد على جدول موجود، مش هنا).
CREATE TABLE IF NOT EXISTS consultant_assistants (
  consultant_doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  assistant_doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  PRIMARY KEY (consultant_doctor_id, assistant_doctor_id)
);

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin','doctor','reception','accountant')),
  doctor_id INTEGER REFERENCES doctors(id),
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS rooms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- A shift assigns a doctor to a room for a time window on a given date.
-- Superseded by doctor_weekly_shifts below for the recurring weekly schedule (kept as-is,
-- unused by the UI now, so we don't touch any historical data in it).
CREATE TABLE IF NOT EXISTS shifts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL REFERENCES rooms(id),
  doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  shift_date TEXT NOT NULL,       -- YYYY-MM-DD
  start_time TEXT NOT NULL,       -- HH:MM
  end_time TEXT NOT NULL,         -- HH:MM
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Recurring weekly schedule: which doctor is in which room on which weekday.
-- weekday: 0=Sunday .. 6=Saturday (matches WEEKDAY_LABELS in lib/settings.ts).
CREATE TABLE IF NOT EXISTS doctor_weekly_shifts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL REFERENCES rooms(id),
  weekday INTEGER NOT NULL,
  doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  start_time TEXT NOT NULL,       -- HH:MM
  end_time TEXT NOT NULL,         -- HH:MM
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS services (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  name_en TEXT,
  category TEXT,
  default_price REAL NOT NULL DEFAULT 0,
  code TEXT,
  price_note TEXT,
  prepaid INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Which doctors are allowed to perform which service (drives the filtered doctor dropdown).
CREATE TABLE IF NOT EXISTS service_doctors (
  service_id INTEGER NOT NULL REFERENCES services(id),
  doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  PRIMARY KEY (service_id, doctor_id)
);

CREATE TABLE IF NOT EXISTS patients (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  file_number TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  age INTEGER, -- قديم/legacy — لمرضى اتسجلوا قبل ما يبقى عندنا تاريخ ميلاد. السن
               -- الجديد بيتحسب من birth_date تحت، شوف src/lib/age.ts.
  birth_date TEXT, -- تاريخ الميلاد (YYYY-MM-DD) — السن بيتحسب منه بالسنين بس.
  phone TEXT,
  address TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Appointments: future bookings, tied primarily to a room (per clinic's shift model).
-- status: booked (محجوز) -> attended (حضر ووصل العيادة) -> done (الكشف خلص).
-- cancelled (ملغي) is used to free the slot in the central schedule grid without hard-deleting
-- the row (keeps history), no_show kept for the rare case reception marks a booked patient absent.
-- duration_minutes: how many minutes the appointment occupies in the central grid (spans multiple
-- time-slot rows for long appointments); NULL/0 means "one slot" using the clinic's slot_minutes setting.
CREATE TABLE IF NOT EXISTS appointments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  room_id INTEGER NOT NULL REFERENCES rooms(id),
  doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  appointment_date TEXT NOT NULL,  -- YYYY-MM-DD
  start_time TEXT NOT NULL,        -- HH:MM
  duration_minutes INTEGER,
  status TEXT NOT NULL DEFAULT 'booked' CHECK (status IN ('booked','attended','done','cancelled','no_show')),
  notes TEXT,
  -- pending_*: لو الموعد اتسجل "تم" من حد معهوش صلاحية تحصيل المدفوعات (زي الدكتور)،
  -- بيقدر يحدد هنا الخدمة والسعر المتوقع "المطلوب دفعه" من غير ما يسجل دفع فعلي —
  -- الاستقبال بيشوفها على طول جنب "محتاج تحصيل" في الجدول، وبتتملى تلقائي في بوكس
  -- التحصيل بتاعه لما يفتحه بأثر رجعي. بتتصفّر لما التحصيل الفعلي يتسجل.
  pending_service_id INTEGER REFERENCES services(id),
  pending_price REAL,
  pending_discount_percent REAL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Visits: the row-per-visit history table shown on the patient file.
-- primary_doctor_id = who revenue is attributed to; performing_doctor_id = who actually did it (may differ).
-- appointment_id: لو الزيارة دي اتسجلت من زر "تم" في الجدول المركزي، بيربطها
-- بالموعد الأصلي (مرجع/تتبع بس، مفيش أي منطق بيعتمد عليه غير كده).
CREATE TABLE IF NOT EXISTS visits (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  visit_date TEXT NOT NULL DEFAULT (date('now')),
  service_id INTEGER REFERENCES services(id),
  notes TEXT,
  primary_doctor_id INTEGER REFERENCES doctors(id),
  performing_doctor_id INTEGER REFERENCES doctors(id),
  room_id INTEGER REFERENCES rooms(id),
  created_by INTEGER REFERENCES users(id),
  appointment_id INTEGER REFERENCES appointments(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- payment_method: طريقة تحصيل المبلغ المدفوع في الفاتورة دي (نقدي/فيزا/انستاباي)، بتتسجل
-- وقت التحصيل من بوكس الفوترة.
-- parent_invoice_id: لو الفاتورة دي "دفعة متابعة" (خدمة كودها 0)، بتشاور على الفاتورة
-- الأصلية اللي المبلغ ده بيتخصم من رصيدها — مبلغ (amount) الفاتورة دي بيفضل صفر (مفيش
-- استحقاق مستقل جديد)، وبس paid بيتسجل فيه المبلغ المحصّل في الدفعة دي، عشان يظهر صح
-- في تقرير تحصيل اليوم من غير ما يتحسب مرتين مع الفاتورة الأصلية.
-- original_price: السعر الأصلي المدخل قبل تطبيق نسبة الخصم (amount = original_price بعد
-- الخصم). بيتسجل وقت إنشاء الفاتورة عشان يظهر في تقارير الفواتير جنب المبلغ النهائي؛
-- NULL لفواتير دفعات المتابعة (amount بتاعتها صفر أصلاً، مفيش "سعر أصلي" منطقي ليها).
CREATE TABLE IF NOT EXISTS invoices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  visit_id INTEGER NOT NULL REFERENCES visits(id),
  amount REAL NOT NULL DEFAULT 0,
  paid REAL NOT NULL DEFAULT 0,
  payment_method TEXT,
  parent_invoice_id INTEGER REFERENCES invoices(id),
  original_price REAL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Patient image/x-ray gallery — grouped batches, each with a date. File storage path is a placeholder
-- for now (local disk in dev); production will point at object storage (e.g. Cloudflare R2) per the plan.
CREATE TABLE IF NOT EXISTS patient_image_groups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  label TEXT,
  taken_at TEXT NOT NULL DEFAULT (date('now')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS patient_images (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  group_id INTEGER NOT NULL REFERENCES patient_image_groups(id),
  file_path TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS inventory_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  quantity REAL NOT NULL DEFAULT 0,
  unit TEXT,
  expiry_date TEXT,
  low_stock_threshold REAL NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Clinic-wide configuration (e.g. appointment slot length in minutes).
CREATE TABLE IF NOT EXISTS clinic_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

-- Tracks manual overrides that need to show up in the end-of-day report
-- (price overridden away from the price list, doctor reassigned on a visit, ...).
CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity_type TEXT NOT NULL,
  entity_id INTEGER NOT NULL,
  field TEXT NOT NULL,
  old_value TEXT,
  new_value TEXT,
  reason TEXT,
  changed_by INTEGER REFERENCES users(id),
  changed_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Per-user permission overrides on top of the role's default permission set.
-- granted=1 explicitly grants a permission the role wouldn't normally have;
-- granted=0 explicitly revokes a permission the role would normally have.
-- Absence of a row means "use the role default" (see src/lib/permissions.ts).
CREATE TABLE IF NOT EXISTS user_permissions (
  user_id INTEGER NOT NULL REFERENCES users(id),
  permission_key TEXT NOT NULL,
  granted INTEGER NOT NULL,
  PRIMARY KEY (user_id, permission_key)
);

-- شارت تشخيص وخطة علاج التقويم — سجل واحد بس لكل مريض (يتعمل مرة واحدة وقت
-- بداية علاج التقويم)، منفصل تمامًا عن سجل الزيارات العادي (الملف الطبي العام).
-- نفس قيود تعديل الملف الطبي (دكتور + أدمن + مدير عيادة)، شوف canEditMedicalRecordFor.
-- missing_teeth / extraction_teeth: JSON array نصي لمعرّفات أسنان زي "UR6"، "LLc"
-- (شوف src/lib/dental-chart.ts) — مش أعمدة منفصلة عشان عددهم متغيّر.
CREATE TABLE IF NOT EXISTS orthodontic_charts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL UNIQUE REFERENCES patients(id),
  sex TEXT CHECK (sex IN ('male','female')),
  chief_complaint TEXT,
  past_medical_history TEXT,
  missing_teeth TEXT,
  -- Skeletal
  antero_posterior TEXT CHECK (antero_posterior IN ('class1','class2','class3')),
  facial_height TEXT CHECK (facial_height IN ('increased','average','decreased')),
  -- Dental
  mx_incisor_inclination TEXT CHECK (mx_incisor_inclination IN ('proclined','average','retroclined')),
  mn_incisor_inclination TEXT CHECK (mn_incisor_inclination IN ('proclined','average','retroclined')),
  molar_relation_right TEXT CHECK (molar_relation_right IN ('class1','class2','class3')),
  molar_relation_left TEXT CHECK (molar_relation_left IN ('class1','class2','class3')),
  overbite TEXT CHECK (overbite IN ('open_bite','average','deep_bite')),
  overjet TEXT CHECK (overjet IN ('increased','average','decreased')),
  midline_upper_direction TEXT CHECK (midline_upper_direction IN ('right','left')),
  midline_upper_mm REAL,
  midline_lower_direction TEXT CHECK (midline_lower_direction IN ('right','left')),
  midline_lower_mm REAL,
  space_upper_type TEXT CHECK (space_upper_type IN ('crowding','spacing')),
  space_upper_mm REAL,
  space_lower_type TEXT CHECK (space_lower_type IN ('crowding','spacing')),
  space_lower_mm REAL,
  -- Cephalometric (بس قيمة الحالة الفعلية — القيم القياسية "Norms" ثابتة ومعروضة في الواجهة بس)
  sna_case REAL,
  snb_case REAL,
  anb_case REAL,
  mma_case REAL,
  u1_pp_case REAL,
  l1_mp_case REAL,
  nasolabial_case REAL,
  -- Facial analysis
  nasolabial_angle TEXT CHECK (nasolabial_angle IN ('acute','average','obtuse')),
  lips TEXT CHECK (lips IN ('competent','incompetent')),
  -- Treatment plan
  extraction_choice TEXT CHECK (extraction_choice IN ('extraction','non_extraction')),
  extraction_teeth TEXT,
  anchorage TEXT CHECK (anchorage IN ('minimal','moderate','maximum')),
  anchorage_note TEXT,
  hints TEXT,
  created_by INTEGER REFERENCES users(id),
  updated_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_visits_patient ON visits(patient_id);
CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(appointment_date, room_id);
CREATE INDEX IF NOT EXISTS idx_shifts_date ON shifts(shift_date, room_id);
CREATE INDEX IF NOT EXISTS idx_doctor_weekly_shifts_weekday ON doctor_weekly_shifts(weekday, room_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_date ON audit_log(changed_at);

-- دفعة 21 — فهارس إضافية كانت ناقصة على أعمدة بتتفلتر/تتربط عليها كتير (الملف
-- المالي للمريض، لوجيك الموعد المعلّق، دفعات المتابعة) — من غير فهرسة، SQLite
-- بيعمل full table scan على invoices/appointments/visits في كل استعلام من دول،
-- ومع زيادة عدد الزيارات/الفواتير بمرور الوقت ده بيبقى أبطأ تدريجيًا. إضافة
-- فهرس آمنة 100% ومالهاش أي تأثير على البيانات أو السلوك، بس بتسرّع القراءة.
CREATE INDEX IF NOT EXISTS idx_invoices_visit ON invoices(visit_id);
CREATE INDEX IF NOT EXISTS idx_invoices_parent ON invoices(parent_invoice_id);
CREATE INDEX IF NOT EXISTS idx_appointments_patient_status ON appointments(patient_id, status);
CREATE INDEX IF NOT EXISTS idx_visits_appointment ON visits(appointment_id);
