import { notFound } from "next/navigation";
import Link from "next/link";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { displayAge } from "@/lib/age";
import OrthodonticChartForm from "@/components/OrthodonticChartForm";

// شارت تشخيص وخطة علاج التقويم — صفحة منفصلة عن الملف الطبي العام (بقرار صريح
// من المستخدم)، بس نفس صلاحية التعديل (دكتور + أدمن + مدير عيادة). أي حد يقدر
// يفتح ملف المريض يقدر يشوف الشارت هنا (عرض بس لو مش معاه صلاحية تعديل).
function canEditMedicalRecordFor(role: string | undefined): boolean {
  return role === "doctor" || role === "admin" || role === "clinic_manager";
}

export default async function OrthodonticChartPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const patientId = Number(id);
  if (!patientId) notFound();

  const patient = await db.selectFrom("patients").selectAll().where("id", "=", patientId).executeTakeFirst();
  if (!patient) notFound();

  const session = await getSession();
  const editable = canEditMedicalRecordFor(session?.role);

  const existing =
    (await db.selectFrom("orthodontic_charts").selectAll().where("patient_id", "=", patientId).executeTakeFirst()) ??
    null;

  // عناصر المخزون المتاحة — عشان قوائم اختيار نوع البراكت/التيوب وقت التركيب
  // والريبوندينج (شوف BondingArchSection/RebondingSection في OrthodonticChartForm).
  const inventoryItems = await db
    .selectFrom("inventory_items")
    .select(["id", "name", "unit", "quantity"])
    .orderBy("name")
    .execute();

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Link href={`/patients/${patientId}`} className="text-xs text-primary hover:underline">
          ← رجوع لملف المريض
        </Link>
        <div className="text-xs text-muted">ملف رقم {patient.file_number}</div>
        <h1 className="text-xl font-bold">شارت التقويم — {patient.full_name}</h1>
        <div className="text-sm text-muted flex gap-4 flex-wrap">
          {displayAge(patient) != null && <span>السن: {displayAge(patient)}</span>}
          {patient.phone && <span>التليفون: {patient.phone}</span>}
        </div>
      </div>

      <section className="card-3d rounded-xl p-5">
        {!editable && !existing && (
          <p className="text-sm text-muted">مفيش شارت تقويم اتسجل لسه لهذا المريض.</p>
        )}
        {(editable || existing) && (
          <OrthodonticChartForm patientId={patientId} existing={existing} editable={editable} inventoryItems={inventoryItems} />
        )}
      </section>
    </div>
  );
}
