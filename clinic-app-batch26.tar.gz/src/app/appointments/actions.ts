"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";

// "المريض جاي يعمل إيه" (دفعة 26) — بيتقرأ من الفورم وبيترجع الشكل الجاهز للحفظ،
// أو null لو مفيش اختيار (يفضل الحقل فاضي، سلوك قديم زي ما هو). مستخدمة في الحجز
// وفي تعديل الموعد بعد كده (نفس القواعد في المكانين).
function readPurpose(formData: FormData): { purpose_type: "bonding_upper" | "bonding_lower" | "service" | null; purpose_service_id: number | null } {
  const raw = String(formData.get("purpose_type") || "");
  if (raw === "bonding_upper" || raw === "bonding_lower") {
    return { purpose_type: raw, purpose_service_id: null };
  }
  if (raw === "service") {
    const serviceId = Number(formData.get("purpose_service_id"));
    if (serviceId) return { purpose_type: "service", purpose_service_id: serviceId };
  }
  return { purpose_type: null, purpose_service_id: null };
}

export async function addAppointmentAction(formData: FormData) {
  const patient_id = Number(formData.get("patient_id"));
  const room_id = Number(formData.get("room_id"));
  const doctor_id = Number(formData.get("doctor_id"));
  const appointment_date = String(formData.get("appointment_date") || "");
  const start_time = String(formData.get("start_time") || "");
  const notes = String(formData.get("notes") || "").trim() || null;
  // بيوصل من الجدول المركزي كعدد دقايق (مضاعفات وحدة الزمن)؛ لو مبعوتش أو صفر
  // بيتعامل معاه كموعد بطول خانة واحدة بس (نفس السلوك القديم قبل ما الحقل ده يتضاف).
  const durationRaw = formData.get("duration_minutes");
  const duration_minutes = durationRaw ? Number(durationRaw) || null : null;
  const { purpose_type, purpose_service_id } = readPurpose(formData);

  if (!patient_id || !room_id || !doctor_id || !appointment_date || !start_time) return;

  await db
    .insertInto("appointments")
    .values({ patient_id, room_id, doctor_id, appointment_date, start_time, duration_minutes, notes, purpose_type, purpose_service_id })
    .execute();
  revalidatePath("/front-desk");
  revalidatePath("/");
}

// تحديد/تغيير "المريض جاي يعمل إيه" لموعد موجود بالفعل — قابل للاستدعاء في أي وقت
// (وقت الحجز أو بعده) من خانة الموعد في الجدول المركزي مباشرة، مش بس من بوكس
// الحجز. نفس صلاحية تعديل الجدول (schedule_edit) اللي أصلاً بتتحكم في ظهور بوكس
// الحجز وزراير الحالة — تحقق حقيقي في السيرفر، مش بس إخفاء زرار في الواجهة.
export async function setAppointmentPurposeAction(formData: FormData) {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "schedule_edit"))) return;

  const id = Number(formData.get("appointment_id"));
  if (!id) return;

  const { purpose_type, purpose_service_id } = readPurpose(formData);

  await db.updateTable("appointments").set({ purpose_type, purpose_service_id }).where("id", "=", id).execute();
  revalidatePath("/front-desk");
  revalidatePath("/");
}

// موعد "تم" نهائي — مايترجعش لحالة تانية خالص (اتفقنا على كده من دفعة 8). الجدول
// المركزي (CentralSchedule.tsx) أصلاً مايعرضش أي خيار تراجع لموعد "تم" في الواجهة،
// لكن ده كان بس قيد في الواجهة — السيرفر هنا كان بيقبل أي تغيير حالة من غير أي
// تحقق، وده اللي خلى صفحة "المواعيد والشيفتات" القديمة (كان فيها StatusSelect حر
// بيقدر يرجّع أي موعد "تم" لـ"محجوز"/"ملغي" بسهولة) تكسر الاتفاق ده فعليًا — الصفحة
// دي اتشالت بالكامل (كانت مكررة مع الجدول المركزي بالكامل)، وهنا كمان بقى فيه تحقق
// في السيرفر نفسه بغض النظر عن مين بيستدعي الأكشن.
export async function updateAppointmentStatusAction(formData: FormData) {
  const id = Number(formData.get("id"));
  const status = String(formData.get("status") || "") as "booked" | "attended" | "done" | "cancelled" | "no_show";
  if (!id || !status) return;

  const current = await db.selectFrom("appointments").select("status").where("id", "=", id).executeTakeFirst();
  if (!current) return;
  if (current.status === "done") return;

  await db.updateTable("appointments").set({ status }).where("id", "=", id).execute();
  revalidatePath("/front-desk");
  revalidatePath("/");
}
