"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { logOverride } from "@/lib/audit";
import { findMatchingVisit } from "@/lib/visit-match";
import { FOLLOWUP_SERVICE_CODE } from "@/lib/followup";

// فواتير المريض اللي لسه عليها مبلغ مستحق (باستثناء فواتير "دفعات المتابعة" نفسها) —
// بتتحسب مع طرح أي دفعات متابعة سابقة اتسجلت عليها، عشان الرصيد المعروض يكون دقيق.
// بتتنادى مباشرة من CentralSchedule (client component) لما يتم اختيار خدمة "متابعة".
export async function getPatientBillableInvoicesAction(patientId: number) {
  if (!patientId) return [];

  const originals = await db
    .selectFrom("invoices")
    .innerJoin("visits", "visits.id", "invoices.visit_id")
    .leftJoin("services", "services.id", "visits.service_id")
    .select([
      "invoices.id",
      "invoices.amount",
      "invoices.paid",
      "visits.visit_date",
      "services.name as service_name",
    ])
    .where("visits.patient_id", "=", patientId)
    .where("invoices.parent_invoice_id", "is", null)
    .orderBy("visits.visit_date", "desc")
    .execute();

  if (originals.length === 0) return [];

  const followups = await db
    .selectFrom("invoices")
    .select(["parent_invoice_id", "paid"])
    .where(
      "parent_invoice_id",
      "in",
      originals.map((o) => o.id)
    )
    .execute();

  const followupSum = new Map<number, number>();
  for (const f of followups) {
    if (f.parent_invoice_id == null) continue;
    followupSum.set(f.parent_invoice_id, (followupSum.get(f.parent_invoice_id) ?? 0) + f.paid);
  }

  return originals
    .map((o) => ({
      id: o.id,
      service_name: o.service_name ?? "-",
      visit_date: o.visit_date,
      balance: Math.round((o.amount - o.paid - (followupSum.get(o.id) ?? 0)) * 100) / 100,
    }))
    .filter((o) => o.balance > 0.01);
}

// بيرجع مواعيد اليوم/الغرفة المحجوزة فعلًا (غير الملغية) — بتتنادى من بوكس "حجز
// الموعد القادم" الاختياري في بوكس التحصيل، عشان مربع الوقت يعرض بس الفترات
// المتاحة فعلًا للتاريخ والغرفة المختارين، مش كل فترات اليوم.
export async function getBookedSlotsForRoomDateAction(roomId: number, date: string): Promise<string[]> {
  if (!roomId || !date) return [];
  const rows = await db
    .selectFrom("appointments")
    .select(["start_time"])
    .where("room_id", "=", roomId)
    .where("appointment_date", "=", date)
    .where("status", "!=", "cancelled")
    .execute();
  return rows.map((r) => r.start_time);
}

// بيتسجل من بوكس الفوترة اللي بيتفتح لما يتم الضغط على "تم" في الجدول المركزي
// (لو المستخدم عنده صلاحية collect_payments). فيه مسارين:
// 1) خدمة عادية جديدة: بتتسجل زيارة + فاتورة جديدة بالسعر (قابل للتعديل) والخصم.
// 2) خدمة "متابعة" (كود 0): بتتسجل زيارة (تظهر في الملف الطبي) وفاتورة بمبلغ صفر
//    مربوطة بـ parent_invoice_id على الفاتورة الأصلية المختارة — المبلغ المدفوع
//    بيتحط في paid بتاعتها هي، عشان يتخصم من رصيد الفاتورة الأصلية تحديدًا من غير
//    ما يعمل استحقاق جديد.
// في الحالتين: بيحدّث حالة الموعد لـ "تم".
export async function recordAppointmentBillingAction(formData: FormData) {
  const appointmentId = Number(formData.get("appointment_id"));
  const serviceId = Number(formData.get("service_id"));
  const paymentMethod = String(formData.get("payment_method") || "").trim() || null;
  const amountNow = Math.max(0, Number(formData.get("amount_now") || 0));

  if (!appointmentId || !serviceId) return;

  const session = await getSession();
  if (!session) return;

  // محصور بصلاحية collect_payments — نفس الصلاحية اللي بتتحكم في ظهور بوكس
  // التحصيل من الجدول المركزي أصلاً. الأكشن ده بقى ليه مدخلين دلوقتي (بوكس
  // التحصيل الفوري من الجدول، وبوكس تحصيل الموعد المعلّق من الملف المالي
  // للمريض، دفعة 21) فمحتاج يتحقق بنفسه مش يعتمد بس على إخفاء الزرار بالواجهة.
  const canCollect = await hasPermission(session.userId, session.role, "collect_payments");
  if (!canCollect) return;

  const appt = await db.selectFrom("appointments").selectAll().where("id", "=", appointmentId).executeTakeFirst();
  if (!appt) return;

  const service = await db
    .selectFrom("services")
    .select(["id", "name", "code", "default_price"])
    .where("id", "=", serviceId)
    .executeTakeFirst();
  if (!service) return;

  const isFollowup = service.code === FOLLOWUP_SERVICE_CODE;

  // دفعة 24 (متابعة تقرير ازدواجية الخدمات): "الطبيب المساعد" اختياري هنا كمان،
  // بما فيها حالة "متابعة" — نقلناها لفوق قبل تفرع isFollowup/else عشان تنطبق
  // على الحالتين، مش بس "غير المتابعة" زي ما كانت قبل كده.
  const canEditAssistant =
    (await hasPermission(session.userId, session.role, "edit_visit_assistant_doctor")) ||
    (await hasPermission(session.userId, session.role, "override_visit_doctor"));
  const performingRaw = formData.get("performing_doctor_id");
  const explicitPerforming = canEditAssistant && performingRaw ? Number(performingRaw) || null : null;

  if (isFollowup) {
    const targetInvoiceId = Number(formData.get("target_invoice_id"));
    const targetInvoice = targetInvoiceId
      ? await db.selectFrom("invoices").select(["id"]).where("id", "=", targetInvoiceId).executeTakeFirst()
      : undefined;
    if (!targetInvoice) return;

    // دفعة 24: المعالجة تفضل فاضية (مش "دفعة متابعة" ثابتة) — نفس السبب الموصوف
    // في addPatientServiceAction (src/app/patients/[id]/billing/actions.ts).
    const visitResult = await db
      .insertInto("visits")
      .values({
        patient_id: appt.patient_id,
        visit_date: appt.appointment_date,
        service_id: service.id,
        notes: null,
        primary_doctor_id: appt.doctor_id,
        performing_doctor_id: explicitPerforming ?? appt.doctor_id,
        room_id: appt.room_id,
        created_by: session?.userId ?? null,
        appointment_id: appt.id,
      })
      .executeTakeFirst();
    const visitId = Number(visitResult.insertId);

    await db
      .insertInto("invoices")
      .values({
        visit_id: visitId,
        amount: 0,
        paid: amountNow,
        discount_percent: 0,
        price_overridden: 0,
        payment_method: paymentMethod,
        parent_invoice_id: targetInvoice.id,
      })
      .execute();
  } else {
    const price = Math.max(0, Number(formData.get("price") || service.default_price));
    const discountPercent = Math.min(100, Math.max(0, Number(formData.get("discount_percent") || 0)));
    const amount = Math.max(0, price * (1 - discountPercent / 100));
    const priceOverridden = Math.round(service.default_price) !== Math.round(price);

    // دفعة 22: قبل ما نسجل زيارة جديدة، ندوّر على زيارة موجودة بالفعل لنفس
    // (مريض/دكتور/يوم/خدمة) — سواء سجلها الطبيب بنفسه من سجل الزيارات بالملف
    // الطبي، أو الاستقبال من الملف المالي مباشرة — بغض النظر عن ربطها بموعد
    // تاني من عدمه (findMatchingVisit عمدًا من غير قيد على appointment_id، شوف
    // src/lib/visit-match.ts). لو لقينا واحدة، بنربطها/بنعيد ربطها بالموعد ده
    // ونستخدم فاتورتها الموجودة بالفعل بدل ما نعمل زيارة وفاتورة جديدتين
    // مستقلتين — عشان مايظهرش إن الخدمة اتعملت مرتين وميتضاعفش المبلغ المستحق
    // على المريض فعليًا. لو مفيش تطابق، بيتعمل زيارة وفاتورة جديدتين عادي.
    const existingVisit = await findMatchingVisit({
      patientId: appt.patient_id,
      doctorId: appt.doctor_id,
      visitDate: appt.appointment_date,
      serviceId: service.id,
    });

    let visitId: number;
    if (existingVisit) {
      visitId = existingVisit.id;
      await db
        .updateTable("visits")
        .set({
          appointment_id: appt.id,
          room_id: appt.room_id,
          ...(explicitPerforming != null ? { performing_doctor_id: explicitPerforming } : {}),
        })
        .where("id", "=", visitId)
        .execute();
    } else {
      const visitResult = await db
        .insertInto("visits")
        .values({
          patient_id: appt.patient_id,
          visit_date: appt.appointment_date,
          service_id: service.id,
          notes: null,
          primary_doctor_id: appt.doctor_id,
          performing_doctor_id: explicitPerforming ?? appt.doctor_id,
          room_id: appt.room_id,
          created_by: session?.userId ?? null,
          appointment_id: appt.id,
        })
        .executeTakeFirst();
      visitId = Number(visitResult.insertId);
    }

    const existingInvoice = await db
      .selectFrom("invoices")
      .select(["id"])
      .where("visit_id", "=", visitId)
      .where("parent_invoice_id", "is", null)
      .executeTakeFirst();

    let invoiceId: number;
    if (existingInvoice) {
      invoiceId = existingInvoice.id;
      await db
        .updateTable("invoices")
        .set({
          amount,
          paid: amountNow,
          discount_percent: discountPercent,
          price_overridden: priceOverridden ? 1 : 0,
          payment_method: paymentMethod,
          original_price: price,
        })
        .where("id", "=", invoiceId)
        .execute();
    } else {
      const invoiceResult = await db
        .insertInto("invoices")
        .values({
          visit_id: visitId,
          amount,
          paid: amountNow,
          discount_percent: discountPercent,
          price_overridden: priceOverridden ? 1 : 0,
          payment_method: paymentMethod,
          parent_invoice_id: null,
          original_price: price,
        })
        .executeTakeFirst();
      invoiceId = Number(invoiceResult.insertId);
    }

    if (priceOverridden) {
      await logOverride({
        entityType: "invoice_price",
        entityId: invoiceId,
        field: "السعر",
        oldValue: service.default_price,
        newValue: price,
        changedBy: session?.userId ?? null,
        reason: `تعديل سعر خدمة "${service.name}" عند التحصيل من الجدول المركزي`,
      });
    }
  }

  await db
    .updateTable("appointments")
    .set({ status: "done", pending_service_id: null, pending_price: null, pending_discount_percent: null })
    .where("id", "=", appointmentId)
    .execute();

  revalidatePath("/front-desk");
  revalidatePath("/");
  revalidatePath("/invoices");
  revalidatePath(`/patients/${appt.patient_id}`);
  revalidatePath(`/patients/${appt.patient_id}/billing`);
}

// بيتسجل من بوكس "المطلوب دفعه" اللي بيفتح لما حد معهوش صلاحية collect_payments
// (زي الدكتور) يدوس "تم" — بيحدد الخدمة والسعر المتوقع كـ"مطلوب دفعه" (pending_*)
// من غير ما يسجل زيارة أو فاتورة أو أي دفع فعلي، وبيحدد الموعد "تم". الاستقبال
// بيشوف التفاصيل دي على طول جنب شارة "محتاج تحصيل" في الجدول، وبتتملى تلقائي في
// بوكس التحصيل بتاعه لما يفتحه بأثر رجعي (تسجيل التحصيل).
export async function recordPendingBillingAction(formData: FormData) {
  const appointmentId = Number(formData.get("appointment_id"));
  const serviceId = Number(formData.get("service_id"));
  const price = Math.max(0, Number(formData.get("price") || 0));
  const discountPercent = Math.min(100, Math.max(0, Number(formData.get("discount_percent") || 0)));

  if (!appointmentId || !serviceId) return;

  const appt = await db.selectFrom("appointments").select(["id", "patient_id"]).where("id", "=", appointmentId).executeTakeFirst();
  if (!appt) return;

  await db
    .updateTable("appointments")
    .set({
      status: "done",
      pending_service_id: serviceId,
      pending_price: price,
      pending_discount_percent: discountPercent,
    })
    .where("id", "=", appointmentId)
    .execute();

  revalidatePath("/front-desk");
  revalidatePath("/");
}
