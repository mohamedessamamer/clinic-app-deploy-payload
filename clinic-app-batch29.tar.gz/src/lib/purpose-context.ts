import { db } from "@/lib/db/client";

// دفعة 27 (P3.2): سياق "متابعة: <اسم الخدمة>" اللي بيظهر للدكتور وقت إدخال
// معالجة (سواء الملف الطبي العادي أو شارت التقويم) — من غير أي دخل ليه في
// الجزء المالي نفسه (الفصل الكامل بين الملفين فاضل زي ما هو)، مجرد سياق يوضح
// إن الزيارة دي متابعة لخدمة سبق فتحها من الاستقبال (appointments.purpose_linked_invoice_id).
//
// دفعة 28: شلنا الرصيد المالي (balance) خالص من هنا — كان ظاهر للدكتور كـ"context
// only" بس المستخدم اعتبره خرق لقرار الفصل الكامل بين الملف الطبي والمالي (مبلغ
// فلوس قدام الدكتور، حتى لو "للسياق بس"). دلوقتي السياق المرجوع اسم الخدمة بس،
// من غير أي رقم مالي خالص.
export type PurposeContext = {
  serviceName: string;
};

// بيدوّر على أقرب موعد للمريض النهاردة معاه purpose_linked_invoice_id، ولو
// لقى، بيرجّع اسم الخدمة الأصلية بس (من غير أي مبلغ مالي). بيرجّع null لو
// مفيش موعد النهاردة أو مفيش ربط أصلاً.
export async function getTodayPurposeContext(patientId: number, today: string): Promise<PurposeContext | null> {
  if (!patientId) return null;

  const appt = await db
    .selectFrom("appointments")
    .select(["purpose_linked_invoice_id"])
    .where("patient_id", "=", patientId)
    .where("appointment_date", "=", today)
    .where("status", "!=", "cancelled")
    .where("purpose_linked_invoice_id", "is not", null)
    .orderBy("start_time")
    .executeTakeFirst();

  if (!appt || !appt.purpose_linked_invoice_id) return null;

  const invoice = await db
    .selectFrom("invoices")
    .leftJoin("services", "services.id", "invoices.service_id")
    .select(["services.name as service_name"])
    .where("invoices.id", "=", appt.purpose_linked_invoice_id)
    .executeTakeFirst();
  if (!invoice) return null;

  return { serviceName: invoice.service_name ?? "-" };
}
