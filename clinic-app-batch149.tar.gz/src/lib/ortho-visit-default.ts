import { db } from "@/lib/db/client";
import { suggestOrthoVisitService, type OrthoVisitDefaultInput, type OrthoVisitService } from "@/lib/ortho-visit-service";

export type { OrthoVisitService };

export async function getTodayOrthoVisitDefault(patientId: number, today: string): Promise<OrthoVisitService | null> {
  if (!patientId) return null;
  const rows = await db
    .selectFrom("appointments")
    .leftJoin("services as purpose_services", "purpose_services.id", "appointments.purpose_service_id")
    .leftJoin("invoices as purpose_invoices", "purpose_invoices.id", "appointments.purpose_linked_invoice_id")
    .leftJoin("services as linked_purpose_services", "linked_purpose_services.id", "purpose_invoices.service_id")
    .select([
      "appointments.purpose_type",
      "purpose_services.name as purpose_service_name",
      "purpose_services.name_en as purpose_service_name_en",
      "purpose_services.category as purpose_service_category",
      "purpose_services.ends_ortho as purpose_service_ends_ortho",
      "appointments.purpose_linked_invoice_id",
      "linked_purpose_services.name as purpose_linked_service_name",
      "linked_purpose_services.name_en as purpose_linked_service_name_en",
      "linked_purpose_services.category as purpose_linked_service_category",
    ])
    .where("appointments.patient_id", "=", patientId)
    .where("appointments.appointment_date", "=", today)
    .where("appointments.status", "not in", ["cancelled", "no_show"])
    .orderBy("appointments.start_time", "asc")
    .execute();
  for (const row of rows) {
    const suggestion = suggestOrthoVisitService(row as OrthoVisitDefaultInput);
    if (suggestion) return suggestion;
  }
  return null;
}
