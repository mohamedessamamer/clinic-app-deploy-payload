// دفعة 149 — أنهي شهر يفتح عليه كشف الرواتب في شاشة المصروفات.
//
// المشكلة: الكشف كان بيتبع الشهر المعروض، والافتراضي هو الشهر الحالي. فمرتبات
// أكتوبر اللي بتتصرف يوم 1 أو 10 نوفمبر كانت بتتسجل على كشف نوفمبر وبتاريخ 30/11.
// الحل: في أول PAYROLL_GRACE_DAYS يوم من الشهر، الكشف بيفتح على الشهر اللي فات
// (وقت صرف المرتبات والنسب). المحاسب يقدر يغيّر الشهر بإيده بالأسهم، والاختيار
// بيتحفظ في الـ URL (?payroll=YYYY-MM).
// ملف نقي من غير أي import لقاعدة البيانات عشان يتختبر مباشرة.

/** لحد يوم كام في الشهر الكشف يفتح على الشهر اللي فات (قرار صاحب العيادة: 15). */
export const PAYROLL_GRACE_DAYS = 15;

const MONTH_RE = /^\d{4}-(0[1-9]|1[0-2])$/;

export function isMonth(value: string | null | undefined): value is string {
  return typeof value === "string" && MONTH_RE.test(value);
}

/** يزوّد أو ينقص شهور على YYYY-MM. */
export function shiftMonth(month: string, delta: number): string {
  const [year, monthNumber] = month.split("-").map(Number);
  const date = new Date(Date.UTC(year, monthNumber - 1 + delta, 1));
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;
}

/**
 * الشهر اللي الكشف يفتح عليه.
 * - لو المحاسب اختار شهر للكشف صراحة (?payroll) → هو.
 * - لو الصفحة معروضة على شهر قديم (مش الشهر الحالي) → نفس الشهر، زي الأول.
 * - لو الصفحة على الشهر الحالي وإحنا في أول 15 يوم → الشهر اللي فات.
 * - غير كده → الشهر الحالي.
 */
export function resolvePayrollMonth(opts: { today: string; viewedMonth: string; requested?: string | null }): { month: string; autoShifted: boolean } {
  if (isMonth(opts.requested)) return { month: opts.requested, autoShifted: false };
  const currentMonth = opts.today.slice(0, 7);
  const day = Number(opts.today.slice(8, 10));
  if (opts.viewedMonth === currentMonth && day <= PAYROLL_GRACE_DAYS) {
    return { month: shiftMonth(currentMonth, -1), autoShifted: true };
  }
  return { month: opts.viewedMonth, autoShifted: false };
}

/** هل الشهر لسه مخلصش (آخر يوم فيه بعد النهارده أو هو النهارده)؟ */
export function monthNotFinished(month: string, today: string): boolean {
  return shiftMonth(month, 1) > today.slice(0, 7) && month >= today.slice(0, 7);
}
