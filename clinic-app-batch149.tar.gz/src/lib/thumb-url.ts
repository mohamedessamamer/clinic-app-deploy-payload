// Batch 148: نسخة مصغّرة من صورة المريض للعرض داخل المعارض (الخانات الصغيرة).
// الصورة الكاملة بتتحمّل بس لما حد يفتحها. السيرفر بيعمل النسخة المصغّرة مرة
// واحدة ويحتفظ بيها (شوف patient-files/[...path]/route.ts).
export const THUMB_WIDTHS = [160, 320, 800] as const;
export type ThumbWidth = (typeof THUMB_WIDTHS)[number];

const THUMBABLE = /^\/patient-files\/patients\/.+\.(jpe?g|png|webp)$/i;

export function thumbUrl(filePath: string, width: ThumbWidth, contentHash?: string | null): string {
  const [pathOnly] = filePath.split("?");
  if (!THUMBABLE.test(pathOnly)) {
    return contentHash ? `${pathOnly}?v=${contentHash.slice(0, 12)}` : filePath;
  }
  const params = new URLSearchParams({ w: String(width) });
  if (contentHash) params.set("v", contentHash.slice(0, 12));
  return `${pathOnly}?${params.toString()}`;
}
