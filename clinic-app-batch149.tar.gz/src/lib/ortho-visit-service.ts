import { isOrthodonticAppointmentPurpose } from "./appointment-purpose.ts";

// Batch 148: خانة Visit Type في كارت "Visit Details" بتتملى مبدئيًا من سبب
// حجز المريض النهاردة (والدكتور يقدر يغيّرها). الربط:
//   تركيب أول تقويم (bonding_upper)  → Bonding Upper
//   تركيب تاني تقويم (bonding_lower) → Bonding Lower
//   خدمة تقويم اسمها فيه فك تقويم/Debond → Debonding
//   ريتينر/مثبت/Retainer (مش إعادة لصق) → Retainer delivery
//   استشارة/كشف/Consult              → Consultation
//   أي خدمة تقويم تانية أو متابعة مربوطة بفاتورة تقويم → Follow up
// موعد مش تقويم أو مالوش سبب → فاضية زي الأول.
export type OrthoVisitService = "Follow up" | "Bonding Upper" | "Bonding Lower" | "Debonding" | "Retainer delivery" | "Consultation";

export type OrthoVisitDefaultInput = {
  purpose_type: "bonding_upper" | "bonding_lower" | "service" | null;
  purpose_service_name: string | null;
  purpose_service_name_en: string | null;
  purpose_service_category: string | null;
  // خدمة متعلّم عليها في الإعدادات إنها بتنهي التقويم (فك).
  purpose_service_ends_ortho?: number | null;
  purpose_linked_invoice_id: number | null;
  purpose_linked_service_name: string | null;
  purpose_linked_service_name_en: string | null;
  purpose_linked_service_category: string | null;
};

export function suggestOrthoVisitService(appt: OrthoVisitDefaultInput): OrthoVisitService | null {
  if (appt.purpose_type === "bonding_upper") return "Bonding Upper";
  if (appt.purpose_type === "bonding_lower") return "Bonding Lower";
  if (appt.purpose_type !== "service") return null;
  if (!isOrthodonticAppointmentPurpose(appt)) return null;
  // اسم الخدمة المحجوزة نفسها هو اللي بيحدد؛ لو متابعة لفاتورة مفتوحة فهي متابعة.
  const own = `${appt.purpose_service_name ?? ""} ${appt.purpose_service_name_en ?? ""}`.toLowerCase();
  // "فك" لوحدها ممكن تكون "فك علوي" (jaw)، فلازم تبقى "فك تقويم/براكتس".
  if (appt.purpose_service_ends_ortho === 1 || /debond|فك\s*(ال)?(تقويم|براكت|براكيت)/.test(own)) return "Debonding";
  // "إعادة لصق مثبت" (Rebonding for fixed retainer) زيارة متابعة مش تسليم مثبت.
  if (/rebond|لصق/.test(own)) return "Follow up";
  if (/retainer|ريتينر|ريتنر|مثبت/.test(own)) return "Retainer delivery";
  if (/consult|استشار|كشف/.test(own)) return "Consultation";
  return "Follow up";
}

