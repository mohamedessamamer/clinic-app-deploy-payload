"use client";

// شارت التقويم v2 — "Follow ups" (النسخة الحقيقية، دمج 2026-08-27). نفس
// السلوك بالظبط اللي كان في البروتوتايب المعزول: خدمة الـBonding بتتقفل
// نهائيًا بمجرد ما تتطبق، الوير لازم مقاس ونوع مع بعض أو Same/فاضي، زرار Save
// واحد بيطبق كل حاجة مرة واحدة، وزرار Edit بعد الحفظ (لو معاك الصلاحية) بيفتح
// باقي الحقول تاني من غير الـService. الفرق: الزيارات دلوقتي صفوف حقيقية في
// ortho_visits — "+ New visit" بيضيف صف مسودة محلي (draft-...) لحد ما تدوس
// Save، وبعدها بيتحول لصف حقيقي بمعرف رقمي حقيقي.

import { useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { saveOrthoVisitAction, deleteOrthoVisitAction } from "@/app/patients/[id]/orthodontics/ortho-v2-actions";
import { elastomericColorForItemName } from "@/lib/ortho/elastomeric-colors";

const MOCK_SERVICES = ["Follow up", "Bonding Upper", "Bonding Lower", "Debonding", "Retainer delivery", "Consultation"];
const NO_WIRE_SERVICES = ["Debonding", "Retainer delivery", "Consultation"];
const QUANTITY_OPTIONS = Array.from({ length: 24 }, (_, index) => String(index + 1));

export interface OrthoDoctorOption {
  id: number;
  full_name: string;
  isConsultant: boolean;
}

export interface OrthoOptionLists {
  wireSizes: string[];
  wireTypes: string[];
  otieColors: string[];
  elasticSizes: string[];
}

// الصنف الفعلي من مخزن التقويم، وليس اسمًا حرًا أو قيمة من قائمة مستقلة.
export interface OrthoStockItem {
  id: number;
  name: string;
  quantity: number;
  unit: string | null;
  usage: "wire" | "bracket" | "tube" | "elastic" | "otie" | "power_chain" | "button" | "compressed_coil";
}

export interface OrthoVisitRow {
  id: number;
  date: string;
  service: string;
  upperSize: string;
  upperType: string;
  lowerSize: string;
  lowerType: string;
  note: string;
  elasticsDispensed: boolean;
  elasticsSize: string;
  otieColor: string;
  powerChainQty: string;
  buttonsQty: string;
  compressedCoilMm: string;
  upperWireItemId: number | null;
  lowerWireItemId: number | null;
  elasticItemId: number | null;
  otieItemId: number | null;
  powerChainItemId: number | null;
  buttonsItemId: number | null;
  compressedCoilItemId: number | null;
  bondingBracketItemId: number | null;
  bondingBracketBrand: string | null;
  bondingTubeItemId: number | null;
  doctorId: number | null;
  seenByConsultant: boolean;
  consultantDoctorId: number | null;
  bracketCount: number;
  bondingApplied: boolean;
  debondApplied: boolean;
}

interface DraftRow {
  id: string; // "draft-..."
  date: string;
  service: string;
  upperSize: string;
  upperType: string;
  lowerSize: string;
  lowerType: string;
  note: string;
  elasticsDispensed: boolean;
  elasticsSize: string;
  otieColor: string;
  powerChainQty: string;
  buttonsQty: string;
  compressedCoilMm: string;
  upperWireItemId: number | null;
  lowerWireItemId: number | null;
  elasticItemId: number | null;
  otieItemId: number | null;
  powerChainItemId: number | null;
  buttonsItemId: number | null;
  compressedCoilItemId: number | null;
  bondingBracketItemId: number | null;
  bondingBracketBrand: string | null;
  bondingTubeItemId: number | null;
  doctorId: number | null;
  seenByConsultant: boolean;
  consultantDoctorId: number | null;
  bracketCount: number;
  upperSizeInvalid: boolean;
  upperTypeInvalid: boolean;
  lowerSizeInvalid: boolean;
  lowerTypeInvalid: boolean;
  doctorMissing: boolean;
}

function todayStr(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function makeDraftRow(defaultDoctorId: number | null, defaultService = ""): DraftRow {
  return {
    id: `draft-${Date.now()}-${Math.random()}`,
    date: "",
    service: defaultService,
    upperSize: "",
    upperType: "",
    lowerSize: "",
    lowerType: "",
    note: "",
    elasticsDispensed: false,
    elasticsSize: "",
    otieColor: "",
    powerChainQty: "",
    buttonsQty: "",
    compressedCoilMm: "",
    upperWireItemId: null,
    lowerWireItemId: null,
    elasticItemId: null,
    otieItemId: null,
    powerChainItemId: null,
    buttonsItemId: null,
    compressedCoilItemId: null,
    bondingBracketItemId: null,
    bondingBracketBrand: null,
    bondingTubeItemId: null,
    doctorId: defaultDoctorId,
    seenByConsultant: false,
    consultantDoctorId: null,
    bracketCount: 0,
    upperSizeInvalid: false,
    upperTypeInvalid: false,
    lowerSizeInvalid: false,
    lowerTypeInvalid: false,
    doctorMissing: false,
  };
}

function AutoGrowTextarea({
  value,
  onChange,
  placeholder,
  disabled = false,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  disabled?: boolean;
}) {
  return (
    <textarea
      value={value}
      onChange={(e) => {
        onChange(e.target.value);
        e.target.style.height = "auto";
        e.target.style.height = `${e.target.scrollHeight}px`;
      }}
      placeholder={placeholder}
      rows={1}
      disabled={disabled}
      className="w-full min-w-0 resize-none overflow-hidden rounded-md border border-border bg-background px-2 py-1 text-sm font-bold disabled:opacity-60 disabled:cursor-not-allowed"
    />
  );
}

function Dropdown({
  value,
  onChange,
  options,
  placeholder = "—",
  className = "",
  disabled = false,
  error = false,
}: {
  value: string;
  onChange: (v: string) => void;
  options: string[];
  placeholder?: string;
  className?: string;
  disabled?: boolean;
  error?: boolean;
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      disabled={disabled}
      className={`rounded-md border bg-background px-1.5 py-1 text-xs disabled:opacity-60 disabled:cursor-not-allowed ${
        error ? "border-red-500 ring-1 ring-red-500" : "border-border"
      } ${className}`}
    >
      <option value="">{placeholder}</option>
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  );
}

function StockDropdown({
  value,
  onChange,
  items,
  placeholder,
  disabled = false,
}: {
  value: number | null;
  onChange: (id: number | null) => void;
  items: OrthoStockItem[];
  placeholder: string;
  disabled?: boolean;
}) {
  return (
    <select value={value ?? ""} onChange={(event) => onChange(event.target.value ? Number(event.target.value) : null)} disabled={disabled} className="rounded-md border border-border bg-background px-1.5 py-1 text-xs disabled:opacity-60 disabled:cursor-not-allowed max-w-[150px]">
      <option value="">{placeholder}</option>
      {items.map((item) => <option key={item.id} value={item.id}>{item.name} ({item.quantity} {item.unit ?? ""})</option>)}
    </select>
  );
}

function WireStockDropdown({
  value,
  same,
  onChange,
  items,
  disabled = false,
}: {
  value: number | null;
  same: boolean;
  onChange: (next: { id: number | null; same: boolean }) => void;
  items: OrthoStockItem[];
  disabled?: boolean;
}) {
  const selectedValue = same ? "same" : value != null ? String(value) : "";
  return (
    <select
      value={selectedValue}
      onChange={(event) => {
        if (event.target.value === "same") onChange({ id: null, same: true });
        else onChange({ id: event.target.value ? Number(event.target.value) : null, same: false });
      }}
      disabled={disabled}
      className="rounded-md border border-border bg-background px-1.5 py-1 text-xs disabled:cursor-not-allowed disabled:opacity-60 max-w-[150px]"
    >
      <option value="">Select wire</option>
      <option value="same">Same — no deduction</option>
      {items.map((item) => <option key={item.id} value={item.id}>{item.name} ({item.quantity} {item.unit ?? ""})</option>)}
    </select>
  );
}

// قائمة ألوان خاصة بدل الـselect التقليدي: يظهر الاسم بلونه الحقيقي والكود
// بجانبه، فتظل الألوان المتقاربة قابلة للتمييز أثناء اختيار O-tie.
function ColorStockDropdown({ value, onChange, items, disabled = false }: {
  value: number | null;
  onChange: (id: number | null) => void;
  items: OrthoStockItem[];
  disabled?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const selected = items.find((item) => item.id === value) ?? null;
  const selectedColor = selected ? elastomericColorForItemName(selected.name) : null;
  return <div className="relative">
    <button type="button" disabled={disabled} onClick={() => setOpen((current) => !current)} className="min-w-32 rounded-md border border-border bg-background px-2 py-1 text-left text-xs disabled:opacity-60 disabled:cursor-not-allowed flex items-center gap-1.5">
      {selectedColor ? <><span className="h-3 w-3 rounded-full border border-black/20 shrink-0" style={{ backgroundColor: selectedColor.hex }} /><span className="font-medium" style={{ color: selectedColor.hex }}>{selectedColor.name}</span><span className="text-[10px] text-muted">({selectedColor.code})</span></> : <span className="text-muted">Select color</span>}
    </button>
    {open && !disabled && <div className="absolute z-30 mt-1 max-h-56 w-56 overflow-y-auto rounded-md border border-border bg-background p-1 shadow-lg">
      <button type="button" onClick={() => { onChange(null); setOpen(false); }} className="w-full rounded px-2 py-1.5 text-left text-xs text-muted hover:bg-primary-soft">Clear selection</button>
      {items.map((item) => {
        const color = elastomericColorForItemName(item.name);
        return <button key={item.id} type="button" onClick={() => { onChange(item.id); setOpen(false); }} className="w-full rounded px-2 py-1.5 text-left text-xs hover:bg-primary-soft flex items-center gap-2">
          <span className="h-3 w-3 rounded-full border border-black/20 shrink-0" style={{ backgroundColor: color?.hex ?? "#94a3b8" }} />
          <span className="font-medium" style={{ color: color?.hex ?? undefined }}>{color?.name ?? item.name}</span>
          {color && <span className="text-[10px] text-muted">({color.code})</span>}
          <span className="ml-auto text-[10px] text-muted">{item.quantity} {item.unit ?? ""}</span>
        </button>;
      })}
    </div>}
  </div>;
}

export default function FollowUpsTable({
  patientId,
  editable,
  canEditAfterSave,
  canDeleteVisit,
  defaultDoctorId,
  doctors,
  stockItems,
  activeBracketCount,
  unlinkedBracketCountToday,
  visits,
  upperBondedSince,
  lowerBondedSince,
  defaultVisitService = null,
  editVisitId = null,
  onEditVisitOpened,
}: {
  patientId: number;
  editable: boolean;
  canEditAfterSave: boolean;
  canDeleteVisit: boolean;
  defaultDoctorId: number | null;
  doctors: OrthoDoctorOption[];
  stockItems: OrthoStockItem[];
  activeBracketCount: number;
  unlinkedBracketCountToday: number;
  visits: OrthoVisitRow[];
  upperBondedSince: string | null;
  lowerBondedSince: string | null;
  defaultVisitService?: string | null;
  editVisitId?: number | null;
  onEditVisitOpened?: () => void;
}) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  // بعد الحفظ لا نخفي بطاقة الزيارة: آخر زيارة مسجلة اليوم تظهر في نفس
  // البطاقة مع الاستهلاك ويمكن تعديلها للجميع حتى نهاية اليوم. في اليوم التالي
  // تظهر بطاقة إدخال جديدة، أما القديم فيُفتح فقط من الجدول وبحسب الصلاحية.
  const hasVisitToday = visits.some((visit) => visit.date === todayStr());
  const todaysVisitId = visits.find((visit) => visit.date === todayStr())?.id ?? null;
  // Batch 148: Visit Type المبدئي من سبب حجز النهاردة (تركيب أول → Bonding Upper،
  // متابعة → Follow up ...) وقابل للتغيير. مابنقترحش Bonding لفك متركّب بالفعل
  // ولا Debonding لمريض مالوش براكتس — الخانة تفضل فاضية والدكتور يختار.
  const suggestedService = (() => {
    const s = defaultVisitService ?? "";
    if (!MOCK_SERVICES.includes(s)) return "";
    if (s === "Bonding Upper" && upperBondedSince) return "";
    if (s === "Bonding Lower" && lowerBondedSince) return "";
    if (s === "Debonding" && !upperBondedSince && !lowerBondedSince) return "";
    return s;
  })();
  const [drafts, setDrafts] = useState<DraftRow[]>(() => hasVisitToday ? [] : [makeDraftRow(null, suggestedService)]);
  // لو الاستقبال غيّر سبب الحجز والشارت مفتوح: نحدّث الكارت بس لو الدكتور
  // لسه ماغيّرش الخانة بنفسه (قيمتها لسه هي الاقتراح القديم).
  const lastSuggestionRef = useRef(suggestedService);
  useEffect(() => {
    const previous = lastSuggestionRef.current;
    if (previous === suggestedService) return;
    lastSuggestionRef.current = suggestedService;
    setDrafts((prev) => prev.map((row) => (row.date === "" && row.service === previous ? { ...row, service: suggestedService } : row)));
  }, [suggestedService]);
  const [unlockedIds, setUnlockedIds] = useState<Set<number>>(new Set());
  const [editBuffers, setEditBuffers] = useState<Record<number, OrthoVisitRow>>({});
  const [expandedSavedId, setExpandedSavedId] = useState<number | null>(todaysVisitId);

  useEffect(() => {
    if (editVisitId == null) return;
    const visit = visits.find((entry) => entry.id === editVisitId);
    if (visit) {
      startEdit(visit);
      setExpandedSavedId(visit.id);
    }
    onEditVisitOpened?.();
  }, [editVisitId]); // deliberately reacts only to an explicit table request

  // router.refresh يحدّث الـ visits props لكنه لا يعيد تركيب المكوّن دائمًا؛
  // لذلك نفتح زيارة اليوم فور وصولها من السيرفر بعد الحفظ، بدل أن تختفي البطاقة.
  useEffect(() => {
    const latestToday = visits.find((visit) => visit.date === todayStr());
    if (latestToday) {
      setExpandedSavedId(latestToday.id);
    } else if (drafts.length === 0) {
      setDrafts([makeDraftRow(null, suggestedService)]);
    }
  }, [visits]); // reacts only to refreshed server data

  function addVisit() {
    setDrafts((prev) => [makeDraftRow(defaultDoctorId), ...prev]);
  }

  function patchDraft(id: string, patch: Partial<DraftRow>) {
    setDrafts((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  }

  function onWireChangeDraft(id: string, patch: Partial<DraftRow>) {
    const clears: Partial<DraftRow> = {};
    if ("upperSize" in patch || "upperType" in patch) {
      clears.upperSizeInvalid = false;
      clears.upperTypeInvalid = false;
    }
    if ("lowerSize" in patch || "lowerType" in patch) {
      clears.lowerSizeInvalid = false;
      clears.lowerTypeInvalid = false;
    }
    patchDraft(id, { ...patch, ...clears });
  }

  function startEdit(v: OrthoVisitRow) {
    setEditBuffers((prev) => ({ ...prev, [v.id]: { ...v } }));
    setUnlockedIds((prev) => new Set(prev).add(v.id));
  }

  function patchEditBuffer(id: number, patch: Partial<OrthoVisitRow>, fallback?: OrthoVisitRow) {
    setEditBuffers((prev) => ({ ...prev, [id]: { ...(fallback ?? prev[id]), ...prev[id], ...patch } }));
  }

  // Batch 147: نفس قاعدة السيرفر (wireRequirement): السلك إجباري لو الزيارة
  // Bonding للفك، أو الفك فيه براكتس متركّبة دلوقتي والزيارة مش Debonding /
  // Retainer delivery / Consultation وتاريخها مش قبل تركيب الفك.
  function validateWire(row: Pick<DraftRow | OrthoVisitRow, "upperWireItemId" | "lowerWireItemId" | "upperSize" | "upperType" | "lowerSize" | "lowerType" | "service" | "date">) {
    const upperSame = row.upperSize === "Same" && row.upperType === "Same";
    const lowerSame = row.lowerSize === "Same" && row.lowerType === "Same";
    const visitDate = row.date || todayStr();
    const needs = (since: string | null) => since != null && !NO_WIRE_SERVICES.includes(row.service) && visitDate >= since;
    const upperRequired = row.service === "Bonding Upper" || needs(upperBondedSince);
    const lowerRequired = row.service === "Bonding Lower" || needs(lowerBondedSince);
    return {
      upperSizeInvalid: upperRequired && !row.upperWireItemId && !upperSame,
      upperTypeInvalid: upperRequired && !row.upperWireItemId && !upperSame,
      lowerSizeInvalid: lowerRequired && !row.lowerWireItemId && !lowerSame,
      lowerTypeInvalid: lowerRequired && !row.lowerWireItemId && !lowerSame,
    };
  }

  function saveDraft(id: string) {
    const r = drafts.find((row) => row.id === id);
    if (!r) return;
    const invalid = validateWire(r);
    const doctorMissing = !r.doctorId;
    if (invalid.upperSizeInvalid || invalid.upperTypeInvalid || invalid.lowerSizeInvalid || invalid.lowerTypeInvalid || doctorMissing) {
      patchDraft(id, { ...invalid, doctorMissing });
      return;
    }
    const date = r.date || todayStr();
    startTransition(async () => {
      const res = await saveOrthoVisitAction({
        patientId,
        date,
        service: r.service,
        upperWireSize: r.upperSize,
        upperWireType: r.upperType,
        lowerWireSize: r.lowerSize,
        lowerWireType: r.lowerType,
        note: r.note,
        elasticsDispensed: r.elasticsDispensed,
        elasticsSize: r.elasticsSize,
        otieColor: r.otieColor,
        powerChainQty: r.powerChainQty,
        buttonsQty: r.buttonsQty,
        compressedCoilMm: r.compressedCoilMm,
        upperWireItemId: r.upperWireItemId,
        lowerWireItemId: r.lowerWireItemId,
        elasticItemId: r.elasticItemId,
        otieItemId: r.otieItemId,
        powerChainItemId: r.powerChainItemId,
        buttonsItemId: r.buttonsItemId,
        compressedCoilItemId: r.compressedCoilItemId,
        bondingBracketItemId: r.bondingBracketItemId,
        bondingBracketBrand: r.bondingBracketBrand,
        bondingTubeItemId: r.bondingTubeItemId,
        doctorId: r.doctorId,
        seenByConsultant: r.seenByConsultant,
      });
      if (!res.ok) {
        window.alert(res.reason || "حصل خطأ، حاول تاني.");
        return;
      }
      setDrafts((prev) => prev.filter((row) => row.id !== id));
      router.refresh();
    });
  }

  function saveEdit(id: number) {
    const r = editBuffers[id];
    if (!r) return;
    const invalid = validateWire(r);
    if (invalid.upperSizeInvalid || invalid.upperTypeInvalid || invalid.lowerSizeInvalid || invalid.lowerTypeInvalid) {
      window.alert("Wire needs both a size and a type — or leave it as \"Same\"");
      return;
    }
    if (!r.doctorId) {
      window.alert("Please select a doctor before saving");
      return;
    }
    startTransition(async () => {
      const res = await saveOrthoVisitAction({
        patientId,
        visitId: id,
        date: r.date || todayStr(),
        service: r.service,
        upperWireSize: r.upperSize,
        upperWireType: r.upperType,
        lowerWireSize: r.lowerSize,
        lowerWireType: r.lowerType,
        note: r.note,
        elasticsDispensed: r.elasticsDispensed,
        elasticsSize: r.elasticsSize,
        otieColor: r.otieColor,
        powerChainQty: r.powerChainQty,
        buttonsQty: r.buttonsQty,
        compressedCoilMm: r.compressedCoilMm,
        upperWireItemId: r.upperWireItemId,
        lowerWireItemId: r.lowerWireItemId,
        elasticItemId: r.elasticItemId,
        otieItemId: r.otieItemId,
        powerChainItemId: r.powerChainItemId,
        buttonsItemId: r.buttonsItemId,
        compressedCoilItemId: r.compressedCoilItemId,
        bondingBracketItemId: r.bondingBracketItemId,
        bondingBracketBrand: r.bondingBracketBrand,
        bondingTubeItemId: r.bondingTubeItemId,
        doctorId: r.doctorId,
        seenByConsultant: r.seenByConsultant,
      });
      if (!res.ok) {
        window.alert(res.reason || "حصل خطأ، حاول تاني.");
        return;
      }
      setUnlockedIds((prev) => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
      setExpandedSavedId(null);
      router.refresh();
    });
  }

  // حذف زيارة بالكامل — دفعة 27، بصلاحية delete_visits (نفس صلاحية حذف زيارات
  // الملف الطبي العادي). السيرفر بيرجّع أي خصم مخزون/تغيير حالة أسنان اتسبب
  // فيه (شوف deleteOrthoVisitAction).
  function deleteVisit(v: OrthoVisitRow) {
    const ok = window.confirm(
      v.bondingApplied
        ? "Delete this visit entirely? This will also revert the bonding it applied (tooth states + inventory) for any tooth still attributed to it. This can't be undone."
        : v.debondApplied
        ? "Delete this debonding visit? The brackets it removed will be put back on the chart exactly as they were before it. This can't be undone."
        : "Delete this visit entirely? Any inventory it consumed (elastics/O-ties/power chain/etc) will be refunded. This can't be undone."
    );
    if (!ok) return;
    startTransition(async () => {
      const res = await deleteOrthoVisitAction({ patientId, visitId: v.id });
      if (!res.ok) {
        window.alert(res.reason || "حصل خطأ، حاول تاني.");
        return;
      }
      router.refresh();
    });
  }

  const allRows: Array<{ kind: "draft"; row: DraftRow } | { kind: "saved"; row: OrthoVisitRow }> = [
    ...drafts.map((row) => ({ kind: "draft" as const, row })),
    ...visits.filter((row) => row.id === expandedSavedId).map((row) => ({ kind: "saved" as const, row })),
  ];

  return (
    <section id="ortho-visit-editor" className={`ortho-visit-details card-3d scroll-mt-20 ${isPending ? "opacity-70 pointer-events-none" : ""}`}>
      <div className="ortho-visit-details-heading"><h3>Visit Details</h3><span>Today</span></div>
      {allRows.map((entry) => {
        const isDraft = entry.kind === "draft";
        const saved = entry.kind === "saved";
        const unlocked = saved && unlockedIds.has(entry.row.id);
        const isSameDay = saved && entry.row.date === todayStr();
        const editableSaved = saved && (unlocked || isSameDay);
        const r = isDraft ? entry.row : editableSaved ? editBuffers[entry.row.id] ?? entry.row : entry.row;
        const fieldsDisabled = !editable || (saved && !editableSaved);
        const errors = isDraft ? entry.row : { upperSizeInvalid: false, upperTypeInvalid: false, lowerSizeInvalid: false, lowerTypeInvalid: false, doctorMissing: false };
        const powerChainPieces = Math.max(0, Number(r.powerChainQty) || 0);
        const calculatedOtieQty = Math.max(0, activeBracketCount - powerChainPieces);
        const otieColor = r.otieItemId ? elastomericColorForItemName(stockItems.find((item) => item.id === r.otieItemId)?.name ?? "") : null;
        const buttonStock = stockItems.find((item) => item.usage === "button") ?? null;
        const coilStock = stockItems.find((item) => item.usage === "compressed_coil") ?? null;
        const selectedDoctor = doctors.find((doctor) => doctor.id === r.doctorId) ?? null;
        const doctorIsConsultant = selectedDoctor?.isConsultant ?? false;
        const seenByConsultant = doctorIsConsultant || r.seenByConsultant;
        const patch = (p: Record<string, unknown>) => {
          if (isDraft) patchDraft(entry.row.id, p);
          else if (editableSaved) {
            if (!editBuffers[entry.row.id]) startEdit(entry.row);
            patchEditBuffer(entry.row.id, p, entry.row);
          }
        };
        const patchWire = (p: Record<string, unknown>) => {
          if (isDraft) onWireChangeDraft(entry.row.id, p);
          else if (editableSaved) {
            if (!editBuffers[entry.row.id]) startEdit(entry.row);
            patchEditBuffer(entry.row.id, p, entry.row);
          }
        };
        const wireItems = stockItems.filter((item) => item.usage === "wire");
        const displayedBracketCount = r.bracketCount + (isDraft ? unlinkedBracketCountToday : 0);
        const consumptionItems = [
          r.upperWireItemId ? { label: "Upper wire", value: "1 piece" } : null,
          r.lowerWireItemId ? { label: "Lower wire", value: "1 piece" } : null,
          displayedBracketCount > 0 ? { label: "Brackets", value: `${displayedBracketCount} pcs` } : null,
          r.otieItemId && calculatedOtieQty > 0 ? { label: "O-tie", value: `${calculatedOtieQty} pcs` } : null,
          powerChainPieces > 0 ? { label: "Power chain", value: `${powerChainPieces} pcs` } : null,
          r.elasticsDispensed && r.elasticItemId ? { label: "Elastics", value: "1 pack" } : null,
          Number(r.buttonsQty) > 0 ? { label: "Buttons", value: `${r.buttonsQty} pcs` } : null,
          Number(r.compressedCoilMm) > 0 ? { label: "Compressed coil", value: `${r.compressedCoilMm} mm` } : null,
        ].filter((item): item is { label: string; value: string } => item != null);

        return <div key={isDraft ? entry.row.id : `visit-${entry.row.id}`} className="ortho-visit-details-body">
          <label className="ortho-visit-field"><span>Doctor</span><select value={r.doctorId != null ? String(r.doctorId) : ""} onChange={(event) => { const doctorId = event.target.value ? Number(event.target.value) : null; const doctor = doctors.find((entry) => entry.id === doctorId); patch({ doctorId, seenByConsultant: doctor?.isConsultant ?? false, consultantDoctorId: doctor?.isConsultant ? doctor.id : null, doctorMissing: false }); }} disabled={fieldsDisabled} className={errors.doctorMissing ? "is-invalid" : ""}><option value="">Select a doctor</option>{doctors.map((doctor) => <option key={doctor.id} value={doctor.id}>{doctor.full_name}</option>)}</select></label>
          <label className="ortho-visit-field"><span>Visit Type</span><Dropdown value={r.service} onChange={(service) => patch({ service })} options={MOCK_SERVICES} placeholder="Select visit type" disabled={fieldsDisabled || Boolean(saved && (entry.row.bondingApplied || entry.row.debondApplied))} className="ortho-visit-select" /></label>
          {(r.service === "Bonding Upper" || r.service === "Bonding Lower") && <label className="ortho-visit-field"><span>Bracket Company</span><select value={r.bondingBracketBrand ?? ""} onChange={(event) => patch({ bondingBracketBrand: event.target.value || null })} disabled={fieldsDisabled || Boolean(saved && entry.row.bondingApplied)}><option value="">Select bracket company</option><option value="American">American</option><option value="Ormco">Ormco</option><option value="3M">3M</option></select></label>}
          <label className="ortho-visit-field"><span>Upper wire (in)</span><WireStockDropdown value={r.upperWireItemId} same={r.upperSize === "Same" && r.upperType === "Same"} onChange={({ id, same }) => { const item = stockItems.find((entry) => entry.id === id); patchWire({ upperWireItemId: id, upperSize: same ? "Same" : item?.name ?? "", upperType: same ? "Same" : "" }); }} items={wireItems} disabled={fieldsDisabled} /></label>
          <label className="ortho-visit-field"><span>Lower wire (in)</span><WireStockDropdown value={r.lowerWireItemId} same={r.lowerSize === "Same" && r.lowerType === "Same"} onChange={({ id, same }) => { const item = stockItems.find((entry) => entry.id === id); patchWire({ lowerWireItemId: id, lowerSize: same ? "Same" : item?.name ?? "", lowerType: same ? "Same" : "" }); }} items={wireItems} disabled={fieldsDisabled} /></label>
          <label className="ortho-visit-field"><span>O-tie color</span><span className="ortho-visit-inline"><ColorStockDropdown value={r.otieItemId} onChange={(id) => { const item = stockItems.find((entry) => entry.id === id); patch({ otieItemId: id, otieColor: item?.name ?? "", powerChainItemId: null }); }} items={stockItems.filter((item) => item.usage === "otie")} disabled={fieldsDisabled} /><small>{r.otieItemId ? `${calculatedOtieQty} pcs` : ""}</small></span></label>
          <label className="ortho-visit-field"><span>Power chain</span><span className="ortho-visit-inline"><span className="ortho-visit-color">{otieColor ? <><i style={{ backgroundColor: otieColor.hex }} />{otieColor.name}</> : "Select O-tie"}</span><input type="number" min={0} max={24} value={r.powerChainQty} onChange={(event) => patch({ powerChainQty: event.target.value })} disabled={fieldsDisabled} placeholder="Qty" /></span></label>
          <label className="ortho-visit-field"><span>Elastics</span><StockDropdown value={r.elasticItemId} onChange={(id) => { const item = stockItems.find((entry) => entry.id === id); patch({ elasticItemId: id, elasticsDispensed: Boolean(id), elasticsSize: item?.name ?? "" }); }} items={stockItems.filter((item) => item.usage === "elastic")} placeholder="Select elastic" disabled={fieldsDisabled} /></label>
          <label className="ortho-visit-field"><span>Buttons <small>Available: {buttonStock?.quantity ?? 0}</small></span><Dropdown value={r.buttonsQty} onChange={(buttonsQty) => patch({ buttonsQty, buttonsItemId: buttonsQty ? buttonStock?.id ?? null : null })} options={QUANTITY_OPTIONS} placeholder="Select quantity" disabled={fieldsDisabled || !buttonStock} className="ortho-visit-quantity ortho-visit-quantity--wide" /></label>
          <label className="ortho-visit-field"><span>Compressed coil <small>Available: {coilStock?.quantity ?? 0} mm</small></span><Dropdown value={r.compressedCoilMm} onChange={(compressedCoilMm) => patch({ compressedCoilMm, compressedCoilItemId: compressedCoilMm ? coilStock?.id ?? null : null })} options={QUANTITY_OPTIONS} placeholder="Select mm" disabled={fieldsDisabled || !coilStock} className="ortho-visit-quantity ortho-visit-quantity--wide" /></label>
          <label className="ortho-visit-notes"><span>Free notes</span><AutoGrowTextarea value={r.note} onChange={(note) => patch({ note })} placeholder="Patient complaint. Mild crowding improvement." disabled={fieldsDisabled} /></label>
          <label className={`ortho-consultant-seen ${seenByConsultant ? "is-checked" : ""} ${doctorIsConsultant ? "is-automatic" : ""}`}>
            <span>Seen by consultant</span>
            <input type="checkbox" checked={seenByConsultant} onChange={(event) => patch({ seenByConsultant: event.target.checked })} disabled={fieldsDisabled || doctorIsConsultant} />
          </label>
          {isDraft && (errors.doctorMissing || errors.upperSizeInvalid || errors.lowerSizeInvalid) && <p className="ortho-visit-error">Select a doctor and choose both wires or Same before saving.</p>}
          {isDraft && editable && <button type="button" onClick={() => saveDraft(entry.row.id)} className="ortho-save-visit btn-3d-primary">Save Visit <span>▣</span></button>}
          {saved && !editableSaved && <div className="ortho-saved-actions"><span>✓ Saved</span>{editable && canEditAfterSave && <button type="button" onClick={() => startEdit(entry.row)}>Edit</button>}{canDeleteVisit && <button type="button" className="is-danger" onClick={() => deleteVisit(entry.row)}>Delete</button>}</div>}
          {saved && editableSaved && <button type="button" onClick={() => saveEdit(entry.row.id)} className="ortho-save-visit btn-3d-primary">Save changes</button>}
          {/* Batch 147: زرار Delete كان بيظهر بس لزيارة محفوظة "مش مفتوحة للتعديل"،
              والشاشة عمرها ما بتعرض زيارة بالشكل ده (زيارة النهارده وأي زيارة
              بتتفتح من Edit بتبقى مفتوحة للتعديل) — فالحذف كان مستحيل من الشاشة. */}
          {saved && editableSaved && canDeleteVisit && <div className="ortho-saved-actions"><button type="button" className="is-danger" onClick={() => deleteVisit(entry.row)}>Delete visit</button></div>}
          {(isDraft || isSameDay) && consumptionItems.length > 0 && <section className="ortho-visit-consumption" aria-label="Inventory and consumption for this visit"><div className="ortho-visit-consumption-title">Inventory &amp; Consumption <span>(This Visit)</span></div><div className="ortho-visit-consumption-grid">{consumptionItems.map((item) => <div key={item.label}><span>{item.label}</span><strong>{item.value}</strong></div>)}</div></section>}
        </div>;
      })}
    </section>
  );
}
