"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { getChatDoctorsAction, getStaffChatUpdatesAction, markStaffChatReadAction, sendStaffChatAction } from "@/app/chat/actions";

type Message = { id: number; body: string; created_at: string; sender_user_id: number; sender_name: string; recipient_user_id: number | null; audience: "reception" | "doctor" | "all_doctors" };
type Doctor = { id: number; full_name: string };

export default function StaffChat({ currentUserId, role, notificationSound = "gentle_bell" }: { currentUserId: number; role: string; notificationSound?: string }) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [open, setOpen] = useState(false);
  const [popup, setPopup] = useState(false);
  const [popupMessage, setPopupMessage] = useState<Message | null>(null);
  const [unreadCount, setUnreadCount] = useState(0);
  const [draft, setDraft] = useState("");
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [recipient, setRecipient] = useState("");
  const [broadcast, setBroadcast] = useState(false);
  const [busy, startTransition] = useTransition();
  const initialized = useRef(false);
  const lastSeenId = useRef(0);
  const listRef = useRef<HTMLDivElement>(null);
  const wasAtBottomRef = useRef(true);
  const audioContextRef = useRef<AudioContext | null>(null);
  const [soundReady, setSoundReady] = useState(false);
  const popupTimeoutRef = useRef<number | null>(null);
  // Batch 147: آخر id اتحمّل عندنا — التحديث الدوري بيطلب اللي بعده بس.
  const lastLoadedId = useRef(0);
  const hoverTimerRef = useRef<number | null>(null);
  const isDoctor = role === "doctor";
  const isReceptionSide = ["reception", "admin", "clinic_manager"].includes(role);

  async function ensureAudioContext() {
    const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return null;
    const context = audioContextRef.current ?? new AudioContextClass();
    audioContextRef.current = context;
    if (context.state === "suspended") {
      try { await context.resume(); } catch { setSoundReady(false); return context; }
    }
    const ready = context.state === "running";
    setSoundReady(ready);
    return context;
  }

  async function playNotificationSound(sound = notificationSound) {
    if (sound === "off") return;
    const context = await ensureAudioContext();
    if (!context || context.state !== "running") return;
    const notes = sound === "soft_chime"
      ? [{ frequency: 660, delay: 0, duration: 0.13 }, { frequency: 880, delay: 0.11, duration: 0.18 }]
      : sound === "water_drop"
        ? [{ frequency: 920, delay: 0, duration: 0.09 }, { frequency: 520, delay: 0.07, duration: 0.2 }]
        : [{ frequency: 740, delay: 0, duration: 0.2 }, { frequency: 990, delay: 0.16, duration: 0.28 }];
    for (const note of notes) {
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      const start = context.currentTime + note.delay;
      oscillator.type = sound === "water_drop" ? "sine" : "triangle";
      oscillator.frequency.setValueAtTime(note.frequency, start);
      gain.gain.setValueAtTime(0.13, start);
      gain.gain.exponentialRampToValueAtTime(0.001, start + note.duration);
      oscillator.connect(gain).connect(context.destination);
      oscillator.start(start);
      oscillator.stop(start + note.duration);
    }
  }

  async function refreshMessages() {
    // Batch 147: بدل تحميل آخر 250 رسالة كاملة (مرتين) كل ثانيتين، بنطلب
    // الجديد بس. نفس السرعة، ونفس الإشعار/الصوت/الفقاعة. حدود الرسائل
    // الموجودة على السيرفر (oldestId/newestId) بتخلي اللي انتهت مدته (48 ساعة)
    // أو اتمسح من الإعدادات يختفي هنا زي الأول.
    let update = await getStaffChatUpdatesAction(lastLoadedId.current);
    if (update.newestId != null && update.newestId < lastLoadedId.current) {
      // الشات اتمسح واتكتب فيه من جديد بأرقام أصغر — نحمّل من الأول.
      lastLoadedId.current = 0;
      update = await getStaffChatUpdatesAction(0);
    }
    const rows = update.messages;
    const unread = update.unread;
    const newest = rows.at(-1);
    if (initialized.current && newest && newest.id > lastSeenId.current && newest.sender_user_id !== currentUserId) {
      setPopupMessage(newest);
      setPopup(true);
      if (popupTimeoutRef.current) window.clearTimeout(popupTimeoutRef.current);
      popupTimeoutRef.current = window.setTimeout(() => {
        setPopup(false);
        popupTimeoutRef.current = null;
      }, 20_000);
      if ("Notification" in window && Notification.permission === "granted" && document.visibilityState !== "visible") {
        new Notification(`رسالة من ${newest.sender_name}`, { body: newest.body, tag: `staff-chat-${newest.id}` });
      }
      await playNotificationSound();
    }
    if (newest) lastSeenId.current = newest.id;
    initialized.current = true;
    const oldestId = update.oldestId;
    if (update.newestId == null) {
      lastLoadedId.current = 0;
      setMessages((current) => (current.length ? [] : current));
    } else {
      if (newest) lastLoadedId.current = Math.max(lastLoadedId.current, newest.id);
      setMessages((current) => {
        const kept = oldestId == null ? current : current.filter((message) => message.id >= oldestId);
        if (!rows.length && kept.length === current.length) return current;
        const known = new Set(kept.map((message) => message.id));
        return [...kept, ...rows.filter((message) => !known.has(message.id))].slice(-250);
      });
    }
    setUnreadCount(unread);
  }

  useEffect(() => {
    const unlockSound = () => { ensureAudioContext().catch(() => setSoundReady(false)); };
    const onVisibilityChange = () => {
      if (document.visibilityState === "visible") unlockSound();
      else setSoundReady(audioContextRef.current?.state === "running");
    };
    const onPreview = (event: Event) => {
      const sound = (event as CustomEvent<{ sound?: string }>).detail?.sound || notificationSound;
      playNotificationSound(sound).catch(() => setSoundReady(false));
    };
    window.addEventListener("pointerdown", unlockSound);
    window.addEventListener("keydown", unlockSound);
    window.addEventListener("pageshow", unlockSound);
    document.addEventListener("visibilitychange", onVisibilityChange);
    window.addEventListener("clinic-chat-sound-preview", onPreview);
    return () => {
      window.removeEventListener("pointerdown", unlockSound);
      window.removeEventListener("keydown", unlockSound);
      window.removeEventListener("pageshow", unlockSound);
      document.removeEventListener("visibilitychange", onVisibilityChange);
      window.removeEventListener("clinic-chat-sound-preview", onPreview);
    };
  }, []);

  useEffect(() => () => {
    if (popupTimeoutRef.current) window.clearTimeout(popupTimeoutRef.current);
  }, []);

  useEffect(() => {
    refreshMessages().catch(() => undefined);
    const timer = window.setInterval(() => refreshMessages().catch(() => undefined), 2000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    if (open && (isReceptionSide || isDoctor) && !doctors.length) getChatDoctorsAction().then(setDoctors).catch(() => undefined);
  }, [open, isReceptionSide, isDoctor, doctors.length]);

  useEffect(() => {
    if (!open || !wasAtBottomRef.current) return;
    const list = listRef.current;
    if (list) list.scrollTo({ top: list.scrollHeight });
  }, [messages]);

  // الشات الذي فُتح بالخطأ لا يفضل في المنتصف: يقفل بعد 20 ثانية طالما لا
  // توجد مسودة. بمجرد الكتابة نحافظ على النص ونلغي الإغلاق التلقائي.
  useEffect(() => {
    if (!open || draft.trim()) return;
    const timer = window.setTimeout(() => setOpen(false), 20_000);
    return () => window.clearTimeout(timer);
  }, [open, draft]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  function showChat() {
    wasAtBottomRef.current = true;
    setOpen(true);
    setPopup(false);
    if (popupTimeoutRef.current) window.clearTimeout(popupTimeoutRef.current);
    setUnreadCount(0);
    markStaffChatReadAction().catch(() => undefined);
  }

  function cancelHoverOpen() {
    if (hoverTimerRef.current) {
      window.clearTimeout(hoverTimerRef.current);
      hoverTimerRef.current = null;
    }
  }

  function scheduleHoverOpen() {
    if (open) return;
    cancelHoverOpen();
    hoverTimerRef.current = window.setTimeout(() => {
      hoverTimerRef.current = null;
      showChat();
    }, 250);
  }

  useEffect(() => () => cancelHoverOpen(), []);

  function send() {
    startTransition(async () => {
      const form = new FormData();
      form.set("body", draft);
      if (broadcast) form.set("broadcast", "1");
      if (recipient) form.set("recipient_user_id", recipient);
      const result = await sendStaffChatAction(form);
      if (!result.ok) return window.alert(result.reason || "تعذر إرسال الرسالة.");
      setDraft("");
      await refreshMessages();
    });
  }

  return (
    <>
      {/* Batch 147: تاب "CHAT" بالطول في الهامش الشمال بدل الزرار المدوّر اللي
          كان بيغطي المحتوى. التعدية بالماوس بتفتح الشات بعد ربع ثانية (عشان
          الماوس العابر مايفتحوش بالغلط)، والضغط (لمس/ماوس) بيفتحه على طول.
          الشات مابيقفلش لما الماوس يخرج — نفس الإغلاق الحالي (× / Esc /
          الإغلاق التلقائي بعد 20 ثانية من غير كتابة). */}
      <button
        type="button"
        onClick={() => { cancelHoverOpen(); if (!open) showChat(); }}
        onPointerEnter={(event) => { if (event.pointerType === "mouse") scheduleHoverOpen(); }}
        onPointerLeave={cancelHoverOpen}
        className="staff-chat-tab"
        title="الشات الداخلي"
        aria-label={unreadCount > 0 ? `الشات الداخلي — ${unreadCount} رسالة غير مقروءة` : "الشات الداخلي"}
        aria-expanded={open}
      >
        <span className="staff-chat-tab-label" aria-hidden="true">CHAT</span>
        {unreadCount > 0 && <span className="staff-chat-tab-dot" aria-hidden="true" />}
      </button>
      {popup && !open && (
        <button type="button" onClick={showChat} className="fixed z-50 bottom-36 left-8 w-72 rounded-xl bg-primary text-white shadow-xl p-3 text-right text-sm">
          <div className="text-[11px] text-white/80 mb-1">{popupMessage?.sender_name ?? "رسالة جديدة"}</div>
          <div className="truncate">{popupMessage?.body ?? ""}</div>
        </button>
      )}
      {open && (
        <section className="fixed z-50 bottom-20 left-8 w-[min(27rem,calc(100vw-3rem))] h-[min(34rem,calc(100vh-7rem))] card-3d rounded-xl shadow-2xl flex flex-col overflow-hidden" dir="rtl">
          <header className="flex items-center justify-between px-3 py-2 border-b border-border bg-primary-soft">
            <div><strong>شات العيادة</strong><span className="text-xs text-muted mr-2">الرسائل تُحفظ 48 ساعة</span>{notificationSound !== "off" && <span className={`mr-2 text-[10px] ${soundReady ? "text-primary" : "text-amber-700"}`}>{soundReady ? "● الصوت مفعّل" : "اضغط داخل الصفحة لتفعيل الصوت"}</span>}</div>
            <button type="button" onClick={() => setOpen(false)} className="text-lg leading-none" aria-label="إغلاق">×</button>
          </header>
          <div ref={listRef} onScroll={(event) => { const node = event.currentTarget; wasAtBottomRef.current = node.scrollHeight - node.scrollTop - node.clientHeight < 24; }} className="flex-1 overflow-y-auto p-3 space-y-2 bg-background">
            {!messages.length && <p className="text-sm text-muted text-center py-8">ابدأ رسالة للاستقبال أو للأطباء.</p>}
            {messages.map((message) => {
              const mine = message.sender_user_id === currentUserId;
              return (
                <div key={message.id} className={`max-w-[85%] rounded-xl px-3 py-2 text-sm ${mine ? "bg-primary text-white mr-auto" : "bg-surface border border-border ml-auto"}`}>
                  <div className={`text-[10px] mb-1 ${mine ? "text-white/80" : "text-muted"}`}>{mine ? "أنت" : message.sender_name}{message.audience === "all_doctors" ? " — لكل الأطباء" : ""}</div>
                  <p className="whitespace-pre-wrap">{message.body}</p>
                </div>
              );
            })}
          </div>
          <div className="border-t border-border p-2 space-y-2">
            {(isReceptionSide || (isDoctor && doctors.length > 0)) && (
              <div className="flex gap-2 text-xs">
                <select value={recipient} disabled={broadcast} onChange={(event) => setRecipient(event.target.value)} className="min-w-0 flex-1 rounded border border-border bg-background px-2 py-1.5">
                  <option value="">{isDoctor ? "إرسال للاستقبال" : "اختر طبيبًا للرد المباشر"}</option>
                  {doctors.map((doctor) => <option key={doctor.id} value={doctor.id}>{doctor.full_name}</option>)}
                </select>
                <label className="flex items-center gap-1 whitespace-nowrap"><input type="checkbox" checked={broadcast} onChange={(event) => { setBroadcast(event.target.checked); if (event.target.checked) setRecipient(""); }} /> كل الأطباء</label>
              </div>
            )}
            {isDoctor && <p className="text-[11px] text-muted">{recipient || broadcast ? "سيتم الإرسال حسب الاختيار." : "رسالتك ستصل إلى الاستقبال."}</p>}
            <div className="flex gap-2">
              <textarea value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => { if (event.key === "Escape") setOpen(false); if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); send(); } }} rows={2} placeholder="اكتب رسالة…" className="min-w-0 flex-1 rounded border border-border bg-background px-2 py-1.5 text-sm" />
              <button type="button" disabled={busy || !draft.trim()} onClick={send} className="rounded btn-3d-primary px-3 text-sm">إرسال</button>
            </div>
          </div>
        </section>
      )}
    </>
  );
}
