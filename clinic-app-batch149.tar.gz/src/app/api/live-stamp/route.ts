import { NextResponse } from "next/server";
import { getSession } from "@/lib/session";
import { getDbChangeStamp } from "@/lib/db/client";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Batch 148: الجدول بيسأل هنا كل 4.5 ثانية (~100 بايت) بدل ما يحمّل الصفحة كلها.
export async function GET() {
  const session = await getSession();
  if (!session) return new NextResponse("", { status: 401, headers: { "Cache-Control": "no-store" } });
  return new NextResponse(getDbChangeStamp(), { headers: { "Cache-Control": "no-store", "Content-Type": "text/plain; charset=utf-8" } });
}
