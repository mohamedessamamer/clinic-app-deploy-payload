// Batch 149 browser integration test (local only, test DB only).
// Checks on the real app:
//   1. the payroll section has its own month switcher and the pay button names the month,
//   2. paying a month that has not finished asks first; «تراجع» records nothing,
//   3. admin can move a settlement to another month (period + expense date + audit row),
//   4. admin can cancel a settlement (settlement + expense removed + audit row),
//   5. an accountant with manage_expenses only does NOT see move/cancel.
//
// Run: CLINIC_DB_PATH=$PWD/test-data/clinic.db SESSION_SECRET=batch149-local-test-only-secret-at-least-32 npx next start -p 3149
//      then: node scripts/test-batch149.mjs
import assert from "node:assert/strict";
import path from "node:path";
import fs from "node:fs";
import Database from "better-sqlite3";
import { SignJWT } from "jose";
import { chromium } from "playwright";

const BASE = process.env.TEST_BASE_URL || "http://localhost:3149";
const SECRET = process.env.TEST_SESSION_SECRET || "batch149-local-test-only-secret-at-least-32";
const dbPath = path.resolve("test-data/clinic.db");
assert(dbPath.includes(path.sep + "test-data" + path.sep), "test DB only");
const db = new Database(dbPath);
db.pragma("busy_timeout = 5000");
const suffix = Date.now();
const mkUser = (role) => Number(db.prepare("INSERT INTO users(username,password_hash,full_name,role,must_change_password) VALUES (?, 'unused', ?, ?, 0)").run(`${role}149_${suffix}`, role, role).lastInsertRowid);
const adminId = mkUser("admin");
const accountantId = mkUser("accountant");
db.prepare("INSERT OR REPLACE INTO user_permissions VALUES (?, 'manage_expenses', 1)").run(accountantId);
const staffId = Number(db.prepare("INSERT INTO hr_staff(full_name, staff_group, employment_start) VALUES (?, 'employee', '2026-01-01')").run("موظف اختبار 149").lastInsertRowid);
db.prepare("INSERT INTO hr_compensation_rules(person_type, person_id, staff_group, compensation_type, fixed_basis, fixed_amount, effective_from) VALUES ('staff', ?, 'employee', 'fixed', 'monthly', 5000, '2026-01-01')").run(staffId);

const settlements = (from) => db.prepare("SELECT * FROM hr_period_settlements WHERE period_from = ? ORDER BY id").all(from);
const expense = (id) => db.prepare("SELECT * FROM expenses WHERE id = ?").get(id);
const audit = (event) => db.prepare("SELECT * FROM audit_log WHERE field = ? ORDER BY id DESC").get(event);
async function until(predicate, message) {
  for (let n = 0; n < 100; n += 1) { if (predicate()) return; await new Promise((r) => setTimeout(r, 200)); }
  assert(predicate(), message);
}
async function contextFor(browser, userId, role) {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, locale: "ar-EG" });
  const token = await new SignJWT({ userId, username: `${role}149`, fullName: role, role, doctorId: null, sessionVersion: 0 })
    .setProtectedHeader({ alg: "HS256" }).setIssuedAt().setExpirationTime("1h").sign(new TextEncoder().encode(SECRET));
  await context.addCookies([{ name: "clinic_session", value: token, url: BASE }]);
  return context;
}

const today = new Date().toLocaleString("sv-SE", { timeZone: "Africa/Cairo" }).slice(0, 10);
const currentMonth = today.slice(0, 7);
const browser = await chromium.launch({ headless: true, ...(process.env.CHROME_PATH ? { executablePath: process.env.CHROME_PATH } : {}) });
fs.mkdirSync("test-data/screenshots", { recursive: true });
const errors = [];
const results = [];
const ok = (name) => { results.push(name); console.log("✓", name); };
try {
  const admin = await (await contextFor(browser, adminId, "admin")).newPage();
  admin.on("pageerror", (e) => errors.push(e.message));
  admin.on("dialog", (d) => { errors.push("unexpected dialog: " + d.message()); d.dismiss(); });

  // 1. own month switcher + button names the month (current month explicitly).
  await admin.goto(`${BASE}/expenses?payroll=${currentMonth}#payroll`);
  const section = admin.locator("#payroll");
  await section.waitFor();
  const payButton = section.locator("form#hr-settlement-form button");
  const label = (await payButton.textContent()).trim();
  assert.match(label, /^سداد .+ \d{4}$/, "pay button names the month: " + label);
  assert.equal(await section.locator('[aria-label="شهر الكشف"] a').count(), 2, "prev/next month links");
  ok(`payroll section has its own month switcher; button reads «${label}»`);

  // 2. paying the unfinished current month asks first; تراجع records nothing.
  await section.locator('input[name="salary_amount"]').fill("1234");
  await payButton.click();
  const dialog = admin.locator('[role="dialog"]');
  await dialog.waitFor();
  assert.match(await dialog.textContent(), /لسه مخلصش/);
  await admin.screenshot({ path: "test-data/screenshots/149-confirm-unfinished.png" });
  await dialog.getByRole("button", { name: "تراجع" }).click();
  await admin.waitForTimeout(800);
  assert.equal(settlements(`${currentMonth}-01`).length, 0, "nothing recorded after تراجع");
  ok("unfinished month → confirmation; «تراجع» recorded nothing");

  await payButton.click();
  await dialog.waitFor();
  await dialog.getByRole("button", { name: /أيوه، سدّد/ }).click();
  await until(() => settlements(`${currentMonth}-01`).length === 1, "settlement recorded after confirm");
  const recorded = settlements(`${currentMonth}-01`)[0];
  assert.equal(recorded.amount, 1234);
  ok("confirm → settlement recorded on the shown month");

  // 3. move it to the previous month.
  const prevMonth = (() => { const [y, m] = currentMonth.split("-").map(Number); const d = new Date(Date.UTC(y, m - 2, 1)); return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`; })();
  await admin.reload();
  await section.waitFor();
  await section.getByRole("button", { name: "نقل لشهر تاني" }).first().click();
  await dialog.waitFor();
  await dialog.locator("select").selectOption(prevMonth);
  await admin.screenshot({ path: "test-data/screenshots/149-move.png" });
  await dialog.getByRole("button", { name: "نقل السداد" }).click();
  await until(() => settlements(`${prevMonth}-01`).length === 1, "settlement moved");
  const moved = settlements(`${prevMonth}-01`)[0];
  assert.equal(moved.id, recorded.id);
  assert.equal(moved.paid_date, recorded.paid_date, "paid_date unchanged");
  const movedExpense = expense(moved.expense_id);
  assert.equal(movedExpense.expense_date.slice(0, 7), prevMonth);
  assert.match(movedExpense.title, new RegExp(prevMonth));
  assert(audit("move_hr_settlement"), "audit row for move");
  ok(`admin moved the settlement to ${prevMonth} (expense ${movedExpense.expense_date}, paid_date kept, audit logged)`);

  // 5. accountant without correct_hr_settlements sees no move/cancel.
  const accountant = await (await contextFor(browser, accountantId, "accountant")).newPage();
  accountant.on("pageerror", (e) => errors.push(e.message));
  await accountant.goto(`${BASE}/expenses?payroll=${prevMonth}#payroll`);
  await accountant.locator("#payroll").waitFor();
  assert.equal(await accountant.getByRole("button", { name: "نقل لشهر تاني" }).count(), 0);
  assert.equal(await accountant.locator("#payroll").getByRole("button", { name: "إلغاء", exact: true }).count(), 0);
  ok("accountant (manage_expenses only) sees no move/cancel");

  // 4. admin cancels it.
  await admin.goto(`${BASE}/expenses?payroll=${prevMonth}#payroll`);
  await section.waitFor();
  await section.getByRole("button", { name: "إلغاء", exact: true }).first().click();
  await dialog.waitFor();
  await dialog.getByRole("button", { name: "إلغاء السداد" }).click();
  await until(() => settlements(`${prevMonth}-01`).length === 0, "settlement cancelled");
  assert.equal(expense(moved.expense_id), undefined, "its expense is gone too");
  assert(audit("cancel_hr_settlement"), "audit row for cancel");
  ok("admin cancelled the settlement (settlement + expense removed, audit logged)");

  // React #418 (hydration text mismatch) بيظهر في كشف الرواتب على batch 148 كمان
  // بنفس البيانات بالظبط — مشكلة قديمة متسجّلة للمتابعة، مش من التعديل ده.
  const newErrors = errors.filter((message) => !message.includes("Minified React error #418"));
  assert.deepEqual(newErrors, [], "no new page errors: " + newErrors.join(" | "));
  console.log(`\nALL ${results.length} CHECKS PASSED`);
} finally {
  await browser.close();
  db.close();
}
