import { test } from "node:test";
import assert from "node:assert/strict";
import { monthNotFinished, resolvePayrollMonth, shiftMonth } from "../../src/lib/payroll-month.ts";

test("shiftMonth crosses year boundaries", () => {
  assert.equal(shiftMonth("2026-01", -1), "2025-12");
  assert.equal(shiftMonth("2026-12", 1), "2027-01");
  assert.equal(shiftMonth("2026-11", 0), "2026-11");
});

test("first 15 days of the month open the previous month's payroll", () => {
  assert.deepEqual(resolvePayrollMonth({ today: "2026-11-01", viewedMonth: "2026-11" }), { month: "2026-10", autoShifted: true });
  assert.deepEqual(resolvePayrollMonth({ today: "2026-11-15", viewedMonth: "2026-11" }), { month: "2026-10", autoShifted: true });
  assert.deepEqual(resolvePayrollMonth({ today: "2027-01-03", viewedMonth: "2027-01" }), { month: "2026-12", autoShifted: true });
});

test("after day 15 the current month's payroll opens", () => {
  assert.deepEqual(resolvePayrollMonth({ today: "2026-11-16", viewedMonth: "2026-11" }), { month: "2026-11", autoShifted: false });
});

test("an explicitly viewed old month keeps its own payroll", () => {
  assert.deepEqual(resolvePayrollMonth({ today: "2026-11-05", viewedMonth: "2026-09" }), { month: "2026-09", autoShifted: false });
});

test("an explicit ?payroll choice always wins, invalid values are ignored", () => {
  assert.deepEqual(resolvePayrollMonth({ today: "2026-11-05", viewedMonth: "2026-11", requested: "2026-11" }), { month: "2026-11", autoShifted: false });
  assert.deepEqual(resolvePayrollMonth({ today: "2026-11-05", viewedMonth: "2026-11", requested: "2026-13" }), { month: "2026-10", autoShifted: true });
  assert.deepEqual(resolvePayrollMonth({ today: "2026-11-05", viewedMonth: "2026-11", requested: "x" }), { month: "2026-10", autoShifted: true });
});

test("monthNotFinished flags only the current (or a future) month", () => {
  assert.equal(monthNotFinished("2026-11", "2026-11-24"), true);
  assert.equal(monthNotFinished("2026-12", "2026-11-24"), true);
  assert.equal(monthNotFinished("2026-10", "2026-11-01"), false);
});
