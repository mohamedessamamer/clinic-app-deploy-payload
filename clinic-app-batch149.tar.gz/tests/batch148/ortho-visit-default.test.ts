import { test } from "node:test";
import assert from "node:assert/strict";
import { suggestOrthoVisitService, type OrthoVisitDefaultInput } from "../../src/lib/ortho-visit-service.ts";

const base: OrthoVisitDefaultInput = {
  purpose_type: null, purpose_service_name: null, purpose_service_name_en: null, purpose_service_category: null,
  purpose_linked_invoice_id: null, purpose_linked_service_name: null, purpose_linked_service_name_en: null, purpose_linked_service_category: null,
};

test("bonding purposes map to the arch", () => {
  assert.equal(suggestOrthoVisitService({ ...base, purpose_type: "bonding_upper" }), "Bonding Upper");
  assert.equal(suggestOrthoVisitService({ ...base, purpose_type: "bonding_lower" }), "Bonding Lower");
});

test("ortho follow-up service and linked ortho invoice -> Follow up", () => {
  assert.equal(suggestOrthoVisitService({ ...base, purpose_type: "service", purpose_service_name: "متابعة تقويم", purpose_service_category: "تقويم" }), "Follow up");
  assert.equal(suggestOrthoVisitService({ ...base, purpose_type: "service", purpose_service_name: "متابعة", purpose_service_category: "عام", purpose_linked_invoice_id: 5, purpose_linked_service_category: "Orthodontics" }), "Follow up");
  // "فك علوي" = jaw, not debonding
  assert.equal(suggestOrthoVisitService({ ...base, purpose_type: "service", purpose_service_name: "تقويم فك علوي", purpose_service_category: "تقويم" }), "Follow up");
});

test("named ortho services", () => {
  assert.equal(suggestOrthoVisitService({ ...base, purpose_type: "service", purpose_service_name: "فك التقويم", purpose_service_category: "تقويم" }), "Debonding");
  assert.equal(suggestOrthoVisitService({ ...base, purpose_type: "service", purpose_service_name_en: "Retainer", purpose_service_category: "Orthodontics" }), "Retainer delivery");
  assert.equal(suggestOrthoVisitService({ ...base, purpose_type: "service", purpose_service_name: "كشف تقويم", purpose_service_category: "تقويم" }), "Consultation");
});

test("real clinic service names", () => {
  const svc = (name: string, name_en: string, ends = 0) => suggestOrthoVisitService({ ...base, purpose_type: "service", purpose_service_name: name, purpose_service_name_en: name_en, purpose_service_category: "Orthodontics", purpose_service_ends_ortho: ends });
  assert.equal(svc("متابعة تقويم حالة من الداخل", "Ortho follow up"), "Follow up");
  assert.equal(svc("متابعة تقويم حالة من الخارج", "Follow up for external case"), "Follow up");
  assert.equal(svc("مثبت شفاف", "Vaccum retainer"), "Retainer delivery");
  assert.equal(svc("مثبت دائم", "Fixed retainer"), "Retainer delivery");
  assert.equal(svc("اعادة لصق مثبت دائم", "Rebonding for fixed retainer"), "Follow up");
  assert.equal(svc("اعادة لصق فص", "Rebonding for bracket"), "Follow up");
  assert.equal(svc("موسع فك", "Hyrax expander"), "Follow up");
  assert.equal(svc("خدمة فك", "Removal", 1), "Debonding");
});

test("non-ortho or no purpose stays empty", () => {
  assert.equal(suggestOrthoVisitService(base), null);
  assert.equal(suggestOrthoVisitService({ ...base, purpose_type: "service", purpose_service_name: "حشو", purpose_service_category: "علاج تحفظي" }), null);
});
