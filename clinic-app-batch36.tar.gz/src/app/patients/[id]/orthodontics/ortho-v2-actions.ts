"use server";

// شارت التقويم v2 — أكشنز السيرفر الحقيقية (دمج البروتوتايب المعزول مع
// السيستم الحقيقي، 2026-08-27). ملف منفصل عن actions.ts القديم (بيانات
// تشخيص/bonding/rebonding "batch 25" الأصلية) بقرار متعمد: نفس منطق الصلاحيات
// (canEditMedicalRecordFor)، لكن سطح جديد كليًا (زيارات فولو أب حقيقية، سجل
// خصومات مخزون قابل للـUndo، حالة كل سن لوحده) — إضافي، مش بديل، عشان لو حصل
// أي مشكلة يبقى سهل نرجع نعطّل الاستدعاء الجديد من غير ما نلمس الأكشنز
// القديمة اللي كانت شغالة بالفعل.
//
// خصم المخزون الحقيقي: كل خصم بيتسجل في ortho_inventory_deductions (ledger
// قابل للـUndo)، وبيحاول كمان يخصم من inventory_items.quantity الحقيقي عن
// طريق مطابقة الاسم (case-insensitive، أول بالنص كامل زي "Wire 16 NiTi
// (Upper)"، ولو مفيش تطابق بيجرب الاسم الأساسي من غير اللاحقة زي "Wire" أو
// "Brackets" أو "Tubes"). لو مفيش أي تطابق، الخصم بيتسجل في تقرير الشارت
// (traceable) من غير ما يأثر على أرقام مخزون حقيقية — ده أفضل من نخترع صنف
// مخزون جديد تلقائيًا من غير ما حد يقصد كده. لو حصل كتير، الحل: يتضاف صنف
// بنفس الاسم في صفحة المخزون.

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { UPPER_ROW, LOWER_ROW, ALL_TEETH } from "@/lib/ortho/fdi-teeth";
import type { Role } from "@/lib/auth";
import { getClinicToday } from "@/lib/clinic-date";
import type { Transaction } from "kysely";
import type { Database } from "@/lib/db/types";
import { buildOrthoTreatmentParagraph, syncOrthoNoteToMedicalVisit, clearSyncedOrthoNote } from "@/lib/ortho-treatment-sync";

function canEditMedicalRecordFor(role: string | undefined): boolean {
  return role === "doctor" || role === "admin" || role === "clinic_manager";
}

type ActionResult = { ok: boolean; reason?: string; [key: string]: unknown };

function isMolarPosition(position: number): boolean {
  return position >= 6;
}

const TOOTH_BY_FDI = Object.fromEntries(ALL_TEETH.map((t) => [t.fdi, t]));

interface ToothState {
  bracket: "none" | "bonded" | "broken";
  debondDate: string | null;
  bondedDate: string | null;
  rebondCount: number;
  extracted: boolean;
  comment: string;
}

function emptyToothState(): ToothState {
  return { bracket: "none", debondDate: null, bondedDate: null, rebondCount: 0, extracted: false, comment: "" };
}

function parseToothStates(raw: string | null): Record<string, ToothState> {
  if (!raw) return {};
  try {
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

function parseCounts(raw: string | null): Record<string, number> {
  if (!raw) return {};
  try {
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

function parseFlags(raw: string | null): Record<string, boolean> {
  if (!raw) return {};
  try {
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

async function ensureChartRow(patientId: number, userId: number) {
  const existing = await db
    .selectFrom("orthodontic_charts")
    .select(["id"])
    .where("patient_id", "=", patientId)
    .executeTakeFirst();
  if (existing) return;
  await db.insertInto("orthodontic_charts").values({ patient_id: patientId, created_by: userId, updated_by: userId }).execute();
}

async function logChartEvent(
  trx: Transaction<Database>,
  params: { patientId: number; field: string; reason: string; date: string; userId: number }
) {
  await trx
    .insertInto("audit_log")
    .values({
      entity_type: "orthodontic_chart",
      entity_id: params.patientId,
      field: params.field,
      old_value: null,
      new_value: null,
      reason: params.reason,
      changed_by: params.userId,
      event_date: params.date,
    })
    .execute();
}

// بيحاول يلاقي صنف حقيقي في المخزون بنفس اسم الخصم — أول بالاسم كامل، بعدين
// بالاسم الأساسي من غير أي لاحقة بعد "—" أو "(". مطابقة case-insensitive.
async function resolveInventoryItemId(trx: Transaction<Database>, label: string): Promise<number | null> {
  const baseLabel = label.split(/[—(]/)[0].trim();
  const candidates = Array.from(new Set([label.trim(), baseLabel]));
  for (const candidate of candidates) {
    if (!candidate) continue;
    const row = await trx
      .selectFrom("inventory_items")
      .select(["id"])
      .where((eb) => eb("name", "like", candidate))
      .executeTakeFirst();
    if (row) return row.id;
  }
  return null;
}

// خصم مخزون حقيقي — بيسجل في ortho_inventory_deductions (ledger)، وبيدمج
// خصومات الـTubes بنفس التاريخ (زي البروتوتايب بالظبط: كل تيوبز اتركبت في
// نفس تاريخ الزيارة بيتحطوا في سطر واحد بعددهم وأرقام الأسنان)، وبيخصم من
// inventory_items.quantity الحقيقي لو لقى صنف بنفس الاسم.
async function deductInventory(
  trx: Transaction<Database>,
  params: { patientId: number; visitId: number | null; label: string; qty: number; teeth?: number[]; date: string; userId: number }
) {
  const itemId = await resolveInventoryItemId(trx, params.label);

  // الدمج بيحصل لأي خصم بيتبعت معاه أرقام أسنان (teeth) — مش بس Tubes زي ما
  // كان الحال قبل كده — عشان بعد كده نقدر نعمل ريفند جزئي لسن واحد من سطر
  // مجمّع (زي "Brackets — Bonding Upper") لما يتصحح إنه ما كانش المفروض يتركّب.
  if (params.teeth && params.teeth.length > 0 && params.visitId === null) {
    const existing = await trx
      .selectFrom("ortho_inventory_deductions")
      .selectAll()
      .where("patient_id", "=", params.patientId)
      .where("label", "=", params.label)
      .where("deduction_date", "=", params.date)
      .where("visit_id", "is", null)
      .where("undone_at", "is", null)
      .executeTakeFirst();

    if (existing) {
      const existingTeeth: number[] = existing.teeth ? JSON.parse(existing.teeth) : [];
      await trx
        .updateTable("ortho_inventory_deductions")
        .set({ qty: existing.qty + params.qty, teeth: JSON.stringify([...existingTeeth, ...params.teeth]) })
        .where("id", "=", existing.id)
        .execute();
      if (itemId) {
        await trx.updateTable("inventory_items").set({ quantity: (eb) => eb("quantity", "-", params.qty) }).where("id", "=", itemId).execute();
      }
      return;
    }
  }

  await trx
    .insertInto("ortho_inventory_deductions")
    .values({
      patient_id: params.patientId,
      visit_id: params.visitId,
      item_id: itemId,
      label: params.label,
      qty: params.qty,
      teeth: params.teeth && params.teeth.length > 0 ? JSON.stringify(params.teeth) : null,
      deduction_date: params.date,
      created_by: params.userId,
    })
    .execute();

  if (itemId) {
    await trx.updateTable("inventory_items").set({ quantity: (eb) => eb("quantity", "-", params.qty) }).where("id", "=", itemId).execute();
  }
}

// --- أعلى الصفحة (بروفايل الشارت + Treatment Plan) --------------------------

export async function saveOrthoTopSectionAction(formData: FormData): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const patientId = Number(formData.get("patient_id"));
  if (!patientId) return { ok: false, reason: "بيانات ناقصة" };

  await ensureChartRow(patientId, session!.userId);

  const extractionQuadrants = {
    ur: String(formData.get("extraction_ur") || ""),
    ul: String(formData.get("extraction_ul") || ""),
    lr: String(formData.get("extraction_lr") || ""),
    ll: String(formData.get("extraction_ll") || ""),
  };
  const hasExtraction = Object.values(extractionQuadrants).some(Boolean);

  await db
    .updateTable("orthodontic_charts")
    .set({
      bracket_type: String(formData.get("bracket_type") || "").trim() || null,
      prescription: String(formData.get("prescription") || "").trim() || null,
      slot: String(formData.get("slot") || "").trim() || null,
      chief_complaint: String(formData.get("chief_complaint") || "").trim() || null,
      extraction_quadrants: hasExtraction ? JSON.stringify(extractionQuadrants) : null,
      anchorage_device: String(formData.get("anchorage_device") || "").trim() || null,
      treatment_note: String(formData.get("treatment_note") || "").trim() || null,
      updated_by: session!.userId,
      updated_at: new Date().toISOString(),
    })
    .where("patient_id", "=", patientId)
    .execute();

  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true };
}

// --- Diagnostic chart --------------------------------------------------------
// تحديث جزئي بس (مش upsert كامل الصف زي saveOrthodonticChartAction القديمة في
// actions.ts) — عمدًا فعل منفصل، عشان الحقول دي والحقول اللي أعلى الصفحة
// (chief_complaint/prescription وغيرهم في saveOrthoTopSectionAction فوق)
// بتتحفظ من نموذجين منفصلين على الشاشة؛ لو استخدمنا upsert كامل الصف في
// الاتنين كانوا هيمسحوا بيانات بعض (كل حفظ من فورم بيبعت بس الحقول اللي هو
// عارفها، فالتانية بترجع null). التحديث الجزئي هنا بيلمس بس أعمدة الـDiagnostic
// نفسها.
export async function saveOrthoDiagnosticAction(formData: FormData): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const patientId = Number(formData.get("patient_id"));
  if (!patientId) return { ok: false, reason: "بيانات ناقصة" };

  await ensureChartRow(patientId, session!.userId);

  const str = (key: string) => {
    const raw = String(formData.get(key) ?? "").trim();
    return raw || null;
  };
  const num = (key: string) => {
    const raw = formData.get(key);
    if (raw == null || raw === "") return null;
    const n = Number(raw);
    return Number.isFinite(n) ? n : null;
  };

  await db
    .updateTable("orthodontic_charts")
    .set({
      antero_posterior: str("antero_posterior") as "class1" | "class2" | "class3" | null,
      facial_height: str("facial_height") as "increased" | "average" | "decreased" | null,
      mx_incisor_inclination: str("mx_incisor_inclination") as "proclined" | "average" | "retroclined" | null,
      mn_incisor_inclination: str("mn_incisor_inclination") as "proclined" | "average" | "retroclined" | null,
      molar_relation_right: str("molar_relation_right") as "class1" | "class2" | "class3" | null,
      molar_relation_left: str("molar_relation_left") as "class1" | "class2" | "class3" | null,
      overbite: str("overbite") as "open_bite" | "average" | "deep_bite" | null,
      overjet: str("overjet") as "increased" | "average" | "decreased" | null,
      midline_upper_direction: str("midline_upper_direction") as "right" | "left" | null,
      midline_upper_mm: num("midline_upper_mm"),
      midline_lower_direction: str("midline_lower_direction") as "right" | "left" | null,
      midline_lower_mm: num("midline_lower_mm"),
      space_upper_type: str("space_upper_type") as "crowding" | "spacing" | null,
      space_upper_mm: num("space_upper_mm"),
      space_lower_type: str("space_lower_type") as "crowding" | "spacing" | null,
      space_lower_mm: num("space_lower_mm"),
      nasolabial_angle: str("nasolabial_angle") as "acute" | "average" | "obtuse" | null,
      lips: str("lips") as "competent" | "incompetent" | null,
      updated_by: session!.userId,
      updated_at: new Date().toISOString(),
    })
    .where("patient_id", "=", patientId)
    .execute();

  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true };
}

// --- الشارت التفاعلي ---------------------------------------------------------

export async function bulkBondAction(params: { patientId: number; arch: "upper" | "lower"; date: string }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, arch, date } = params;
  await ensureChartRow(patientId, session!.userId);

  const chart = await db.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const states = parseToothStates(chart.tooth_states);
  const row = arch === "upper" ? UPPER_ROW : LOWER_ROW;
  // الأسنان المخلوعة مستبعدة من التركيب ومن عدد المخزون مع بعض — لو سن اتسجل
  // إنه مخلوع قبل عمل خدمة البوندنج، منقدرش نركّبله براكت/تيوب خالص.
  const targets = row.filter((t) => t.position <= 6 && !(states[t.fdi]?.extracted ?? false));
  if (targets.length === 0) return { ok: false, reason: "كل أسنان الفك ده مخلوعة أو متركّبة بالفعل" };

  await db.transaction().execute(async (trx) => {
    const nextStates = { ...states };
    targets.forEach((t) => {
      const current = nextStates[t.fdi] ?? emptyToothState();
      nextStates[t.fdi] = { ...current, bracket: "bonded", debondDate: null, bondedDate: date };
    });
    await trx
      .updateTable("orthodontic_charts")
      .set({ tooth_states: JSON.stringify(nextStates), updated_by: session!.userId, updated_at: new Date().toISOString() })
      .where("patient_id", "=", patientId)
      .execute();

    const archLabel = arch === "upper" ? "Upper" : "Lower";
    const bracketTargets = targets.filter((t) => !isMolarPosition(t.position));
    const tubeTargets = targets.filter((t) => isMolarPosition(t.position));

    if (bracketTargets.length > 0) {
      await deductInventory(trx, {
        patientId,
        visitId: null,
        label: `Brackets — Bonding ${archLabel}`,
        qty: bracketTargets.length,
        teeth: bracketTargets.map((t) => t.fdi),
        date,
        userId: session!.userId,
      });
    }
    if (tubeTargets.length > 0) {
      await deductInventory(trx, {
        patientId,
        visitId: null,
        label: "Tubes",
        qty: tubeTargets.length,
        teeth: tubeTargets.map((t) => t.fdi),
        date,
        userId: session!.userId,
      });
    }

    await logChartEvent(trx, {
      patientId,
      field: "bulk_bond",
      reason: `Bulk bond — ${archLabel} arch (${targets.map((t) => t.fdi).join(", ")})`,
      date,
      userId: session!.userId,
    });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  revalidatePath("/inventory");
  return { ok: true };
}

export async function manualBondToothAction(params: { patientId: number; fdi: number; date: string }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, fdi, date } = params;
  const meta = TOOTH_BY_FDI[fdi];
  if (!meta) return { ok: false, reason: "سن غير معروف" };

  await ensureChartRow(patientId, session!.userId);
  const chart = await db.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const states = parseToothStates(chart.tooth_states);
  const current = states[fdi] ?? emptyToothState();
  if (current.extracted) return { ok: false, reason: `السن ${fdi} مخلوع — منقدرش نركّبله براكت/تيوب` };
  if (current.bracket === "bonded") return { ok: false, reason: "السن ده متركّب بالفعل" };

  const isMolar = isMolarPosition(meta.position);

  await db.transaction().execute(async (trx) => {
    const nextStates = { ...states, [fdi]: { ...current, bracket: "bonded" as const, bondedDate: date, debondDate: null } };
    await trx
      .updateTable("orthodontic_charts")
      .set({ tooth_states: JSON.stringify(nextStates), updated_by: session!.userId, updated_at: new Date().toISOString() })
      .where("patient_id", "=", patientId)
      .execute();

    await deductInventory(trx, {
      patientId,
      visitId: null,
      label: isMolar ? "Tubes" : `Bracket (tooth ${fdi})`,
      qty: 1,
      teeth: isMolar ? [fdi] : undefined,
      date,
      userId: session!.userId,
    });

    await logChartEvent(trx, {
      patientId,
      field: "manual_bond",
      reason: `Bonded ${isMolar ? "tube" : "bracket"} — tooth ${fdi}`,
      date,
      userId: session!.userId,
    });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  revalidatePath("/inventory");
  return { ok: true };
}

export async function confirmDebondAction(params: { patientId: number; fdi: number; date: string }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, fdi, date } = params;
  const chart = await db.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const states = parseToothStates(chart.tooth_states);
  const current = states[fdi] ?? emptyToothState();

  await db.transaction().execute(async (trx) => {
    const nextStates = { ...states, [fdi]: { ...current, bracket: "broken" as const, debondDate: date } };
    await trx
      .updateTable("orthodontic_charts")
      .set({ tooth_states: JSON.stringify(nextStates), updated_by: session!.userId, updated_at: new Date().toISOString() })
      .where("patient_id", "=", patientId)
      .execute();
    await logChartEvent(trx, { patientId, field: "debond", reason: `Debonded — tooth ${fdi}`, date, userId: session!.userId });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true };
}

// تصحيح غلطة بوندنج (السن أصلاً مكانش المفروض يتركّب) — يرجع لحالة "none" من
// غير ما يسجل debond حقيقي. لغاية 2026-08-27 كان مفيش أي تأثير على المخزون —
// اتصلح بناءً على بلاغ: الخصم الأصلي (وقت البوندنج الجماعي أو اليدوي) دلوقتي
// بيترجع (سن واحد بس، مش كل الخصم لو كان مجمّع لعدة أسنان زي "Brackets —
// Bonding Upper"/"Tubes") — أول ما نلاقي أقرب خصم فعلي (لسه ماتعملوش Undo)
// بيغطي السن ده.
export async function confirmNoBracketsAction(params: { patientId: number; fdi: number }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, fdi } = params;
  const meta = TOOTH_BY_FDI[fdi];
  const chart = await db.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const states = parseToothStates(chart.tooth_states);
  const current = states[fdi] ?? emptyToothState();
  const today = getClinicToday();
  const isMolar = meta ? isMolarPosition(meta.position) : false;
  const singleToothLabels = [`Bracket (tooth ${fdi})`, `New bracket (tooth ${fdi})`];
  const candidateLabels = isMolar ? ["Tubes", ...singleToothLabels] : ["Brackets — Bonding Upper", "Brackets — Bonding Lower", ...singleToothLabels];

  await db.transaction().execute(async (trx) => {
    const nextStates = { ...states, [fdi]: { ...current, bracket: "none" as const, debondDate: null, bondedDate: null } };
    await trx
      .updateTable("orthodontic_charts")
      .set({ tooth_states: JSON.stringify(nextStates), updated_by: session!.userId, updated_at: new Date().toISOString() })
      .where("patient_id", "=", patientId)
      .execute();

    const rows = await trx
      .selectFrom("ortho_inventory_deductions")
      .selectAll()
      .where("patient_id", "=", patientId)
      .where("undone_at", "is", null)
      .where("label", "in", candidateLabels)
      .orderBy("id", "desc")
      .execute();

    // لو السطر فيه teeth array (خصم مجمّع لعدة أسنان)، لازم يشمل السن ده فعلاً؛
    // لو من غير teeth (سطر مخصوص لسن واحد أصلاً)، اللابل نفسه كفاية.
    const target = rows.find((r) => {
      if (!r.teeth) return singleToothLabels.includes(r.label);
      try {
        return (JSON.parse(r.teeth) as number[]).includes(fdi);
      } catch {
        return false;
      }
    });

    let refunded = false;
    if (target) {
      if (target.teeth) {
        const teeth = (JSON.parse(target.teeth) as number[]).filter((t) => t !== fdi);
        if (teeth.length > 0) {
          await trx
            .updateTable("ortho_inventory_deductions")
            .set({ qty: target.qty - 1, teeth: JSON.stringify(teeth) })
            .where("id", "=", target.id)
            .execute();
        } else {
          await trx
            .updateTable("ortho_inventory_deductions")
            .set({ undone_by: session!.userId, undone_at: new Date().toISOString() })
            .where("id", "=", target.id)
            .execute();
        }
      } else {
        await trx
          .updateTable("ortho_inventory_deductions")
          .set({ undone_by: session!.userId, undone_at: new Date().toISOString() })
          .where("id", "=", target.id)
          .execute();
      }
      if (target.item_id) {
        await trx.updateTable("inventory_items").set({ quantity: (eb) => eb("quantity", "+", 1) }).where("id", "=", target.item_id).execute();
      }
      refunded = true;
    }

    await logChartEvent(trx, {
      patientId,
      field: "no_brackets",
      reason: `No-brackets correction — tooth ${fdi}${refunded ? " (inventory refunded)" : ""}`,
      date: today,
      userId: session!.userId,
    });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  revalidatePath("/inventory");
  return { ok: true };
}

// حذف زيارة فولو أب بالكامل من شارت التقويم — دفعة 27، طلب صريح: "دخلت خدمة
// غلط، عايز أمسحها كاملة وأدخلها تاني" بدل ما أتقيّد بالـEdit (اللي مايفتحش
// تغيير الـservice بعد ما تتحفظ). نفس صلاحية "delete_visits" الموجودة أصلاً
// لحذف زيارات الملف الطبي العادي (تأكيد المستخدم: "نفس صلاحية الحذف تطبق على
// شارت التقويم"), مش صلاحية جديدة مخصوصة.
//
// بيرجع كل حاجة اتسببت فيها الزيارة دي:
//   1) خصومات المخزون المربوطة بالزيارة مباشرة (visit_id) — إلاستكس/أوتايز/
//      باور تشين/بازر/كويل — بترجع لرصيد المخزون وتتمسح.
//   2) لو الزيارة دي هي اللي عملت bonding (bonding_applied=1)، بترجع حالة كل
//      سن لسه متسجل عليه إنه اتلزّق بنفس تاريخ الزيارة دي بالظبط (bondedDate
//      === visit_date) — معيار دقيق بيستثني تلقائيًا أي سن اتصحح بعدين بـ
//      "No brackets" أو اتفك/اتلزّق تاني بتاريخ مختلف. لكل سن من دول، بيتطبق
//      نفس منطق الريفند الجزئي بالظبط اللي في confirmNoBracketsAction فوق
//      (تشيل السن من الـteeth array لو الخصم مجمّع، أو تلغي الخصم كله لو ده
//      كان آخر سن فيه).
export async function deleteOrthoVisitAction(params: { patientId: number; visitId: number }): Promise<ActionResult> {
  const session = await getSession();
  if (!session) return { ok: false, reason: "غير مسموح" };
  const canDelete = await hasPermission(session.userId, session.role as Role, "delete_visits");
  if (!canDelete) return { ok: false, reason: "محتاج صلاحية حذف الزيارات" };

  const { patientId, visitId } = params;
  const visitRow = await db.selectFrom("ortho_visits").selectAll().where("id", "=", visitId).where("patient_id", "=", patientId).executeTakeFirst();
  if (!visitRow) return { ok: false, reason: "الزيارة دي مش موجودة" };

  let revertedTeeth = 0;

  await db.transaction().execute(async (trx) => {
    // (1) خصومات مربوطة بالزيارة مباشرة — نفس الاستهلاكات اللي بتترجع أصلاً
    // وقت الـEdit (شوف فوق)، بس هنا بترجع فعليًا للمخزون بدل ما تتسجل تاني.
    const tiedDeductions = await trx
      .selectFrom("ortho_inventory_deductions")
      .selectAll()
      .where("visit_id", "=", visitId)
      .where("undone_at", "is", null)
      .execute();
    for (const d of tiedDeductions) {
      if (d.item_id) {
        await trx.updateTable("inventory_items").set({ quantity: (eb) => eb("quantity", "+", d.qty) }).where("id", "=", d.item_id).execute();
      }
    }
    await trx.deleteFrom("ortho_inventory_deductions").where("visit_id", "=", visitId).execute();

    // (2) لو الزيارة دي عملت bonding، رجّع حالة الأسنان + خصومات البراكيت/التيوب
    if (visitRow.bonding_applied === 1) {
      const chart = await trx.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
      let states = parseToothStates(chart?.tooth_states ?? null);
      const arch = visitRow.service === "Bonding Upper" ? "upper" : "lower";
      const row = arch === "upper" ? UPPER_ROW : LOWER_ROW;
      const affected = row.filter((t) => {
        const st = states[t.fdi];
        return st && st.bracket === "bonded" && st.bondedDate === visitRow.visit_date;
      });

      for (const t of affected) {
        const isMolar = isMolarPosition(t.position);
        const singleToothLabels = [`Bracket (tooth ${t.fdi})`, `New bracket (tooth ${t.fdi})`];
        const candidateLabels = isMolar ? ["Tubes", ...singleToothLabels] : ["Brackets — Bonding Upper", "Brackets — Bonding Lower", ...singleToothLabels];
        const rows = await trx
          .selectFrom("ortho_inventory_deductions")
          .selectAll()
          .where("patient_id", "=", patientId)
          .where("undone_at", "is", null)
          .where("label", "in", candidateLabels)
          .orderBy("id", "desc")
          .execute();
        const target = rows.find((r) => {
          if (!r.teeth) return singleToothLabels.includes(r.label);
          try {
            return (JSON.parse(r.teeth) as number[]).includes(t.fdi);
          } catch {
            return false;
          }
        });
        if (target) {
          if (target.teeth) {
            const teeth = (JSON.parse(target.teeth) as number[]).filter((x) => x !== t.fdi);
            if (teeth.length > 0) {
              await trx.updateTable("ortho_inventory_deductions").set({ qty: target.qty - 1, teeth: JSON.stringify(teeth) }).where("id", "=", target.id).execute();
            } else {
              await trx
                .updateTable("ortho_inventory_deductions")
                .set({ undone_by: session!.userId, undone_at: new Date().toISOString() })
                .where("id", "=", target.id)
                .execute();
            }
          } else {
            await trx
              .updateTable("ortho_inventory_deductions")
              .set({ undone_by: session!.userId, undone_at: new Date().toISOString() })
              .where("id", "=", target.id)
              .execute();
          }
          if (target.item_id) {
            await trx.updateTable("inventory_items").set({ quantity: (eb) => eb("quantity", "+", 1) }).where("id", "=", target.item_id).execute();
          }
        }
        states = { ...states, [t.fdi]: { ...states[t.fdi], bracket: "none", bondedDate: null, debondDate: null } };
        revertedTeeth++;
      }

      if (revertedTeeth > 0) {
        await trx
          .updateTable("orthodontic_charts")
          .set({ tooth_states: JSON.stringify(states), updated_by: session!.userId, updated_at: new Date().toISOString() })
          .where("patient_id", "=", patientId)
          .execute();
      }
    }

    // (3) الزيارة نفسها
    await trx.deleteFrom("ortho_visits").where("id", "=", visitId).execute();

    // دفعة 27 (P2.4): امسح مزامنة المعالجة من الزيارة المقابلة بالملف الطبي —
    // إلا لو لسه فيه زيارة متابعة تانية باقية لنفس المريض/التاريخ (نادر، بس
    // ممكن)، وقتها بنعيد المزامنة بمحتواها هي بدل ما نمسح المعالجة بالغلط.
    const remaining = await trx
      .selectFrom("ortho_visits")
      .selectAll()
      .where("patient_id", "=", patientId)
      .where("visit_date", "=", visitRow.visit_date)
      .orderBy("id", "desc")
      .executeTakeFirst();
    if (remaining?.doctor_id) {
      const paragraph = buildOrthoTreatmentParagraph({
        service: remaining.service,
        upperWireSize: remaining.upper_wire_size,
        upperWireType: remaining.upper_wire_type,
        lowerWireSize: remaining.lower_wire_size,
        lowerWireType: remaining.lower_wire_type,
        note: remaining.note,
      });
      await syncOrthoNoteToMedicalVisit(trx, {
        patientId,
        visitDate: visitRow.visit_date,
        paragraph,
        performingDoctorId: remaining.doctor_id,
      });
    } else {
      await clearSyncedOrthoNote(trx, { patientId, visitDate: visitRow.visit_date });
    }

    await logChartEvent(trx, {
      patientId,
      field: "delete_visit",
      reason: `Deleted follow-up visit (${visitRow.visit_date}, ${visitRow.service || "—"})${revertedTeeth > 0 ? ` — reverted bonding on ${revertedTeeth} tooth/teeth` : ""}`,
      date: getClinicToday(),
      userId: session!.userId,
    });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  revalidatePath(`/patients/${patientId}`);
  revalidatePath("/inventory");
  return { ok: true };
}

export async function confirmRebondAction(params: { patientId: number; fdi: number; kind: "new" | "old"; date: string }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, fdi, kind, date } = params;
  const meta = TOOTH_BY_FDI[fdi];
  if (!meta) return { ok: false, reason: "سن غير معروف" };

  const chart = await db.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const states = parseToothStates(chart.tooth_states);
  const current = states[fdi] ?? emptyToothState();
  const isMolar = isMolarPosition(meta.position);

  await db.transaction().execute(async (trx) => {
    const nextStates = {
      ...states,
      [fdi]: { ...current, bracket: "bonded" as const, debondDate: null, bondedDate: date, rebondCount: current.rebondCount + 1 },
    };
    await trx
      .updateTable("orthodontic_charts")
      .set({ tooth_states: JSON.stringify(nextStates), updated_by: session!.userId, updated_at: new Date().toISOString() })
      .where("patient_id", "=", patientId)
      .execute();

    if (kind === "new") {
      await deductInventory(trx, {
        patientId,
        visitId: null,
        label: isMolar ? "Tubes" : `New bracket (tooth ${fdi})`,
        qty: 1,
        teeth: isMolar ? [fdi] : undefined,
        date,
        userId: session!.userId,
      });
    }

    await logChartEvent(trx, {
      patientId,
      field: "rebond",
      reason: `Rebonded (${kind} ${isMolar ? "tube" : "bracket"}) — tooth ${fdi}`,
      date,
      userId: session!.userId,
    });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  revalidatePath("/inventory");
  return { ok: true };
}

export async function toggleExtractedAction(params: { patientId: number; fdi: number }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, fdi } = params;
  await ensureChartRow(patientId, session!.userId);
  const chart = await db.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const states = parseToothStates(chart.tooth_states);
  const current = states[fdi] ?? emptyToothState();
  const wasExtracted = current.extracted;
  const today = getClinicToday();

  await db.transaction().execute(async (trx) => {
    const nextStates = { ...states, [fdi]: { ...current, extracted: !wasExtracted } };
    await trx
      .updateTable("orthodontic_charts")
      .set({ tooth_states: JSON.stringify(nextStates), updated_by: session!.userId, updated_at: new Date().toISOString() })
      .where("patient_id", "=", patientId)
      .execute();
    await logChartEvent(trx, {
      patientId,
      field: "extraction",
      reason: wasExtracted ? `Undo extraction — tooth ${fdi}` : `Extracted — tooth ${fdi}`,
      date: today,
      userId: session!.userId,
    });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true };
}

export async function saveToothCommentAction(params: { patientId: number; fdi: number; comment: string }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, fdi, comment } = params;
  await ensureChartRow(patientId, session!.userId);
  const chart = await db.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const states = parseToothStates(chart.tooth_states);
  const current = states[fdi] ?? emptyToothState();
  const nextStates = { ...states, [fdi]: { ...current, comment } };

  await db
    .updateTable("orthodontic_charts")
    .set({ tooth_states: JSON.stringify(nextStates), updated_by: session!.userId, updated_at: new Date().toISOString() })
    .where("patient_id", "=", patientId)
    .execute();

  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true };
}

export async function recordStrippingAction(params: { patientId: number; gapId: string }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, gapId } = params;
  await ensureChartRow(patientId, session!.userId);
  const chart = await db.selectFrom("orthodontic_charts").select(["strip_counts"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const counts = parseCounts(chart.strip_counts);
  const today = getClinicToday();

  await db.transaction().execute(async (trx) => {
    const nextCounts = { ...counts, [gapId]: (counts[gapId] ?? 0) + 1 };
    await trx
      .updateTable("orthodontic_charts")
      .set({ strip_counts: JSON.stringify(nextCounts), updated_by: session!.userId, updated_at: new Date().toISOString() })
      .where("patient_id", "=", patientId)
      .execute();
    await logChartEvent(trx, {
      patientId,
      field: "stripping",
      reason: `Stripping — between ${gapId.replace("-", " & ")}`,
      date: today,
      userId: session!.userId,
    });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true };
}

export async function undoStrippingAction(params: { patientId: number; gapId: string }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, gapId } = params;
  const chart = await db.selectFrom("orthodontic_charts").select(["strip_counts"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const counts = parseCounts(chart.strip_counts);
  const current = counts[gapId] ?? 0;
  const today = getClinicToday();

  await db.transaction().execute(async (trx) => {
    const nextCounts = { ...counts };
    if (current <= 1) delete nextCounts[gapId];
    else nextCounts[gapId] = current - 1;
    await trx
      .updateTable("orthodontic_charts")
      .set({ strip_counts: Object.keys(nextCounts).length ? JSON.stringify(nextCounts) : null, updated_by: session!.userId, updated_at: new Date().toISOString() })
      .where("patient_id", "=", patientId)
      .execute();
    await logChartEvent(trx, {
      patientId,
      field: "stripping_undo",
      reason: `Stripping undo — between ${gapId.replace("-", " & ")}`,
      date: today,
      userId: session!.userId,
    });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true };
}

export async function toggleMiniscrewAction(params: { patientId: number; gapId: string }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, gapId } = params;
  await ensureChartRow(patientId, session!.userId);
  const chart = await db.selectFrom("orthodontic_charts").select(["miniscrews"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const flags = parseFlags(chart.miniscrews);
  const placed = !flags[gapId];
  const today = getClinicToday();

  await db.transaction().execute(async (trx) => {
    const nextFlags = { ...flags, [gapId]: placed };
    await trx
      .updateTable("orthodontic_charts")
      .set({ miniscrews: JSON.stringify(nextFlags), updated_by: session!.userId, updated_at: new Date().toISOString() })
      .where("patient_id", "=", patientId)
      .execute();
    await logChartEvent(trx, {
      patientId,
      field: "miniscrew",
      reason: `Miniscrew ${placed ? "placed" : "removed"} — between ${gapId.replace("-", " & ")}`,
      date: today,
      userId: session!.userId,
    });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true };
}

// --- زيارات الفولو أب --------------------------------------------------------

interface VisitInput {
  patientId: number;
  visitId?: number; // موجود = تعديل زيارة اتحفظت قبل كده، غير موجود = أول حفظ
  date: string;
  service: string;
  upperWireSize: string;
  upperWireType: string;
  lowerWireSize: string;
  lowerWireType: string;
  note: string;
  elasticsDispensed: boolean;
  elasticsSize: string;
  otieColor: string;
  powerChainQty: string;
  buttonsQty: string;
  compressedCoilMm: string;
  doctorId: number | null;
}

// نفس نطاق قائمة الطبيب في الشارت: عند وجود موعد في تاريخ الزيارة، لا نقبل إلا
// صاحب الموعد أو مساعديه المعرّفين له. لو لا يوجد موعد، تظل كل قائمة الأطباء
// النشطين متاحة لتسجيل زيارة قديمة أو زيارة بدون حجز.
async function allowedOrthoDoctorIds(patientId: number, visitDate: string): Promise<number[]> {
  const appointment = await db
    .selectFrom("appointments")
    .select(["doctor_id"])
    .where("patient_id", "=", patientId)
    .where("appointment_date", "=", visitDate)
    .where("status", "!=", "cancelled")
    .orderBy("start_time", "asc")
    .executeTakeFirst();

  if (!appointment) {
    const activeDoctors = await db.selectFrom("doctors").select("id").where("active", "=", 1).execute();
    return activeDoctors.map((doctor) => doctor.id);
  }

  const appointmentDoctor = await db
    .selectFrom("doctors")
    .select(["id", "is_consultant"])
    .where("id", "=", appointment.doctor_id)
    .where("active", "=", 1)
    .executeTakeFirst();
  if (!appointmentDoctor) return [];
  if (appointmentDoctor.is_consultant !== 1) return [appointmentDoctor.id];

  const assistants = await db
    .selectFrom("consultant_assistants")
    .innerJoin("doctors", "doctors.id", "consultant_assistants.assistant_doctor_id")
    .select("doctors.id")
    .where("consultant_assistants.consultant_doctor_id", "=", appointmentDoctor.id)
    .where("doctors.active", "=", 1)
    .execute();
  return [appointmentDoctor.id, ...assistants.map((assistant) => assistant.id)];
}

export async function saveOrthoVisitAction(input: VisitInput): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, date } = input;
  if (!patientId || !date) return { ok: false, reason: "بيانات ناقصة" };
  // الدكتور بقى إجباري قبل الحفظ (طلب صريح من المستخدم) — نفس نمط validation
  // الحقيقي في السيرفر، مش بس تعطيل الزرار في الواجهة.
  const selectedDoctorId = input.doctorId;
  if (!selectedDoctorId) return { ok: false, reason: "لازم تختار الدكتور قبل الحفظ" };
  const allowedDoctorIds = await allowedOrthoDoctorIds(patientId, date);
  if (!allowedDoctorIds.includes(selectedDoctorId)) {
    return { ok: false, reason: "الدكتور المختار لا يتبع موعد هذه الزيارة. اختر صاحب الموعد أو أحد مساعديه." };
  }

  // الوير لازم يتحدد مقاس ونوع مع بعض — "Same" أو فاضي يعدي عادي، لكن مقاس
  // من غير نوع (أو العكس) منقدرش نخصمه صح من المخزون. نفس قاعدة البروتوتايب،
  // اتفعّلت هنا كمان (validation حقيقي في السيرفر، مش بس واجهة).
  const isRealWire = (v: string) => v !== "" && v !== "Same";
  const upperSizeSet = isRealWire(input.upperWireSize);
  const upperTypeSet = isRealWire(input.upperWireType);
  const lowerSizeSet = isRealWire(input.lowerWireSize);
  const lowerTypeSet = isRealWire(input.lowerWireType);
  if (upperSizeSet !== upperTypeSet || lowerSizeSet !== lowerTypeSet) {
    return { ok: false, reason: "الوير لازم يتحدد له مقاس ونوع مع بعض (أو يتسيب Same/فاضي)" };
  }

  let visitRow = input.visitId
    ? await db.selectFrom("ortho_visits").selectAll().where("id", "=", input.visitId).where("patient_id", "=", patientId).executeTakeFirst()
    : undefined;

  const isEdit = Boolean(visitRow);
  if (input.visitId && !visitRow) return { ok: false, reason: "الزيارة دي مش موجودة" };

  if (isEdit) {
    const canEditAfterSave = await hasPermission(session!.userId, session!.role as Role, "edit_ortho_visit_after_save");
    if (!canEditAfterSave) return { ok: false, reason: "محتاج صلاحية تعديل الزيارة بعد الحفظ" };
  }

  // خدمة الـBonding بتتقفل نهائيًا بمجرد ما تتطبق مرة واحدة — لو الزيارة دي
  // كانت Bonding قبل كده، الخدمة المسجلة بتفضل زي ما هي حتى لو القيمة الجديدة
  // مختلفة (دفاع في السيرفر، مش بس الواجهة المقفولة).
  const bondingAlreadyApplied = visitRow?.bonding_applied === 1;
  const service = bondingAlreadyApplied ? visitRow!.service : input.service;
  const willTriggerBonding = !bondingAlreadyApplied && (service === "Bonding Upper" || service === "Bonding Lower");

  const result = await db.transaction().execute(async (trx) => {
    let visitId: number;

    if (isEdit) {
      // إعادة حفظ بعد Edit — تشيل خصومات الزيارة دي القديمة الأول (مش خصومات
      // الـbonding، دي مش متعلّمة بـvisit_id خالص) وبعدين تسجل من جديد بالقيم
      // الحالية — استبدال نضيف، مش تكرار.
      await trx.deleteFrom("ortho_inventory_deductions").where("visit_id", "=", visitRow!.id).execute();
      await trx
        .updateTable("ortho_visits")
        .set({
          visit_date: input.date,
          service,
          upper_wire_size: input.upperWireSize || null,
          upper_wire_type: input.upperWireType || null,
          lower_wire_size: input.lowerWireSize || null,
          lower_wire_type: input.lowerWireType || null,
          note: input.note || null,
          elastics_dispensed: input.elasticsDispensed ? 1 : 0,
          elastics_size: input.elasticsDispensed ? input.elasticsSize || null : null,
          otie_color: input.otieColor || null,
          power_chain_qty: input.powerChainQty ? Number(input.powerChainQty) : null,
          buttons_qty: input.buttonsQty ? Number(input.buttonsQty) : null,
          compressed_coil_mm: input.compressedCoilMm ? Number(input.compressedCoilMm) : null,
          doctor_id: input.doctorId,
          bonding_applied: bondingAlreadyApplied ? 1 : willTriggerBonding ? 1 : 0,
          updated_by: session!.userId,
          updated_at: new Date().toISOString(),
        })
        .where("id", "=", visitRow!.id)
        .execute();
      visitId = visitRow!.id;
    } else {
      const inserted = await trx
        .insertInto("ortho_visits")
        .values({
          patient_id: patientId,
          visit_date: input.date,
          service,
          upper_wire_size: input.upperWireSize || null,
          upper_wire_type: input.upperWireType || null,
          lower_wire_size: input.lowerWireSize || null,
          lower_wire_type: input.lowerWireType || null,
          note: input.note || null,
          elastics_dispensed: input.elasticsDispensed ? 1 : 0,
          elastics_size: input.elasticsDispensed ? input.elasticsSize || null : null,
          otie_color: input.otieColor || null,
          power_chain_qty: input.powerChainQty ? Number(input.powerChainQty) : null,
          buttons_qty: input.buttonsQty ? Number(input.buttonsQty) : null,
          compressed_coil_mm: input.compressedCoilMm ? Number(input.compressedCoilMm) : null,
          doctor_id: input.doctorId,
          bonding_applied: willTriggerBonding ? 1 : 0,
          created_by: session!.userId,
          updated_by: session!.userId,
        })
        .returning(["id"])
        .executeTakeFirstOrThrow();
      visitId = inserted.id;
    }

    if (willTriggerBonding) {
      const arch = service === "Bonding Upper" ? "upper" : "lower";
      const chart = await trx.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
      const states = parseToothStates(chart?.tooth_states ?? null);
      const row = arch === "upper" ? UPPER_ROW : LOWER_ROW;
      const targets = row.filter((t) => t.position <= 6 && !(states[t.fdi]?.extracted ?? false));
      if (targets.length > 0) {
        const nextStates = { ...states };
        targets.forEach((t) => {
          const current = nextStates[t.fdi] ?? emptyToothState();
          nextStates[t.fdi] = { ...current, bracket: "bonded", debondDate: null, bondedDate: input.date };
        });
        // ensureChartRow() itself queries via the module-level `db`, not `trx` — fine
        // functionally (same underlying connection), but calling it from inside an
        // already-open transaction is a correctness smell worth avoiding, so this one
        // spot does the same "insert row if missing" check directly on `trx` instead.
        const existingChart = await trx.selectFrom("orthodontic_charts").select(["id"]).where("patient_id", "=", patientId).executeTakeFirst();
        if (!existingChart) {
          await trx.insertInto("orthodontic_charts").values({ patient_id: patientId, created_by: session!.userId, updated_by: session!.userId }).execute();
        }
        await trx
          .updateTable("orthodontic_charts")
          .set({ tooth_states: JSON.stringify(nextStates), updated_by: session!.userId, updated_at: new Date().toISOString() })
          .where("patient_id", "=", patientId)
          .execute();

        const archLabel = arch === "upper" ? "Upper" : "Lower";
        const bracketTargets = targets.filter((t) => !isMolarPosition(t.position));
        const tubeTargets = targets.filter((t) => isMolarPosition(t.position));
        if (bracketTargets.length > 0) {
          await deductInventory(trx, {
            patientId,
            visitId: null,
            label: `Brackets — Bonding ${archLabel}`,
            qty: bracketTargets.length,
            teeth: bracketTargets.map((t) => t.fdi),
            date: input.date,
            userId: session!.userId,
          });
        }
        if (tubeTargets.length > 0) {
          await deductInventory(trx, {
            patientId,
            visitId: null,
            label: "Tubes",
            qty: tubeTargets.length,
            teeth: tubeTargets.map((t) => t.fdi),
            date: input.date,
            userId: session!.userId,
          });
        }
        await logChartEvent(trx, {
          patientId,
          field: "bulk_bond",
          reason: `Bulk bond — ${archLabel} arch (${targets.map((t) => t.fdi).join(", ")})`,
          date: input.date,
          userId: session!.userId,
        });
      }
    }

    if (upperSizeSet) {
      await deductInventory(trx, {
        patientId,
        visitId,
        label: `Wire ${input.upperWireSize} ${input.upperWireType} (Upper)`,
        qty: 1,
        date: input.date,
        userId: session!.userId,
      });
    }
    if (lowerSizeSet) {
      await deductInventory(trx, {
        patientId,
        visitId,
        label: `Wire ${input.lowerWireSize} ${input.lowerWireType} (Lower)`,
        qty: 1,
        date: input.date,
        userId: session!.userId,
      });
    }
    if (input.elasticsDispensed && input.elasticsSize) {
      await deductInventory(trx, { patientId, visitId, label: `Elastics ${input.elasticsSize}`, qty: 1, date: input.date, userId: session!.userId });
    }
    if (input.otieColor) {
      await deductInventory(trx, { patientId, visitId, label: `O-ties — ${input.otieColor}`, qty: 1, date: input.date, userId: session!.userId });
    }
    const powerChainQty = parseInt(input.powerChainQty, 10);
    if (powerChainQty > 0) {
      await deductInventory(trx, { patientId, visitId, label: "Power chain links", qty: powerChainQty, date: input.date, userId: session!.userId });
    }
    const buttonsQty = parseInt(input.buttonsQty, 10);
    if (buttonsQty > 0) {
      await deductInventory(trx, { patientId, visitId, label: "Buttons", qty: buttonsQty, date: input.date, userId: session!.userId });
    }
    const coilMm = parseInt(input.compressedCoilMm, 10);
    if (coilMm > 0) {
      await deductInventory(trx, { patientId, visitId, label: "Compressed coil (mm)", qty: coilMm, date: input.date, userId: session!.userId });
    }

    // دفعة 27 (P2.4): مزامنة المعالجة لحقل notes في الزيارة المقابلة بالملف
    // الطبي العادي. لو اتغيّر التاريخ وقت Edit، بنمسح المزامنة من تاريخ الزيارة
    // القديم الأول (لو كانت هي مصدرها) قبل ما نزامن على التاريخ الجديد.
    if (isEdit && visitRow!.visit_date !== input.date) {
      await clearSyncedOrthoNote(trx, { patientId, visitDate: visitRow!.visit_date });
    }
    const paragraph = buildOrthoTreatmentParagraph({
      service,
      upperWireSize: input.upperWireSize || null,
      upperWireType: input.upperWireType || null,
      lowerWireSize: input.lowerWireSize || null,
      lowerWireType: input.lowerWireType || null,
      note: input.note || null,
    });
    await syncOrthoNoteToMedicalVisit(trx, {
      patientId,
      visitDate: input.date,
      paragraph,
      performingDoctorId: selectedDoctorId,
    });

    return visitId;
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  revalidatePath(`/patients/${patientId}`);
  revalidatePath("/inventory");
  return { ok: true, visitId: result };
}

export async function undoOrthoInventoryDeductionAction(params: { patientId: number; deductionId: number }): Promise<ActionResult> {
  const session = await getSession();
  if (!session) return { ok: false, reason: "غير مسموح" };
  const canUndo = await hasPermission(session.userId, session.role as Role, "undo_ortho_inventory_deduction");
  if (!canUndo) return { ok: false, reason: "محتاج صلاحية Undo المخزون" };

  const { patientId, deductionId } = params;
  const row = await db
    .selectFrom("ortho_inventory_deductions")
    .selectAll()
    .where("id", "=", deductionId)
    .where("patient_id", "=", patientId)
    .executeTakeFirst();
  if (!row) return { ok: false, reason: "الخصم ده مش موجود" };
  if (row.undone_at) return { ok: false, reason: "اتعمله Undo بالفعل" };

  await db.transaction().execute(async (trx) => {
    await trx
      .updateTable("ortho_inventory_deductions")
      .set({ undone_by: session.userId, undone_at: new Date().toISOString() })
      .where("id", "=", deductionId)
      .execute();
    if (row.item_id) {
      await trx.updateTable("inventory_items").set({ quantity: (eb) => eb("quantity", "+", row.qty) }).where("id", "=", row.item_id).execute();
    }
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  revalidatePath("/inventory");
  return { ok: true };
}
