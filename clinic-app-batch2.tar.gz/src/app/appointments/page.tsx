import Link from "next/link";
import { db } from "@/lib/db/client";
import AppointmentForm from "@/components/AppointmentForm";
import StatusSelect from "@/components/StatusSelect";
import { getAllSettings, buildTimeSlots, weekdayOf } from "@/lib/settings";

export default async function AppointmentsPage({
  searchParams,
}: {
  searchParams: Promise<{ date?: string }>;
}) {
  const { date } = await searchParams;
  const day = date && /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : new Date().toISOString().slice(0, 10);
  const weekday = weekdayOf(day);

  const [rooms, doctors, patients, shifts, appointments, settings] = await Promise.all([
    db.selectFrom("rooms").selectAll().execute(),
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).execute(),
    db.selectFrom("patients").select(["id", "full_name", "file_number"]).orderBy("id", "desc").limit(200).execute(),
    db
      .selectFrom("doctor_weekly_shifts")
      .leftJoin("rooms", "rooms.id", "doctor_weekly_shifts.room_id")
      .leftJoin("doctors", "doctors.id", "doctor_weekly_shifts.doctor_id")
      .select([
        "doctor_weekly_shifts.id",
        "doctor_weekly_shifts.start_time",
        "doctor_weekly_shifts.end_time",
        "rooms.name as room_name",
        "doctors.full_name as doctor_name",
      ])
      .where("weekday", "=", weekday)
      .orderBy("doctor_weekly_shifts.start_time")
      .execute(),
    db
      .selectFrom("appointments")
      .leftJoin("patients", "patients.id", "appointments.patient_id")
      .leftJoin("rooms", "rooms.id", "appointments.room_id")
      .leftJoin("doctors", "doctors.id", "appointments.doctor_id")
      .select([
        "appointments.id",
        "appointments.patient_id",
        "appointments.start_time",
        "appointments.status",
        "appointments.notes",
        "patients.full_name as patient_name",
        "rooms.name as room_name",
        "doctors.full_name as doctor_name",
      ])
      .where("appointment_date", "=", day)
      .orderBy("appointments.start_time")
      .execute(),
    getAllSettings(),
  ]);

  const timeSlots = buildTimeSlots(settings.day_start, settings.day_end, Number(settings.slot_minutes));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h1 className="text-xl font-bold">المواعيد والشيفتات</h1>
        <form className="flex items-center gap-2">
          <label className="text-sm text-muted">اليوم:</label>
          <input
            type="date"
            name="date"
            defaultValue={day}
            className="rounded-md border border-border bg-surface px-2 py-1.5 text-sm"
          />
          <button type="submit" className="px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft">
            عرض
          </button>
        </form>
      </div>

      {/* Shifts (read-only — تتحدد من صفحة الإعدادات حسب الشيفت الأسبوعي المتكرر) */}
      <section className="bg-surface border border-border rounded-xl p-5 space-y-3">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <h2 className="font-semibold">شيفتات {day}</h2>
          <Link href="/settings" className="text-xs px-2 py-1 rounded-md border border-border hover:bg-primary-soft">
            تعديل الشيفتات من الإعدادات
          </Link>
        </div>
        <div className="flex flex-wrap gap-2">
          {shifts.map((s) => (
            <span key={s.id} className="text-xs bg-primary-soft text-primary-dark rounded-full px-3 py-1.5">
              {s.room_name} · {s.doctor_name} · {s.start_time}–{s.end_time}
            </span>
          ))}
          {shifts.length === 0 && <p className="text-sm text-muted">مفيش شيفتات مسجلة لليوم ده.</p>}
        </div>
      </section>

      {/* Appointments */}
      <section className="bg-surface border border-border rounded-xl p-5 space-y-4">
        <h2 className="font-semibold">مواعيد {day}</h2>
        <AppointmentForm date={day} rooms={rooms} patients={patients} doctors={doctors} timeSlots={timeSlots} />

        <div className="overflow-x-auto">
          <table className="w-full text-sm mt-2">
            <thead className="bg-primary-soft text-primary-dark">
              <tr>
                <th className="text-right px-3 py-2 font-medium">الوقت</th>
                <th className="text-right px-3 py-2 font-medium">المريض</th>
                <th className="text-right px-3 py-2 font-medium">الغرفة</th>
                <th className="text-right px-3 py-2 font-medium">الدكتور</th>
                <th className="text-right px-3 py-2 font-medium">الحالة</th>
              </tr>
            </thead>
            <tbody>
              {appointments.map((a) => (
                <tr key={a.id} className="border-t border-border">
                  <td className="px-3 py-2 whitespace-nowrap">{a.start_time}</td>
                  <td className="px-3 py-2">
                    <Link
                      href={`/patients/${a.patient_id}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-medium hover:text-primary hover:underline"
                    >
                      {a.patient_name}
                    </Link>
                  </td>
                  <td className="px-3 py-2">{a.room_name}</td>
                  <td className="px-3 py-2">{a.doctor_name}</td>
                  <td className="px-3 py-2">
                    <StatusSelect id={a.id} status={a.status} />
                  </td>
                </tr>
              ))}
              {appointments.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-3 py-6 text-center text-muted">
                    لا يوجد مواعيد مسجلة لليوم ده.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
