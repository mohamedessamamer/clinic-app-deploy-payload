import type { Role } from "./auth";

// ثوابت الصلاحيات فقط — من غير أي استيراد لطبقة قاعدة البيانات، عشان يصلح
// للاستخدام في مكونات العميل (client components) زي PermissionsManager كمان.
// الدوال اللي بتلمس قاعدة البيانات (getPermissionOverrides..) موجودة في lib/permissions.ts.
export const PERMISSION_DEFS = [
  { key: "reports_full", label: "عرض كل التقارير (كل الأطباء وكل الفترات)" },
  { key: "reports_own", label: "عرض تقريره الشخصي بس (للدكتور)" },
  { key: "collect_payments", label: "تحصيل المدفوعات من الاستقبال" },
  { key: "manage_inventory", label: "إدارة المخزون" },
  { key: "manage_expenses", label: "إدارة المصروفات والمرتبات" },
  { key: "manage_settings", label: "الوصول لصفحة الإعدادات" },
] as const;

export type PermissionKey = (typeof PERMISSION_DEFS)[number]["key"];

export const ROLE_DEFAULT_PERMISSIONS: Record<Role, PermissionKey[]> = {
  admin: ["reports_full", "collect_payments", "manage_inventory", "manage_expenses", "manage_settings"],
  clinic_manager: ["reports_full", "manage_inventory"],
  accountant: ["reports_full", "collect_payments", "manage_expenses"],
  reception: ["collect_payments"],
  doctor: ["reports_own"],
};
