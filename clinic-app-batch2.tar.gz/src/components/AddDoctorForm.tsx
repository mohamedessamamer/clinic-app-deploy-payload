"use client";

import { useActionState, useRef } from "react";
import { addDoctorAction } from "@/app/settings/actions";

const initialState: { username?: string; password?: string; error?: string } = {};

export default function AddDoctorForm() {
  const [state, formAction, isPending] = useActionState(addDoctorAction, initialState);
  const formRef = useRef<HTMLFormElement>(null);

  return (
    <div className="space-y-3">
      {state.username && state.password && (
        <div className="rounded-md bg-green-50 border border-green-200 px-3 py-3 text-sm space-y-1">
          <p className="font-medium text-green-800">تم إنشاء حساب الدكتور. سجّل البيانات دي دلوقتي — مش هتتعرض تاني:</p>
          <p>
            اسم المستخدم: <span className="font-mono font-semibold">{state.username}</span>
          </p>
          <p>
            كلمة السر: <span className="font-mono font-semibold">{state.password}</span>
          </p>
        </div>
      )}
      {state.error && (
        <p className="text-sm text-red-700 bg-red-50 border border-red-200 rounded-md px-3 py-2">
          حصل خطأ، حاول تاني.
        </p>
      )}
      <form
        ref={formRef}
        action={(formData) => {
          formAction(formData);
          formRef.current?.reset();
        }}
        className="flex items-end gap-2 flex-wrap"
      >
        <div className="flex-1 min-w-[200px]">
          <label className="block text-xs text-muted mb-1">اسم الدكتور بالكامل</label>
          <input
            name="full_name"
            required
            className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
          />
        </div>
        <button
          type="submit"
          disabled={isPending}
          className="rounded-md bg-primary text-white px-4 py-2 text-sm font-medium hover:bg-primary-dark transition-colors disabled:opacity-60"
        >
          {isPending ? "جارٍ الإنشاء..." : "+ إضافة دكتور"}
        </button>
      </form>
    </div>
  );
}
