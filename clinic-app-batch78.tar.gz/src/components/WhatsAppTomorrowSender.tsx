"use client";

import { useState, useTransition } from "react";
import { prepareTomorrowManualConfirmationsAction, sendTomorrowConfirmationsAction } from "@/app/appointment-reminders/report-actions";

type ManualRow = { appointmentId: number; patientName: string; time: string; whatsappUrl: string };
export default function WhatsAppTomorrowSender() {
  const [busy, startTransition] = useTransition();
  const [rows, setRows] = useState<ManualRow[]>([]);
  const [opened, setOpened] = useState<number[]>([]);
  return <section className="rounded-xl border border-border bg-background p-4 space-y-3" dir="rtl">
    <div><h2 className="font-semibold">تأكيدات مرضى غدًا</h2><p className="mt-1 text-xs text-muted">الإرسال الرسمي يرسل للجميع بضغطة واحدة. الإرسال اليدوي يجهز الرسائل بالتتابع في واتساب.</p></div>
    <div className="flex flex-wrap gap-2">
      <button disabled={busy} onClick={() => startTransition(async () => { const result = await sendTomorrowConfirmationsAction(); if (!result.ok) return alert(result.error); alert(`تم إرسال ${result.sent} رسالة. تم تخطي ${result.skipped} موعد مؤكد أو مُرسل سابقًا. فشل ${result.failed}.`); window.location.reload(); })} className="btn-3d-primary rounded-md px-4 py-2 text-sm">إرسال رسائل التأكيد لمرضى غدًا</button>
      <button disabled={busy} onClick={() => startTransition(async () => { const result = await prepareTomorrowManualConfirmationsAction(); if (!result.ok) return alert(result.error); setRows(result.rows); setOpened([]); if (!result.rows.length) alert("لا توجد مواعيد تحتاج إرسالًا يدويًا غدًا."); })} className="rounded-md border border-primary px-4 py-2 text-sm text-primary">تجهيز الإرسال اليدوي</button>
    </div>
    {rows.length > 0 && <div className="space-y-2 border-t border-border pt-3"><p className="text-xs text-muted">افتح كل رسالة واضغط إرسال داخل واتساب. علامة «تم الفتح» تساعدك على متابعة الباقي.</p>{rows.map((row) => <div key={row.appointmentId} className="flex items-center justify-between gap-3 rounded-lg border border-border p-2 text-sm"><span>{row.time} — {row.patientName}</span><button onClick={() => { window.open(row.whatsappUrl, "_blank", "noopener,noreferrer"); setOpened((current) => current.includes(row.appointmentId) ? current : [...current, row.appointmentId]); }} className={`rounded-md px-3 py-1.5 ${opened.includes(row.appointmentId) ? "bg-emerald-100 text-emerald-800" : "bg-primary-soft text-primary"}`}>{opened.includes(row.appointmentId) ? "تم الفتح" : "فتح واتساب"}</button></div>)}</div>}
  </section>;
}
