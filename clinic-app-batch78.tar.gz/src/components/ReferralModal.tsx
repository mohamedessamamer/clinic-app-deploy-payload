"use client";

import { useState, useTransition } from "react";
import { createReferralAction } from "@/app/referrals/actions";

export default function ReferralModal({ appointmentId, patientName, doctors, currentDoctorId, onClose }: {
  appointmentId: number;
  patientName: string;
  doctors: { id: number; full_name: string }[];
  currentDoctorId: number;
  onClose: () => void;
}) {
  const [doctorId, setDoctorId] = useState("");
  const [requestText, setRequestText] = useState("");
  const [busy, startTransition] = useTransition();
  const choices = doctors.filter((doctor) => doctor.id !== currentDoctorId);
  return <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40 p-4" onClick={onClose} dir="rtl">
    <form className="card-3d w-full max-w-md space-y-4 rounded-xl p-5" onClick={(event) => event.stopPropagation()} onSubmit={(event) => {
      event.preventDefault();
      startTransition(async () => {
        const result = await createReferralAction({ appointmentId, toDoctorId: Number(doctorId), requestText });
        if (!result.ok) return window.alert(result.error || "تعذر إرسال التحويل.");
        window.alert("تم إرسال التحويل للطبيب وإضافته للملف الطبي.");
        onClose();
      });
    }}>
      <div><h3 className="font-semibold">تحويل المريض (Refer)</h3><p className="mt-1 text-sm text-muted">{patientName}</p></div>
      <label className="block text-sm">الطبيب المحوّل إليه
        <select required value={doctorId} onChange={(e) => setDoctorId(e.target.value)} className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2">
          <option value="">اختر الطبيب</option>{choices.map((doctor) => <option key={doctor.id} value={doctor.id}>{doctor.full_name}</option>)}
        </select>
      </label>
      <label className="block text-sm">المطلوب
        <textarea required maxLength={1000} rows={4} value={requestText} onChange={(e) => setRequestText(e.target.value)} className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2" placeholder="اكتب المطلوب من الطبيب الآخر…" />
      </label>
      <p className="text-xs text-muted">التحويل لا يضيف المريض لقائمة الانتظار؛ الاستقبال ينظم دخوله أو يحجز له موعدًا.</p>
      <div className="flex justify-end gap-2"><button type="button" onClick={onClose} className="rounded-md border border-border px-4 py-2">إلغاء</button><button disabled={busy} className="btn-3d-primary rounded-md px-4 py-2">{busy ? "جارٍ الإرسال…" : "إرسال التحويل"}</button></div>
    </form>
  </div>;
}
