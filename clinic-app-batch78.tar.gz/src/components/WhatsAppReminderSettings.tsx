"use client";

import { useState, useTransition } from "react";
import { createAppointmentTemplatesAction, saveReminderSettingsAction } from "@/app/appointment-reminders/report-actions";
export default function WhatsAppReminderSettings({ initialTime }: { initialTime: string }) {
  const [time, setTime] = useState(initialTime); const [busy, startTransition] = useTransition();
  return <div className="flex flex-wrap items-end gap-3" dir="rtl"><label className="text-sm">وقت إرسال تذكير اليوم السابق<input type="time" value={time} onChange={(e) => setTime(e.target.value)} className="mt-1 block rounded-md border border-border bg-background px-3 py-2" /></label><button disabled={busy} onClick={() => startTransition(async () => { const result = await saveReminderSettingsAction(time); alert(result.ok ? "تم حفظ الوقت." : result.error); })} className="btn-3d-primary rounded-md px-4 py-2">حفظ</button><button disabled={busy} onClick={() => startTransition(async () => { const result = await createAppointmentTemplatesAction(); alert(result.ok ? "تم إرسال قالبَي التذكير والتأكيد إلى Meta للمراجعة." : result.error); })} className="rounded-md border border-primary px-4 py-2 text-primary">إنشاء قوالب المواعيد</button><p className="text-xs text-muted">صلاحية رابط المريض 3 ساعات. التقرير يظل متاحًا ويتحدث تلقائيًا. يجب أن توافق Meta على القالبين قبل الإرسال التلقائي.</p></div>;
}
