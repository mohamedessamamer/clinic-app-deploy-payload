"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { ROLE_LABELS, type SessionPayload } from "@/lib/auth";
import LogoutButton from "./LogoutButton";
import AccountMenu from "./AccountMenu";
import NotificationCenter from "./NotificationCenter";
import StaffChat from "./StaffChat";
import AttendanceQueue from "./AttendanceQueue";
import ThemeToggle from "./ThemeToggle";
import HeaderBackButton from "./HeaderBackButton";
import { HomeIcon, CalendarIcon, PatientsIcon, InvoiceIcon, ExpensesIcon, InventoryIcon, ReportsIcon, SettingsIcon } from "./icons";

type IconComponent = (props: { className?: string }) => React.JSX.Element;

// ترتيب ثابت مطلوب صراحة من المستخدم — أي لينك ظاهر لأي حساب (سواء بحكم الدور
// الثابت أو صلاحية قابلة للمنح زي reports_full/reports_own أو manage_inventory)
// لازم يفضل بنفس الترتيب ده دايمًا، مش بس للأدمن: الرئيسية، الاستقبال، المرضى،
// الفواتير، المخزن، التقارير. "الإعدادات" (أدمن بس) مش جزء من الترتيب اللي
// المستخدم حدده فمتسيبة آخر حاجة زي ما كانت. كل لينك له لون شارة مختلف (tone)
// عشان تسهيل التمييز البصري السريع بين الصفحات — نفس فكرة نموذج التصميم (ج)
// اللي المستخدم اختاره.
function buildOrderedLinks(
  session: SessionPayload,
  canViewReports: boolean,
  canViewInventory: boolean,
  canViewExpenses: boolean,
  canViewPatients: boolean,
  canManageWhatsapp: boolean
): { href: string; label: string; icon: IconComponent; tone?: string }[] {
  const candidates: { href: string; label: string; icon: IconComponent; tone?: string; visible: boolean }[] = [
    { href: "/", label: "الرئيسية", icon: HomeIcon, visible: true },
    // للاستقبال بس: مفيش داعي للينك منفصل هنا — "الرئيسية" أصلاً بتوجّههم لنفس
    // الصفحة دي تلقائيًا (شوف src/app/page.tsx)، فاللينك المنفصل كان مكرر بصريًا.
    { href: "/front-desk", label: "الاستقبال", icon: CalendarIcon, tone: "tone-blue", visible: session.role === "admin" },
    { href: "/patients", label: "المرضى", icon: PatientsIcon, tone: "tone-purple", visible: canViewPatients },
    { href: "/whatsapp", label: "واتساب", icon: InvoiceIcon, tone: "tone-teal", visible: canManageWhatsapp },
    {
      href: "/invoices",
      label: "الفواتير",
      icon: InvoiceIcon,
      tone: "tone-amber",
      // الطبيب يدخلها كتقرير يومه الشخصي فقط؛ صفحة الفواتير نفسها بتفرض فلترة
      // الطبيب والتاريخ على السيرفر، فلا يمكنه فتح فواتير زملائه أو أيام أخرى.
      visible: ["admin", "reception", "accountant", "doctor"].includes(session.role),
    },
    { href: "/expenses", label: "المصروفات", icon: ExpensesIcon, tone: "tone-amber", visible: canViewExpenses },
    { href: "/inventory", label: "المخزن", icon: InventoryIcon, tone: "tone-teal", visible: canViewInventory },
    { href: "/reports", label: "التقارير", icon: ReportsIcon, tone: "tone-red", visible: canViewReports },
    { href: "/settings", label: "الإعدادات", icon: SettingsIcon, visible: session.role === "admin" },
  ];
  return candidates.filter((c) => c.visible).map(({ href, label, icon, tone }) => ({ href, label, icon, tone }));
}

export default function NavBar({
  session,
  canViewReports = false,
  canViewInventory = false,
  canViewExpenses = false,
  canViewPatients = false,
  canManageWhatsapp = false,
  medicalUiLanguage = "en",
  initialNotifications = [],
  chatNotificationSound = "gentle_bell",
}: {
  session: SessionPayload;
  canViewReports?: boolean;
  canViewInventory?: boolean;
  canViewExpenses?: boolean;
  canViewPatients?: boolean;
  canManageWhatsapp?: boolean;
  medicalUiLanguage?: "en" | "ar";
  initialNotifications?: { id: number; type: string; title: string; body: string; patient_id: number | null; notification_case_id: number | null; read_at: string | null; created_at: string }[];
  chatNotificationSound?: string;
}) {
  const pathname = usePathname();
  const [mobileAccountOpen, setMobileAccountOpen] = useState(false);
  const visibleLinks = buildOrderedLinks(session, canViewReports, canViewInventory, canViewExpenses, canViewPatients, canManageWhatsapp);
  return <>
    <header className="clinic-reception-nav">
      <Link href="/" className="clinic-reception-brand" aria-label="عيادتي">
        <Image src="/clinic-smile-logo.png" alt="" width={72} height={64} priority className="clinic-reception-logo-image" />
      </Link>
      <nav className="clinic-reception-links" aria-label="التنقل الرئيسي">
        {visibleLinks.map((l) => {
          const Icon = l.icon;
          const active = l.href === "/" ? pathname === "/" : pathname.startsWith(l.href);
          return <Link key={l.href} href={l.href} data-active={active} className="clinic-reception-link"><Icon /><span>{l.label}</span></Link>;
        })}
      </nav>
      <div className="clinic-reception-account">
        <div className="clinic-reception-account-actions">
          <NotificationCenter initialNotifications={initialNotifications} canResolveFollowups={["reception", "admin", "clinic_manager"].includes(session.role)} />
          <AccountMenu fullName={session.fullName} roleLabel={ROLE_LABELS[session.role]} medicalUiLanguage={medicalUiLanguage} />
          <LogoutButton />
          <HeaderBackButton />
          <ThemeToggle />
        </div>
        <button type="button" className="clinic-mobile-account-trigger" onClick={() => setMobileAccountOpen((open) => !open)} aria-expanded={mobileAccountOpen} aria-label="Open account menu">
          ☰
        </button>
        {mobileAccountOpen && (
          <div className="clinic-mobile-account-popover">
            <div className="clinic-mobile-account-title">{session.fullName}</div>
            <NotificationCenter initialNotifications={initialNotifications} canResolveFollowups={["reception", "admin", "clinic_manager"].includes(session.role)} />
            <AccountMenu fullName={session.fullName} roleLabel={ROLE_LABELS[session.role]} medicalUiLanguage={medicalUiLanguage} />
            <LogoutButton />
            <HeaderBackButton />
            <ThemeToggle />
          </div>
        )}
      </div>
    </header>
    <AttendanceQueue />
    <StaffChat currentUserId={session.userId} role={session.role} notificationSound={chatNotificationSound} />
  </>;
}
