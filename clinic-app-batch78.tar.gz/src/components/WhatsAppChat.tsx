"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { listMessagesAction, sendMessageAction } from "@/app/whatsapp/actions";

type Conversation = { id: number; waId: string; profileName: string | null; lastMessageAt: string | null };
type Message = { id: number; direction: "inbound" | "outbound"; body: string | null; status: string; isEcho: boolean; createdAt: string };

export default function WhatsAppChat({ conversations }: { conversations: Conversation[] }) {
  const [activeId, setActiveId] = useState<number | null>(conversations[0]?.id ?? null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [draft, setDraft] = useState("");
  const [loadError, setLoadError] = useState<string | null>(null);
  const [sendError, setSendError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();
  const activeIdRef = useRef(activeId);
  const latestRequestRef = useRef(0);

  useEffect(() => {
    activeIdRef.current = activeId;
  }, [activeId]);

  useEffect(() => {
    setActiveId((current) =>
      current !== null && conversations.some((conversation) => conversation.id === current)
        ? current
        : (conversations[0]?.id ?? null),
    );
  }, [conversations]);

  useEffect(() => {
    if (activeId === null) {
      setMessages([]);
      return;
    }

    let cancelled = false;
    let timer: ReturnType<typeof setTimeout> | undefined;
    setMessages([]);
    setLoadError(null);

    async function load() {
      const requestId = ++latestRequestRef.current;

      try {
        const rows = await listMessagesAction(activeId as number);
        if (!cancelled && requestId === latestRequestRef.current) {
          setMessages(rows);
          setLoadError(null);
        }
      } catch {
        if (!cancelled) setLoadError("تعذر تحميل الرسائل. هنحاول تاني تلقائيًا.");
      } finally {
        if (!cancelled) timer = setTimeout(load, 5000);
      }
    }

    void load();
    return () => {
      cancelled = true;
      latestRequestRef.current += 1;
      if (timer) clearTimeout(timer);
    };
  }, [activeId]);

  function handleSend() {
    const body = draft.trim();
    if (activeId === null || !body || isPending) return;

    const conversationId = activeId;
    setSendError(null);
    setDraft("");

    const formData = new FormData();
    formData.set("contact_id", String(conversationId));
    formData.set("body", body);

    startTransition(async () => {
      try {
        const result = await sendMessageAction(formData);
        if (!result.ok) {
          if (activeIdRef.current === conversationId) {
            setSendError(result.error ?? "فشل الإرسال");
            setDraft((current) => current || body);
          }
          return;
        }

        const requestId = ++latestRequestRef.current;
        const rows = await listMessagesAction(conversationId);
        if (activeIdRef.current === conversationId && requestId === latestRequestRef.current) {
          setMessages(rows);
        }
      } catch {
        if (activeIdRef.current === conversationId) {
          setSendError("حصل خطأ أثناء الإرسال. حاول مرة تانية.");
          setDraft((current) => current || body);
        }
      }
    });
  }

  if (conversations.length === 0) {
    return <p className="text-sm text-muted">لسه مفيش أي محادثة واردة. ابعت رسالة من رقم شخصي للرقم المتصل عشان تظهر هنا.</p>;
  }

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
      <div className="space-y-1 md:col-span-1">
        {conversations.map((c) => (
          <button
            key={c.id}
            type="button"
            aria-pressed={activeId === c.id}
            onClick={() => {
              setSendError(null);
              setActiveId(c.id);
            }}
            className={`w-full rounded-lg p-2 text-right text-sm ${activeId === c.id ? "bg-emerald-100 font-medium" : "hover:bg-slate-50"}`}
          >
            <div>{c.profileName || c.waId}</div>
            <div className="text-xs text-muted">+{c.waId}</div>
          </button>
        ))}
      </div>

      <div className="flex flex-col gap-3 md:col-span-2">
        <div className="max-h-96 min-h-[200px] space-y-2 overflow-y-auto rounded-lg border border-slate-200 p-3">
          {messages.map((m) => (
            <div key={m.id} className={`flex ${m.direction === "outbound" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${
                  m.direction === "outbound" ? "bg-emerald-600 text-white" : "bg-slate-100 text-slate-900"
                }`}
              >
                <div>{m.body}</div>
                <div className="mt-1 text-[10px] opacity-70">
                  {new Date(m.createdAt).toLocaleString("ar-EG")}
                  {m.direction === "outbound" ? ` — ${m.status}` : m.isEcho ? " — من تطبيق واتساب بزنس" : ""}
                </div>
              </div>
            </div>
          ))}
          {messages.length === 0 && <p className="text-sm text-muted">مفيش رسائل لسه في المحادثة دي.</p>}
        </div>

        <div className="flex gap-2">
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.nativeEvent.isComposing) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="اكتب رسالة..."
            aria-label="نص الرسالة"
            className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm"
          />
          <button
            type="button"
            disabled={isPending || !draft.trim()}
            onClick={handleSend}
            className="btn-primary rounded-lg px-4 py-2 text-sm"
          >
            {isPending ? "جاري الإرسال..." : "إرسال"}
          </button>
        </div>
        {loadError && (
          <p role="status" className="text-sm text-amber-700">
            {loadError}
          </p>
        )}
        {sendError && (
          <p role="alert" className="text-sm text-red-700">
            {sendError}
          </p>
        )}
      </div>
    </div>
  );
}
