"use client";

import { useState } from "react";

const labels = { gentle_bell: "جرس هادئ", soft_chime: "نغمة قصيرة", water_drop: "قطرة خفيفة", off: "بدون صوت" } as const;

export default function ChatSoundPicker({ initialValue }: { initialValue: string }) {
  const [value, setValue] = useState(initialValue in labels ? initialValue : "gentle_bell");
  function preview() {
    if (value === "off") return;
    const context = new AudioContext();
    const notes = value === "soft_chime" ? [[660, 0, .13], [880, .11, .18]] : value === "water_drop" ? [[920, 0, .09], [520, .07, .2]] : [[740, 0, .2], [990, .16, .28]];
    for (const [frequency, delay, duration] of notes) {
      const oscillator = context.createOscillator(); const gain = context.createGain(); const start = context.currentTime + delay;
      oscillator.type = value === "water_drop" ? "sine" : "triangle";
      oscillator.frequency.setValueAtTime(frequency, start); gain.gain.setValueAtTime(.09, start); gain.gain.exponentialRampToValueAtTime(.001, start + duration);
      oscillator.connect(gain).connect(context.destination); oscillator.start(start); oscillator.stop(start + duration);
    }
    window.setTimeout(() => context.close().catch(() => undefined), 800);
  }
  return <div className="flex gap-2"><select name="chat_notification_sound" value={value} onChange={(event) => setValue(event.target.value)} className="min-w-0 flex-1 rounded-md border border-border bg-background px-3 py-2 text-sm">{Object.entries(labels).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select><button type="button" disabled={value === "off"} onClick={preview} className="rounded-md border border-primary px-3 py-2 text-sm text-primary">تجربة الصوت</button></div>;
}
