"use client";

import { useEffect, useState, useTransition } from "react";
import { approveAppointmentRescheduleAction, listAppointmentReminderReportAction } from "@/app/appointment-reminders/report-actions";

type Row = Awaited<ReturnType<typeof listAppointmentReminderReportAction>>[number];
const labels: Record<Row["response_status"], string> = { pending: "لم يرد", confirmed: "أكد الموعد", reschedule_pending: "عدّل — ينتظر الاعتماد", reschedule_approved: "تم اعتماد التعديل", send_failed: "فشل الإرسال" };
export default function WhatsAppAppointmentReport({ initialRows }: { initialRows: Row[] }) {
  const [rows, setRows] = useState(initialRows);
  const [busy, startTransition] = useTransition();
  useEffect(() => { const timer = setInterval(() => listAppointmentReminderReportAction().then(setRows).catch(() => undefined), 10_000); return () => clearInterval(timer); }, []);
  return <div className="overflow-x-auto" dir="rtl"><table className="w-full text-sm"><thead><tr className="border-b text-right"><th className="p-2">المريض</th><th className="p-2">الطبيب</th><th className="p-2">الموعد</th><th className="p-2">الرد</th><th className="p-2">التعديل</th><th className="p-2"></th></tr></thead><tbody>
    {rows.map((row) => <tr key={row.id} className="border-b border-border"><td className="p-2 font-medium">{row.patient_name}</td><td className="p-2">{row.doctor_name}</td><td className="p-2 whitespace-nowrap">{row.appointment_date} · {row.start_time.slice(0, 5)}</td><td className="p-2">{labels[row.response_status]}</td><td className="p-2 whitespace-nowrap">{row.requested_date ? `${row.requested_date} · ${row.requested_time?.slice(0, 5)}` : "—"}</td><td className="p-2">{row.response_status === "reschedule_pending" && <button disabled={busy} onClick={() => startTransition(async () => { const result = await approveAppointmentRescheduleAction(row.id); if (!result.ok) return alert(result.error); if (result.warning) alert(result.warning); setRows(await listAppointmentReminderReportAction()); })} className="rounded-md bg-emerald-700 px-3 py-1.5 text-white">اعتماد</button>}{row.response_status === "send_failed" && <span className="text-xs text-red-700" title={row.error_message ?? ""}>راجع الإرسال</span>}</td></tr>)}
    {!rows.length && <tr><td colSpan={6} className="p-8 text-center text-muted">لا توجد رسائل تذكير حتى الآن.</td></tr>}
  </tbody></table></div>;
}
