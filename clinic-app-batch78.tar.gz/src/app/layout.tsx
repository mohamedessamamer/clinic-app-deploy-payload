import type { Metadata } from "next";
import "./globals.css";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import NavBar from "@/components/NavBar";
import WhatsAppOAuthRelay from "@/components/WhatsAppOAuthRelay";
import { db } from "@/lib/db/client";
import { getNotificationCenter } from "@/lib/notifications";
import { getSetting } from "@/lib/settings";

export const metadata: Metadata = {
  title: "نظام إدارة العيادة",
  description: "نظام إدارة عيادة بسيط وسريع",
};

export default async function RootLayout({ children }: LayoutProps<"/">) {
  const session = await getSession();
  // ظهور لينك "التقارير" مبني على صلاحية فعلية (reports_full/reports_own) مش
  // على الدور الثابت زي باقي اللينكات — عشان الصلاحيتين دول قابلين للمنح/السحب
  // لأي مستخدم لوحده من الإعدادات، مش مرتبطين بدور واحد بس.
  const canViewReports = session
    ? (await hasPermission(session.userId, session.role, "reports_full")) ||
      (await hasPermission(session.userId, session.role, "reports_own"))
    : false;
  // نفس الفكرة للينك "المخزن" — مبني على صلاحية manage_inventory القابلة للمنح،
  // مش على دور ثابت (كان قبل كده hardcoded لأدمن/استقبال بس، من غير أي تحقق
  // حقيقي في الصفحة نفسها).
  const canViewInventory = session ? await hasPermission(session.userId, session.role, "manage_inventory") : false;
  const canViewExpenses = session ? await hasPermission(session.userId, session.role, "manage_expenses") : false;
  const canManageWhatsapp = session ? (await hasPermission(session.userId, session.role, "manage_whatsapp")) || (await hasPermission(session.userId, session.role, "view_whatsapp_reminder_report")) : false;
  // رابط المرضى يظل متاحًا للأدوار الإدارية والاستقبال كالمعتاد، لكنه مخفي عن
  // الطبيب افتراضيًا ولا يظهر له إلا بمنح فردي من شاشة الصلاحيات.
  const canViewPatients = session
    ? session.role !== "doctor" || (await hasPermission(session.userId, session.role, "view_patients_list"))
    : false;
  const [medicalLanguageValue, initialNotifications, chatNotificationSound] = session
    ? await Promise.all([
        db.selectFrom("users").select("medical_ui_language").where("id", "=", session.userId).executeTakeFirst().then((row) => row?.medical_ui_language ?? "en"),
        getNotificationCenter(session.userId),
        getSetting("chat_notification_sound"),
      ])
    : ["en", [] as Awaited<ReturnType<typeof getNotificationCenter>>, "gentle_bell"];
  const medicalUiLanguage: "en" | "ar" = medicalLanguageValue === "ar" ? "ar" : "en";

  return (
    <html lang="ar" dir="rtl" className="h-full antialiased">
      <body className="min-h-full font-sans">
        <WhatsAppOAuthRelay />
        {session && <NavBar session={session} canViewReports={canViewReports} canViewInventory={canViewInventory} canViewExpenses={canViewExpenses} canViewPatients={canViewPatients} canManageWhatsapp={canManageWhatsapp} medicalUiLanguage={medicalUiLanguage} initialNotifications={initialNotifications} chatNotificationSound={chatNotificationSound} />}
        <main className="app-shell-main">{children}</main>
      </body>
    </html>
  );
}
