import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db/client";
import AddVisitForm from "@/components/AddVisitForm";
import AddImageGroupForm from "@/components/AddImageGroupForm";
import PatientImageGallery from "@/components/PatientImageGallery";
import VisitsTable from "@/components/VisitsTable";
import DeletePatientButton from "@/components/DeletePatientButton";
import EditPatientForm from "@/components/EditPatientForm";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { displayAge } from "@/lib/age";
import { getTodayPurposeContext } from "@/lib/purpose-context";
import { getClinicToday } from "@/lib/clinic-date";
import { missingPatientDetails, PATIENT_MISSING_FIELD_LABELS, PATIENT_MISSING_FIELD_LABELS_EN } from "@/lib/patient-details";
import { formatPatientPhone } from "@/lib/phone";
import MedicalTimeline from "@/components/MedicalTimeline";
import PatientRecordTabs from "@/components/PatientRecordTabs";
import PatientReferrals from "@/components/PatientReferrals";

// عدد شهور "محتاج صور جديدة" — لو المريض بيعمل متابعة ومفيش صور/أشعة اتسجلت له
// من أكتر من كذا شهر، بيظهر تنبيه في ملفه (شوف needsNewPhotos تحت). نفس
// الرقم مكرر (بمعيار مختلف لـ"بيعمل متابعة") في src/lib/photo-reminder.ts
// وفي src/app/patients/[id]/orthodontics/page.tsx — لازم يتغيروا مع بعض.
const PHOTO_REMINDER_MONTHS = 6;

export default async function PatientDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const patientId = Number(id);
  if (!patientId) notFound();

  const patient = await db.selectFrom("patients").selectAll().where("id", "=", patientId).executeTakeFirst();
  if (!patient) notFound();

  const session = await getSession();
  const medicalUiLanguage = session
    ? (await db.selectFrom("users").select("medical_ui_language").where("id", "=", session.userId).executeTakeFirst())?.medical_ui_language ?? "en"
    : "en";
  // واجهة الملف الطبي أصبحت English by design؛ ده لا يغير لغة الاستقبال أو
  // الحسابات، ولا بيانات الزيارة نفسها، فقط لغة أدوات الطبيب وسجل العلاج.
  const en = true;
  const medicalRecordLanguage = "en" as const;
  const canOverrideDoctor = session ? await hasPermission(session.userId, session.role, "override_visit_doctor") : false;
  const canEditOldVisits = session ? await hasPermission(session.userId, session.role, "edit_old_visits") : false;
  const canDeleteVisits = session ? await hasPermission(session.userId, session.role, "delete_visits") : false;
  // زرار "الملف المالي" — نفس مكانه دايمًا، بس بيظهر بس لمين عنده صلاحية
  // view_patient_billing فعليًا (افتراضيًا كل الأدوار ماعدا الدكتور).
  const canViewBilling = session ? await hasPermission(session.userId, session.role, "view_patient_billing") : false;
  // تعديل بيانات المريض الأساسية (دفعة 22) — الأدمن والاستقبال افتراضيًا.
  const canViewPersonalData = session ? await hasPermission(session.userId, session.role, "view_patient_personal_data") : false;
  const canEditPatientInfo = session
    ? canViewPersonalData && (await hasPermission(session.userId, session.role, "edit_patient_info"))
    : false;
  // تعديل حقل "الطبيب المساعد" بس (مستقل عن باقي سجل الزيارات) — دفعة 22،
  // افتراضيًا أدمن/مدير عيادة/استقبال، بالإضافة للطبيب الأساسي صاحب الزيارة نفسه
  // (بيتحقق منه لكل زيارة على حدة في VisitsTable/الأكشن، مش هنا).
  const canEditAssistantDoctor = session
    ? await hasPermission(session.userId, session.role, "edit_visit_assistant_doctor")
    : false;
  // الملف الطبي (سجل الزيارات) بقى مقصور على الدورين + الأدمن + مدير العيادة بس —
  // الاستقبال/المحاسب يقدروا يفتحوا الصفحة يشوفوا بس (عرض)، من غير إضافة أو تعديل.
  const canEditMedicalRecord = session?.role === "doctor" || session?.role === "admin" || session?.role === "clinic_manager";
  const today = getClinicToday();

  const [visits, doctors, services, todaysAppt, imageGroups, referrals] = await Promise.all([
    db
      .selectFrom("visits")
      .leftJoin("services", "services.id", "visits.service_id")
      // بيعرض "مقدم الخدمة الفعلي" هنا (مش الطبيب الأساسي اللي بيتحسب له التحصيل
      // المالي) — القيمتين متساويين افتراضيًا، وبيختلفوا بس لو حد عنده صلاحية
      // "اختيار مقدم خدمة مختلف" حدد حد تاني وقت تسجيل الزيارة.
      .leftJoin("doctors", "doctors.id", "visits.performing_doctor_id")
      .select([
        "visits.id",
        "visits.visit_date",
        "visits.service_id",
        "visits.notes",
        "visits.created_at",
        "visits.ortho_visit_id",
        "visits.primary_doctor_id",
        "visits.performing_doctor_id",
        "services.name as service_name",
        "services.name_en as service_name_en",
        "services.code as service_code",
        "doctors.full_name as doctor_name",
      ])
      .where("visits.patient_id", "=", patientId)
      .orderBy("visits.visit_date", "desc")
      .execute(),
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).execute(),
    db.selectFrom("services").select(["id", "name", "name_en", "code", "default_price"]).execute(),
    // موعد المريض المسجل من الاستقبال النهاردة (لو موجود) — بيستخدم عشان لما
    // الأدمن/مدير العيادة يضيف زيارة، "الطبيب المعالج" يتحدد أوتوماتيك منه بدل
    // اختيار حر (شوف AddVisitForm وaddVisitAction). لو مفيش حجز النهاردة، الفورم
    // بيرجع للاختيار اليدوي.
    db
      .selectFrom("appointments")
      .leftJoin("doctors", "doctors.id", "appointments.doctor_id")
      .select(["appointments.doctor_id", "doctors.full_name as doctor_name", "appointments.purpose_linked_invoice_id"])
      .where("appointments.patient_id", "=", patientId)
      .where("appointments.appointment_date", "=", today)
      .where("appointments.status", "!=", "cancelled")
      .orderBy("appointments.start_time")
      .executeTakeFirst(),
    db
      .selectFrom("patient_image_groups")
      .selectAll()
      .where("patient_id", "=", patientId)
      .orderBy("taken_at", "desc")
      .execute(),
    db.selectFrom("patient_referrals")
      .innerJoin("doctors as from_doctor", "from_doctor.id", "patient_referrals.from_doctor_id")
      .innerJoin("doctors as to_doctor", "to_doctor.id", "patient_referrals.to_doctor_id")
      .select(["patient_referrals.id", "patient_referrals.request_text", "patient_referrals.status", "patient_referrals.created_at", "patient_referrals.completed_at", "patient_referrals.to_doctor_id", "from_doctor.full_name as from_name", "to_doctor.full_name as to_name"])
      .where("patient_referrals.patient_id", "=", patientId)
      .orderBy("patient_referrals.status", "asc")
      .orderBy("patient_referrals.created_at", "desc")
      .execute(),
  ]);

  const imageGroupsWithFiles = await Promise.all(
    imageGroups.map(async (g) => ({
      ...g,
      images: await db.selectFrom("patient_images").selectAll().where("group_id", "=", g.id).execute(),
    }))
  );

  // تنبيه "محتاج صور جديدة": المريض بيعمل متابعة (خدمة كودها "0") من غير ما يكون
  // اتصورله حاجة جديدة من أكتر من PHOTO_REMINDER_MONTHS شهر (أو مالوش صور خالص).
  const hasFollowupVisit = visits.some((v) => v.service_code === "0");
  const lastPhotoTakenAt = imageGroups[0]?.taken_at ?? null; // imageGroups already ordered desc
  const reminderCutoff = new Date();
  reminderCutoff.setMonth(reminderCutoff.getMonth() - PHOTO_REMINDER_MONTHS);
  const reminderCutoffStr = reminderCutoff.toISOString().slice(0, 10);
  const needsNewPhotos = hasFollowupVisit && (!lastPhotoTakenAt || lastPhotoTakenAt < reminderCutoffStr);
  const missingDetails = missingPatientDetails(patient);

  // دفعة 27 (P3.2): سياق "متابعة: <اسم الخدمة>" — بس لمين يقدر يدخل معالجة أصلاً.
  const purposeContext = canEditMedicalRecord ? await getTodayPurposeContext(patientId, today) : null;

  return (
    <div className="medical-record-shell medical-page space-y-5" dir="ltr">
      <div className="medical-record-header medical-patient-card card-3d rounded-2xl p-4">
        <div className="patient-identity">
          <div className="patient-initial-avatar" aria-hidden="true">{patient.full_name.trim().slice(0, 1)}</div>
          <div className="space-y-1">
            <h1 className="text-xl font-bold">{patient.full_name}</h1>
            <div className="text-sm text-muted flex gap-4 flex-wrap items-center">
            {/* السن معلومة علاجية يحتاجها الطبيب داخل الملف الطبي نفسه؛ أما تاريخ
                الميلاد والهاتف والعنوان فيظلون ضمن البيانات الشخصية المحجوبة. */}
            {displayAge(patient) != null && <span>{en ? `Age: ${displayAge(patient)}` : `السن: ${displayAge(patient)}`}</span>}
            <span>File no. {patient.file_number}</span>
            {canEditPatientInfo && (
              <EditPatientForm
                patientId={patientId}
                fullName={patient.full_name}
                birthDate={patient.birth_date}
                phone={patient.phone}
                phoneCountryCode={patient.phone_country_code}
                address={patient.address}
                language={medicalRecordLanguage}
              />
            )}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          {/* شارت التقويم — منفصل عن سجل الزيارات (الملف الطبي العام) بقرار صريح
              من المستخدم، ظاهر لأي حد يقدر يفتح ملف المريض (عرض بس لو مالوش
              صلاحية تعديل الملف الطبي — شوف صفحة orthodontics نفسها). */}
          <Link
            href={`/patients/${patientId}/orthodontics`}
            className="px-3 py-2 rounded-md border border-border text-sm hover:bg-primary-soft whitespace-nowrap"
          >
            {en ? "Orthodontic chart" : "شارت التقويم"}
          </Link>
          {canViewBilling && (
            <Link
              href={`/patients/${patientId}/billing`}
              className="px-3 py-2 rounded-md border border-border text-sm hover:bg-primary-soft whitespace-nowrap"
            >
              {en ? "Financial record" : "الملف المالي"}
            </Link>
          )}
          {/* حذف حالة نهائيًا - للأدمن بس، أساسًا لتنظيف حالات تجربة (test) بعد الانتهاء منها. */}
          {session?.role === "admin" && (
            <DeletePatientButton patientId={patientId} patientName={patient.full_name} redirectTo="/patients" />
          )}
        </div>
      </div>

      {/* حجز الموعد القادم اتنقل من هنا لبوكس التحصيل في الجدول (يظهر للاستقبال
          بعد ما يختار الخدمة ويسجل الدفع وقت ما يحدد الموعد "تم") — اختياري هناك. */}
      {needsNewPhotos && (
        <div className="text-sm bg-amber-50 text-amber-800 border border-amber-300 rounded-md px-3 py-2">
          {en
            ? `This patient has follow-up visits but no new photos or X-rays from the last ${PHOTO_REMINDER_MONTHS} months${lastPhotoTakenAt ? ` (last image: ${lastPhotoTakenAt})` : " (no images recorded)"}. New images are recommended at the next visit.`
            : <>المريض ده بيعمل متابعة، ومفيش صور أو أشعة مسجلة له من أكتر من {PHOTO_REMINDER_MONTHS} شهور{lastPhotoTakenAt ? ` (آخر صورة بتاريخ ${lastPhotoTakenAt})` : " (مفيش صور اتسجلت له خالص)"} — يفضل تتاخد صور جديدة في زيارته الجاية.</>}
        </div>
      )}

      {canViewPersonalData && missingDetails.length > 0 && (
        <div className="text-sm bg-amber-50 text-amber-800 border border-amber-300 rounded-md px-3 py-2">
          {en ? "Patient details are incomplete: " : "بيانات المريض ناقصة: "}
          {(en ? PATIENT_MISSING_FIELD_LABELS_EN : PATIENT_MISSING_FIELD_LABELS)[missingDetails[0]]}
          {missingDetails.slice(1).map((field) => `، ${(en ? PATIENT_MISSING_FIELD_LABELS_EN : PATIENT_MISSING_FIELD_LABELS)[field]}`)}.
          {en ? " Please complete them before the next visit." : " يفضّل استكمالها قبل الزيارة القادمة."}
        </div>
      )}

      <div className="medical-layout">
        <main className="space-y-4 min-w-0">
          <PatientRecordTabs orthodonticHref={`/patients/${patientId}/orthodontics`} />
          <PatientReferrals referrals={referrals} currentDoctorId={session?.doctorId ?? null} />
          <section id="patient-summary" className="card-3d rounded-2xl p-4 space-y-3 scroll-mt-6">
            <h2 className="font-semibold text-lg">Medical visit history</h2>
            <MedicalTimeline visits={visits} />
          </section>
          <section id="medical-visits" className="card-3d rounded-2xl p-4 space-y-4 scroll-mt-6">
            <h2 className="font-semibold">Medical visits</h2>

        {/* الإضافة/التعديل في الملف الطبي مقصورة على الدورين + الأدمن + مدير العيادة
            — الاستقبال/المحاسب يشوفوا السجل بس من غير أي فورم إضافة. */}
        {purposeContext && (
          <div className="text-sm bg-primary-soft text-primary-dark rounded-md px-3 py-2">
            {en ? `Follow-up: ${purposeContext.serviceNameEn || purposeContext.serviceName} (context only; not part of the medical record).` : `متابعة: ${purposeContext.serviceName} (للسياق بس، مش جزء من الملف الطبي).`}
          </div>
        )}
        {/* التعديل مسموح خلال أول 3 أيام من تسجيل الزيارة (وبعد كده محتاج صلاحية
            "edit_old_visits")، لكن بس لمين معاه canEditMedicalRecord أصلاً — شوف
            VisitsTable.tsx وactions.ts. */}
        <VisitsTable
          patientId={patientId}
          visits={visits}
          services={services}
          doctors={doctors}
          canEditMedicalRecord={canEditMedicalRecord}
          canEditOldVisits={canEditOldVisits}
          canDeleteVisits={canDeleteVisits}
          canEditAssistantDoctor={canEditAssistantDoctor}
          currentDoctorId={session?.role === "doctor" ? session.doctorId ?? null : null}
          language={medicalRecordLanguage}
        />
          </section>
        </main>
        <aside className="space-y-4">
          <section className="medical-side-card space-y-3">
            <h2 className="font-semibold">Add treatment</h2>
            {canEditMedicalRecord ? <AddVisitForm patientId={patientId} services={services} doctors={doctors} currentDoctorId={session?.role === "doctor" ? session.doctorId ?? null : null} canOverrideDoctor={canOverrideDoctor} todaysApptDoctorId={session?.role !== "doctor" ? todaysAppt?.doctor_id ?? null : null} todaysApptDoctorName={session?.role !== "doctor" ? todaysAppt?.doctor_name ?? null : null} language={medicalRecordLanguage} /> : <p className="text-xs text-muted">This medical record is view-only for your account.</p>}
          </section>
          <section id="patient-photos" className="medical-side-card space-y-3 scroll-mt-6">
            <h2 className="font-semibold">Photos &amp; X-rays</h2>
            <PatientImageGallery groups={imageGroupsWithFiles} patientId={patientId} language={medicalRecordLanguage} />
            <AddImageGroupForm patientId={patientId} language={medicalRecordLanguage} />
          </section>
        </aside>
      </div>
    </div>
  );
}
