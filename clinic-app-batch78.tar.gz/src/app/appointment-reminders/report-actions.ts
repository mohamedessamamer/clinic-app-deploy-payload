"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getAllSettings, setSetting } from "@/lib/settings";
import { getActiveAccount, getAccountAccessToken } from "@/lib/whatsapp/store";
import { sendRescheduleConfirmationTemplate } from "@/lib/whatsapp/graph";
import { createAppointmentReminderTemplates } from "@/lib/whatsapp/graph";
import { sendAppointmentReminderTemplate } from "@/lib/whatsapp/graph";
import { hashAppointmentToken, issueAppointmentLink } from "@/lib/appointment-self-service";
import { getClinicToday } from "@/lib/clinic-date";

const sqlNow = () => new Date().toISOString().replace("T", " ").slice(0, 19);
const waNumber = (country: string, local: string) => `${country.replace(/\D/g, "")}${local.replace(/\D/g, "").replace(/^0+/, "")}`;
async function canView() { const session = await getSession(); return session && (await hasPermission(session.userId, session.role, "view_whatsapp_reminder_report")) ? session : null; }
const nextDay = (date: string) => { const [year, month, day] = date.split("-").map(Number); return new Date(Date.UTC(year, month - 1, day + 1)).toISOString().slice(0, 10); };

export async function listAppointmentReminderReportAction() {
  if (!(await canView())) return [];
  return db.selectFrom("appointment_reminders")
    .innerJoin("appointments", "appointments.id", "appointment_reminders.appointment_id")
    .innerJoin("patients", "patients.id", "appointment_reminders.patient_id")
    .innerJoin("doctors", "doctors.id", "appointments.doctor_id")
    .select(["appointment_reminders.id", "appointment_reminders.appointment_date", "appointment_reminders.response_status", "appointment_reminders.sent_at", "appointment_reminders.responded_at", "appointment_reminders.requested_date", "appointment_reminders.requested_time", "appointment_reminders.error_message", "patients.full_name as patient_name", "doctors.full_name as doctor_name", "appointments.start_time"])
    .orderBy("appointment_reminders.appointment_date", "desc").orderBy("appointments.start_time", "asc").limit(300).execute();
}

export async function getReminderSettingsAction() {
  if (!(await canView())) return null;
  const settings = await getAllSettings();
  return { time: settings.whatsapp_reminder_time, validHours: settings.whatsapp_reminder_valid_hours };
}

export async function saveReminderSettingsAction(time: string) {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "manage_whatsapp"))) return { ok: false, error: "غير مصرح" };
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) return { ok: false, error: "الوقت غير صحيح" };
  await setSetting("whatsapp_reminder_time", time);
  revalidatePath("/whatsapp");
  return { ok: true };
}

export async function createAppointmentTemplatesAction() {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "manage_whatsapp"))) return { ok: false, error: "غير مصرح" };
  const [account, settings] = await Promise.all([getActiveAccount(), getAllSettings()]);
  if (!account) return { ok: false, error: "اربط حساب واتساب أولًا." };
  try {
    await createAppointmentReminderTemplates(account.waba_id, await getAccountAccessToken(account.id), settings.clinic_public_url);
    return { ok: true };
  } catch (error) { return { ok: false, error: error instanceof Error ? error.message : "تعذر إنشاء القوالب" }; }
}

export async function approveAppointmentRescheduleAction(reminderId: number) {
  const session = await canView();
  if (!session) return { ok: false, error: "غير مصرح" };
  const reminder = await db.selectFrom("appointment_reminders")
    .innerJoin("appointments", "appointments.id", "appointment_reminders.appointment_id")
    .innerJoin("patients", "patients.id", "appointment_reminders.patient_id")
    .innerJoin("doctors", "doctors.id", "appointments.doctor_id")
    .select(["appointment_reminders.id", "appointment_reminders.response_status", "appointments.id as appointment_id", "appointments.appointment_date", "appointments.start_time", "patients.phone", "patients.phone_country_code", "doctors.full_name as doctor_name"])
    .where("appointment_reminders.id", "=", reminderId).executeTakeFirst();
  if (!reminder || reminder.response_status !== "reschedule_pending") return { ok: false, error: "طلب التعديل غير متاح." };
  const now = sqlNow();
  await db.transaction().execute(async (trx) => {
    await trx.updateTable("appointments").set({ reschedule_pending: 0, confirmed_at: now }).where("id", "=", reminder.appointment_id).execute();
    await trx.updateTable("appointment_reminders").set({ response_status: "reschedule_approved", approved_by: session.userId, approved_at: now, updated_at: now }).where("id", "=", reminder.id).execute();
  });
  let warning: string | undefined;
  if (reminder.phone) {
    try {
      const [account, settings] = await Promise.all([getActiveAccount(), getAllSettings()]);
      if (!account) throw new Error("لا يوجد حساب واتساب متصل");
      await sendRescheduleConfirmationTemplate({ phoneNumberId: account.phone_number_id, accessToken: await getAccountAccessToken(account.id), to: waNumber(reminder.phone_country_code, reminder.phone), templateName: settings.whatsapp_confirmation_template_name, language: settings.whatsapp_template_language, date: reminder.appointment_date, time: reminder.start_time.slice(0, 5), doctorName: reminder.doctor_name });
    } catch (error) { warning = `تم الاعتماد لكن تعذر إرسال رسالة التأكيد: ${error instanceof Error ? error.message : "خطأ إرسال"}`; }
  }
  revalidatePath("/whatsapp");
  return { ok: true, warning };
}

export async function approveAppointmentRescheduleByAppointmentAction(appointmentId: number) {
  const session = await canView();
  if (!session) return { ok: false, error: "غير مصرح" };
  const reminder = await db.selectFrom("appointment_reminders").select("id").where("appointment_id", "=", appointmentId).where("response_status", "=", "reschedule_pending").orderBy("id", "desc").executeTakeFirst();
  if (!reminder) return { ok: false, error: "لا يوجد تعديل ينتظر الاعتماد." };
  return approveAppointmentRescheduleAction(reminder.id);
}

export async function sendTomorrowConfirmationsAction() {
  if (!(await canView())) return { ok: false, error: "غير مصرح", sent: 0, skipped: 0, failed: 0 };
  const [account, settings] = await Promise.all([getActiveAccount(), getAllSettings()]);
  if (!account) return { ok: false, error: "لا يوجد حساب واتساب متصل. استخدم الإرسال اليدوي.", sent: 0, skipped: 0, failed: 0 };
  const date = nextDay(getClinicToday());
  const appointments = await db.selectFrom("appointments")
    .innerJoin("patients", "patients.id", "appointments.patient_id")
    .innerJoin("doctors", "doctors.id", "appointments.doctor_id")
    .select(["appointments.id", "appointments.start_time", "appointments.confirmed_at", "patients.full_name as patient_name", "patients.phone", "patients.phone_country_code", "doctors.full_name as doctor_name"])
    .where("appointments.appointment_date", "=", date).where("appointments.status", "=", "booked").where("appointments.reschedule_pending", "=", 0).orderBy("appointments.start_time").execute();
  const accessToken = await getAccountAccessToken(account.id);
  let sent = 0, skipped = 0, failed = 0;
  for (const appointment of appointments) {
    const existing = await db.selectFrom("appointment_reminders").select(["response_status", "sent_at"]).where("appointment_id", "=", appointment.id).where("appointment_date", "=", date).executeTakeFirst();
    if (appointment.confirmed_at || existing?.response_status === "confirmed" || existing?.response_status === "reschedule_approved" || (existing?.response_status === "pending" && existing.sent_at)) { skipped++; continue; }
    const issued = await issueAppointmentLink(appointment.id, "automatic");
    const tokenHash = hashAppointmentToken(issued.rawToken);
    if (!appointment.phone) {
      failed++;
      await db.updateTable("appointment_reminders").set({ response_status: "send_failed", send_attempts: 1, last_attempt_at: sqlNow(), error_message: "لا يوجد رقم هاتف مسجل للمريض", updated_at: sqlNow() }).where("token_hash", "=", tokenHash).execute();
      continue;
    }
    try {
      await sendAppointmentReminderTemplate({ phoneNumberId: account.phone_number_id, accessToken, to: waNumber(appointment.phone_country_code, appointment.phone), templateName: settings.whatsapp_reminder_template_name, language: settings.whatsapp_template_language, patientName: appointment.patient_name, date, time: appointment.start_time.slice(0, 5), doctorName: appointment.doctor_name, token: issued.rawToken });
      sent++;
      await db.updateTable("appointment_reminders").set({ response_status: "pending", sent_at: sqlNow(), send_attempts: 1, last_attempt_at: sqlNow(), error_message: null, updated_at: sqlNow() }).where("token_hash", "=", tokenHash).execute();
    } catch (error) {
      failed++;
      await db.updateTable("appointment_reminders").set({ response_status: "send_failed", send_attempts: 1, last_attempt_at: sqlNow(), error_message: error instanceof Error ? error.message.slice(0, 500) : "فشل الإرسال", updated_at: sqlNow() }).where("token_hash", "=", tokenHash).execute();
    }
  }
  revalidatePath("/whatsapp");
  return { ok: true, sent, skipped, failed };
}

export async function prepareTomorrowManualConfirmationsAction() {
  if (!(await canView())) return { ok: false, error: "غير مصرح", rows: [] as { appointmentId: number; patientName: string; time: string; whatsappUrl: string }[] };
  const date = nextDay(getClinicToday());
  const appointments = await db.selectFrom("appointments")
    .innerJoin("patients", "patients.id", "appointments.patient_id")
    .innerJoin("doctors", "doctors.id", "appointments.doctor_id")
    .select(["appointments.id", "appointments.start_time", "appointments.confirmed_at", "patients.full_name as patient_name", "patients.phone", "patients.phone_country_code", "doctors.full_name as doctor_name"])
    .where("appointments.appointment_date", "=", date).where("appointments.status", "=", "booked").where("appointments.reschedule_pending", "=", 0).orderBy("appointments.start_time").execute();
  const rows: { appointmentId: number; patientName: string; time: string; whatsappUrl: string }[] = [];
  for (const appointment of appointments) {
    if (appointment.confirmed_at || !appointment.phone) continue;
    const issued = await issueAppointmentLink(appointment.id, "manual");
    const message = `أهلًا ${appointment.patient_name}\nهذه الرسالة لتأكيد موعدك يوم ${date} الساعة ${appointment.start_time.slice(0, 5)} مع د. ${appointment.doctor_name}.\nبرجاء الضغط على الرابط لتأكيد الموعد أو تعديله:\n\n${issued.url}`;
    rows.push({ appointmentId: appointment.id, patientName: appointment.patient_name, time: appointment.start_time.slice(0, 5), whatsappUrl: `https://wa.me/${waNumber(appointment.phone_country_code, appointment.phone)}?text=${encodeURIComponent(message)}` });
  }
  return { ok: true, rows };
}
