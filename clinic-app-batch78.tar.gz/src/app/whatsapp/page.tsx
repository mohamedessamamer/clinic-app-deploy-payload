import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getAccountStatusAction, listConversationsAction, listTemplatesAction } from "./actions";
import WhatsAppConnectButton from "@/components/WhatsAppConnectButton";
import WhatsAppChat from "@/components/WhatsAppChat";
import WhatsAppTemplateManager from "@/components/WhatsAppTemplateManager";
import WhatsAppReconnectToken from "@/components/WhatsAppReconnectToken";
import WhatsAppAppointmentReport from "@/components/WhatsAppAppointmentReport";
import WhatsAppReminderSettings from "@/components/WhatsAppReminderSettings";
import { getReminderSettingsAction, listAppointmentReminderReportAction } from "@/app/appointment-reminders/report-actions";
import WhatsAppTomorrowSender from "@/components/WhatsAppTomorrowSender";

export default async function WhatsAppPage() {
  const session = await getSession();
  if (!session) {
    return <div className="card-3d rounded-xl p-5 text-sm text-muted">لازم تسجل دخول عشان توصل لصفحة واتساب.</div>;
  }
  const allowed = await hasPermission(session.userId, session.role, "manage_whatsapp");
  const canViewReport = await hasPermission(session.userId, session.role, "view_whatsapp_reminder_report");
  if (!allowed && !canViewReport) {
    return <div className="card-3d rounded-xl p-5 text-sm text-muted">مفيش صلاحية عندك لصفحة واتساب.</div>;
  }

  const account = allowed ? await getAccountStatusAction() : null;
  const [conversations, templates] = account
    ? await Promise.all([listConversationsAction(), listTemplatesAction()])
    : [[], []];
  const [reportRows, reminderSettings] = canViewReport ? await Promise.all([listAppointmentReminderReportAction(), getReminderSettingsAction()]) : [[], null];

  return (
    <div className="mx-auto max-w-6xl space-y-6 p-4">
      {canViewReport && <div className="card-3d rounded-xl p-5 space-y-4"><h1 className="text-lg font-semibold">متابعة تأكيد المواعيد</h1><WhatsAppTomorrowSender />{allowed && reminderSettings && <WhatsAppReminderSettings initialTime={reminderSettings.time} />}<WhatsAppAppointmentReport initialRows={reportRows} /></div>}

      {allowed && <div className="card-3d rounded-xl p-5">
        <h1 className="text-lg font-semibold">واتساب العيادة</h1>
        {!account ? (
          <div className="mt-3 space-y-3 text-sm">
            <p className="text-muted">
              لسه مفيش حساب واتساب متصل بالسيستم. اضغط الزرار تحت وسجّل دخول Meta واختر رقم واتساب بزنس.
            </p>
            <p className="rounded-lg bg-amber-50 p-3 text-xs leading-relaxed text-amber-800">
              مهم: أول ربط لازم يكون <strong>برقم Meta التجريبي</strong> وقت التطوير والمراجعة (App Review)، مش رقم
              العيادة الحقيقي. رقم العيادة بيتربط بس عن طريق خيار &quot;Coexistence&quot; في نافذة الربط، وبعد ما تتأكد
              إن تطبيق WhatsApp Business هيفضل شغال عادي على موبايل الاستقبال.
            </p>
            <WhatsAppConnectButton />
          </div>
        ) : (
          <div className="mt-3 grid grid-cols-1 gap-2 text-sm sm:grid-cols-2">
            <div>
              الرقم المتصل: <strong>{account.displayPhoneNumber ?? "—"}</strong>
              {account.verifiedName ? ` (${account.verifiedName})` : ""}
            </div>
            <div>
              الوضع:{" "}
              <span className={account.environment === "test" ? "text-amber-600" : "text-emerald-700"}>
                {account.environment === "test" ? "رقم تجريبي (Test number)" : "إنتاج"}
              </span>
              {account.coexistenceMode ? " — Coexistence مع WhatsApp Business App" : ""}
            </div>
            <div>
              حالة الاتصال:{" "}
              <span className={account.connectionStatus === "connected" ? "text-emerald-700" : "text-red-700"}>
                {account.connectionStatus}
              </span>
            </div>
          </div>
        )}
        {account && (
          <div className="mt-4 border-t border-slate-100 pt-3">
            <WhatsAppReconnectToken />
          </div>
        )}
      </div>}

      {account && (
        <>
          <div className="card-3d rounded-xl p-5">
            <h2 className="mb-3 text-base font-semibold">المحادثات</h2>
            <WhatsAppChat conversations={conversations} />
          </div>

          <div className="card-3d rounded-xl p-5">
            <h2 className="mb-3 text-base font-semibold">قوالب الرسائل (Message Templates)</h2>
            <WhatsAppTemplateManager templates={templates} />
          </div>
        </>
      )}
    </div>
  );
}
