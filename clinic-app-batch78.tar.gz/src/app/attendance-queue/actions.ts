"use server";

import { db } from "@/lib/db/client";
import { getClinicToday } from "@/lib/clinic-date";
import { getSession } from "@/lib/session";

export type AttendanceQueueRoom = {
  roomId: number;
  roomName: string;
  patients: {
    appointmentId: number;
    patientName: string;
    attendedAt: string | null;
  }[];
};

export async function getAttendanceQueueAction(): Promise<AttendanceQueueRoom[]> {
  const session = await getSession();
  if (!session) return [];

  const rows = await db
    .selectFrom("appointments")
    .innerJoin("patients", "patients.id", "appointments.patient_id")
    .innerJoin("rooms", "rooms.id", "appointments.room_id")
    .innerJoin("doctors", "doctors.id", "appointments.doctor_id")
    .select([
      "appointments.id as appointment_id",
      "appointments.room_id",
      "appointments.doctor_id",
      "appointments.start_time",
      "appointments.attended_at",
      "patients.full_name as patient_name",
      "rooms.name as room_name",
      "doctors.full_name as doctor_name",
    ])
    .where("appointments.appointment_date", "=", getClinicToday())
    .where("appointments.status", "=", "attended")
    .orderBy("rooms.id", "asc")
    .execute();

  // المواعيد الجديدة تُرتّب بوقت الوصول الحقيقي. الحالات القديمة التي كانت
  // «حضر» قبل إضافة العمود تأتي بعدها بترتيب الموعد كحل احتياطي ثابت.
  rows.sort((a, b) => {
    if (a.doctor_id !== b.doctor_id) return a.doctor_id - b.doctor_id;
    if (a.attended_at && b.attended_at) return a.attended_at.localeCompare(b.attended_at);
    if (a.attended_at) return -1;
    if (b.attended_at) return 1;
    const byTime = a.start_time.localeCompare(b.start_time);
    return byTime || a.appointment_id - b.appointment_id;
  });

  const rooms = new Map<number, AttendanceQueueRoom & { roomNames: Set<string>; doctorName: string }>();
  for (const row of rows) {
    // الطبيب هو وحدة الطابور الفعلية. لو مسؤول عن عيادتين في نفس الشيفت، مرضى
    // العيادتين يدخلون في ترتيب حضور واحد بدل قائمتين متعارضتين.
    let room = rooms.get(row.doctor_id);
    if (!room) {
      room = { roomId: row.doctor_id, roomName: row.room_name, roomNames: new Set(), doctorName: row.doctor_name, patients: [] };
      rooms.set(row.doctor_id, room);
    }
    room.roomNames.add(row.room_name);
    room.patients.push({
      appointmentId: row.appointment_id,
      patientName: row.patient_name,
      attendedAt: row.attended_at,
    });
  }

  return [...rooms.values()].map((group) => ({
    roomId: group.roomId,
    roomName: group.roomNames.size > 1 ? `د. ${group.doctorName} — ${[...group.roomNames].join(" + ")}` : [...group.roomNames][0] ?? group.roomName,
    patients: group.patients,
  }));
}
