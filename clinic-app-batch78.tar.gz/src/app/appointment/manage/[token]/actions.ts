"use server";

import { confirmAppointmentByToken, getAvailableAppointmentSlots, reserveRescheduleByToken } from "@/lib/appointment-self-service";

export async function confirmPublicAppointmentAction(token: string) { return confirmAppointmentByToken(token); }
export async function listPublicAppointmentSlotsAction(token: string) { return getAvailableAppointmentSlots(token); }
export async function reservePublicAppointmentAction(token: string, date: string, time: string, roomId: number) { return reserveRescheduleByToken(token, date, time, roomId); }
