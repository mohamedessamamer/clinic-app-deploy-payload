import "server-only";

import { db } from "@/lib/db/client";
import { getAllSettings } from "@/lib/settings";
import { issueAppointmentLink, hashAppointmentToken } from "@/lib/appointment-self-service";
import { getActiveAccount, getAccountAccessToken } from "@/lib/whatsapp/store";
import { sendAppointmentReminderTemplate } from "@/lib/whatsapp/graph";

const sqlNow = () => new Date().toISOString().replace("T", " ").slice(0, 19);
const cairoParts = () => Object.fromEntries(new Intl.DateTimeFormat("en-CA", { timeZone: "Africa/Cairo", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(new Date()).map((part) => [part.type, part.value]));
const addDay = (date: string) => { const [y, m, d] = date.split("-").map(Number); return new Date(Date.UTC(y, m - 1, d + 1)).toISOString().slice(0, 10); };
const whatsappNumber = (country: string, local: string) => `${country.replace(/\D/g, "")}${local.replace(/\D/g, "").replace(/^0+/, "")}`;

let running = false;
export async function processDueAppointmentReminders() {
  if (running) return;
  running = true;
  try {
    const settings = await getAllSettings();
    const parts = cairoParts();
    const current = Number(parts.hour) * 60 + Number(parts.minute);
    const [hour, minute] = settings.whatsapp_reminder_time.split(":").map(Number);
    const sendMinute = hour * 60 + minute;
    const validMinutes = Math.max(1, Number(settings.whatsapp_reminder_valid_hours) || 3) * 60;
    if (current < sendMinute || current >= sendMinute + validMinutes) return;
    const account = await getActiveAccount();
    if (!account || account.connection_status !== "connected") return;
    const targetDate = addDay(`${parts.year}-${parts.month}-${parts.day}`);
    const appointments = await db.selectFrom("appointments")
      .innerJoin("patients", "patients.id", "appointments.patient_id")
      .innerJoin("doctors", "doctors.id", "appointments.doctor_id")
      .select(["appointments.id", "appointments.start_time", "patients.full_name as patient_name", "patients.phone", "patients.phone_country_code", "doctors.full_name as doctor_name"])
      .where("appointments.appointment_date", "=", targetDate).where("appointments.status", "=", "booked").where("appointments.reschedule_pending", "=", 0).execute();
    const accessToken = await getAccountAccessToken(account.id);
    for (const appointment of appointments) {
      const exists = await db.selectFrom("appointment_reminders").select("id").where("appointment_id", "=", appointment.id).where("appointment_date", "=", targetDate).executeTakeFirst();
      if (exists) continue;
      const issued = await issueAppointmentLink(appointment.id, "automatic");
      const tokenHash = hashAppointmentToken(issued.rawToken);
      if (!appointment.phone) {
        await db.updateTable("appointment_reminders").set({ response_status: "send_failed", send_attempts: 1, last_attempt_at: sqlNow(), error_message: "لا يوجد رقم هاتف مسجل للمريض", updated_at: sqlNow() }).where("token_hash", "=", tokenHash).execute();
        continue;
      }
      try {
        await sendAppointmentReminderTemplate({ phoneNumberId: account.phone_number_id, accessToken, to: whatsappNumber(appointment.phone_country_code, appointment.phone), templateName: settings.whatsapp_reminder_template_name, language: settings.whatsapp_template_language, patientName: appointment.patient_name, date: targetDate, time: appointment.start_time.slice(0, 5), doctorName: appointment.doctor_name, token: issued.rawToken });
        await db.updateTable("appointment_reminders").set({ sent_at: sqlNow(), send_attempts: 1, last_attempt_at: sqlNow(), error_message: null, updated_at: sqlNow() }).where("token_hash", "=", tokenHash).execute();
      } catch (error) {
        await db.updateTable("appointment_reminders").set({ response_status: "send_failed", send_attempts: 1, last_attempt_at: sqlNow(), error_message: error instanceof Error ? error.message.slice(0, 500) : "فشل الإرسال", updated_at: sqlNow() }).where("token_hash", "=", tokenHash).execute();
      }
    }
  } finally { running = false; }
}

export function startAppointmentReminderScheduler() {
  const globalScheduler = globalThis as typeof globalThis & { __clinicReminderTimer?: ReturnType<typeof setInterval> };
  if (globalScheduler.__clinicReminderTimer) return;
  const timer = setInterval(() => processDueAppointmentReminders().catch((error) => console.error("[appointment-reminders]", error instanceof Error ? error.message : error)), 60_000);
  timer.unref?.();
  globalScheduler.__clinicReminderTimer = timer;
  setTimeout(() => processDueAppointmentReminders().catch(() => undefined), 5_000).unref?.();
}
