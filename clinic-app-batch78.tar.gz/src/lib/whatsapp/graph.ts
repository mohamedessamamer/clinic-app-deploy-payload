import "server-only";
import { getWhatsappConfig } from "./config";

// طبقة رقيقة فوق Meta Graph API لواتساب — كل الدوال هنا بتاخد accessToken كـ
// parameter صريح (متسحبش من DB هنا، شوف lib/whatsapp/store.ts) عشان الملف ده
// يفضل بدون أي اتصال بقاعدة البيانات. ممنوع طبع/تسجيل accessToken أو أي جزء
// منه في أي مكان في الملف ده — أخطاء الشبكة بتتسجل برسالة عامة بس.

class WhatsappGraphError extends Error {
  constructor(message: string, public status: number, public metaError?: unknown) {
    super(message);
  }
}

async function graphFetch<T>(path: string, accessToken: string, init?: RequestInit): Promise<T> {
  const { graphVersion } = getWhatsappConfig();
  const url = path.startsWith("http") ? path : `https://graph.facebook.com/${graphVersion}${path}`;
  const res = await fetch(url, {
    ...init,
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      ...(init?.headers || {}),
    },
  });
  const json = await res.json().catch(() => null);
  if (!res.ok) {
    // ما بنسجّلش الـheaders (فيها الـtoken) ولا الـbody كامل لو فيه شك إنه يحتوي
    // سر — رسالة Meta نفسها (json.error) آمنة تتسجل، مبتحتويش توكنات.
    throw new WhatsappGraphError(
      `Graph API error (${res.status}) على ${path}: ${JSON.stringify((json as { error?: unknown } | null)?.error ?? json)}`,
      res.status,
      (json as { error?: unknown } | null)?.error
    );
  }
  return json as T;
}

// تبادل الـcode القادم من Embedded Signup (Facebook Login for Business) بتوكن
// فعلي. الـcode بييجي من الـfrontend (WhatsAppConnectButton) بعد ما المستخدم
// يوافق في نافذة الـEmbedded Signup.
export async function exchangeCodeForToken(code: string): Promise<{ access_token: string; token_type: string; expires_in?: number }> {
  const { appId, appSecret, graphVersion } = getWhatsappConfig();
  const params = new URLSearchParams({ client_id: appId, client_secret: appSecret, code });
  const res = await fetch(`https://graph.facebook.com/${graphVersion}/oauth/access_token?${params.toString()}`);
  const json = await res.json();
  if (!res.ok) {
    throw new WhatsappGraphError(`فشل تبادل الـcode: ${JSON.stringify(json?.error ?? json)}`, res.status, json?.error);
  }
  return json;
}

// اشتراك التطبيق على أحداث الـWABA دي تحديدًا (لازم بعد كل عملية ربط جديدة —
// من غير الخطوة دي الـwebhook مش هيستقبل حاجة لحساب العميل ده).
export async function subscribeAppToWaba(wabaId: string, accessToken: string): Promise<void> {
  await graphFetch(`/${wabaId}/subscribed_apps`, accessToken, { method: "POST" });
}

export async function getWabaPhoneNumbers(
  wabaId: string,
  accessToken: string
): Promise<{ data: { id: string; display_phone_number: string; verified_name: string }[] }> {
  return graphFetch(`/${wabaId}/phone_numbers`, accessToken);
}

export async function getWabaInfo(wabaId: string, accessToken: string): Promise<{ id: string; name?: string }> {
  return graphFetch(`/${wabaId}?fields=id,name`, accessToken);
}

export interface SendTextResult {
  messaging_product: "whatsapp";
  messages: { id: string }[];
}

// to: رقم بصيغة دولية بدون + (زي "201234567890")
export async function sendTextMessage(phoneNumberId: string, accessToken: string, to: string, body: string): Promise<SendTextResult> {
  return graphFetch(`/${phoneNumberId}/messages`, accessToken, {
    method: "POST",
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      type: "text",
      text: { preview_url: false, body },
    }),
  });
}

export async function sendAppointmentReminderTemplate(params: {
  phoneNumberId: string; accessToken: string; to: string; templateName: string; language: string;
  patientName: string; date: string; time: string; doctorName: string; token: string;
}): Promise<SendTextResult> {
  return graphFetch(`/${params.phoneNumberId}/messages`, params.accessToken, {
    method: "POST",
    body: JSON.stringify({ messaging_product: "whatsapp", to: params.to, type: "template", template: {
      name: params.templateName, language: { code: params.language }, components: [
        { type: "body", parameters: [params.patientName, params.date, params.time, params.doctorName].map((text) => ({ type: "text", text })) },
        { type: "button", sub_type: "quick_reply", index: "0", parameters: [{ type: "payload", payload: `confirm:${params.token}` }] },
        { type: "button", sub_type: "url", index: "1", parameters: [{ type: "text", text: params.token }] },
      ],
    }}),
  });
}

export async function sendRescheduleConfirmationTemplate(params: { phoneNumberId: string; accessToken: string; to: string; templateName: string; language: string; date: string; time: string; doctorName: string }): Promise<SendTextResult> {
  return graphFetch(`/${params.phoneNumberId}/messages`, params.accessToken, { method: "POST", body: JSON.stringify({
    messaging_product: "whatsapp", to: params.to, type: "template", template: { name: params.templateName, language: { code: params.language }, components: [
      { type: "body", parameters: [params.date, params.time, params.doctorName].map((text) => ({ type: "text", text })) },
    ] },
  }) });
}

export async function markMessageAsRead(phoneNumberId: string, accessToken: string, wamid: string): Promise<void> {
  await graphFetch(`/${phoneNumberId}/messages`, accessToken, {
    method: "POST",
    body: JSON.stringify({ messaging_product: "whatsapp", status: "read", message_id: wamid }),
  });
}

export interface MetaTemplate {
  id: string;
  name: string;
  language: string;
  category: string;
  status: string;
  rejected_reason?: string;
}

export async function listTemplates(wabaId: string, accessToken: string): Promise<{ data: MetaTemplate[] }> {
  return graphFetch(`/${wabaId}/message_templates?fields=id,name,language,category,status,rejected_reason&limit=100`, accessToken);
}

// إنشاء قالب رسالة تجريبي بسيط: جسم نصي بس، من غير أزرار أو متغيرات — كافي
// لخطوة App Review (المطلوب: قالب واحد يتعمل من داخل السيستم وتظهر حالته).
export async function createMessageTemplate(
  wabaId: string,
  accessToken: string,
  params: { name: string; language: string; category: string; bodyText: string }
): Promise<{ id: string; status: string; category: string }> {
  return graphFetch(`/${wabaId}/message_templates`, accessToken, {
    method: "POST",
    body: JSON.stringify({
      name: params.name,
      language: params.language,
      category: params.category,
      components: [{ type: "BODY", text: params.bodyText }],
    }),
  });
}

export async function createAppointmentReminderTemplates(wabaId: string, accessToken: string, publicUrl: string) {
  const reminder = await graphFetch<{ id: string; status: string }>(`/${wabaId}/message_templates`, accessToken, { method: "POST", body: JSON.stringify({
    name: "appointment_reminder", language: "ar", category: "UTILITY", components: [
      { type: "BODY", text: "مرحبًا {{1}}، نذكرك بموعدك يوم {{2}} الساعة {{3}} مع د. {{4}}. يمكنك تأكيد الموعد أو طلب تعديله خلال 3 ساعات.", example: { body_text: [["أحمد محمد", "2026-09-09", "18:00", "محمد علي"]] } },
      { type: "BUTTONS", buttons: [
        { type: "QUICK_REPLY", text: "تأكيد الموعد" },
        { type: "URL", text: "تعديل الموعد", url: `${publicUrl.replace(/\/$/, "")}/appointment/manage/{{1}}`, example: ["sample-token-for-review"] },
      ] },
    ],
  }) });
  const confirmation = await graphFetch<{ id: string; status: string }>(`/${wabaId}/message_templates`, accessToken, { method: "POST", body: JSON.stringify({
    name: "appointment_reschedule_confirmed", language: "ar", category: "UTILITY", components: [
      { type: "BODY", text: "تم اعتماد تعديل موعدك إلى يوم {{1}} الساعة {{2}} مع د. {{3}}. ننتظرك في الموعد الجديد.", example: { body_text: [["2026-09-10", "19:00", "محمد علي"]] } },
    ],
  }) });
  return { reminder, confirmation };
}

export { WhatsappGraphError };
