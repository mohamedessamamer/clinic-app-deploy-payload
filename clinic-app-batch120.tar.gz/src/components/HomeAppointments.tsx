"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

export type HomeAppointment = { id: number; doctorName: string; patientName: string; service: string; href: string; status: "booked" | "attended"; startTime: string; attendedAt: string | null };

function elapsed(value: string | null, now: number) {
  if (!value) return "00:00";
  const minutes = Math.max(0, Math.floor((now - new Date(value).getTime()) / 60_000));
  return `${String(Math.floor(minutes / 60)).padStart(2, "0")}:${String(minutes % 60).padStart(2, "0")}`;
}

export default function HomeAppointments({ items }: { items: HomeAppointment[] }) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => { const timer = window.setInterval(() => setNow(Date.now()), 30_000); return () => window.clearInterval(timer); }, []);
  const groups = useMemo(() => {
    const result = new Map<string, HomeAppointment[]>();
    for (const item of items) result.set(item.doctorName, [...(result.get(item.doctorName) ?? []), item]);
    return [...result.entries()];
  }, [items]);
  return <div className="space-y-4">{groups.map(([doctorName, group]) => <div key={doctorName} className="home-doctor-appointments"><div className="home-doctor-appointments-title">{doctorName}</div><div className="space-y-2">{group.map((item) => <div key={item.id} className={`schedule-appointment-card home-appointment-card ${item.status === "attended" ? "schedule-appointment-cell--attended" : ""}`}><div className="schedule-card-clinical"><Link href={item.href} className="schedule-card-name font-semibold inline-block cursor-pointer hover:underline">{item.patientName}</Link><div className="schedule-card-service">{item.service}</div></div><div className="schedule-card-meta"><span className={`schedule-card-status schedule-card-status--${item.status}`}>{item.status === "attended" ? `حضر ${elapsed(item.attendedAt, now)}` : item.startTime}</span></div></div>)}</div></div>)}</div>;
}
