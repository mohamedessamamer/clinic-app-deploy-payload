"use client";

import { useMemo, useState } from "react";
import { addVisitAction } from "@/app/patients/[id]/actions";
import ServiceCombobox from "@/components/ServiceCombobox";

type Service = { id: number; name: string; code?: string | null; default_price?: number | null };
type Doctor = { id: number; full_name: string };

export default function AddVisitForm({
  patientId,
  services,
  doctors,
  currentDoctorId = null,
  canOverrideDoctor = false,
  todaysApptDoctorId = null,
  todaysApptDoctorName = null,
}: {
  patientId: number;
  services: Service[];
  doctors: Doctor[];
  // لو المستخدم الحالي دكتور (داخل بأكونته هو)، بيبقى هو الطبيب الأساسي (اللي
  // بيتحسب له ماليًا) أوتوماتيك من غير ما يحتاج يختار نفسه من قايمة أصلًا.
  currentDoctorId?: number | null;
  // صلاحية "اختيار مقدم خدمة مختلف" — بتفتح حقل تاني اختياري لتحديد مين اللي نفّذ
  // الخدمة فعليًا لو مختلف عن الطبيب الأساسي (زي دكتور مساعد)، من غير ما ده يأثر
  // على مين بيتحسب له التحصيل المالي (ده بيفضل الطبيب الأساسي/صاحب الشيفت دايمًا).
  canOverrideDoctor?: boolean;
  // للأدمن/مدير العيادة بس (مش دكتور): دكتور موعد المريض المسجل من الاستقبال
  // النهاردة، لو موجود — لو موجود، الطبيب المعالج بيتثبت عليه (مش اختيار حر)
  // وبيبقى متاح بس اختيار "الطبيب المساعد". لو مفيش حجز النهاردة، الفورم بيرجع
  // للاختيار اليدوي العادي (شوف addVisitAction اللي بيعمل نفس التحقق في السيرفر).
  todaysApptDoctorId?: number | null;
  todaysApptDoctorName?: string | null;
}) {
  const today = useMemo(() => new Date().toISOString().slice(0, 10), []);
  const [serviceId, setServiceId] = useState<string>("");

  const isDoctorAccount = currentDoctorId != null;

  return (
    <form action={addVisitAction} className="grid grid-cols-1 sm:grid-cols-5 gap-2 items-end">
      <input type="hidden" name="patient_id" value={patientId} />
      <div className="sm:col-span-1">
        <label className="block text-xs text-muted mb-1">التاريخ</label>
        <input
          type="date"
          name="visit_date"
          defaultValue={today}
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>
      <div className="sm:col-span-1">
        <label className="block text-xs text-muted mb-1">نوع الخدمة</label>
        {/* Combobox بدل select عادي: بيفتح كقايمة كاملة لو اتدوس عليه من غير كتابة،
            وبيدور بالاسم أو بالكود مع كل حرف/رقم بيتكتب — أسرع من السكرول في قايمة طويلة. */}
        <ServiceCombobox name="service_id" services={services} value={serviceId} onChange={setServiceId} />
      </div>
      <div className={isDoctorAccount && !canOverrideDoctor ? "sm:col-span-3" : "sm:col-span-2"}>
        <label className="block text-xs text-muted mb-1">المعالجة</label>
        {/* textarea مش input عشان Enter يعمل سطر جديد بس (زي أي محرر نصوص عادي)
            بدل ما يبعت الفورم على طول — الإرسال بقى بس من زرار "إضافة زيارة". */}
        <textarea
          name="notes"
          placeholder="تفاصيل اللي تم عمله..."
          rows={1}
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary resize-y"
        />
      </div>

      {/* دكتور حساب: اسمه بيتحدد أوتوماتيك (هو صاحب الشيفت/التحصيل المالي) من غير
          أي اختيار — إلا لو معاه صلاحية "مقدم خدمة مختلف" بيظهر له حقل اختياري تاني. */}
      {isDoctorAccount ? (
        <>
          <input type="hidden" name="doctor_id" value={currentDoctorId ?? ""} />
          {canOverrideDoctor && (
            <div className="sm:col-span-1">
              <label className="block text-xs text-muted mb-1">مقدم الخدمة الفعلي (لو مختلف)</label>
              <select
                name="performing_doctor_id"
                defaultValue=""
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="">نفس الطبيب الأساسي (أنا)</option>
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.full_name}
                  </option>
                ))}
              </select>
            </div>
          )}
        </>
      ) : todaysApptDoctorId ? (
        // أدمن/مدير عيادة، والمريض عليه حجز مسجل من الاستقبال النهاردة: الطبيب
        // المعالج بيتثبت على صاحب الحجز ده (مش اختيار حر — نفس التحقق مطبّق في
        // addVisitAction على السيرفر)، والاختيار المتاح هنا بس هو "الطبيب المساعد"
        // لحالة مريض جاي فجأة لدكتور تاني غير صاحب الحجز.
        <>
          <input type="hidden" name="doctor_id" value={todaysApptDoctorId} />
          <div className="sm:col-span-1">
            <label className="block text-xs text-muted mb-1">الطبيب المعالج</label>
            <div className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm text-muted">
              {todaysApptDoctorName ?? "—"}
            </div>
            <p className="text-[10px] text-muted mt-0.5">حسب حجز الاستقبال النهاردة</p>
          </div>
          <div className="sm:col-span-1">
            <label className="block text-xs text-muted mb-1">الطبيب المساعد (لو مختلف)</label>
            <select
              name="performing_doctor_id"
              defaultValue=""
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="">نفس الطبيب المعالج فوق</option>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.full_name}
                </option>
              ))}
            </select>
          </div>
        </>
      ) : (
        // أدمن/مدير عيادة، ومفيش حجز مسجل للمريض النهاردة (زيارة قديمة أو تصحيح
        // بيانات مثلاً) — اختيار يدوي عادي، من كل الأطباء (من غير أي تصفية حسب
        // نوع الخدمة).
        <>
          <div className="sm:col-span-1">
            <label className="block text-xs text-muted mb-1">الدكتور</label>
            <select
              name="doctor_id"
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="">اختر دكتور</option>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.full_name}
                </option>
              ))}
            </select>
          </div>
          {canOverrideDoctor && (
            <div className="sm:col-span-1">
              <label className="block text-xs text-muted mb-1">مقدم الخدمة الفعلي (لو مختلف)</label>
              <select
                name="performing_doctor_id"
                defaultValue=""
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="">نفس الدكتور المختار فوق</option>
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.full_name}
                  </option>
                ))}
              </select>
            </div>
          )}
        </>
      )}

      <div className="sm:col-span-5">
        <button
          type="submit"
          className="rounded-md bg-primary text-white px-4 py-1.5 text-sm font-medium hover:bg-primary-dark transition-colors"
        >
          + إضافة زيارة
        </button>
      </div>
    </form>
  );
}
