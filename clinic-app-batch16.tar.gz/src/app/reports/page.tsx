import Link from "next/link";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { paymentMethodLabel } from "@/lib/payment-methods";
import ReportsFilterForm from "@/components/ReportsFilterForm";

// تقرير الإيرادات — صفحة/صلاحية مستقلة (reports_full / reports_own، شوف
// permission-defs.ts) بتجمّع بيانات الفواتير الموجودة فعلاً (نفس مصدر بيانات
// /invoices والملف المالي لكل مريض) بفلاتر فترة/دكتور/خدمة، بدل ما تبقى صفحة
// منفصلة بمنطق حسابي مختلف. عمدًا بيربط رجوع لصفوف اليوم التفصيلية في /invoices
// (شوف "ربط الشاشات" في رابط عمود التاريخ تحت).

function isValidDate(s: string | undefined): s is string {
  return !!s && /^\d{4}-\d{2}-\d{2}$/.test(s);
}

function firstDayOfMonth(d: Date) {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1)).toISOString().slice(0, 10);
}

function round2(n: number) {
  return Math.round(n * 100) / 100;
}

type SearchParams = { from?: string; to?: string; doctor_id?: string; service_id?: string };

export default async function ReportsPage({ searchParams }: { searchParams: Promise<SearchParams> }) {
  const session = await getSession();
  if (!session) {
    return (
      <div className="bg-surface border border-border rounded-xl p-5 text-sm text-muted">لازم تسجل دخول عشان توصل للتقارير.</div>
    );
  }

  const [reportsFull, reportsOwn] = await Promise.all([
    hasPermission(session.userId, session.role, "reports_full"),
    hasPermission(session.userId, session.role, "reports_own"),
  ]);

  if (!reportsFull && !reportsOwn) {
    return (
      <div className="bg-surface border border-border rounded-xl p-5 text-sm text-muted">
        مفيش صلاحية عندك لعرض التقارير — كلم الأدمن لو محتاج توصل للصفحة دي.
      </div>
    );
  }

  if (!reportsFull && !session.doctorId) {
    return (
      <div className="bg-surface border border-border rounded-xl p-5 text-sm text-muted">
        الحساب ده مالوش دكتور مرتبط بيه، فمفيش تقرير شخصي نقدر نعرضه ليك.
      </div>
    );
  }

  const sp = await searchParams;
  const today = new Date().toISOString().slice(0, 10);
  const from = isValidDate(sp.from) ? sp.from : firstDayOfMonth(new Date());
  const to = isValidDate(sp.to) ? sp.to : today;

  // reports_own (من غير reports_full، عادة دكتور): الدكتور مقفول على نفسه —
  // أي doctor_id مبعوت في الرابط بيتجاهل، ومفيش قايمة اختيار أصلاً في الفورم.
  const requestedDoctorId = sp.doctor_id ? Number(sp.doctor_id) : null;
  const doctorId = reportsFull ? requestedDoctorId : session.doctorId!;
  const serviceId = sp.service_id ? Number(sp.service_id) : null;

  const [doctors, allServices] = await Promise.all([
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).execute(),
    db.selectFrom("services").select(["id", "name", "code"]).execute(),
  ]);
  // خدمة "متابعة" (كود 0) مش خدمة فعلية تتقاس كإيراد مستقل — دفعاتها بتتنسب
  // للخدمة الأصلية اللي بتقفل رصيدها (شوف تحت)، فمالهاش داعي تظهر كخيار فلتر.
  const services = allServices.filter((s) => s.code !== "0");

  // فواتير أصلية (استحقاق جديد) في الفترة، بفلاتر الدكتور/الخدمة مباشرة.
  let rootQuery = db
    .selectFrom("invoices")
    .innerJoin("visits", "visits.id", "invoices.visit_id")
    .leftJoin("doctors", "doctors.id", "visits.primary_doctor_id")
    .leftJoin("services", "services.id", "visits.service_id")
    .select([
      "invoices.id",
      "invoices.amount",
      "invoices.paid",
      "invoices.payment_method",
      "visits.visit_date",
      "visits.primary_doctor_id as doctor_id",
      "doctors.full_name as doctor_name",
      "visits.service_id",
      "services.name as service_name",
    ])
    .where("invoices.parent_invoice_id", "is", null)
    .where("visits.visit_date", ">=", from)
    .where("visits.visit_date", "<=", to);
  if (doctorId) rootQuery = rootQuery.where("visits.primary_doctor_id", "=", doctorId);
  if (serviceId) rootQuery = rootQuery.where("visits.service_id", "=", serviceId);
  const rootInvoices = await rootQuery.execute();

  // دفعات متابعة (تحصيل على فواتير قديمة) اللي حصلت *في الفترة دي* — بغض النظر
  // عن تاريخ الفاتورة الأصلية. بتتجاب من غير فلتر دكتور/خدمة الأول، لأن الدكتور/
  // الخدمة الحقيقيين ليها هما بتوع الفاتورة الأصلية (parent) مش بتوعها هي —
  // شوف parentInfoById تحت، نفس مبدأ إصلاح /invoices في دفعة 15.
  const followupRaw = await db
    .selectFrom("invoices")
    .innerJoin("visits", "visits.id", "invoices.visit_id")
    .select(["invoices.id", "invoices.paid", "invoices.payment_method", "invoices.parent_invoice_id", "visits.visit_date"])
    .where("invoices.parent_invoice_id", "is not", null)
    .where("visits.visit_date", ">=", from)
    .where("visits.visit_date", "<=", to)
    .execute();

  const parentIds = [...new Set(followupRaw.map((f) => f.parent_invoice_id).filter((id): id is number => id != null))];
  const parentInfoById = new Map<number, { doctor_id: number | null; doctor_name: string | null; service_id: number | null; service_name: string | null }>();
  if (parentIds.length > 0) {
    const parents = await db
      .selectFrom("invoices")
      .innerJoin("visits", "visits.id", "invoices.visit_id")
      .leftJoin("doctors", "doctors.id", "visits.primary_doctor_id")
      .leftJoin("services", "services.id", "visits.service_id")
      .select(["invoices.id", "visits.primary_doctor_id as doctor_id", "doctors.full_name as doctor_name", "visits.service_id", "services.name as service_name"])
      .where("invoices.id", "in", parentIds)
      .execute();
    for (const p of parents) {
      parentInfoById.set(p.id, { doctor_id: p.doctor_id, doctor_name: p.doctor_name, service_id: p.service_id, service_name: p.service_name });
    }
  }

  // دلوقتي بنفلتر دفعات المتابعة حسب دكتور/خدمة الفاتورة الأصلية بتاعتها (مش
  // بتاعتها هي) — عشان تحصيل على "تقويم معدني" يتحسب مع "تقويم معدني" في التقرير
  // برضه، مش يختفي أو يتحسب لخدمة "متابعة" العامة.
  const followups = followupRaw
    .map((f) => {
      const parent = f.parent_invoice_id != null ? parentInfoById.get(f.parent_invoice_id) : undefined;
      return {
        id: f.id,
        paid: f.paid,
        payment_method: f.payment_method,
        visit_date: f.visit_date,
        doctor_id: parent?.doctor_id ?? null,
        doctor_name: parent?.doctor_name ?? null,
        service_id: parent?.service_id ?? null,
        service_name: parent?.service_name ?? null,
      };
    })
    .filter((f) => (doctorId ? f.doctor_id === doctorId : true))
    .filter((f) => (serviceId ? f.service_id === serviceId : true));

  // إجماليات عامة
  const newAmount = round2(rootInvoices.reduce((s, i) => s + i.amount, 0));
  const collected = round2(rootInvoices.reduce((s, i) => s + i.paid, 0) + followups.reduce((s, f) => s + f.paid, 0));
  const visitCount = rootInvoices.length;

  // حسب وسيلة الدفع
  const byMethod = new Map<string, number>();
  for (const i of rootInvoices) {
    if (i.paid <= 0) continue;
    const key = i.payment_method ?? "غير محدد";
    byMethod.set(key, round2((byMethod.get(key) ?? 0) + i.paid));
  }
  for (const f of followups) {
    if (f.paid <= 0) continue;
    const key = f.payment_method ?? "غير محدد";
    byMethod.set(key, round2((byMethod.get(key) ?? 0) + f.paid));
  }

  // تجميع مساعد عام: بيرجع خريطة key -> {label, amount, paid, visits}
  function aggregate<T extends { paid: number }>(
    rootRows: (T & { amount: number; visit_date: string })[],
    followupRows: T[],
    keyOf: (r: T) => string | number | null,
    labelOf: (r: T) => string
  ) {
    const map = new Map<string | number, { key: string | number; label: string; amount: number; paid: number; visits: number }>();
    for (const r of rootRows) {
      const k = keyOf(r);
      if (k == null) continue;
      const cur = map.get(k) ?? { key: k, label: labelOf(r), amount: 0, paid: 0, visits: 0 };
      cur.amount = round2(cur.amount + r.amount);
      cur.paid = round2(cur.paid + r.paid);
      cur.visits += 1;
      map.set(k, cur);
    }
    for (const r of followupRows) {
      const k = keyOf(r);
      if (k == null) continue;
      const cur = map.get(k) ?? { key: k, label: labelOf(r), amount: 0, paid: 0, visits: 0 };
      cur.paid = round2(cur.paid + r.paid);
      map.set(k, cur);
    }
    return [...map.values()].sort((a, b) => b.paid - a.paid);
  }

  const byDoctor =
    reportsFull && !doctorId
      ? aggregate(rootInvoices, followups, (r) => r.doctor_id, (r) => r.doctor_name ?? "بدون دكتور")
      : [];

  const byService = aggregate(rootInvoices, followups, (r) => r.service_id, (r) => r.service_name ?? "بدون خدمة");

  const byDayMap = new Map<string, { date: string; amount: number; paid: number; visits: number }>();
  for (const r of rootInvoices) {
    const cur = byDayMap.get(r.visit_date) ?? { date: r.visit_date, amount: 0, paid: 0, visits: 0 };
    cur.amount = round2(cur.amount + r.amount);
    cur.paid = round2(cur.paid + r.paid);
    cur.visits += 1;
    byDayMap.set(r.visit_date, cur);
  }
  for (const f of followups) {
    const cur = byDayMap.get(f.visit_date) ?? { date: f.visit_date, amount: 0, paid: 0, visits: 0 };
    cur.paid = round2(cur.paid + f.paid);
    byDayMap.set(f.visit_date, cur);
  }
  const byDay = [...byDayMap.values()].sort((a, b) => (a.date < b.date ? 1 : -1));

  const qs = (overrides: Record<string, string | null>) => {
    const params = new URLSearchParams();
    params.set("from", from);
    params.set("to", to);
    if (doctorId) params.set("doctor_id", String(doctorId));
    if (serviceId) params.set("service_id", String(serviceId));
    for (const [k, v] of Object.entries(overrides)) {
      if (v == null) params.delete(k);
      else params.set(k, v);
    }
    return params.toString();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-xl font-bold">تقرير الإيرادات</h1>
          {!reportsFull && <p className="text-xs text-muted mt-1">تقريرك الشخصي بس — مش هتشوف أرقام دكاترة تانيين.</p>}
        </div>
        <Link href={`/invoices?date=${to}`} className="text-sm text-primary hover:underline">
          فتح فواتير يوم {to} بالتفصيل
        </Link>
      </div>

      <ReportsFilterForm
        from={from}
        to={to}
        doctorId={reportsFull ? doctorId : null}
        serviceId={serviceId}
        doctors={doctors}
        services={services}
        showDoctorFilter={reportsFull}
      />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-surface border border-border rounded-xl p-4">
          <div className="text-xs text-muted">إجمالي الفواتير الجديدة في الفترة</div>
          <div className="text-2xl font-bold">{newAmount.toFixed(0)} ج.م</div>
        </div>
        <div className="bg-surface border border-border rounded-xl p-4">
          <div className="text-xs text-muted">المحصّل في الفترة</div>
          <div className="text-2xl font-bold text-primary">{collected.toFixed(0)} ج.م</div>
          <div className="text-[10px] text-muted mt-0.5">شامل أي دفعات متابعة اتحصّلت في الفترة دي على فواتير أقدم</div>
        </div>
        <div className="bg-surface border border-border rounded-xl p-4">
          <div className="text-xs text-muted">عدد الزيارات المفوترة</div>
          <div className="text-2xl font-bold">{visitCount}</div>
        </div>
      </div>

      {byMethod.size > 0 && (
        <div className="bg-surface border border-border rounded-xl p-4">
          <div className="text-sm font-semibold mb-2">المحصّل حسب وسيلة الدفع</div>
          <div className="flex flex-wrap gap-4">
            {[...byMethod.entries()].map(([method, amount]) => (
              <div key={method} className="text-sm">
                <span className="text-muted">{paymentMethodLabel(method)}: </span>
                <span className="font-semibold">{amount.toFixed(0)} ج.م</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {byDoctor.length > 0 && (
        <div className="bg-surface border border-border rounded-xl overflow-hidden">
          <div className="px-4 py-2 font-semibold text-sm bg-primary-soft text-primary-dark">حسب الدكتور</div>
          <table className="w-full text-sm">
            <thead className="bg-primary-soft/50 text-muted">
              <tr>
                <th className="text-right px-3 py-2 font-medium">الدكتور</th>
                <th className="text-right px-3 py-2 font-medium">عدد الزيارات</th>
                <th className="text-right px-3 py-2 font-medium">الفواتير الجديدة</th>
                <th className="text-right px-3 py-2 font-medium">المحصّل</th>
              </tr>
            </thead>
            <tbody>
              {byDoctor.map((row) => (
                <tr key={row.key} className="border-t border-border">
                  <td className="px-3 py-2 font-medium">
                    <Link href={`/reports?${qs({ doctor_id: String(row.key) })}`} className="text-primary hover:underline">
                      {row.label}
                    </Link>
                  </td>
                  <td className="px-3 py-2">{row.visits}</td>
                  <td className="px-3 py-2">{row.amount.toFixed(0)}</td>
                  <td className="px-3 py-2 text-primary">{row.paid.toFixed(0)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {byService.length > 0 && (
        <div className="bg-surface border border-border rounded-xl overflow-hidden">
          <div className="px-4 py-2 font-semibold text-sm bg-primary-soft text-primary-dark">حسب الخدمة</div>
          <table className="w-full text-sm">
            <thead className="bg-primary-soft/50 text-muted">
              <tr>
                <th className="text-right px-3 py-2 font-medium">الخدمة</th>
                <th className="text-right px-3 py-2 font-medium">عدد الزيارات</th>
                <th className="text-right px-3 py-2 font-medium">الفواتير الجديدة</th>
                <th className="text-right px-3 py-2 font-medium">المحصّل</th>
              </tr>
            </thead>
            <tbody>
              {byService.map((row) => (
                <tr key={row.key} className="border-t border-border">
                  <td className="px-3 py-2 font-medium">
                    <Link href={`/reports?${qs({ service_id: String(row.key) })}`} className="text-primary hover:underline">
                      {row.label}
                    </Link>
                  </td>
                  <td className="px-3 py-2">{row.visits}</td>
                  <td className="px-3 py-2">{row.amount.toFixed(0)}</td>
                  <td className="px-3 py-2 text-primary">{row.paid.toFixed(0)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="bg-surface border border-border rounded-xl overflow-hidden">
        <div className="px-4 py-2 font-semibold text-sm bg-primary-soft text-primary-dark">تفصيل يومي</div>
        <table className="w-full text-sm">
          <thead className="bg-primary-soft/50 text-muted">
            <tr>
              <th className="text-right px-3 py-2 font-medium">اليوم</th>
              <th className="text-right px-3 py-2 font-medium">عدد الزيارات</th>
              <th className="text-right px-3 py-2 font-medium">الفواتير الجديدة</th>
              <th className="text-right px-3 py-2 font-medium">المحصّل</th>
              <th className="text-right px-3 py-2 font-medium" />
            </tr>
          </thead>
          <tbody>
            {byDay.map((row) => (
              <tr key={row.date} className="border-t border-border">
                <td className="px-3 py-2 whitespace-nowrap">{row.date}</td>
                <td className="px-3 py-2">{row.visits}</td>
                <td className="px-3 py-2">{row.amount.toFixed(0)}</td>
                <td className="px-3 py-2 text-primary">{row.paid.toFixed(0)}</td>
                <td className="px-3 py-2">
                  <Link href={`/invoices?date=${row.date}`} className="text-xs text-primary hover:underline whitespace-nowrap">
                    تفاصيل الفواتير ←
                  </Link>
                </td>
              </tr>
            ))}
            {byDay.length === 0 && (
              <tr>
                <td colSpan={5} className="px-3 py-6 text-center text-muted">
                  لا يوجد بيانات في الفترة المختارة.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
