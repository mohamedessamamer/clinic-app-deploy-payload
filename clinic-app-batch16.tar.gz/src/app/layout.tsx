import type { Metadata } from "next";
import "./globals.css";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import NavBar from "@/components/NavBar";

export const metadata: Metadata = {
  title: "نظام إدارة العيادة",
  description: "نظام إدارة عيادة بسيط وسريع",
};

export default async function RootLayout({ children }: LayoutProps<"/">) {
  const session = await getSession();
  // ظهور لينك "التقارير" مبني على صلاحية فعلية (reports_full/reports_own) مش
  // على الدور الثابت زي باقي اللينكات — عشان الصلاحيتين دول قابلين للمنح/السحب
  // لأي مستخدم لوحده من الإعدادات، مش مرتبطين بدور واحد بس.
  const canViewReports = session
    ? (await hasPermission(session.userId, session.role, "reports_full")) ||
      (await hasPermission(session.userId, session.role, "reports_own"))
    : false;

  return (
    <html lang="ar" dir="rtl" className="h-full antialiased">
      <body className="min-h-full flex flex-col font-sans">
        {session && <NavBar session={session} canViewReports={canViewReports} />}
        <main className="flex-1 w-full max-w-6xl mx-auto px-4 py-6">{children}</main>
      </body>
    </html>
  );
}
