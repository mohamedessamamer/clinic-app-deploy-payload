import { NextRequest, NextResponse } from "next/server";
import { SESSION_COOKIE, isDefaultPasswordDeadlinePassed, verifySessionToken } from "@/lib/auth";
import { getClinicToday } from "@/lib/clinic-date";

// /api/whatsapp/webhook: Meta بتناديه مباشرة من غير أي session cookie (تحقق
// الهوية بتاعه مستقل تمامًا — توقيع X-Hub-Signature-256 + verify token، شوف
// src/app/api/whatsapp/webhook/route.ts) — لازم يفضل متاح من غير ما الـproxy
// يحوّله لصفحة /login.
// Batch 147: أيقونة التاب نفسها (/icon.png) عامة — كانت بتتحوّل لصفحة الدخول
// قبل تسجيل الدخول، فصفحة الدخول كانت من غير أيقونة.
const PUBLIC_PATHS = ["/login", "/icon.png", "/clinic-smile-logo.png", "/premier-whatsapp-logo.png", "/api/whatsapp/webhook", "/appointment/manage", "/review/"];

export async function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl;

  if (PUBLIC_PATHS.some((p) => pathname.startsWith(p)) || pathname.startsWith("/_next")) {
    return NextResponse.next();
  }

  const token = req.cookies.get(SESSION_COOKIE)?.value;
  const session = token ? await verifySessionToken(token) : null;

  if (!session) {
    const loginUrl = new URL("/login", req.url);
    loginUrl.searchParams.set("next", pathname);
    return NextResponse.redirect(loginUrl);
  }

  // بعد DEFAULT_PASSWORD_DEADLINE: أي حساب لسه على كلمة السر الافتراضية
  // مبيوصلش لأي صفحة غير صفحة تغيير كلمة السر (والخروج). قبل التاريخ ده الشرط
  // ده مبيشتغلش خالص، والمستخدم بيشوف الصفحة بعد الدخول ويقدر يتخطاها.
  if (
    session.mustChangePassword &&
    isDefaultPasswordDeadlinePassed(getClinicToday()) &&
    !pathname.startsWith("/change-password") &&
    !pathname.startsWith("/logout")
  ) {
    const changeUrl = new URL("/change-password", req.url);
    changeUrl.searchParams.set("next", pathname);
    return NextResponse.redirect(changeUrl);
  }

  return NextResponse.next();
}

export const config = {
  // مسار الرفع يتحقق من الجلسة والصلاحية بنفسه، واستبعاده هنا مهم لأن Proxy
  // ينسخ جسم الطلب في الذاكرة. الملف يذهب مباشرة وبشكل متدفق إلى القرص.
  matcher: ["/((?!api/public|api/patient-files/upload|api/hr-documents/upload|_next/static|_next/image|favicon.ico).*)"],
};
