// Batch 147: "المتبقي" على كل فاتورة مورد = توزيع كل اللي اتدفع للمورد على
// فواتيره من الأقدم للأحدث (زي كشف حساب أي مورد)، مش "المدفوع المسجّل على
// الفاتورة دي بالذات". السبب: الدفعة المجمّعة (مثلًا 5000 بتغطي كذا فاتورة)
// كانت بتتسجل على فاتورة واحدة، فتطلع الفاتورة دي بالسالب (-3520) والفواتير
// القديمة اللي اتغطت فعلًا تفضل ظاهرة إنها عليها فلوس.
//
// العرض بس: ولا دفعة بتتعدل ولا بتتنقل في قاعدة البيانات، والمصروفات زي ما هي.
// مديونية المورد (إجمالي الفواتير - إجمالي الدفعات) مابتتغيرش بالتوزيع ده.

export type AllocInvoice = { id: number; supplier_id: number; amount: number; invoice_date: string };
export type AllocPayment = { supplier_id: number; amount: number };

const round2 = (value: number) => Math.round(value * 100) / 100;

/** Remaining per invoice id after allocating each supplier's total paid FIFO (oldest invoice first). */
export function allocateSupplierPaymentsFifo(invoices: AllocInvoice[], payments: AllocPayment[]): Map<number, number> {
  const paidBySupplier = new Map<number, number>();
  for (const payment of payments) {
    paidBySupplier.set(payment.supplier_id, round2((paidBySupplier.get(payment.supplier_id) ?? 0) + payment.amount));
  }
  const bySupplier = new Map<number, AllocInvoice[]>();
  for (const invoice of invoices) bySupplier.set(invoice.supplier_id, [...(bySupplier.get(invoice.supplier_id) ?? []), invoice]);

  const remaining = new Map<number, number>();
  for (const [supplierId, list] of bySupplier) {
    let pool = paidBySupplier.get(supplierId) ?? 0;
    const ordered = [...list].sort((a, b) => (a.invoice_date === b.invoice_date ? a.id - b.id : a.invoice_date < b.invoice_date ? -1 : 1));
    for (const invoice of ordered) {
      const applied = Math.min(Math.max(pool, 0), Math.max(invoice.amount, 0));
      pool = round2(pool - applied);
      remaining.set(invoice.id, round2(invoice.amount - applied));
    }
  }
  return remaining;
}

/** Supplier debt = all invoices - all payments (negative = we paid in advance / credit). Unchanged by FIFO. */
export function supplierDebt(invoices: AllocInvoice[], payments: AllocPayment[], supplierId: number): number {
  const invoiced = invoices.filter((invoice) => invoice.supplier_id === supplierId).reduce((sum, invoice) => sum + invoice.amount, 0);
  const paid = payments.filter((payment) => payment.supplier_id === supplierId).reduce((sum, payment) => sum + payment.amount, 0);
  return round2(invoiced - paid);
}
