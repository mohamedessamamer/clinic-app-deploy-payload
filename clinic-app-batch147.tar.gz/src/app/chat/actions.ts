"use server";

import { sql } from "kysely";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";

type ChatMessage = { id: number; body: string; created_at: string; sender_user_id: number; sender_name: string; recipient_user_id: number | null; audience: "reception" | "doctor" | "all_doctors" };

async function cleanExpiredMessages() {
  // مدة الاحتفاظ 48 ساعة حسب طلب المستخدم. التنظيف يحصل مع استعمال الشات؛
  // لا نحتاج خدمة خارجية أو WebSocket لتنفيذه.
  await db.deleteFrom("chat_messages").where(sql<boolean>`created_at <= datetime('now', '-48 hours')`).execute();
}

export async function getStaffChatAction(): Promise<ChatMessage[]> {
  const session = await getSession();
  if (!session) return [];
  await cleanExpiredMessages();
  const query = db
    .selectFrom("chat_messages")
    .innerJoin("users as senders", "senders.id", "chat_messages.sender_user_id")
    .select([
      "chat_messages.id",
      "chat_messages.body",
      "chat_messages.created_at",
      "chat_messages.sender_user_id",
      "senders.full_name as sender_name",
      "chat_messages.recipient_user_id",
      "chat_messages.audience",
    ])
    .orderBy("chat_messages.id", "asc")
    .limit(250);

  if (session.role === "reception" || session.role === "admin" || session.role === "clinic_manager") {
    return query.execute();
  }
  // الطبيب يرى رسائله إلى الاستقبال، رد الاستقبال المباشر له، وأي رسالة لكل الأطباء.
  return query.where((eb) =>
    eb.or([
      eb("chat_messages.sender_user_id", "=", session.userId),
      eb("chat_messages.recipient_user_id", "=", session.userId),
      eb("chat_messages.audience", "=", "all_doctors"),
    ])
  ).execute();
}

export async function getStaffChatUnreadCountAction(): Promise<number> {
  const session = await getSession();
  if (!session) return 0;
  const [messages, state] = await Promise.all([
    getStaffChatAction(),
    db.selectFrom("chat_read_states").select("last_read_message_id").where("user_id", "=", session.userId).executeTakeFirst(),
  ]);
  const lastRead = state?.last_read_message_id ?? 0;
  return messages.filter((message) => message.id > lastRead && message.sender_user_id !== session.userId).length;
}

// Batch 147: التحديث الدوري (كل ثانيتين) كان بينادي getStaffChatAction +
// getStaffChatUnreadCountAction — يعني آخر 250 رسالة كاملة مرتين في كل طلب،
// حتى والشات مقفول. دلوقتي العميل بيبعت آخر id عنده ويرجعله الجديد بس + عدد
// غير المقروء + حدود الرسائل الموجودة (عشان الرسائل اللي انتهت مدتها أو
// اتمسحت تختفي عنده زي الأول بالظبط). نفس فلتر الطبيب/الاستقبال حرفيًا.
export type StaffChatUpdate = {
  messages: ChatMessage[];
  oldestId: number | null;
  newestId: number | null;
  unread: number;
};

export async function getStaffChatUpdatesAction(afterId: number): Promise<StaffChatUpdate> {
  const session = await getSession();
  if (!session) return { messages: [], oldestId: null, newestId: null, unread: 0 };
  await cleanExpiredMessages();
  const since = Number.isInteger(afterId) && afterId > 0 ? afterId : 0;
  const receptionSide = session.role === "reception" || session.role === "admin" || session.role === "clinic_manager";
  let rowsQuery = db
    .selectFrom("chat_messages")
    .innerJoin("users as senders", "senders.id", "chat_messages.sender_user_id")
    .select([
      "chat_messages.id",
      "chat_messages.body",
      "chat_messages.created_at",
      "chat_messages.sender_user_id",
      "senders.full_name as sender_name",
      "chat_messages.recipient_user_id",
      "chat_messages.audience",
    ])
    .where("chat_messages.id", ">", since)
    .orderBy("chat_messages.id", "asc")
    .limit(250);
  let boundsQuery = db
    .selectFrom("chat_messages")
    .innerJoin("users as senders", "senders.id", "chat_messages.sender_user_id")
    .select((eb) => [eb.fn.min("chat_messages.id").as("oldest"), eb.fn.max("chat_messages.id").as("newest")]);
  if (!receptionSide) {
    // الطبيب يرى رسائله إلى الاستقبال، رد الاستقبال المباشر له، وأي رسالة لكل الأطباء.
    rowsQuery = rowsQuery.where((eb) => eb.or([
      eb("chat_messages.sender_user_id", "=", session.userId),
      eb("chat_messages.recipient_user_id", "=", session.userId),
      eb("chat_messages.audience", "=", "all_doctors"),
    ]));
    boundsQuery = boundsQuery.where((eb) => eb.or([
      eb("chat_messages.sender_user_id", "=", session.userId),
      eb("chat_messages.recipient_user_id", "=", session.userId),
      eb("chat_messages.audience", "=", "all_doctors"),
    ]));
  }

  const [messages, bounds, state] = await Promise.all([
    rowsQuery.execute(),
    boundsQuery.executeTakeFirst(),
    db.selectFrom("chat_read_states").select("last_read_message_id").where("user_id", "=", session.userId).executeTakeFirst(),
  ]);
  const lastRead = state?.last_read_message_id ?? 0;

  let unreadQuery = db
    .selectFrom("chat_messages")
    .innerJoin("users as senders", "senders.id", "chat_messages.sender_user_id")
    .select((eb) => eb.fn.countAll<number>().as("n"))
    .where("chat_messages.id", ">", lastRead)
    .where("chat_messages.sender_user_id", "!=", session.userId);
  if (!receptionSide) {
    unreadQuery = unreadQuery.where((eb) =>
      eb.or([
        eb("chat_messages.sender_user_id", "=", session.userId),
        eb("chat_messages.recipient_user_id", "=", session.userId),
        eb("chat_messages.audience", "=", "all_doctors"),
      ])
    );
  }
  const unreadRow = await unreadQuery.executeTakeFirst();

  return {
    messages,
    oldestId: bounds?.oldest == null ? null : Number(bounds.oldest),
    newestId: bounds?.newest == null ? null : Number(bounds.newest),
    unread: Number(unreadRow?.n ?? 0),
  };
}

export async function markStaffChatReadAction() {
  const session = await getSession();
  if (!session) return;
  const messages = await getStaffChatAction();
  const lastMessageId = messages.at(-1)?.id ?? 0;
  await db
    .insertInto("chat_read_states")
    .values({ user_id: session.userId, last_read_message_id: lastMessageId, updated_at: sql<string>`datetime('now')` })
    .onConflict((oc) => oc.column("user_id").doUpdateSet({ last_read_message_id: lastMessageId, updated_at: sql<string>`datetime('now')` }))
    .execute();
}

export async function getChatDoctorsAction() {
  const session = await getSession();
  if (!session) return [];
  const allowed =
    ["reception", "admin", "clinic_manager"].includes(session.role) ||
    (session.role === "doctor" && (await hasPermission(session.userId, session.role, "send_staff_chat_to_doctors")));
  if (!allowed) return [];
  return db
    .selectFrom("users")
    .innerJoin("doctors", "doctors.id", "users.doctor_id")
    .select(["users.id", "users.full_name"])
    .where("users.active", "=", 1)
    .where("doctors.active", "=", 1)
    .orderBy("users.full_name")
    .execute();
}

export async function sendStaffChatAction(formData: FormData): Promise<{ ok: boolean; reason?: string }> {
  const session = await getSession();
  if (!session) return { ok: false, reason: "سجل الدخول أولًا." };
  const body = String(formData.get("body") || "").trim().slice(0, 2000);
  if (!body) return { ok: false, reason: "اكتب رسالة أولًا." };

  const broadcast = formData.get("broadcast") === "1";
  const recipientUserId = Number(formData.get("recipient_user_id")) || null;
  let audience: "reception" | "doctor" | "all_doctors" = "reception";
  let recipient_user_id: number | null = null;

  if (session.role === "doctor") {
    const canTargetDoctors = await hasPermission(session.userId, session.role, "send_staff_chat_to_doctors");
    // الرسالة الافتراضية للطبيب تذهب للاستقبال. الصلاحية الفردية فقط هي التي
    // تفتح له اختيار طبيب محدد أو إعلانًا لكل الأطباء.
    if (!canTargetDoctors || (!broadcast && !recipientUserId)) {
      audience = "reception";
    } else if (broadcast) {
      audience = "all_doctors";
    } else {
      const recipient = await db.selectFrom("users").select(["id", "role", "active"]).where("id", "=", recipientUserId).executeTakeFirst();
      if (!recipient || !recipient.active || recipient.role !== "doctor") return { ok: false, reason: "اختر طبيبًا نشطًا." };
      audience = "doctor";
      recipient_user_id = recipient.id;
    }
  } else if (broadcast) {
    audience = "all_doctors";
  } else if (recipientUserId) {
    const recipient = await db.selectFrom("users").select(["id", "role", "active"]).where("id", "=", recipientUserId).executeTakeFirst();
    if (!recipient || !recipient.active || recipient.role !== "doctor") return { ok: false, reason: "اختر طبيبًا نشطًا." };
    audience = "doctor";
    recipient_user_id = recipient.id;
  } else {
    return { ok: false, reason: "اختر طبيبًا أو أرسل الرسالة لكل الأطباء." };
  }

  await cleanExpiredMessages();
  await db.insertInto("chat_messages").values({ sender_user_id: session.userId, recipient_user_id, audience, body }).execute();
  return { ok: true };
}
