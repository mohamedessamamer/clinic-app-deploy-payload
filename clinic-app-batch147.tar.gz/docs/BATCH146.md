# دفعة 146 — ترقية أمنية للمكتبات (بدون أي تغيير في الكود أو قاعدة البيانات)

## الملخص
ترقية 4 مكتبات لقفل ثغرات معلنة. **مفيش ولا سطر اتغيّر في `src/`** ولا أي
migration — الملفات المتغيرة: `package.json` و `package-lock.json` و الملف ده بس.

| المكتبة | قبل | بعد | السبب |
|---|---|---|---|
| next | 16.3.4 | 16.4.3 | DoS في App Router عبر Server Actions (GHSA-p3m5-59mp-jv5r)، RCE في `next/og` (GHSA-vcvr-r3jv-pc5j)، RCE في Image Optimization عبر SVG (CVE-2026-96889)، وثغرات cache/SSRF من إصدار سبتمبر |
| eslint-config-next | 16.3.4 | 16.4.3 | لازم يطابق next |
| react / react-dom | 19.2.8 | 19.2.9 | إصدار 14 أكتوبر الأمني المصاحب لـ next 16.4.1 |
| sharp | ^0.34.4 (0.34.5) | 0.35.5 | ثغرات libvips (CVE-2026-33327/33328/35590/35591)، libheif، librsvg |

كل الإصدارات مثبتة بالظبط (من غير `^`) عشان أي `npm ci` يطلع نفس النتيجة.

## السياق: الترقية دي متطبقة على السيرفر بالفعل
اتطبقت يدويًا على السيرفر يوم 2026-10-29 الساعة 09:36 بتوقيت القاهرة (سكريبت
`clinic-upgrade-next.sh`، بنفس أسلوب النشر: بناء جانبي + اختبارات + رجوع تلقائي).
الدفعة دي بتخلّي الكود الرسمي يطابق اللي شغال، عشان أي دفعة جاية تتبني فوق
`package.json` الجديد ومترجعش الإصدارات القديمة بالثغرات.

**أي دفعة جاية (147+) لازم تتبني فوق `package.json` و `package-lock.json` بتوع
الدفعة دي**، وسكريبت النشر بتاعها لازم يفحص `"next": "16.4.3"` (مش 16.3.4).

## التحقق اللي اتعمل
- `npm run test:security` ✓ و `npm run typecheck` ✓ و `scripts/check-use-server.mjs` ✓
- `next build --webpack` ✓
- تشغيل فعلي: `/login` = 200، `/patients` = 307، webhook من غير توقيع = 403،
  Server Action مزيف = 400.
- **معالجة الصور (sharp 0.35)**: `analyzeImage` و `extractFeatures` و
  `guessAndBakeOrientation` و `bakeRotation` و `cropFaceThumbnail` اتشغلوا على نفس
  مجموعة صور (وش، أسنان، أشعة، EXIF orientation 6، PNG، صورة عشوائية) بـ
  0.34.5 وبـ 0.35.5 — **صفر فرق** في النوع والثقة والأبعاد والاتجاه.
  `sharp.strategy.attention` لسه موجودة (فحص batch 130 بيعدّي).
- `npm audit --omit=dev`: صفر critical. فاضل high في `brace-expansion` و
  `source-map-js` — أدوات بناء/lint بس (eslint, tailwind, archiver داخل exceljs)
  ومش بتستقبل أي مدخلات من المستخدمين.

## ملاحظة تشغيلية (مهمة لكل نشر)
بعد أي نشر، أي تبويب كان مفتوح على النسخة القديمة بيفشل في أي حفظ/إرسال
(`Failed to find Server Action ... older or newer deployment`) لحد ما يتعمله
Refresh. ده حصل فعلًا 09:40–09:41 يوم الترقية. **النشر يكون والعيادة قافلة،
وبعده كل الأجهزة تعمل F5.**

## سكريبت النشر (deploy146.sh)
- بيقبل السيرفر لو مصدره مطابق لدفعة 145 المنشورة (بغض النظر عن `package.json`،
  عشان يقبل السيرفر سواء اتعملت عليه الترقية اليدوية أو لأ).
- بيفحص الإصدارات في `package.json` و `package-lock.json` قبل الإيقاف، وفي
  `node_modules` بعد `npm ci`.
- بعد النجاح بيشغّل `/opt/clinic-maintenance/clinic-maintenance.sh` لو موجود
  (بيسيب آخر نسختين من الإصدارات ونسخ الداتا) — عشان الديسك ميتملاش تاني.
