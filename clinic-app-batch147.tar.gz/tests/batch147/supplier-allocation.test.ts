import { test } from "node:test";
import assert from "node:assert/strict";
import { allocateSupplierPaymentsFifo, supplierDebt } from "../../src/lib/supplier-allocation.ts";

// Real data of supplier "الإيمان" on 2026-10-29 (id, number, date, amount, paid-as-recorded).
const S = 7;
const invoices = [
  { id: 3, supplier_id: S, invoice_date: "2026-09-14", amount: 5685 },
  { id: 4, supplier_id: S, invoice_date: "2026-09-19", amount: 975 },
  { id: 12, supplier_id: S, invoice_date: "2026-09-26", amount: 2400 },
  { id: 13, supplier_id: S, invoice_date: "2026-09-26", amount: 525 },
  { id: 14, supplier_id: S, invoice_date: "2026-09-26", amount: 595 },
  { id: 7, supplier_id: S, invoice_date: "2026-10-04", amount: 775 },
  { id: 17, supplier_id: S, invoice_date: "2026-10-06", amount: 580 },
  { id: 15, supplier_id: S, invoice_date: "2026-10-13", amount: 2785 },
  { id: 16, supplier_id: S, invoice_date: "2026-10-18", amount: 1480 },
];
const payments = [3700, 2000, 4000, 5000].map((amount) => ({ supplier_id: S, amount }));

test("al-iman: everything settled except the newest invoice (1100), no negatives", () => {
  const r = allocateSupplierPaymentsFifo(invoices, payments);
  assert.deepEqual([...invoices].map((i) => r.get(i.id)), [0, 0, 0, 0, 0, 0, 0, 0, 1100]);
  for (const v of r.values()) assert.ok(v >= 0);
});

test("supplier debt is unchanged by the allocation (15800 - 14700 = 1100)", () => {
  assert.equal(supplierDebt(invoices, payments, S), 1100);
  const r = allocateSupplierPaymentsFifo(invoices, payments);
  assert.equal([...r.values()].reduce((a, b) => a + b, 0), 1100);
});

test("overpaid supplier: all invoices 0, debt negative (credit)", () => {
  const inv = [{ id: 1, supplier_id: 1, invoice_date: "2026-01-01", amount: 100 }];
  const r = allocateSupplierPaymentsFifo(inv, [{ supplier_id: 1, amount: 150 }]);
  assert.equal(r.get(1), 0);
  assert.equal(supplierDebt(inv, [{ supplier_id: 1, amount: 150 }], 1), -50);
});

test("suppliers do not share payments; same-date invoices go by id", () => {
  const inv = [
    { id: 9, supplier_id: 1, invoice_date: "2026-01-01", amount: 100 },
    { id: 8, supplier_id: 1, invoice_date: "2026-01-01", amount: 100 },
    { id: 5, supplier_id: 2, invoice_date: "2026-01-01", amount: 100 },
  ];
  const r = allocateSupplierPaymentsFifo(inv, [{ supplier_id: 1, amount: 120 }]);
  assert.equal(r.get(8), 0);
  assert.equal(r.get(9), 80);
  assert.equal(r.get(5), 100);
});

test("unpaid supplier keeps full amounts; fractions rounded to 0.01", () => {
  const inv = [{ id: 1, supplier_id: 3, invoice_date: "2026-01-01", amount: 10.1 }, { id: 2, supplier_id: 3, invoice_date: "2026-01-02", amount: 20.2 }];
  const r = allocateSupplierPaymentsFifo(inv, [{ supplier_id: 3, amount: 10.3 }]);
  assert.equal(r.get(1), 0);
  assert.equal(r.get(2), 20);
});
