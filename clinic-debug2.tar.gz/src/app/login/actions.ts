"use server";

import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { db } from "@/lib/db/client";
import { SESSION_COOKIE, createSessionToken, verifyPassword } from "@/lib/auth";

export async function loginAction(formData: FormData) {
  const username = String(formData.get("username") || "").trim();
  const password = String(formData.get("password") || "");
  const next = String(formData.get("next") || "/");

  if (!username || !password) {
    redirect(`/login?error=missing&next=${encodeURIComponent(next)}`);
  }

  const user = await db
    .selectFrom("users")
    .selectAll()
    .where("username", "=", username)
    .where("active", "=", 1)
    .executeTakeFirst();

  if (!user || !(await verifyPassword(password, user.password_hash))) {
    redirect(`/login?error=invalid&next=${encodeURIComponent(next)}`);
  }

  const token = await createSessionToken({
    userId: user.id,
    username: user.username,
    fullName: user.full_name,
    role: user.role,
    doctorId: user.doctor_id,
  });

  // Only mark the cookie Secure when the request actually arrived over HTTPS.
  // Browsers silently refuse to store Secure cookies on a plain-HTTP connection,
  // which (before this fix) caused every post-login request to look logged-out.
  const hdrs = await headers();
  const isHttps = hdrs.get("x-forwarded-proto") === "https";

  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: isHttps,
    path: "/",
    maxAge: 60 * 60 * 12,
  });

  console.log(
    `[login] set cookie for user=${username} | isHttps=${isHttps} | x-forwarded-proto=${hdrs.get("x-forwarded-proto")} | next-action=${hdrs.get("next-action")} | accept=${hdrs.get("accept")} | origin=${hdrs.get("origin")} | host=${hdrs.get("host")} | readBack=${store.get(SESSION_COOKIE)?.value ? "present" : "MISSING"} | redirectTo=${next && next.startsWith("/") ? next : "/"}`
  );

  redirect(next && next.startsWith("/") ? next : "/");
}
