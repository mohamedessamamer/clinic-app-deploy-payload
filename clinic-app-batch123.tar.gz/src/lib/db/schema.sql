-- Clinic Management System — SQLite schema (dev). Portable design, will map to Postgres for production.

CREATE TABLE IF NOT EXISTS doctors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- دفعة 22: ربط دكتور استشاري بدكاترة مساعدين (many-to-many) — استشاري واحد
-- ممكن يكون عنده أكتر من مساعد. doctors.is_consultant بيتضاف عن طريق
-- tryAddColumn في client.ts (عمود جديد على جدول موجود، مش هنا).
CREATE TABLE IF NOT EXISTS consultant_assistants (
  consultant_doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  assistant_doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  PRIMARY KEY (consultant_doctor_id, assistant_doctor_id)
);

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin','doctor','reception','accountant')),
  doctor_id INTEGER REFERENCES doctors(id),
  active INTEGER NOT NULL DEFAULT 1,
  medical_ui_language TEXT NOT NULL DEFAULT 'en' CHECK (medical_ui_language IN ('en', 'ar')),
  color_theme TEXT NOT NULL DEFAULT 'revere' CHECK (color_theme IN ('revere', 'medical')),
  contact_name TEXT,
  -- 1 = الحساب لسه على كلمة السر الافتراضية "123". بيتصفّر لوحده أول دخول
  -- بكلمة سر مختلفة، وبيترجع 1 مع أي تصفير من الأدمن.
  must_change_password INTEGER NOT NULL DEFAULT 1,
  session_version INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS rooms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- A shift assigns a doctor to a room for a time window on a given date.
-- Superseded by doctor_weekly_shifts below for the recurring weekly schedule (kept as-is,
-- unused by the UI now, so we don't touch any historical data in it).
CREATE TABLE IF NOT EXISTS shifts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL REFERENCES rooms(id),
  doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  shift_date TEXT NOT NULL,       -- YYYY-MM-DD
  start_time TEXT NOT NULL,       -- HH:MM
  end_time TEXT NOT NULL,         -- HH:MM
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Recurring weekly schedule: which doctor is in which room on which weekday.
-- weekday: 0=Sunday .. 6=Saturday (matches WEEKDAY_LABELS in lib/settings.ts).
CREATE TABLE IF NOT EXISTS doctor_weekly_shifts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL REFERENCES rooms(id),
  weekday INTEGER NOT NULL,
  doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  start_time TEXT NOT NULL,       -- HH:MM
  end_time TEXT NOT NULL,         -- HH:MM
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- شفت استثنائي — دفعة 27: تسهيل ليوم بعينه (مش شيفت متكرر جديد في
-- doctor_weekly_shifts فوق) لما دكتور ييجي في يوم مش يومه الأصلي. إضافي مش
-- بديل — مايمسحش/يلغيش doctor_weekly_shifts، بس بياخد أولوية عليه في تحديد
-- "صاحب الشيفت المقترح افتراضيًا" لحجوزات الغرفة/اليوم ده (شوف
-- roomShiftDoctorIds في front-desk/page.tsx و app/page.tsx) — قابل للتغيير
-- يدويًا لكل حجز على حدة برضه، مش قيد. UNIQUE(room_id, shift_date): شفت
-- استثنائي واحد بس لكل غرفة/يوم — تعيين واحد جديد بيستبدل القديم مش يضيفله.
CREATE TABLE IF NOT EXISTS doctor_date_shifts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL REFERENCES rooms(id),
  doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  shift_date TEXT NOT NULL,       -- YYYY-MM-DD
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(room_id, shift_date)
);

CREATE TABLE IF NOT EXISTS services (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  name_en TEXT,
  category TEXT,
  default_price REAL NOT NULL DEFAULT 0,
  code TEXT,
  price_note TEXT,
  prepaid INTEGER NOT NULL DEFAULT 0,
  has_lab_cost INTEGER NOT NULL DEFAULT 0,
  lab_cost REAL NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Which doctors are allowed to perform which service (drives the filtered doctor dropdown).
CREATE TABLE IF NOT EXISTS service_doctors (
  service_id INTEGER NOT NULL REFERENCES services(id),
  doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  PRIMARY KEY (service_id, doctor_id)
);

CREATE TABLE IF NOT EXISTS patients (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  file_number TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  age INTEGER, -- قديم/legacy — لمرضى اتسجلوا قبل ما يبقى عندنا تاريخ ميلاد. السن
               -- الجديد بيتحسب من birth_date تحت، شوف src/lib/age.ts.
  birth_date TEXT, -- تاريخ الميلاد (YYYY-MM-DD) — السن بيتحسب منه بالسنين بس.
  phone_country_code TEXT NOT NULL DEFAULT '+20',
  phone TEXT,
  address TEXT,
  -- الأرشفة لا تحذف المريض ولا تمنع علاجه؛ هي فقط توقف التواصل الاستباقي
  -- وتفصله عن القائمة اليومية حتى يعود للحجز/الزيارة.
  archived_at TEXT,
  archived_by INTEGER REFERENCES users(id),
  archive_reason TEXT CHECK (archive_reason IN ('manual','inactive')),
  archive_activity_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Appointments: future bookings, tied primarily to a room (per clinic's shift model).
-- status: booked (محجوز) -> attended (حضر ووصل العيادة) -> done (الكشف خلص).
-- cancelled (ملغي) is used to free the slot in the central schedule grid without hard-deleting
-- the row (keeps history), no_show kept for the rare case reception marks a booked patient absent.
-- duration_minutes: how many minutes the appointment occupies in the central grid (spans multiple
-- time-slot rows for long appointments); NULL/0 means "one slot" using the clinic's slot_minutes setting.
CREATE TABLE IF NOT EXISTS appointments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER REFERENCES patients(id),
  room_id INTEGER NOT NULL REFERENCES rooms(id),
  doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  appointment_date TEXT NOT NULL,  -- YYYY-MM-DD
  start_time TEXT NOT NULL,        -- HH:MM
  duration_minutes INTEGER,
  status TEXT NOT NULL DEFAULT 'booked' CHECK (status IN ('booked','attended','done','cancelled','no_show')),
  -- وقت تسجيل الوصول الفعلي؛ يستخدم لترتيب قائمة الانتظار داخل كل عيادة.
  attended_at TEXT,
  -- بداية انتظار الاستقبال بعد تثبيت الحضور؛ منفصلة عن وقت دخول العيادة.
  reception_wait_started_at TEXT,
  -- العيادة التي دخلها المريض فعليًا؛ قد تختلف عن عيادة الحجز، ولا تغيّر الحجز نفسه.
  entered_room_id INTEGER REFERENCES rooms(id),
  entered_at TEXT,
  -- Batch 123: خروج من العيادة لخانة الاستقبال بانتظار «تم»، وتثبيت الزيارة بعد 3 دقائق داخل العيادة.
  left_clinic_at TEXT,
  clinic_confirmed_at TEXT,
  -- وقت اعتماد الموعد سواء من المريض أو الاستقبال؛ منفصل عن حالة سير الزيارة.
  confirmed_at TEXT,
  -- حجز المريض للنقلة بنفسه يظل مؤكداً على الخانة الجديدة لكنه ينتظر اعتماد الاستقبال.
  reschedule_pending INTEGER NOT NULL DEFAULT 0,
  notes TEXT,
  -- pending_*: لو الموعد اتسجل "تم" من حد معهوش صلاحية تحصيل المدفوعات (زي الدكتور)،
  -- بيقدر يحدد هنا الخدمة والسعر المتوقع "المطلوب دفعه" من غير ما يسجل دفع فعلي —
  -- الاستقبال بيشوفها على طول جنب "محتاج تحصيل" في الجدول، وبتتملى تلقائي في بوكس
  -- التحصيل بتاعه لما يفتحه بأثر رجعي. بتتصفّر لما التحصيل الفعلي يتسجل.
  pending_service_id INTEGER REFERENCES services(id),
  pending_price REAL,
  pending_discount_percent REAL,
  completed_without_payment INTEGER NOT NULL DEFAULT 0,
  debt_on_completion REAL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- تحويل طبي داخلي. لا ينشئ موعداً أو يضيف المريض لقائمة الانتظار؛ هو مهمة
-- مرتبطة بالملف الطبي وإشعار للطبيب المُحال إليه حتى يغلقها.
CREATE TABLE IF NOT EXISTS patient_referrals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  appointment_id INTEGER REFERENCES appointments(id) ON DELETE SET NULL,
  from_doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  to_doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  request_text TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','completed')),
  created_by INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  completed_by INTEGER REFERENCES users(id),
  completed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_patient_referrals_patient ON patient_referrals(patient_id, status, created_at);
CREATE INDEX IF NOT EXISTS idx_patient_referrals_target ON patient_referrals(to_doctor_id, status, created_at);

-- Batch 111: actionable requests are separate from transient notifications.
CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER REFERENCES patients(id) ON DELETE CASCADE,
  created_by INTEGER NOT NULL REFERENCES users(id),
  recipient_type TEXT NOT NULL CHECK (recipient_type IN ('user','reception')),
  recipient_user_id INTEGER REFERENCES users(id),
  task_text TEXT NOT NULL,
  source_type TEXT NOT NULL DEFAULT 'manual' CHECK (source_type IN ('manual','referral')),
  referral_id INTEGER UNIQUE REFERENCES patient_referrals(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','completed','closed')),
  completed_by INTEGER REFERENCES users(id),
  completed_at TEXT,
  closed_by INTEGER REFERENCES users(id),
  closed_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  CHECK ((recipient_type = 'reception' AND recipient_user_id IS NULL) OR (recipient_type = 'user' AND recipient_user_id IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS idx_tasks_recipient ON tasks(recipient_type, recipient_user_id, status, created_at);
CREATE INDEX IF NOT EXISTS idx_tasks_creator ON tasks(created_by, status, created_at);

-- رابط آمن مستقل لكل موعد. لا يُحفظ التوكن نفسه، بل SHA-256 فقط. يحتفظ هذا
-- السجل بحالة الرد والتعديل حتى يظهر تقرير الاستقبال الحي.
CREATE TABLE IF NOT EXISTS appointment_reminders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  appointment_id INTEGER NOT NULL REFERENCES appointments(id) ON DELETE CASCADE,
  patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  delivery_method TEXT NOT NULL DEFAULT 'automatic' CHECK (delivery_method IN ('automatic','manual')),
  appointment_date TEXT NOT NULL,
  sent_at TEXT,
  expires_at TEXT NOT NULL,
  response_status TEXT NOT NULL DEFAULT 'pending' CHECK (response_status IN ('pending','confirmed','reschedule_pending','reschedule_approved','send_failed')),
  responded_at TEXT,
  requested_date TEXT,
  requested_time TEXT,
  requested_room_id INTEGER REFERENCES rooms(id),
  approved_by INTEGER REFERENCES users(id),
  approved_at TEXT,
  send_attempts INTEGER NOT NULL DEFAULT 0,
  last_attempt_at TEXT,
  error_message TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(appointment_id, appointment_date)
);
CREATE INDEX IF NOT EXISTS idx_appointment_reminders_report ON appointment_reminders(appointment_date, response_status);

-- Visits: the row-per-visit history table shown on the patient file.
-- primary_doctor_id = who revenue is attributed to; performing_doctor_id = who actually did it (may differ).
-- appointment_id: لو الزيارة دي اتسجلت من زر "تم" في الجدول المركزي، بيربطها
-- بالموعد الأصلي (مرجع/تتبع بس، مفيش أي منطق بيعتمد عليه غير كده).
CREATE TABLE IF NOT EXISTS visits (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  visit_date TEXT NOT NULL DEFAULT (date('now')),
  service_id INTEGER REFERENCES services(id),
  notes TEXT,
  primary_doctor_id INTEGER REFERENCES doctors(id),
  performing_doctor_id INTEGER REFERENCES doctors(id),
  room_id INTEGER REFERENCES rooms(id),
  created_by INTEGER REFERENCES users(id),
  appointment_id INTEGER REFERENCES appointments(id),
  -- يحفظ رابط زيارة شارت التقويم بسطرها الطبي المزامن، حتى لا تستبدل زيارة
  -- تقويم جديدة زيارة أقدم لها نفس التاريخ.
  ortho_visit_id INTEGER UNIQUE,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- payment_method: طريقة تحصيل المبلغ المدفوع في الفاتورة دي (نقدي/فيزا/انستاباي)، بتتسجل
-- وقت التحصيل من بوكس الفوترة.
-- parent_invoice_id: لو الفاتورة دي "دفعة متابعة" (خدمة كودها 0)، بتشاور على الفاتورة
-- الأصلية اللي المبلغ ده بيتخصم من رصيدها — مبلغ (amount) الفاتورة دي بيفضل صفر (مفيش
-- استحقاق مستقل جديد)، وبس paid بيتسجل فيه المبلغ المحصّل في الدفعة دي، عشان يظهر صح
-- في تقرير تحصيل اليوم من غير ما يتحسب مرتين مع الفاتورة الأصلية.
-- original_price: السعر الأصلي المدخل قبل تطبيق نسبة الخصم (amount = original_price بعد
-- الخصم). بيتسجل وقت إنشاء الفاتورة عشان يظهر في تقارير الفواتير جنب المبلغ النهائي؛
-- NULL لفواتير دفعات المتابعة (amount بتاعتها صفر أصلاً، مفيش "سعر أصلي" منطقي ليها).
CREATE TABLE IF NOT EXISTS invoices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  -- الفاتورة سجل مالي مستقل. ربطها بزيارة طبية اختياري فقط للسجلات القديمة
  -- أو في الحالات التي نريد فيها الربط كمرجع؛ لا يصح أن يكون شرطاً للتحصيل.
  visit_id INTEGER REFERENCES visits(id),
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  doctor_id INTEGER REFERENCES doctors(id),
  appointment_id INTEGER REFERENCES appointments(id),
  service_id INTEGER REFERENCES services(id),
  invoice_date TEXT NOT NULL DEFAULT (date('now')),
  amount REAL NOT NULL DEFAULT 0,
  paid REAL NOT NULL DEFAULT 0,
  discount_percent REAL NOT NULL DEFAULT 0,
  price_overridden INTEGER NOT NULL DEFAULT 0,
  payment_method TEXT,
  parent_invoice_id INTEGER REFERENCES invoices(id),
  original_price REAL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- سجل المصروفات المركزي: الإدخال اليدوي، المرتبات المتكررة، وتوريدات المخزن
-- كلها تنتهي هنا. source_type/source_id يمنعان تسجيل توريد واحد مرتين عندما
-- تتوسع عمليات الشراء والمخازن لاحقاً.
CREATE TABLE IF NOT EXISTS expense_templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  payee TEXT,
  default_amount REAL NOT NULL CHECK (default_amount > 0),
  note TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  effective_from TEXT,
  effective_to TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  expense_date TEXT NOT NULL,
  category TEXT NOT NULL,
  title TEXT NOT NULL,
  payee TEXT,
  amount REAL NOT NULL CHECK (amount > 0),
  payment_method TEXT,
  note TEXT,
  source_type TEXT NOT NULL DEFAULT 'manual',
  source_id INTEGER,
  template_id INTEGER REFERENCES expense_templates(id),
  doctor_id INTEGER REFERENCES doctors(id),
  patient_id INTEGER REFERENCES patients(id),
  service_id INTEGER REFERENCES services(id),
  affects_commission INTEGER NOT NULL DEFAULT 0,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(source_type, source_id)
);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(expense_date);
CREATE INDEX IF NOT EXISTS idx_expenses_category_date ON expenses(category, expense_date);

-- قاعدة استحقاق الطبيب الحالية. تفاصيل كل شهر تُنسخ داخل payroll run عند
-- توليده، لذلك تغيير النسبة لاحقاً لا يعيد كتابة كشوف الأشهر السابقة.
CREATE TABLE IF NOT EXISTS doctor_compensation_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  doctor_id INTEGER NOT NULL UNIQUE REFERENCES doctors(id),
  compensation_type TEXT NOT NULL CHECK (compensation_type IN ('fixed','percentage','mixed')),
  fixed_amount REAL NOT NULL DEFAULT 0 CHECK (fixed_amount >= 0),
  percentage REAL NOT NULL DEFAULT 0 CHECK (percentage >= 0 AND percentage <= 100),
  effective_from TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  created_by INTEGER REFERENCES users(id),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- كشف الطبيب الشهري: لقطة مستقلة من التحصيل والقواعد وقت الحساب. لا يصبح
-- مصروفاً إلا عند الاعتماد والصرف، ثم يتصل بسطر expenses واحد فقط.
CREATE TABLE IF NOT EXISTS doctor_payroll_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  period_month TEXT NOT NULL,
  fixed_amount REAL NOT NULL DEFAULT 0,
  percentage REAL NOT NULL DEFAULT 0,
  collected_amount REAL NOT NULL DEFAULT 0,
  percentage_amount REAL NOT NULL DEFAULT 0,
  total_amount REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','paid')),
  paid_date TEXT,
  expense_id INTEGER UNIQUE REFERENCES expenses(id),
  created_by INTEGER REFERENCES users(id),
  paid_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(doctor_id, period_month)
);
CREATE INDEX IF NOT EXISTS idx_doctor_payroll_period ON doctor_payroll_runs(period_month, doctor_id);

-- قواعد HR موحدة للأطباء والموظفين والتمريض. القاعدة الحالية فقط هي النشطة؛
-- كشف الفترة يحتفظ بلقطة الحساب حتى لا تتغير الشهور السابقة عند تعديل القاعدة.
CREATE TABLE IF NOT EXISTS hr_staff (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name TEXT NOT NULL,
  staff_group TEXT NOT NULL CHECK (staff_group IN ('employee','nursing')),
  linked_user_id INTEGER UNIQUE REFERENCES users(id),
  employment_start TEXT NOT NULL,
  employment_end TEXT,
  notes TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS hr_compensation_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  person_type TEXT NOT NULL CHECK (person_type IN ('doctor','staff')),
  person_id INTEGER NOT NULL,
  staff_group TEXT NOT NULL CHECK (staff_group IN ('doctor','employee','nursing')),
  compensation_type TEXT NOT NULL CHECK (compensation_type IN ('fixed','percentage','mixed')),
  fixed_basis TEXT NOT NULL DEFAULT 'monthly' CHECK (fixed_basis IN ('monthly','shift')),
  fixed_amount REAL NOT NULL DEFAULT 0 CHECK (fixed_amount >= 0),
  percentage_basis TEXT NOT NULL DEFAULT 'personal' CHECK (percentage_basis IN ('personal','clinic')),
  percentage_mode TEXT NOT NULL DEFAULT 'fixed' CHECK (percentage_mode IN ('fixed','progressive')),
  percentage REAL NOT NULL DEFAULT 0 CHECK (percentage >= 0 AND percentage <= 100),
  effective_from TEXT NOT NULL,
  effective_to TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_by INTEGER REFERENCES users(id),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(person_type, person_id)
);

CREATE TABLE IF NOT EXISTS hr_payroll_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  person_type TEXT NOT NULL CHECK (person_type IN ('doctor','staff')),
  person_id INTEGER NOT NULL,
  person_name TEXT NOT NULL,
  staff_group TEXT NOT NULL CHECK (staff_group IN ('doctor','employee','nursing')),
  period_from TEXT NOT NULL,
  period_to TEXT NOT NULL,
  shift_count REAL NOT NULL DEFAULT 0,
  fixed_amount REAL NOT NULL DEFAULT 0,
  percentage_basis TEXT NOT NULL,
  percentage_mode TEXT NOT NULL,
  percentage REAL NOT NULL DEFAULT 0,
  gross_collected REAL NOT NULL DEFAULT 0,
  lab_cost REAL NOT NULL DEFAULT 0,
  net_collected REAL NOT NULL DEFAULT 0,
  percentage_amount REAL NOT NULL DEFAULT 0,
  incentives REAL NOT NULL DEFAULT 0,
  deductions REAL NOT NULL DEFAULT 0,
  total_amount REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','paid')),
  paid_date TEXT,
  expense_id INTEGER UNIQUE REFERENCES expenses(id),
  created_by INTEGER REFERENCES users(id),
  paid_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(person_type, person_id, period_from, period_to)
);
CREATE INDEX IF NOT EXISTS idx_hr_payroll_period ON hr_payroll_runs(period_from, period_to, person_type, person_id);

CREATE TABLE IF NOT EXISTS hr_documents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  person_type TEXT NOT NULL CHECK (person_type IN ('doctor','staff')),
  person_id INTEGER NOT NULL,
  document_type TEXT NOT NULL,
  label TEXT,
  file_path TEXT NOT NULL,
  original_name TEXT NOT NULL,
  uploaded_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_hr_documents_person ON hr_documents(person_type, person_id, created_at);

-- طلب داخلي من الطبيب/المساعد إلى الاستقبال. لا ينشئ زيارة أو فاتورة أو دفعة.
CREATE TABLE IF NOT EXISTS collection_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  appointment_id INTEGER NOT NULL UNIQUE REFERENCES appointments(id),
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  service_id INTEGER REFERENCES services(id),
  requested_amount REAL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','settled','cancelled')),
  requested_by INTEGER NOT NULL REFERENCES users(id),
  requested_at TEXT NOT NULL DEFAULT (datetime('now')),
  settled_by INTEGER REFERENCES users(id),
  settled_at TEXT,
  cancelled_by INTEGER REFERENCES users(id),
  cancelled_at TEXT
);

-- دفعة مقدمة حقيقية استلمها الاستقبال قبل تحديد الخدمة أو قبل انتهاء الزيارة.
-- available_amount هو الرصيد الذي لم يُخصم بعد من فاتورة.
CREATE TABLE IF NOT EXISTS patient_credits (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  appointment_id INTEGER REFERENCES appointments(id),
  original_amount REAL NOT NULL CHECK (original_amount > 0),
  available_amount REAL NOT NULL CHECK (available_amount >= 0),
  payment_method TEXT,
  received_by INTEGER NOT NULL REFERENCES users(id),
  received_at TEXT NOT NULL DEFAULT (datetime('now')),
  note TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','used','refunded'))
);

-- Patient image/x-ray gallery — grouped batches, each with a date. File storage path is a placeholder
-- for now (local disk in dev); production will point at object storage (e.g. Cloudflare R2) per the plan.
CREATE TABLE IF NOT EXISTS patient_image_groups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  label TEXT,
  taken_at TEXT NOT NULL DEFAULT (date('now')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS patient_images (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  group_id INTEGER NOT NULL REFERENCES patient_image_groups(id),
  file_path TEXT NOT NULL,
  rotation INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS inventory_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  quantity REAL NOT NULL DEFAULT 0,
  unit TEXT,
  expiry_date TEXT,
  low_stock_threshold REAL NOT NULL DEFAULT 0,
  product_id INTEGER REFERENCES inventory_products(id),
  supplier_id INTEGER REFERENCES inventory_suppliers(id),
  attribute_value_ids TEXT,
  item_code TEXT,
  -- الاستخدام داخل شارت التقويم. قيمة الصنف الفعلي (وليس اسمًا حرًا) هي
  -- التي تحدد ما يظهر في حقول الشارت وما يُخصم منه.
  ortho_usage TEXT,
  reorder_quantity REAL NOT NULL DEFAULT 0,
  critical_stock_threshold REAL NOT NULL DEFAULT 0,
  -- الخامة العلاجية هي ما يختاره الطبيب ويُجرَد كوحدة واحدة. الشركة والمورد
  -- والسعر تحفظ في inventory_supply_batches تحت هذه الخامة، فلا يضطر الطبيب
  -- لاختيار American/Ormco وهو يختار Wire 0.012 مثلاً.
  specialty_id INTEGER REFERENCES inventory_specialties(id),
  category_id INTEGER REFERENCES inventory_categories(id),
  -- مجموعة عرض داخل الفئة فقط، مثل NiTi / St.St داخل WIRES. لا تغير وحدة
  -- الجرد ولا طريقة الخصم، لكنها تجعل التصفح والجرد مفهومين للموظف.
  catalog_group TEXT,
  -- مفتاح ثابت للاستهلاك التلقائي الذي لا يختاره الطبيب من قائمة الشارت،
  -- مثل كومبوزيت التقويم الذي يخصم بالملليجرام مع كل تركيب أو rebonding.
  auto_deduction_key TEXT,
  -- كمية الاستهلاك التلقائي لكل سن/وحدة ربط. إعداد للصنف نفسه، لا رقم ثابت
  -- في الشارت، حتى يمكن تعديل جرعة الـ Adhesive من المخزن لاحقًا.
  auto_deduction_per_attachment REAL NOT NULL DEFAULT 0,
  -- الإيقاف هنا لا يمسح الرصيد؛ فقط يخفي الصنف من اختيارات الاستخدام الطبي
  -- حتى لا يختاره الطبيب بينما هو غير متوفر فعلياً.
  available_in_clinical_selection INTEGER NOT NULL DEFAULT 1,
  -- الحذف من الواجهة أرشفة قابلة للمراجعة؛ لا نمسح تاريخ الجرد أو الاستخدام.
  active INTEGER NOT NULL DEFAULT 1,
  is_general_consumable INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- المخزن المرن: التخصص > التصنيف > الصنف الأساسي > مواصفات الصنف > الصنف
-- الفعلي الذي له رصيد. استخدام مواصفات كجداول مستقلة (بدلاً من أعمدة ثابتة
-- للمقاس/الشركة/Prescription) يسمح بإضافة أي تقسيمة لاحقاً من الإعدادات.
CREATE TABLE IF NOT EXISTS inventory_specialties (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  parent_id INTEGER REFERENCES inventory_specialties(id),
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS inventory_categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  specialty_id INTEGER NOT NULL REFERENCES inventory_specialties(id),
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(specialty_id, name)
);

CREATE TABLE IF NOT EXISTS inventory_products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category_id INTEGER NOT NULL REFERENCES inventory_categories(id),
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(category_id, name)
);

CREATE TABLE IF NOT EXISTS inventory_attribute_groups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL REFERENCES inventory_products(id),
  name TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  UNIQUE(product_id, name)
);

CREATE TABLE IF NOT EXISTS inventory_attribute_values (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  attribute_group_id INTEGER NOT NULL REFERENCES inventory_attribute_groups(id),
  value TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  UNIQUE(attribute_group_id, value)
);

CREATE TABLE IF NOT EXISTS inventory_units (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  short_name TEXT NOT NULL UNIQUE,
  active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS inventory_suppliers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  phone_country_code TEXT NOT NULL DEFAULT '+20',
  phone TEXT,
  notes TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- كل توريد فعلي للخامة العلاجية. ينفع لنفس الخامة أكثر من شركة أو مورد،
-- بينما inventory_items.quantity يبقى دائمًا الرصيد الإجمالي السهل للجرد.
CREATE TABLE IF NOT EXISTS inventory_supply_batches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id INTEGER NOT NULL REFERENCES inventory_items(id),
  supplier_id INTEGER REFERENCES inventory_suppliers(id),
  brand TEXT,
  quantity_received REAL NOT NULL CHECK (quantity_received > 0),
  quantity_remaining REAL NOT NULL CHECK (quantity_remaining >= 0),
  -- اسم العبوة وعددها ومحتوى كل عبوة. الرصيد الداخلي دائماً بوحدة الاستهلاك
  -- (منديل/دائرة O-tie/قطعة)، لذلك يجوز أن تختلف العبوات بين توريد وآخر.
  purchase_unit_label TEXT,
  package_count REAL,
  units_per_package REAL,
  total_cost REAL,
  received_at TEXT NOT NULL DEFAULT (date('now')),
  note TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- دفتر حركة موحد: توريد، جرد، خصم شارت تقويم، واستهلاك عام لكل موعد تم.
-- unique في الاستهلاك العام يمنع خصم الجوانتي/الكوباية مرتين لنفس الموعد.
CREATE TABLE IF NOT EXISTS inventory_stock_movements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id INTEGER NOT NULL REFERENCES inventory_items(id),
  batch_id INTEGER REFERENCES inventory_supply_batches(id),
  appointment_id INTEGER REFERENCES appointments(id),
  movement_type TEXT NOT NULL CHECK (movement_type IN ('supply','count_adjustment','ortho_use','general_consumption','return')),
  quantity REAL NOT NULL,
  note TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- متوسط ثابت لاستهلاك المستهلكات العامة من كل موعد حالته "تم".
CREATE TABLE IF NOT EXISTS inventory_consumable_rules (
  item_id INTEGER PRIMARY KEY REFERENCES inventory_items(id),
  quantity_per_completed_appointment REAL NOT NULL CHECK (quantity_per_completed_appointment >= 0),
  active INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- مسودة شراء مفتوحة واحدة لكل مورد. عند وصول صنف لحد التنبيه يضاف إليها،
-- فتتجمع احتياجات المورد قبل فتح رسالة WhatsApp له.
CREATE TABLE IF NOT EXISTS inventory_purchase_drafts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  supplier_id INTEGER NOT NULL REFERENCES inventory_suppliers(id),
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','sent','closed')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS inventory_purchase_draft_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  draft_id INTEGER NOT NULL REFERENCES inventory_purchase_drafts(id),
  item_id INTEGER NOT NULL REFERENCES inventory_items(id),
  suggested_quantity REAL NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(draft_id, item_id)
);

-- حالة التنبيه مستقلة عن مركز الإشعارات حتى نرسل عند أول وصول للحد أو عند
-- انتقاله من "قرب النفاد" إلى "حرج" فقط، ثم تبدأ دورة جديدة بعد إعادة التوريد.
CREATE TABLE IF NOT EXISTS inventory_stock_alerts (
  item_id INTEGER PRIMARY KEY REFERENCES inventory_items(id),
  level TEXT NOT NULL CHECK (level IN ('low','critical')),
  cycle INTEGER NOT NULL DEFAULT 1,
  resolved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Clinic-wide configuration (e.g. appointment slot length in minutes).
CREATE TABLE IF NOT EXISTS clinic_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

-- مركز الإشعارات: الحالات (مثل تأخر متابعة التقويم) تبقى محفوظة حتى تُحل،
-- بينما التنبيه المعروض في الجرس مؤقت وله وقت انتهاء مستقل.
CREATE TABLE IF NOT EXISTS notification_cases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  rule_key TEXT NOT NULL,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  doctor_id INTEGER REFERENCES doctors(id),
  last_visit_date TEXT,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','snoozed','resolved')),
  last_stage_days INTEGER NOT NULL DEFAULT 0,
  last_notified_at TEXT,
  reason TEXT,
  next_review_date TEXT,
  resolved_by INTEGER REFERENCES users(id),
  resolved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(rule_key, patient_id)
);

CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  recipient_user_id INTEGER NOT NULL REFERENCES users(id),
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  patient_id INTEGER REFERENCES patients(id),
  notification_case_id INTEGER REFERENCES notification_cases(id),
  dedupe_key TEXT NOT NULL,
  read_at TEXT,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(recipient_user_id, dedupe_key)
);

CREATE INDEX IF NOT EXISTS idx_notifications_recipient ON notifications(recipient_user_id, read_at, expires_at);
CREATE INDEX IF NOT EXISTS idx_notification_cases_rule ON notification_cases(rule_key, status, patient_id);

-- شات داخلي قصير العمر: رسالة طبيب للاستقبال تظهر للاستقبال وصاحبها فقط؛
-- ورسالة استقبال إلى طبيب معيّن أو لكل الأطباء تحددها recipient/audience.
CREATE TABLE IF NOT EXISTS chat_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sender_user_id INTEGER NOT NULL REFERENCES users(id),
  recipient_user_id INTEGER REFERENCES users(id),
  audience TEXT NOT NULL CHECK (audience IN ('reception','doctor','all_doctors')),
  body TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_chat_messages_created ON chat_messages(created_at);

-- آخر رسالة شاهدها كل مستخدم؛ يجعل علامة الرسائل غير المقروءة باقية حتى لو
-- كان النظام مغلقًا وقت وصول الرسالة.
CREATE TABLE IF NOT EXISTS chat_read_states (
  user_id INTEGER PRIMARY KEY REFERENCES users(id),
  last_read_message_id INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Tracks manual overrides that need to show up in the end-of-day report
-- (price overridden away from the price list, doctor reassigned on a visit, ...).
CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity_type TEXT NOT NULL,
  entity_id INTEGER NOT NULL,
  field TEXT NOT NULL,
  old_value TEXT,
  new_value TEXT,
  reason TEXT,
  changed_by INTEGER REFERENCES users(id),
  changed_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Per-user permission overrides on top of the role's default permission set.
-- granted=1 explicitly grants a permission the role wouldn't normally have;
-- granted=0 explicitly revokes a permission the role would normally have.
-- Absence of a row means "use the role default" (see src/lib/permissions.ts).
CREATE TABLE IF NOT EXISTS user_permissions (
  user_id INTEGER NOT NULL REFERENCES users(id),
  permission_key TEXT NOT NULL,
  granted INTEGER NOT NULL,
  PRIMARY KEY (user_id, permission_key)
);

-- شارت تشخيص وخطة علاج التقويم — سجل واحد بس لكل مريض (يتعمل مرة واحدة وقت
-- بداية علاج التقويم)، منفصل تمامًا عن سجل الزيارات العادي (الملف الطبي العام).
-- نفس قيود تعديل الملف الطبي (دكتور + أدمن + مدير عيادة)، شوف canEditMedicalRecordFor.
-- missing_teeth / extraction_teeth: JSON array نصي لمعرّفات أسنان زي "UR6"، "LLc"
-- (شوف src/lib/dental-chart.ts) — مش أعمدة منفصلة عشان عددهم متغيّر.
CREATE TABLE IF NOT EXISTS orthodontic_charts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL UNIQUE REFERENCES patients(id),
  sex TEXT CHECK (sex IN ('male','female')),
  chief_complaint TEXT,
  diagnosis_summary TEXT,
  past_medical_history TEXT,
  missing_teeth TEXT,
  -- Skeletal
  antero_posterior TEXT CHECK (antero_posterior IN ('class1','class2','class3')),
  facial_height TEXT CHECK (facial_height IN ('increased','average','decreased')),
  -- Dental
  mx_incisor_inclination TEXT CHECK (mx_incisor_inclination IN ('proclined','average','retroclined')),
  mn_incisor_inclination TEXT CHECK (mn_incisor_inclination IN ('proclined','average','retroclined')),
  molar_relation_right TEXT CHECK (molar_relation_right IN ('class1','class2','class3')),
  molar_relation_left TEXT CHECK (molar_relation_left IN ('class1','class2','class3')),
  overbite TEXT CHECK (overbite IN ('open_bite','average','deep_bite')),
  overjet TEXT CHECK (overjet IN ('increased','average','decreased')),
  midline_upper_direction TEXT CHECK (midline_upper_direction IN ('right','left')),
  midline_upper_mm REAL,
  midline_lower_direction TEXT CHECK (midline_lower_direction IN ('right','left')),
  midline_lower_mm REAL,
  space_upper_type TEXT CHECK (space_upper_type IN ('crowding','spacing')),
  space_upper_mm REAL,
  space_lower_type TEXT CHECK (space_lower_type IN ('crowding','spacing')),
  space_lower_mm REAL,
  -- Cephalometric (بس قيمة الحالة الفعلية — القيم القياسية "Norms" ثابتة ومعروضة في الواجهة بس)
  sna_case REAL,
  snb_case REAL,
  anb_case REAL,
  mma_case REAL,
  u1_pp_case REAL,
  l1_mp_case REAL,
  nasolabial_case REAL,
  -- Facial analysis
  nasolabial_angle TEXT CHECK (nasolabial_angle IN ('acute','average','obtuse')),
  lips TEXT CHECK (lips IN ('competent','incompetent')),
  -- Treatment plan
  extraction_choice TEXT CHECK (extraction_choice IN ('extraction','non_extraction')),
  extraction_teeth TEXT,
  anchorage TEXT CHECK (anchorage IN ('minimal','moderate','maximum')),
  anchorage_note TEXT,
  hints TEXT,
  created_by INTEGER REFERENCES users(id),
  updated_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- شارت التقويم v2 (دمج البروتوتايب المعزول مع السيستم الحقيقي، 2026-08-27):
-- زيارات الـFollow up. صف واحد لكل زيارة (مش JSON على orthodontic_charts زي
-- broken_teeth/rebonding_counts) عشان محتاجين نستعلم بيها بالتاريخ ونعدّل زيارة
-- بعينها من غير ما نلمس غيرها (زرار Edit بعد Save). bonding_applied بيتقفل
-- نهائيًا لما تتسجل خدمة Bonding على الزيارة دي — نفس قاعدة البروتوتايب:
-- تصحيح غلطة تركيب بيتم من الشارت نفسه (Debonded/No brackets) مش من هنا.
CREATE TABLE IF NOT EXISTS ortho_visits (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  visit_date TEXT NOT NULL,
  service TEXT,
  upper_wire_size TEXT,
  upper_wire_type TEXT,
  lower_wire_size TEXT,
  lower_wire_type TEXT,
  note TEXT,
  elastics_dispensed INTEGER NOT NULL DEFAULT 0,
  elastics_size TEXT,
  otie_color TEXT,
  power_chain_qty REAL,
  buttons_qty REAL,
  compressed_coil_mm REAL,
  upper_wire_item_id INTEGER REFERENCES inventory_items(id),
  lower_wire_item_id INTEGER REFERENCES inventory_items(id),
  elastic_item_id INTEGER REFERENCES inventory_items(id),
  otie_item_id INTEGER REFERENCES inventory_items(id),
  power_chain_item_id INTEGER REFERENCES inventory_items(id),
  buttons_item_id INTEGER REFERENCES inventory_items(id),
  compressed_coil_item_id INTEGER REFERENCES inventory_items(id),
  bonding_bracket_item_id INTEGER REFERENCES inventory_items(id),
  bonding_tube_item_id INTEGER REFERENCES inventory_items(id),
  doctor_id INTEGER REFERENCES doctors(id),
  -- Seen by consultant: يتسجل مع كل زيارة. لو Doctor نفسه استشاري، التطبيق
  -- يفعّله تلقائياً ويحفظ نفس الطبيب في consultant_doctor_id.
  seen_by_consultant INTEGER NOT NULL DEFAULT 0,
  consultant_doctor_id INTEGER REFERENCES doctors(id),
  bonding_applied INTEGER NOT NULL DEFAULT 0,
  created_by INTEGER REFERENCES users(id),
  updated_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- سجل حقيقي (ledger) لخصومات المخزون المرتبطة بشارت التقويم — النظام الحالي
-- (bonding/rebonding في actions.ts فوق) بيخصم مباشرة من inventory_items.quantity
-- من غير أي أثر قابل للـUndo. الجدول ده إضافة (مش استبدال) بيسجل كل خصم بشكل
-- منفصل قابل للإلغاء (Undo، صلاحية أدمن بس — undo_inventory_deduction) من غير
-- ما يمس منطق الـbonding/rebonding الحالي. visit_id فاضي (NULL) للخصومات
-- الناتجة عن bonding مباشرة (مش من صف زيارة)، ومليان لخصومات صف الـFollow up
-- (عشان يوم ما نعمل Edit وSave تاني نقدر نشيل خصومات الزيارة دي بس ونسجلها
-- من جديد، زي ما البروتوتايب بيعمل بالظبط).
CREATE TABLE IF NOT EXISTS ortho_inventory_deductions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  visit_id INTEGER REFERENCES ortho_visits(id),
  item_id INTEGER REFERENCES inventory_items(id),
  label TEXT NOT NULL,
  qty REAL NOT NULL,
  teeth TEXT,
  deduction_date TEXT NOT NULL,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  undone_by INTEGER REFERENCES users(id),
  undone_at TEXT
);

-- مخزون البراكتس مختلف عن باقي الخامات: الرصيد يتابع الفص نفسه (FDI) داخل
-- كل شركة، وليس عدداً إجمالياً. الـCase يضيف واحداً لكل واحد من العشرين سناً
-- بينما الـRefill يضيف لسن واحد فقط.
CREATE TABLE IF NOT EXISTS orthodontic_bracket_stock (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  brand TEXT NOT NULL,
  fdi INTEGER NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(brand, fdi)
);

CREATE TABLE IF NOT EXISTS orthodontic_bracket_stock_movements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  brand TEXT NOT NULL,
  fdi INTEGER NOT NULL,
  quantity INTEGER NOT NULL,
  movement_type TEXT NOT NULL CHECK (movement_type IN ('case_purchase','refill_purchase','manual_count','ortho_use','return')),
  patient_id INTEGER REFERENCES patients(id),
  visit_id INTEGER REFERENCES ortho_visits(id),
  -- التاريخ العلاجي الذي اختاره الطبيب داخل الشارت. created_at وحده لا يكفي
  -- لأنه UTC وقد ينقل استخدام آخر الليل إلى يوم مختلف في ملخص الزيارة.
  movement_date TEXT,
  note TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Tubes have no brands. Stock is tracked separately for the 6 and 7 molars in
-- every quadrant: 16/17, 26/27, 36/37 and 46/47.
CREATE TABLE IF NOT EXISTS orthodontic_tube_stock (
  fdi INTEGER PRIMARY KEY CHECK (fdi IN (16,17,26,27,36,37,46,47)),
  quantity INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS orthodontic_tube_stock_movements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  fdi INTEGER NOT NULL REFERENCES orthodontic_tube_stock(fdi),
  quantity INTEGER NOT NULL,
  movement_type TEXT NOT NULL CHECK (movement_type IN ('case_purchase','refill_purchase','manual_count','ortho_use','return')),
  patient_id INTEGER REFERENCES patients(id) ON DELETE CASCADE,
  visit_id INTEGER REFERENCES ortho_visits(id) ON DELETE SET NULL,
  movement_date TEXT,
  note TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  undone_by INTEGER REFERENCES users(id),
  undone_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_orthodontic_tube_stock_movements_patient ON orthodontic_tube_stock_movements(patient_id, fdi, created_at);

-- قوايم اختيارات شارت التقويم (مقاسات/أنواع الوير، ألوان الـO-tie، مقاسات
-- الإيلاستكس) قابلة للتعديل من صفحة الإعدادات بمعرفة المستخدم (طلب صريح —
-- مش placeholders ثابتة في الكود). دكاترة الفولو أب بيستخدموا جدول doctors
-- الموجود بالفعل، مش لستة جديدة هنا.
CREATE TABLE IF NOT EXISTS ortho_option_lists (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT NOT NULL CHECK (category IN ('wire_size','wire_type','otie_color','elastic_size','anchorage_device')),
  value TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_ortho_visits_patient ON ortho_visits(patient_id, visit_date);
CREATE INDEX IF NOT EXISTS idx_ortho_inventory_deductions_patient ON ortho_inventory_deductions(patient_id, deduction_date);
CREATE INDEX IF NOT EXISTS idx_ortho_inventory_deductions_visit ON ortho_inventory_deductions(visit_id);
CREATE INDEX IF NOT EXISTS idx_orthodontic_bracket_stock_brand ON orthodontic_bracket_stock(brand, fdi);

CREATE INDEX IF NOT EXISTS idx_visits_patient ON visits(patient_id);
CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(appointment_date, room_id);
CREATE INDEX IF NOT EXISTS idx_shifts_date ON shifts(shift_date, room_id);
CREATE INDEX IF NOT EXISTS idx_doctor_weekly_shifts_weekday ON doctor_weekly_shifts(weekday, room_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_date ON audit_log(changed_at);

-- دفعة 21 — فهارس إضافية كانت ناقصة على أعمدة بتتفلتر/تتربط عليها كتير (الملف
-- المالي للمريض، لوجيك الموعد المعلّق، دفعات المتابعة) — من غير فهرسة، SQLite
-- بيعمل full table scan على invoices/appointments/visits في كل استعلام من دول،
-- ومع زيادة عدد الزيارات/الفواتير بمرور الوقت ده بيبقى أبطأ تدريجيًا. إضافة
-- فهرس آمنة 100% ومالهاش أي تأثير على البيانات أو السلوك، بس بتسرّع القراءة.
CREATE INDEX IF NOT EXISTS idx_invoices_visit ON invoices(visit_id);
CREATE INDEX IF NOT EXISTS idx_invoices_parent ON invoices(parent_invoice_id);
-- فهارس الأعمدة المالية الجديدة تنشأ من client.ts بعد ترقية قاعدة قديمة؛ وضعها
-- هنا يجعل SQLite يحاول استخدامها قبل أن يضيف الأعمدة عند أول تشغيل للتحديث.
CREATE INDEX IF NOT EXISTS idx_appointments_patient_status ON appointments(patient_id, status);
CREATE INDEX IF NOT EXISTS idx_visits_appointment ON visits(appointment_id);
CREATE INDEX IF NOT EXISTS idx_collection_requests_patient_status ON collection_requests(patient_id, status);
CREATE INDEX IF NOT EXISTS idx_patient_credits_patient_status ON patient_credits(patient_id, status);

-- =====================================================================
-- WhatsApp Cloud API integration.
--
-- حساب واحد فعليًا لكل عيادة (رقم واحد)، لكن الجدول مصمم يستحمل أكتر من صف
-- (WABA/Phone Number ID مختلفين) لو احتجنا نبدّل لاحقًا من غير هجرة إضافية.
-- access_token_encrypted: التوكن الناتج من Embedded Signup مشفّر بمفتاح
-- WHATSAPP_TOKEN_ENC_KEY (متغير بيئة على السيرفر، شوف src/lib/whatsapp/crypto.ts) —
-- التوكن ده بييجي ديناميكيًا وقت الربط (مش قيمة ثابتة تتحط يدويًا في .env مرة واحدة
-- وبس)، فتخزينه في قاعدة البيانات مشفّرًا هو الحل العملي، بينما App Secret وVerify
-- Token (ثابتين، بيتحطوا مرة واحدة وقت النشر) فضلوا في .env.production زي باقي أسرار
-- المشروع. لا يوجد نص صريح لأي توكن في أي عمود.
CREATE TABLE IF NOT EXISTS whatsapp_accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  waba_id TEXT NOT NULL UNIQUE,
  phone_number_id TEXT NOT NULL UNIQUE,
  display_phone_number TEXT,
  verified_name TEXT,
  business_id TEXT,
  access_token_encrypted TEXT NOT NULL,
  token_type TEXT NOT NULL DEFAULT 'system_user',
  environment TEXT NOT NULL DEFAULT 'test' CHECK (environment IN ('test', 'production')),
  -- coexistence_mode=1: الرقم ده رقم العيادة الحقيقي المتصل عن طريق WhatsApp
  -- Business App Coexistence (لسه شغال على تطبيق واتساب بزنس في نفس الوقت).
  -- =0: رقم Cloud API عادي (رقم Meta التجريبي وقت التطوير/المراجعة).
  coexistence_mode INTEGER NOT NULL DEFAULT 0,
  connection_status TEXT NOT NULL DEFAULT 'connected' CHECK (connection_status IN ('connected','disconnected','error')),
  last_error TEXT,
  connected_by INTEGER REFERENCES users(id),
  connected_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS whatsapp_contacts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id INTEGER NOT NULL REFERENCES whatsapp_accounts(id),
  wa_id TEXT NOT NULL, -- رقم واتساب بصيغة دولية بدون علامة +، زي ما بترجعه Meta
  profile_name TEXT,
  patient_id INTEGER REFERENCES patients(id),
  last_message_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(account_id, wa_id)
);

CREATE TABLE IF NOT EXISTS whatsapp_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id INTEGER NOT NULL REFERENCES whatsapp_accounts(id),
  contact_id INTEGER NOT NULL REFERENCES whatsapp_contacts(id),
  -- wamid: معرف الرسالة عند Meta. UNIQUE هنا هو خط الدفاع الأساسي ضد تكرار
  -- الرسائل (Meta بتعيد إرسال نفس الـwebhook delivery أحيانًا) — أي محاولة إدراج
  -- بنفس wamid تتجاهل (INSERT OR IGNORE في lib/whatsapp/store.ts).
  wamid TEXT UNIQUE,
  direction TEXT NOT NULL CHECK (direction IN ('inbound','outbound')),
  message_type TEXT NOT NULL DEFAULT 'text',
  body TEXT,
  template_name TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','sent','delivered','read','failed')),
  error_message TEXT,
  -- smb_message_echoes: رسالة اتبعتت من السكرتارية من تطبيق WhatsApp Business
  -- نفسه (مش من السيستم) لكن وصلتنا كـwebhook echo — بتتسجل هنا للعرض فقط،
  -- مش رسالة "outbound" بعتها السيستم.
  is_echo INTEGER NOT NULL DEFAULT 0,
  sent_by INTEGER REFERENCES users(id),
  wa_timestamp TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_whatsapp_messages_contact ON whatsapp_messages(contact_id, created_at);

CREATE TABLE IF NOT EXISTS whatsapp_message_templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id INTEGER NOT NULL REFERENCES whatsapp_accounts(id),
  meta_template_id TEXT,
  name TEXT NOT NULL,
  language TEXT NOT NULL DEFAULT 'ar',
  category TEXT NOT NULL DEFAULT 'UTILITY',
  body_text TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','paused','disabled')),
  rejected_reason TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(account_id, name, language)
);

-- منع تكرار معالجة نفس حدث webhook (Meta بترسل نفس الـdelivery أكتر من مرة
-- أحيانًا كـretry). event_key بيتبني من نوع الحدث + معرف فريد ليه (wamid لحدث
-- رسالة، أو message_id/status/timestamp لتحديث حالة، أو hash لأي حدث تاني
-- زي smb_app_state_sync اللي معهوش معرف طبيعي فريد).
CREATE TABLE IF NOT EXISTS whatsapp_webhook_events (
  event_key TEXT PRIMARY KEY,
  event_type TEXT NOT NULL,
  received_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_whatsapp_webhook_events_received ON whatsapp_webhook_events(received_at);

CREATE TABLE IF NOT EXISTS whatsapp_manual_templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  header_text TEXT,
  body_text TEXT NOT NULL,
  recipient_type TEXT NOT NULL DEFAULT 'patient',
  variable_map TEXT NOT NULL DEFAULT '{}',
  quick_slot INTEGER CHECK (quick_slot BETWEEN 1 AND 5),
  active INTEGER NOT NULL DEFAULT 1,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_whatsapp_manual_quick_slot ON whatsapp_manual_templates(quick_slot) WHERE quick_slot IS NOT NULL AND active = 1;

-- قواعد إرسال Meta التلقائية. variable_map يربط {{1}}... ببيانات الموعد
-- بدل تثبيت قالب واحد في الكود، وdedupe يمنع إرسال نفس القاعدة لنفس الموعد مرتين.
CREATE TABLE IF NOT EXISTS whatsapp_automation_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  template_id INTEGER NOT NULL REFERENCES whatsapp_message_templates(id),
  trigger_type TEXT NOT NULL CHECK (trigger_type IN ('appointment_relative', 'appointment_completed')),
  day_offset INTEGER NOT NULL DEFAULT -1,
  send_time TEXT NOT NULL DEFAULT '18:00',
  delay_minutes INTEGER NOT NULL DEFAULT 0,
  variable_map TEXT NOT NULL DEFAULT '{}',
  active INTEGER NOT NULL DEFAULT 1,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS whatsapp_automation_deliveries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  rule_id INTEGER NOT NULL REFERENCES whatsapp_automation_rules(id) ON DELETE CASCADE,
  appointment_id INTEGER NOT NULL REFERENCES appointments(id),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'sent', 'failed', 'skipped')),
  scheduled_for TEXT NOT NULL,
  sent_at TEXT,
  error_message TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(rule_id, appointment_id)
);

-- فتح رسالة يدوية من النظام يُسجل كمحاولة حتى يظهر خيار إعادة الإرسال ما دام
-- المريض لم يرد أو يؤكد. لا ندّعي أن WhatsApp Web ضغط زر Send فعليًا.
CREATE TABLE IF NOT EXISTS whatsapp_manual_deliveries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  appointment_id INTEGER NOT NULL REFERENCES appointments(id),
  template_id INTEGER NOT NULL REFERENCES whatsapp_manual_templates(id),
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  status TEXT NOT NULL DEFAULT 'opened' CHECK (status IN ('opened', 'responded')),
  attempts INTEGER NOT NULL DEFAULT 1,
  last_opened_at TEXT NOT NULL DEFAULT (datetime('now')),
  opened_by INTEGER REFERENCES users(id),
  UNIQUE(appointment_id, template_id)
);

CREATE TABLE IF NOT EXISTS patient_review_invites (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token_hash TEXT NOT NULL UNIQUE,
  appointment_id INTEGER NOT NULL REFERENCES appointments(id),
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS patient_reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token_hash TEXT NOT NULL UNIQUE,
  appointment_id INTEGER REFERENCES appointments(id),
  patient_id INTEGER REFERENCES patients(id),
  doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  visit_date TEXT NOT NULL,
  anonymous INTEGER NOT NULL DEFAULT 0,
  rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  submitted_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_patient_reviews_date ON patient_reviews(visit_date, doctor_id);

-- محاولات تسجيل الدخول (دفعة 94): بتمنع تجربة كلمات السر بالتخمين، وبتدي كمان
-- سجلًا لمين حاول يدخل — مكانش موجود قبل كده خالص. الصفوف الأقدم من ساعة
-- بتتمسح تلقائيًا مع كل محاولة (شوف src/lib/login-attempts.ts).
CREATE TABLE IF NOT EXISTS login_attempts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL,
  succeeded INTEGER NOT NULL DEFAULT 0,
  attempted_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_login_attempts_user ON login_attempts(username, attempted_at);
