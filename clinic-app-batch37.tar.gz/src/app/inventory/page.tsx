import Link from "next/link";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getClinicToday } from "@/lib/clinic-date";
import { evaluateInventoryReorderNeeds, supplierOrderMessage, supplierWhatsAppUrl } from "@/lib/inventory-reorder";
import InventoryItemForm from "@/components/InventoryItemForm";
import { markInventoryDraftSentAction, updateQuantityAction } from "./actions";

type DraftItem = { name: string; quantity: number; unit: string | null; suggested_quantity: number };

export default async function InventoryPage() {
  const session = await getSession();
  const canManage = session ? await hasPermission(session.userId, session.role, "manage_inventory") : false;
  if (!canManage) {
    return <div className="card-3d rounded-xl p-5 text-sm text-muted">مفيش صلاحية عندك لعرض المخزن — كلم الأدمن لو محتاج توصل له.</div>;
  }

  await evaluateInventoryReorderNeeds();
  const [items, products, groups, values, units, suppliers, draftRows] = await Promise.all([
    db
      .selectFrom("inventory_items")
      .leftJoin("inventory_suppliers", "inventory_suppliers.id", "inventory_items.supplier_id")
      .leftJoin("inventory_products", "inventory_products.id", "inventory_items.product_id")
      .select([
        "inventory_items.id", "inventory_items.name", "inventory_items.quantity", "inventory_items.unit", "inventory_items.expiry_date",
        "inventory_items.low_stock_threshold", "inventory_items.critical_stock_threshold", "inventory_items.reorder_quantity",
        "inventory_items.item_code", "inventory_items.ortho_usage", "inventory_suppliers.name as supplier_name", "inventory_products.name as product_name",
      ])
      .orderBy("inventory_items.name")
      .execute(),
    db
      .selectFrom("inventory_products")
      .innerJoin("inventory_categories", "inventory_categories.id", "inventory_products.category_id")
      .innerJoin("inventory_specialties", "inventory_specialties.id", "inventory_categories.specialty_id")
      .select(["inventory_products.id", "inventory_products.name", "inventory_categories.name as categoryName", "inventory_specialties.name as specialtyName"])
      .where("inventory_products.active", "=", 1)
      .orderBy("inventory_specialties.name")
      .orderBy("inventory_categories.name")
      .orderBy("inventory_products.name")
      .execute(),
    db.selectFrom("inventory_attribute_groups").select(["id", "product_id", "name"]).orderBy("sort_order").execute(),
    db.selectFrom("inventory_attribute_values").select(["id", "attribute_group_id", "value"]).where("active", "=", 1).orderBy("sort_order").execute(),
    db.selectFrom("inventory_units").select(["id", "name", "short_name"]).where("active", "=", 1).orderBy("name").execute(),
    db.selectFrom("inventory_suppliers").select(["id", "name", "phone_country_code", "phone"]).where("active", "=", 1).orderBy("name").execute(),
    db
      .selectFrom("inventory_purchase_drafts")
      .innerJoin("inventory_suppliers", "inventory_suppliers.id", "inventory_purchase_drafts.supplier_id")
      .innerJoin("inventory_purchase_draft_items", "inventory_purchase_draft_items.draft_id", "inventory_purchase_drafts.id")
      .innerJoin("inventory_items", "inventory_items.id", "inventory_purchase_draft_items.item_id")
      .select([
        "inventory_purchase_drafts.id as draft_id", "inventory_purchase_drafts.updated_at", "inventory_suppliers.name as supplier_name",
        "inventory_suppliers.phone_country_code", "inventory_suppliers.phone", "inventory_items.name",
        "inventory_items.quantity", "inventory_items.unit", "inventory_purchase_draft_items.suggested_quantity",
      ])
      .where("inventory_purchase_drafts.status", "=", "open")
      .orderBy("inventory_purchase_drafts.updated_at", "desc")
      .execute(),
  ]);

  const drafts = new Map<number, { id: number; supplierName: string; phoneCountryCode: string | null; phone: string | null; updatedAt: string; items: DraftItem[] }>();
  for (const row of draftRows) {
    const draft = drafts.get(row.draft_id) ?? { id: row.draft_id, supplierName: row.supplier_name, phoneCountryCode: row.phone_country_code, phone: row.phone, updatedAt: row.updated_at, items: [] };
    draft.items.push({ name: row.name, quantity: row.suggested_quantity, unit: row.unit, suggested_quantity: row.suggested_quantity });
    drafts.set(row.draft_id, draft);
  }

  const today = getClinicToday();
  const soon = new Date();
  soon.setDate(soon.getDate() + 30);
  const soonStr = soon.toISOString().slice(0, 10);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold">المخزن</h1>
          <p className="text-sm text-muted mt-1">كل صنف فعلي يمكن أن يحمل مواصفات متعددة، رصيدًا، وموردًا مختلفًا.</p>
        </div>
        <Link href="/settings" className="rounded-md border border-border px-3 py-2 text-sm hover:bg-primary-soft">إدارة كتالوج المخزن والموردين</Link>
      </div>

      {drafts.size > 0 && (
        <section className="card-3d rounded-xl p-5 space-y-4">
          <div><h2 className="font-semibold">طلبات شراء معلّقة حسب المورد</h2><p className="text-xs text-muted mt-1">كل صنف وصل لحد التنبيه يُضاف تلقائيًا إلى مسودة مورده. زر واتساب يفتح رسالة جاهزة فقط؛ الإرسال يتم يدويًا.</p></div>
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            {Array.from(drafts.values()).map((draft) => {
              const message = supplierOrderMessage(draft.supplierName, draft.items);
              const whatsappUrl = supplierWhatsAppUrl(draft.phoneCountryCode, draft.phone, message);
              return (
                <article key={draft.id} className="rounded-lg border border-border p-4 space-y-3">
                  <h3 className="font-semibold">{draft.supplierName}</h3>
                  <ul className="text-sm space-y-1">{draft.items.map((item, index) => <li key={`${item.name}-${index}`}>• {item.name}: <b>{item.suggested_quantity} {item.unit ?? ""}</b></li>)}</ul>
                  <div className="flex flex-wrap gap-2">
                    {whatsappUrl ? <a href={whatsappUrl} target="_blank" rel="noreferrer" className="rounded-md btn-3d-primary px-3 py-1.5 text-sm">فتح رسالة واتساب للمورد</a> : <span className="text-sm text-danger">أضف رقم واتساب للمورد من الإعدادات لتفعيل الرابط.</span>}
                    <form action={markInventoryDraftSentAction}><input type="hidden" name="draft_id" value={draft.id} /><button className="rounded-md border border-border px-3 py-1.5 text-sm hover:bg-primary-soft">تم إرسال الطلب</button></form>
                  </div>
                </article>
              );
            })}
          </div>
        </section>
      )}

      <section className="card-3d rounded-xl p-5 space-y-4">
        <div><h2 className="font-semibold">إضافة رصيد أو صنف فعلي</h2><p className="text-xs text-muted mt-1">أضف التخصص والفئة والصنف ووحداته وموردَه أولًا من الإعدادات، ثم اختر المواصفات المناسبة هنا.</p></div>
        <InventoryItemForm products={products} attributeGroups={groups} attributeValues={values} units={units} suppliers={suppliers} />
      </section>

      <div className="card-3d rounded-xl overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-primary-soft text-primary-dark"><tr><th className="text-right px-3 py-2 font-medium">الصنف</th><th className="text-right px-3 py-2 font-medium">المورد</th><th className="text-right px-3 py-2 font-medium">الرصيد</th><th className="text-right px-3 py-2 font-medium">الصلاحية</th><th className="px-3 py-2"></th></tr></thead>
          <tbody>
            {items.map((item) => {
              const low = item.low_stock_threshold > 0 && item.quantity <= item.low_stock_threshold;
              const critical = low && item.quantity <= item.critical_stock_threshold;
              const expiringSoon = item.expiry_date && item.expiry_date <= soonStr && item.expiry_date >= today;
              const expired = item.expiry_date && item.expiry_date < today;
              return (
                <tr key={item.id} className="border-t border-border">
                  <td className="px-3 py-2 font-medium">{item.name}{item.item_code && <div className="text-xs text-muted font-normal">{item.item_code}</div>}{item.ortho_usage && <div className="text-xs text-primary font-normal">شارت التقويم: {item.ortho_usage}</div>}</td>
                  <td className="px-3 py-2">{item.supplier_name ?? "-"}</td>
                  <td className="px-3 py-2"><span className={low ? "text-danger font-semibold" : ""}>{item.quantity} {item.unit ?? ""}</span>{critical ? <span className="ms-2 text-xs bg-danger-soft text-danger rounded-full px-2 py-0.5">حرج</span> : low ? <span className="ms-2 text-xs bg-danger-soft text-danger rounded-full px-2 py-0.5">قرب النفاد</span> : null}</td>
                  <td className="px-3 py-2"><span className={expired ? "text-danger font-semibold" : expiringSoon ? "text-danger" : ""}>{item.expiry_date ?? "-"}</span>{expired && <span className="ms-2 text-xs bg-danger-soft text-danger rounded-full px-2 py-0.5">منتهي</span>}{!expired && expiringSoon && <span className="ms-2 text-xs bg-danger-soft text-danger rounded-full px-2 py-0.5">قريب الانتهاء</span>}</td>
                  <td className="px-3 py-2"><form action={updateQuantityAction} className="flex items-center gap-1"><input type="hidden" name="id" value={item.id} /><input type="number" min="0" name="quantity" defaultValue={item.quantity} step="0.01" className="w-20 rounded-md border border-border bg-background px-2 py-1 text-xs" /><button className="text-xs px-2 py-1 rounded-md border border-border hover:bg-primary-soft">تحديث</button></form></td>
                </tr>
              );
            })}
            {items.length === 0 && <tr><td colSpan={5} className="px-3 py-6 text-center text-muted">لا يوجد أصناف مسجلة بعد.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
