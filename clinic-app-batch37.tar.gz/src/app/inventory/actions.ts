"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { setSetting } from "@/lib/settings";
import { evaluateInventoryReorderNeeds } from "@/lib/inventory-reorder";

async function requireManageInventory(): Promise<boolean> {
  const session = await getSession();
  if (!session) return false;
  return hasPermission(session.userId, session.role, "manage_inventory");
}

async function requireInventoryAdmin(): Promise<boolean> {
  const session = await getSession();
  return Boolean(session && session.role === "admin");
}

function text(formData: FormData, key: string): string {
  return String(formData.get(key) || "").trim();
}

function positiveId(formData: FormData, key: string): number | null {
  const value = Number(formData.get(key));
  return Number.isInteger(value) && value > 0 ? value : null;
}

function nonNegative(formData: FormData, key: string, fallback = 0): number {
  const value = Number(formData.get(key));
  return Number.isFinite(value) && value >= 0 ? value : fallback;
}

function refreshInventoryPages() {
  revalidatePath("/inventory");
  revalidatePath("/settings");
}

export async function addInventorySpecialtyAction(formData: FormData) {
  if (!(await requireInventoryAdmin())) return;
  const name = text(formData, "name");
  if (!name) return;
  const parentId = positiveId(formData, "parent_id");
  await db
    .insertInto("inventory_specialties")
    .values({ name, parent_id: parentId })
    .onConflict((oc) => oc.column("name").doNothing())
    .execute();
  refreshInventoryPages();
}

export async function addInventoryCategoryAction(formData: FormData) {
  if (!(await requireInventoryAdmin())) return;
  const specialtyId = positiveId(formData, "specialty_id");
  const name = text(formData, "name");
  if (!specialtyId || !name) return;
  await db
    .insertInto("inventory_categories")
    .values({ specialty_id: specialtyId, name })
    .onConflict((oc) => oc.columns(["specialty_id", "name"]).doNothing())
    .execute();
  refreshInventoryPages();
}

export async function addInventoryProductAction(formData: FormData) {
  if (!(await requireInventoryAdmin())) return;
  const categoryId = positiveId(formData, "category_id");
  const name = text(formData, "name");
  if (!categoryId || !name) return;
  await db
    .insertInto("inventory_products")
    .values({ category_id: categoryId, name })
    .onConflict((oc) => oc.columns(["category_id", "name"]).doNothing())
    .execute();
  refreshInventoryPages();
}

export async function addInventoryAttributeGroupAction(formData: FormData) {
  if (!(await requireInventoryAdmin())) return;
  const productId = positiveId(formData, "product_id");
  const name = text(formData, "name");
  if (!productId || !name) return;
  await db.insertInto("inventory_attribute_groups").values({ product_id: productId, name }).execute();
  refreshInventoryPages();
}

export async function addInventoryAttributeValueAction(formData: FormData) {
  if (!(await requireInventoryAdmin())) return;
  const attributeGroupId = positiveId(formData, "attribute_group_id");
  const value = text(formData, "value");
  if (!attributeGroupId || !value) return;
  await db
    .insertInto("inventory_attribute_values")
    .values({ attribute_group_id: attributeGroupId, value })
    .onConflict((oc) => oc.columns(["attribute_group_id", "value"]).doNothing())
    .execute();
  refreshInventoryPages();
}

export async function addInventoryUnitAction(formData: FormData) {
  if (!(await requireInventoryAdmin())) return;
  const name = text(formData, "name");
  const shortName = text(formData, "short_name");
  if (!name) return;
  await db
    .insertInto("inventory_units")
    .values({ name, short_name: shortName || name })
    .onConflict((oc) => oc.column("name").doNothing())
    .execute();
  refreshInventoryPages();
}

export async function addInventorySupplierAction(formData: FormData) {
  if (!(await requireInventoryAdmin())) return;
  const name = text(formData, "name");
  if (!name) return;
  await db
    .insertInto("inventory_suppliers")
    .values({
      name,
      phone_country_code: text(formData, "phone_country_code") || "+20",
      phone: text(formData, "phone") || null,
      notes: text(formData, "notes") || null,
    })
    .onConflict((oc) => oc.column("name").doNothing())
    .execute();
  refreshInventoryPages();
}

export async function saveInventoryNotificationRecipientsAction(formData: FormData) {
  if (!(await requireInventoryAdmin())) return;
  const ids = formData
    .getAll("recipient_user_ids")
    .map((value) => Number(value))
    .filter((value) => Number.isInteger(value) && value > 0);
  await setSetting("inventory_low_stock_recipient_ids", Array.from(new Set(ids)).join(","));
  refreshInventoryPages();
}

// ينشئ الهيكل فقط، لا ينشئ أي رصيد أو مورد أو صنف فعلي. لذلك يمكن تشغيله
// بأمان مرة أو أكثر؛ القيم الموجودة لا تتكرر ولا تُستبدل.
export async function seedOrthodonticInventoryCatalogAction() {
  if (!(await requireInventoryAdmin())) return;
  const specialtyName = "تقويم";
  await db.insertInto("inventory_specialties").values({ name: specialtyName }).onConflict((oc) => oc.column("name").doNothing()).execute();
  const specialty = await db.selectFrom("inventory_specialties").select("id").where("name", "=", specialtyName).executeTakeFirst();
  if (!specialty) return;

  const blueprint: Array<{ category: string; product: string; attributes: string[] }> = [
    { category: "Wires", product: "Orthodontic wire", attributes: ["Size", "Type", "Arch", "Company"] },
    { category: "Brackets", product: "Bracket", attributes: ["Company", "Prescription", "Slot", "Arch"] },
    { category: "Tubes", product: "Tube", attributes: ["Company", "Prescription", "Side"] },
    { category: "O-ties", product: "O-tie", attributes: ["Color", "Company"] },
    { category: "Elastics", product: "Elastic", attributes: ["Size", "Force", "Company"] },
    { category: "Power chain", product: "Power chain", attributes: ["Color", "Type", "Company"] },
    { category: "Buttons", product: "Button", attributes: ["Type", "Company"] },
    { category: "Compressed coil", product: "Compressed coil", attributes: ["Size", "Length", "Company"] },
    { category: "Anchorage", product: "Anchorage device", attributes: ["Type", "Company"] },
  ];
  for (const entry of blueprint) {
    await db.insertInto("inventory_categories").values({ specialty_id: specialty.id, name: entry.category }).onConflict((oc) => oc.columns(["specialty_id", "name"]).doNothing()).execute();
    const category = await db.selectFrom("inventory_categories").select("id").where("specialty_id", "=", specialty.id).where("name", "=", entry.category).executeTakeFirst();
    if (!category) continue;
    await db.insertInto("inventory_products").values({ category_id: category.id, name: entry.product }).onConflict((oc) => oc.columns(["category_id", "name"]).doNothing()).execute();
    const product = await db.selectFrom("inventory_products").select("id").where("category_id", "=", category.id).where("name", "=", entry.product).executeTakeFirst();
    if (!product) continue;
    for (const name of entry.attributes) {
      await db.insertInto("inventory_attribute_groups").values({ product_id: product.id, name }).onConflict((oc) => oc.columns(["product_id", "name"]).doNothing()).execute();
    }
  }
  refreshInventoryPages();
}

export async function addInventoryVariantAction(formData: FormData) {
  if (!(await requireManageInventory())) return;
  const productId = positiveId(formData, "product_id");
  const supplierId = positiveId(formData, "supplier_id");
  const orthoUsage = text(formData, "ortho_usage");
  const validOrthoUsages = new Set(["wire", "bracket", "tube", "elastic", "otie", "power_chain", "button", "compressed_coil", "anchorage_device"]);
  if (orthoUsage && !validOrthoUsages.has(orthoUsage)) return;
  let name = text(formData, "name");
  const selectedAttributes = Array.from(formData.entries())
    .filter(([key, value]) => key.startsWith("attribute_group_") && String(value))
    .map(([, value]) => Number(value))
    .filter((value) => Number.isInteger(value) && value > 0);

  if (productId) {
    const product = await db
      .selectFrom("inventory_products")
      .innerJoin("inventory_categories", "inventory_categories.id", "inventory_products.category_id")
      .innerJoin("inventory_specialties", "inventory_specialties.id", "inventory_categories.specialty_id")
      .select(["inventory_products.name", "inventory_specialties.name as specialty_name"])
      .where("inventory_products.id", "=", productId)
      .where("inventory_products.active", "=", 1)
      .executeTakeFirst();
    if (!product) return;
    if (orthoUsage && product.specialty_name !== "تقويم") return;
    const values = selectedAttributes.length
      ? await db
          .selectFrom("inventory_attribute_values")
          .innerJoin("inventory_attribute_groups", "inventory_attribute_groups.id", "inventory_attribute_values.attribute_group_id")
          .select(["inventory_attribute_values.id", "inventory_attribute_values.value"])
          .where("inventory_attribute_groups.product_id", "=", productId)
          .where("inventory_attribute_values.id", "in", selectedAttributes)
          .execute()
      : [];
    const validValueIds = values.map((value) => value.id);
    if (!name) name = [product.name, ...values.map((value) => value.value)].join(" — ");
    await createVariant(formData, { productId, supplierId, name, attributeValueIds: validValueIds, orthoUsage });
  } else {
    if (!name || orthoUsage) return;
    await createVariant(formData, { productId: null, supplierId, name, attributeValueIds: [], orthoUsage: "" });
  }
  await evaluateInventoryReorderNeeds();
  refreshInventoryPages();
}

async function createVariant(
  formData: FormData,
  input: { productId: number | null; supplierId: number | null; name: string; attributeValueIds: number[]; orthoUsage: string }
) {
  const lowStock = nonNegative(formData, "low_stock_threshold");
  const criticalStock = Math.min(nonNegative(formData, "critical_stock_threshold"), lowStock);
  await db
    .insertInto("inventory_items")
    .values({
      name: input.name,
      product_id: input.productId,
      supplier_id: input.supplierId,
      attribute_value_ids: input.attributeValueIds.length ? input.attributeValueIds.join(",") : null,
      item_code: text(formData, "item_code") || null,
      ortho_usage: input.orthoUsage || null,
      quantity: nonNegative(formData, "quantity"),
      unit: text(formData, "unit") || null,
      expiry_date: text(formData, "expiry_date") || null,
      low_stock_threshold: lowStock,
      critical_stock_threshold: criticalStock,
      reorder_quantity: nonNegative(formData, "reorder_quantity"),
    })
    .execute();
}

// نحافظ على الاسم القديم حتى لا يتعطل أي استدعاء قديم من الواجهة.
export async function addItemAction(formData: FormData) {
  await addInventoryVariantAction(formData);
}

export async function updateQuantityAction(formData: FormData) {
  if (!(await requireManageInventory())) return;
  const id = positiveId(formData, "id");
  const quantity = nonNegative(formData, "quantity", -1);
  if (!id || quantity < 0) return;
  await db.updateTable("inventory_items").set({ quantity }).where("id", "=", id).execute();
  await evaluateInventoryReorderNeeds();
  revalidatePath("/inventory");
}

export async function markInventoryDraftSentAction(formData: FormData) {
  if (!(await requireManageInventory())) return;
  const id = positiveId(formData, "draft_id");
  if (!id) return;
  await db.updateTable("inventory_purchase_drafts").set({ status: "sent", updated_at: new Date().toISOString().replace("T", " ").slice(0, 19) }).where("id", "=", id).execute();
  revalidatePath("/inventory");
}
