import {
  addInventoryAttributeGroupAction,
  addInventoryAttributeValueAction,
  addInventoryCategoryAction,
  addInventoryProductAction,
  addInventorySpecialtyAction,
  addInventorySupplierAction,
  addInventoryUnitAction,
  saveInventoryNotificationRecipientsAction,
  seedOrthodonticInventoryCatalogAction,
} from "@/app/inventory/actions";

type Specialty = { id: number; name: string; parent_id: number | null };
type Category = { id: number; name: string; specialty_id: number };
type Product = { id: number; name: string; category_id: number };
type AttributeGroup = { id: number; name: string; product_id: number };
type AttributeValue = { id: number; value: string; attribute_group_id: number };
type Unit = { id: number; name: string; short_name: string | null };
type Supplier = { id: number; name: string; phone_country_code: string | null; phone: string | null };
type User = { id: number; full_name: string; role: string };

const inputClass = "w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm";
const buttonClass = "rounded-md btn-3d-primary px-3 py-1.5 text-sm font-medium";

export default function InventoryCatalogManager({
  specialties,
  categories,
  products,
  attributeGroups,
  attributeValues,
  units,
  suppliers,
  users,
  recipientIds,
}: {
  specialties: Specialty[];
  categories: Category[];
  products: Product[];
  attributeGroups: AttributeGroup[];
  attributeValues: AttributeValue[];
  units: Unit[];
  suppliers: Supplier[];
  users: User[];
  recipientIds: number[];
}) {
  const specialtyName = (id: number) => specialties.find((entry) => entry.id === id)?.name ?? "-";
  const categoryName = (id: number) => categories.find((entry) => entry.id === id)?.name ?? "-";
  const productName = (id: number) => products.find((entry) => entry.id === id)?.name ?? "-";
  const groupName = (id: number) => attributeGroups.find((entry) => entry.id === id)?.name ?? "-";

  return (
    <div className="space-y-7">
      <p className="text-sm text-muted">
        ابْنِ الكتالوج بالترتيب: تخصص ← فئة ← صنف ← تقسيمات الصنف وقيمها. التقسيمات مرنة؛ مثل المقاس أو الشركة أو الـ prescription أو اللون.
      </p>

      <section className="rounded-xl border border-primary/30 bg-primary-soft/30 p-4 flex flex-wrap items-center justify-between gap-3">
        <div><h3 className="font-semibold">تهيئة مخزن التقويم</h3><p className="text-xs text-muted mt-1">ينشئ الهيكل الأساسي لـ Wires وBrackets وO-ties وغيرها، من دون رصيد أو موردين أو خامات فعلية.</p></div>
        <form action={seedOrthodonticInventoryCatalogAction}><button className={buttonClass}>إنشاء هيكل التقويم</button></form>
      </section>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
        <section className="rounded-xl border border-border p-4 space-y-3">
          <h3 className="font-semibold">1. التخصصات</h3>
          <form action={addInventorySpecialtyAction} className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <input name="name" required placeholder="مثال: تقويم أو زراعة" className={inputClass} />
            <select name="parent_id" className={inputClass} defaultValue="">
              <option value="">تخصص رئيسي</option>
              {specialties.map((entry) => <option key={entry.id} value={entry.id}>{entry.name}</option>)}
            </select>
            <button className={buttonClass}>إضافة تخصص</button>
          </form>
          <div className="text-xs text-muted">{specialties.map((entry) => `${entry.parent_id ? `${specialtyName(entry.parent_id)} ← ` : ""}${entry.name}`).join(" · ") || "لا توجد تخصصات بعد"}</div>
        </section>

        <section className="rounded-xl border border-border p-4 space-y-3">
          <h3 className="font-semibold">2. الفئات داخل التخصص</h3>
          <form action={addInventoryCategoryAction} className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <select name="specialty_id" required className={inputClass} defaultValue=""><option value="" disabled>اختر التخصص</option>{specialties.map((entry) => <option key={entry.id} value={entry.id}>{entry.name}</option>)}</select>
            <input name="name" required placeholder="مثال: Wires أو Brackets" className={inputClass} />
            <button className={buttonClass}>إضافة فئة</button>
          </form>
          <div className="text-xs text-muted">{categories.map((entry) => `${specialtyName(entry.specialty_id)}: ${entry.name}`).join(" · ") || "لا توجد فئات بعد"}</div>
        </section>

        <section className="rounded-xl border border-border p-4 space-y-3">
          <h3 className="font-semibold">3. الأصناف</h3>
          <form action={addInventoryProductAction} className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <select name="category_id" required className={inputClass} defaultValue=""><option value="" disabled>اختر الفئة</option>{categories.map((entry) => <option key={entry.id} value={entry.id}>{specialtyName(entry.specialty_id)} — {entry.name}</option>)}</select>
            <input name="name" required placeholder="مثال: Niti wire" className={inputClass} />
            <button className={buttonClass}>إضافة صنف</button>
          </form>
          <div className="text-xs text-muted">{products.map((entry) => `${categoryName(entry.category_id)}: ${entry.name}`).join(" · ") || "لا توجد أصناف بعد"}</div>
        </section>

        <section className="rounded-xl border border-border p-4 space-y-3">
          <h3 className="font-semibold">4. تقسيمات الصنف</h3>
          <form action={addInventoryAttributeGroupAction} className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <select name="product_id" required className={inputClass} defaultValue=""><option value="" disabled>اختر الصنف</option>{products.map((entry) => <option key={entry.id} value={entry.id}>{entry.name}</option>)}</select>
            <input name="name" required placeholder="مقاس، شركة، prescription..." className={inputClass} />
            <button className={buttonClass}>إضافة تقسيمة</button>
          </form>
          <div className="text-xs text-muted">{attributeGroups.map((entry) => `${productName(entry.product_id)}: ${entry.name}`).join(" · ") || "لا توجد تقسيمات بعد"}</div>
        </section>

        <section className="rounded-xl border border-border p-4 space-y-3">
          <h3 className="font-semibold">5. قيم التقسيمات</h3>
          <form action={addInventoryAttributeValueAction} className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <select name="attribute_group_id" required className={inputClass} defaultValue=""><option value="" disabled>اختر التقسيمة</option>{attributeGroups.map((entry) => <option key={entry.id} value={entry.id}>{productName(entry.product_id)} — {entry.name}</option>)}</select>
            <input name="value" required placeholder="مثال: 0.012 أو Ormco" className={inputClass} />
            <button className={buttonClass}>إضافة قيمة</button>
          </form>
          <div className="text-xs text-muted">{attributeValues.map((entry) => `${groupName(entry.attribute_group_id)}: ${entry.value}`).join(" · ") || "لا توجد قيم بعد"}</div>
        </section>

        <section className="rounded-xl border border-border p-4 space-y-3">
          <h3 className="font-semibold">6. الوحدات</h3>
          <form action={addInventoryUnitAction} className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <input name="name" required placeholder="مثال: علبة" className={inputClass} />
            <input name="short_name" placeholder="اختصار: box" className={inputClass} />
            <button className={buttonClass}>إضافة وحدة</button>
          </form>
          <div className="text-xs text-muted">{units.map((entry) => `${entry.name}${entry.short_name ? ` (${entry.short_name})` : ""}`).join(" · ") || "لا توجد وحدات بعد"}</div>
        </section>

        <section className="rounded-xl border border-border p-4 space-y-3 xl:col-span-2">
          <h3 className="font-semibold">الموردون</h3>
          <form action={addInventorySupplierAction} className="grid grid-cols-1 sm:grid-cols-5 gap-2">
            <input name="name" required placeholder="اسم المورد" className={inputClass} />
            <input name="phone_country_code" defaultValue="+20" placeholder="كود الدولة" className={inputClass} />
            <input name="phone" placeholder="رقم واتساب محلي" className={inputClass} />
            <input name="notes" placeholder="ملاحظات" className={inputClass} />
            <button className={buttonClass}>إضافة مورد</button>
          </form>
          <div className="text-xs text-muted">{suppliers.map((entry) => `${entry.name}${entry.phone ? ` — ${entry.phone_country_code ?? "+20"} ${entry.phone}` : ""}`).join(" · ") || "لا يوجد موردون بعد"}</div>
        </section>
      </div>

      <section className="rounded-xl border border-border p-4 space-y-3">
        <h3 className="font-semibold">من يستلم تنبيهات نقص المخزون؟</h3>
        <form action={saveInventoryNotificationRecipientsAction} className="space-y-3">
          <div className="flex flex-wrap gap-x-5 gap-y-2">
            {users.map((user) => (
              <label key={user.id} className="inline-flex items-center gap-2 text-sm">
                <input type="checkbox" name="recipient_user_ids" value={user.id} defaultChecked={recipientIds.includes(user.id)} />
                {user.full_name} <span className="text-xs text-muted">({user.role})</span>
              </label>
            ))}
          </div>
          <button className={buttonClass}>حفظ المستلمين</button>
        </form>
      </section>
    </div>
  );
}
