"use server";

import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";

// تقرير "مدة المريض في العيادة": المدة بين وصول المريض فعليًا (attended_at)
// وانتهاء الزيارة (completed_at) على مواعيد status='done' بس.
//
// مهم: مش كل موعد "تم" له وقت وصول مسجَّل. لو الموعد اتقفل "تم" من غير ما
// يعدّي بحالة "حضر" الأول (زي تسجيل التحصيل المباشر من الطبيب) هيبقى
// attended_at فاضي، ومينفعش نحسب مدة له. التقرير بيعرض عدد المواعيد دي
// لوحده بدل ما يتجاهلها بصمت — عشان يبان للمستخدم إن المتوسط محسوب على
// جزء من المواعيد بس، مش كلها.

export type PatientDurationRow = {
  appointmentId: number;
  patientName: string;
  doctorName: string;
  appointmentDate: string;
  attendedAt: string;
  completedAt: string;
  durationMinutes: number;
};

export type DoctorDurationSummary = {
  doctorId: number;
  doctorName: string;
  count: number;
  averageMinutes: number;
  missingAttendedAt: number;
};

export type PatientDurationResult =
  | { ok: false; error: string }
  | {
      ok: true;
      rows: PatientDurationRow[];
      truncated: boolean;
      byDoctor: DoctorDurationSummary[];
      overallAverageMinutes: number;
      totalDone: number;
      missingAttendedAt: number;
    };

const DATE = /^\d{4}-\d{2}-\d{2}$/;
const MAX_ROWS = 500;

export async function getPatientDurationReportAction(params: {
  from: string;
  to: string;
  doctorId?: number;
  patientQuery?: string;
}): Promise<PatientDurationResult> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "view_patient_reports"))) {
    return { ok: false, error: "مفيش صلاحية عندك لعرض تقرير مدة المريض في العيادة." };
  }
  if (!DATE.test(params.from) || !DATE.test(params.to)) {
    return { ok: false, error: "التاريخ غير صحيح." };
  }
  if (params.to < params.from) {
    return { ok: false, error: "تاريخ النهاية لازم يكون بعد تاريخ البداية." };
  }

  let base = db
    .selectFrom("appointments")
    .innerJoin("patients", "patients.id", "appointments.patient_id")
    .innerJoin("doctors", "doctors.id", "appointments.doctor_id")
    .where("appointments.status", "=", "done")
    .where("appointments.appointment_date", ">=", params.from)
    .where("appointments.appointment_date", "<=", params.to);
  if (params.doctorId) base = base.where("appointments.doctor_id", "=", params.doctorId);
  // بحث بالاسم أو رقم الملف — عشان تقدر تدور على مريض بعينه وتشوف كل زياراته
  // في الفترة، مش بس متوسط عام لكل المرضى.
  const patientQuery = params.patientQuery?.trim();
  if (patientQuery) {
    const like = `%${patientQuery}%`;
    base = base.where((eb) => eb.or([
      eb("patients.full_name", "like", like),
      eb("patients.file_number", "like", like),
    ]));
  }

  const doneAppointments = await base
    .select([
      "appointments.id",
      "appointments.doctor_id",
      "appointments.appointment_date",
      "appointments.attended_at",
      "appointments.completed_at",
      "patients.full_name as patient_name",
      "doctors.full_name as doctor_name",
    ])
    .orderBy("appointments.attended_at", "desc")
    .execute();

  const rows: PatientDurationRow[] = [];
  const missingByDoctor = new Map<number, { name: string; missing: number }>();
  const sumByDoctor = new Map<number, { name: string; count: number; totalMinutes: number }>();
  let missingAttendedAt = 0;

  for (const appointment of doneAppointments) {
    const doctorEntry = missingByDoctor.get(appointment.doctor_id) ?? { name: appointment.doctor_name, missing: 0 };
    if (!appointment.attended_at || !appointment.completed_at) {
      missingAttendedAt += 1;
      doctorEntry.missing += 1;
      missingByDoctor.set(appointment.doctor_id, doctorEntry);
      continue;
    }
    missingByDoctor.set(appointment.doctor_id, doctorEntry);

    const attendedMs = new Date(appointment.attended_at).getTime();
    const completedMs = new Date(appointment.completed_at).getTime();
    if (!Number.isFinite(attendedMs) || !Number.isFinite(completedMs) || completedMs < attendedMs) {
      // تسجيل تالف أو ساعة السيرفر اتغيرت بين الحدثين — نستبعدها من الحساب
      // بدل ما نعرض مدة سالبة أو غير منطقية، ونعدّها ضمن "غير محسوبة".
      missingAttendedAt += 1;
      const entry = missingByDoctor.get(appointment.doctor_id)!;
      entry.missing += 1;
      continue;
    }

    const durationMinutes = Math.round((completedMs - attendedMs) / 60000);
    rows.push({
      appointmentId: appointment.id,
      patientName: appointment.patient_name,
      doctorName: appointment.doctor_name,
      appointmentDate: appointment.appointment_date,
      attendedAt: appointment.attended_at,
      completedAt: appointment.completed_at,
      durationMinutes,
    });

    const sumEntry = sumByDoctor.get(appointment.doctor_id) ?? { name: appointment.doctor_name, count: 0, totalMinutes: 0 };
    sumEntry.count += 1;
    sumEntry.totalMinutes += durationMinutes;
    sumByDoctor.set(appointment.doctor_id, sumEntry);
  }

  const byDoctor: DoctorDurationSummary[] = Array.from(
    new Set([...sumByDoctor.keys(), ...missingByDoctor.keys()]),
  )
    .map((doctorId) => {
      const sum = sumByDoctor.get(doctorId);
      const missing = missingByDoctor.get(doctorId);
      return {
        doctorId,
        doctorName: sum?.name ?? missing?.name ?? "—",
        count: sum?.count ?? 0,
        averageMinutes: sum && sum.count > 0 ? Math.round(sum.totalMinutes / sum.count) : 0,
        missingAttendedAt: missing?.missing ?? 0,
      };
    })
    .sort((a, b) => b.count - a.count);

  const totalMinutes = rows.reduce((sum, row) => sum + row.durationMinutes, 0);
  const overallAverageMinutes = rows.length > 0 ? Math.round(totalMinutes / rows.length) : 0;

  return {
    ok: true,
    rows: rows.slice(0, MAX_ROWS),
    truncated: rows.length > MAX_ROWS,
    byDoctor,
    overallAverageMinutes,
    totalDone: doneAppointments.length,
    missingAttendedAt,
  };
}

export async function getPatientDurationDoctorsAction() {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "view_patient_reports"))) return [];
  return db.selectFrom("doctors").select(["id", "full_name"]).orderBy("full_name").execute();
}

// نفس نمط بحث المريض المستخدم في بوكس الحجز بالجدول المركزي وبوكس البحث
// السريع: تحميل قائمة المرضى مرة واحدة، والفلترة بتحصل في المتصفح مع كل حرف
// - بدل ما نبعت طلب سيرفر مع كل كبسة زرار.
export async function getPatientDurationPatientsAction() {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "view_patient_reports"))) return [];
  return db.selectFrom("patients").select(["id", "full_name", "file_number"]).orderBy("full_name").execute();
}
