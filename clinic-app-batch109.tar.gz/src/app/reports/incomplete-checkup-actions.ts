"use server";

import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";

// تقرير "الكشوفات غير المكتملة": مرضى عملوا زيارة كشف مدفوعة (خدمة اسمها
// "كشف" بالظبط — ممكن يكون ليها أكتر من صف في جدول services حسب التخصص/الفئة،
// فبنطابق كل الصفوف دي مش صف واحد بس) لكن معندهمش أي زيارة تانية لأي خدمة
// غير الكشف طول تاريخهم — يعني اتكشفوا وما رجعوش يكملوا علاج. الفلترة بالفترة
// بتبقى على تاريخ زيارة الكشف نفسها، مش على أي حاجة تانية.

export type IncompleteCheckupRow = {
  visitId: number;
  patientName: string;
  fileNumber: string;
  checkupDate: string;
  doctorName: string;
  phone: string;
};

export type IncompleteCheckupResult =
  | { ok: false; error: string }
  | { ok: true; rows: IncompleteCheckupRow[] };

const DATE = /^\d{4}-\d{2}-\d{2}$/;

export async function getIncompleteCheckupReportAction(params: { from: string; to: string }): Promise<IncompleteCheckupResult> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "view_patient_reports"))) {
    return { ok: false, error: "مفيش صلاحية عندك لعرض تقرير الكشوفات غير المكتملة." };
  }
  if (!DATE.test(params.from) || !DATE.test(params.to)) {
    return { ok: false, error: "التاريخ غير صحيح." };
  }
  if (params.to < params.from) {
    return { ok: false, error: "تاريخ النهاية لازم يكون بعد تاريخ البداية." };
  }

  const checkupServices = await db.selectFrom("services").select(["id"]).where("name", "=", "كشف").execute();
  const checkupServiceIds = checkupServices.map((s) => s.id);
  if (!checkupServiceIds.length) return { ok: true, rows: [] };

  // زيارات الكشف المدفوعة في الفترة المختارة — "مدفوعة" يعني ليها فاتورة
  // بمبلغ محصّل (paid) أكبر من صفر، مش بس مسجّلة.
  const checkupVisits = await db
    .selectFrom("visits")
    .innerJoin("patients", "patients.id", "visits.patient_id")
    .innerJoin("invoices", "invoices.visit_id", "visits.id")
    .leftJoin("doctors", "doctors.id", "visits.performing_doctor_id")
    .select([
      "visits.id as visit_id",
      "visits.patient_id",
      "visits.visit_date",
      "patients.full_name as patient_name",
      "patients.file_number",
      "patients.phone",
      "doctors.full_name as doctor_name",
    ])
    .where("visits.service_id", "in", checkupServiceIds)
    .where("visits.visit_date", ">=", params.from)
    .where("visits.visit_date", "<=", `${params.to} 23:59:59`)
    .where("invoices.paid", ">", 0)
    .orderBy("visits.visit_date", "desc")
    .execute();

  if (!checkupVisits.length) return { ok: true, rows: [] };

  const patientIds = [...new Set(checkupVisits.map((v) => v.patient_id))];

  // أي زيارة تانية (غير الكشف) لنفس المرضى دول، طول تاريخهم بلا أي تقييد
  // بالفترة — عشان "لسه ما رجعش يكمل علاج" معناها إنه ماعملش أي خدمة تانية
  // خالص، مش بس في الفترة المختارة.
  const otherServiceVisits = await db
    .selectFrom("visits")
    .select(["patient_id"])
    .where("patient_id", "in", patientIds)
    .where((eb) => eb.or([eb("service_id", "is", null), eb("service_id", "not in", checkupServiceIds)]))
    .execute();
  const patientsWithOtherServices = new Set(otherServiceVisits.map((v) => v.patient_id));

  const rows: IncompleteCheckupRow[] = checkupVisits
    .filter((visit) => !patientsWithOtherServices.has(visit.patient_id))
    .map((visit) => ({
      visitId: visit.visit_id,
      patientName: visit.patient_name,
      fileNumber: visit.file_number,
      checkupDate: visit.visit_date.slice(0, 10),
      doctorName: visit.doctor_name || "—",
      phone: visit.phone || "—",
    }));

  return { ok: true, rows };
}
