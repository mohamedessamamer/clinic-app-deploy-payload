import Link from "next/link";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { redirect } from "next/navigation";
import { displayAge } from "@/lib/age";
import DeletePatientButton from "@/components/DeletePatientButton";
import { missingPatientDetails } from "@/lib/patient-details";
import { formatPatientPhone, normalizePhoneNumber } from "@/lib/phone";
import PatientsSearchBar from "@/components/PatientsSearchBar";

const PAGE_SIZE = 100;
type SortKey = "file_number" | "name";

export default async function PatientsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; page?: string; sort?: string; dir?: string }>;
}) {
  const { q, page: pageParam, sort: sortParam, dir: dirParam } = await searchParams;
  // ترقيم صفحات (100 مريض للصفحة) وترتيب (رقم الملف / الاسم أبجديًا، تصاعدي أو
  // تنازلي) بدل عرض كل المرضى في صفحة واحدة زي قبل كده. من غير sort في الـ URL
  // بيفضل الترتيب الافتراضي القديم (الأحدث أولًا) زي ما كان بالظبط.
  const sortKey: SortKey | null = sortParam === "file_number" || sortParam === "name" ? sortParam : null;
  const sortDir: "asc" | "desc" = dirParam === "desc" ? "desc" : "asc";
  const currentPage = Math.max(1, Number(pageParam) || 1);
  const session = await getSession();
  const isAdmin = session?.role === "admin";

  // نفس القاعدة الموحّدة من دفعة 8: "من أكونت الطبيب بيفتح الملف الطبي، من أي
  // أكونت تاني بيفتح الملف المالي" — لغاية دفعة 21 الصفحة دي كانت الاستثناء
  // الوحيد اللي بيفتح الملف الطبي لأي حد بغض النظر عن دوره، وده كان بيسبب لبس
  // للاستقبال (بيفتح الملف المالي من الجدول المركزي، بس الملف الطبي من هنا).
  // لو المستخدم مش دكتور بس مالوش صلاحية view_patient_billing فعليًا (نادر)،
  // بيرجع للملف الطبي كـ fallback عشان ميوصلش لصفحة "مفيش صلاحية" على طول.
  const isDoctorRole = session?.role === "doctor";
  // كانت الصلاحية دي مقتصرة على الطبيب بس (باقي الأدوار عندهم bypass)؛ بقت
  // صلاحية حقيقية لكل الأدوار — الأدمن بيعديها تلقائيًا (bypass الأدمن نفسه
  // في hasPermission)، وأي دور تاني لازم يتمنحله view_patients_list فرديًا.
  const canViewPatientsList = session ? await hasPermission(session.userId, session.role, "view_patients_list") : false;
  // إخفاء الرابط وحده لا يكفي: الطبيب الذي لم تُمنح له الصلاحية لا يستطيع فتح
  // قائمة كل المرضى حتى لو كتب الرابط يدويًا، بينما يظل قادرًا على فتح مريض
  // موعده من جدول اليوم والملف الطبي كما كان.
  if (!canViewPatientsList) redirect("/");
  const canViewBilling = session ? await hasPermission(session.userId, session.role, "view_patient_billing") : false;
  const patientHref = (id: number) => (!isDoctorRole && canViewBilling ? `/patients/${id}/billing` : `/patients/${id}`);

  const hasSearch = !!(q && q.trim());
  const term = hasSearch ? `%${q!.trim()}%` : null;
  const phoneDigits = hasSearch ? normalizePhoneNumber(q!.trim()) : "";
  const phoneTerm = phoneDigits ? `%${phoneDigits}%` : null;
  const applyFilter = <T extends { where: (...args: any[]) => any }>(qb: T): T =>
    term
      ? qb.where((eb: any) => {
          const conditions = [eb("full_name", "like", term), eb("file_number", "like", term)];
          if (phoneTerm) conditions.push(eb("phone", "like", phoneTerm));
          return eb.or(conditions);
        })
      : qb;

  const countRow = await applyFilter(
    db.selectFrom("patients").select(db.fn.countAll<number>().as("count"))
  ).executeTakeFirst();
  const totalCount = Number(countRow?.count ?? 0);
  const totalPages = Math.max(1, Math.ceil(totalCount / PAGE_SIZE));
  const safePage = Math.min(currentPage, totalPages);

  let listQuery = applyFilter(db.selectFrom("patients").selectAll());
  if (sortKey === "file_number") listQuery = listQuery.orderBy("file_number", sortDir);
  else if (sortKey === "name") listQuery = listQuery.orderBy("full_name", sortDir);
  else listQuery = listQuery.orderBy("id", "desc");
  const patients = await listQuery
    .limit(PAGE_SIZE)
    .offset((safePage - 1) * PAGE_SIZE)
    .execute();

  // بناء لينك التبويب/الترتيب مع الحفاظ على باقي البارامترز (q) — الترقيم بيرجع
  // لصفحة 1 عند أي تغيير في الترتيب.
  const buildHref = (params: { page?: number; sort?: SortKey; dir?: "asc" | "desc" }) => {
    const usp = new URLSearchParams();
    if (q && q.trim()) usp.set("q", q.trim());
    const nextSort = params.sort ?? sortKey ?? undefined;
    const nextDir = params.dir ?? sortDir;
    if (nextSort) {
      usp.set("sort", nextSort);
      usp.set("dir", nextDir);
    }
    const nextPage = params.page ?? safePage;
    if (nextPage > 1) usp.set("page", String(nextPage));
    const qs = usp.toString();
    return `/patients${qs ? `?${qs}` : ""}`;
  };

  const sortHref = (key: SortKey) => {
    const nextDir: "asc" | "desc" = sortKey === key && sortDir === "asc" ? "desc" : "asc";
    return buildHref({ sort: key, dir: nextDir, page: 1 });
  };

  const sortIndicator = (key: SortKey) => (sortKey === key ? (sortDir === "asc" ? " ▲" : " ▼") : "");

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 flex-wrap">
        <h1 className="text-xl font-bold whitespace-nowrap">ملفات المرضى</h1>
        <PatientsSearchBar initialQuery={q ?? ""} />
        <Link href="/patients/new" className="px-3 py-2 rounded-md btn-3d-primary text-sm whitespace-nowrap">
          + مريض جديد
        </Link>
      </div>

      <div className="text-xs text-muted">
        {totalCount} مريض{hasSearch ? " مطابق للبحث" : ""} — صفحة {safePage} من {totalPages}
      </div>

      <div className="card-3d rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-primary-soft text-primary-dark">
            <tr>
              <th className="text-right px-4 py-2 font-medium">
                <Link href={sortHref("file_number")} className="hover:underline">
                  رقم الملف{sortIndicator("file_number")}
                </Link>
              </th>
              <th className="text-right px-4 py-2 font-medium">
                <Link href={sortHref("name")} className="hover:underline">
                  الاسم{sortIndicator("name")}
                </Link>
              </th>
              <th className="text-right px-4 py-2 font-medium">السن</th>
              <th className="text-right px-4 py-2 font-medium">التليفون</th>
              <th className="px-4 py-2"></th>
            </tr>
          </thead>
          <tbody>
            {patients.map((p) => (
              <tr key={p.id} className="border-t border-border hover:bg-background">
                <td className="px-4 py-2 text-muted">{p.file_number}</td>
                <td className="px-4 py-2 font-medium">
                  <Link href={patientHref(p.id)} className="hover:text-primary hover:underline">
                    {p.full_name}
                  </Link>
                  {missingPatientDetails(p).length > 0 && (
                    <span className="mr-2 inline-flex rounded-full bg-amber-100 px-2 py-0.5 text-[11px] font-medium text-amber-800">
                      بيانات ناقصة
                    </span>
                  )}
                </td>
                <td className="px-4 py-2">{displayAge(p) ?? "-"}</td>
                <td className="px-4 py-2" dir="ltr">{formatPatientPhone(p.phone_country_code, p.phone) ?? "-"}</td>
                <td className="px-4 py-2 text-left">
                  <div className="flex items-center justify-end gap-3">
                    {/* لينك "فتح الملف" المنفصل اتشال (دفعة 21) — بقى مكرر مع الدوسة على
                        الاسم بعد ما بقى النظام كله تاب واحد. */}
                    {/* حذف حالة نهائيًا - للأدمن بس، أساسًا لتنظيف حالات تجربة (test) بعد
                        الانتهاء منها. */}
                    {isAdmin && <DeletePatientButton patientId={p.id} patientName={p.full_name} />}
                  </div>
                </td>
              </tr>
            ))}
            {patients.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-muted">
                  لا يوجد مرضى مطابقين.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 text-sm">
          <Link
            href={buildHref({ page: Math.max(1, safePage - 1) })}
            aria-disabled={safePage <= 1}
            className={`px-3 py-1.5 rounded-md border border-border ${safePage <= 1 ? "pointer-events-none opacity-40" : "hover:bg-primary-soft"}`}
          >
            السابق
          </Link>
          <span className="text-muted">صفحة {safePage} من {totalPages}</span>
          <Link
            href={buildHref({ page: Math.min(totalPages, safePage + 1) })}
            aria-disabled={safePage >= totalPages}
            className={`px-3 py-1.5 rounded-md border border-border ${safePage >= totalPages ? "pointer-events-none opacity-40" : "hover:bg-primary-soft"}`}
          >
            التالي
          </Link>
        </div>
      )}
    </div>
  );
}
