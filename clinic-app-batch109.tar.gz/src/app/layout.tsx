import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import NavBar from "@/components/NavBar";
import WhatsAppOAuthRelay from "@/components/WhatsAppOAuthRelay";
import { db } from "@/lib/db/client";
import { getNotificationCenter } from "@/lib/notifications";
import { getSetting } from "@/lib/settings";

export const metadata: Metadata = {
  title: "نظام إدارة العيادة",
  description: "Designed around your comfort",
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const session = await getSession();
  // ظهور لينك "التقارير" مبني على صلاحية فعلية (reports_full/reports_own) مش
  // على الدور الثابت زي باقي اللينكات — عشان الصلاحيتين دول قابلين للمنح/السحب
  // لأي مستخدم لوحده من الإعدادات، مش مرتبطين بدور واحد بس.
  const canViewReports = session ? (await Promise.all([
    "reports_full", "reports_own", "view_whatsapp_reminder_report", "view_patient_reports"
  ].map((key) => hasPermission(session.userId, session.role, key as import("@/lib/permission-defs").PermissionKey)))).some(Boolean) : false;
  // نفس الفكرة للينك "المخزن" — مبني على صلاحية manage_inventory القابلة للمنح،
  // مش على دور ثابت (كان قبل كده hardcoded لأدمن/استقبال بس، من غير أي تحقق
  // حقيقي في الصفحة نفسها).
  const canViewInventory = session ? await hasPermission(session.userId, session.role, "manage_inventory") : false;
  const canViewExpenses = session ? await hasPermission(session.userId, session.role, "manage_expenses") : false;
  const canManageHr = session ? await hasPermission(session.userId, session.role, "manage_hr") : false;
  const canManageWhatsapp = session ? (await Promise.all([
    "manage_whatsapp", "whatsapp_manual_send", "whatsapp_manual_templates", "whatsapp_automation", "whatsapp_meta_connection", "whatsapp_meta_conversations", "whatsapp_meta_templates", "whatsapp_meta_sync"
  ].map((key) => hasPermission(session.userId, session.role, key as import("@/lib/permission-defs").PermissionKey)))).some(Boolean) : false;
  // رابط المرضى بقى صلاحية حقيقية لكل الأدوار مش بس الطبيب — الأدمن بيشوفه
  // تلقائيًا (bypass الأدمن في hasPermission)، وأي دور تاني (استقبال، محاسب،
  // مدير عيادة، طبيب) لازم يتمنحله view_patients_list فرديًا من الإعدادات.
  const canViewPatients = session ? await hasPermission(session.userId, session.role, "view_patients_list") : false;
  const [accountPreferences, initialNotifications, chatNotificationSound] = session
    ? await Promise.all([
        db.selectFrom("users").select(["medical_ui_language", "color_theme"]).where("id", "=", session.userId).executeTakeFirst(),
        getNotificationCenter(session.userId),
        getSetting("chat_notification_sound"),
      ])
    : [undefined, [] as Awaited<ReturnType<typeof getNotificationCenter>>, "gentle_bell"];
  const medicalUiLanguage: "en" | "ar" = accountPreferences?.medical_ui_language === "ar" ? "ar" : "en";
  const colorTheme: "revere" | "medical" = accountPreferences?.color_theme === "medical" ? "medical" : "revere";

  return (
    <html lang="ar" dir="rtl" className="h-full antialiased">
      <body data-color-theme={colorTheme} className="min-h-full font-sans">
        <WhatsAppOAuthRelay />
        {session && <NavBar session={session} canViewReports={canViewReports} canViewInventory={canViewInventory} canViewExpenses={canViewExpenses} canManageHr={canManageHr} canViewPatients={canViewPatients} canManageWhatsapp={canManageWhatsapp} medicalUiLanguage={medicalUiLanguage} colorTheme={colorTheme} initialNotifications={initialNotifications} chatNotificationSound={chatNotificationSound} />}
        <main className="app-shell-main">{children}</main>
      </body>
    </html>
  );
}
