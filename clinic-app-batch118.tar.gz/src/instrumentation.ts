export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs" || process.env.NEXT_PHASE === "phase-production-build") return;
  const { startAppointmentReminderScheduler } = await import("@/lib/whatsapp/appointment-reminders");
  const { archiveInactivePatients } = await import("@/lib/patient-archive");
  startAppointmentReminderScheduler();
  const scheduler = globalThis as typeof globalThis & { __clinicPatientArchiveTimer?: ReturnType<typeof setInterval> };
  const runArchive = () => archiveInactivePatients().catch((error) => console.error("[patient-archive]", error instanceof Error ? error.message : error));
  runArchive();
  if (!scheduler.__clinicPatientArchiveTimer) {
    const timer = setInterval(runArchive, 6 * 60 * 60 * 1000);
    timer.unref?.();
    scheduler.__clinicPatientArchiveTimer = timer;
  }
}
