#!/usr/bin/env node
// اختبار محلي لـ /api/whatsapp/webhook: بيبني payload شكله زي رسالة واتساب
// واردة حقيقية، يوقّعه بـX-Hub-Signature-256 (بنفس الطريقة اللي Meta بتستخدمها)،
// ويبعته للسيرفر المحلي. يساعد في التحقق من التحقق من التوقيع + منطق التخزين
// من غير الحاجة لحساب Meta فعلي متصل وقت التطوير.
//
// الاستخدام:
//   WHATSAPP_APP_SECRET=xxx node scripts/test-whatsapp-webhook.js [base_url]
//
// ملاحظة: السكريبت ده بيفترض إن فيه حساب whatsapp_accounts متصل بالفعل في
// قاعدة البيانات المحلية (عن طريق Connect Button فعلي، أو إدخال يدوي وقت
// الاختبار) — من غيره الـwebhook هيرد 200 بس مش هيسجل أي رسالة (شوف
// التعليق في route.ts).

const crypto = require("node:crypto");

const appSecret = process.env.WHATSAPP_APP_SECRET;
if (!appSecret) {
  console.error("لازم تحدد WHATSAPP_APP_SECRET كمتغير بيئة للسكريبت ده (نفس القيمة الموجودة في .env.production محليًا).");
  process.exit(1);
}

const baseUrl = process.argv[2] || "http://localhost:3000";

const payload = {
  object: "whatsapp_business_account",
  entry: [
    {
      id: "TEST_WABA_ID",
      changes: [
        {
          field: "messages",
          value: {
            messaging_product: "whatsapp",
            metadata: { display_phone_number: "15550000000", phone_number_id: "TEST_PHONE_NUMBER_ID" },
            contacts: [{ profile: { name: "مريض تجريبي" }, wa_id: "201000000000" }],
            messages: [
              {
                from: "201000000000",
                id: `wamid.TEST_${Date.now()}`,
                timestamp: String(Math.floor(Date.now() / 1000)),
                type: "text",
                text: { body: "السلام عليكم، عايز أعرف مواعيد العيادة" },
              },
            ],
          },
        },
      ],
    },
  ],
};

const rawBody = JSON.stringify(payload);
const signature = "sha256=" + crypto.createHmac("sha256", appSecret).update(rawBody, "utf8").digest("hex");

fetch(`${baseUrl}/api/whatsapp/webhook`, {
  method: "POST",
  headers: { "Content-Type": "application/json", "X-Hub-Signature-256": signature },
  body: rawBody,
})
  .then(async (res) => {
    console.log("status:", res.status);
    console.log("body:", await res.text());
  })
  .catch((err) => {
    console.error("فشل الطلب:", err.message);
    process.exit(1);
  });
