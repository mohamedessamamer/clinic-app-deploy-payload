# تكامل WhatsApp Cloud API — عيادة د. محمد عصام عامر

هذا المستند يوثّق كل حاجة لازمة لتشغيل تكامل واتساب: متغيرات البيئة، خطوات
الحصول على بيانات Meta، النشر على السيرفر، وخطوات App Review بما فيها الفيديوهين
المطلوبين. **لا تحتوي أي قيمة سرية فعلية في هذا الملف أو في الكود.**

## 1) نظرة عامة على ما تم بناؤه

- **قاعدة البيانات**: 5 جداول جديدة في `src/lib/db/schema.sql`:
  - `whatsapp_accounts` — حساب واتساب متصل (WABA ID، Phone Number ID، التوكن **مشفّر**، حالة الاتصال، Coexistence أم لا).
  - `whatsapp_contacts` — جهات الاتصال (أرقام المرضى اللي راسلوا الرقم).
  - `whatsapp_messages` — كل رسالة واردة/صادرة، بمعرف Meta الفريد (`wamid`) لمنع التكرار.
  - `whatsapp_message_templates` — القوالب المُنشأة من داخل السيستم وحالتها عند Meta.
  - `whatsapp_webhook_events` — سجل idempotency لكل حدث webhook (يمنع معالجة نفس الحدث مرتين لو Meta أعادت الإرسال).
- **الكود**: `src/lib/whatsapp/` (إعدادات، تشفير، Graph API، تحقق التوقيع، تخزين)، `src/app/api/whatsapp/webhook/route.ts` (الـwebhook العام)، `src/app/whatsapp/` (الصفحة + Server Actions)، ومكونات `src/components/WhatsApp*.tsx`.
- **صلاحية جديدة**: `manage_whatsapp` (مجموعة "الإدارة والتواصل" في الإعدادات) — امنحها لأي مستخدم غير الأدمن يحتاج يدخل صفحة واتساب.
- تم فحص الكود بـ `tsc --noEmit` و`eslint` من غير أخطاء. الاختبار الكامل مع Meta الفعلي لسه محتاج بيانات حساب حقيقية (خطوة 3 تحت).

## 2) متغيرات البيئة المطلوبة

انسخ محتوى `.env.whatsapp.example` (في جذر المشروع) لملف `.env.production` الموجود
على السيرفر، واملأ القيم. **لا تلصق أي قيمة سرية في المحادثة مع أي مساعد ذكاء
اصطناعي أو في Git.**

| المتغير | سري؟ | المصدر |
|---|---|---|
| `WHATSAPP_APP_ID` | لا | Meta App Dashboard — ثابت: `1975222643113788` |
| `WHATSAPP_APP_SECRET` | **نعم** | Meta App Dashboard → App Settings → Basic → Show |
| `WHATSAPP_CONFIG_ID` | لا | Meta App Dashboard — ثابت: `2894880867537953` |
| `NEXT_PUBLIC_WHATSAPP_APP_ID` | لا | نفس `WHATSAPP_APP_ID` (لازم للـfrontend) |
| `NEXT_PUBLIC_WHATSAPP_CONFIG_ID` | لا | نفس `WHATSAPP_CONFIG_ID` |
| `NEXT_PUBLIC_WHATSAPP_GRAPH_VERSION` | لا | `v23.0` أو أحدث إصدار متاح وقت النشر |
| `WHATSAPP_WEBHOOK_VERIFY_TOKEN` | **نعم** (لكن مش سري بنفس درجة App Secret) | من اختيارك: `openssl rand -hex 24` |
| `WHATSAPP_TOKEN_ENC_KEY` | **نعم** | `openssl rand -base64 32` |
| `WHATSAPP_GRAPH_VERSION` | لا | `v23.0` |

بعد إضافتهم:
```bash
chmod 600 .env.production
sudo systemctl restart clinic-app   # أو اسم الـservice الفعلي على السيرفر
```

`NEXT_PUBLIC_*` بيتحطوا في الكود وقت الـbuild (مش runtime) — لازم `pnpm build`/`npm run build` يتشغل بعد ما تتحط القيم دي في `.env.production` عشان تتضمن فعليًا في الـbundle.

## 3) خطوات الحصول على بيانات Meta (تتعمل مع بعض دلوقتي)

1. **App Secret**: Meta App Dashboard → التطبيق (App ID: `1975222643113788`) → App Settings → Basic → Show بجانب App Secret.
2. **Test WABA / رقم Meta التجريبي**: WhatsApp → API Setup (أو "Getting Started") داخل نفس التطبيق — بتلاقي هناك:
   - Test number (رقم Meta الجاهز، بدون تسجيل).
   - WABA ID و Phone Number ID الخاصين بيه (ظاهرين في نفس الصفحة).
   - إمكانية إضافة رقمك الشخصي كـ"مستقبِل مسموح له" (Recipient) للاختبار.
3. **Permanent System User Access Token**: هذا **لن يُنشأ إلا بتأكيدك** —
   Business Settings → Users → System Users → إنشاء System User (أو استخدام
   موجود) → Add Assets → اختيار الـWABA → صلاحية Full control → Generate
   Token → اختيار صلاحيات `whatsapp_business_messaging` + `whatsapp_business_management`
   بدون تاريخ انتهاء. **لما توصل للخطوة دي فعليًا، وقّف واطلب مني (أو من مين
   بيدير حساب Meta) تنفيذها، والتوكن يتحط مباشرة في `.env.production` على
   السيرفر من غير ما ينسخ في أي محادثة.** الطريقة العملية الموصى بها فعليًا في
   هذا التكامل هي عدم إنشاء توكن يدوي إطلاقًا، والاعتماد بدلاً منه على توكن
   Embedded Signup الناتج تلقائيًا من زرار "Connect WhatsApp" (خطوة 4) —
   يُخزَّن مشفّرًا في قاعدة البيانات، فلا حاجة لنسخ أي توكن يدويًا في العادة.

## 4) ربط الحساب من داخل النظام (Embedded Signup)

بعد نشر الكود وضبط متغيرات البيئة:

1. سجّل دخول كأدمن → افتح `/whatsapp`.
2. اضغط **"Connect WhatsApp (رقم تجريبي)"** أولاً — هيفتح نافذة Meta، اختر
   Business Portfolio: **"Amer Orthodontics new"** (الجديد، مش القديم إطلاقًا)،
   واختر رقم Meta التجريبي. النظام هيستقبل WABA ID و Phone Number ID تلقائيًا،
   يبادل الـcode بتوكن، يشترك في أحداث الـWABA، ويخزّن كل حاجة مشفّرة.
3. رقم العيادة الحقيقي **لا يُربط إلا بعد التأكد الكامل** من Coexistence —
   الزرار التاني في نفس الصفحة يطلب تأكيد صريح (checkbox) قبل ما يفعّل، ويستخدم
   `featureType=whatsapp_business_app_onboarding` وهو المسار الرسمي من Meta
   اللي بيسيب تطبيق WhatsApp Business شغال عادي على موبايل الاستقبال.
   **متعملش الخطوة دي إلا بعد ما نتأكد سوا إن الاختبار الأول (الرقم التجريبي)
   نجح بالكامل.**

## 5) ضبط الـWebhook في Meta App Dashboard

WhatsApp → Configuration → Webhook:

- **Callback URL**: `https://clinicsys.revereeg.com/api/whatsapp/webhook`
- **Verify token**: نفس قيمة `WHATSAPP_WEBHOOK_VERIFY_TOKEN`
- **Webhook fields** (اشترك فيهم بالتحديد):
  - `messages`
  - `message_template_status_update` (لمعرفة اعتماد/رفض القوالب)
  - `smb_message_echoes`
  - `smb_app_state_sync`
  - `history` (لو ظاهر متاح لتطبيقك — بعض الحسابات محتاجة موافقة Meta إضافية عليه)

بعد الضبط، Meta هتبعت GET verification request فورًا — الـroute جاهز يرد عليه
(`src/app/api/whatsapp/webhook/route.ts`، دالة `GET`).

## 6) اختبار محلي قبل النشر

```bash
npm run dev   # أو pnpm dev
# في نافذة تانية:
WHATSAPP_APP_SECRET=<نفس القيمة المحلية> node scripts/test-whatsapp-webhook.js
```

السكريبت ده بيبني رسالة واردة تجريبية موقّعة بنفس طريقة Meta، ويبعتها للـwebhook
المحلي. لازم يكون فيه حساب `whatsapp_accounts` متصل بالفعل (من خطوة Embedded
Signup) عشان الرسالة تتسجل فعليًا.

اختبار إرسال حقيقي: من صفحة `/whatsapp`، ابعت رسالة لرقمك الشخصي (المضاف كـ
Recipient في Meta Dashboard) وتأكد من وصولها ومن تحديث حالتها (sent → delivered
→ read) في الواجهة.

## 7) خطوات App Review + الفيديوهين المطلوبين

الصلاحيات المطلوبة: `whatsapp_business_messaging`, `whatsapp_business_management`.

**الفيديو الأول — إرسال رسالة ووصولها لواتساب:**
1. افتح `/whatsapp` وسجّل الشاشة.
2. اضغط على محادثة (أو ابدأ واحدة جديدة لرقمك الشخصي المسموح بيه).
3. اكتب رسالة واضغط إرسال.
4. بدّل لموبايل فيه واتساب على نفس الرقم الشخصي، وأظهر وصول الرسالة فعليًا
   (مع ظهور اسم/رقم العيادة كمرسل).
5. ارجع للسيستم وأظهر تحديث الحالة لـ"sent"/"delivered".

**الفيديو الثاني — إنشاء Message Template من السيستم:**
1. من نفس الصفحة، قسم "قوالب الرسائل".
2. املأ نموذج إنشاء قالب (اسم بالإنجليزي، لغة، تصنيف Utility، نص الرسالة).
3. اضغط "إنشاء القالب في Meta" وأظهر ظهوره في القايمة بحالة "قيد المراجعة".
4. (اختياري لو الوقت سمح) افتح Meta Business Manager → WhatsApp Manager →
   Message Templates وأظهر نفس القالب هناك لإثبات إنه فعلاً اتسجل عند Meta.

**قبل التسجيل:**
- تأكد إن الحساب المتصل وقتها هو **رقم Meta التجريبي فقط**، مش رقم العيادة.
- رابط سياسة الخصوصية جاهز: https://revereeg.com/privacy-policy.html — لازم يكون
  مربوط في إعدادات التطبيق (App Settings → Basic → Privacy Policy URL) قبل تقديم
  المراجعة.
- في نموذج App Review، اشرح بوضوح: "نظام إدارة عيادة أسنان يستخدم واتساب
  لإرسال تذكيرات المواعيد وقوالب رسائل معتمدة للمرضى، ويدعم Coexistence مع
  تطبيق WhatsApp Business الحالي لرقم العيادة."

## 8) الأمان — ما تم تطبيقه

- **لا نصوص صريحة لأي توكن**: `access_token` يُشفّر (AES-256-GCM) قبل التخزين
  في قاعدة البيانات (`src/lib/whatsapp/crypto.ts`)، ومفتاح التشفير نفسه في
  `.env.production` على السيرفر بس. `App Secret` و`Verify Token` أيضًا في
  `.env.production` فقط، أبدًا في الكود أو قاعدة البيانات.
- **بدون تسجيل أسرار**: كل رسائل الـlog في الكود (`console.warn`/`console.error`)
  تطبع رسالة الخطأ العامة بس، أبدًا الـheaders أو الـbody الخام اللي ممكن يحتوي
  توكن.
- **تحقق توقيع الـwebhook**: `X-Hub-Signature-256` يتحقق منه على الـraw body
  بمقارنة زمنية آمنة (`crypto.timingSafeEqual`) قبل أي معالجة — طلب بتوقيع غلط
  يترفض 403 فورًا.
- **منع التكرار**: `whatsapp_webhook_events.event_key` (UNIQUE) لأي حدث webhook،
  و`whatsapp_messages.wamid` (UNIQUE) لأي رسالة — أي إعادة إرسال من Meta تتجاهل
  تلقائيًا.
- **صلاحيات داخل النظام**: صفحة واتساب وكل الـServer Actions بتاعتها محمية
  بصلاحية `manage_whatsapp` (افتراضيًا للأدمن بس، قابلة للمنح لغيره من الإعدادات).
- **Business Portfolio القديم**: لا يوجد أي كود في هذا التكامل يلمس أو ينقل أي
  أصل من الـportfolio القديم — كل عمليات الربط تمر فقط عن طريق Embedded Signup
  اللي بيحدد الـPortfolio والـWABA بمعرفة المستخدم وقت الربط نفسه.

## 9) Coexistence — ماذا يعني عمليًا

Coexistence وضع رسمي من Meta بيسمح لرقم بيستخدم حاليًا تطبيق WhatsApp Business
العادي (زي رقم العيادة عند السكرتارية) إنه يتصل بالـCloud API **من غير ما يوقف
التطبيق عن الشغل**. الفرق عن الربط العادي:

- الربط بيتم باختيار `featureType=whatsapp_business_app_onboarding` في نافذة
  Embedded Signup (مش أي مسار تاني).
- **لا** يتم نقل الرقم أو "تسجيله" في Cloud API-only mode (اللي كان هيوقف تطبيق
  WhatsApp Business نهائيًا).
- بعد الربط، الرسائل اللي بتتبعت من موبايل السكرتارية (تطبيق WhatsApp Business)
  بتوصل النظام كـ`smb_message_echoes` (بتتسجل للعرض في المحادثة، مش بترسل تاني).
- تاريخ المحادثات القديم بيوصل عن طريق حدث `history` (لو Meta فعّلته للحساب).

هذا الكود **لا يربط رقم العيادة الحقيقي تلقائيًا بأي حال** — الربط بيحصل فقط
لما مستخدم أدمن يضغط الزرار المخصص بعد تأكيد صريح (checkbox) في الواجهة.

## 10) ما لم يُنفَّذ بعد / قرارات مفتوحة

- لسه محتاجين **Test WABA ID + Phone Number ID فعليين** من Meta Dashboard
  (خطوة 3 فوق) — الكود جاهز يستقبلهم تلقائيًا أول ما تضغط "Connect".
- إنشاء **Permanent System User Token يدوي** لسه معلّق لحد تأكيدك — التصميم
  الحالي أصلاً بيعتمد على توكن Embedded Signup (مش محتاج توكن يدوي عادةً)، إلا
  لو حبيت مسار احتياطي إضافي.
- الفحص الفعلي مع Meta (إرسال/استقبال حقيقي، إنشاء قالب حقيقي) لسه محتاج ربط
  فعلي بالخطوات فوق — تم التحقق برمجيًا من: التشفير/فك التشفير، تحقق التوقيع،
  و`tsc`/`eslint` نظيفين على كل الملفات الجديدة (لم يتيسّر تشغيل `better-sqlite3`
  الأصلي في بيئة الإعداد الحالية بسبب حجب الشبكة لتنزيل رؤوس Node — يعمل عاديًا
  على السيرفر/جهازك المحلي).
