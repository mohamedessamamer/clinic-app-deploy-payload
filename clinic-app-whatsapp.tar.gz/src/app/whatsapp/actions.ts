"use server";

import { revalidatePath } from "next/cache";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import * as graph from "@/lib/whatsapp/graph";
import * as store from "@/lib/whatsapp/store";

async function requireWhatsappAccess() {
  const session = await getSession();
  if (!session) return null;
  if (!(await hasPermission(session.userId, session.role, "manage_whatsapp"))) return null;
  return session;
}

// خطوة إكمال Embedded Signup: الـfrontend (WhatsAppConnectButton) بيستقبل
// { code, wabaId, phoneNumberId, businessId } من نافذة واتساب (postMessage) وبيبعتهم
// هنا. السيرفر بس هو اللي بيعمل تبادل الـcode بتوكن فعلي (client secret لازم
// يفضل سيرفر بس)، ثم يشترك في أحداث الـWABA، ثم يخزّن الحساب مشفّرًا.
//
// coexistence: true لو ده رقم العيادة الحقيقي متصل عن طريق WhatsApp Business
// App Coexistence (المستخدم أكّد صراحة إنه عايز كده)، false لو رقم Meta
// التجريبي وقت التطوير/المراجعة. الـcaller (الزرار في الواجهة) هو اللي بيحدد
// القيمة دي بناءً على اختيار واضح للمستخدم — مفيش تخمين هنا.
export async function completeEmbeddedSignupAction(params: {
  code: string;
  wabaId: string;
  phoneNumberId: string;
  businessId?: string;
  coexistence: boolean;
  environment: "test" | "production";
}) {
  const session = await requireWhatsappAccess();
  if (!session) return { ok: false, error: "غير مصرح" };

  try {
    const tokenResult = await graph.exchangeCodeForToken(params.code);
    const accessToken = tokenResult.access_token;

    await graph.subscribeAppToWaba(params.wabaId, accessToken);

    let displayNumber: string | null = null;
    let verifiedName: string | null = null;
    try {
      const phones = await graph.getWabaPhoneNumbers(params.wabaId, accessToken);
      const match = phones.data.find((p) => p.id === params.phoneNumberId);
      displayNumber = match?.display_phone_number ?? null;
      verifiedName = match?.verified_name ?? null;
    } catch {
      // مش حرج — الربط نجح والاشتراك في الأحداث حصل، بيانات العرض دي تجميلية بس.
    }

    await store.upsertAccountFromSignup({
      wabaId: params.wabaId,
      phoneNumberId: params.phoneNumberId,
      displayPhoneNumber: displayNumber,
      verifiedName,
      businessId: params.businessId ?? null,
      accessToken,
      coexistence: params.coexistence,
      environment: params.environment,
      connectedBy: session.userId,
    });

    revalidatePath("/whatsapp");
    return { ok: true };
  } catch (err) {
    // رسالة الخطأ بترجع للواجهة (مفيدة للمستخدم) لكن أي حاجة شبه توكن اتفلترت
    // فعليًا من رسائل graph.ts نفسها (بترجع رسالة Meta المنظمة بس، مش أي header).
    const message = err instanceof Error ? err.message : "فشل ربط واتساب";
    return { ok: false, error: message };
  }
}

export async function getAccountStatusAction() {
  const session = await requireWhatsappAccess();
  if (!session) return null;
  const account = await store.getActiveAccount();
  if (!account) return null;
  return {
    id: account.id,
    displayPhoneNumber: account.display_phone_number,
    verifiedName: account.verified_name,
    environment: account.environment,
    coexistenceMode: account.coexistence_mode === 1,
    connectionStatus: account.connection_status,
    connectedAt: account.connected_at,
  };
}

export async function listConversationsAction() {
  const session = await requireWhatsappAccess();
  if (!session) return [];
  const account = await store.getActiveAccount();
  if (!account) return [];
  const rows = await store.listConversations(account.id);
  return rows.map((r) => ({ id: r.id, waId: r.wa_id, profileName: r.profile_name, lastMessageAt: r.last_message_at }));
}

export async function listMessagesAction(contactId: number) {
  const session = await requireWhatsappAccess();
  if (!session) return [];
  const rows = await store.listMessagesForContact(contactId);
  return rows.map((r) => ({
    id: r.id,
    direction: r.direction,
    body: r.body,
    status: r.status,
    isEcho: r.is_echo === 1,
    createdAt: r.created_at,
  }));
}

export async function sendMessageAction(formData: FormData) {
  const session = await requireWhatsappAccess();
  if (!session) return { ok: false, error: "غير مصرح" };
  const contactId = Number(formData.get("contact_id"));
  const body = String(formData.get("body") ?? "").trim();
  if (!contactId || !body) return { ok: false, error: "بيانات ناقصة" };

  const account = await store.getActiveAccount();
  if (!account) return { ok: false, error: "لا يوجد حساب واتساب متصل" };

  const contact = (await store.listConversations(account.id)).find((c) => c.id === contactId);
  if (!contact) return { ok: false, error: "المحادثة غير موجودة" };

  try {
    const accessToken = await store.getAccountAccessToken(account.id);
    const result = await graph.sendTextMessage(account.phone_number_id, accessToken, contact.wa_id, body);
    await store.recordOutboundMessage({
      accountId: account.id,
      contactId,
      wamid: result.messages?.[0]?.id ?? null,
      body,
      sentBy: session.userId,
      status: "sent",
    });
    await store.touchContactLastMessage(contactId, new Date().toISOString());
    revalidatePath("/whatsapp");
    return { ok: true };
  } catch (err) {
    const message = err instanceof Error ? err.message : "فشل الإرسال";
    await store.recordOutboundMessage({
      accountId: account.id,
      contactId,
      wamid: null,
      body,
      sentBy: session.userId,
      status: "failed",
      errorMessage: message,
    });
    revalidatePath("/whatsapp");
    return { ok: false, error: message };
  }
}

export async function listTemplatesAction() {
  const session = await requireWhatsappAccess();
  if (!session) return [];
  const account = await store.getActiveAccount();
  if (!account) return [];
  const rows = await store.listTemplateRows(account.id);
  return rows.map((r) => ({
    id: r.id,
    name: r.name,
    language: r.language,
    category: r.category,
    bodyText: r.body_text,
    status: r.status,
    rejectedReason: r.rejected_reason,
  }));
}

export async function createTemplateAction(formData: FormData) {
  const session = await requireWhatsappAccess();
  if (!session) return { ok: false, error: "غير مصرح" };
  const name = String(formData.get("name") ?? "").trim().toLowerCase().replace(/[^a-z0-9_]/g, "_");
  const language = String(formData.get("language") ?? "ar");
  const category = String(formData.get("category") ?? "UTILITY");
  const bodyText = String(formData.get("body_text") ?? "").trim();
  if (!name || !bodyText) return { ok: false, error: "بيانات ناقصة" };

  const account = await store.getActiveAccount();
  if (!account) return { ok: false, error: "لا يوجد حساب واتساب متصل" };

  try {
    const accessToken = await store.getAccountAccessToken(account.id);
    const result = await graph.createMessageTemplate(account.waba_id, accessToken, { name, language, category, bodyText });
    await store.upsertTemplateRow({
      accountId: account.id,
      metaTemplateId: result.id,
      name,
      language,
      category,
      bodyText,
      status: result.status?.toLowerCase() || "pending",
      createdBy: session.userId,
    });
    revalidatePath("/whatsapp");
    return { ok: true };
  } catch (err) {
    const message = err instanceof Error ? err.message : "فشل إنشاء القالب";
    return { ok: false, error: message };
  }
}

// تحديث حالات القوالب من Meta (Approved/Rejected بتتحدد بعد المراجعة، مش وقت
// الإنشاء) — زرار "تحديث الحالة" في الواجهة بينادي عليها.
export async function refreshTemplateStatusesAction() {
  const session = await requireWhatsappAccess();
  if (!session) return { ok: false, error: "غير مصرح" };
  const account = await store.getActiveAccount();
  if (!account) return { ok: false, error: "لا يوجد حساب واتساب متصل" };
  try {
    const accessToken = await store.getAccountAccessToken(account.id);
    const remote = await graph.listTemplates(account.waba_id, accessToken);
    for (const t of remote.data) {
      await store.updateTemplateStatus(account.id, t.name, t.language, t.status.toLowerCase(), t.rejected_reason);
    }
    revalidatePath("/whatsapp");
    return { ok: true };
  } catch (err) {
    const message = err instanceof Error ? err.message : "فشل تحديث حالة القوالب";
    return { ok: false, error: message };
  }
}
