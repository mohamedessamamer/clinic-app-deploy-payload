"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { completeEmbeddedSignupAction } from "@/app/whatsapp/actions";

// Meta Embedded Signup (Facebook Login for Business, config_id-based) — بيفتح
// popup فيه واجهة Meta نفسها. إحنا مش شايفين أي بيانات دخول Meta، بس بنستقبل
// { code } في نهاية العملية عن طريق FB.login callback، وبيانات الـWABA/الرقم
// عن طريق postMessage من نافذة الـsignup (شكل رسمي موثّق من Meta، شوف
// docs/WHATSAPP_INTEGRATION.md#embedded-signup).
//
// featureType=whatsapp_business_app_onboarding هو المسار المطلوب لـCoexistence
// (رقم العيادة الحالي يفضل شغال على تطبيق WhatsApp Business في نفس الوقت).
// المسار التاني (من غير featureType) هو onboarding عادي لرقم Cloud API — ده
// اللي بنستخدمه لرقم Meta التجريبي وقت التطوير وApp Review.

declare global {
  interface Window {
    FB?: {
      init: (params: { appId: string; autoLogAppEvents: boolean; xfbml: boolean; version: string }) => void;
      login: (
        callback: (response: { authResponse?: { code?: string } }) => void,
        options: { config_id: string; response_type: string; override_default_response_type: boolean; extras?: Record<string, unknown> }
      ) => void;
    };
    fbAsyncInit?: () => void;
  }
}

type SignupData = { waba_id?: string; phone_number_id?: string; business_id?: string };

function loadFacebookSdk(appId: string, version: string): Promise<void> {
  return new Promise((resolve) => {
    if (window.FB) {
      resolve();
      return;
    }
    window.fbAsyncInit = () => {
      window.FB!.init({ appId, autoLogAppEvents: true, xfbml: false, version });
      resolve();
    };
    if (document.getElementById("facebook-jssdk")) return;
    const script = document.createElement("script");
    script.id = "facebook-jssdk";
    script.src = "https://connect.facebook.net/en_US/sdk.js";
    script.async = true;
    document.body.appendChild(script);
  });
}

export default function WhatsAppConnectButton() {
  const [status, setStatus] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [confirmCoexistence, setConfirmCoexistence] = useState(false);
  const [isPending, startTransition] = useTransition();
  const signupData = useRef<SignupData>({});

  const appId = process.env.NEXT_PUBLIC_WHATSAPP_APP_ID;
  const configId = process.env.NEXT_PUBLIC_WHATSAPP_CONFIG_ID;
  const graphVersion = process.env.NEXT_PUBLIC_WHATSAPP_GRAPH_VERSION || "v23.0";

  useEffect(() => {
    function onMessage(event: MessageEvent) {
      if (event.origin !== "https://www.facebook.com" && event.origin !== "https://web.facebook.com") return;
      try {
        const data = JSON.parse(typeof event.data === "string" ? event.data : "{}");
        if (data?.type === "WA_EMBEDDED_SIGNUP" && data.data) {
          signupData.current = { ...signupData.current, ...data.data };
        }
      } catch {
        // رسائل postMessage تانية من نفس الأصل مش شكل واتساب — نتجاهلها.
      }
    }
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, []);

  function startSignup(coexistence: boolean, environment: "test" | "production") {
    setError(null);
    if (!appId || !configId) {
      setError("متغيرات NEXT_PUBLIC_WHATSAPP_APP_ID أو NEXT_PUBLIC_WHATSAPP_CONFIG_ID غير مضبوطة على السيرفر.");
      return;
    }
    if (coexistence && !confirmCoexistence) {
      setError("لازم تأكد الصندوق تحت الأول قبل ربط رقم العيادة الحقيقي.");
      return;
    }
    signupData.current = {};
    setStatus("جاري فتح نافذة واتساب...");
    loadFacebookSdk(appId, graphVersion).then(() => {
      window.FB!.login(
        (response) => {
          const code = response.authResponse?.code;
          if (!code) {
            setStatus(null);
            setError("اتقفلت نافذة الربط من غير إتمام العملية.");
            return;
          }
          setStatus("جاري تأكيد الربط...");
          startTransition(async () => {
            const result = await completeEmbeddedSignupAction({
              code,
              wabaId: signupData.current.waba_id ?? "",
              phoneNumberId: signupData.current.phone_number_id ?? "",
              businessId: signupData.current.business_id,
              coexistence,
              environment,
            });
            setStatus(null);
            if (!result.ok) {
              setError(result.error ?? "فشل الربط");
            } else {
              window.location.reload();
            }
          });
        },
        {
          config_id: configId,
          response_type: "code",
          override_default_response_type: true,
          extras: coexistence
            ? { featureType: "whatsapp_business_app_onboarding", sessionInfoVersion: "3" }
            : { sessionInfoVersion: "3" },
        }
      );
    });
  }

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-slate-200 p-3">
        <p className="mb-2 text-sm font-medium">1) ربط رقم Meta التجريبي (للتطوير وApp Review)</p>
        <button
          type="button"
          disabled={isPending}
          onClick={() => startSignup(false, "test")}
          className="btn-primary rounded-lg px-4 py-2 text-sm"
        >
          Connect WhatsApp (رقم تجريبي)
        </button>
      </div>

      <div className="rounded-lg border border-amber-300 bg-amber-50 p-3">
        <p className="mb-2 text-sm font-medium text-amber-900">2) ربط رقم العيادة الحقيقي (Coexistence)</p>
        <label className="mb-2 flex items-start gap-2 text-xs text-amber-900">
          <input
            type="checkbox"
            checked={confirmCoexistence}
            onChange={(e) => setConfirmCoexistence(e.target.checked)}
            className="mt-0.5"
          />
          <span>
            أنا متأكد إن رقم العيادة الحالي هيفضل شغال عادي على تطبيق WhatsApp Business عند السكرتارية بعد الربط ده
            (Coexistence) — مفيش نقل أو تسجيل للرقم بره التطبيق.
          </span>
        </label>
        <button
          type="button"
          disabled={isPending || !confirmCoexistence}
          onClick={() => startSignup(true, "production")}
          className="btn-secondary rounded-lg px-4 py-2 text-sm disabled:opacity-50"
        >
          Connect WhatsApp (رقم العيادة — Coexistence)
        </button>
      </div>

      {status && <p className="text-sm text-muted">{status}</p>}
      {error && <p className="text-sm text-red-700">{error}</p>}
    </div>
  );
}
