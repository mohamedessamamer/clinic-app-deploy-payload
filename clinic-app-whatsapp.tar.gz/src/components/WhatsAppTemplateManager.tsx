"use client";

import { useState, useTransition } from "react";
import { createTemplateAction, refreshTemplateStatusesAction } from "@/app/whatsapp/actions";

type Template = {
  id: number;
  name: string;
  language: string;
  category: string;
  bodyText: string;
  status: string;
  rejectedReason: string | null;
};

const STATUS_LABELS: Record<string, string> = {
  pending: "قيد المراجعة",
  approved: "معتمد",
  rejected: "مرفوض",
  paused: "موقوف",
  disabled: "معطّل",
};

export default function WhatsAppTemplateManager({ templates }: { templates: Template[] }) {
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  function handleCreate(formData: FormData) {
    setError(null);
    startTransition(async () => {
      const result = await createTemplateAction(formData);
      if (!result.ok) setError(result.error ?? "فشل إنشاء القالب");
    });
  }

  function handleRefresh() {
    startTransition(async () => {
      await refreshTemplateStatusesAction();
    });
  }

  return (
    <div className="space-y-5">
      <form action={handleCreate} className="grid grid-cols-1 gap-3 rounded-lg border border-slate-200 p-3 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-xs text-muted">اسم القالب (حروف إنجليزية صغيرة و_ فقط)</label>
          <input name="name" required placeholder="appointment_reminder" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
        </div>
        <div>
          <label className="mb-1 block text-xs text-muted">اللغة</label>
          <select name="language" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option value="ar">العربية</option>
            <option value="en_US">English (US)</option>
          </select>
        </div>
        <div>
          <label className="mb-1 block text-xs text-muted">التصنيف</label>
          <select name="category" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option value="UTILITY">Utility (تذكير موعد، تأكيد)</option>
            <option value="MARKETING">Marketing</option>
          </select>
        </div>
        <div className="sm:col-span-2">
          <label className="mb-1 block text-xs text-muted">نص الرسالة</label>
          <textarea
            name="body_text"
            required
            rows={3}
            placeholder="حضرتك عندك معاد يوم {{1}} الساعة {{2}} في عيادة د. محمد عصام عامر."
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
          />
        </div>
        <div className="sm:col-span-2">
          <button type="submit" disabled={isPending} className="btn-primary rounded-lg px-4 py-2 text-sm">
            إنشاء القالب في Meta
          </button>
        </div>
      </form>
      {error && <p className="text-sm text-red-700">{error}</p>}

      <div className="flex items-center justify-between">
        <p className="text-sm font-medium">القوالب المرسلة للمراجعة</p>
        <button type="button" onClick={handleRefresh} disabled={isPending} className="btn-secondary rounded-lg px-3 py-1.5 text-xs">
          تحديث الحالة من Meta
        </button>
      </div>

      <div className="space-y-2">
        {templates.length === 0 && <p className="text-sm text-muted">لسه مفيش قوالب متعملة.</p>}
        {templates.map((t) => (
          <div key={t.id} className="rounded-lg border border-slate-200 p-3 text-sm">
            <div className="flex items-center justify-between">
              <span className="font-medium">
                {t.name} <span className="text-xs text-muted">({t.language})</span>
              </span>
              <span
                className={
                  t.status === "approved"
                    ? "text-emerald-700"
                    : t.status === "rejected"
                    ? "text-red-700"
                    : "text-amber-700"
                }
              >
                {STATUS_LABELS[t.status] ?? t.status}
              </span>
            </div>
            <p className="mt-1 text-muted">{t.bodyText}</p>
            {t.rejectedReason && <p className="mt-1 text-xs text-red-700">سبب الرفض: {t.rejectedReason}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}
