import "server-only";

// كل إعدادات WhatsApp Cloud API الثابتة (App-level) — بتتقرا من متغيرات بيئة
// السيرفر بس، مفيش أي قيمة منها في الكود. لازم تتحط في .env.production على
// السيرفر (systemd EnvironmentFile) بصلاحيات وصول مقفولة (600) — شوف
// docs/WHATSAPP_INTEGRATION.md لقائمة كل متغير ومعناه.
//
// دالة (مش constant) عشان القراءة تحصل وقت الاستخدام الفعلي بس (مش وقت أول
// import للموديول) — كده صفحات النظام التانية (المرضى، الفواتير...) تفضل شغالة
// عادي حتى لو متغيرات واتساب لسه مش متحطة على السيرفر، وبيبان خطأ واضح بس لما
// حد يحاول فعلاً يستخدم واتساب.
function required(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(
      `[whatsapp] متغير البيئة ${name} غير موجود. راجع docs/WHATSAPP_INTEGRATION.md لإعداد متغيرات واتساب على السيرفر.`
    );
  }
  return value;
}

export function getWhatsappConfig() {
  return {
    appId: required("WHATSAPP_APP_ID"),
    appSecret: required("WHATSAPP_APP_SECRET"),
    configId: required("WHATSAPP_CONFIG_ID"),
    webhookVerifyToken: required("WHATSAPP_WEBHOOK_VERIFY_TOKEN"),
    graphVersion: process.env.WHATSAPP_GRAPH_VERSION || "v23.0",
    tokenEncKey: required("WHATSAPP_TOKEN_ENC_KEY"),
  };
}

// بيتحط في .env بس مش لازم يكون موجود في dev (فقط وقت لمس فعلي لواتساب) — نفس
// فكرة required فوق لكن كنسخة اختيارية للقيم اللي مالهاش قيمة افتراضية منطقية.
export function getOptionalEnv(name: string): string | undefined {
  return process.env[name] || undefined;
}
