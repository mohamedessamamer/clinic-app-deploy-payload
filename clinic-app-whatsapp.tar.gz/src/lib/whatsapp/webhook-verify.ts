import "server-only";
import crypto from "node:crypto";

// توقيع Meta webhook: هيدر X-Hub-Signature-256: "sha256=<hex hmac>" محسوب على
// الـraw body بمفتاح App Secret. لازم يتحقق منه على الـraw body *قبل* أي
// JSON.parse — أي تعديل/إعادة تكوين للنص (whitespace..) بيخلي التوقيع يفشل.
// https://developers.facebook.com/docs/graph-api/webhooks/getting-started#validating-payloads
export function verifyWebhookSignature(rawBody: string, signatureHeader: string | null, appSecret: string): boolean {
  if (!signatureHeader) return false;
  const [algo, providedHex] = signatureHeader.split("=");
  if (algo !== "sha256" || !providedHex) return false;

  const expectedHex = crypto.createHmac("sha256", appSecret).update(rawBody, "utf8").digest("hex");

  const provided = Buffer.from(providedHex, "hex");
  const expected = Buffer.from(expectedHex, "hex");
  if (provided.length !== expected.length) return false;
  return crypto.timingSafeEqual(provided, expected);
}
