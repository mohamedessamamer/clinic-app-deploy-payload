import "server-only";
import crypto from "node:crypto";

// تشفير access token واتساب قبل تخزينه في قاعدة البيانات (AES-256-GCM).
// المفتاح نفسه بيتحط في .env.production على السيرفر (WHATSAPP_TOKEN_ENC_KEY)
// ومش بيتخزن أبدًا في قاعدة البيانات ولا في الكود. ليه التوكن في قاعدة البيانات
// مش .env مباشرة: توكن Embedded Signup بييجي ديناميكيًا وقت الربط من واجهة
// النظام (مش قيمة ثابتة الأدمن بيحطها يدويًا مرة واحدة)، فتخزينه مشفّرًا في
// قاعدة البيانات هو الحل العملي اللي بيسمح بإعادة الربط/تبديل الرقم من غير
// الحاجة لإعادة نشر السيرفر (deploy) في كل مرة.
//
// توليد مفتاح صالح: `openssl rand -base64 32`

function getKey(): Buffer {
  const raw = process.env.WHATSAPP_TOKEN_ENC_KEY;
  if (!raw) {
    throw new Error(
      "[whatsapp] WHATSAPP_TOKEN_ENC_KEY غير موجود — لازم متغير بيئة 32 بايت (base64) على السيرفر. شوف docs/WHATSAPP_INTEGRATION.md."
    );
  }
  const key = Buffer.from(raw, "base64");
  if (key.length !== 32) {
    throw new Error("[whatsapp] WHATSAPP_TOKEN_ENC_KEY لازم يكون 32 بايت بعد فك base64 (استخدم: openssl rand -base64 32).");
  }
  return key;
}

// الناتج: base64(iv[12] + authTag[16] + ciphertext) — قيمة واحدة قابلة للتخزين
// في عمود نصي واحد (access_token_encrypted).
export function encryptSecret(plainText: string): string {
  const key = getKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  const ciphertext = Buffer.concat([cipher.update(plainText, "utf8"), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return Buffer.concat([iv, authTag, ciphertext]).toString("base64");
}

export function decryptSecret(encoded: string): string {
  const key = getKey();
  const raw = Buffer.from(encoded, "base64");
  const iv = raw.subarray(0, 12);
  const authTag = raw.subarray(12, 28);
  const ciphertext = raw.subarray(28);
  const decipher = crypto.createDecipheriv("aes-256-gcm", key, iv);
  decipher.setAuthTag(authTag);
  return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString("utf8");
}
