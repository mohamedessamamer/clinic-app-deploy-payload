import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db/client";
import AddVisitForm from "@/components/AddVisitForm";
import AddImageGroupForm from "@/components/AddImageGroupForm";
import PatientImageGallery from "@/components/PatientImageGallery";
import NextAppointmentForm from "@/components/NextAppointmentForm";
import { getAllSettings, buildTimeSlots } from "@/lib/settings";

export default async function PatientDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const patientId = Number(id);
  if (!patientId) notFound();

  const patient = await db.selectFrom("patients").selectAll().where("id", "=", patientId).executeTakeFirst();
  if (!patient) notFound();

  const [visits, doctors, services, serviceDoctorRows, imageGroups, rooms, settings] = await Promise.all([
    db
      .selectFrom("visits")
      .leftJoin("services", "services.id", "visits.service_id")
      .leftJoin("doctors", "doctors.id", "visits.primary_doctor_id")
      .select([
        "visits.id",
        "visits.visit_date",
        "visits.notes",
        "services.name as service_name",
        "doctors.full_name as doctor_name",
      ])
      .where("visits.patient_id", "=", patientId)
      .orderBy("visits.visit_date", "desc")
      .execute(),
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).execute(),
    db.selectFrom("services").select(["id", "name"]).execute(),
    db.selectFrom("service_doctors").select(["service_id", "doctor_id"]).execute(),
    db
      .selectFrom("patient_image_groups")
      .selectAll()
      .where("patient_id", "=", patientId)
      .orderBy("taken_at", "desc")
      .execute(),
    db.selectFrom("rooms").selectAll().execute(),
    getAllSettings(),
  ]);

  const timeSlots = buildTimeSlots(settings.day_start, settings.day_end, Number(settings.slot_minutes));

  const imageGroupsWithFiles = await Promise.all(
    imageGroups.map(async (g) => ({
      ...g,
      images: await db.selectFrom("patient_images").selectAll().where("group_id", "=", g.id).execute(),
    }))
  );

  const serviceDoctorMap: Record<number, number[]> = {};
  for (const row of serviceDoctorRows) {
    (serviceDoctorMap[row.service_id] ??= []).push(row.doctor_id);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <div className="text-xs text-muted">ملف رقم {patient.file_number}</div>
          <h1 className="text-xl font-bold">{patient.full_name}</h1>
          <div className="text-sm text-muted mt-1 flex gap-4 flex-wrap">
            {patient.age && <span>السن: {patient.age}</span>}
            {patient.phone && <span>التليفون: {patient.phone}</span>}
            {patient.address && <span>العنوان: {patient.address}</span>}
          </div>
        </div>
        <Link
          href={`/patients/${patientId}/billing`}
          target="_blank"
          rel="noopener noreferrer"
          className="px-3 py-2 rounded-md border border-border text-sm hover:bg-primary-soft whitespace-nowrap"
        >
          الملف المالي
        </Link>
      </div>

      {/* Quick booking for the patient's next appointment before they leave */}
      <section className="bg-surface border border-border rounded-xl p-5 space-y-3">
        <h2 className="font-semibold">حجز الموعد القادم</h2>
        <NextAppointmentForm patientId={patientId} rooms={rooms} doctors={doctors} timeSlots={timeSlots} />
      </section>

      {/* Image / X-ray gallery */}
      <section className="bg-surface border border-border rounded-xl p-5 space-y-3">
        <h2 className="font-semibold">الصور والأشعة</h2>

        <PatientImageGallery groups={imageGroupsWithFiles} patientId={patientId} />

        <AddImageGroupForm patientId={patientId} />
      </section>

      {/* Visits history table */}
      <section className="bg-surface border border-border rounded-xl p-5 space-y-4">
        <h2 className="font-semibold">سجل الكشوفات والزيارات</h2>

        <AddVisitForm
          patientId={patientId}
          services={services}
          doctors={doctors}
          serviceDoctorMap={serviceDoctorMap}
        />

        {/* table-fixed + عرض كل عمود بالنسبة المئوية عشان عرض الجدول يفضل ثابت مهما
            كان محتوى أي خانة (زي وصف علاج طويل من غير مسافات) — النص بيلف ويكبر
            ارتفاع الصف بدل ما يوسّع عرض العمود ويحتاج سكرول جانبي. overflow-x-auto
            لسه موجود كحماية إضافية بس مش المفروض يتفعل في الحالة العادية. */}
        <div className="overflow-x-auto">
          <table className="w-full text-sm mt-2 table-fixed">
            <colgroup>
              <col className="w-[16%]" />
              <col className="w-[20%]" />
              <col />
              <col className="w-[18%]" />
            </colgroup>
            <thead className="bg-primary-soft text-primary-dark">
              <tr>
                <th className="text-right px-3 py-2 font-medium">التاريخ</th>
                <th className="text-right px-3 py-2 font-medium">نوع الخدمة</th>
                <th className="text-right px-3 py-2 font-medium">المعالجة</th>
                <th className="text-right px-3 py-2 font-medium">الدكتور</th>
              </tr>
            </thead>
            <tbody>
              {visits.map((v) => (
                <tr key={v.id} className="border-t border-border align-top">
                  <td className="px-3 py-2 text-muted whitespace-nowrap">{v.visit_date}</td>
                  <td className="px-3 py-2 break-words">{v.service_name ?? "-"}</td>
                  <td className="px-3 py-2 break-words">{v.notes ?? "-"}</td>
                  <td className="px-3 py-2 break-words">{v.doctor_name ?? "-"}</td>
                </tr>
              ))}
              {visits.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-3 py-6 text-center text-muted">
                    لا يوجد زيارات مسجلة بعد.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
