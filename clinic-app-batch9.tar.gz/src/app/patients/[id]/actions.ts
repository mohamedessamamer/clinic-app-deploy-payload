"use server";

import { revalidatePath } from "next/cache";
import path from "node:path";
import fs from "node:fs/promises";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";

export async function addVisitAction(formData: FormData) {
  const patientId = Number(formData.get("patient_id"));
  const visit_date = String(formData.get("visit_date") || "").trim();
  const service_id = formData.get("service_id") ? Number(formData.get("service_id")) : null;
  const notes = String(formData.get("notes") || "").trim() || null;
  const primary_doctor_id = formData.get("doctor_id") ? Number(formData.get("doctor_id")) : null;
  const session = await getSession();

  if (!patientId || !visit_date) return;

  const visitResult = await db
    .insertInto("visits")
    .values({
      patient_id: patientId,
      visit_date,
      service_id,
      notes,
      primary_doctor_id,
      performing_doctor_id: primary_doctor_id,
      room_id: null,
      created_by: session?.userId ?? null,
    })
    .executeTakeFirst();

  // Every visit gets an invoice automatically, pre-filled with the service's
  // default price when a service was chosen (staff can adjust the amount later).
  if (visitResult.insertId) {
    let amount = 0;
    if (service_id) {
      const service = await db
        .selectFrom("services")
        .select("default_price")
        .where("id", "=", service_id)
        .executeTakeFirst();
      amount = service?.default_price ?? 0;
    }
    await db
      .insertInto("invoices")
      .values({ visit_id: Number(visitResult.insertId), amount, paid: 0 })
      .execute();
  }

  revalidatePath(`/patients/${patientId}`);
  revalidatePath("/invoices");
}

// NOTE (image-upload-404 fix, v2): two separate bugs were found here.
// (1) process.cwd() under systemd isn't guaranteed to equal the app's source
//     root, so a file could get written to one absolute path while the
//     server resolved requests against a different one — fixed by pinning
//     an absolute root via CLINIC_UPLOAD_DIR (same pattern as CLINIC_DB_PATH).
// (2) more fundamentally: Next.js's "public" folder is only scanned ONCE at
//     server boot (a snapshot of filenames used to serve static assets), so
//     writing new files into "public/..." at runtime is invisible until the
//     next deploy/restart — any photo uploaded during normal clinic hours
//     would 404 forever until then. So uploads are stored OUTSIDE "public"
//     entirely (mirroring where the sqlite db already lives, under data/,
//     which the deploy process already backs up and never overwrites) and
//     served through a dynamic route (src/app/patient-files/[...path]/route.ts)
//     that reads the file from disk on every request — no snapshot involved.
const UPLOAD_ROOT = process.env.CLINIC_UPLOAD_DIR
  ? path.join(path.resolve(process.env.CLINIC_UPLOAD_DIR), "patients")
  : path.join(process.cwd(), "data", "uploads", "patients");

export async function addImageGroupAction(formData: FormData) {
  const patientId = Number(formData.get("patient_id"));
  const taken_at = String(formData.get("taken_at") || "").trim();
  const label = String(formData.get("label") || "").trim() || null;
  const files = formData.getAll("files") as File[];

  if (!patientId || !taken_at) return;

  const group = await db
    .insertInto("patient_image_groups")
    .values({ patient_id: patientId, taken_at, label })
    .executeTakeFirst();

  const groupId = Number(group.insertId);
  const dir = path.join(UPLOAD_ROOT, String(patientId));
  await fs.mkdir(dir, { recursive: true });

  for (const file of files) {
    if (!file || typeof file === "string" || !file.size) continue;
    const safeName = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
    const buffer = Buffer.from(await file.arrayBuffer());
    await fs.writeFile(path.join(dir, safeName), buffer);
    const publicPath = `/patient-files/patients/${patientId}/${safeName}`;
    await db.insertInto("patient_images").values({ group_id: groupId, file_path: publicPath }).execute();
  }

  revalidatePath(`/patients/${patientId}`);
}

// بيمسح صورة واحدة (صورة اترفعت غلط أو مكررة). التأكيد بيحصل في الطبقة
// العميلة (window.confirm) قبل ما الأكشن ده يتستدعى أصلاً، زي نفس النمط
// المتبع مع حذف المستخدمين/العيادات في الإعدادات.
export async function deleteImageAction(formData: FormData) {
  const session = await getSession();
  if (!session) return;

  const imageId = Number(formData.get("image_id"));
  const patientId = Number(formData.get("patient_id"));
  if (!imageId || !patientId) return;

  const image = await db
    .selectFrom("patient_images")
    .select(["id", "file_path", "group_id"])
    .where("id", "=", imageId)
    .executeTakeFirst();
  if (!image) return;

  await db.deleteFrom("patient_images").where("id", "=", imageId).execute();

  // الملف نفسه على القرص - نمسحه best-effort، لو مش موجود أصلاً (اتمسح قبل
  // كده يدويًا مثلاً) منسيبش الحذف كله يفشل بسبب كده.
  if (image.file_path.startsWith("/patient-files/")) {
    // UPLOAD_ROOT فوق already بينتهي بـ "/patients"، و file_path المخزّن شكله
    // "/patient-files/patients/<id>/<name>" — يعني dirname(UPLOAD_ROOT) هو
    // نفس القاعدة اللي راوت العرض (route.ts) بيبني منها المسار.
    const relative = image.file_path.replace(/^\/patient-files\//, "");
    const filePath = path.join(path.dirname(UPLOAD_ROOT), relative);
    await fs.unlink(filePath).catch(() => {});
  }

  // لو دي كانت آخر صورة في مجموعتها، امسح المجموعة (الكارت) نفسها كمان —
  // غير كده كانت هتفضل تظهر في المعرض كمربع فاضي "لا صور" من غير أي فايدة.
  const remaining = await db
    .selectFrom("patient_images")
    .select((eb) => eb.fn.countAll<number>().as("count"))
    .where("group_id", "=", image.group_id)
    .executeTakeFirst();
  if (!remaining || Number(remaining.count) === 0) {
    await db.deleteFrom("patient_image_groups").where("id", "=", image.group_id).execute();
  }

  revalidatePath(`/patients/${patientId}`);
}
