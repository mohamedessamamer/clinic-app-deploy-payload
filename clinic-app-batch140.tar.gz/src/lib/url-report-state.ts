// دفعة 138 — قاعدة عامة: أي مكوّن فيه فلاتر ونتيجة تقرير/بحث لازم يسجّل حالته
// في رابط الصفحة (URL) بدل ما يسيبها في ذاكرة الصفحة (React state) بس. الفايدة
// إن زرار "رجوع" في المتصفح بيرجّعك لنفس الـ URL اللي كنت عليه بالظبط - فلو
// الفلاتر والنتيجة متسجلين في الرابط، بتقدر تعيد بناء نفس الحالة منه أول ما
// المكوّن يتحمّل تاني، مش يرجع لقيمه الافتراضية.
//
// ده نفس الأسلوب اللي كان مستخدم يدويًا في ReportsWorkspace.tsx (اختيار
// التبويب) - هنا بس بقى أداة عامة تتستخدم في أي تقرير فيه فلاتر (تاريخ، فرز،
// تخصص...) بدل ما كل مكوّن يعيد كتابة نفس الكود.
//
// طريقة الاستخدام في أي مكوّن "use client":
//   const router = useRouter();
//   const initial = readUrlReportParams(["fromDate", "toDate", "specialty"]);
//   const [fromDate, setFromDate] = useState(initial.fromDate ?? "");
//   ...
//   function run() {
//     writeUrlReportParams(router, { fromDate, toDate, specialty, applied: "1" });
//     startTransition(async () => { ... });
//   }
//   useEffect(() => { if (initial.applied === "1") run(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
//
// دفعة 140: كان الكتابة بتحصل بـ window.history.replaceState() مباشرة (بدل
// next/navigation) عشان تتجنب أي re-render أو navigation فعلي - إحنا بس كنا
// عايزين نعلّم على الرابط الحالي. المشكلة: الفلاتر جوه التقرير كانت فعلاً
// بترجع صح بعد "رجوع" (لأن المكوّن نفسه فاضل في الذاكرة)، لكن اختيار
// "التبويب" في ReportsWorkspace كان بيتلغي - لأن راوتر Next.js (App Router)
// بيتتبّع الـ history/cache بتاعه من خلال next/navigation بس، ومش بياخد باله
// من تعديل بيحصل على history مباشرة من غيره. فلما تدوس "رجوع" من صفحة تانية
// (زي الملف المالي)، Next كان بيرجّع نسخة قديمة من /reports (من أول تحميل،
// قبل أي اختيار تبويب) بدل الرابط المتغيّر اللي كان ظاهر فعلًا في المتصفح.
// الحل: نستخدم router.replace() بتاع next/navigation، عشان Next نفسه يسجّل
// كل تغيير في رابط الصفحة كجزء من الـ history اللي بيتحكم فيه، فـ"رجوع" يرجع
// صح للحالة اللي كانت ظاهرة فعلًا - سواء فلاتر داخل تقرير أو اختيار التبويب.
type ReportRouter = { replace: (href: string, options?: { scroll?: boolean }) => void };

export function readUrlReportParams(keys: string[]): Record<string, string | null> {
  const result: Record<string, string | null> = {};
  if (typeof window === "undefined") {
    for (const key of keys) result[key] = null;
    return result;
  }
  const params = new URLSearchParams(window.location.search);
  for (const key of keys) result[key] = params.get(key);
  return result;
}

export function writeUrlReportParams(router: ReportRouter, values: Record<string, string | null | undefined>): void {
  if (typeof window === "undefined") return;
  const url = new URL(window.location.href);
  for (const [key, value] of Object.entries(values)) {
    if (value === null || value === undefined || value === "") url.searchParams.delete(key);
    else url.searchParams.set(key, value);
  }
  router.replace(url.pathname + url.search, { scroll: false });
}
