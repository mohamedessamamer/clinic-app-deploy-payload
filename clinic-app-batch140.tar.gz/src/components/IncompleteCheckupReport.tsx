"use client";

import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getIncompleteCheckupReportAction, type IncompleteCheckupResult } from "@/app/reports/incomplete-checkup-actions";
import { CLINIC_TIMEZONE } from "@/lib/clinic-date";
import { readUrlReportParams, writeUrlReportParams } from "@/lib/url-report-state";

// "النهاردة" بتوقيت العيادة (مصر) مش UTC — نفس سبب باج دفعة 28 الموثّق في
// clinic-date.ts وفي PatientDurationReport.tsx.
const clinicTodayFormatter = new Intl.DateTimeFormat("en-CA", {
  timeZone: CLINIC_TIMEZONE,
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});

const input = "rounded border border-border bg-background px-2 py-1.5 text-sm";

// دفعة 138: الفترة والنتيجة بيتسجلوا في رابط الصفحة عشان زرار "رجوع" في
// المتصفح يرجّعك بنفس الفترة ونفس النتيجة اللي كانت ظاهرة.
const urlKeys = ["checkup_from", "checkup_to", "checkup_applied"];

export default function IncompleteCheckupReport() {
  const router = useRouter();
  const initialUrl = readUrlReportParams(urlKeys);
  const [range, setRange] = useState({ from: initialUrl.checkup_from ?? "", to: initialUrl.checkup_to ?? "" });
  const [result, setResult] = useState<IncompleteCheckupResult | null>(null);
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    if (initialUrl.checkup_applied === "1" && initialUrl.checkup_from && initialUrl.checkup_to) run();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function run() {
    writeUrlReportParams(router, { checkup_from: range.from, checkup_to: range.to, checkup_applied: "1" });
    startTransition(async () => {
      setResult(await getIncompleteCheckupReportAction({ from: range.from, to: range.to }));
    });
  }

  function preset(days: number) {
    const end = new Date();
    const start = new Date(end.getTime() - days * 86_400_000);
    setRange({ from: clinicTodayFormatter.format(start), to: clinicTodayFormatter.format(end) });
  }

  return (
    <section className="card-3d rounded-xl p-5 space-y-4">
      <div>
        <h2 className="font-semibold">الكشوفات غير المكتملة</h2>
        <p className="mt-1 text-xs text-muted">
          مرضى عملوا كشف في الفترة المختارة (مدفوع أو مجاني أو «تم بدون دفع»)، ولسه معندهمش أي خدمة تانية مسجلة طول تاريخهم — يعني اتكشفوا وما رجعوش يكملوا علاج.
        </p>
      </div>

      <div className="flex flex-wrap items-end gap-2">
        <label className="text-xs text-muted">
          من
          <input
            type="date"
            value={range.from}
            onChange={(e) => setRange((current) => ({ ...current, from: e.target.value }))}
            className={`${input} mt-1 block w-40`}
          />
        </label>
        <label className="text-xs text-muted">
          إلى
          <input
            type="date"
            value={range.to}
            onChange={(e) => setRange((current) => ({ ...current, to: e.target.value }))}
            className={`${input} mt-1 block w-40`}
          />
        </label>
        <button
          type="button"
          onClick={run}
          disabled={isPending || !range.from || !range.to}
          className="h-9 rounded-md btn-3d-primary px-4 text-sm font-medium disabled:opacity-50"
        >
          {isPending ? "..." : "عرض التقرير"}
        </button>
        <div className="flex gap-1">
          <button type="button" onClick={() => preset(7)} className="h-9 rounded border border-border px-2 text-xs">الأسبوع الماضي</button>
          <button type="button" onClick={() => preset(30)} className="h-9 rounded border border-border px-2 text-xs">الشهر الماضي</button>
        </div>
      </div>

      {result && !result.ok && (
        <p className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{result.error}</p>
      )}

      {result?.ok && (
        <div className="space-y-2">
          {/* الكشف بياخد مهلة قبل ما يتحسب "غير مكتمل"، فالفترة المعروضة ممكن
              تكون أقصر من اللي المستخدم اختاره. من غير السطر ده الرقم بيبان
              ناقص من غير سبب ظاهر. */}
          {result.effectiveTo < range.to && (
            <p className="rounded-md border border-border bg-primary-soft/40 px-3 py-2 text-xs text-muted">
              الكشف بياخد مهلة {result.graceDays} أيام قبل ما يتحسب غير مكتمل، فالتقرير معروض لحد {result.effectiveTo} بدل {range.to}.
            </p>
          )}
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-right">
                  <th className="p-2">اسم المريض</th>
                  <th className="p-2 whitespace-nowrap">رقم الملف</th>
                  <th className="p-2 whitespace-nowrap">تاريخ الكشف</th>
                  <th className="p-2 whitespace-nowrap">نوع الكشف</th>
                  <th className="p-2">اسم الدكتور</th>
                  <th className="p-2 whitespace-nowrap">رقم التليفون</th>
                  <th className="p-2 whitespace-nowrap">المصدر</th>
                </tr>
              </thead>
              <tbody>
                {result.rows.map((row) => (
                  <tr key={row.key} className="border-b border-border">
                    <td className="p-2 font-medium">{row.patientName}</td>
                    <td className="p-2 whitespace-nowrap">{row.fileNumber}</td>
                    <td className="p-2 whitespace-nowrap">{row.checkupDate}</td>
                    <td className="p-2 whitespace-nowrap">{row.checkupName}</td>
                    <td className="p-2">{row.doctorName}</td>
                    <td className="p-2 whitespace-nowrap">{row.phone}</td>
                    <td className="p-2 whitespace-nowrap text-xs text-muted">{row.source}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!result.rows.length && <p className="py-6 text-center text-sm text-muted">لا يوجد مرضى بكشوفات غير مكتملة في الفترة المختارة.</p>}
          </div>
        </div>
      )}
    </section>
  );
}
