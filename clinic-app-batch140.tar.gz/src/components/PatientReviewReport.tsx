"use client";
import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getPatientReviewsAction, saveGoogleReviewUrlAction } from "@/app/reports/review-actions";
import { readUrlReportParams, writeUrlReportParams } from "@/lib/url-report-state";
type Row = { id: number; visit_date: string; rating: number; comment: string | null; anonymous: number; patient_name: string | null; doctor_name: string };
const today = () => new Intl.DateTimeFormat("en-CA", { timeZone: "Africa/Cairo", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
// دفعة 138: الفترة والنتيجة بيتسجلوا في رابط الصفحة عشان زرار "رجوع" في
// المتصفح يرجّعك بنفس الفترة ونفس التقييمات اللي كانت ظاهرة.
const urlKeys = ["review_from", "review_to", "review_applied"];
export default function PatientReviewReport({ canConfigure, initialGoogleUrl }: { canConfigure: boolean; initialGoogleUrl: string }) {
  const router = useRouter();
  const initialUrl = readUrlReportParams(urlKeys);
  const [from, setFrom] = useState(initialUrl.review_from || today().slice(0,7) + "-01"); const [to, setTo] = useState(initialUrl.review_to || today()); const [data, setData] = useState<{ rows: Row[]; average: number } | null>(null); const [busy, startTransition] = useTransition();
  const runReview = () => startTransition(async () => { writeUrlReportParams(router, { review_from: from, review_to: to, review_applied: "1" }); const result = await getPatientReviewsAction(from,to); if (!result.ok) return alert(result.error); setData({ rows: result.rows, average: Number(result.average || 0) }); });
  useEffect(() => { if (initialUrl.review_applied === "1") runReview(); /* eslint-disable-line react-hooks/exhaustive-deps */ }, []);
  return <section className="card-3d rounded-xl p-4 space-y-3" dir="rtl"><div><h2 className="font-semibold">تقييمات المرضى</h2><p className="mt-1 text-xs text-muted">النتائج مخفية حتى الضغط على عرض. خيار بدون اسم يخفي المريض من التقرير.</p></div>
    <div className="flex flex-wrap items-end gap-2"><label className="text-sm">من<input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="mt-1 block rounded-md border border-border bg-background px-3 py-2" /></label><label className="text-sm">إلى<input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="mt-1 block rounded-md border border-border bg-background px-3 py-2" /></label><button disabled={busy} onClick={runReview} className="btn-3d-primary rounded-md px-4 py-2 text-sm">عرض التقييمات</button></div>
    {canConfigure && <form action={(fd) => startTransition(async () => { const result = await saveGoogleReviewUrlAction(String(fd.get("url") || "")); alert(result.ok ? "تم حفظ رابط Google." : result.error); })} className="flex flex-wrap items-end gap-2 border-t border-border pt-3"><label className="min-w-72 flex-1 text-sm">رابط تقييم Google (يظهر لكل المرضى بعد الإرسال)<input name="url" defaultValue={initialGoogleUrl} placeholder="https://g.page/r/.../review" className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2" /></label><button className="rounded-md border border-primary px-4 py-2 text-sm text-primary">حفظ الرابط</button></form>}
    {data && <div className="overflow-x-auto border-t border-border pt-3"><div className="mb-3 flex gap-4 text-sm"><b>عدد التقييمات: {data.rows.length}</b><b>المتوسط: {data.average.toFixed(1)} / 5</b></div><table className="w-full text-sm"><thead><tr className="border-b border-border text-right"><th className="p-2">المريض</th><th className="p-2">الطبيب</th><th className="p-2">تاريخ الزيارة</th><th className="p-2">التقييم</th><th className="p-2">الملاحظة</th></tr></thead><tbody>{data.rows.map((r) => <tr key={r.id} className="border-b border-border"><td className="p-2">{r.anonymous ? "بدون اسم" : r.patient_name || "—"}</td><td className="p-2">{r.doctor_name}</td><td className="p-2">{r.visit_date}</td><td className="p-2 text-amber-500">{"★".repeat(r.rating)}<span className="text-slate-300">{"★".repeat(5-r.rating)}</span></td><td className="p-2">{r.comment || "—"}</td></tr>)}</tbody></table>{!data.rows.length && <p className="py-5 text-center text-muted">لا توجد تقييمات في الفترة.</p>}</div>}
  </section>;
}
