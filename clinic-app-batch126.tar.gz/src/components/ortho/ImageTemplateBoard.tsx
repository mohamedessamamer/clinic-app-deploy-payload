"use client";

// Batch 126: عرض التمبلت — صور المجموعة مرتّبة بالترتيب المتفق عليه:
//   Extra-Oral (أمامي ← جانبي ← 45 درجة) ← Intra-Oral (أمامي ← يمين ← شمال ←
//   علوي ← سفلي) ← X-ray (بانوراما ← سيفالومتري ← باقي الأشعة) ← Templates
//   (أي تمبلت جاهز اتعمل برة السيستم واترفع مع الصور).
// ٣ صور في الصف، كل صورة في إطار بنسبة ثابتة (4:3) والصورة جواه كاملة من غير
// أي مط — الأبعاد الحقيقية بتفضل زي ما هي.

import { useEffect, useMemo, useState } from "react";
import { suggestGroupTemplateAction, type TemplateImage } from "@/app/patients/[id]/images/template-actions";
import { IMAGE_KIND_LABELS_EN, isImageKind } from "@/lib/images/kinds";
import { SECTION_LABELS, SECTION_ORDER, imageSortRank, sectionOf, type ImageSection } from "@/lib/images/order";

type Props = { groupId: number; patientId: number; onClose: () => void };

export default function ImageTemplateBoard({ groupId, onClose }: Props) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [images, setImages] = useState<TemplateImage[]>([]);

  useEffect(() => {
    let cancelled = false;
    suggestGroupTemplateAction(groupId).then((result) => {
      if (cancelled) return;
      if (!result.ok || !result.images) {
        setError(result.error || "Could not load the photos.");
        setLoading(false);
        return;
      }
      setImages(result.images);
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, [groupId]);

  const sections = useMemo(() => {
    const ordered = [...images].sort((a, b) => imageSortRank(a.kind) - imageSortRank(b.kind) || a.id - b.id);
    const grouped = new Map<ImageSection, TemplateImage[]>();
    for (const image of ordered) {
      const section = sectionOf(image.kind);
      grouped.set(section, [...(grouped.get(section) ?? []), image]);
    }
    return SECTION_ORDER.map((section) => ({ section, items: grouped.get(section) ?? [] })).filter((entry) => entry.items.length > 0);
  }, [images]);

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/45 p-3" role="dialog" aria-modal="true" aria-label="Patient photo template">
      <div className="card-3d w-full max-w-5xl max-h-[92vh] overflow-y-auto rounded-xl p-4 text-left" dir="ltr">
        <div className="flex items-center justify-between gap-2">
          <h3 className="font-semibold">Patient photo template</h3>
          <button type="button" onClick={onClose} className="rounded-md border border-border px-3 py-1.5 text-sm hover:bg-primary-soft">Close</button>
        </div>
        {error && <p className="mt-2 text-sm text-danger">{error}</p>}
        {loading ? (
          <p className="mt-6 text-sm text-muted">Loading photos…</p>
        ) : (
          sections.map(({ section, items }) => (
            <section key={section} className="mt-5">
              <h4 className="image-template-section-title">{SECTION_LABELS[section]}</h4>
              <div className="image-template-sheet">
                {items.map((image) => (
                  <figure key={image.id} className="image-template-cell">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={image.filePath} alt={image.kind && isImageKind(image.kind) ? IMAGE_KIND_LABELS_EN[image.kind] : "Photo"} />
                    <figcaption>{image.kind && isImageKind(image.kind) ? IMAGE_KIND_LABELS_EN[image.kind] : "Unclassified"}</figcaption>
                  </figure>
                ))}
              </div>
            </section>
          ))
        )}
        {!loading && !sections.length && <p className="mt-6 text-sm text-muted">No photos in this group.</p>}
      </div>
    </div>
  );
}
