"use client";

// Batch 126: عرض التمبلت — صور المجموعة مرتّبة بالترتيب المتفق عليه:
//   Extra-Oral (أمامي ← جانبي ← 45 درجة) ← Intra-Oral (أمامي ← يمين ← شمال ←
//   علوي ← سفلي) ← X-ray (بانوراما ← سيفالومتري ← باقي الأشعة) ← Templates
//   (أي تمبلت جاهز اتعمل برة السيستم واترفع مع الصور).
// ٣ صور في الصف، كل صورة في إطار بنسبة ثابتة (4:3) والصورة جواه كاملة من غير
// أي مط — الأبعاد الحقيقية بتفضل زي ما هي.
//
// Batch 127: دوسة على الصورة تفتحها بحجمها الكامل (lightbox)، ودوسة على
// التعريف تحتها تفتح قائمة بكل الأنواع المعروفة عند السيستم — اختيار نوع
// بينقل الصورة فورًا لمكانها الصح ويسجّل التصحيح لمراجعة بشرية لاحقًا (بدون
// أي تعديل تلقائي على سلوك التصنيف نفسه).

import { useEffect, useMemo, useState } from "react";
import { suggestGroupTemplateAction, setImageKindAction, type TemplateImage } from "@/app/patients/[id]/images/template-actions";
import { IMAGE_KINDS, IMAGE_KIND_LABELS_EN, isImageKind, type ImageKind } from "@/lib/images/kinds";
import { SECTION_LABELS, SECTION_ORDER, imageSortRank, sectionOf, type ImageSection } from "@/lib/images/order";

type Props = { groupId: number; patientId: number; onClose: () => void };

export default function ImageTemplateBoard({ groupId, onClose }: Props) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [images, setImages] = useState<TemplateImage[]>([]);
  const [lightboxId, setLightboxId] = useState<number | null>(null);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [savingId, setSavingId] = useState<number | null>(null);

  useEffect(() => {
    let cancelled = false;
    suggestGroupTemplateAction(groupId).then((result) => {
      if (cancelled) return;
      if (!result.ok || !result.images) {
        setError(result.error || "Could not load the photos.");
        setLoading(false);
        return;
      }
      setImages(result.images);
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, [groupId]);

  const sections = useMemo(() => {
    const ordered = [...images].sort((a, b) => imageSortRank(a.kind) - imageSortRank(b.kind) || a.id - b.id);
    const grouped = new Map<ImageSection, TemplateImage[]>();
    for (const image of ordered) {
      const section = sectionOf(image.kind);
      grouped.set(section, [...(grouped.get(section) ?? []), image]);
    }
    return SECTION_ORDER.map((section) => ({ section, items: grouped.get(section) ?? [] })).filter((entry) => entry.items.length > 0);
  }, [images]);

  const lightboxImage = lightboxId != null ? images.find((image) => image.id === lightboxId) ?? null : null;

  async function applyKind(imageId: number, newKind: ImageKind) {
    setEditingId(null);
    setSavingId(imageId);
    setError("");
    try {
      const result = await setImageKindAction(imageId, newKind);
      if (!result.ok) {
        setError(result.error || "Could not update the photo type.");
        return;
      }
      // النتيجة بتتحدّث محليًا فورًا عشان الصورة تتنقل لمكانها الجديد في الحال،
      // من غير ما نستنى إعادة تحميل كل التمبلت من السيرفر.
      setImages((prev) => prev.map((image) => (image.id === imageId ? { ...image, kind: newKind, confidence: 1, slot: null } : image)));
    } finally {
      setSavingId(null);
    }
  }

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/45 p-3" role="dialog" aria-modal="true" aria-label="Patient photo template">
      <div className="card-3d w-full max-w-5xl max-h-[92vh] overflow-y-auto rounded-xl p-4 text-left" dir="ltr">
        <div className="flex items-center justify-between gap-2">
          <h3 className="font-semibold">Patient photo template</h3>
          <button type="button" onClick={onClose} className="rounded-md border border-border px-3 py-1.5 text-sm hover:bg-primary-soft">Close</button>
        </div>
        {error && <p className="mt-2 text-sm text-danger">{error}</p>}
        {loading ? (
          <p className="mt-6 text-sm text-muted">Loading photos…</p>
        ) : (
          sections.map(({ section, items }) => (
            <section key={section} className="mt-5">
              <h4 className="image-template-section-title">{SECTION_LABELS[section]}</h4>
              <div className="image-template-sheet">
                {items.map((image) => {
                  const label = image.kind && isImageKind(image.kind) ? IMAGE_KIND_LABELS_EN[image.kind] : "Unclassified";
                  return (
                    <figure key={image.id} className="image-template-cell">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={image.filePath}
                        alt={label}
                        onClick={() => setLightboxId(image.id)}
                        className="cursor-zoom-in"
                        title="Click to view full size"
                      />
                      <figcaption>
                        <button
                          type="button"
                          onClick={() => setEditingId(editingId === image.id ? null : image.id)}
                          disabled={savingId === image.id}
                          className="w-full text-left hover:underline disabled:opacity-60"
                          title="Click to fix the photo type"
                        >
                          {savingId === image.id ? "Saving…" : label}
                        </button>
                        {editingId === image.id && (
                          <select
                            autoFocus
                            defaultValue=""
                            onChange={(event) => {
                              const value = event.target.value;
                              if (isImageKind(value)) applyKind(image.id, value);
                            }}
                            onBlur={() => setEditingId(null)}
                            className="mt-1 w-full rounded border border-border bg-background px-1 py-0.5 text-xs"
                          >
                            <option value="" disabled>Choose type…</option>
                            {IMAGE_KINDS.map((kind) => (
                              <option key={kind} value={kind}>{IMAGE_KIND_LABELS_EN[kind]}</option>
                            ))}
                          </select>
                        )}
                      </figcaption>
                    </figure>
                  );
                })}
              </div>
            </section>
          ))
        )}
        {!loading && !sections.length && <p className="mt-6 text-sm text-muted">No photos in this group.</p>}
      </div>

      {lightboxImage && (
        <div
          className="fixed inset-0 z-[90] flex items-center justify-center bg-black/80 p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Photo preview"
          onClick={() => setLightboxId(null)}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={lightboxImage.filePath}
            alt={lightboxImage.kind && isImageKind(lightboxImage.kind) ? IMAGE_KIND_LABELS_EN[lightboxImage.kind] : "Photo"}
            className="max-h-[90vh] max-w-[90vw] object-contain"
            onClick={(event) => event.stopPropagation()}
          />
          <button
            type="button"
            onClick={() => setLightboxId(null)}
            className="absolute right-4 top-4 grid h-9 w-9 place-items-center rounded-full bg-black/60 text-lg text-white hover:bg-black/80"
            aria-label="Close preview"
          >
            ×
          </button>
        </div>
      )}
    </div>
  );
}
