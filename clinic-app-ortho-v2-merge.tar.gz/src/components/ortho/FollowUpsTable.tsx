"use client";

// شارت التقويم v2 — "Follow ups" (النسخة الحقيقية، دمج 2026-08-27). نفس
// السلوك بالظبط اللي كان في البروتوتايب المعزول: خدمة الـBonding بتتقفل
// نهائيًا بمجرد ما تتطبق، الوير لازم مقاس ونوع مع بعض أو Same/فاضي، زرار Save
// واحد بيطبق كل حاجة مرة واحدة، وزرار Edit بعد الحفظ (لو معاك الصلاحية) بيفتح
// باقي الحقول تاني من غير الـService. الفرق: الزيارات دلوقتي صفوف حقيقية في
// ortho_visits — "+ New visit" بيضيف صف مسودة محلي (draft-...) لحد ما تدوس
// Save، وبعدها بيتحول لصف حقيقي بمعرف رقمي حقيقي.

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { saveOrthoVisitAction } from "@/app/patients/[id]/orthodontics/ortho-v2-actions";

const MOCK_SERVICES = ["Follow up", "Bonding Upper", "Bonding Lower", "Debonding", "Retainer delivery", "Consultation"];

export interface OrthoDoctorOption {
  id: number;
  full_name: string;
}

export interface OrthoOptionLists {
  wireSizes: string[];
  wireTypes: string[];
  otieColors: string[];
  elasticSizes: string[];
}

export interface OrthoVisitRow {
  id: number;
  date: string;
  service: string;
  upperSize: string;
  upperType: string;
  lowerSize: string;
  lowerType: string;
  note: string;
  elasticsDispensed: boolean;
  elasticsSize: string;
  otieColor: string;
  powerChainQty: string;
  buttonsQty: string;
  compressedCoilMm: string;
  doctorId: number | null;
  bondingApplied: boolean;
}

interface DraftRow {
  id: string; // "draft-..."
  date: string;
  service: string;
  upperSize: string;
  upperType: string;
  lowerSize: string;
  lowerType: string;
  note: string;
  elasticsDispensed: boolean;
  elasticsSize: string;
  otieColor: string;
  powerChainQty: string;
  buttonsQty: string;
  compressedCoilMm: string;
  doctorId: number | null;
  upperSizeInvalid: boolean;
  upperTypeInvalid: boolean;
  lowerSizeInvalid: boolean;
  lowerTypeInvalid: boolean;
}

function todayStr(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function makeDraftRow(defaultDoctorId: number | null): DraftRow {
  return {
    id: `draft-${Date.now()}-${Math.random()}`,
    date: "",
    service: "",
    upperSize: "",
    upperType: "",
    lowerSize: "",
    lowerType: "",
    note: "",
    elasticsDispensed: false,
    elasticsSize: "",
    otieColor: "",
    powerChainQty: "",
    buttonsQty: "",
    compressedCoilMm: "",
    doctorId: defaultDoctorId,
    upperSizeInvalid: false,
    upperTypeInvalid: false,
    lowerSizeInvalid: false,
    lowerTypeInvalid: false,
  };
}

function AutoGrowTextarea({
  value,
  onChange,
  placeholder,
  disabled = false,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  disabled?: boolean;
}) {
  return (
    <textarea
      value={value}
      onChange={(e) => {
        onChange(e.target.value);
        e.target.style.height = "auto";
        e.target.style.height = `${e.target.scrollHeight}px`;
      }}
      placeholder={placeholder}
      rows={1}
      disabled={disabled}
      className="w-full min-w-0 resize-none overflow-hidden rounded-md border border-border bg-background px-2 py-1 text-xs disabled:opacity-60 disabled:cursor-not-allowed"
    />
  );
}

function Dropdown({
  value,
  onChange,
  options,
  placeholder = "—",
  className = "",
  disabled = false,
  error = false,
}: {
  value: string;
  onChange: (v: string) => void;
  options: string[];
  placeholder?: string;
  className?: string;
  disabled?: boolean;
  error?: boolean;
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      disabled={disabled}
      className={`rounded-md border bg-background px-1.5 py-1 text-xs disabled:opacity-60 disabled:cursor-not-allowed ${
        error ? "border-red-500 ring-1 ring-red-500" : "border-border"
      } ${className}`}
    >
      <option value="">{placeholder}</option>
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  );
}

function isRealWire(v: string) {
  return v !== "" && v !== "Same";
}

export default function FollowUpsTable({
  patientId,
  editable,
  canEditAfterSave,
  defaultDoctorId,
  doctors,
  options,
  visits,
}: {
  patientId: number;
  editable: boolean;
  canEditAfterSave: boolean;
  defaultDoctorId: number | null;
  doctors: OrthoDoctorOption[];
  options: OrthoOptionLists;
  visits: OrthoVisitRow[];
}) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [drafts, setDrafts] = useState<DraftRow[]>([]);
  const [unlockedIds, setUnlockedIds] = useState<Set<number>>(new Set());
  const [editBuffers, setEditBuffers] = useState<Record<number, OrthoVisitRow>>({});

  function addVisit() {
    setDrafts((prev) => [makeDraftRow(defaultDoctorId), ...prev]);
  }

  function patchDraft(id: string, patch: Partial<DraftRow>) {
    setDrafts((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  }

  function onWireChangeDraft(id: string, patch: Partial<DraftRow>) {
    const clears: Partial<DraftRow> = {};
    if ("upperSize" in patch || "upperType" in patch) {
      clears.upperSizeInvalid = false;
      clears.upperTypeInvalid = false;
    }
    if ("lowerSize" in patch || "lowerType" in patch) {
      clears.lowerSizeInvalid = false;
      clears.lowerTypeInvalid = false;
    }
    patchDraft(id, { ...patch, ...clears });
  }

  function startEdit(v: OrthoVisitRow) {
    setEditBuffers((prev) => ({ ...prev, [v.id]: { ...v } }));
    setUnlockedIds((prev) => new Set(prev).add(v.id));
  }

  function patchEditBuffer(id: number, patch: Partial<OrthoVisitRow>) {
    setEditBuffers((prev) => ({ ...prev, [id]: { ...prev[id], ...patch } }));
  }

  function validateWire(r: { upperSize: string; upperType: string; lowerSize: string; lowerType: string }) {
    const upperSizeSet = isRealWire(r.upperSize);
    const upperTypeSet = isRealWire(r.upperType);
    const lowerSizeSet = isRealWire(r.lowerSize);
    const lowerTypeSet = isRealWire(r.lowerType);
    return {
      upperSizeInvalid: upperTypeSet && !upperSizeSet,
      upperTypeInvalid: upperSizeSet && !upperTypeSet,
      lowerSizeInvalid: lowerTypeSet && !lowerSizeSet,
      lowerTypeInvalid: lowerSizeSet && !lowerTypeSet,
    };
  }

  function saveDraft(id: string) {
    const r = drafts.find((row) => row.id === id);
    if (!r) return;
    const invalid = validateWire(r);
    if (invalid.upperSizeInvalid || invalid.upperTypeInvalid || invalid.lowerSizeInvalid || invalid.lowerTypeInvalid) {
      patchDraft(id, invalid);
      return;
    }
    const date = r.date || todayStr();
    startTransition(async () => {
      const res = await saveOrthoVisitAction({
        patientId,
        date,
        service: r.service,
        upperWireSize: r.upperSize,
        upperWireType: r.upperType,
        lowerWireSize: r.lowerSize,
        lowerWireType: r.lowerType,
        note: r.note,
        elasticsDispensed: r.elasticsDispensed,
        elasticsSize: r.elasticsSize,
        otieColor: r.otieColor,
        powerChainQty: r.powerChainQty,
        buttonsQty: r.buttonsQty,
        compressedCoilMm: r.compressedCoilMm,
        doctorId: r.doctorId,
      });
      if (!res.ok) {
        window.alert(res.reason || "حصل خطأ، حاول تاني.");
        return;
      }
      setDrafts((prev) => prev.filter((row) => row.id !== id));
      router.refresh();
    });
  }

  function saveEdit(id: number) {
    const r = editBuffers[id];
    if (!r) return;
    const invalid = validateWire(r);
    if (invalid.upperSizeInvalid || invalid.upperTypeInvalid || invalid.lowerSizeInvalid || invalid.lowerTypeInvalid) {
      window.alert("Wire needs both a size and a type — or leave it as \"Same\"");
      return;
    }
    startTransition(async () => {
      const res = await saveOrthoVisitAction({
        patientId,
        visitId: id,
        date: r.date || todayStr(),
        service: r.service,
        upperWireSize: r.upperSize,
        upperWireType: r.upperType,
        lowerWireSize: r.lowerSize,
        lowerWireType: r.lowerType,
        note: r.note,
        elasticsDispensed: r.elasticsDispensed,
        elasticsSize: r.elasticsSize,
        otieColor: r.otieColor,
        powerChainQty: r.powerChainQty,
        buttonsQty: r.buttonsQty,
        compressedCoilMm: r.compressedCoilMm,
        doctorId: r.doctorId,
      });
      if (!res.ok) {
        window.alert(res.reason || "حصل خطأ، حاول تاني.");
        return;
      }
      setUnlockedIds((prev) => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
      router.refresh();
    });
  }

  const allRows: Array<{ kind: "draft"; row: DraftRow } | { kind: "saved"; row: OrthoVisitRow }> = [
    ...drafts.map((row) => ({ kind: "draft" as const, row })),
    ...visits.map((row) => ({ kind: "saved" as const, row })),
  ];

  return (
    <div className={`card-3d rounded-xl p-5 space-y-3 ${isPending ? "opacity-70 pointer-events-none" : ""}`}>
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h3 className="font-bold">Follow ups</h3>
        {editable && (
          <button
            type="button"
            onClick={addVisit}
            className="text-xs px-3 py-1.5 rounded-md border border-dashed border-border hover:bg-primary-soft text-muted"
          >
            + New visit
          </button>
        )}
      </div>

      {allRows.length === 0 && <p className="text-xs text-muted">No visits recorded yet.</p>}

      <div>
        {allRows.map((entry, idx) => {
          const isDraft = entry.kind === "draft";
          const saved = entry.kind === "saved";
          const unlocked = saved && unlockedIds.has(entry.row.id);
          const locked = saved && !unlocked;
          const r = isDraft ? entry.row : unlocked ? editBuffers[entry.row.id] ?? entry.row : entry.row;
          const bondingApplied = saved && entry.row.bondingApplied;

          const patch = (p: Record<string, unknown>) => {
            if (isDraft) patchDraft(entry.row.id, p);
            else if (unlocked) patchEditBuffer(entry.row.id, p);
          };
          const patchWire = (p: Record<string, unknown>) => {
            if (isDraft) onWireChangeDraft(entry.row.id, p);
            else if (unlocked) patchEditBuffer(entry.row.id, p);
          };
          const fieldsDisabled = !editable || (saved && !unlocked);
          const wireErrors = isDraft ? entry.row : { upperSizeInvalid: false, upperTypeInvalid: false, lowerSizeInvalid: false, lowerTypeInvalid: false };

          return (
            <div key={isDraft ? entry.row.id : `v-${entry.row.id}`}>
              {idx > 0 && <div className="my-3 border-t-2 border-dashed border-border" />}
              <div className={`rounded-lg border border-border p-3 space-y-2 ${locked ? "bg-primary-soft/20" : ""}`}>
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <div className="flex items-center gap-3 flex-wrap">
                    <input
                      type="date"
                      value={r.date}
                      disabled={fieldsDisabled}
                      onChange={(e) => patch({ date: e.target.value })}
                      className="text-xs px-2 py-1 rounded-md border border-border disabled:opacity-60 disabled:cursor-not-allowed"
                    />
                    <Dropdown
                      value={r.service}
                      onChange={(v) => patch({ service: v })}
                      options={MOCK_SERVICES}
                      placeholder="Service"
                      disabled={fieldsDisabled || bondingApplied}
                    />

                    <div className="flex items-center gap-1.5 text-xs">
                      <span className="font-semibold text-muted w-4 shrink-0">U</span>
                      <Dropdown value={r.upperSize} onChange={(v) => patchWire({ upperSize: v })} options={options.wireSizes} placeholder="Size" disabled={fieldsDisabled} error={"upperSizeInvalid" in wireErrors ? wireErrors.upperSizeInvalid : false} />
                      <Dropdown value={r.upperType} onChange={(v) => patchWire({ upperType: v })} options={options.wireTypes} placeholder="Type" disabled={fieldsDisabled} error={"upperTypeInvalid" in wireErrors ? wireErrors.upperTypeInvalid : false} />
                    </div>
                    <div className="flex items-center gap-1.5 text-xs">
                      <span className="font-semibold text-muted w-4 shrink-0">L</span>
                      <Dropdown value={r.lowerSize} onChange={(v) => patchWire({ lowerSize: v })} options={options.wireSizes} placeholder="Size" disabled={fieldsDisabled} error={"lowerSizeInvalid" in wireErrors ? wireErrors.lowerSizeInvalid : false} />
                      <Dropdown value={r.lowerType} onChange={(v) => patchWire({ lowerType: v })} options={options.wireTypes} placeholder="Type" disabled={fieldsDisabled} error={"lowerTypeInvalid" in wireErrors ? wireErrors.lowerTypeInvalid : false} />
                    </div>
                  </div>
                  <select
                    value={r.doctorId != null ? String(r.doctorId) : ""}
                    onChange={(e) => patch({ doctorId: e.target.value ? Number(e.target.value) : null })}
                    disabled={fieldsDisabled}
                    className="rounded-md border border-border bg-background px-1.5 py-1 text-xs disabled:opacity-60 disabled:cursor-not-allowed min-w-[110px]"
                  >
                    <option value="">Doctor</option>
                    {doctors.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.full_name}
                      </option>
                    ))}
                  </select>
                </div>

                <AutoGrowTextarea value={r.note} onChange={(v) => patch({ note: v })} placeholder="e.g.: retraction 13 & 23" disabled={fieldsDisabled} />

                <div className="flex items-center gap-4 flex-wrap text-xs pt-1 border-t border-border">
                  <label className="flex items-center gap-1.5">
                    <input
                      type="checkbox"
                      checked={r.elasticsDispensed}
                      disabled={fieldsDisabled}
                      onChange={(e) => patch({ elasticsDispensed: e.target.checked, elasticsSize: e.target.checked ? r.elasticsSize : "" })}
                    />
                    Elastics dispensed
                    {r.elasticsDispensed && (
                      <Dropdown value={r.elasticsSize} onChange={(v) => patch({ elasticsSize: v })} options={options.elasticSizes} placeholder="Size" disabled={fieldsDisabled} />
                    )}
                  </label>
                  <div className="flex items-center gap-3 whitespace-nowrap">
                    <label className="flex items-center gap-1.5">
                      O-tie color
                      <Dropdown value={r.otieColor} onChange={(v) => patch({ otieColor: v })} options={options.otieColors} placeholder="—" disabled={fieldsDisabled} />
                    </label>
                    <label className="flex items-center gap-1.5">
                      Power chain
                      <input
                        type="number"
                        min={0}
                        value={r.powerChainQty}
                        disabled={fieldsDisabled}
                        onChange={(e) => patch({ powerChainQty: e.target.value })}
                        placeholder="0"
                        className="w-14 rounded-md border border-border bg-background px-1.5 py-1 text-xs disabled:opacity-60 disabled:cursor-not-allowed"
                      />
                    </label>
                    <label className="flex items-center gap-1.5">
                      Buttons
                      <input
                        type="number"
                        min={0}
                        value={r.buttonsQty}
                        disabled={fieldsDisabled}
                        onChange={(e) => patch({ buttonsQty: e.target.value })}
                        placeholder="0"
                        className="w-14 rounded-md border border-border bg-background px-1.5 py-1 text-xs disabled:opacity-60 disabled:cursor-not-allowed"
                      />
                    </label>
                    <label className="flex items-center gap-1.5">
                      Compressed coil (mm)
                      <input
                        type="number"
                        min={0}
                        value={r.compressedCoilMm}
                        disabled={fieldsDisabled}
                        onChange={(e) => patch({ compressedCoilMm: e.target.value })}
                        placeholder="0"
                        className="w-14 rounded-md border border-border bg-background px-1.5 py-1 text-xs disabled:opacity-60 disabled:cursor-not-allowed"
                      />
                    </label>
                  </div>

                  {isDraft && (wireErrors.upperSizeInvalid || wireErrors.upperTypeInvalid || wireErrors.lowerSizeInvalid || wireErrors.lowerTypeInvalid) && (
                    <span className="text-red-600 text-xs">Wire needs both a size and a type — or leave it as &quot;Same&quot;</span>
                  )}

                  {editable && isDraft && (
                    <button type="button" onClick={() => saveDraft(entry.row.id)} className="ml-auto px-3 py-1.5 rounded-md text-xs font-medium shrink-0 btn-3d-primary">
                      Save
                    </button>
                  )}
                  {saved && locked && (
                    <div className="ml-auto flex items-center gap-2 shrink-0">
                      <span className="px-3 py-1.5 rounded-md text-xs font-medium border border-green-300 bg-green-50 text-green-700 cursor-default" title="This visit is saved">
                        ✓ Saved
                      </span>
                      {editable && canEditAfterSave && (
                        <button
                          type="button"
                          onClick={() => startEdit(entry.row)}
                          className="text-xs text-primary underline hover:no-underline"
                          title={
                            entry.row.bondingApplied
                              ? "Fix wire/elastics/O-tie/power chain/etc — the bonding itself is corrected on the chart, not here"
                              : "Fix this visit's details"
                          }
                        >
                          Edit
                        </button>
                      )}
                    </div>
                  )}
                  {saved && unlocked && (
                    <button type="button" onClick={() => saveEdit(entry.row.id)} className="ml-auto px-3 py-1.5 rounded-md text-xs font-medium shrink-0 btn-3d-primary">
                      Save
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
