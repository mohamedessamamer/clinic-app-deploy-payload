"use client";

// Batch 126: عرض التمبلت — صور المجموعة مرتّبة بالترتيب المتفق عليه:
//   Extra-Oral (أمامي ← جانبي ← 45 درجة) ← Intra-Oral (أمامي ← يمين ← شمال ←
//   علوي ← سفلي) ← X-ray (بانوراما ← سيفالومتري ← باقي الأشعة) ← Templates
//   (أي تمبلت جاهز اتعمل برة السيستم واترفع مع الصور).
// ٣ صور في الصف، كل صورة في إطار بنسبة ثابتة (4:3) والصورة جواه كاملة من غير
// أي مط — الأبعاد الحقيقية بتفضل زي ما هي.
//
// Batch 127: دوسة على الصورة تفتحها بحجمها الكامل (lightbox)، ودوسة على
// التعريف تحتها تفتح قائمة بكل الأنواع المعروفة عند السيستم — اختيار نوع
// بينقل الصورة فورًا لمكانها الصح ويسجّل التصحيح لمراجعة بشرية لاحقًا (بدون
// أي تعديل تلقائي على سلوك التصنيف نفسه).
//
// Batch 127 (الجولة التانية): الطلب "عايز لما ادوس على صورة في الtemplate
// واكبرها يبقى فيها نفس صلاحيات عرض الصورة من الشريط .. السهم الجانبي ينقل
// الصور و علامة الrotate وعلامة x لمسح الصورة" — الـlightbox هنا بقى بنفس
// نمط OrthoImageGallery.tsx (تنقل بالمؤشر فوق قايمة مسطّحة بترتيب العرض، مع
// دعم لوحة المفاتيح)، وزرار rotate بينادي rotateImageAction اللي بقت (نفس
// الدفعة) بتخبّز الدوران فعليًا في الملف وتعيد التصنيف — فبعد الدوران بنعيد
// جلب بيانات المجموعة عشان أي تغيير في النوع/الترتيب يبان فورًا. وزرار X
// بينادي deleteImageAction زي شريط الصور بالظبط (تأكيد قبل الحذف).
// كمان: "لو دوست في الشاشة برة الtemplate يقفله ويرجع للشارت" — الخلفية
// السودة بتاعة نافذة التمبلت نفسها (مش الـlightbox) بقى ليها onClick يقفل
// المودال كله.

import { useCallback, useEffect, useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { suggestGroupTemplateAction, setImageKindAction, reclassifyGroupAction, type TemplateImage } from "@/app/patients/[id]/images/template-actions";
import { deleteImageAction, rotateImageAction } from "@/app/patients/[id]/actions";
import { IMAGE_KINDS, IMAGE_KIND_LABELS_EN, isImageKind, type ImageKind } from "@/lib/images/kinds";
import { SECTION_LABELS, SECTION_ORDER, imageSortRank, sectionOf, type ImageSection } from "@/lib/images/order";

type Props = { groupId: number; patientId: number; onClose: () => void };

// Batch 128: التدوير اليدوي بقى بيخبز البايتات فعليًا على نفس المسار — لازم
// نغيّر شكل الرابط (query param) كل ما المحتوى يتغيّر، وإلا React مش هيعيد
// تحميل عنصر <img> أصلًا (نفس src = نفس عنصر DOM، من غير أي طلب شبكة جديد)
// حتى لو bytes الملف اتغيّرت فعلاً على السيرفر.
function withCacheBust(filePath: string, contentHash?: string | null): string {
  if (!contentHash) return filePath;
  return `${filePath}?v=${contentHash.slice(0, 12)}`;
}

export default function ImageTemplateBoard({ groupId, patientId, onClose }: Props) {
  const router = useRouter();
  const [, startTransition] = useTransition();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [images, setImages] = useState<TemplateImage[]>([]);
  const [openId, setOpenId] = useState<number | null>(null);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [savingId, setSavingId] = useState<number | null>(null);
  const [busyId, setBusyId] = useState<number | null>(null);

  const load = useCallback(() => {
    return suggestGroupTemplateAction(groupId).then((result) => {
      if (!result.ok || !result.images) {
        setError(result.error || "Could not load the photos.");
        setLoading(false);
        return;
      }
      setImages(result.images);
      setLoading(false);
    });
  }, [groupId]);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [groupId]);

  const sections = useMemo(() => {
    const ordered = [...images].sort((a, b) => imageSortRank(a.kind) - imageSortRank(b.kind) || a.id - b.id);
    const grouped = new Map<ImageSection, TemplateImage[]>();
    for (const image of ordered) {
      const section = sectionOf(image.kind);
      grouped.set(section, [...(grouped.get(section) ?? []), image]);
    }
    return SECTION_ORDER.map((section) => ({ section, items: grouped.get(section) ?? [] })).filter((entry) => entry.items.length > 0);
  }, [images]);

  // ليستة مسطحة بنفس ترتيب العرض — عشان أسهم التنقل في الـlightbox تمشي
  // بنفس ترتيب الأقسام على الشاشة، زي شريط الصور بالظبط.
  const flatImages = useMemo(() => sections.flatMap((entry) => entry.items), [sections]);
  const openIndex = openId != null ? flatImages.findIndex((image) => image.id === openId) : -1;
  const openImage = openIndex >= 0 ? flatImages[openIndex] : null;

  const close = useCallback(() => setOpenId(null), []);
  const prev = useCallback(() => {
    setOpenId((current) => {
      if (current == null || flatImages.length === 0) return current;
      const index = flatImages.findIndex((image) => image.id === current);
      if (index < 0) return current;
      return flatImages[(index - 1 + flatImages.length) % flatImages.length].id;
    });
  }, [flatImages]);
  const next = useCallback(() => {
    setOpenId((current) => {
      if (current == null || flatImages.length === 0) return current;
      const index = flatImages.findIndex((image) => image.id === current);
      if (index < 0) return current;
      return flatImages[(index + 1) % flatImages.length].id;
    });
  }, [flatImages]);

  useEffect(() => {
    if (openId == null) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") close();
      else if (e.key === "ArrowLeft") prev();
      else if (e.key === "ArrowRight") next();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [openId, close, prev, next]);

  async function applyKind(imageId: number, newKind: ImageKind) {
    setEditingId(null);
    setSavingId(imageId);
    setError("");
    try {
      const result = await setImageKindAction(imageId, newKind);
      if (!result.ok) {
        setError(result.error || "Could not update the photo type.");
        return;
      }
      // النتيجة بتتحدّث محليًا فورًا عشان الصورة تتنقل لمكانها الجديد في الحال،
      // من غير ما نستنى إعادة تحميل كل التمبلت من السيرفر.
      setImages((prev) => prev.map((image) => (image.id === imageId ? { ...image, kind: newKind, confidence: 1, slot: null } : image)));
    } finally {
      setSavingId(null);
    }
  }

  function handleRotate(imageId: number) {
    setBusyId(imageId);
    setError("");
    const formData = new FormData();
    formData.set("image_id", String(imageId));
    formData.set("patient_id", String(patientId));
    startTransition(async () => {
      try {
        await rotateImageAction(formData);
        // Batch 128: التدوير دلوقتي بيخبز البكسلات وبصمة المحتوى بس — من غير
        // أي إعادة تصنيف تلقائية (شوف الكومنت فوق rotateImageAction نفسها).
        // إعادة الجلب هنا هدفها الوحيد إننا نجيب بصمة المحتوى الجديدة عشان
        // رابط الصورة يتغيّر (cache-bust) والمتصفح يعرض النسخة المدوّرة
        // فورًا، مش لإعادة ترتيب التمبلت. لإعادة الترتيب/التصنيف بعد التدوير،
        // فيه زرار "↻ Re-detect" منفصل تحت.
        await load();
        router.refresh();
      } catch (error) {
        // Batch 128: قبل كده أي فشل هنا كان بيختفي بصمت (الزرار "مبيعملش
        // حاجة" من غير أي رسالة). دلوقتي أي خطأ بيبان للمستخدم بدل ما يفضل
        // يدوس على الزرار من غير ما يعرف ليه مفيش تغيير.
        console.error("[images] handleRotate failed", error);
        setError("Could not rotate the photo. Please try again or refresh the page.");
      } finally {
        setBusyId(null);
      }
    });
  }

  // Batch 128: خطوة صريحة ومنفصلة عن التدوير — بعد ما الدكتور يخلّص تدوير كل
  // الصور اللي محتاجة تصحيح في المجموعة، بيدوس هنا مرة واحدة يعيد تصنيف/ترتيب
  // كل صور المجموعة (reclassifyGroupAction، نفس الزرار الموجود أصلًا في شريط
  // الصور بره التمبلت). ده هو "بعد كدة نعمل redetect يحطه في مكانه الصح".
  const [redetecting, setRedetecting] = useState(false);
  function handleRedetectGroup() {
    setRedetecting(true);
    setError("");
    startTransition(async () => {
      try {
        const result = await reclassifyGroupAction(groupId);
        if (!result.ok) setError(result.error || "Could not re-detect the photos.");
        await load();
        router.refresh();
      } catch (error) {
        console.error("[images] handleRedetectGroup failed", error);
        setError("Could not re-detect the photos. Please try again.");
      } finally {
        setRedetecting(false);
      }
    });
  }

  function handleDelete(imageId: number) {
    const ok = window.confirm("Delete this photo? This can't be undone.");
    if (!ok) return;
    setBusyId(imageId);
    const formData = new FormData();
    formData.set("image_id", String(imageId));
    formData.set("patient_id", String(patientId));
    startTransition(async () => {
      await deleteImageAction(formData);
      setImages((prev) => prev.filter((image) => image.id !== imageId));
      if (openId === imageId) {
        // بعد الحذف: افتح الجاي في الترتيب لو موجود، غير كده اقفل الـlightbox.
        const index = flatImages.findIndex((image) => image.id === imageId);
        const remaining = flatImages.filter((image) => image.id !== imageId);
        setOpenId(remaining.length ? remaining[Math.min(index, remaining.length - 1)].id : null);
      }
      setBusyId(null);
      router.refresh();
    });
  }

  const openRotated90 = openImage ? openImage.rotation % 180 !== 0 : false;

  return (
    <div
      className="fixed inset-0 z-[80] flex items-center justify-center bg-black/45 p-3"
      role="dialog"
      aria-modal="true"
      aria-label="Patient photo template"
      onClick={onClose}
    >
      <div className="card-3d w-full max-w-5xl max-h-[92vh] overflow-y-auto rounded-xl p-4 text-left" dir="ltr" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between gap-2">
          <h3 className="font-semibold">Patient photo template</h3>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleRedetectGroup}
              disabled={redetecting || loading}
              className="rounded-md border border-border px-3 py-1.5 text-sm hover:bg-primary-soft disabled:opacity-60"
              title="Re-run classification/ordering for this whole group (do this after rotating photos)"
            >
              {redetecting ? "…detecting" : "↻ Re-detect"}
            </button>
            <button type="button" onClick={onClose} className="rounded-md border border-border px-3 py-1.5 text-sm hover:bg-primary-soft">Close</button>
          </div>
        </div>
        {error && <p className="mt-2 text-sm text-danger">{error}</p>}
        {loading ? (
          <p className="mt-6 text-sm text-muted">Loading photos…</p>
        ) : (
          sections.map(({ section, items }) => (
            <section key={section} className="mt-5">
              <h4 className="image-template-section-title">{SECTION_LABELS[section]}</h4>
              <div className="image-template-sheet">
                {items.map((image) => {
                  const label = image.kind && isImageKind(image.kind) ? IMAGE_KIND_LABELS_EN[image.kind] : "Unclassified";
                  return (
                    <figure key={image.id} className="image-template-cell">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={withCacheBust(image.filePath, image.contentHash)}
                        alt={label}
                        onClick={() => setOpenId(image.id)}
                        className="cursor-zoom-in"
                        title="Click to view full size"
                        style={image.rotation ? { transform: `rotate(${image.rotation}deg)` } : undefined}
                      />
                      <figcaption>
                        <button
                          type="button"
                          onClick={() => setEditingId(editingId === image.id ? null : image.id)}
                          disabled={savingId === image.id}
                          className="w-full text-left hover:underline disabled:opacity-60"
                          title="Click to fix the photo type"
                        >
                          {savingId === image.id ? "Saving…" : label}
                        </button>
                        {editingId === image.id && (
                          <select
                            autoFocus
                            defaultValue=""
                            onChange={(event) => {
                              const value = event.target.value;
                              if (isImageKind(value)) applyKind(image.id, value);
                            }}
                            onBlur={() => setEditingId(null)}
                            className="mt-1 w-full rounded border border-border bg-background px-1 py-0.5 text-xs"
                          >
                            <option value="" disabled>Choose type…</option>
                            {IMAGE_KINDS.map((kind) => (
                              <option key={kind} value={kind}>{IMAGE_KIND_LABELS_EN[kind]}</option>
                            ))}
                          </select>
                        )}
                      </figcaption>
                    </figure>
                  );
                })}
              </div>
            </section>
          ))
        )}
        {!loading && !sections.length && <p className="mt-6 text-sm text-muted">No photos in this group.</p>}
      </div>

      {openImage && (
        <div
          className="fixed inset-0 z-[90] flex items-center justify-center bg-black/80 p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Photo preview"
          onClick={(e) => { e.stopPropagation(); close(); }}
        >
          {flatImages.length > 1 && (
            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); prev(); }}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-white/80 hover:text-white text-4xl px-3 py-2 select-none"
              aria-label="Previous"
            >
              ‹
            </button>
          )}

          <div
            className={`flex items-center justify-center ${openRotated90 ? "max-w-[85vh] max-h-[90vw]" : "max-w-[90vw] max-h-[85vh]"}`}
            onClick={(e) => e.stopPropagation()}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={withCacheBust(openImage.filePath, openImage.contentHash)}
              alt={openImage.kind && isImageKind(openImage.kind) ? IMAGE_KIND_LABELS_EN[openImage.kind] : "Photo"}
              className={openRotated90 ? "max-h-[85vh] max-w-[85vh] object-contain rounded shadow-2xl" : "max-w-[90vw] max-h-[85vh] object-contain rounded shadow-2xl"}
              style={openImage.rotation ? { transform: `rotate(${openImage.rotation}deg)` } : undefined}
            />
          </div>

          {flatImages.length > 1 && (
            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); next(); }}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-white/80 hover:text-white text-4xl px-3 py-2 select-none"
              aria-label="Next"
            >
              ›
            </button>
          )}

          <div className="absolute top-4 right-4 flex items-center gap-2">
            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); handleRotate(openImage.id); }}
              disabled={busyId === openImage.id}
              className="whitespace-nowrap text-white/90 hover:text-white text-sm bg-black/40 hover:bg-black/60 rounded-md px-3 py-1.5 transition-colors disabled:opacity-60"
            >
              ⟳ Rotate
            </button>
            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); handleDelete(openImage.id); }}
              disabled={busyId === openImage.id}
              className="whitespace-nowrap text-white/90 hover:text-white text-sm bg-black/40 hover:bg-red-600/80 rounded-md px-3 py-1.5 transition-colors disabled:opacity-60"
              aria-label="Delete photo"
            >
              × Delete
            </button>
          </div>

          <div className="absolute bottom-4 inset-x-0 text-center text-white/70 text-xs">
            {openIndex + 1} / {flatImages.length}
          </div>
        </div>
      )}
    </div>
  );
}
