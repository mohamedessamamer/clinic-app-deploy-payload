"use client";

import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { getPatientDebtsReportAction, type PatientDebtsResult } from "@/app/reports/debts-actions";
import { openWhatsAppWindow } from "@/lib/whatsapp/client-url";
import { useUrlReportParams, writeUrlReportParams } from "@/lib/url-report-state";

const input = "rounded border border-border bg-background px-2 py-1.5 text-sm";

type Specialty = "all" | "ortho" | "general";
type Sort = "amount_desc" | "oldest_first";

// دفعة 138: الفلاتر والنتيجة بيتسجلوا في رابط الصفحة، عشان لو دُست على اسم
// مريض وفتحت ملفه ورجعت بزرار "رجوع" في المتصفح، ترجع بنفس التخصص/الترتيب/
// الفترة ونفس النتيجة اللي كانت ظاهرة - مش شاشة فاضية بفلاتر افتراضية.
const urlKeys = ["debts_specialty", "debts_sort", "debts_minDebt", "debts_fromDate", "debts_toDate", "debts_page", "debts_applied"];

export default function PatientDebtsReport() {
  const router = useRouter();
  const initialUrl = useUrlReportParams(urlKeys);
  const [specialty, setSpecialty] = useState<Specialty>((initialUrl.debts_specialty as Specialty) || "all");
  const [sort, setSort] = useState<Sort>((initialUrl.debts_sort as Sort) || "amount_desc");
  const [minDebt, setMinDebt] = useState(initialUrl.debts_minDebt ?? "");
  // فلتر بفترة نشأة المديونية (تاريخ الفاتورة الأصلية) — مثلاً من 2023-01-01
  // لعرض "مرضى مديونين من سنة 2023". فاضي = بلا حد.
  const [fromDate, setFromDate] = useState(initialUrl.debts_fromDate ?? "");
  const [toDate, setToDate] = useState(initialUrl.debts_toDate ?? "");
  const [result, setResult] = useState<PatientDebtsResult | null>(null);
  const [page, setPage] = useState(1);
  const [isPending, startTransition] = useTransition();

  // لو راجعين من رابط فيه تقرير كان اتشغل قبل كده (applied=1)، شغّله تاني
  // تلقائيًا بنفس الفلاتر وبنفس الصفحة عشان الجدول يرجع يظهر من غير ما نضغط
  // "عرض التقرير" تاني.
  useEffect(() => {
    if (initialUrl.debts_applied === "1") run(initialUrl.debts_page ? Number(initialUrl.debts_page) || 1 : 1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function run(nextPage = 1) {
    setPage(nextPage);
    writeUrlReportParams(router, {
      debts_specialty: specialty,
      debts_sort: sort,
      debts_minDebt: minDebt || null,
      debts_fromDate: fromDate || null,
      debts_toDate: toDate || null,
      debts_page: String(nextPage),
      debts_applied: "1",
    });
    startTransition(async () => {
      setResult(
        await getPatientDebtsReportAction({
          specialty,
          sort,
          minDebt: minDebt ? Number(minDebt) : 0,
          fromDate: fromDate || null,
          toDate: toDate || null,
          page: nextPage,
        })
      );
    });
  }

  function sendReminder(url: string | null) {
    if (!url) return;
    openWhatsAppWindow(url);
  }

  return (
    <section className="card-3d rounded-xl p-5 space-y-4">
      <div>
        <h2 className="font-semibold">مديونيات المرضى</h2>
        <p className="mt-1 text-xs text-muted">
          إجمالي المبلغ المتبقي (غير المحصّل) على كل مريض عبر كل فواتيره، مع تاريخ أقدم فاتورة لسه مديونة عليه.
        </p>
      </div>

      <div className="flex flex-wrap items-end gap-2">
        <label className="text-xs text-muted">
          التخصص
          <select value={specialty} onChange={(e) => setSpecialty(e.target.value as Specialty)} className={`${input} mt-1 block w-32`}>
            <option value="all">الكل</option>
            <option value="ortho">تقويم</option>
            <option value="general">عام</option>
          </select>
        </label>
        <label className="text-xs text-muted">
          الترتيب
          <select value={sort} onChange={(e) => setSort(e.target.value as Sort)} className={`${input} mt-1 block w-40`}>
            <option value="amount_desc">الأكثر مديونية أولًا</option>
            <option value="oldest_first">الأقدم مديونية أولًا</option>
          </select>
        </label>
        <label className="text-xs text-muted">
          حد أدنى للمديونية (ج.م)
          <input
            type="number"
            min={0}
            value={minDebt}
            onChange={(e) => setMinDebt(e.target.value)}
            placeholder="0"
            className={`${input} mt-1 block w-32`}
          />
        </label>
        <label className="text-xs text-muted">
          مديون من تاريخ
          <input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} className={`${input} mt-1 block w-40`} />
        </label>
        <label className="text-xs text-muted">
          إلى تاريخ
          <input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} className={`${input} mt-1 block w-40`} />
        </label>
        <button
          type="button"
          onClick={() => run(1)}
          disabled={isPending}
          className="h-9 rounded-md btn-3d-primary px-4 text-sm font-medium disabled:opacity-50"
        >
          {isPending ? "..." : "عرض التقرير"}
        </button>
      </div>

      {result && !result.ok && (
        <p className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{result.error}</p>
      )}

      {result?.ok && (
        <div className="space-y-3">
          <div className="rounded-xl border border-danger/30 bg-danger/5 p-5 text-center">
            <div className="text-xs text-muted mb-1">
              إجمالي المديونية{fromDate || toDate ? " للفترة المختارة" : ""}
              {fromDate ? ` من ${fromDate}` : ""}
              {toDate ? ` إلى ${toDate}` : ""}
            </div>
            <div className="text-4xl font-extrabold text-danger">{result.totalDebtSum.toFixed(0)} ج.م</div>
            <div className="mt-1 text-xs text-muted">عن {result.totalRows} مريض مديون</div>
          </div>
          <p className="text-xs text-muted">
            صفحة {result.page} من {result.totalPages}.
          </p>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-right">
                  <th className="p-2">اسم المريض</th>
                  <th className="p-2 whitespace-nowrap">رقم الملف</th>
                  <th className="p-2">الدكتور</th>
                  <th className="p-2 whitespace-nowrap">عدد الفواتير</th>
                  <th className="p-2 whitespace-nowrap">أقدم مديونية</th>
                  <th className="p-2 whitespace-nowrap">إجمالي المديونية</th>
                  <th className="p-2 whitespace-nowrap">تذكير</th>
                </tr>
              </thead>
              <tbody>
                {result.rows.map((row) => (
                  <tr key={row.patientId} className="border-b border-border">
                    <td className="p-2 font-medium">
                      <Link href={`/patients/${row.patientId}/billing`} className="text-primary hover:underline">
                        {row.patientName}
                      </Link>
                    </td>
                    <td className="p-2 whitespace-nowrap">{row.fileNumber}</td>
                    <td className="p-2">{row.doctorName}</td>
                    <td className="p-2 whitespace-nowrap">{row.invoiceCount}</td>
                    <td className="p-2 whitespace-nowrap">{row.oldestInvoiceDate.slice(0, 10)}</td>
                    <td className="p-2 whitespace-nowrap text-danger font-semibold">{row.totalDebt.toFixed(0)} ج.م</td>
                    <td className="p-2 whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => sendReminder(row.whatsappUrl)}
                        disabled={!row.whatsappUrl}
                        title={row.whatsappUrl ? "إرسال تذكير واتساب" : "لا يوجد رقم تليفون مسجل"}
                        className="rounded border border-border px-2 py-1 text-xs text-primary hover:bg-primary-soft disabled:opacity-40"
                      >
                        واتساب
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!result.rows.length && <p className="py-6 text-center text-sm text-muted">لا يوجد مرضى عليهم مديونية حاليًا.</p>}
          </div>
          {result.totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 text-sm">
              <button type="button" disabled={isPending || page <= 1} onClick={() => run(page - 1)} className="rounded border border-border px-3 py-1 disabled:opacity-50">
                السابق
              </button>
              <span>
                صفحة {page} / {result.totalPages}
              </span>
              <button type="button" disabled={isPending || page >= result.totalPages} onClick={() => run(page + 1)} className="rounded border border-border px-3 py-1 disabled:opacity-50">
                التالي
              </button>
            </div>
          )}
        </div>
      )}
    </section>
  );
}
