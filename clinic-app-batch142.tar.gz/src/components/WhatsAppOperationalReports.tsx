"use client";

import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { getWhatsAppOperationalReportAction, reportPresetDatesAction, saveOrthoFollowupThresholdsAction } from "@/app/whatsapp/report-actions";
import { useUrlReportParams, writeUrlReportParams } from "@/lib/url-report-state";

type ReportType = "appointments" | "ortho" | "referrals" | "unpaid";
type ReportResult = Awaited<ReturnType<typeof getWhatsAppOperationalReportAction>>;
const PAGE_SIZE = 50;
const appointmentStatusLabels: Record<string, string> = { confirmed: "أكد الموعد", reschedule_pending: "طلب تعديل", no_response: "لم يرد", not_sent: "لم تُرسل", send_failed: "فشل الإرسال" };

// `only` بتحدد أنواع التقارير اللي المكوّن ده هيعرضها في المكان ده بالظبط.
// نفس المكوّن بقى بيتعرض في تلات أماكن: تأكيدات المواعيد في شاشة واتساب،
// "تم بدون دفع" في تبويب التقارير المالية، ومتابعة التقويم/التحويلات في تبويب
// تقارير المرضى. الصلاحيات زي ما هي بالظبط — اللي اتغير هو مكان العرض بس.
// دفعة 138: نفس المكوّن بيتعرض في تلات أماكن مختلفة (only=["unpaid"]،
// only=["ortho"]، only=["referrals"]، أو من غير only في شاشة واتساب) - كل
// مكان بياخد مفاتيح URL خاصة بيه (مبنية على only) عشان فلاتر مكان معين متتلخبطش
// مع فلاتر مكان تاني لو اتنقل بينهم.
function urlKeyPrefix(only?: ReportType[]) {
  return `wa_${(only && only.length ? only.join("_") : "all")}_`;
}

export default function WhatsAppOperationalReports({ canAppointment, canOrtho, canReferrals, canThresholds, only, defaultOpen, title }: { canAppointment: boolean; canOrtho: boolean; canReferrals: boolean; canThresholds: boolean; only?: ReportType[]; defaultOpen?: boolean; title?: string }) {
  const router = useRouter();
  const allChoices: { value: ReportType; label: string }[] = [...(canAppointment ? [{ value: "appointments" as const, label: "تأكيدات المواعيد والردود" }, { value: "unpaid" as const, label: "تم بدون دفع" }] : []), ...(canOrtho ? [{ value: "ortho" as const, label: "متابعة تقويم متأخرة" }] : []), ...(canReferrals ? [{ value: "referrals" as const, label: "التحويلات الطبية" }] : [])];
  const choices = only ? allChoices.filter((choice) => only.includes(choice.value)) : allChoices;
  const prefix = urlKeyPrefix(only);
  const urlKeys = [`${prefix}type`, `${prefix}from`, `${prefix}to`, `${prefix}applied`, `${prefix}page`];
  const initialUrl = useUrlReportParams(urlKeys);
  const initialType = (initialUrl[`${prefix}type`] as ReportType) || choices[0]?.value || "appointments";
  const [type, setType] = useState<ReportType>(choices.some((c) => c.value === initialType) ? initialType : (choices[0]?.value || "appointments"));
  const [range, setRange] = useState({ from: initialUrl[`${prefix}from`] ?? "", to: initialUrl[`${prefix}to`] ?? "" });
  const [result, setResult] = useState<ReportResult | null>(null);
  // دفعة 142: تقسيم النتيجة لصفحات (50 صف) — رقم الصفحة في الرابط عشان "رجوع"
  // من ملف المريض يرجع لنفس الصفحة.
  const [page, setPage] = useState(() => Math.max(1, Number(initialUrl[`${prefix}page`]) || 1));
  const goToPage = (next: number) => {
    setPage(next);
    writeUrlReportParams(router, { [`${prefix}page`]: String(next) });
  };
  const [busy, startTransition] = useTransition();
  const applyPreset = (preset: "tomorrow" | "week" | "month") => startTransition(async () => setRange(await reportPresetDatesAction(preset)));
  const show = (keepPage = false) => startTransition(async () => {
    let dates = range;
    if (!dates.from) dates = await reportPresetDatesAction("tomorrow");
    setRange(dates);
    writeUrlReportParams(router, { [`${prefix}type`]: type, [`${prefix}from`]: dates.from, [`${prefix}to`]: dates.to, [`${prefix}applied`]: "1", [`${prefix}page`]: String(keepPage ? page : 1) });
    if (!keepPage) setPage(1);
    setResult(await getWhatsAppOperationalReportAction(type, dates.from, dates.to));
  });
  // لو راجعين من رابط فيه تقرير كان اتشغل قبل كده لنفس المكان ده بالظبط، شغّله
  // تاني تلقائيًا بنفس النوع والفترة.
  useEffect(() => {
    if (initialUrl[`${prefix}applied`] === "1" && initialUrl[`${prefix}from`] && initialUrl[`${prefix}to`]) show(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  if (!choices.length) return null;
  const rows = result?.ok ? result.rows : [];
  const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const pageRows = rows.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
  const orthoTotals = result?.ok && result.type === "ortho" && "totals" in result ? result.totals : null;
  const thresholds = result?.ok && "thresholds" in result && result.thresholds ? result.thresholds : { first: 45, second: 90 };
  const patientLink = (patientId: number, name: string) => <Link href={`/patients/${patientId}/billing`} className="text-primary hover:underline">{name}</Link>;
  const dateControls = type !== "ortho";
  return <details className="card-3d rounded-xl p-5" dir="rtl" open={defaultOpen}><summary className="cursor-pointer font-semibold">{title ?? "التقارير التشغيلية عند الطلب"}</summary><div className="mt-4 space-y-4">
    <div className="flex flex-wrap items-end gap-2">
      <label className="text-sm">التقرير<select value={type} onChange={(e) => { setType(e.target.value as ReportType); setResult(null); }} className="mt-1 block rounded-md border border-border bg-background px-3 py-2">{choices.map((choice) => <option key={choice.value} value={choice.value}>{choice.label}</option>)}</select></label>
      {dateControls && <>
        <button type="button" onClick={() => applyPreset("tomorrow")} className="rounded-md border border-border px-3 py-2 text-sm">غدًا</button>
        <button type="button" onClick={() => applyPreset("week")} className="rounded-md border border-border px-3 py-2 text-sm">الأسبوع القادم</button>
        <button type="button" onClick={() => applyPreset("month")} className="rounded-md border border-border px-3 py-2 text-sm">الشهر القادم</button>
        <label className="text-xs">من<input type="date" value={range.from} onChange={(e) => setRange((r) => ({ ...r, from: e.target.value }))} className="mt-1 block rounded-md border border-border bg-background px-2 py-2" /></label>
        <label className="text-xs">إلى<input type="date" value={range.to} onChange={(e) => setRange((r) => ({ ...r, to: e.target.value }))} className="mt-1 block rounded-md border border-border bg-background px-2 py-2" /></label>
      </>}
      <button type="button" disabled={busy} onClick={() => show()} className="rounded-md btn-3d-primary px-4 py-2 text-sm">{busy ? "..." : "عرض التقرير"}</button>
    </div>
    {type === "ortho" && <p className="text-xs text-muted">المتأخر = مريض تقويم آخر حضور ليه (زيارة تقويم، زيارة طبية، دفعة، أو موعد تم) من {thresholds.first} يوم أو أكتر. اللي خلّصوا مش بيظهروا: فك متسجّل في الشارت، أو فاتورة بخدمة عليها «انتهاء تقويم» في إعدادات الخدمات.</p>}
    {canThresholds && type === "ortho" && <form key={`${thresholds.first}-${thresholds.second}`} onSubmit={(e) => { e.preventDefault(); const form = new FormData(e.currentTarget); startTransition(async () => { const response = await saveOrthoFollowupThresholdsAction(Number(form.get("first")), Number(form.get("second"))); if (!response.ok) alert(response.error); else { alert("تم حفظ المدد"); setResult(null); } }); }} className="flex flex-wrap items-end gap-2 rounded-lg bg-primary-soft/40 p-3"><label className="text-xs">المرحلة الأولى<input name="first" type="number" min="1" defaultValue={thresholds.first} className="mt-1 block w-24 rounded border border-border bg-background px-2 py-1.5" /></label><label className="text-xs">المرحلة الثانية<input name="second" type="number" min="2" defaultValue={thresholds.second} className="mt-1 block w-24 rounded border border-border bg-background px-2 py-1.5" /></label><button className="rounded border border-primary px-3 py-1.5 text-sm text-primary">حفظ المدد</button></form>}
    {result && !result.ok && <p className="text-sm text-danger">{result.error}</p>}
    {orthoTotals && <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
      <div className="rounded-xl border border-border p-3 text-center"><div className="text-xs text-muted">إجمالي المتأخرين</div><div className="text-2xl font-extrabold">{orthoTotals.total}</div></div>
      <div className="rounded-xl border border-border p-3 text-center"><div className="text-xs text-muted">{thresholds.first} – {thresholds.second - 1} يوم</div><div className="text-2xl font-extrabold text-primary">{orthoTotals.firstStage}</div></div>
      <div className="rounded-xl border border-danger/30 bg-danger/5 p-3 text-center"><div className="text-xs text-muted">{thresholds.second} يوم أو أكتر</div><div className="text-2xl font-extrabold text-danger">{orthoTotals.secondStage}</div></div>
      <div className="rounded-xl border border-border p-3 text-center"><div className="text-xs text-muted">خلّصوا (مش محسوبين)</div><div className="text-2xl font-extrabold text-muted">{orthoTotals.finished}</div></div>
    </div>}
    {result?.ok && !orthoTotals && rows.length > 0 && <p className="text-xs text-muted">عدد النتايج: {rows.length}</p>}
    {result?.ok && <div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="border-b border-border text-right">{result.type === "appointments" ? <><th className="p-2">المريض</th><th className="p-2">الطبيب</th><th className="p-2">الموعد</th><th className="p-2">الحالة</th><th className="p-2">التعديل المطلوب</th></> : result.type === "ortho" ? <><th className="p-2">المريض</th><th className="p-2 whitespace-nowrap">رقم الملف</th><th className="p-2">الطبيب</th><th className="p-2 whitespace-nowrap">آخر حضور</th><th className="p-2">التأخير</th><th className="p-2">المرحلة</th></> : result.type === "referrals" ? <><th className="p-2">المريض</th><th className="p-2">من</th><th className="p-2">إلى</th><th className="p-2">المطلوب</th><th className="p-2">الحالة</th></> : <><th className="p-2">المريض</th><th className="p-2">الطبيب</th><th className="p-2">التاريخ</th><th className="p-2">المديونية</th></>}</tr></thead><tbody>{pageRows.map((row, index) => <tr key={"id" in row ? String(row.id) : `${row.patientId}-${index}`} className="border-b border-border">{result.type === "appointments" && "time" in row && "status" in row ? <><td className="p-2 font-medium">{row.patientName}</td><td className="p-2">{row.doctorName}</td><td className="p-2 whitespace-nowrap">{row.date} · {row.time.slice(0, 5)}</td><td className="p-2">{appointmentStatusLabels[row.status] || row.status}</td><td className="p-2 whitespace-nowrap">{row.requestedDate ? `${row.requestedDate} · ${row.requestedTime?.slice(0, 5)}` : "—"}</td></> : result.type === "ortho" && "days" in row ? <><td className="p-2 font-medium">{patientLink(row.patientId, row.patientName)}</td><td className="p-2 whitespace-nowrap">{"fileNumber" in row ? row.fileNumber : ""}</td><td className="p-2">{row.doctorName}</td><td className="p-2 whitespace-nowrap">{row.date}{"source" in row && <span className="block text-[11px] text-muted">{row.source}</span>}</td><td className="p-2 whitespace-nowrap">{row.days} يوم</td><td className="p-2 whitespace-nowrap">{row.stage}</td></> : result.type === "referrals" && "fromDoctor" in row ? <><td className="p-2 font-medium">{patientLink(row.patientId, row.patientName)}</td><td className="p-2">{row.fromDoctor}</td><td className="p-2">{row.toDoctor}</td><td className="p-2">{row.requestText}</td><td className="p-2">{row.status === "completed" ? "تم" : "قيد الإجراء"}</td></> : "debt" in row ? <><td className="p-2 font-medium">{patientLink(row.patientId, row.patientName)}</td><td className="p-2">{row.doctorName}</td><td className="p-2">{row.date}</td><td className="p-2 text-danger">{Number(row.debt || 0).toFixed(0)} ج.م</td></> : null}</tr>)}</tbody></table>{!rows.length && <p className="py-6 text-center text-sm text-muted">لا توجد نتائج.</p>}</div>}
    {result?.ok && totalPages > 1 && <div className="flex items-center justify-center gap-2 text-sm">
      <button type="button" disabled={currentPage <= 1} onClick={() => goToPage(currentPage - 1)} className="rounded border border-border px-3 py-1 disabled:opacity-50">السابق</button>
      <span>صفحة {currentPage} / {totalPages}</span>
      <button type="button" disabled={currentPage >= totalPages} onClick={() => goToPage(currentPage + 1)} className="rounded border border-border px-3 py-1 disabled:opacity-50">التالي</button>
    </div>}
  </div></details>;
}
