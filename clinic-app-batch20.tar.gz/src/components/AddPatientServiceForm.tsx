"use client";

import { useEffect, useMemo, useState } from "react";
import { useFormStatus } from "react-dom";
import ServiceCombobox from "./ServiceCombobox";
import { PAYMENT_METHODS } from "@/lib/payment-methods";
import { addPatientServiceAction } from "@/app/patients/[id]/billing/actions";

type Service = { id: number; name: string; code?: string | null; default_price?: number | null };
type Doctor = { id: number; full_name: string };
type BillableInvoice = { id: number; service_name: string; visit_date: string; balance: number };
type PendingAppointment = {
  id: number;
  serviceId: number | null;
  price: number | null;
  discountPercent: number | null;
  doctorId: number | null;
} | null;

const FOLLOWUP_SERVICE_CODE = "0";

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      disabled={pending}
      className="rounded-md btn-3d-primary px-4 py-1.5 text-sm font-medium transition-colors disabled:opacity-60"
    >
      {pending ? "جاري الحفظ..." : "+ إضافة الخدمة"}
    </button>
  );
}

// بوكس "إضافة خدمة" جوه الملف المالي للمريض — بديل بوكس "إضافة خدمة" اللي كان
// تحت الجدول المركزي في /front-desk (دفعة 20)، بنفس منطق بوكس التحصيل بالجدول
// المركزي (السعر/الخصم/المبلغ المدفوع دلوقتي بيتحدث تلقائي معاهم لحد ما يتلمس
// يدويًا/طريقة الدفع/خدمة "متابعة" بتتخصم من فاتورة سابقة) عشان التجربة تفضل
// متسقة في كل أماكن التحصيل بالتطبيق.
export default function AddPatientServiceForm({
  patientId,
  services,
  doctors,
  billableInvoices,
  pendingAppointment,
  canBackdate,
  today,
}: {
  patientId: number;
  services: Service[];
  doctors: Doctor[];
  billableInvoices: BillableInvoice[];
  pendingAppointment: PendingAppointment;
  canBackdate: boolean;
  today: string;
}) {
  const [serviceId, setServiceId] = useState<string>(pendingAppointment?.serviceId ? String(pendingAppointment.serviceId) : "");
  const [price, setPrice] = useState<string>(pendingAppointment?.price != null ? String(pendingAppointment.price) : "0");
  const [discountPercent, setDiscountPercent] = useState<string>(
    pendingAppointment?.discountPercent != null ? String(pendingAppointment.discountPercent) : "0"
  );
  const [amountNow, setAmountNow] = useState<string>("0");
  const [amountTouched, setAmountTouched] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<string>("cash");
  const [doctorId, setDoctorId] = useState<string>(pendingAppointment?.doctorId ? String(pendingAppointment.doctorId) : "");
  const [visitDate, setVisitDate] = useState<string>(today);
  const [targetInvoiceId, setTargetInvoiceId] = useState<string>("");

  const selectedService = useMemo(() => services.find((s) => String(s.id) === serviceId) ?? null, [services, serviceId]);
  const isFollowup = selectedService?.code === FOLLOWUP_SERVICE_CODE;

  const computedTotal = useMemo(() => {
    const p = Number(price) || 0;
    const d = Math.min(100, Math.max(0, Number(discountPercent) || 0));
    return Math.max(0, p * (1 - d / 100));
  }, [price, discountPercent]);

  // لما تتغيّر خدمة عادية، السعر بيتعبى من سعر القايمة والمبلغ المدفوع بيتزامن
  // مع الإجمالي تلقائيًا (دفع كامل افتراضيًا) لحد ما المستخدم يعدّله بنفسه يدويًا.
  useEffect(() => {
    if (!selectedService || isFollowup) return;
    if (pendingAppointment?.serviceId === selectedService.id) return; // already prefilled from pending appt
    setPrice(String(selectedService.default_price ?? 0));
    setDiscountPercent("0");
    setAmountTouched(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedService?.id]);

  useEffect(() => {
    if (!selectedService || isFollowup || amountTouched) return;
    setAmountNow(String(Math.round(computedTotal * 100) / 100));
  }, [computedTotal, selectedService, isFollowup, amountTouched]);

  const selectedTargetBalance = useMemo(
    () => billableInvoices.find((b) => String(b.id) === targetInvoiceId) ?? null,
    [billableInvoices, targetInvoiceId]
  );

  return (
    <div className="card-3d rounded-xl p-5 space-y-3">
      <h2 className="font-semibold">إضافة خدمة</h2>

      {pendingAppointment && (
        <div className="text-xs bg-amber-50 text-amber-800 border border-amber-200 rounded-md px-3 py-2">
          للمريض ده موعد &quot;تم&quot; لسه محتاج تحصيل من الجدول — هيتربط بيه تلقائيًا وهتقفل شارة &quot;محتاج تحصيل&quot;
          بتاعته بعد الحفظ
          {pendingAppointment.serviceId ? "، وعبّينالك الخدمة والسعر من بيانات الموعد (تقدر تعدلهم لو حابب)." : "."}
        </div>
      )}

      <form action={addPatientServiceAction} className="space-y-3">
        <input type="hidden" name="patient_id" value={patientId} />
        <input type="hidden" name="visit_date" value={visitDate} />
        <input type="hidden" name="payment_method" value={paymentMethod} />
        {isFollowup ? (
          <input type="hidden" name="target_invoice_id" value={targetInvoiceId} />
        ) : (
          <>
            <input type="hidden" name="price" value={price} />
            <input type="hidden" name="discount_percent" value={discountPercent} />
          </>
        )}
        <input type="hidden" name="amount_now" value={amountNow} />

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs text-muted mb-1">الخدمة</label>
            <ServiceCombobox name="service_id" services={services} value={serviceId} onChange={setServiceId} />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">
              التاريخ {!canBackdate && <span className="text-muted">(النهاردة بس)</span>}
            </label>
            <input
              type="date"
              value={visitDate}
              max={today}
              disabled={!canBackdate}
              onChange={(e) => setVisitDate(e.target.value)}
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm disabled:opacity-60 disabled:cursor-not-allowed"
            />
          </div>
        </div>

        {selectedService && isFollowup && (
          <div>
            <label className="block text-xs text-muted mb-1">الخدمة الأصلية (اللي هتتخصم منها الدفعة)</label>
            {billableInvoices.length > 0 ? (
              <select
                value={targetInvoiceId}
                onChange={(e) => setTargetInvoiceId(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              >
                <option value="">اختر خدمة</option>
                {billableInvoices.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.service_name} — {b.visit_date} — الباقي {b.balance.toFixed(0)} ج.م
                  </option>
                ))}
              </select>
            ) : (
              <div className="text-xs text-danger">مفيش فواتير سابقة لسه عليها مبلغ مستحق لهذا المريض.</div>
            )}
            {selectedTargetBalance && (
              <div className="text-sm mt-1">
                الباقي المستحق: <span className="text-danger font-semibold">{selectedTargetBalance.balance.toFixed(0)} ج.م</span>
              </div>
            )}
          </div>
        )}

        {selectedService && !isFollowup && (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-muted mb-1">السعر</label>
              <input
                type="number"
                step="0.01"
                min={0}
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-muted mb-1">خصم (%)</label>
              <input
                type="number"
                step="1"
                min={0}
                max={100}
                value={discountPercent}
                onChange={(e) => setDiscountPercent(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              />
            </div>
            <div className="col-span-2 text-sm">
              المطلوب دفعه: <span className="font-semibold">{computedTotal.toFixed(0)} ج.م</span>
            </div>
          </div>
        )}

        {selectedService && (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-muted mb-1">المبلغ المدفوع دلوقتي</label>
              <input
                type="number"
                step="0.01"
                min={0}
                value={amountNow}
                onChange={(e) => {
                  setAmountTouched(true);
                  setAmountNow(e.target.value);
                }}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-muted mb-1">وسيلة الدفع</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              >
                {PAYMENT_METHODS.map((m) => (
                  <option key={m.value} value={m.value}>
                    {m.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        )}

        <div>
          <label className="block text-xs text-muted mb-1">الدكتور</label>
          <select
            name="doctor_id"
            required
            value={doctorId}
            onChange={(e) => setDoctorId(e.target.value)}
            className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
          >
            <option value="">اختر دكتور</option>
            {doctors.map((d) => (
              <option key={d.id} value={d.id}>
                {d.full_name}
              </option>
            ))}
          </select>
        </div>

        <SubmitButton />
      </form>
    </div>
  );
}
