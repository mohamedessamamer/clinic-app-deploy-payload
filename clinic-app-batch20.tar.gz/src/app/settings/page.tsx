import { getAllSettings, buildTimeSlots, WEEKDAY_LABELS, WEEKDAY_DISPLAY_ORDER } from "@/lib/settings";
import { getSession } from "@/lib/session";
import { db } from "@/lib/db/client";
import { saveSettingsAction, changePasswordAction } from "./actions";
import ServicesManager from "@/components/ServicesManager";
import AddDoctorForm from "@/components/AddDoctorForm";
import AddEmployeeForm from "@/components/AddEmployeeForm";
import UsersList from "@/components/UsersList";
import PermissionsManager from "@/components/PermissionsManager";
import RoomsManager from "@/components/RoomsManager";
import WeeklyShiftsManager from "@/components/WeeklyShiftsManager";
import { getPermissionOverrides } from "@/lib/permissions";

const PW_ERROR_LABELS: Record<string, string> = {
  missing: "لازم تملى كل الحقول.",
  short: "كلمة السر الجديدة لازم تكون 6 حروف/أرقام على الأقل.",
  mismatch: "كلمة السر الجديدة وتأكيدها مش متطابقين.",
  wrong: "كلمة السر الحالية غلط.",
};

const ROOM_ERROR_LABELS: Record<string, string> = {
  in_use: "العيادة/الغرفة دي مستخدمة في شيفتات أو مواعيد أو زيارات مسجلة، لازم تشيلها من هناك الأول قبل الحذف.",
};

export default async function SettingsPage({
  searchParams,
}: {
  searchParams: Promise<{ pwerror?: string; pwsuccess?: string; roomerror?: string; openpw?: string; resetpw?: string }>;
}) {
  const session = await getSession();

  if (!session) {
    return (
      <div className="card-3d rounded-xl p-5 text-sm text-muted">
        لازم تسجل دخول عشان توصل للإعدادات.
      </div>
    );
  }

  const { pwerror, pwsuccess, roomerror, openpw, resetpw } = await searchParams;

  const changePasswordSection = (
    <details
      id="changepw"
      className="card-3d rounded-xl p-5 max-w-lg group"
      open={Boolean(pwerror || pwsuccess || openpw)}
    >
      <summary className="font-semibold cursor-pointer select-none">تغيير كلمة السر</summary>
      <div className="space-y-4 mt-4">
      {pwsuccess && (
        <p className="text-sm text-green-700 bg-green-50 border border-green-200 rounded-md px-3 py-2">
          تم تغيير كلمة السر بنجاح.
        </p>
      )}
      {pwerror && (
        <p className="text-sm text-red-700 bg-red-50 border border-red-200 rounded-md px-3 py-2">
          {PW_ERROR_LABELS[pwerror] || "حصل خطأ، حاول تاني."}
        </p>
      )}
      <form action={changePasswordAction} className="space-y-3">
        <div>
          <label className="block text-sm text-muted mb-1">كلمة السر الحالية</label>
          <input
            type="password"
            name="current_password"
            required
            className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-sm text-muted mb-1">كلمة السر الجديدة</label>
          <input
            type="password"
            name="new_password"
            required
            minLength={6}
            className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-sm text-muted mb-1">تأكيد كلمة السر الجديدة</label>
          <input
            type="password"
            name="confirm_password"
            required
            minLength={6}
            className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
          />
        </div>
        <button
          type="submit"
          className="rounded-md btn-3d-primary px-4 py-2 text-sm font-medium transition-colors"
        >
          حفظ كلمة السر
        </button>
      </form>
      </div>
    </details>
  );

  if (session.role !== "admin") {
    return (
      <div className="space-y-6">
        <h1 className="text-xl font-bold">الإعدادات</h1>
        {changePasswordSection}
        <div className="card-3d rounded-xl p-5 text-sm text-muted max-w-lg">
          باقي الإعدادات (وحدة الزمن والشيفتات) متاحة لمدير النظام فقط.
        </div>
      </div>
    );
  }

  const [settings, rooms, doctors, weeklyShiftsRaw, services, users] = await Promise.all([
    getAllSettings(),
    db.selectFrom("rooms").selectAll().execute(),
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).execute(),
    db
      .selectFrom("doctor_weekly_shifts")
      .leftJoin("rooms", "rooms.id", "doctor_weekly_shifts.room_id")
      .leftJoin("doctors", "doctors.id", "doctor_weekly_shifts.doctor_id")
      .select([
        "doctor_weekly_shifts.id",
        "doctor_weekly_shifts.weekday",
        "doctor_weekly_shifts.start_time",
        "doctor_weekly_shifts.end_time",
        "rooms.name as room_name",
        "doctors.full_name as doctor_name",
      ])
      .orderBy("doctor_weekly_shifts.weekday")
      .orderBy("doctor_weekly_shifts.start_time")
      .execute(),
    db.selectFrom("services").selectAll().orderBy("name").execute(),
    db.selectFrom("users").select(["id", "username", "full_name", "role"]).where("active", "=", 1).execute(),
  ]);

  const overridesEntries = await Promise.all(
    users.filter((u) => u.role !== "admin").map(async (u) => [u.id, await getPermissionOverrides(u.id)] as const)
  );
  const overridesByUser = Object.fromEntries(overridesEntries);

  const timeSlots = buildTimeSlots(settings.day_start, settings.day_end, Number(settings.slot_minutes));
  const holidayWeekdays = settings.holiday_weekdays
    ? settings.holiday_weekdays.split(",").filter(Boolean).map(Number)
    : [];

  return (
    <div className="max-w-3xl space-y-6">
      <h1 className="text-xl font-bold">إعدادات العيادة</h1>

      {changePasswordSection}

      <section className="card-3d rounded-xl p-5 space-y-6">
        <h2 className="font-semibold">إعدادات العيادات</h2>

        {roomerror && (
          <p className="text-sm text-red-700 bg-red-50 border border-red-200 rounded-md px-3 py-2">
            {ROOM_ERROR_LABELS[roomerror] || "حصل خطأ، حاول تاني."}
          </p>
        )}

        <form action={saveSettingsAction} className="space-y-4">
          <h3 className="text-sm font-medium">وحدة الزمن</h3>
          <div>
            <label className="block text-sm text-muted mb-1">وحدة الزمن (مدة الموعد الواحد بالدقايق)</label>
            <select
              name="slot_minutes"
              defaultValue={settings.slot_minutes}
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
            >
              {[5, 10, 15, 20, 30, 45, 60].map((m) => (
                <option key={m} value={m}>
                  {m} دقيقة
                </option>
              ))}
            </select>
            <p className="text-xs text-muted mt-1">
              ده بيتحكم في الفواصل الزمنية اللي بتظهر عند حجز موعد جديد (مثلاً كل 15 دقيقة) — وده نفسه اللي بيحدد
              اختيارات الوقت في شيفتات الأطباء الأسبوعية تحت.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-muted mb-1">بداية يوم العمل</label>
              <input
                type="time"
                name="day_start"
                defaultValue={settings.day_start}
                className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-sm text-muted mb-1">نهاية يوم العمل</label>
              <input
                type="time"
                name="day_end"
                defaultValue={settings.day_end}
                className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm text-muted mb-1">أيام الإجازة الأسبوعية</label>
            <div className="flex flex-wrap gap-3">
              {WEEKDAY_DISPLAY_ORDER.map((idx) => (
                <label key={idx} className="flex items-center gap-1.5 text-sm">
                  <input
                    type="checkbox"
                    name="holiday_weekdays"
                    value={idx}
                    defaultChecked={holidayWeekdays.includes(idx)}
                    className="h-4 w-4"
                  />
                  {WEEKDAY_LABELS[idx]}
                </label>
              ))}
            </div>
          </div>

          <button
            type="submit"
            className="rounded-md btn-3d-primary px-4 py-2 text-sm font-medium transition-colors"
          >
            حفظ الإعدادات
          </button>
        </form>

        <div className="border-t border-border pt-5">
          <h3 className="text-sm font-medium mb-2">العيادات/الغرف</h3>
          <RoomsManager rooms={rooms} />
        </div>

        <div className="border-t border-border pt-5">
          <h3 className="text-sm font-medium mb-1">شيفتات الأطباء الأسبوعية</h3>
          <p className="text-xs text-muted mb-3">
            هنا بتحدد مين الدكتور صاحب الشيفت في كل عيادة/غرفة في كل يوم من أيام الأسبوع، وده اللي هيتحدد تلقائيًا
            في سجل الاستقبال والمواعيد كل أسبوع من غير ما تحتاج تضيفه كل يوم.
          </p>
          <WeeklyShiftsManager rooms={rooms} doctors={doctors} timeSlots={timeSlots} weeklyShifts={weeklyShiftsRaw} />
        </div>
      </section>

      <section className="card-3d rounded-xl p-5 space-y-4">
        <h2 className="font-semibold">إعدادات الخدمات</h2>
        <ServicesManager services={services} />
      </section>

      <section className="card-3d rounded-xl p-5 space-y-5">
        <h2 className="font-semibold">إعدادات المستخدمين</h2>

        <div>
          <h3 className="text-sm font-medium mb-2">إضافة طبيب</h3>
          <AddDoctorForm />
        </div>

        <div>
          <h3 className="text-sm font-medium mb-2">إضافة موظف (استقبال / محاسب / مدير عيادة)</h3>
          <AddEmployeeForm />
        </div>

        <div>
          <h3 className="text-sm font-medium mb-2">المستخدمون الحاليون</h3>
          {resetpw && (
            <p className="text-sm text-green-700 bg-green-50 border border-green-200 rounded-md px-3 py-2 mb-2">
              تم تصفير كلمة سر &quot;{resetpw}&quot; لكلمة السر الافتراضية &quot;123&quot;.
            </p>
          )}
          <UsersList users={users} currentUserId={session.userId} />
        </div>
      </section>

      <section className="card-3d rounded-xl p-5 space-y-4">
        <h2 className="font-semibold">إعدادات الصلاحيات</h2>
        <p className="text-xs text-muted -mt-2">
          كل مستخدم بياخد صلاحيات افتراضية حسب دوره، وممكن تخصّصها له لوحده من هنا.
        </p>
        <PermissionsManager
          users={users}
          overridesByUser={overridesByUser}
          doctorReportMaxDays={settings.doctor_report_max_days}
        />
      </section>

    </div>
  );
}
