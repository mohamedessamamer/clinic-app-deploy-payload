"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { recordHrSettlementAction, saveHrPayrollInputsAction } from "@/app/expenses/actions";
import { calculateHrPayroll, type HrRule } from "@/lib/hr-payroll-math";
import { PAYMENT_METHODS } from "@/lib/payment-methods";

// ---------------------------------------------------------------------------
// دفعة 132 — كشف الرواتب والنسب.
//
// التغيير المعماري الأساسي: المدخلات (شيفتات/حوافز/خصومات) بقت في الأب هنا مش
// جوه كل صف. قبل كده الصف كان ماسك حالته بنفسه وبيعيد الحساب لحظيًا، بينما
// مجاميع المجموعات والإجمالي الكلي كانوا بيقروا `run.total_amount` المتجمّد
// وقت الحفظ — فالصف والمجموع كانوا بيختلفوا فعليًا (فرق الـ5,160 في كشف
// سبتمبر: طبيب اتحفظ كشفه وتحصيله صفر، وبعدين حصّل 12,900).
//
// دلوقتي الأربع أرقام (الصف · مجموع المجموعة · الإجمالي الكلي · المستحق في صف
// السداد) كلهم بيتولدوا من نفس `computed` في نفس دورة الرسم، فمستحيل يختلفوا —
// مش "بنزامنهم"، هم حرفيًا نفس الحساب.
//
// وعاء «صافي النقدية» بيتحسب هنا كمان بنفس معادلة السيرفر بالظبط:
//   المحصّل − المصروفات العادية − إجمالي الرواتب المستحقة
// عشان كده بنستقبل clinicGross و otherExpenses كأرقام ثابتة من السيرفر: الرواتب
// هي الجزء المتغير الوحيد، فأي تعديل في الشيفتات بيحرّك الوعاء ومعاه نسب
// الموظفين فورًا وبنفس اللي السيرفر هيحسبه لما يعيد التحميل.
// ---------------------------------------------------------------------------

type Row = {
  key: string;
  name: string;
  personType: "doctor" | "staff";
  personId: number;
  group: "doctor" | "employee" | "nursing";
  rule: HrRule;
  personalBase: number;
  computedShifts: number;
  shiftCountOverride: number | null;
  incentives: number;
  deductions: number;
};

type Settlement = {
  id: number;
  kind: "salary" | "commission";
  amount: number;
  paid_date: string;
  payment_method: string;
};

const groupLabels = { doctor: "الأطباء", employee: "الموظفون", nursing: "التمريض" } as const;
const GROUP_ORDER = ["doctor", "employee", "nursing"] as const;

const EMPTY_INPUT = { shifts: "", incentives: "0", deductions: "0" };

function round2(value: number) {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

function money(value: number) {
  return value.toLocaleString("en-US", { maximumFractionDigits: 0 });
}

function methodLabel(value: string) {
  return PAYMENT_METHODS.find((item) => item.value === value)?.label ?? value;
}

export default function HrPayrollTable({
  rows,
  settlements,
  from,
  to,
  today,
  periodLabel,
  canViewBase,
  clinicGross,
  clinicAfterLab,
  otherExpenses,
}: {
  rows: Row[];
  settlements: Settlement[];
  from: string;
  to: string;
  today: string;
  periodLabel: string;
  canViewBase: boolean;
  clinicGross: number;
  clinicAfterLab: number;
  otherExpenses: number;
}) {
  // مفتاح الفترة جزء من الحالة عشان لما المحاسب يبدّل الشهر، المدخلات تترجع من
  // الصفوف الجديدة بدل ما تفضل شايلة قيم الشهر اللي فات.
  const [inputs, setInputs] = useState(() => initialInputs(rows));
  const periodKey = `${from}:${to}`;
  const [syncedPeriod, setSyncedPeriod] = useState(periodKey);
  if (syncedPeriod !== periodKey) {
    setSyncedPeriod(periodKey);
    setInputs(initialInputs(rows));
  }

  // الحفظ بيتأجل 600ms بعد آخر ضغطة زرار: العرض فوري، والتخزين بعدها بلحظة، من
  // غير ما نبعت طلب لكل حرف. أي تغيير جديد بيلغي المؤقت السابق لنفس الصف.
  const saveTimers = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());
  useEffect(() => {
    const timers = saveTimers.current;
    return () => {
      for (const timer of timers.values()) clearTimeout(timer);
      timers.clear();
    };
  }, []);

  function updateInput(row: Row, field: "shifts" | "incentives" | "deductions", raw: string) {
    // بنحسب حالة الصف الجديدة هنا (جوه الـhandler، مش وقت الرسم) ونبعتها للمؤقت
    // مباشرة — كده مش محتاجين ref يلاحق الحالة، وكل ضغطة زرار بتعيد جدولة
    // الحفظ بأحدث قيم الصف.
    const state = { ...(inputs[row.key] ?? EMPTY_INPUT), [field]: raw };
    setInputs((current) => ({ ...current, [row.key]: state }));
    const timers = saveTimers.current;
    const existing = timers.get(row.key);
    if (existing) clearTimeout(existing);
    timers.set(
      row.key,
      setTimeout(() => {
        timers.delete(row.key);
        const data = new FormData();
        data.set("person_type", row.personType);
        data.set("person_id", String(row.personId));
        data.set("period_from", from);
        data.set("period_to", to);
        // خانة الشيفتات الفاضية معناها "ارجع للمحسوب من أيام الشيفت" — مش صفر.
        data.set("shift_count_override", row.rule.fixed_basis === "shift" ? state.shifts.trim() : "");
        data.set("incentives", state.incentives.trim() || "0");
        data.set("deductions", state.deductions.trim() || "0");
        void saveHrPayrollInputsAction(data);
      }, 600)
    );
  }

  // ---- الحساب: مصدر واحد لكل رقم في الشاشة ----
  const computed = useMemo(() => {
    const withSalary = rows.map((row) => {
      const state = inputs[row.key] ?? EMPTY_INPUT;
      const overrideRaw = state.shifts.trim();
      const shiftCount = row.rule.fixed_basis === "shift" ? (overrideRaw === "" ? row.computedShifts : Math.max(0, Number(overrideRaw) || 0)) : 0;
      const incentives = Math.max(0, Number(state.incentives) || 0);
      const deductions = Math.max(0, Number(state.deductions) || 0);
      const fixedAmount =
        row.rule.compensation_type === "percentage"
          ? 0
          : round2(row.rule.fixed_basis === "shift" ? row.rule.fixed_amount * shiftCount : row.rule.fixed_amount);
      return { row, shiftCount, incentives, deductions, fixedAmount, salary: round2(Math.max(0, fixedAmount + incentives - deductions)) };
    });

    // نفس معادلة السيرفر: الرواتب المستحقة كاملة (مش المدفوع منها) عشان الوعاء
    // مايتحركش مع كل دفعة سداد جزئية، وسداد النسب مستثنى أصلاً من otherExpenses.
    const accruedSalaries = round2(withSalary.reduce((sum, item) => sum + item.salary, 0));
    const netCash = round2(Math.max(0, clinicGross - otherExpenses - accruedSalaries));

    return withSalary.map((item) => {
      const base =
        item.row.rule.percentage_basis === "clinic_net_cash"
          ? netCash
          : item.row.rule.percentage_basis === "clinic"
            ? clinicAfterLab
            : item.row.personalBase;
      const commission = round2(Math.max(0, calculateHrPayroll(item.row.rule, base, item.shiftCount).percentageAmount));
      return { ...item, base, commission, total: round2(item.salary + commission) };
    });
  }, [rows, inputs, clinicGross, clinicAfterLab, otherExpenses]);

  const salaryTotal = round2(computed.reduce((sum, item) => sum + item.salary, 0));
  const commissionTotal = round2(computed.reduce((sum, item) => sum + item.commission, 0));
  const grandTotal = round2(salaryTotal + commissionTotal);

  const salaryPayments = settlements.filter((item) => item.kind === "salary");
  const commissionPayments = settlements.filter((item) => item.kind === "commission");
  const salaryPaid = round2(salaryPayments.reduce((sum, item) => sum + item.amount, 0));
  const commissionPaid = round2(commissionPayments.reduce((sum, item) => sum + item.amount, 0));
  const salaryRest = round2(Math.max(0, salaryTotal - salaryPaid));
  const commissionRest = round2(Math.max(0, commissionTotal - commissionPaid));
  // الدفعات بتتعرض صف جنب صف: لو الراتب اتسدد 3 مرات والنسبة مرة، دفعة النسبة
  // بتبان قدام أول سطر والباقي بيفضل فاضي — زي ما اتفق عليه في الديزاين.
  const paymentRowCount = Math.max(salaryPayments.length, commissionPayments.length);

  const cell = "px-3 py-1.5 whitespace-nowrap";
  const mini = "h-7 w-full rounded border border-border bg-background px-1.5 text-xs";
  const colCount = canViewBase ? 8 : 7;
  const leadSpan = colCount - 3;

  return (
    <section className="card-3d rounded-xl p-4 space-y-3">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="font-semibold">استحقاقات الأطباء والموظفين — {periodLabel}</h2>
          <p className="mt-1 text-xs text-muted">اكتب الشيفتات والحوافز والخصومات؛ الأرقام بتتحدّث فورًا والحفظ تلقائي.</p>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-xs table-fixed min-w-[60rem]">
          <colgroup>
            <col className="w-[17%]" />
            {canViewBase && <col className="w-[12%]" />}
            <col className="w-[12%]" />
            <col className="w-[9%]" />
            <col className="w-[9%]" />
            <col className="w-[13%]" />
            <col className="w-[14%]" />
            <col className="w-[14%]" />
          </colgroup>
          <thead className="bg-primary-soft text-primary-dark">
            <tr>
              <th className="p-2 text-right">الاسم</th>
              {canViewBase && <th className="p-2 text-right">صافي التحصيل</th>}
              <th className="p-2 text-right">الثابت/الشيفتات</th>
              <th className="p-2 text-right">حوافز</th>
              <th className="p-2 text-right">خصومات</th>
              <th className="p-2 text-right">الراتب</th>
              <th className="p-2 text-right">النسبة</th>
              <th className="p-2 text-right">الإجمالي</th>
            </tr>
          </thead>
          <tbody>
            {GROUP_ORDER.map((group) => {
              const list = computed.filter((item) => item.row.group === group);
              if (!list.length) return null;
              const groupSalary = round2(list.reduce((sum, item) => sum + item.salary, 0));
              const groupCommission = round2(list.reduce((sum, item) => sum + item.commission, 0));
              return (
                <tbody key={group} className="contents">
                  <tr className="border-t-2 border-primary/20 bg-background font-bold">
                    <td className={cell} colSpan={leadSpan}>
                      {groupLabels[group]}
                    </td>
                    <td className={cell}>{money(groupSalary)}</td>
                    <td className={cell}>{groupCommission > 0 ? money(groupCommission) : <span className="text-muted/50">—</span>}</td>
                    <td className={cell}>{groupCommission > 0 ? money(round2(groupSalary + groupCommission)) : <span className="text-muted/50">—</span>}</td>
                  </tr>
                  {list.map((item) => {
                    const state = inputs[item.row.key] ?? { shifts: "", incentives: "0", deductions: "0" };
                    const isShiftBased = item.row.rule.fixed_basis === "shift";
                    return (
                      <tr key={item.row.key} className="border-t border-border">
                        <td className={`${cell} font-medium truncate`}>{item.row.name}</td>
                        {canViewBase && <td className={cell}>{money(item.base)}</td>}
                        <td className="px-3 py-1.5">
                          {isShiftBased ? (
                            <div>
                              <input
                                type="number"
                                min="0"
                                step="0.5"
                                value={state.shifts}
                                placeholder={String(item.row.computedShifts)}
                                onChange={(event) => updateInput(item.row, "shifts", event.target.value)}
                                className={mini}
                              />
                              <span className="mt-0.5 block text-[10px] text-muted">محسوب: {item.row.computedShifts}</span>
                            </div>
                          ) : (
                            <span>{money(item.fixedAmount)}</span>
                          )}
                        </td>
                        <td className="px-3 py-1.5">
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            value={state.incentives}
                            onChange={(event) => updateInput(item.row, "incentives", event.target.value)}
                            className={mini}
                          />
                        </td>
                        <td className="px-3 py-1.5">
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            value={state.deductions}
                            onChange={(event) => updateInput(item.row, "deductions", event.target.value)}
                            className={mini}
                          />
                        </td>
                        <td className={`${cell} font-bold`}>{money(item.salary)}</td>
                        <td className={cell}>{item.commission > 0 ? money(item.commission) : <span className="text-muted/50">—</span>}</td>
                        {/* الإجمالي بيفضل فاضي بصريًا لو مفيش نسبة عشان مايكررش رقم
                            الراتب، لكن كل المجاميع فوق وتحت بتعدّه عادي. */}
                        <td className={`${cell} font-bold text-primary-dark`}>
                          {item.commission > 0 ? money(item.total) : <span className="text-muted/50">—</span>}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              );
            })}

            {!rows.length && (
              <tr>
                <td colSpan={colCount} className="p-6 text-center text-muted">
                  لا توجد قواعد HR سارية في الفترة دي.
                </td>
              </tr>
            )}

            {rows.length > 0 && (
              <>
                <tr className="border-t-2 border-primary bg-primary-soft font-extrabold">
                  <td className={cell} colSpan={leadSpan}>
                    الإجمالي الكلي
                  </td>
                  <td className={cell}>{money(salaryTotal)}</td>
                  <td className={cell}>{money(commissionTotal)}</td>
                  <td className={cell}>{money(grandTotal)}</td>
                </tr>

                {Array.from({ length: paymentRowCount }).map((_, index) => {
                  const salaryPayment = salaryPayments[index];
                  const commissionPayment = commissionPayments[index];
                  return (
                    <tr key={`settlement-${index}`} className={index === 0 ? "border-t-2 border-primary" : "border-t border-dashed border-border"}>
                      <td className={cell} colSpan={leadSpan}>
                        {index === 0 && <span className="font-semibold text-muted">سداد</span>}
                      </td>
                      <td className={cell}>{salaryPayment ? <PaymentCell payment={salaryPayment} /> : <span className="text-muted/50">—</span>}</td>
                      <td className={cell}>{commissionPayment ? <PaymentCell payment={commissionPayment} /> : <span className="text-muted/50">—</span>}</td>
                      <td className={cell} />
                    </tr>
                  );
                })}

                <tr className={paymentRowCount ? "border-t border-dashed border-border" : "border-t-2 border-primary"}>
                  <td className={cell} colSpan={leadSpan}>
                    <span className="font-semibold text-muted">المتبقي</span>
                  </td>
                  <td className={cell}>
                    {salaryRest > 0 ? <span className="font-extrabold text-danger">{money(salaryRest)}</span> : <span className="font-bold text-primary">تم السداد</span>}
                  </td>
                  <td className={cell}>
                    {commissionTotal <= 0 ? (
                      <span className="text-muted/50">—</span>
                    ) : commissionRest > 0 ? (
                      <span className="font-extrabold text-danger">{money(commissionRest)}</span>
                    ) : (
                      <span className="font-bold text-primary">تم السداد</span>
                    )}
                  </td>
                  <td className={cell} />
                </tr>

                <tr className="border-t-2 border-border bg-primary-soft/40">
                  <td className="px-3 py-3 align-middle" colSpan={leadSpan}>
                    {/* تاريخ السداد ووسيلة الدفع مشتركين بين الوعاءين، زي ما
                        اتفق: تقدر تسجل دفعة للراتب وحده أو للنسبة وحدها أو
                        الاتنين مع بعض في نفس الضغطة. */}
                    <div className="flex flex-wrap items-center gap-3">
                      <span className="text-sm font-semibold">تسجيل سداد</span>
                      <input form="hr-settlement-form" name="paid_date" type="date" defaultValue={today} required className="h-10 w-44 rounded-lg border border-border bg-background px-2.5 text-sm" />
                    </div>
                  </td>
                  <td className="px-3 py-3">
                    <input form="hr-settlement-form" name="salary_amount" type="number" min="0" step="0.01" placeholder="مبلغ الراتب" className="h-10 w-full rounded-lg border border-border bg-background px-2.5 text-sm font-semibold" />
                  </td>
                  <td className="px-3 py-3">
                    <input form="hr-settlement-form" name="commission_amount" type="number" min="0" step="0.01" placeholder="مبلغ النسبة" className="h-10 w-full rounded-lg border border-border bg-background px-2.5 text-sm font-semibold" />
                  </td>
                  <td className="px-3 py-3">
                    <form id="hr-settlement-form" action={recordHrSettlementAction} className="flex items-center gap-2">
                      <input type="hidden" name="period_from" value={from} />
                      <input type="hidden" name="period_to" value={to} />
                      <select name="payment_method" defaultValue="cash" className="h-10 min-w-0 flex-1 rounded-lg border border-border bg-background px-2 text-sm">
                        {PAYMENT_METHODS.map((item) => (
                          <option key={item.value} value={item.value}>
                            {item.label}
                          </option>
                        ))}
                      </select>
                      <button className="h-10 rounded-lg btn-3d-primary px-4 text-sm font-medium">سداد</button>
                    </form>
                  </td>
                </tr>
              </>
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function PaymentCell({ payment }: { payment: Settlement }) {
  return (
    <span className="font-bold text-primary">
      {money(payment.amount)}
      <small className="block text-[10px] font-normal text-muted">
        {payment.paid_date} · {methodLabel(payment.payment_method)}
      </small>
    </span>
  );
}

function initialInputs(rows: Row[]) {
  return Object.fromEntries(
    rows.map((row) => [
      row.key,
      {
        // فاضية = اتبع العدد المحسوب من أيام الشيفت، فبيتحدّث لوحده كل شهر.
        shifts: row.shiftCountOverride == null ? "" : String(row.shiftCountOverride),
        incentives: String(row.incentives ?? 0),
        deductions: String(row.deductions ?? 0),
      },
    ])
  ) as Record<string, { shifts: string; incentives: string; deductions: string }>;
}
