"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ChevronDownIcon } from "./icons";
import { setColorThemeAction, setMedicalUiLanguageAction } from "@/app/account/actions";

type ColorTheme = "revere" | "medical";

const COLOR_THEMES: { id: ColorTheme; label: string; colors: string[] }[] = [
  { id: "revere", label: "Revere", colors: ["#231a12", "#a07634", "#f8f3e9"] },
  { id: "medical", label: "Medical", colors: ["#075448", "#11745f", "#e9f5f0"] },
];

// قايمة اسم الحساب في القايمة العلوية — بدل ما كان مجرد نص ثابت، بقى زرار
// بيفتح قايمة صغيرة فيها "تغيير كلمة السر" (بيوديك مباشرة لصفحة الإعدادات
// وبيفتحلك سكشن تغيير كلمة السر على طول، مش محتاج تدور عليه).
export default function AccountMenu({
  fullName,
  roleLabel,
  medicalUiLanguage,
  colorTheme,
}: {
  fullName: string;
  roleLabel: string;
  medicalUiLanguage: "en" | "ar";
  colorTheme: ColorTheme;
}) {
  const [open, setOpen] = useState(false);
  const [themesOpen, setThemesOpen] = useState(false);
  const [isPending, startTransition] = useTransition();
  const router = useRouter();
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) {
        setOpen(false);
        setThemesOpen(false);
      }
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  return (
    <div className="relative clinic-account-menu-wrap" ref={wrapRef}>
      <button
        type="button"
        onClick={() => {
          setOpen((o) => !o);
          setThemesOpen(false);
        }}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft/40 transition-colors"
      >
        <span>
          {fullName} · {roleLabel}
        </span>
        <ChevronDownIcon className="w-3.5 h-3.5" />
      </button>
      {open && (
        <div className="clinic-account-menu absolute left-0 z-50 mt-1 w-56 card-3d rounded-md shadow-lg text-sm">
          <Link
            href="/settings?openpw=1"
            onClick={() => setOpen(false)}
            className="block px-3 py-2 hover:bg-primary-soft"
          >
            تغيير كلمة السر
          </Link>
          <button
            type="button"
            disabled={isPending}
            onClick={() => {
              const next = medicalUiLanguage === "en" ? "ar" : "en";
              startTransition(async () => {
                await setMedicalUiLanguageAction(next);
                router.refresh();
              });
            }}
            className="block w-full px-3 py-2 text-right hover:bg-primary-soft disabled:opacity-60"
          >
            لغة الملف الطبي: {medicalUiLanguage === "en" ? "English" : "العربية"}
          </button>
          <div
            className="clinic-theme-menu-item"
            onMouseEnter={() => setThemesOpen(true)}
            onMouseLeave={() => setThemesOpen(false)}
          >
            <button
              type="button"
              aria-haspopup="menu"
              aria-expanded={themesOpen}
              onClick={() => setThemesOpen((value) => !value)}
              className="clinic-theme-menu-trigger"
            >
              <span>ألوان النظام</span>
              <span aria-hidden="true" className="clinic-theme-menu-arrow">‹</span>
            </button>
            {themesOpen && (
              <div className="clinic-theme-submenu card-3d" role="menu" aria-label="ألوان النظام المتاحة">
                {COLOR_THEMES.map((theme) => (
                  <button
                    key={theme.id}
                    type="button"
                    role="menuitemradio"
                    aria-checked={colorTheme === theme.id}
                    disabled={isPending}
                    onClick={() => {
                      document.body.dataset.colorTheme = theme.id;
                      startTransition(async () => {
                        await setColorThemeAction(theme.id);
                        router.refresh();
                        setThemesOpen(false);
                        setOpen(false);
                      });
                    }}
                    className="clinic-theme-option"
                  >
                    <span className="clinic-theme-check" aria-hidden="true">{colorTheme === theme.id ? "✓" : ""}</span>
                    <span>{theme.label}</span>
                    <span className="clinic-theme-swatches" aria-hidden="true">
                      {theme.colors.map((color) => <i key={color} style={{ backgroundColor: color }} />)}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
