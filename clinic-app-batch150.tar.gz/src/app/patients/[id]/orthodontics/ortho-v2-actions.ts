"use server";

// شارت التقويم v2 — أكشنز السيرفر الحقيقية (دمج البروتوتايب المعزول مع
// السيستم الحقيقي، 2026-08-27). ملف منفصل عن actions.ts القديم (بيانات
// تشخيص/bonding/rebonding "batch 25" الأصلية) بقرار متعمد: نفس منطق الصلاحيات
// (canEditMedicalRecordFor)، لكن سطح جديد كليًا (زيارات فولو أب حقيقية، سجل
// خصومات مخزون قابل للـUndo، حالة كل سن لوحده) — إضافي، مش بديل، عشان لو حصل
// أي مشكلة يبقى سهل نرجع نعطّل الاستدعاء الجديد من غير ما نلمس الأكشنز
// القديمة اللي كانت شغالة بالفعل.
//
// خصم المخزون الحقيقي: كل خصم بيتسجل في ortho_inventory_deductions (ledger
// قابل للـUndo)، وبيحاول كمان يخصم من inventory_items.quantity الحقيقي عن
// طريق مطابقة الاسم (case-insensitive، أول بالنص كامل زي "Wire 16 NiTi
// (Upper)"، ولو مفيش تطابق بيجرب الاسم الأساسي من غير اللاحقة زي "Wire" أو
// "Brackets" أو "Tubes"). لو مفيش أي تطابق، الخصم بيتسجل في تقرير الشارت
// (traceable) من غير ما يأثر على أرقام مخزون حقيقية — ده أفضل من نخترع صنف
// مخزون جديد تلقائيًا من غير ما حد يقصد كده. لو حصل كتير، الحل: يتضاف صنف
// بنفس الاسم في صفحة المخزون.

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { UPPER_ROW, LOWER_ROW, ALL_TEETH } from "@/lib/ortho/fdi-teeth";
import type { Role } from "@/lib/auth";
import { getClinicToday } from "@/lib/clinic-date";
import type { Transaction } from "kysely";
import type { Database } from "@/lib/db/types";
import { buildOrthoTreatmentParagraph, syncOrthoNoteToMedicalVisit, clearSyncedOrthoNote } from "@/lib/ortho-treatment-sync";
import { deductInventoryItem, returnInventoryItem } from "@/lib/inventory-stock";
import { inventoryDeductionsEnabled } from "@/lib/inventory-control";
import { normalizeChains, chainQty, otieQtyForArch, type PowerChainInput, type PowerChainSaved } from "@/lib/ortho/power-chain";
import { elastomericColorForItemName, elastomericItemName } from "@/lib/ortho/elastomeric-colors";
import { deductBracketTooth, isBracketBrand, returnBracketTooth } from "@/lib/ortho/bracket-stock";
import { deductTubeTooth, isTubeTooth, returnTubeTooth } from "@/lib/ortho/tube-stock";
import { logAdminEvent } from "@/lib/audit";

function canEditMedicalRecordFor(role: string | undefined): boolean {
  return role === "doctor" || role === "admin" || role === "clinic_manager";
}

type ActionResult = { ok: boolean; reason?: string; [key: string]: unknown };

function isMolarPosition(position: number): boolean {
  return position >= 6;
}

const TOOTH_BY_FDI = Object.fromEntries(ALL_TEETH.map((t) => [t.fdi, t]));

interface ToothState {
  bracket: "none" | "bonded" | "broken";
  debondDate: string | null;
  bondedDate: string | null;
  rebondCount: number;
  extracted: boolean;
  comment: string;
}

function emptyToothState(): ToothState {
  return { bracket: "none", debondDate: null, bondedDate: null, rebondCount: 0, extracted: false, comment: "" };
}

function parseToothStates(raw: string | null): Record<string, ToothState> {
  if (!raw) return {};
  try {
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

function parseCounts(raw: string | null): Record<string, number> {
  if (!raw) return {};
  try {
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

function parseFlags(raw: string | null): Record<string, boolean> {
  if (!raw) return {};
  try {
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

async function ensureChartRow(patientId: number, userId: number) {
  const existing = await db
    .selectFrom("orthodontic_charts")
    .select(["id"])
    .where("patient_id", "=", patientId)
    .executeTakeFirst();
  if (existing) return;
  await db.insertInto("orthodontic_charts").values({ patient_id: patientId, created_by: userId, updated_by: userId }).execute();
}

async function logChartEvent(
  trx: Transaction<Database>,
  params: { patientId: number; field: string; reason: string; date: string; userId: number }
) {
  await trx
    .insertInto("audit_log")
    .values({
      entity_type: "orthodontic_chart",
      entity_id: params.patientId,
      field: params.field,
      old_value: null,
      new_value: null,
      reason: params.reason,
      changed_by: params.userId,
      event_date: params.date,
    })
    .execute();
}

// بيحاول يلاقي صنف حقيقي في المخزون بنفس اسم الخصم — أول بالاسم كامل، بعدين
// بالاسم الأساسي من غير أي لاحقة بعد "—" أو "(". مطابقة case-insensitive.
async function resolveInventoryItemId(trx: Transaction<Database>, label: string): Promise<number | null> {
  const baseLabel = label.split(/[—(]/)[0].trim();
  const candidates = Array.from(new Set([label.trim(), baseLabel]));
  for (const candidate of candidates) {
    if (!candidate) continue;
    const row = await trx
      .selectFrom("inventory_items")
      .select(["id"])
      .where((eb) => eb("name", "like", candidate))
      .executeTakeFirst();
    if (row) return row.id;
  }
  return null;
}

// خصم مخزون حقيقي — بيسجل في ortho_inventory_deductions (ledger)، وبيدمج
// خصومات الـTubes بنفس التاريخ (زي البروتوتايب بالظبط: كل تيوبز اتركبت في
// نفس تاريخ الزيارة بيتحطوا في سطر واحد بعددهم وأرقام الأسنان)، وبيخصم من
// inventory_items.quantity الحقيقي لو لقى صنف بنفس الاسم.
async function deductInventory(
  trx: Transaction<Database>,
  params: { patientId: number; visitId: number | null; label: string; itemId?: number | null; qty: number; teeth?: number[]; date: string; userId: number }
) {
  if (!(await inventoryDeductionsEnabled(trx))) return;
  const itemId = params.itemId ?? (await resolveInventoryItemId(trx, params.label));

  // الدمج بيحصل لأي خصم بيتبعت معاه أرقام أسنان (teeth) — مش بس Tubes زي ما
  // كان الحال قبل كده — عشان بعد كده نقدر نعمل ريفند جزئي لسن واحد من سطر
  // مجمّع (زي "Brackets — Bonding Upper") لما يتصحح إنه ما كانش المفروض يتركّب.
  if (params.teeth && params.teeth.length > 0 && params.visitId === null) {
    const existing = await trx
      .selectFrom("ortho_inventory_deductions")
      .selectAll()
      .where("patient_id", "=", params.patientId)
      .where("label", "=", params.label)
      .where("deduction_date", "=", params.date)
      .where("visit_id", "is", null)
      .where("undone_at", "is", null)
      .executeTakeFirst();

    if (existing) {
      const existingTeeth: number[] = existing.teeth ? JSON.parse(existing.teeth) : [];
      await trx
        .updateTable("ortho_inventory_deductions")
        .set({ qty: existing.qty + params.qty, teeth: JSON.stringify([...existingTeeth, ...params.teeth]) })
        .where("id", "=", existing.id)
        .execute();
      if (itemId) await deductInventoryItem(trx, { itemId, quantity: params.qty, movementType: "ortho_use", note: params.label, createdBy: params.userId });
      return;
    }
  }

  await trx
    .insertInto("ortho_inventory_deductions")
    .values({
      patient_id: params.patientId,
      visit_id: params.visitId,
      item_id: itemId,
      label: params.label,
      qty: params.qty,
      teeth: params.teeth && params.teeth.length > 0 ? JSON.stringify(params.teeth) : null,
      deduction_date: params.date,
      created_by: params.userId,
    })
    .execute();

  if (itemId) await deductInventoryItem(trx, { itemId, quantity: params.qty, movementType: "ortho_use", note: params.label, createdBy: params.userId });
}

async function latestBondingBracketBrand(trx: Transaction<Database>, patientId: number) {
  const row = await trx.selectFrom("ortho_visits").select("bonding_bracket_brand")
    .where("patient_id", "=", patientId).where("bonding_bracket_brand", "is not", null).orderBy("id", "desc").executeTakeFirst();
  return isBracketBrand(row?.bonding_bracket_brand) ? row.bonding_bracket_brand : null;
}

// الكومبوزيت ليس اختياراً يكتبه الطبيب كل مرة: كل Bracket أو Tube جديد أو
// Rebonding يستهلك كمية الصنف المعرّفة "لكل سن" في المخزن. لو لم يُعرّف
// الصنف بعد في المخزن، لا نمنع الشارت من العمل؛ يبدأ الخصم تلقائياً بعد تعريفه.
async function deductOrthodonticComposite(
  trx: Transaction<Database>,
  params: { patientId: number; visitId: number | null; attachmentCount: number; teeth?: number[]; date: string; userId: number }
) {
  if (params.attachmentCount <= 0) return;
  const composite = await trx
    .selectFrom("inventory_items")
    .select(["id", "name", "auto_deduction_per_attachment"])
    .where("auto_deduction_key", "=", "orthodontic_composite")
    .executeTakeFirst();
  if (!composite || composite.auto_deduction_per_attachment <= 0) return;
  await deductInventory(trx, {
    patientId: params.patientId,
    visitId: params.visitId,
    label: composite.name,
    itemId: composite.id,
    qty: params.attachmentCount * composite.auto_deduction_per_attachment,
    teeth: params.teeth,
    date: params.date,
    userId: params.userId,
  });
}

// دفعة 150: نفس activeBondedBracketCount بس بترجّع أرقام الأسنان، عشان الـ O-ties
// تتحسب لكل فك لوحده ويتطرح منها الأسنان اللي عليها Power chain على البراكتس.
async function activeBondedBracketTeeth(trx: Transaction<Database>, patientId: number): Promise<number[]> {
  const chart = await trx.selectFrom("orthodontic_charts").select("tooth_states").where("patient_id", "=", patientId).executeTakeFirst();
  const states = parseToothStates(chart?.tooth_states ?? null);
  return ALL_TEETH.filter((tooth) => tooth.position < 6 && states[tooth.fdi]?.bracket === "bonded").map((tooth) => tooth.fdi);
}

async function activeBondedBracketCount(trx: Transaction<Database>, patientId: number): Promise<number> {
  const chart = await trx.selectFrom("orthodontic_charts").select("tooth_states").where("patient_id", "=", patientId).executeTakeFirst();
  const states = parseToothStates(chart?.tooth_states ?? null);
  // موضع 6 فأكثر هو Tube/ضرس، وليس Bracket، فلا يدخل في O-tie.
  return ALL_TEETH.filter((tooth) => tooth.position < 6 && states[tooth.fdi]?.bracket === "bonded").length;
}

// Batch 147: قاعدة السلك. قبل كده السلك كان إجباري لأي فك اتعمله Bonding في
// أي وقت (من تاريخ الزيارات)، فكان بيتطلب في Debonding وRetainer delivery
// وفي تعديل زيارة Consultation قديمة. دلوقتي: إجباري بس لو
//   - الزيارة نفسها Bonding للفك ده، أو
//   - الفك فيه براكتس متركّبة "دلوقتي" في الشارت، والزيارة مش من الأنواع اللي
//     مالهاش سلك، وتاريخها مش قبل تركيب الفك.
// نفس القاعدة بالحرف في FollowUpsTable (الواجهة) — السيرفر هو الحكم.
const NO_WIRE_SERVICES = new Set(["Debonding", "Retainer delivery", "Consultation"]);

function archBondedSince(states: Record<string, ToothState>, row: typeof UPPER_ROW): string | null {
  const bonded = row.filter((tooth) => states[tooth.fdi]?.bracket === "bonded");
  if (bonded.length === 0) return null;
  const dates = bonded.map((tooth) => states[tooth.fdi]?.bondedDate).filter((date): date is string => Boolean(date)).map((date) => date.slice(0, 10)).sort();
  return dates[0] ?? "0000-00-00";
}

function wireRequirement(states: Record<string, ToothState>, service: string, visitDate: string) {
  const needs = (since: string | null) => since != null && !NO_WIRE_SERVICES.has(service) && visitDate >= since;
  return {
    upper: service === "Bonding Upper" || needs(archBondedSince(states, UPPER_ROW)),
    lower: service === "Bonding Lower" || needs(archBondedSince(states, LOWER_ROW)),
  };
}

// --- أعلى الصفحة (بروفايل الشارت + Treatment Plan) --------------------------

export async function saveOrthoTopSectionAction(formData: FormData): Promise<ActionResult> {
  const session = await getSession();
  if (!session || !canEditMedicalRecordFor(session.role)) return { ok: false, reason: "غير مسموح" };

  const patientId = Number(formData.get("patient_id"));
  if (!patientId) return { ok: false, reason: "بيانات ناقصة" };

  await ensureChartRow(patientId, session!.userId);

  const extractionQuadrants = {
    ur: String(formData.get("extraction_ur") || ""),
    ul: String(formData.get("extraction_ul") || ""),
    lr: String(formData.get("extraction_lr") || ""),
    ll: String(formData.get("extraction_ll") || ""),
  };
  const hasExtraction = Object.values(extractionQuadrants).some(Boolean);

  await db
    .updateTable("orthodontic_charts")
    .set({
      bracket_type: String(formData.get("bracket_type") || "").trim() || null,
      prescription: String(formData.get("prescription") || "").trim() || null,
      slot: String(formData.get("slot") || "").trim() || null,
      chief_complaint: String(formData.get("chief_complaint") || "").trim() || null,
      extraction_quadrants: hasExtraction ? JSON.stringify(extractionQuadrants) : null,
      anchorage_device: String(formData.get("anchorage_device") || "").trim() || null,
      treatment_note: String(formData.get("treatment_note") || "").trim() || null,
      updated_by: session!.userId,
      updated_at: new Date().toISOString(),
    })
    .where("patient_id", "=", patientId)
    .execute();

  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true };
}

// حفظ مستقل وخفيف للملخصات الثلاثة الظاهرة أسفل الأسنان. هذا يمنع نموذج
// الـDiagnostic أو نموذج Treatment plan من مسح أحدهما للآخر عند الحفظ التلقائي.
export async function saveOrthoChartSummaryAction(input: {
  patientId: number;
  field: "chief_complaint" | "treatment_note" | "diagnosis_summary";
  value: string;
}): Promise<ActionResult> {
  const session = await getSession();
  if (!session || !canEditMedicalRecordFor(session.role)) return { ok: false, reason: "غير مسموح" };
  if (!Number.isInteger(input.patientId) || input.patientId <= 0) return { ok: false, reason: "بيانات ناقصة" };
  if (!["chief_complaint", "treatment_note", "diagnosis_summary"].includes(input.field)) return { ok: false, reason: "حقل غير صحيح" };

  await ensureChartRow(input.patientId, session.userId);
  await db
    .updateTable("orthodontic_charts")
    .set({ [input.field]: input.value.trim() || null, updated_by: session.userId, updated_at: new Date().toISOString() })
    .where("patient_id", "=", input.patientId)
    .execute();
  revalidatePath(`/patients/${input.patientId}/orthodontics`);
  return { ok: true };
}

// --- Diagnostic chart --------------------------------------------------------
// تحديث جزئي بس (مش upsert كامل الصف زي saveOrthodonticChartAction القديمة في
// actions.ts) — عمدًا فعل منفصل، عشان الحقول دي والحقول اللي أعلى الصفحة
// (chief_complaint/prescription وغيرهم في saveOrthoTopSectionAction فوق)
// بتتحفظ من نموذجين منفصلين على الشاشة؛ لو استخدمنا upsert كامل الصف في
// الاتنين كانوا هيمسحوا بيانات بعض (كل حفظ من فورم بيبعت بس الحقول اللي هو
// عارفها، فالتانية بترجع null). التحديث الجزئي هنا بيلمس بس أعمدة الـDiagnostic
// نفسها.
export async function saveOrthoDiagnosticAction(formData: FormData): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const patientId = Number(formData.get("patient_id"));
  if (!patientId) return { ok: false, reason: "بيانات ناقصة" };

  await ensureChartRow(patientId, session!.userId);

  const str = (key: string) => {
    const raw = String(formData.get(key) ?? "").trim();
    return raw || null;
  };
  const num = (key: string) => {
    const raw = formData.get(key);
    if (raw == null || raw === "") return null;
    const n = Number(raw);
    return Number.isFinite(n) ? n : null;
  };

  await db
    .updateTable("orthodontic_charts")
    .set({
      antero_posterior: str("antero_posterior") as "class1" | "class2" | "class3" | null,
      facial_height: str("facial_height") as "increased" | "average" | "decreased" | null,
      mx_incisor_inclination: str("mx_incisor_inclination") as "proclined" | "average" | "retroclined" | null,
      mn_incisor_inclination: str("mn_incisor_inclination") as "proclined" | "average" | "retroclined" | null,
      molar_relation_right: str("molar_relation_right") as "class1" | "class2" | "class3" | null,
      molar_relation_left: str("molar_relation_left") as "class1" | "class2" | "class3" | null,
      overbite: str("overbite") as "open_bite" | "average" | "deep_bite" | null,
      overjet: str("overjet") as "increased" | "average" | "decreased" | null,
      midline_upper_direction: str("midline_upper_direction") as "right" | "left" | null,
      midline_upper_mm: num("midline_upper_mm"),
      midline_lower_direction: str("midline_lower_direction") as "right" | "left" | null,
      midline_lower_mm: num("midline_lower_mm"),
      space_upper_type: str("space_upper_type") as "crowding" | "spacing" | null,
      space_upper_mm: num("space_upper_mm"),
      space_lower_type: str("space_lower_type") as "crowding" | "spacing" | null,
      space_lower_mm: num("space_lower_mm"),
      nasolabial_angle: str("nasolabial_angle") as "acute" | "average" | "obtuse" | null,
      lips: str("lips") as "competent" | "incompetent" | null,
      updated_by: session!.userId,
      updated_at: new Date().toISOString(),
    })
    .where("patient_id", "=", patientId)
    .execute();

  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true };
}

// --- الشارت التفاعلي ---------------------------------------------------------

export async function bulkBondAction(params: { patientId: number; arch: "upper" | "lower"; date: string }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, arch, date } = params;
  await ensureChartRow(patientId, session!.userId);

  const chart = await db.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const states = parseToothStates(chart.tooth_states);
  const row = arch === "upper" ? UPPER_ROW : LOWER_ROW;
  // الأسنان المخلوعة مستبعدة من التركيب ومن عدد المخزون مع بعض — لو سن اتسجل
  // إنه مخلوع قبل عمل خدمة البوندنج، منقدرش نركّبله براكت/تيوب خالص.
  const targets = row.filter((t) => t.position <= 6 && !(states[t.fdi]?.extracted ?? false));
  if (targets.length === 0) return { ok: false, reason: "كل أسنان الفك ده مخلوعة أو متركّبة بالفعل" };

  await db.transaction().execute(async (trx) => {
    const nextStates = { ...states };
    targets.forEach((t) => {
      const current = nextStates[t.fdi] ?? emptyToothState();
      nextStates[t.fdi] = { ...current, bracket: "bonded", debondDate: null, bondedDate: date };
    });
    await trx
      .updateTable("orthodontic_charts")
      .set({ tooth_states: JSON.stringify(nextStates), updated_by: session!.userId, updated_at: new Date().toISOString() })
      .where("patient_id", "=", patientId)
      .execute();

    const archLabel = arch === "upper" ? "Upper" : "Lower";
    const bracketTargets = targets.filter((t) => !isMolarPosition(t.position));
    const tubeTargets = targets.filter((t) => isMolarPosition(t.position));

    if (bracketTargets.length > 0) {
      await deductInventory(trx, {
        patientId,
        visitId: null,
        label: `Brackets — Bonding ${archLabel}`,
        qty: bracketTargets.length,
        teeth: bracketTargets.map((t) => t.fdi),
        date,
        userId: session!.userId,
      });
    }
    if (tubeTargets.length > 0) {
      for (const tooth of tubeTargets) await deductTubeTooth(trx, { fdi: tooth.fdi, patientId, createdBy: session!.userId, note: `Bonding ${archLabel}` });
    }
    await deductOrthodonticComposite(trx, {
      patientId,
      visitId: null,
      attachmentCount: targets.length,
      teeth: targets.map((tooth) => tooth.fdi),
      date,
      userId: session!.userId,
    });

    await logChartEvent(trx, {
      patientId,
      field: "bulk_bond",
      reason: `Bulk bond — ${archLabel} arch (${targets.map((t) => t.fdi).join(", ")})`,
      date,
      userId: session!.userId,
    });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  revalidatePath("/inventory");
  return { ok: true };
}

export async function manualBondToothAction(params: { patientId: number; fdi: number; date: string }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, fdi, date } = params;
  const meta = TOOTH_BY_FDI[fdi];
  if (!meta) return { ok: false, reason: "سن غير معروف" };

  await ensureChartRow(patientId, session!.userId);
  const chart = await db.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const states = parseToothStates(chart.tooth_states);
  const current = states[fdi] ?? emptyToothState();
  if (current.extracted) return { ok: false, reason: `السن ${fdi} مخلوع — منقدرش نركّبله براكت/تيوب` };
  if (current.bracket === "bonded") return { ok: false, reason: "السن ده متركّب بالفعل" };

  const isMolar = isMolarPosition(meta.position);

  const bracketBrand = !isMolar ? await db.transaction().execute((trx) => latestBondingBracketBrand(trx, patientId)) : null;
  if (!isMolar && !bracketBrand) return { ok: false, reason: "سجل أولاً زيارة Bonding واختر شركة البراكتس." };

  await db.transaction().execute(async (trx) => {
    const nextStates = { ...states, [fdi]: { ...current, bracket: "bonded" as const, bondedDate: date, debondDate: null } };
    await trx
      .updateTable("orthodontic_charts")
      .set({ tooth_states: JSON.stringify(nextStates), updated_by: session!.userId, updated_at: new Date().toISOString() })
      .where("patient_id", "=", patientId)
      .execute();

    if (isMolar) {
      if (isTubeTooth(fdi)) await deductTubeTooth(trx, { fdi, patientId, createdBy: session!.userId, note: `تركيب Tube سن ${fdi}` });
    } else {
      await deductBracketTooth(trx, { brand: bracketBrand!, fdi, patientId, date, createdBy: session!.userId, note: `تركيب براكت سن ${fdi}` });
    }
    await deductOrthodonticComposite(trx, { patientId, visitId: null, attachmentCount: 1, teeth: [fdi], date, userId: session!.userId });

    await logChartEvent(trx, {
      patientId,
      field: "manual_bond",
      reason: `Bonded ${isMolar ? "tube" : "bracket"} — tooth ${fdi}`,
      date,
      userId: session!.userId,
    });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  revalidatePath("/inventory");
  return { ok: true };
}

export async function confirmDebondAction(params: { patientId: number; fdi: number; date: string }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, fdi, date } = params;
  const chart = await db.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const states = parseToothStates(chart.tooth_states);
  const current = states[fdi] ?? emptyToothState();

  await db.transaction().execute(async (trx) => {
    const nextStates = { ...states, [fdi]: { ...current, bracket: "broken" as const, debondDate: date } };
    await trx
      .updateTable("orthodontic_charts")
      .set({ tooth_states: JSON.stringify(nextStates), updated_by: session!.userId, updated_at: new Date().toISOString() })
      .where("patient_id", "=", patientId)
      .execute();
    await logChartEvent(trx, { patientId, field: "debond", reason: `Broken / fell off — tooth ${fdi}`, date, userId: session!.userId });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true };
}

// تصحيح غلطة بوندنج (السن أصلاً مكانش المفروض يتركّب) — يرجع لحالة "none" من
// غير ما يسجل debond حقيقي. لغاية 2026-08-27 كان مفيش أي تأثير على المخزون —
// اتصلح بناءً على بلاغ: الخصم الأصلي (وقت البوندنج الجماعي أو اليدوي) دلوقتي
// بيترجع (سن واحد بس، مش كل الخصم لو كان مجمّع لعدة أسنان زي "Brackets —
// Bonding Upper"/"Tubes") — أول ما نلاقي أقرب خصم فعلي (لسه ماتعملوش Undo)
// بيغطي السن ده.
export async function confirmNoBracketsAction(params: { patientId: number; fdi: number }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, fdi } = params;
  const chart = await db.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const states = parseToothStates(chart.tooth_states);
  const current = states[fdi] ?? emptyToothState();
  const today = getClinicToday();
  const singleToothLabels = [`Bracket (tooth ${fdi})`, `New bracket (tooth ${fdi})`];

  await db.transaction().execute(async (trx) => {
    const nextStates = { ...states, [fdi]: { ...current, bracket: "none" as const, debondDate: null, bondedDate: null } };
    await trx
      .updateTable("orthodontic_charts")
      .set({ tooth_states: JSON.stringify(nextStates), updated_by: session!.userId, updated_at: new Date().toISOString() })
      .where("patient_id", "=", patientId)
      .execute();

    const rows = await trx
      .selectFrom("ortho_inventory_deductions")
      .selectAll()
      .where("patient_id", "=", patientId)
      .where("undone_at", "is", null)
      .orderBy("id", "desc")
      .execute();

    // لو السطر فيه teeth array (خصم مجمّع لعدة أسنان)، لازم يشمل السن ده فعلاً؛
    // لو من غير teeth (سطر مخصوص لسن واحد أصلاً)، اللابل نفسه كفاية.
    const target = rows.find((r) => {
      if (!r.teeth) return singleToothLabels.includes(r.label);
      try {
        return (JSON.parse(r.teeth) as number[]).includes(fdi);
      } catch {
        return false;
      }
    });

    let refunded = false;
    let bracketRefunded = false;
    if (target) {
      if (target.teeth) {
        const teeth = (JSON.parse(target.teeth) as number[]).filter((t) => t !== fdi);
        if (teeth.length > 0) {
          await trx
            .updateTable("ortho_inventory_deductions")
            .set({ qty: target.qty - 1, teeth: JSON.stringify(teeth) })
            .where("id", "=", target.id)
            .execute();
        } else {
          await trx
            .updateTable("ortho_inventory_deductions")
            .set({ undone_by: session!.userId, undone_at: new Date().toISOString() })
            .where("id", "=", target.id)
            .execute();
        }
      } else {
        await trx
          .updateTable("ortho_inventory_deductions")
          .set({ undone_by: session!.userId, undone_at: new Date().toISOString() })
          .where("id", "=", target.id)
          .execute();
      }
      if (target.item_id) await returnInventoryItem(trx, { itemId: target.item_id, quantity: 1, note: "إلغاء bracket من شارت التقويم", createdBy: session!.userId });
      const bracketBrand = target.label.replace(/ brackets$/i, "");
      if (!target.item_id && isBracketBrand(bracketBrand) && !isMolarPosition(TOOTH_BY_FDI[fdi]?.position ?? 6)) {
        await returnBracketTooth(trx, { brand: bracketBrand, fdi, patientId, date: target.deduction_date, createdBy: session!.userId, note: "تصحيح No brackets" });
        bracketRefunded = true;
      }
      refunded = true;
    }
    // البراكتس الجديدة لها دفتر مستقل عن خامات المخزن العادية. هذا يغطي
    // التركيب اليدوي أو Rebonding، حيث لا يوجد بالضرورة سطر generic في ledger.
    if (!bracketRefunded && !isMolarPosition(TOOTH_BY_FDI[fdi]?.position ?? 6)) {
      const use = await trx.selectFrom("orthodontic_bracket_stock_movements").select(["brand", "movement_date", "created_at"])
        .where("patient_id", "=", patientId).where("fdi", "=", fdi).where("movement_type", "=", "ortho_use").orderBy("id", "desc").executeTakeFirst();
      if (use && isBracketBrand(use.brand)) {
        await returnBracketTooth(trx, { brand: use.brand, fdi, patientId, date: use.movement_date ?? use.created_at.slice(0, 10), createdBy: session!.userId, note: "تصحيح No brackets" });
        refunded = true;
      }
    }
    if (isMolarPosition(TOOTH_BY_FDI[fdi]?.position ?? 6) && isTubeTooth(fdi)) {
      await returnTubeTooth(trx, { fdi, patientId, createdBy: session!.userId, note: "تصحيح No brackets" });
      refunded = true;
    }

    await logChartEvent(trx, {
      patientId,
      field: "no_brackets",
      reason: `No-brackets correction — tooth ${fdi}${refunded ? " (inventory refunded)" : ""}`,
      date: today,
      userId: session!.userId,
    });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  revalidatePath("/inventory");
  return { ok: true };
}

// حذف زيارة فولو أب بالكامل من شارت التقويم — دفعة 27، طلب صريح: "دخلت خدمة
// غلط، عايز أمسحها كاملة وأدخلها تاني" بدل ما أتقيّد بالـEdit (اللي مايفتحش
// تغيير الـservice بعد ما تتحفظ). نفس صلاحية "delete_visits" الموجودة أصلاً
// لحذف زيارات الملف الطبي العادي (تأكيد المستخدم: "نفس صلاحية الحذف تطبق على
// شارت التقويم"), مش صلاحية جديدة مخصوصة.
//
// بيرجع كل حاجة اتسببت فيها الزيارة دي:
//   1) خصومات المخزون المربوطة بالزيارة مباشرة (visit_id) — إلاستكس/أوتايز/
//      باور تشين/بازر/كويل — بترجع لرصيد المخزون وتتمسح.
//   2) لو الزيارة دي هي اللي عملت bonding (bonding_applied=1)، بترجع حالة كل
//      سن لسه متسجل عليه إنه اتلزّق بنفس تاريخ الزيارة دي بالظبط (bondedDate
//      === visit_date) — معيار دقيق بيستثني تلقائيًا أي سن اتصحح بعدين بـ
//      "No brackets" أو اتفك/اتلزّق تاني بتاريخ مختلف. لكل سن من دول، بيتطبق
//      نفس منطق الريفند الجزئي بالظبط اللي في confirmNoBracketsAction فوق
//      (تشيل السن من الـteeth array لو الخصم مجمّع، أو تلغي الخصم كله لو ده
//      كان آخر سن فيه).
export async function deleteOrthoVisitAction(params: { patientId: number; visitId: number }): Promise<ActionResult> {
  const session = await getSession();
  if (!session) return { ok: false, reason: "غير مسموح" };
  const canDelete = await hasPermission(session.userId, session.role as Role, "delete_visits");
  if (!canDelete) return { ok: false, reason: "محتاج صلاحية حذف الزيارات" };

  const { patientId, visitId } = params;
  const visitRow = await db.selectFrom("ortho_visits").selectAll().where("id", "=", visitId).where("patient_id", "=", patientId).executeTakeFirst();
  if (!visitRow) return { ok: false, reason: "الزيارة دي مش موجودة" };

  let revertedTeeth = 0;

  await db.transaction().execute(async (trx) => {
    // (1) خصومات مربوطة بالزيارة مباشرة — نفس الاستهلاكات اللي بتترجع أصلاً
    // وقت الـEdit (شوف فوق)، بس هنا بترجع فعليًا للمخزون بدل ما تتسجل تاني.
    const tiedDeductions = await trx
      .selectFrom("ortho_inventory_deductions")
      .selectAll()
      .where("visit_id", "=", visitId)
      .where("undone_at", "is", null)
      .execute();
    for (const d of tiedDeductions) {
      if (d.item_id) await returnInventoryItem(trx, { itemId: d.item_id, quantity: d.qty, note: "حذف زيارة تقويم", createdBy: session!.userId });
    }
    await trx.deleteFrom("ortho_inventory_deductions").where("visit_id", "=", visitId).execute();

    // (2) لو الزيارة دي عملت bonding، رجّع حالة الأسنان + خصومات البراكيت/التيوب
    if (visitRow.bonding_applied === 1) {
      const chart = await trx.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
      let states = parseToothStates(chart?.tooth_states ?? null);
      const arch = visitRow.service === "Bonding Upper" ? "upper" : "lower";
      const row = arch === "upper" ? UPPER_ROW : LOWER_ROW;
      const affected = row.filter((t) => {
        const st = states[t.fdi];
        return st && st.bracket === "bonded" && st.bondedDate === visitRow.visit_date;
      });

      for (const t of affected) {
        const singleToothLabels = [`Bracket (tooth ${t.fdi})`, `New bracket (tooth ${t.fdi})`];
        const rows = await trx
          .selectFrom("ortho_inventory_deductions")
          .selectAll()
          .where("patient_id", "=", patientId)
          .where("undone_at", "is", null)
          .orderBy("id", "desc")
          .execute();
        const target = rows.find((r) => {
          if (!r.teeth) return singleToothLabels.includes(r.label);
          try {
            return (JSON.parse(r.teeth) as number[]).includes(t.fdi);
          } catch {
            return false;
          }
        });
        if (target) {
          if (target.teeth) {
            const teeth = (JSON.parse(target.teeth) as number[]).filter((x) => x !== t.fdi);
            if (teeth.length > 0) {
              await trx.updateTable("ortho_inventory_deductions").set({ qty: target.qty - 1, teeth: JSON.stringify(teeth) }).where("id", "=", target.id).execute();
            } else {
              await trx
                .updateTable("ortho_inventory_deductions")
                .set({ undone_by: session!.userId, undone_at: new Date().toISOString() })
                .where("id", "=", target.id)
                .execute();
            }
          } else {
            await trx
              .updateTable("ortho_inventory_deductions")
              .set({ undone_by: session!.userId, undone_at: new Date().toISOString() })
              .where("id", "=", target.id)
              .execute();
          }
          if (target.item_id) await returnInventoryItem(trx, { itemId: target.item_id, quantity: 1, note: "تصحيح bonding من شارت التقويم", createdBy: session!.userId });
          const bracketBrand = target.label.replace(/ brackets$/i, "");
          if (!target.item_id && isBracketBrand(bracketBrand) && !isMolarPosition(t.position)) {
            await returnBracketTooth(trx, { brand: bracketBrand, fdi: t.fdi, patientId, visitId, date: visitRow.visit_date, createdBy: session!.userId, note: "حذف زيارة Bonding" });
          }
        }
        if (isMolarPosition(t.position) && isTubeTooth(t.fdi)) {
          await returnTubeTooth(trx, { fdi: t.fdi, patientId, visitId, createdBy: session!.userId, note: "حذف زيارة Bonding" });
        }
        states = { ...states, [t.fdi]: { ...states[t.fdi], bracket: "none", bondedDate: null, debondDate: null } };
        revertedTeeth++;
      }

      if (revertedTeeth > 0) {
        await trx
          .updateTable("orthodontic_charts")
          .set({ tooth_states: JSON.stringify(states), updated_by: session!.userId, updated_at: new Date().toISOString() })
          .where("patient_id", "=", patientId)
          .execute();
      }
    }

    // Batch 147: بعد إلغاء تركيب الفك، لو مفيش ولا سن في الفك ده لسه متركّب
    // أو مكسور، بادج "Upper/Lower bonding" ماتفضلش ظاهرة بتاريخ قديم.
    if (visitRow.bonding_applied === 1 && revertedTeeth > 0) {
      const arch = visitRow.service === "Bonding Upper" ? "upper" : "lower";
      const row = arch === "upper" ? UPPER_ROW : LOWER_ROW;
      const chartNow = await trx.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
      const statesNow = parseToothStates(chartNow?.tooth_states ?? null);
      const archStillHasBrackets = row.some((tooth) => statesNow[tooth.fdi]?.bracket === "bonded" || statesNow[tooth.fdi]?.bracket === "broken");
      if (!archStillHasBrackets) {
        await trx
          .updateTable("orthodontic_charts")
          .set(arch === "upper" ? { bonding_upper_date: null } : { bonding_lower_date: null })
          .where("patient_id", "=", patientId)
          .execute();
      }
    }

    // Batch 147: حذف زيارة Debonding بيرجّع السنان اللي الزيارة دي فكّتها
    // لحالتها قبل الفك بالظبط (من debond_snapshot). أي سن اتغيرت حالته بعد
    // الفك (اتركّب تاني مثلًا) مابيتلمسش.
    let restoredTeeth = 0;
    if (visitRow.debond_applied === 1 && visitRow.debond_snapshot) {
      const before = parseToothStates(visitRow.debond_snapshot);
      const chartNow = await trx.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
      const statesNow = parseToothStates(chartNow?.tooth_states ?? null);
      const restored: Record<string, ToothState> = { ...statesNow };
      for (const tooth of ALL_TEETH) {
        const prior = before[tooth.fdi];
        const current = statesNow[tooth.fdi];
        if (prior && (prior.bracket === "bonded" || prior.bracket === "broken") && current && current.bracket === "none" && current.debondDate === visitRow.visit_date) {
          restored[tooth.fdi] = prior;
          restoredTeeth++;
        }
      }
      if (chartNow && restoredTeeth > 0) {
        await trx
          .updateTable("orthodontic_charts")
          .set({ tooth_states: JSON.stringify(restored), updated_by: session!.userId, updated_at: new Date().toISOString() })
          .where("patient_id", "=", patientId)
          .execute();
      }
    }

    // (3) الزيارة نفسها
    await trx.deleteFrom("ortho_visits").where("id", "=", visitId).execute();

    // دفعة 27 (P2.4): امسح مزامنة المعالجة من الزيارة المقابلة بالملف الطبي —
    // إلا لو لسه فيه زيارة متابعة تانية باقية لنفس المريض/التاريخ (نادر، بس
    // ممكن)، وقتها بنعيد المزامنة بمحتواها هي بدل ما نمسح المعالجة بالغلط.
    const remaining = await trx
      .selectFrom("ortho_visits")
      .selectAll()
      .where("patient_id", "=", patientId)
      .where("visit_date", "=", visitRow.visit_date)
      .orderBy("id", "desc")
      .executeTakeFirst();
    if (remaining?.doctor_id) {
      const paragraph = buildOrthoTreatmentParagraph({
        service: remaining.service,
        upperWireSize: remaining.upper_wire_size,
        upperWireType: remaining.upper_wire_type,
        lowerWireSize: remaining.lower_wire_size,
        lowerWireType: remaining.lower_wire_type,
        elastics: remaining.elastics_size,
        otie: remaining.otie_color,
        powerChainQty: remaining.power_chain_qty,
        buttonsQty: remaining.buttons_qty,
        compressedCoilMm: remaining.compressed_coil_mm,
        note: remaining.note,
      });
      await syncOrthoNoteToMedicalVisit(trx, {
        patientId,
        orthoVisitId: remaining.id,
        visitDate: visitRow.visit_date,
        paragraph,
        performingDoctorId: remaining.doctor_id,
      });
    } else {
      await clearSyncedOrthoNote(trx, { patientId, orthoVisitId: visitId });
    }

    await logChartEvent(trx, {
      patientId,
      field: "delete_visit",
      reason: `Deleted follow-up visit (${visitRow.visit_date}, ${visitRow.service || "—"})${revertedTeeth > 0 ? ` — reverted bonding on ${revertedTeeth} tooth/teeth` : ""}${restoredTeeth > 0 ? ` — restored ${restoredTeeth} bracket(s) removed by this debonding` : ""}`,
      date: getClinicToday(),
      userId: session!.userId,
    });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  revalidatePath(`/patients/${patientId}`);
  revalidatePath("/inventory");
  return { ok: true };
}

export async function confirmRebondAction(params: { patientId: number; fdi: number; kind: "new" | "old"; date: string }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, fdi, kind, date } = params;
  const meta = TOOTH_BY_FDI[fdi];
  if (!meta) return { ok: false, reason: "سن غير معروف" };

  const chart = await db.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const states = parseToothStates(chart.tooth_states);
  const current = states[fdi] ?? emptyToothState();
  const isMolar = isMolarPosition(meta.position);
  const bracketBrand = kind === "new" && !isMolar ? await db.transaction().execute((trx) => latestBondingBracketBrand(trx, patientId)) : null;
  if (kind === "new" && !isMolar && !bracketBrand) return { ok: false, reason: "سجل أولاً زيارة Bonding واختر شركة البراكتس." };

  await db.transaction().execute(async (trx) => {
    const nextStates = {
      ...states,
      [fdi]: { ...current, bracket: "bonded" as const, debondDate: null, bondedDate: date, rebondCount: current.rebondCount + 1 },
    };
    await trx
      .updateTable("orthodontic_charts")
      .set({ tooth_states: JSON.stringify(nextStates), updated_by: session!.userId, updated_at: new Date().toISOString() })
      .where("patient_id", "=", patientId)
      .execute();

    if (kind === "new") {
      if (isMolar) {
        if (isTubeTooth(fdi)) await deductTubeTooth(trx, { fdi, patientId, createdBy: session!.userId, note: `Rebonding Tube سن ${fdi}` });
      } else {
        await deductBracketTooth(trx, { brand: bracketBrand!, fdi, patientId, date, createdBy: session!.userId, note: `Rebonding سن ${fdi}` });
      }
    }
    await deductOrthodonticComposite(trx, { patientId, visitId: null, attachmentCount: 1, teeth: [fdi], date, userId: session!.userId });

    await logChartEvent(trx, {
      patientId,
      field: "rebond",
      reason: `Rebonded (${kind} ${isMolar ? "tube" : "bracket"}) — tooth ${fdi}`,
      date,
      userId: session!.userId,
    });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  revalidatePath("/inventory");
  return { ok: true };
}

export async function toggleExtractedAction(params: { patientId: number; fdi: number }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, fdi } = params;
  await ensureChartRow(patientId, session!.userId);
  const chart = await db.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const states = parseToothStates(chart.tooth_states);
  const current = states[fdi] ?? emptyToothState();
  const wasExtracted = current.extracted;
  const today = getClinicToday();

  await db.transaction().execute(async (trx) => {
    const nextStates = { ...states, [fdi]: { ...current, extracted: !wasExtracted } };
    await trx
      .updateTable("orthodontic_charts")
      .set({ tooth_states: JSON.stringify(nextStates), updated_by: session!.userId, updated_at: new Date().toISOString() })
      .where("patient_id", "=", patientId)
      .execute();
    await logChartEvent(trx, {
      patientId,
      field: "extraction",
      reason: wasExtracted ? `Undo extraction — tooth ${fdi}` : `Extracted — tooth ${fdi}`,
      date: today,
      userId: session!.userId,
    });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true };
}

export async function saveToothCommentAction(params: { patientId: number; fdi: number; comment: string }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, fdi, comment } = params;
  await ensureChartRow(patientId, session!.userId);
  const chart = await db.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const states = parseToothStates(chart.tooth_states);
  const current = states[fdi] ?? emptyToothState();
  const nextStates = { ...states, [fdi]: { ...current, comment } };

  await db
    .updateTable("orthodontic_charts")
    .set({ tooth_states: JSON.stringify(nextStates), updated_by: session!.userId, updated_at: new Date().toISOString() })
    .where("patient_id", "=", patientId)
    .execute();

  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true };
}

export async function recordStrippingAction(params: { patientId: number; gapId: string }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, gapId } = params;
  await ensureChartRow(patientId, session!.userId);
  const chart = await db.selectFrom("orthodontic_charts").select(["strip_counts"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const counts = parseCounts(chart.strip_counts);
  const today = getClinicToday();

  await db.transaction().execute(async (trx) => {
    const nextCounts = { ...counts, [gapId]: (counts[gapId] ?? 0) + 1 };
    await trx
      .updateTable("orthodontic_charts")
      .set({ strip_counts: JSON.stringify(nextCounts), updated_by: session!.userId, updated_at: new Date().toISOString() })
      .where("patient_id", "=", patientId)
      .execute();
    await logChartEvent(trx, {
      patientId,
      field: "stripping",
      reason: `Stripping — between ${gapId.replace("-", " & ")}`,
      date: today,
      userId: session!.userId,
    });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true };
}

export async function undoStrippingAction(params: { patientId: number; gapId: string }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, gapId } = params;
  const chart = await db.selectFrom("orthodontic_charts").select(["strip_counts"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const counts = parseCounts(chart.strip_counts);
  const current = counts[gapId] ?? 0;
  const today = getClinicToday();

  await db.transaction().execute(async (trx) => {
    const nextCounts = { ...counts };
    if (current <= 1) delete nextCounts[gapId];
    else nextCounts[gapId] = current - 1;
    await trx
      .updateTable("orthodontic_charts")
      .set({ strip_counts: Object.keys(nextCounts).length ? JSON.stringify(nextCounts) : null, updated_by: session!.userId, updated_at: new Date().toISOString() })
      .where("patient_id", "=", patientId)
      .execute();
    await logChartEvent(trx, {
      patientId,
      field: "stripping_undo",
      reason: `Stripping undo — between ${gapId.replace("-", " & ")}`,
      date: today,
      userId: session!.userId,
    });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true };
}

export async function toggleMiniscrewAction(params: { patientId: number; gapId: string }): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, gapId } = params;
  await ensureChartRow(patientId, session!.userId);
  const chart = await db.selectFrom("orthodontic_charts").select(["miniscrews"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };

  const flags = parseFlags(chart.miniscrews);
  const placed = !flags[gapId];
  const today = getClinicToday();

  await db.transaction().execute(async (trx) => {
    const nextFlags = { ...flags, [gapId]: placed };
    await trx
      .updateTable("orthodontic_charts")
      .set({ miniscrews: JSON.stringify(nextFlags), updated_by: session!.userId, updated_at: new Date().toISOString() })
      .where("patient_id", "=", patientId)
      .execute();
    await logChartEvent(trx, {
      patientId,
      field: "miniscrew",
      reason: `Miniscrew ${placed ? "placed" : "removed"} — between ${gapId.replace("-", " & ")}`,
      date: today,
      userId: session!.userId,
    });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true };
}

// --- زيارات الفولو أب --------------------------------------------------------

interface VisitInput {
  patientId: number;
  visitId?: number; // موجود = تعديل زيارة اتحفظت قبل كده، غير موجود = أول حفظ
  date: string;
  service: string;
  upperWireSize: string;
  upperWireType: string;
  lowerWireSize: string;
  lowerWireType: string;
  note: string;
  elasticsDispensed: boolean;
  elasticsSize: string;
  otieColor: string;
  powerChainQty: string;
  buttonsQty: string;
  compressedCoilMm: string;
  upperWireItemId: number | null;
  lowerWireItemId: number | null;
  elasticItemId: number | null;
  otieItemId: number | null;
  /** دفعة 150: لون O-tie الفك التحتاني. null = نفس لون الفوقاني. */
  otieLowerItemId?: number | null;
  /** دفعة 150: أماكن الـ Power chain. العدد بيتحسب منها في السيرفر. */
  powerChains?: unknown;
  powerChainItemId: number | null;
  buttonsItemId: number | null;
  compressedCoilItemId: number | null;
  bondingBracketItemId: number | null;
  bondingBracketBrand: string | null;
  bondingTubeItemId: number | null;
  doctorId: number | null;
  seenByConsultant: boolean;
}

// نفس نطاق قائمة الطبيب في الشارت: عند وجود موعد في تاريخ الزيارة، لا نقبل إلا
// صاحب الموعد أو مساعديه المعرّفين له. لو لا يوجد موعد، تظل كل قائمة الأطباء
// النشطين متاحة لتسجيل زيارة قديمة أو زيارة بدون حجز.
async function allowedOrthoDoctorIds(patientId: number, visitDate: string): Promise<number[]> {
  const appointment = await db
    .selectFrom("appointments")
    .select(["doctor_id"])
    .where("patient_id", "=", patientId)
    .where("appointment_date", "=", visitDate)
    .where("status", "!=", "cancelled")
    .orderBy("start_time", "asc")
    .executeTakeFirst();

  if (!appointment) {
    const activeDoctors = await db.selectFrom("doctors").select("id").where("active", "=", 1).execute();
    return activeDoctors.map((doctor) => doctor.id);
  }

  const appointmentDoctor = await db
    .selectFrom("doctors")
    .select(["id", "is_consultant"])
    .where("id", "=", appointment.doctor_id)
    .where("active", "=", 1)
    .executeTakeFirst();
  if (!appointmentDoctor) return [];
  if (appointmentDoctor.is_consultant !== 1) return [appointmentDoctor.id];

  const assistants = await db
    .selectFrom("consultant_assistants")
    .innerJoin("doctors", "doctors.id", "consultant_assistants.assistant_doctor_id")
    .select("doctors.id")
    .where("consultant_assistants.consultant_doctor_id", "=", appointmentDoctor.id)
    .where("doctors.active", "=", 1)
    .execute();
  return [appointmentDoctor.id, ...assistants.map((assistant) => assistant.id)];
}

async function resolveConsultantSeen(
  patientId: number,
  visitDate: string,
  selectedDoctorId: number,
  requestedSeen: boolean
): Promise<{ seen: number; consultantDoctorId: number | null; reason?: string }> {
  const selectedDoctor = await db
    .selectFrom("doctors")
    .select(["id", "is_consultant"])
    .where("id", "=", selectedDoctorId)
    .where("active", "=", 1)
    .executeTakeFirst();
  if (!selectedDoctor) return { seen: 0, consultantDoctorId: null, reason: "الدكتور المختار غير موجود" };

  // اختيار الاستشاري نفسه في Doctor إثبات كافٍ، لذلك الواجهة تعرض المربع
  // أخضر وغير قابل للتعديل، والسيرفر يفرض نفس القاعدة حتى لو عُدلت البيانات.
  if (selectedDoctor.is_consultant === 1) return { seen: 1, consultantDoctorId: selectedDoctor.id };
  if (!requestedSeen) return { seen: 0, consultantDoctorId: null };

  // لو موعد اليوم على استشاري والطبيب المختار أحد مساعديه، فهذا هو الاستشاري
  // المقصود. وإلا نستخدم الاستشاري المرتبط بالطبيب من إعدادات الأطباء.
  const appointment = await db
    .selectFrom("appointments")
    .innerJoin("doctors", "doctors.id", "appointments.doctor_id")
    .select(["appointments.doctor_id", "doctors.is_consultant"])
    .where("appointments.patient_id", "=", patientId)
    .where("appointments.appointment_date", "=", visitDate)
    .where("appointments.status", "!=", "cancelled")
    .orderBy("appointments.start_time", "asc")
    .executeTakeFirst();
  if (appointment?.is_consultant === 1) {
    const linked = await db
      .selectFrom("consultant_assistants")
      .select("assistant_doctor_id")
      .where("consultant_doctor_id", "=", appointment.doctor_id)
      .where("assistant_doctor_id", "=", selectedDoctorId)
      .executeTakeFirst();
    if (linked) return { seen: 1, consultantDoctorId: appointment.doctor_id };
  }

  const linkedConsultant = await db
    .selectFrom("consultant_assistants")
    .innerJoin("doctors", "doctors.id", "consultant_assistants.consultant_doctor_id")
    .select("doctors.id")
    .where("consultant_assistants.assistant_doctor_id", "=", selectedDoctorId)
    .where("doctors.is_consultant", "=", 1)
    .where("doctors.active", "=", 1)
    .orderBy("doctors.id")
    .executeTakeFirst();
  if (!linkedConsultant) {
    return { seen: 0, consultantDoctorId: null, reason: "اربط الطبيب المختار بالاستشاري من الإعدادات أولاً" };
  }
  return { seen: 1, consultantDoctorId: linkedConsultant.id };
}

export async function saveOrthoVisitAction(input: VisitInput): Promise<ActionResult> {
  const session = await getSession();
  if (!canEditMedicalRecordFor(session?.role)) return { ok: false, reason: "غير مسموح" };

  const { patientId, date } = input;
  if (!patientId || !date) return { ok: false, reason: "بيانات ناقصة" };
  // الدكتور بقى إجباري قبل الحفظ (طلب صريح من المستخدم) — نفس نمط validation
  // الحقيقي في السيرفر، مش بس تعطيل الزرار في الواجهة.
  const selectedDoctorId = input.doctorId;
  if (!selectedDoctorId) return { ok: false, reason: "لازم تختار الدكتور قبل الحفظ" };
  const allowedDoctorIds = await allowedOrthoDoctorIds(patientId, date);
  if (!allowedDoctorIds.includes(selectedDoctorId)) {
    return { ok: false, reason: "الدكتور المختار لا يتبع موعد هذه الزيارة. اختر صاحب الموعد أو أحد مساعديه." };
  }
  const consultantSeen = await resolveConsultantSeen(patientId, date, selectedDoctorId, input.seenByConsultant);
  if (consultantSeen.reason) return { ok: false, reason: consultantSeen.reason };

  // Batch 147: الزيارة الأصلية (لو تعديل) بتتقرا هنا بدري، عشان الخدمة المقفولة
  // (Bonding/Debonding اتطبقوا) تدخل في قاعدة السلك بقيمتها الحقيقية.
  const visitRow = input.visitId
    ? await db.selectFrom("ortho_visits").selectAll().where("id", "=", input.visitId).where("patient_id", "=", patientId).executeTakeFirst()
    : undefined;
  if (input.visitId && !visitRow) return { ok: false, reason: "الزيارة دي مش موجودة" };
  const isEdit = Boolean(visitRow);
  // خدمة الـBonding (ومن دفعة 147 الـDebonding) بتتقفل نهائيًا بمجرد ما
  // تتطبق مرة واحدة — الخدمة المسجلة بتفضل زي ما هي حتى لو القيمة الجديدة
  // مختلفة (دفاع في السيرفر، مش بس الواجهة المقفولة).
  const bondingAlreadyApplied = visitRow?.bonding_applied === 1;
  const debondAlreadyApplied = visitRow?.debond_applied === 1;
  const service = bondingAlreadyApplied || debondAlreadyApplied ? visitRow!.service : input.service;

  // "Same" يوثق استمرار السلك من الزيارة السابقة بلا أي خصم جديد من المخزون.
  const isRealWire = (v: string) => v !== "" && v !== "Same";
  const upperSizeSet = Boolean(input.upperWireItemId) || isRealWire(input.upperWireSize);
  const upperTypeSet = Boolean(input.upperWireItemId) || isRealWire(input.upperWireType);
  const lowerSizeSet = Boolean(input.lowerWireItemId) || isRealWire(input.lowerWireSize);
  const lowerTypeSet = Boolean(input.lowerWireItemId) || isRealWire(input.lowerWireType);
  const upperSame = input.upperWireSize === "Same" && input.upperWireType === "Same";
  const lowerSame = input.lowerWireSize === "Same" && input.lowerWireType === "Same";
  const chartForWire = await db.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
  const wireRule = wireRequirement(parseToothStates(chartForWire?.tooth_states ?? null), service ?? "", date);
  const upperWireRequired = wireRule.upper;
  const lowerWireRequired = wireRule.lower;
  if (
    upperSizeSet !== upperTypeSet || lowerSizeSet !== lowerTypeSet ||
    (upperWireRequired && !upperSizeSet && !upperSame) ||
    (lowerWireRequired && !lowerSizeSet && !lowerSame)
  ) {
    return { ok: false, reason: "اختر wire للفك المتركّب فيه براكتس، أو اختر Same إذا لم يتغير." };
  }

  const selectedIds = Array.from(new Set([
    input.upperWireItemId, input.lowerWireItemId, input.elasticItemId, input.otieItemId, input.otieLowerItemId ?? null,
    input.buttonsItemId, input.compressedCoilItemId,
  ].filter((id): id is number => typeof id === "number" && Number.isInteger(id) && id > 0)));
  const selectedItems = selectedIds.length
    ? await db.selectFrom("inventory_items").select(["id", "name", "ortho_usage", "available_in_clinical_selection"]).where("id", "in", selectedIds).execute()
    : [];
  const stockItem = (id: number | null, usage: string) => {
    if (!id) return null;
    const item = selectedItems.find((candidate) => candidate.id === id && candidate.ortho_usage === usage);
    return item ?? null;
  };
  const upperWire = stockItem(input.upperWireItemId, "wire");
  const lowerWire = stockItem(input.lowerWireItemId, "wire");
  const elastic = stockItem(input.elasticItemId, "elastic");
  const otie = stockItem(input.otieItemId, "otie");
  // دفعة 150: الفك التحتاني ممكن ياخد لون تاني. لو مااتختارش = نفس لون الفوقاني.
  const otieLowerChosen = stockItem(input.otieLowerItemId ?? null, "otie");
  if (input.otieLowerItemId && !otieLowerChosen) return { ok: false, reason: "الصنف المختار لا يطابق استخدامه داخل شارت التقويم. راجع إعداد الصنف في المخزن." };
  const otieLower = otieLowerChosen ?? otie;
  let powerChain: { id: number; name: string; ortho_usage: string | null; available_in_clinical_selection: number } | null = null;
  const buttons = stockItem(input.buttonsItemId, "button");
  const compressedCoil = stockItem(input.compressedCoilItemId, "compressed_coil");
  const bondingBracketBrand = isBracketBrand(input.bondingBracketBrand) ? input.bondingBracketBrand : null;
  if ((input.upperWireItemId && !upperWire) || (input.lowerWireItemId && !lowerWire) || (input.elasticItemId && !elastic) || (input.otieItemId && !otie) || (input.buttonsItemId && !buttons) || (input.compressedCoilItemId && !compressedCoil)) {
    return { ok: false, reason: "الصنف المختار لا يطابق استخدامه داخل شارت التقويم. راجع إعداد الصنف في المخزن." };
  }
  if (selectedItems.some((item) => item.available_in_clinical_selection !== 1)) return { ok: false, reason: "أحد الأصناف المختارة غير متاح حالياً للاستخدام الطبي." };
  if (input.elasticsDispensed && !elastic) return { ok: false, reason: "اختر خامة الـ Elastics من المخزن." };
  if (input.otieColor && !otie) return { ok: false, reason: "اختر خامة الـ O-tie من المخزن." };
  // دفعة 150: الـ Power chain بأماكنه. العدد = عدد الأسنان في كل سلسلة، ولونها
  // = لون O-tie الفك بتاعها، وصنف المخزن بيتحدد من اللون. لو اللون مالوش صنف
  // Power chain في المخزن: الزيارة بتتحفظ عادي والسلسلة بتتعلّم "متخصمتش"
  // (قرار صاحب العيادة: متوقفش الحفظ). وقبل كده كان بيرفض الحفظ.
  const normalized = normalizeChains(input.powerChains);
  if (!normalized.ok) return { ok: false, reason: normalized.reason };
  const chainInputs: PowerChainInput[] = normalized.chains;
  const legacyPowerChainQty = chainInputs.length === 0 ? Math.max(0, parseInt(input.powerChainQty, 10) || 0) : 0;
  type ChainStock = { id: number; name: string; ortho_usage: string | null; available_in_clinical_selection: number } | null;
  const chainStockByArch: Record<"upper" | "lower", { item: ChainStock; color: string | null }> = { upper: { item: null, color: null }, lower: { item: null, color: null } };
  const resolveChainStock = async (archOtie: typeof otie): Promise<{ item: ChainStock; color: string | null }> => {
    if (!archOtie) return { item: null, color: null };
    const color = elastomericColorForItemName(archOtie.name);
    if (!color) return { item: null, color: null };
    const canonicalName = elastomericItemName("Power chain", color);
    const item = await db
      .selectFrom("inventory_items")
      .select(["id", "name", "ortho_usage", "available_in_clinical_selection"])
      .where("ortho_usage", "=", "power_chain")
      .where((eb) => eb.or([eb("name", "=", canonicalName), eb("name", "=", `Power chain — ${color.name}`)]))
      .executeTakeFirst() ?? null;
    return { item: item && item.available_in_clinical_selection === 1 ? item : null, color: color.name };
  };
  for (const arch of ["upper", "lower"] as const) {
    if (!chainInputs.some((chain) => chain.arch === arch)) continue;
    const archOtie = arch === "upper" ? otie : otieLower;
    if (!archOtie) return { ok: false, reason: `Select the ${arch} O-tie colour first — the power chain follows it.` };
    chainStockByArch[arch] = await resolveChainStock(archOtie);
  }
  const savedChains: PowerChainSaved[] = chainInputs.map((chain) => {
    const stock = chainStockByArch[chain.arch];
    return { ...chain, qty: chainQty(chain), itemId: stock.item?.id ?? null, deducted: Boolean(stock.item), color: stock.color };
  });
  if (legacyPowerChainQty > 0 && otie) {
    // تاب قديم مفتوح قبل النشر (بيبعت عدد من غير أماكن): نفس سلوك 149 بس من غير ما نوقف الحفظ.
    powerChain = (await resolveChainStock(otie)).item;
  } else if (savedChains.length > 0) {
    powerChain = savedChains.find((chain) => chain.itemId != null) ? chainStockByArch[savedChains.find((chain) => chain.itemId != null)!.arch].item : null;
  }
  const totalPowerChainQty = savedChains.length > 0 ? savedChains.reduce((sum, chain) => sum + chain.qty, 0) : legacyPowerChainQty;
  const notDeductedChains = savedChains.filter((chain) => !chain.deducted);
  if (Number(input.buttonsQty) > 0 && !buttons) return { ok: false, reason: "اختر خامة الـ Buttons من المخزن." };
  if (Number(input.compressedCoilMm) > 0 && !compressedCoil) return { ok: false, reason: "اختر خامة الـ Compressed coil من المخزن." };

  if (isEdit) {
    const canEditAfterSave = await hasPermission(session!.userId, session!.role as Role, "edit_ortho_visit_after_save");
    // كل الفريق يستطيع تصحيح زيارة اليوم نفسه؛ أما الزيارات الأقدم فتظل
    // محكومة بصلاحية تعديل الزيارة بعد الحفظ.
    const isSameClinicDay = visitRow!.visit_date === getClinicToday();
    if (!isSameClinicDay && !canEditAfterSave) return { ok: false, reason: "محتاج صلاحية تعديل الزيارة بعد الحفظ" };
  }

  const willTriggerDebond = !debondAlreadyApplied && !bondingAlreadyApplied && service === "Debonding";
  const willTriggerBonding = !bondingAlreadyApplied && (service === "Bonding Upper" || service === "Bonding Lower");
  if (willTriggerBonding && !bondingBracketBrand) {
    return { ok: false, reason: "عند تسجيل Bonding اختر شركة البراكتس." };
  }

  const result = await db.transaction().execute(async (trx) => {
    let visitId: number;

    if (isEdit) {
      // إعادة حفظ بعد Edit: نرجع الرصيد الذي خُصم من الزيارة أولاً، ثم نستبدل
      // الخصومات بالقيم الجديدة. حذف السجل وحده كان يترك الرصيد ناقصًا.
      const previousDeductions = await trx
        .selectFrom("ortho_inventory_deductions")
        .select(["id", "item_id", "qty", "label"])
        .where("visit_id", "=", visitRow!.id)
        .where("undone_at", "is", null)
        .execute();
      // تعديل زيارة Bonding لا يجب أن يرجع كومبوزيت التركيب ثم ينسى خصمه
      // مرة أخرى، لأن تركيب الأسنان نفسه مقفول بعد أول حفظ. نحتفظ بسطره حتى
      // حذف الزيارة فعلاً (وقتها يرجع مع كل خصومات الزيارة بشكل صحيح).
      const deductionsToReplace = bondingAlreadyApplied
        ? previousDeductions.filter((deduction) => deduction.label !== "Orthodontic composite")
        : previousDeductions;
      for (const deduction of deductionsToReplace) {
        if (deduction.item_id) await returnInventoryItem(trx, { itemId: deduction.item_id, quantity: deduction.qty, note: "تعديل زيارة تقويم", createdBy: session!.userId });
      }
      if (deductionsToReplace.length > 0) {
        await trx.deleteFrom("ortho_inventory_deductions").where("id", "in", deductionsToReplace.map((deduction) => deduction.id)).execute();
      }
      await trx
        .updateTable("ortho_visits")
        .set({
          visit_date: input.date,
          service,
          upper_wire_size: (upperWire?.name ?? input.upperWireSize) || null,
          upper_wire_type: upperWire ? null : (input.upperWireType || null),
          lower_wire_size: (lowerWire?.name ?? input.lowerWireSize) || null,
          lower_wire_type: lowerWire ? null : (input.lowerWireType || null),
          note: input.note || null,
          elastics_dispensed: input.elasticsDispensed ? 1 : 0,
          elastics_size: input.elasticsDispensed ? ((elastic?.name ?? input.elasticsSize) || null) : null,
          otie_color: (otie?.name ?? input.otieColor) || null,
          power_chain_qty: totalPowerChainQty > 0 ? totalPowerChainQty : null,
          buttons_qty: input.buttonsQty ? Number(input.buttonsQty) : null,
          compressed_coil_mm: input.compressedCoilMm ? Number(input.compressedCoilMm) : null,
          upper_wire_item_id: upperWire?.id ?? null,
          lower_wire_item_id: lowerWire?.id ?? null,
          elastic_item_id: elastic?.id ?? null,
          otie_item_id: otie?.id ?? null,
          otie_lower_item_id: otieLowerChosen && otieLowerChosen.id !== otie?.id ? otieLowerChosen.id : null,
          otie_lower_color: otieLowerChosen && otieLowerChosen.id !== otie?.id ? otieLowerChosen.name : null,
          power_chains: savedChains.length > 0 ? JSON.stringify(savedChains) : null,
          power_chain_item_id: powerChain?.id ?? null,
          buttons_item_id: buttons?.id ?? null,
          compressed_coil_item_id: compressedCoil?.id ?? null,
          bonding_bracket_item_id: visitRow!.bonding_bracket_item_id,
          bonding_bracket_brand: bondingBracketBrand ?? visitRow!.bonding_bracket_brand,
          bonding_tube_item_id: visitRow!.bonding_tube_item_id,
          doctor_id: input.doctorId,
          seen_by_consultant: consultantSeen.seen,
          consultant_doctor_id: consultantSeen.consultantDoctorId,
          bonding_applied: bondingAlreadyApplied ? 1 : willTriggerBonding ? 1 : 0,
          updated_by: session!.userId,
          updated_at: new Date().toISOString(),
        })
        .where("id", "=", visitRow!.id)
        .execute();
      visitId = visitRow!.id;
    } else {
      const inserted = await trx
        .insertInto("ortho_visits")
        .values({
          patient_id: patientId,
          visit_date: input.date,
          service,
          upper_wire_size: (upperWire?.name ?? input.upperWireSize) || null,
          upper_wire_type: upperWire ? null : (input.upperWireType || null),
          lower_wire_size: (lowerWire?.name ?? input.lowerWireSize) || null,
          lower_wire_type: lowerWire ? null : (input.lowerWireType || null),
          note: input.note || null,
          elastics_dispensed: input.elasticsDispensed ? 1 : 0,
          elastics_size: input.elasticsDispensed ? ((elastic?.name ?? input.elasticsSize) || null) : null,
          otie_color: (otie?.name ?? input.otieColor) || null,
          power_chain_qty: totalPowerChainQty > 0 ? totalPowerChainQty : null,
          buttons_qty: input.buttonsQty ? Number(input.buttonsQty) : null,
          compressed_coil_mm: input.compressedCoilMm ? Number(input.compressedCoilMm) : null,
          upper_wire_item_id: upperWire?.id ?? null,
          lower_wire_item_id: lowerWire?.id ?? null,
          elastic_item_id: elastic?.id ?? null,
          otie_item_id: otie?.id ?? null,
          otie_lower_item_id: otieLowerChosen && otieLowerChosen.id !== otie?.id ? otieLowerChosen.id : null,
          otie_lower_color: otieLowerChosen && otieLowerChosen.id !== otie?.id ? otieLowerChosen.name : null,
          power_chains: savedChains.length > 0 ? JSON.stringify(savedChains) : null,
          power_chain_item_id: powerChain?.id ?? null,
          buttons_item_id: buttons?.id ?? null,
          compressed_coil_item_id: compressedCoil?.id ?? null,
          bonding_bracket_item_id: null,
          bonding_bracket_brand: bondingBracketBrand,
          bonding_tube_item_id: null,
          doctor_id: input.doctorId,
          seen_by_consultant: consultantSeen.seen,
          consultant_doctor_id: consultantSeen.consultantDoctorId,
          bonding_applied: willTriggerBonding ? 1 : 0,
          created_by: session!.userId,
          updated_by: session!.userId,
        })
        .returning(["id"])
        .executeTakeFirstOrThrow();
      visitId = inserted.id;
    }

    // Batch 147: Debonding = فك براكتس الفكين من الشارت (زي ما Bonding بيركّب).
    // قبل كده كان اسم بس، والسنان بتفضل "متركّبة" — فتقرير المتابعة المتأخرة
    // كان شايف المريض لسه في العلاج. اللقطة debond_snapshot = حالة السنان قبل
    // الفك بالظبط، عشان حذف الزيارة يرجّعها. بيحصل قبل خصم الـO-tie تحت، فعدد
    // البراكتس بيبقى صفر ومفيش O-tie بيتخصم في زيارة الفك.
    if (willTriggerDebond) {
      const chart = await trx.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
      const rawBefore = chart?.tooth_states ?? "{}";
      const states = parseToothStates(rawBefore);
      const nextStates: Record<string, ToothState> = { ...states };
      const removed: number[] = [];
      for (const tooth of ALL_TEETH) {
        const current = states[tooth.fdi];
        if (current && (current.bracket === "bonded" || current.bracket === "broken")) {
          nextStates[tooth.fdi] = { ...current, bracket: "none", debondDate: input.date };
          removed.push(tooth.fdi);
        }
      }
      if (chart && removed.length > 0) {
        await trx
          .updateTable("orthodontic_charts")
          .set({ tooth_states: JSON.stringify(nextStates), updated_by: session!.userId, updated_at: new Date().toISOString() })
          .where("patient_id", "=", patientId)
          .execute();
      }
      await trx.updateTable("ortho_visits").set({ debond_applied: 1, debond_snapshot: rawBefore }).where("id", "=", visitId).execute();
      await logChartEvent(trx, {
        patientId,
        field: "debond_all",
        reason: removed.length > 0 ? `Debonding — both arches (${removed.join(", ")})` : "Debonding — no bonded teeth on the chart",
        date: input.date,
        userId: session!.userId,
      });
    }

    if (willTriggerBonding) {
      const arch = service === "Bonding Upper" ? "upper" : "lower";
      const chart = await trx.selectFrom("orthodontic_charts").select(["tooth_states"]).where("patient_id", "=", patientId).executeTakeFirst();
      const states = parseToothStates(chart?.tooth_states ?? null);
      const row = arch === "upper" ? UPPER_ROW : LOWER_ROW;
      const targets = row.filter((t) => t.position <= 6 && !(states[t.fdi]?.extracted ?? false));
      if (targets.length > 0) {
        const nextStates = { ...states };
        targets.forEach((t) => {
          const current = nextStates[t.fdi] ?? emptyToothState();
          nextStates[t.fdi] = { ...current, bracket: "bonded", debondDate: null, bondedDate: input.date };
        });
        // ensureChartRow() itself queries via the module-level `db`, not `trx` — fine
        // functionally (same underlying connection), but calling it from inside an
        // already-open transaction is a correctness smell worth avoiding, so this one
        // spot does the same "insert row if missing" check directly on `trx` instead.
        const existingChart = await trx.selectFrom("orthodontic_charts").select(["id"]).where("patient_id", "=", patientId).executeTakeFirst();
        if (!existingChart) {
          await trx.insertInto("orthodontic_charts").values({ patient_id: patientId, created_by: session!.userId, updated_by: session!.userId }).execute();
        }
        await trx
          .updateTable("orthodontic_charts")
          .set({ tooth_states: JSON.stringify(nextStates), updated_by: session!.userId, updated_at: new Date().toISOString() })
          .where("patient_id", "=", patientId)
          .execute();

        const archLabel = arch === "upper" ? "Upper" : "Lower";
        const bracketTargets = targets.filter((t) => !isMolarPosition(t.position));
        const tubeTargets = targets.filter((t) => isMolarPosition(t.position));
        if (bracketTargets.length > 0) {
          await deductInventory(trx, {
            patientId,
            visitId: null,
            label: `${bondingBracketBrand} brackets`,
            qty: bracketTargets.length,
            teeth: bracketTargets.map((t) => t.fdi),
            date: input.date,
            userId: session!.userId,
          });
          for (const tooth of bracketTargets) await deductBracketTooth(trx, { brand: bondingBracketBrand!, fdi: tooth.fdi, patientId, visitId, date: input.date, createdBy: session!.userId, note: `Bonding ${archLabel}` });
        }
        if (tubeTargets.length > 0) {
          for (const tooth of tubeTargets) await deductTubeTooth(trx, { fdi: tooth.fdi, patientId, visitId, createdBy: session!.userId, note: `Bonding ${archLabel}` });
        }
        await deductOrthodonticComposite(trx, {
          patientId,
          visitId,
          attachmentCount: targets.length,
          teeth: targets.map((tooth) => tooth.fdi),
          date: input.date,
          userId: session!.userId,
        });
        await logChartEvent(trx, {
          patientId,
          field: "bulk_bond",
          reason: `Bulk bond — ${archLabel} arch (${targets.map((t) => t.fdi).join(", ")})`,
          date: input.date,
          userId: session!.userId,
        });
      }
    }

    if (upperWire) {
      await deductInventory(trx, {
        patientId,
        visitId,
        label: upperWire.name,
        itemId: upperWire.id,
        qty: 1,
        date: input.date,
        userId: session!.userId,
      });
    }
    if (lowerWire) {
      await deductInventory(trx, {
        patientId,
        visitId,
        label: lowerWire.name,
        itemId: lowerWire.id,
        qty: 1,
        date: input.date,
        userId: session!.userId,
      });
    }
    if (input.elasticsDispensed && elastic) {
      await deductInventory(trx, { patientId, visitId, label: elastic.name, itemId: elastic.id, qty: 1, date: input.date, userId: session!.userId });
    }
    const powerChainQty = totalPowerChainQty;
    if (savedChains.length === 0) {
      // زيارة من غير أماكن سلاسل (أو تاب قديم): نفس حساب 149 بالظبط على لون واحد.
      const bondedBrackets = await activeBondedBracketCount(trx, patientId);
      const otieQty = Math.max(0, bondedBrackets - legacyPowerChainQty);
      const bondedTeeth = otieLowerChosen && otie && otieLowerChosen.id !== otie.id ? await activeBondedBracketTeeth(trx, patientId) : null;
      if (bondedTeeth) {
        // لونين ومن غير سلاسل: كل فك من لونه.
        for (const [arch, item] of [["upper", otie], ["lower", otieLowerChosen]] as const) {
          const qty = otieQtyForArch(arch, bondedTeeth, []);
          if (item && qty > 0) await deductInventory(trx, { patientId, visitId, label: item.name, itemId: item.id, qty, date: input.date, userId: session!.userId });
        }
      } else if (otie && otieQty > 0) {
        await deductInventory(trx, { patientId, visitId, label: otie.name, itemId: otie.id, qty: otieQty, date: input.date, userId: session!.userId });
      }
      if (legacyPowerChainQty > 0 && powerChain) {
        await deductInventory(trx, { patientId, visitId, label: powerChain.name, itemId: powerChain.id, qty: legacyPowerChainQty, date: input.date, userId: session!.userId });
      }
    } else {
      // دفعة 150: كل فك بلونه، والأسنان اللي عليها سلسلة على البراكتس مالهاش O-tie.
      const bondedTeeth = await activeBondedBracketTeeth(trx, patientId);
      for (const [arch, item] of [["upper", otie], ["lower", otieLower]] as const) {
        const qty = otieQtyForArch(arch, bondedTeeth, chainInputs);
        if (item && qty > 0) await deductInventory(trx, { patientId, visitId, label: item.name, itemId: item.id, qty, date: input.date, userId: session!.userId });
      }
      for (const chain of savedChains) {
        const stock = chainStockByArch[chain.arch].item;
        if (chain.deducted && stock) await deductInventory(trx, { patientId, visitId, label: stock.name, itemId: stock.id, qty: chain.qty, date: input.date, userId: session!.userId });
      }
    }
    const buttonsQty = parseInt(input.buttonsQty, 10);
    if (buttonsQty > 0 && buttons) {
      await deductInventory(trx, { patientId, visitId, label: buttons.name, itemId: buttons.id, qty: buttonsQty, date: input.date, userId: session!.userId });
    }
    const coilMm = parseInt(input.compressedCoilMm, 10);
    if (coilMm > 0 && compressedCoil) {
      await deductInventory(trx, { patientId, visitId, label: compressedCoil.name, itemId: compressedCoil.id, qty: coilMm, date: input.date, userId: session!.userId });
    }

    // دفعة 27 (P2.4): مزامنة المعالجة لحقل notes في الزيارة المقابلة بالملف
    // الطبي العادي. الربط ثابت برقم زيارة التقويم، لذلك تعديل تاريخها ينقل
    // سطرها نفسه فقط ولا يلمس أي زيارة قديمة أخرى في الملف الطبي.
    const paragraph = buildOrthoTreatmentParagraph({
      service,
      upperWireSize: input.upperWireSize || null,
      upperWireType: input.upperWireType || null,
      lowerWireSize: input.lowerWireSize || null,
      lowerWireType: input.lowerWireType || null,
      elastics: input.elasticsDispensed ? (elastic?.name ?? input.elasticsSize) || null : null,
      otie: (otie?.name ?? input.otieColor) || null,
      powerChainQty,
      buttonsQty: Number.isFinite(buttonsQty) ? buttonsQty : null,
      compressedCoilMm: Number.isFinite(coilMm) ? coilMm : null,
      note: input.note || null,
    });
    await syncOrthoNoteToMedicalVisit(trx, {
      patientId,
      orthoVisitId: visitId,
      visitDate: input.date,
      paragraph,
      performingDoctorId: selectedDoctorId,
    });

    return visitId;
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  revalidatePath(`/patients/${patientId}`);
  revalidatePath("/inventory");
  const warning = notDeductedChains.length > 0
    ? `Saved. Power chain not deducted from stock (no "Power chain — ${[...new Set(notDeductedChains.map((chain) => chain.color ?? "?"))].join(" / ")}" item).`
    : undefined;
  return { ok: true, visitId: result, warning };
}

export async function undoOrthoInventoryDeductionAction(params: { patientId: number; deductionId: number }): Promise<ActionResult> {
  const session = await getSession();
  if (!session) return { ok: false, reason: "غير مسموح" };
  const canUndo = await hasPermission(session.userId, session.role as Role, "undo_ortho_inventory_deduction");
  if (!canUndo) return { ok: false, reason: "محتاج صلاحية Undo المخزون" };

  const { patientId, deductionId } = params;
  const row = await db
    .selectFrom("ortho_inventory_deductions")
    .selectAll()
    .where("id", "=", deductionId)
    .where("patient_id", "=", patientId)
    .executeTakeFirst();
  if (!row) return { ok: false, reason: "الخصم ده مش موجود" };
  if (row.undone_at) return { ok: false, reason: "اتعمله Undo بالفعل" };

  await db.transaction().execute(async (trx) => {
    await trx
      .updateTable("ortho_inventory_deductions")
      .set({ undone_by: session.userId, undone_at: new Date().toISOString() })
      .where("id", "=", deductionId)
      .execute();
    if (row.item_id) await returnInventoryItem(trx, { itemId: row.item_id, quantity: row.qty, note: "Undo خصم شارت التقويم", createdBy: session.userId });
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  revalidatePath("/inventory");
  return { ok: true };
}

// --- Batch 147: إلغاء/تعديل تركيب فك من بادج Upper/Lower bonding -------------
// السبب: استيراد البيانات التاريخية علّم بعض المرضى إنهم مركّبين فكين وهم فك
// واحد، ومكانش فيه طريقة تصلّح غير سنة سنة. الاتنين بصلاحية undo_ortho_bonding
// (أدمن بس افتراضيًا)، ومخصوصين للتركيب اللي مالوش زيارة Bonding في السيستم —
// اللي جه من زيارة بيتلغي بحذف الزيارة نفسها (بترجّع البراكتس والكومبوزيت
// للمخزن). الاتنين مابيلمسوش المخزن خالص.

async function bondingVisitForArch(patientId: number, arch: "upper" | "lower") {
  return db
    .selectFrom("ortho_visits")
    .select(["id", "visit_date"])
    .where("patient_id", "=", patientId)
    .where("bonding_applied", "=", 1)
    .where("service", "=", arch === "upper" ? "Bonding Upper" : "Bonding Lower")
    .orderBy("visit_date", "desc")
    .executeTakeFirst();
}

export async function undoArchBondingAction(params: { patientId: number; arch: "upper" | "lower" }): Promise<ActionResult> {
  const session = await getSession();
  if (!session) return { ok: false, reason: "غير مسموح" };
  if (!(await hasPermission(session.userId, session.role as Role, "undo_ortho_bonding"))) return { ok: false, reason: "محتاج صلاحية إلغاء/تعديل تركيب فك التقويم" };
  const { patientId, arch } = params;
  if (!Number.isInteger(patientId) || patientId <= 0 || (arch !== "upper" && arch !== "lower")) return { ok: false, reason: "بيانات ناقصة" };

  const visit = await bondingVisitForArch(patientId, arch);
  if (visit) return { ok: false, reason: `تركيب الفك ده جه من زيارة Bonding بتاريخ ${visit.visit_date}. امسح الزيارة دي بدل كده (بترجّع البراكتس للمخزن).` };

  const chart = await db.selectFrom("orthodontic_charts").select(["tooth_states", "bonding_upper_date", "bonding_lower_date"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };
  const states = parseToothStates(chart.tooth_states);
  const row = arch === "upper" ? UPPER_ROW : LOWER_ROW;
  const nextStates: Record<string, ToothState> = { ...states };
  const cleared: number[] = [];
  for (const tooth of row) {
    const current = states[tooth.fdi];
    if (current && (current.bracket === "bonded" || current.bracket === "broken")) {
      nextStates[tooth.fdi] = { ...current, bracket: "none", bondedDate: null, debondDate: null, rebondCount: 0 };
      cleared.push(tooth.fdi);
    }
  }
  const hadDate = arch === "upper" ? chart.bonding_upper_date : chart.bonding_lower_date;
  if (cleared.length === 0 && !hadDate) return { ok: false, reason: "الفك ده مفيهوش تركيب أصلاً" };
  const archLabel = arch === "upper" ? "Upper" : "Lower";
  const today = getClinicToday();

  await db.transaction().execute(async (trx) => {
    await trx
      .updateTable("orthodontic_charts")
      .set({
        tooth_states: JSON.stringify(nextStates),
        ...(arch === "upper" ? { bonding_upper_date: null } : { bonding_lower_date: null }),
        updated_by: session.userId,
        updated_at: new Date().toISOString(),
      })
      .where("patient_id", "=", patientId)
      .execute();
    await logChartEvent(trx, {
      patientId,
      field: "undo_bonding",
      reason: `Undo bonding — ${archLabel} arch${cleared.length ? ` (${cleared.join(", ")})` : ""} — no inventory change`,
      date: today,
      userId: session.userId,
    });
  });
  // برة الترانزاكشن عن قصد (batch 108).
  await logAdminEvent({
    entityType: "orthodontic_chart",
    entityId: patientId,
    event: "undo_ortho_bonding",
    details: `إلغاء تركيب الفك ${arch === "upper" ? "العلوي" : "السفلي"} للمريض رقم ${patientId} (${cleared.length} سن) — بدون أي تغيير في المخزن`,
    changedBy: session.userId,
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true, cleared: cleared.length };
}

export async function changeArchBondingDateAction(params: { patientId: number; arch: "upper" | "lower"; date: string }): Promise<ActionResult> {
  const session = await getSession();
  if (!session) return { ok: false, reason: "غير مسموح" };
  if (!(await hasPermission(session.userId, session.role as Role, "undo_ortho_bonding"))) return { ok: false, reason: "محتاج صلاحية إلغاء/تعديل تركيب فك التقويم" };
  const { patientId, arch, date } = params;
  if (!Number.isInteger(patientId) || patientId <= 0 || (arch !== "upper" && arch !== "lower")) return { ok: false, reason: "بيانات ناقصة" };
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(Date.parse(date))) return { ok: false, reason: "التاريخ غير صحيح" };
  if (date > getClinicToday()) return { ok: false, reason: "التاريخ مايبقاش في المستقبل" };

  const visit = await bondingVisitForArch(patientId, arch);
  if (visit) return { ok: false, reason: `تركيب الفك ده جه من زيارة Bonding بتاريخ ${visit.visit_date} — تاريخه هو تاريخ الزيارة.` };

  const chart = await db.selectFrom("orthodontic_charts").select(["tooth_states", "bonding_upper_date", "bonding_lower_date"]).where("patient_id", "=", patientId).executeTakeFirst();
  if (!chart) return { ok: false, reason: "مفيش شارت للمريض ده" };
  const states = parseToothStates(chart.tooth_states);
  const row = arch === "upper" ? UPPER_ROW : LOWER_ROW;
  const columnDate = (arch === "upper" ? chart.bonding_upper_date : chart.bonding_lower_date)?.slice(0, 10) ?? null;
  const toothDates = row.map((tooth) => states[tooth.fdi]?.bondedDate?.slice(0, 10)).filter((d): d is string => Boolean(d)).sort();
  const oldDate = columnDate ?? toothDates[0] ?? null;
  const hasBrackets = row.some((tooth) => states[tooth.fdi]?.bracket === "bonded" || states[tooth.fdi]?.bracket === "broken");
  if (!oldDate && !hasBrackets) return { ok: false, reason: "الفك ده مفيهوش تركيب أصلاً" };

  // السنان اللي اتركّبت في نفس يوم تركيب الفك (أو مالهاش تاريخ) بس — سن اتعمله
  // Rebond بعدين يفضل بتاريخه.
  const nextStates: Record<string, ToothState> = { ...states };
  let moved = 0;
  for (const tooth of row) {
    const current = states[tooth.fdi];
    if (!current || (current.bracket !== "bonded" && current.bracket !== "broken")) continue;
    const own = current.bondedDate?.slice(0, 10) ?? null;
    if (own === null || own === oldDate) {
      nextStates[tooth.fdi] = { ...current, bondedDate: date };
      moved++;
    }
  }
  const archLabel = arch === "upper" ? "Upper" : "Lower";

  await db.transaction().execute(async (trx) => {
    await trx
      .updateTable("orthodontic_charts")
      .set({
        tooth_states: JSON.stringify(nextStates),
        ...(arch === "upper" ? { bonding_upper_date: date } : { bonding_lower_date: date }),
        updated_by: session.userId,
        updated_at: new Date().toISOString(),
      })
      .where("patient_id", "=", patientId)
      .execute();
    await logChartEvent(trx, {
      patientId,
      field: "bonding_date",
      reason: `${archLabel} bonding date changed ${oldDate ?? "—"} → ${date}`,
      date: getClinicToday(),
      userId: session.userId,
    });
  });
  await logAdminEvent({
    entityType: "orthodontic_chart",
    entityId: patientId,
    event: "change_ortho_bonding_date",
    details: `تعديل تاريخ تركيب الفك ${arch === "upper" ? "العلوي" : "السفلي"} للمريض رقم ${patientId}: ${oldDate ?? "—"} ← ${date} (${moved} سن)`,
    changedBy: session.userId,
  });

  revalidatePath(`/patients/${patientId}/orthodontics`);
  return { ok: true, moved };
}
