"use client";

// ===================================================================
// شارت التقويم v2 — صفحة 1 كاملة (النسخة الحقيقية، دمج 2026-08-27)
// ===================================================================
// نفس التصميم اللي المستخدم راجعه ووافق عليه في البروتوتايب المعزول
// (design_id Canva: DAHTZKEWWQI) — الفرق إن كل حاجة دلوقتي مربوطة بقاعدة
// البيانات الحقيقية للمريض: أعلى الصفحة + Treatment Plan فورم واحد
// (saveOrthoTopSectionAction)، الصور والأشعة بتستخدم نفس الداتا/actions
// الحقيقية اللي في ملف المريض العادي (addImageGroupAction/deleteImageAction)
// لكن من خلال عرض إنجليزي/LTR مستقل (OrthoImageGallery/OrthoAddImageGroupForm)
// بدل مكون المريض العادي العربي/RTL — الشارت ده المفروض يفضل إنجليزي طول
// الوقت مهما كانت لغة باقي السيستم (طلب صريح من المستخدم بعد أول نشر حقيقي،
// راجع claude/orthodontic-chart-v2-preview-status.md تحديث 12). والـInventory
// list/Interactive report بيقروا من ortho_inventory_deductions/audit_log الحقيقيين.

import { useEffect, useRef, useState, useMemo, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import InteractiveToothChart, { type GapMode, type ToothState } from "./InteractiveToothChart";
import DiagnosticChart, { type DiagnosticChartData } from "./DiagnosticChart";
import FollowUpsTable, { type OrthoDoctorOption, type OrthoOptionLists, type OrthoVisitRow, type OrthoStockItem } from "./FollowUpsTable";
import OrthoImageGallery from "./OrthoImageGallery";
import PatientAvatar from "@/components/PatientAvatar";
import OrthoAddImageGroupForm from "./OrthoAddImageGroupForm";
import { saveOrthoChartSummaryAction, saveOrthoTopSectionAction, undoOrthoInventoryDeductionAction } from "@/app/patients/[id]/orthodontics/ortho-v2-actions";
import { UPPER_ROW, LOWER_ROW } from "@/lib/ortho/fdi-teeth";
import { elastomericColorForItemName } from "@/lib/ortho/elastomeric-colors";
import { formatNoteLines } from "@/lib/format-notes";
import { chainLabel, chainTeeth } from "@/lib/ortho/power-chain";

const MOCK_BRACKET_TYPES = ["American", "Ormco", "3M"];
const PRESCRIPTION_OPTIONS = ["Roth", "MBT", "Andrews"];
const SLOT_OPTIONS = ["18", "22"];
const POSITIONS = ["1", "2", "3", "4", "5", "6", "7", "8"];

type ChartView = "interactive" | "diagnostic";
type SummaryField = "chief_complaint" | "treatment_note" | "diagnosis_summary";

interface ExtractionState {
  ur: string;
  ul: string;
  lr: string;
  ll: string;
}

export interface InventoryLogEntry {
  id: number;
  label: string;
  qty: number;
  teeth: number[] | null;
  date: string;
  undoneAt: string | null;
}

export interface ChartEventEntry {
  id: number;
  date: string;
  text: string;
}

export interface ImageGroupWithFiles {
  id: number;
  label: string | null;
  taken_at: string;
  images: { id: number; file_path: string; rotation: number; image_kind?: string | null; content_hash?: string | null }[];
}

function Dropdown({
  name,
  defaultValue,
  options,
  placeholder = "—",
  disabled,
  form,
}: {
  name: string;
  defaultValue: string | null;
  options: string[];
  placeholder?: string;
  disabled?: boolean;
  form?: string;
}) {
  return (
    <select name={name} form={form} defaultValue={defaultValue ?? ""} disabled={disabled} className="rounded-md border border-border bg-background px-2 py-1 text-xs disabled:opacity-60">
      <option value="">{placeholder}</option>
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  );
}

export default function OrthoChartV2({
  patientId,
  patientName,
  avatarPath = null,
  fileNumber,
  patientAge,
  patientPhone,
  editable,
  canEditAfterSave,
  canUndoInventory,
  defaultDoctorId,
  doctors,
  stockItems,
  activeBracketCount,
  unlinkedBracketCountToday,
  options,
  chart,
  toothStates,
  stripCounts,
  miniscrews,
  diagnostic,
  visits,
  inventoryLog,
  chartEvents,
  imageGroups,
  needsNewPhotos,
  needsConsultantVisit,
  consultantName,
  consultantReminderMonths,
  lastPhotoTakenAt,
  photoReminderMonths,
  canUploadPhotos,
  canDeleteVisit,
  canManageBonding,
  purposeContext,
  defaultVisitService = null,
  upperBulkBondingDate,
  lowerBulkBondingDate,
  summaryOptions,
}: {
  patientId: number;
  patientName: string;
  /** Batch 125: صورة ملف المريض المقصوصة تلقائيًا من صورة وش أمامية (لو موجودة). */
  avatarPath?: string | null;
  fileNumber: string;
  patientAge: number | null;
  patientPhone: string | null;
  editable: boolean;
  canEditAfterSave: boolean;
  canUndoInventory: boolean;
  defaultDoctorId: number | null;
  doctors: OrthoDoctorOption[];
  stockItems: OrthoStockItem[];
  activeBracketCount: number;
  unlinkedBracketCountToday: number;
  options: OrthoOptionLists & { anchorageDevices: string[] };
  chart: {
    bracket_type: string | null;
    prescription: string | null;
    slot: string | null;
    chief_complaint: string | null;
    extraction_quadrants: ExtractionState | null;
    anchorage_device: string | null;
    treatment_note: string | null;
    diagnosis_summary: string | null;
  };
  toothStates: Record<number, ToothState>;
  stripCounts: Record<string, number>;
  miniscrews: Record<string, boolean>;
  diagnostic: DiagnosticChartData;
  visits: OrthoVisitRow[];
  inventoryLog: InventoryLogEntry[];
  chartEvents: ChartEventEntry[];
  imageGroups: ImageGroupWithFiles[];
  needsNewPhotos: boolean;
  needsConsultantVisit: boolean;
  consultantName: string | null;
  consultantReminderMonths: number;
  lastPhotoTakenAt: string | null;
  photoReminderMonths: number;
  // صلاحية "رفع صور فقط" (upload_ortho_photos) — بتديله دخول لقسم الصور بس،
  // بدل ما يتقيّد بالـeditable الكامل بتاع باقي الشارت. الاستقبال افتراضيًا.
  canUploadPhotos: boolean;
  // نفس صلاحية delete_visits بتاعة الملف الطبي العادي — دفعة 27.
  canDeleteVisit: boolean;
  // Batch 147: undo_ortho_bonding — قايمة بادج Upper/Lower bonding.
  canManageBonding: boolean;
  // دفعة 27 (P3.2): سياق "متابعة: <اسم الخدمة>" لو موعد المريض النهاردة اتربط
  // بخدمة مفتوحة فعلية — للسياق بس، من غير أي دخل في الجزء المالي (الفصل
  // الكامل بين الملفين فاضل زي ما هو).
  purposeContext: { serviceName: string; serviceNameEn: string | null } | null;
  // Batch 148: Visit Type المبدئي من سبب حجز النهاردة.
  defaultVisitService?: string | null;
  upperBulkBondingDate: string | null;
  lowerBulkBondingDate: string | null;
  summaryOptions: { chief_complaint: string[]; treatment: string[]; diagnosis: string[] };
}) {
  const [gapMode, setGapMode] = useState<GapMode>("none");
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [view, setView] = useState<ChartView>("interactive");
  const [showInventoryModal, setShowInventoryModal] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [visitToEdit, setVisitToEdit] = useState<number | null>(null);
  const [summary, setSummary] = useState<Record<SummaryField, string>>({
    chief_complaint: chart.chief_complaint ?? "",
    treatment_note: chart.treatment_note ?? "",
    diagnosis_summary: chart.diagnosis_summary ?? "",
  });
  const pendingSummarySave = useRef<number | null>(null);
  const latestSummary = useRef(summary);
  useEffect(() => { latestSummary.current = summary; }, [summary]);
  useEffect(() => () => { if (pendingSummarySave.current) window.clearTimeout(pendingSummarySave.current); }, []);

  function updateSummary(field: SummaryField, value: string) {
    const next = { ...latestSummary.current, [field]: value };
    latestSummary.current = next;
    setSummary(next);
    if (!editable) return;
    if (pendingSummarySave.current) window.clearTimeout(pendingSummarySave.current);
    pendingSummarySave.current = window.setTimeout(async () => {
      const result = await saveOrthoChartSummaryAction({ patientId, field, value: latestSummary.current[field] });
      if (!result.ok) window.alert(result.reason || "تعذر الحفظ التلقائي.");
    }, 700);
  }
  function openVisitForEdit(visitId: number) {
    setVisitToEdit(visitId);
    window.setTimeout(() => document.getElementById("ortho-visit-editor")?.scrollIntoView({ behavior: "smooth", block: "start" }), 50);
  }
  function handleTopSectionSubmit(formData: FormData) {
    startTransition(async () => {
      const res = await saveOrthoTopSectionAction(formData);
      if (!res.ok) window.alert(res.reason || "حصل خطأ، حاول تاني.");
      router.refresh();
    });
  }

  function undoDeduction(id: number) {
    if (!window.confirm("Undo this inventory deduction?")) return;
    startTransition(async () => {
      const res = await undoOrthoInventoryDeductionAction({ patientId, deductionId: id });
      if (!res.ok) window.alert(res.reason || "حصل خطأ، حاول تاني.");
      router.refresh();
    });
  }

  const inventoryByDate = useMemo(() => {
    const map = new Map<string, InventoryLogEntry[]>();
    inventoryLog.forEach((l) => {
      const key = l.date || "—";
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(l);
    });
    return Array.from(map.entries());
  }, [inventoryLog]);

  const chartEventsByDate = useMemo(() => {
    const map = new Map<string, ChartEventEntry[]>();
    chartEvents.forEach((ev) => {
      const key = ev.date || "—";
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(ev);
    });
    return Array.from(map.entries());
  }, [chartEvents]);

  const activeInventoryCount = inventoryLog.filter((l) => !l.undoneAt).length;
  // Batch 147: السلك بيتحدد بالبراكتس المتركّبة "دلوقتي" في كل فك (أقدم تاريخ
  // تركيب)، مش بتاريخ الزيارات — شوف wireRequirement في ortho-v2-actions.
  const bondedSince = (row: typeof UPPER_ROW) => {
    const bonded = row.filter((tooth) => toothStates[tooth.fdi]?.bracket === "bonded");
    if (!bonded.length) return null;
    return bonded.map((tooth) => toothStates[tooth.fdi]?.bondedDate?.slice(0, 10)).filter((d): d is string => Boolean(d)).sort()[0] ?? "0000-00-00";
  };
  const upperBondedSince = bondedSince(UPPER_ROW);
  const lowerBondedSince = bondedSince(LOWER_ROW);
  const bondingVisitFor = (service: string) => visits.filter((visit) => visit.bondingApplied && visit.service === service).map((visit) => ({ id: visit.id, date: visit.date }))[0] ?? null;
  const debondedDate = visits.filter((visit) => visit.debondApplied).map((visit) => visit.date).sort().at(-1) ?? null;
  // دفعة 150: اللي بيترسم على الشارت. ألوان الـ O-tie من آخر زيارة اتسجّل فيها
  // لون (فوق، وتحت = لونه لو مختلف وإلا نفس لون فوق)، والـ Power chain من آخر
  // زيارة بس (لو آخر زيارة مافيهاش سلسلة، مفيش سلسلة على الشارت).
  const bondedBracketTeeth = useMemo(() => [...UPPER_ROW, ...LOWER_ROW].filter((tooth) => tooth.position < 6 && toothStates[tooth.fdi]?.bracket === "bonded").map((tooth) => tooth.fdi), [toothStates]);
  const chartAppliances = useMemo(() => {
    const lastOtie = visits.find((visit) => visit.otieColor);
    const upper = lastOtie ? elastomericColorForItemName(lastOtie.otieColor) : null;
    const lower = lastOtie ? (lastOtie.otieLowerColor ? elastomericColorForItemName(lastOtie.otieLowerColor) : upper) : null;
    const latest = visits[0];
    const chains = (latest?.powerChains ?? []).map((chain) => ({
      arch: chain.arch,
      teeth: chainTeeth(chain),
      onHooks: chain.onHooks,
      hex: (chain.arch === "upper" ? upper?.hex : lower?.hex) ?? "#64748b",
    }));
    return { otieUpper: upper?.hex ?? null, otieLower: lower?.hex ?? null, chains };
  }, [visits]);

  return (
    <div dir="ltr" className={`space-y-4 ${isPending ? "opacity-70 pointer-events-none" : ""}`}>
        {/* Title + back link — سطر واحد مضغوط بدل الهيدر الكبير اللي كان في
            page.tsx (كان مكرر ومساحته كبيرة، طلب المستخدم بعد أول نشر حقيقي). */}
        <div className="ortho-chart-title-row">
          <Link href={`/patients/${patientId}`} className="text-xs text-primary hover:underline shrink-0">
            ← Back to patient file
          </Link>
          <h1 className="text-lg font-bold">Orthodontic chart</h1>
          {needsNewPhotos && <span className="ortho-photo-alert">No photos from the last 6 months</span>}
          {needsConsultantVisit && <span className="ortho-consultant-alert">{consultantName ? `Dr. ${consultantName}` : "Consultant"} has not seen the patient for {consultantReminderMonths} months</span>}
          <div className="ortho-title-controls">
            <span className="text-xs font-semibold text-muted">Brackets:</span>
            <Dropdown name="bracket_type" form="ortho-top-section-form" defaultValue={chart.bracket_type} options={MOCK_BRACKET_TYPES} disabled={!editable} />
            <Dropdown name="prescription" form="ortho-top-section-form" defaultValue={chart.prescription} options={PRESCRIPTION_OPTIONS} disabled={!editable} />
            <Dropdown name="slot" form="ortho-top-section-form" defaultValue={chart.slot} options={SLOT_OPTIONS} disabled={!editable} />
          </div>
        </div>

        <div className="ortho-workbench">
          <aside className="ortho-visit-sidebar">
            <div className="ortho-patient-identity ortho-patient-identity--sidebar">
              {/* Batch 126: نفس صورة الملف، قابلة للضغط للتكبير/التغيير/الحذف. */}
              <PatientAvatar patientId={patientId} patientName={patientName} avatarPath={avatarPath} className="ortho-patient-avatar" editable={editable || canUploadPhotos} />
              <div>
                <div className="ortho-patient-name">{patientName}</div>
                {patientAge != null && <div className="ortho-patient-age">Age <strong>{patientAge}</strong></div>}
              </div>
            </div>
            <FollowUpsTable
              patientId={patientId}
              editable={editable}
              canEditAfterSave={canEditAfterSave}
              canDeleteVisit={canDeleteVisit}
              defaultDoctorId={defaultDoctorId}
              doctors={doctors}
              stockItems={stockItems}
              activeBracketCount={activeBracketCount}
              bondedBracketTeeth={bondedBracketTeeth}
              unlinkedBracketCountToday={unlinkedBracketCountToday}
              visits={visits}
              upperBondedSince={upperBondedSince}
              lowerBondedSince={lowerBondedSince}
              defaultVisitService={defaultVisitService}
              editVisitId={visitToEdit}
              onEditVisitOpened={() => setVisitToEdit(null)}
            />
          </aside>

          <main className="ortho-workbench-main">
            {/* This is the same live gallery/upload flow used by the medical record. */}
            <div className="ortho-live-photos ortho-live-photos--workbench" aria-label="Patient photos and X-rays">
            <OrthoImageGallery groups={imageGroups} patientId={patientId} editable={editable || canUploadPhotos} compact />
            {(editable || canUploadPhotos) && <OrthoAddImageGroupForm patientId={patientId} compact />}
            </div>

      {/* Diagnosis / Interactive chart toggle */}
      <div className="ortho-chart-section card-3d rounded-xl">
        <div className="ortho-chart-section-header">
          <button type="button" onClick={() => setView((v) => (v === "interactive" ? "diagnostic" : "interactive"))} className="ortho-chart-view-toggle text-primary hover:underline">
            {view === "interactive" ? "Diagnostic chart" : "Interactive chart"}
          </button>
          {view === "interactive" && editable && (
            <div className="ortho-chart-command-center">
              <button type="button" className={`ortho-chart-mode-button ${gapMode === "stripping" ? "is-active" : ""}`} aria-pressed={gapMode === "stripping"} onClick={() => setGapMode(gapMode === "stripping" ? "none" : "stripping")}>Stripping</button>
              <button type="button" className={`ortho-chart-mode-button ${gapMode === "miniscrew" ? "is-active" : ""}`} aria-pressed={gapMode === "miniscrew"} onClick={() => setGapMode(gapMode === "miniscrew" ? "none" : "miniscrew")}>Miniscrews</button>
            </div>
          )}
          <h3>{view === "interactive" ? "Interactive chart" : "Diagnosis:"}</h3>
        </div>

        <div style={{ display: view === "interactive" ? "block" : "none" }}>
          <InteractiveToothChart appliances={chartAppliances} patientId={patientId} editable={editable} teeth={toothStates} stripCounts={stripCounts} miniscrews={miniscrews} mode={gapMode} onModeChange={setGapMode} upperBulkBondingDate={upperBulkBondingDate} lowerBulkBondingDate={lowerBulkBondingDate} canManageBonding={canManageBonding} canDeleteVisit={canDeleteVisit} upperBondingVisit={bondingVisitFor("Bonding Upper")} lowerBondingVisit={bondingVisitFor("Bonding Lower")} debondedDate={debondedDate} summary={summary} summaryOptions={summaryOptions} onSummaryChange={updateSummary} />
        </div>
        <div style={{ display: view === "diagnostic" ? "block" : "none" }}>
          <div className="ortho-diagnostic-layout">
            <form id="ortho-top-section-form" action={handleTopSectionSubmit} className="ortho-treatment-panel">
              <input type="hidden" name="patient_id" value={patientId} />
              <section className="space-y-1.5">
                <div className="text-sm font-semibold">Chief Complaint</div>
                <textarea
                  name="chief_complaint"
                  value={summary.chief_complaint}
                  onChange={(event) => updateSummary("chief_complaint", event.target.value)}
                  disabled={!editable}
                  placeholder="Eg.: Spacing"
                  rows={5}
                  className="ortho-chief-complaint w-full resize-none rounded-md border border-border bg-background px-2 py-1.5 text-sm placeholder:text-muted disabled:opacity-60"
                />
              </section>

              <section className="space-y-3">
                <div className="text-sm font-semibold">Treatment Plan</div>
                <div className="flex items-start gap-6 flex-wrap">
                  <div className="space-y-1.5">
                    <div className="text-xs text-muted">Extraction:</div>
                    <div className="relative inline-block">
                      <div className="grid grid-cols-2 gap-x-3">
                        <div className="pb-1.5 flex justify-center" style={{ borderBottom: "2px solid #1c2521" }}>
                          <Dropdown name="extraction_ur" defaultValue={chart.extraction_quadrants?.ur ?? null} options={POSITIONS} disabled={!editable} />
                        </div>
                        <div className="pb-1.5 flex justify-center" style={{ borderBottom: "2px solid #1c2521" }}>
                          <Dropdown name="extraction_ul" defaultValue={chart.extraction_quadrants?.ul ?? null} options={POSITIONS} disabled={!editable} />
                        </div>
                        <div className="pt-1.5 flex justify-center">
                          <Dropdown name="extraction_lr" defaultValue={chart.extraction_quadrants?.lr ?? null} options={POSITIONS} disabled={!editable} />
                        </div>
                        <div className="pt-1.5 flex justify-center">
                          <Dropdown name="extraction_ll" defaultValue={chart.extraction_quadrants?.ll ?? null} options={POSITIONS} disabled={!editable} />
                        </div>
                      </div>
                      <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 pointer-events-none" style={{ width: "2px", background: "#1c2521" }} />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <div className="text-xs text-muted">Anchorage:</div>
                    <Dropdown name="anchorage_device" defaultValue={chart.anchorage_device} options={options.anchorageDevices} disabled={!editable} />
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="text-xs text-muted">Notes (free text)</div>
                  <textarea name="treatment_note" value={summary.treatment_note} onChange={(event) => updateSummary("treatment_note", event.target.value)} disabled={!editable} rows={4} className="ortho-treatment-notes w-full resize-none rounded-md border border-border bg-background px-2 py-1.5 text-sm disabled:opacity-60" />
                </div>
              </section>

              <div className="flex justify-end">
                {editable && <button type="submit" className="px-4 py-2 rounded-md text-sm font-medium btn-3d-primary">Save</button>}
              </div>
            </form>
            <div className="ortho-diagnostic-panel">
              <DiagnosticChart patientId={patientId} editable={editable} data={diagnostic} diagnosisSummary={summary.diagnosis_summary} onDiagnosisSummaryChange={(value) => updateSummary("diagnosis_summary", value)} />
              <div className="ortho-diagnostic-links">
                <button type="button" onClick={() => setShowInventoryModal(true)} className="font-medium text-primary underline hover:no-underline">Inventory list{activeInventoryCount > 0 ? ` (${activeInventoryCount})` : ""}</button>
                <button type="button" onClick={() => setShowReportModal(true)} className="font-medium text-primary underline hover:no-underline">Interactive report{chartEvents.length > 0 ? ` (${chartEvents.length})` : ""}</button>
              </div>
            </div>
          </div>
        </div>
      </div>

          </main>
        </div>

      <section className="ortho-visits-table card-3d" aria-label="Previous orthodontic visits">
        <div className="ortho-visits-table-heading"><div><h3>Previous Visits</h3><span>Full clinical and inventory details</span></div><strong>{visits.length} recorded</strong></div>
        <div className="ortho-visits-table-scroll">
          <table>
            <thead><tr><th>Date</th><th>Doctor</th><th>Visit type</th><th>Upper wire</th><th>Lower wire</th><th>O-tie</th><th>Power chain</th><th>Elastics</th><th>Buttons</th><th>Coil</th><th>Notes</th>{editable && canEditAfterSave && <th />}</tr></thead>
            <tbody>{visits.length === 0 ? <tr><td colSpan={editable && canEditAfterSave ? 12 : 11} className="ortho-visits-table-empty">No visits recorded yet.</td></tr> : visits.map((visit) => {
              const doctor = doctors.find((entry) => entry.id === visit.doctorId)?.full_name ?? "—";
              const otie = visit.otieColor ? elastomericColorForItemName(visit.otieColor) : null;
              const otieLower = visit.otieLowerColor ? elastomericColorForItemName(visit.otieLowerColor) : null;
              const chainCell = visit.powerChains.length > 0
                ? visit.powerChains.map((chain, index) => <span key={index} className="block">{chainLabel(chain)} ({chain.qty}){chain.deducted ? "" : <em className="ortho-visits-not-deducted"> · not deducted</em>}</span>)
                : visit.powerChainQty || "—";
              return <tr key={visit.id}><td>{visit.date}</td><td>{doctor}</td><td>{visit.service || "—"}</td><td>{visit.upperSize || "—"}</td><td>{visit.lowerSize || "—"}</td><td className="ortho-visits-table-otie">{otie ? <><span style={{ color: otie.hex }}>{otieLower ? `U ${otie.name}` : otie.name}</span>{otieLower && <span className="block" style={{ color: otieLower.hex }}>L {otieLower.name}</span>}</> : "—"}</td><td>{chainCell}</td><td>{visit.elasticsSize || "—"}</td><td>{visit.buttonsQty || "—"}</td><td>{visit.compressedCoilMm ? `${visit.compressedCoilMm} mm` : "—"}</td><td className="ortho-visits-table-note">{formatNoteLines(visit.note) || "—"}</td>{editable && canEditAfterSave && <td><button type="button" onClick={() => openVisitForEdit(visit.id)}>Edit</button></td>}</tr>;
            })}</tbody>
          </table>
        </div>
      </section>

      {showInventoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={() => setShowInventoryModal(false)}>
          <div className="card-3d rounded-xl p-5 w-full max-w-md max-h-[80vh] flex flex-col space-y-3" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold">Inventory list</h3>
              <button type="button" onClick={() => setShowInventoryModal(false)} className="text-muted text-lg leading-none px-1">
                ×
              </button>
            </div>
            <p className="text-xs text-muted">Materials used for this patient since treatment started.</p>
            <div className="overflow-y-auto space-y-3">
              {inventoryLog.length === 0 && <p className="text-xs text-muted">Nothing used yet.</p>}
              {inventoryByDate.map(([date, entries]) => (
                <div key={date} className="rounded-lg border border-border p-2 space-y-1.5">
                  <div className="text-[11px] font-semibold text-muted">📅 {date}</div>
                  {entries.map((l) => (
                    <div key={l.id} className={`flex items-center justify-between gap-2 text-xs rounded-md border border-border px-2 py-1.5 ${l.undoneAt ? "opacity-50 line-through" : ""}`}>
                      <span>
                        − {l.qty} × {l.label}
                        {l.teeth && l.teeth.length > 0 ? ` (${l.teeth.join(", ")})` : ""}
                      </span>
                      {!l.undoneAt && canUndoInventory && (
                        <button type="button" onClick={() => undoDeduction(l.id)} className="text-muted hover:text-red-600 shrink-0" title="Undo this deduction">
                          Undo
                        </button>
                      )}
                      {l.undoneAt && <span className="text-muted shrink-0">Undone</span>}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={() => setShowReportModal(false)}>
          <div className="card-3d rounded-xl p-5 w-full max-w-md max-h-[80vh] flex flex-col space-y-3" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold">Interactive report</h3>
              <button type="button" onClick={() => setShowReportModal(false)} className="text-muted text-lg leading-none px-1">
                ×
              </button>
            </div>
            <p className="text-xs text-muted">Everything that happened on the Interactive chart, by date.</p>
            <div className="overflow-y-auto space-y-3">
              {chartEvents.length === 0 && <p className="text-xs text-muted">Nothing recorded yet.</p>}
              {chartEventsByDate.map(([date, events]) => (
                <div key={date} className="rounded-lg border border-border p-2 space-y-1.5">
                  <div className="text-[11px] font-semibold text-muted">📅 {date}</div>
                  {events.map((ev) => (
                    <div key={ev.id} className="text-xs rounded-md border border-border px-2 py-1.5">
                      {ev.text}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
