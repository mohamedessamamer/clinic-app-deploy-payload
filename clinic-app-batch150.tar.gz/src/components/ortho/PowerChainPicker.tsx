"use client";

// دفعة 150 — بوكس اختيار أماكن الـ Power chain (من 7 لـ 7).
// شبكة واحدة للفكين: كل ضغطتين في نفس الصف = سلسلة. كل سلسلة بتظهر كـ chip
// فيه ⇄ (on hooks / on brackets) و ×. البوكس مابيظهرش غير لما الدكتور يدوس على
// خانة Power chain. كل الكلام English (قرار صاحب العيادة).

import { useState } from "react";
import { LOWER_BOX, UPPER_BOX, chainLabel, chainQty, chainTeeth, MAX_CHAINS_PER_VISIT, type ChainArch, type PowerChainInput } from "@/lib/ortho/power-chain";

export default function PowerChainPicker({
  value,
  upper,
  lower,
  onDone,
  onCancel,
}: {
  value: PowerChainInput[];
  upper: { hex: string; name: string } | null;
  lower: { hex: string; name: string } | null;
  onDone: (chains: PowerChainInput[]) => void;
  onCancel: () => void;
}) {
  const [chains, setChains] = useState<PowerChainInput[]>(() => value.map(({ arch, from, to, onHooks }) => ({ arch, from, to, onHooks })));
  const [pending, setPending] = useState<{ arch: ChainArch; fdi: number } | null>(null);
  const [message, setMessage] = useState("");

  function tap(arch: ChainArch, fdi: number) {
    setMessage("");
    const colour = arch === "upper" ? upper : lower;
    if (!colour) {
      setMessage(`Select the ${arch} O-tie colour first — the chain follows it.`);
      return;
    }
    if (!pending || pending.arch !== arch) {
      setPending({ arch, fdi });
      return;
    }
    if (pending.fdi === fdi) {
      setPending(null);
      return;
    }
    if (chains.length >= MAX_CHAINS_PER_VISIT) {
      setMessage(`At most ${MAX_CHAINS_PER_VISIT} chains per visit.`);
      setPending(null);
      return;
    }
    setChains((current) => [...current, { arch, from: pending.fdi, to: fdi, onHooks: false }]);
    setPending(null);
  }

  function row(arch: ChainArch, teeth: readonly number[]) {
    const colour = arch === "upper" ? upper : lower;
    const covered = new Map<number, number>();
    for (const chain of chains) if (chain.arch === arch) for (const fdi of chainTeeth(chain)) covered.set(fdi, (covered.get(fdi) ?? 0) + 1);
    return (
      <div className="ortho-pc-row">
        {teeth.map((fdi, index) => {
          const count = covered.get(fdi) ?? 0;
          const isPending = pending?.arch === arch && pending.fdi === fdi;
          return (
            <span key={fdi} className="contents">
              {index === 7 && <span className="ortho-pc-mid" aria-hidden="true" />}
              <button
                type="button"
                className={`ortho-pc-tooth ${count > 0 ? "is-on" : ""} ${isPending ? "is-pending" : ""}`}
                style={{ "--pc": colour?.hex ?? "#94a3b8" } as React.CSSProperties}
                onClick={() => tap(arch, fdi)}
                aria-pressed={count > 0 || isPending}
                aria-label={`Tooth ${fdi}`}
              >
                {fdi}
                {count > 1 && <i>{count}</i>}
              </button>
            </span>
          );
        })}
      </div>
    );
  }

  return (
    <div className="ortho-pc-backdrop" role="dialog" aria-modal="true" aria-label="Power chain" onClick={(event) => event.stopPropagation()}>
      <div className="ortho-pc-sheet">
        <h3>Power chain</h3>
        <p className="ortho-pc-hint">Tap the first and the last tooth. Upper and lower on the same grid.</p>
        <div className="ortho-pc-label">UPPER · O-tie {upper?.name ?? "not selected"}</div>
        {row("upper", UPPER_BOX)}
        <div className="ortho-pc-label">LOWER · O-tie {lower?.name ?? "not selected"}</div>
        {row("lower", LOWER_BOX)}
        {message && <p className="ortho-pc-message" role="alert">{message}</p>}
        {chains.length > 0 && (
          <div className="ortho-pc-chips">
            {chains.map((chain, index) => (
              <div key={index} className="ortho-pc-chip" style={{ "--pc": (chain.arch === "upper" ? upper?.hex : lower?.hex) ?? "#94a3b8" } as React.CSSProperties}>
                <span><b>{chain.arch === "upper" ? "Upper" : "Lower"} {chainLabel({ ...chain, onHooks: false })}</b> · Qty {chainQty(chain)}</span>
                <span className="ortho-pc-chip-actions">
                  <button type="button" onClick={() => setChains((current) => current.map((item, i) => (i === index ? { ...item, onHooks: !item.onHooks } : item)))}>
                    {chain.onHooks ? "On hooks" : "On brackets"} ⇄
                  </button>
                  <button type="button" aria-label="Remove chain" onClick={() => setChains((current) => current.filter((_, i) => i !== index))}>×</button>
                </span>
              </div>
            ))}
          </div>
        )}
        <div className="ortho-pc-actions">
          <button type="button" className="is-primary" onClick={() => onDone(chains)}>Done</button>
          <button type="button" onClick={onCancel}>Cancel</button>
        </div>
      </div>
    </div>
  );
}
