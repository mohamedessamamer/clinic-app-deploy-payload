// دفعة 150 — أماكن الـ Power chain على الأسنان.
//
// قبل كده الزيارة كانت بتسجّل "عدد" بس. دلوقتي كل سلسلة = فك + من سنة لسنة
// (من 7 لـ 7) + على البراكتس ولا على الهوكس. العدد بيتحسب لوحده = عدد الأسنان
// في المدى، شاملة أي سنة مخلوعة جوه المدى (السلسلة بتعدّي عليها — قرار صاحب
// العيادة). ممكن أكتر من سلسلة في نفس الفك، وممكن سلسلتين على نفس السنة.
//
// ملف نقي من غير أي import لقاعدة البيانات أو React، عشان يتستخدم في السيرفر
// والواجهة والاختبارات بنفس المنطق بالظبط.

export type ChainArch = "upper" | "lower";

export interface PowerChainInput {
  arch: ChainArch;
  from: number;
  to: number;
  onHooks: boolean;
}

export interface PowerChainSaved extends PowerChainInput {
  qty: number;
  /** صنف المخزن اللي اتخصم منه (null لو مفيش صنف بلون الـ O-tie ده). */
  itemId: number | null;
  /** false = اتحفظ بس متخصمش من المخزن (مفيش صنف للون ده). */
  deducted: boolean;
  color: string | null;
}

/** صفوف البوكس: من 7 لـ 7، بنفس ترتيب الشارت (يمين المريض على الشمال). */
export const UPPER_BOX = [17, 16, 15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 26, 27] as const;
export const LOWER_BOX = [47, 46, 45, 44, 43, 42, 41, 31, 32, 33, 34, 35, 36, 37] as const;

export const MAX_CHAINS_PER_VISIT = 6;

export function boxFor(arch: ChainArch): readonly number[] {
  return arch === "upper" ? UPPER_BOX : LOWER_BOX;
}

export function archOfTooth(fdi: number): ChainArch | null {
  if ((UPPER_BOX as readonly number[]).includes(fdi)) return "upper";
  if ((LOWER_BOX as readonly number[]).includes(fdi)) return "lower";
  return null;
}

/** الأسنان اللي السلسلة بتعدّي عليها بالترتيب، من غير ما يفرق مين الأول. */
export function chainTeeth(chain: Pick<PowerChainInput, "arch" | "from" | "to">): number[] {
  const box = boxFor(chain.arch);
  const a = box.indexOf(chain.from);
  const b = box.indexOf(chain.to);
  if (a < 0 || b < 0) return [];
  const [start, end] = a <= b ? [a, b] : [b, a];
  return box.slice(start, end + 1);
}

export function chainQty(chain: Pick<PowerChainInput, "arch" | "from" | "to">): number {
  return chainTeeth(chain).length;
}

export function chainLabel(chain: Pick<PowerChainInput, "arch" | "from" | "to" | "onHooks">): string {
  const teeth = chainTeeth(chain);
  return `${teeth[0]}-${teeth[teeth.length - 1]}${chain.onHooks ? " on hooks" : ""}`;
}

/**
 * بيراجع المدخلات اللي جاية من الواجهة: فك صحيح، والسنتين في نفس الفك، ومدى
 * فيه سنتين على الأقل. أي حاجة مش صح بترجع رسالة بدل ما تتحفظ ناقصة.
 */
export function normalizeChains(raw: unknown): { ok: true; chains: PowerChainInput[] } | { ok: false; reason: string } {
  if (raw == null) return { ok: true, chains: [] };
  if (!Array.isArray(raw)) return { ok: false, reason: "Power chain data is invalid." };
  if (raw.length > MAX_CHAINS_PER_VISIT) return { ok: false, reason: `At most ${MAX_CHAINS_PER_VISIT} power chains per visit.` };
  const chains: PowerChainInput[] = [];
  for (const item of raw) {
    if (typeof item !== "object" || item === null) return { ok: false, reason: "Power chain data is invalid." };
    const { arch, from, to, onHooks } = item as Record<string, unknown>;
    if (arch !== "upper" && arch !== "lower") return { ok: false, reason: "Power chain arch is invalid." };
    const f = Number(from);
    const t = Number(to);
    if (!Number.isInteger(f) || !Number.isInteger(t) || archOfTooth(f) !== arch || archOfTooth(t) !== arch) {
      return { ok: false, reason: "Power chain teeth must be in the same arch (7 to 7)." };
    }
    if (f === t) return { ok: false, reason: "A power chain needs two different teeth." };
    chains.push({ arch, from: f, to: t, onHooks: onHooks === true });
  }
  return { ok: true, chains };
}

/**
 * عدد الـ O-ties لكل فك = البراكتس المتركّبة (مش التيوبس) ناقص الأسنان اللي
 * عليها سلسلة "على البراكتس" (السلسلة نفسها بتربط البراكت). السلسلة على الهوكس
 * مابتشيلش الـ O-tie. السنة اللي عليها سلسلتين بتتطرح مرة واحدة بس.
 */
export function otieQtyForArch(arch: ChainArch, bondedBracketTeeth: number[], chains: PowerChainInput[]): number {
  const bonded = new Set(bondedBracketTeeth.filter((fdi) => (arch === "upper" ? fdi < 30 : fdi > 30)));
  const covered = new Set<number>();
  for (const chain of chains) {
    if (chain.arch !== arch || chain.onHooks) continue;
    for (const fdi of chainTeeth(chain)) if (bonded.has(fdi)) covered.add(fdi);
  }
  return bonded.size - covered.size;
}

/** بيقرا العمود power_chains من قاعدة البيانات من غير ما يقع لو النص بايظ. */
export function parseSavedChains(raw: string | null | undefined): PowerChainSaved[] {
  if (!raw) return [];
  try {
    const value = JSON.parse(raw);
    if (!Array.isArray(value)) return [];
    return value
      .filter((item) => item && (item.arch === "upper" || item.arch === "lower") && Number.isInteger(item.from) && Number.isInteger(item.to))
      .map((item) => ({
        arch: item.arch,
        from: item.from,
        to: item.to,
        onHooks: item.onHooks === true,
        qty: Number.isFinite(item.qty) ? item.qty : chainQty(item),
        itemId: Number.isInteger(item.itemId) ? item.itemId : null,
        deducted: item.deducted !== false,
        color: typeof item.color === "string" ? item.color : null,
      }));
  } catch {
    return [];
  }
}
