import { test } from "node:test";
import assert from "node:assert/strict";
import { chainLabel, chainQty, chainTeeth, normalizeChains, otieQtyForArch, parseSavedChains } from "../../src/lib/ortho/power-chain.ts";

test("chain teeth follow the chart order and ignore direction", () => {
  assert.deepEqual(chainTeeth({ arch: "upper", from: 13, to: 23 }), [13, 12, 11, 21, 22, 23]);
  assert.deepEqual(chainTeeth({ arch: "upper", from: 23, to: 13 }), [13, 12, 11, 21, 22, 23]);
  assert.deepEqual(chainTeeth({ arch: "lower", from: 33, to: 36 }), [33, 34, 35, 36]);
});

test("qty = teeth in the range, an extracted tooth in the middle still counts", () => {
  assert.equal(chainQty({ arch: "upper", from: 13, to: 15 }), 3);
  assert.equal(chainQty({ arch: "lower", from: 47, to: 37 }), 14);
});

test("label", () => {
  assert.equal(chainLabel({ arch: "upper", from: 23, to: 13, onHooks: true }), "13-23 on hooks");
  assert.equal(chainLabel({ arch: "lower", from: 33, to: 43, onHooks: false }), "43-33");
});

test("normalize rejects wrong arch, same tooth, 8s and junk", () => {
  assert.equal(normalizeChains([{ arch: "upper", from: 13, to: 33, onHooks: false }]).ok, false);
  assert.equal(normalizeChains([{ arch: "upper", from: 13, to: 13 }]).ok, false);
  assert.equal(normalizeChains([{ arch: "upper", from: 18, to: 13 }]).ok, false);
  assert.equal(normalizeChains("x").ok, false);
  assert.deepEqual(normalizeChains(null), { ok: true, chains: [] });
  const ok = normalizeChains([{ arch: "lower", from: "43", to: 33, onHooks: true }]);
  assert.deepEqual(ok, { ok: true, chains: [{ arch: "lower", from: 43, to: 33, onHooks: true }] });
});

test("O-ties per arch: chains on brackets replace O-ties, chains on hooks do not, overlap counted once", () => {
  const bonded = [15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 45, 44, 43, 42, 41, 31, 32, 33, 34, 35];
  assert.equal(otieQtyForArch("upper", bonded, []), 10);
  assert.equal(otieQtyForArch("upper", bonded, [{ arch: "upper", from: 13, to: 23, onHooks: true }]), 10);
  assert.equal(otieQtyForArch("lower", bonded, [{ arch: "lower", from: 43, to: 33, onHooks: false }]), 4);
  assert.equal(otieQtyForArch("lower", bonded, [{ arch: "lower", from: 43, to: 33, onHooks: false }, { arch: "lower", from: 42, to: 32, onHooks: false }]), 4);
  // a chain over a tooth without a bracket (extraction space) removes nothing
  assert.equal(otieQtyForArch("upper", [13, 15], [{ arch: "upper", from: 13, to: 15, onHooks: false }]), 0);
});

test("parse saved chains tolerates bad JSON", () => {
  assert.deepEqual(parseSavedChains("not json"), []);
  assert.deepEqual(parseSavedChains(null), []);
  const saved = parseSavedChains(JSON.stringify([{ arch: "upper", from: 13, to: 23, onHooks: true, qty: 6, itemId: 5, deducted: false, color: "Purple" }]));
  assert.equal(saved[0].deducted, false);
  assert.equal(saved[0].qty, 6);
});
