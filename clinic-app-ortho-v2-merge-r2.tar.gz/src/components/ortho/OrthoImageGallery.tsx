"use client";

// Photos & X-rays — same real data as the patient file's PatientImageGallery
// (patient_image_groups/patient_images, same addImageGroupAction/deleteImageAction),
// but a separate English/LTR presentation matching the v2 chart's design instead of
// the shared Arabic/RTL card strip — the chart is meant to stay English regardless
// of the rest of the (Arabic/RTL) system, per the 2026-08-27 review round.

import { useCallback, useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { deleteImageAction } from "@/app/patients/[id]/actions";

type GroupImage = { id: number; file_path: string };
type ImageGroup = { id: number; label: string | null; taken_at: string; images: GroupImage[] };
type FlatImage = { id: number; file_path: string; label: string | null; taken_at: string };

function extensionOf(filePath: string): string {
  const match = /\.[a-zA-Z0-9]+$/.exec(filePath);
  return match ? match[0] : "";
}

export default function OrthoImageGallery({ groups, patientId, editable }: { groups: ImageGroup[]; patientId: number; editable: boolean }) {
  const router = useRouter();
  const [, startTransition] = useTransition();

  // Flat pool across all groups — matches the v2 design (no visible grouping),
  // while the underlying data stays grouped for the rest of the app.
  const flatImages: FlatImage[] = groups.flatMap((g) =>
    g.images.map((img) => ({ id: img.id, file_path: img.file_path, label: g.label, taken_at: g.taken_at }))
  );

  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const close = useCallback(() => setOpenIndex(null), []);
  const prev = useCallback(() => {
    setOpenIndex((i) => (i === null || flatImages.length === 0 ? i : (i - 1 + flatImages.length) % flatImages.length));
  }, [flatImages.length]);
  const next = useCallback(() => {
    setOpenIndex((i) => (i === null || flatImages.length === 0 ? i : (i + 1) % flatImages.length));
  }, [flatImages.length]);

  useEffect(() => {
    if (openIndex === null) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") close();
      else if (e.key === "ArrowLeft") prev();
      else if (e.key === "ArrowRight") next();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [openIndex, close, prev, next]);

  function handleDelete(imageId: number, e: React.MouseEvent) {
    e.stopPropagation();
    const ok = window.confirm("Delete this photo? This can't be undone.");
    if (!ok) return;
    const formData = new FormData();
    formData.set("image_id", String(imageId));
    formData.set("patient_id", String(patientId));
    startTransition(async () => {
      await deleteImageAction(formData);
      router.refresh();
    });
  }

  return (
    <div dir="ltr">
      <div className="flex gap-3 flex-wrap items-start">
        {flatImages.map((img, idx) => (
          <div key={img.id} className="relative w-20 h-20 rounded-md overflow-hidden border border-border bg-background group">
            <button type="button" onClick={() => setOpenIndex(idx)} className="block w-full h-full cursor-zoom-in">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={img.file_path} alt={img.label || "Photo"} className="w-full h-full object-cover" />
            </button>
            {editable && (
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-center justify-center gap-1 opacity-0 group-hover:opacity-100 pointer-events-none">
                <button
                  type="button"
                  onClick={(e) => handleDelete(img.id, e)}
                  className="text-white text-xs bg-black/50 rounded px-1.5 py-0.5 pointer-events-auto"
                  title="Delete"
                  aria-label="Delete photo"
                >
                  ×
                </button>
              </div>
            )}
          </div>
        ))}
        {flatImages.length === 0 && <p className="text-xs text-muted">No photos or X-rays uploaded for this patient yet.</p>}
      </div>

      {openIndex !== null && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4" onClick={close}>
          {flatImages.length > 1 && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                prev();
              }}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-white/80 hover:text-white text-4xl px-3 py-2 select-none"
              aria-label="Previous"
            >
              ‹
            </button>
          )}

          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={flatImages[openIndex].file_path}
            alt={flatImages[openIndex].label || "Photo"}
            className="max-w-[90vw] max-h-[85vh] object-contain rounded shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          />

          {flatImages.length > 1 && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                next();
              }}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-white/80 hover:text-white text-4xl px-3 py-2 select-none"
              aria-label="Next"
            >
              ›
            </button>
          )}

          <a
            href={flatImages[openIndex].file_path}
            download={`${flatImages[openIndex].taken_at}-${openIndex + 1}${extensionOf(flatImages[openIndex].file_path)}`}
            onClick={(e) => e.stopPropagation()}
            className="absolute top-4 right-4 text-white/90 hover:text-white text-sm bg-black/40 hover:bg-black/60 rounded-md px-3 py-1.5 transition-colors"
          >
            ⬇ Download
          </a>

          <div className="absolute bottom-4 inset-x-0 text-center text-white/70 text-xs">
            {openIndex + 1} / {flatImages.length}
            {flatImages[openIndex].taken_at ? ` · ${flatImages[openIndex].taken_at}` : ""}
          </div>
        </div>
      )}
    </div>
  );
}
