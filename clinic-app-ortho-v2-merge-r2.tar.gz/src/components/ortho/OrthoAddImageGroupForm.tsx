"use client";

// Upload widget for the v2 chart's Photos & X-rays section — same real
// addImageGroupAction as the patient file's AddImageGroupForm (real storage,
// real patient_image_groups/patient_images rows), styled to match the "+" tile
// from the v2 design instead of the shared Arabic dropzone, and always English/LTR.

import { useMemo, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { addImageGroupAction } from "@/app/patients/[id]/actions";

export default function OrthoAddImageGroupForm({ patientId }: { patientId: number }) {
  const router = useRouter();
  const [, startTransition] = useTransition();
  const today = useMemo(() => new Date().toISOString().slice(0, 10), []);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const [date, setDate] = useState(today);
  const [description, setDescription] = useState("");
  const [pending, setPending] = useState(false);

  function upload(files: FileList | File[] | null) {
    if (!files || files.length === 0) return;
    const formData = new FormData();
    formData.set("patient_id", String(patientId));
    formData.set("taken_at", date);
    formData.set("label", description);
    for (const f of Array.from(files)) formData.append("files", f);
    setPending(true);
    startTransition(async () => {
      await addImageGroupAction(formData);
      router.refresh();
      setPending(false);
      setDescription("");
      if (fileInputRef.current) fileInputRef.current.value = "";
    });
  }

  return (
    <div dir="ltr" className="space-y-2">
      <div className="flex gap-3 flex-wrap items-start">
        <label
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            upload(e.dataTransfer.files);
          }}
          className={`w-20 h-20 rounded-md border-2 border-dashed flex items-center justify-center cursor-pointer text-2xl text-muted transition-colors ${
            dragOver ? "border-primary bg-primary-soft" : "border-border hover:bg-primary-soft"
          } ${pending ? "opacity-60 pointer-events-none" : ""}`}
        >
          +
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*,.pdf"
            multiple
            className="hidden"
            onChange={(e) => upload(e.target.files)}
          />
        </label>
      </div>
      <div className="flex gap-3 flex-wrap items-end max-w-md">
        <div>
          <div className="text-[11px] text-muted mb-1">Date</div>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="rounded-md border border-border bg-background px-2 py-1 text-xs"
          />
        </div>
        <div className="flex-1 min-w-[160px]">
          <div className="text-[11px] text-muted mb-1">Description (Optional)</div>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Eg.: Panorama"
            className="w-full rounded-md border border-border bg-background px-2 py-1 text-xs"
          />
        </div>
      </div>
    </div>
  );
}
