import { db } from "./db/client";
import type { Role } from "./auth";

// نظام صلاحيات مرن: كل مفتاح صلاحية له قيمة افتراضية حسب دور المستخدم (role)،
// وأي صف في user_permissions بيبقى "استثناء" (override) فوق الافتراضي ده.
// غياب الصف = استخدم افتراضي الدور. الأدمن مينفعش تتغيّر صلاحياته (دايمًا كل حاجة).
export const PERMISSION_DEFS = [
  { key: "reports_full", label: "عرض كل التقارير (كل الأطباء وكل الفترات)" },
  { key: "reports_own", label: "عرض تقريره الشخصي بس (للدكتور)" },
  { key: "collect_payments", label: "تحصيل المدفوعات من الاستقبال" },
  { key: "manage_inventory", label: "إدارة المخزون" },
  { key: "manage_expenses", label: "إدارة المصروفات والمرتبات" },
  { key: "manage_settings", label: "الوصول لصفحة الإعدادات" },
] as const;

export type PermissionKey = (typeof PERMISSION_DEFS)[number]["key"];

export const ROLE_DEFAULT_PERMISSIONS: Record<Role, PermissionKey[]> = {
  admin: ["reports_full", "collect_payments", "manage_inventory", "manage_expenses", "manage_settings"],
  clinic_manager: ["reports_full", "manage_inventory"],
  accountant: ["reports_full", "collect_payments", "manage_expenses"],
  reception: ["collect_payments"],
  doctor: ["reports_own"],
};

export async function getPermissionOverrides(userId: number): Promise<Record<string, boolean>> {
  const rows = await db
    .selectFrom("user_permissions")
    .select(["permission_key", "granted"])
    .where("user_id", "=", userId)
    .execute();
  return Object.fromEntries(rows.map((r) => [r.permission_key, r.granted === 1]));
}

export async function hasPermission(userId: number, role: Role, key: PermissionKey): Promise<boolean> {
  if (role === "admin") return true; // الأدمن دايمًا عنده كل الصلاحيات، مش قابل للتقييد.
  const row = await db
    .selectFrom("user_permissions")
    .select("granted")
    .where("user_id", "=", userId)
    .where("permission_key", "=", key)
    .executeTakeFirst();
  if (row) return row.granted === 1;
  return ROLE_DEFAULT_PERMISSIONS[role]?.includes(key) ?? false;
}

export async function setPermissionOverride(userId: number, key: string, granted: boolean) {
  await db
    .insertInto("user_permissions")
    .values({ user_id: userId, permission_key: key, granted: granted ? 1 : 0 })
    .onConflict((oc) => oc.columns(["user_id", "permission_key"]).doUpdateSet({ granted: granted ? 1 : 0 }))
    .execute();
}

// رجوع الصلاحية لوضعها الافتراضي (حسب الدور) بحذف الاستثناء.
export async function clearPermissionOverride(userId: number, key: string) {
  await db.deleteFrom("user_permissions").where("user_id", "=", userId).where("permission_key", "=", key).execute();
}
