import { db } from "./db/client";

export const SETTINGS_DEFAULTS = {
  slot_minutes: "15", // وحدة الزمن الافتراضية للعيادة (طول فترة الموعد بالدقايق)
  day_start: "09:00",
  day_end: "22:00",
  // أرقام أيام الأسبوع اللي العيادة إجازة فيها، مفصولة بفاصلة (0=الأحد ... 6=السبت).
  holiday_weekdays: "",
  // أقصى عدد أيام رجوع بالتاريخ يقدر الدكتور (غير صاحب الصلاحية الكاملة) يشوف تقريره الشخصي فيها.
  // قابل للتغيير من "إعدادات الصلاحيات" بدل ما يكون رقم ثابت بالكود.
  doctor_report_max_days: "60",
};

export const WEEKDAY_LABELS = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];

export type SettingKey = keyof typeof SETTINGS_DEFAULTS;

export async function getSetting(key: SettingKey): Promise<string> {
  const row = await db.selectFrom("clinic_settings").select("value").where("key", "=", key).executeTakeFirst();
  return row?.value ?? SETTINGS_DEFAULTS[key];
}

export async function getAllSettings(): Promise<Record<SettingKey, string>> {
  const rows = await db.selectFrom("clinic_settings").selectAll().execute();
  const map = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  return { ...SETTINGS_DEFAULTS, ...map } as Record<SettingKey, string>;
}

export async function setSetting(key: SettingKey, value: string) {
  await db
    .insertInto("clinic_settings")
    .values({ key, value })
    .onConflict((oc) => oc.column("key").doUpdateSet({ value }))
    .execute();
}

// Generates ["09:00", "09:15", "09:30", ...] between start/end using the clinic's configured slot length.
export function buildTimeSlots(startTime: string, endTime: string, slotMinutes: number): string[] {
  const slots: string[] = [];
  const [sh, sm] = startTime.split(":").map(Number);
  const [eh, em] = endTime.split(":").map(Number);
  let cursor = sh * 60 + sm;
  const end = eh * 60 + em;
  const step = Math.max(5, slotMinutes || 15);
  while (cursor <= end) {
    const h = String(Math.floor(cursor / 60)).padStart(2, "0");
    const m = String(cursor % 60).padStart(2, "0");
    slots.push(`${h}:${m}`);
    cursor += step;
  }
  return slots;
}
