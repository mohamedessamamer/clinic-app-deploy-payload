import Database from "better-sqlite3";
import { Kysely, SqliteDialect } from "kysely";
import fs from "node:fs";
import path from "node:path";
import type { Database as DB } from "./types";

const DB_PATH = process.env.CLINIC_DB_PATH || path.join(process.cwd(), "data", "clinic.db");

// Ensure the data directory exists (works for local disk in dev; a real deployment
// on the VPS would point CLINIC_DB_PATH at a persistent volume).
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const sqlite = new Database(DB_PATH);
sqlite.pragma("journal_mode = WAL");
sqlite.pragma("foreign_keys = ON");
// Under Next.js/Turbopack, this module can end up evaluated by more than one
// route chunk/process around the same time, so multiple connections may hit the
// startup migrations below concurrently. Give a busy connection a chance to wait
// for the writer lock instead of throwing SQLITE_BUSY immediately.
sqlite.pragma("busy_timeout = 10000");

// Lightweight migrations for columns added after the initial CREATE TABLE.
// SQLite has no "ADD COLUMN IF NOT EXISTS", so we just swallow the duplicate-column error.
function tryAddColumn(table: string, ddl: string) {
  try {
    sqlite.exec(`ALTER TABLE ${table} ADD COLUMN ${ddl}`);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    if (!message.includes("duplicate column name")) throw err;
  }
}

// Rebuilds `table` from `createFixedTableSql` (which must CREATE TABLE `${table}_fixed`)
// if and only if its current schema still references the now-nonexistent "users_old"
// table (see the long comment on the users-table rebuild below for how that happens).
// Same "build under a new name, drop the old, rename into place" pattern — safe even
// if this table is itself referenced elsewhere, since we never rename the live table away.
function repairDanglingUsersOldReference(table: string, createFixedTableSql: string) {
  const row = sqlite.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name=?").get(table) as
    | { sql: string }
    | undefined;
  if (!row || !row.sql.includes("users_old")) return;

  sqlite.exec(`DROP TABLE IF EXISTS ${table}_fixed;`);
  sqlite.exec(createFixedTableSql);
  sqlite.exec(`
    INSERT INTO ${table}_fixed SELECT * FROM ${table};
    DROP TABLE ${table};
    ALTER TABLE ${table}_fixed RENAME TO ${table};
  `);
}

// All startup migrations run inside a single BEGIN IMMEDIATE transaction so that
// if two connections (e.g. two route chunks initializing concurrently on first
// request) reach this code at the same time, the second one blocks until the
// first commits, then re-checks conditions against the now-migrated schema
// instead of racing on multi-statement DDL like the users-table rebuild below.
function runStartupMigrations() {
  // The users-table rebuild below drops and recreates "users" (see the comment further
  // down). SQLite refuses to drop a table that other tables have *live rows* referencing
  // via foreign key (visits.created_by, audit_log.changed_by, user_permissions.user_id) —
  // not just a schema check, an actual data check — so once the clinic has any real visits/
  // audit/permission rows this would otherwise hard-fail (and crash-loop on every restart,
  // since the migration never completes). FK enforcement can only be toggled outside a
  // transaction, so it's off for this whole function and restored in the finally below.
  sqlite.pragma("foreign_keys = OFF");
  sqlite.exec("BEGIN IMMEDIATE");
  try {
    // Run schema.sql once at startup — idempotent (CREATE TABLE IF NOT EXISTS).
    const schemaPath = path.join(process.cwd(), "src", "lib", "db", "schema.sql");
    if (fs.existsSync(schemaPath)) {
      sqlite.exec(fs.readFileSync(schemaPath, "utf-8"));
    }

    tryAddColumn("invoices", "discount_percent REAL NOT NULL DEFAULT 0");
    tryAddColumn("invoices", "price_overridden INTEGER NOT NULL DEFAULT 0");
    tryAddColumn("services", "code TEXT");
    tryAddColumn("services", "prepaid INTEGER NOT NULL DEFAULT 0");

    // users.role was created with CHECK (role IN ('admin','doctor','reception','accountant')).
    // SQLite can't ALTER a CHECK constraint in place, so adding 'clinic_manager' requires a
    // table rebuild. Done once, guarded by checking sqlite_master for the old constraint text
    // — re-checked here, inside the write lock, so a second concurrent connection sees the
    // already-migrated schema and skips this block instead of racing on it.
    //
    // IMPORTANT: we build the replacement under a fresh name (users_new), copy into it, drop
    // the old "users" table, then rename the replacement into place — we never rename the
    // still-referenced "users" table away. SQLite's ALTER TABLE RENAME auto-rewrites *other*
    // tables' foreign-key definitions to point at the new name (e.g. visits.created_by
    // REFERENCES users(id) silently becomes REFERENCES "users_old"(id)), and that rewrite
    // sticks permanently even after users_old is dropped and "users" exists again — a real
    // bug we hit and verified locally with visits/audit_log/user_permissions. Renaming the
    // *new* table into place instead avoids ever touching the name other tables reference.
    const usersTableSql = sqlite
      .prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='users'")
      .get() as { sql: string } | undefined;
    if (usersTableSql && usersTableSql.sql.includes("'admin','doctor','reception','accountant'")) {
      sqlite.exec(`DROP TABLE IF EXISTS users_new;`);
      sqlite.exec(`
        CREATE TABLE users_new (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT NOT NULL UNIQUE,
          password_hash TEXT NOT NULL,
          full_name TEXT NOT NULL,
          role TEXT NOT NULL CHECK (role IN ('admin','doctor','reception','accountant','clinic_manager')),
          doctor_id INTEGER REFERENCES doctors(id),
          active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        INSERT INTO users_new SELECT * FROM users;
        DROP TABLE users;
        ALTER TABLE users_new RENAME TO users;
      `);
    }

    // One-time repair for databases that already went through the old (buggy) RENAME-based
    // migration above and got their FK text silently corrupted to reference "users_old".
    // Safe/no-op once repaired: each check only fires if the dangling reference is still there.
    repairDanglingUsersOldReference("visits", `
      CREATE TABLE visits_fixed (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_id INTEGER NOT NULL REFERENCES patients(id),
        visit_date TEXT NOT NULL DEFAULT (date('now')),
        service_id INTEGER REFERENCES services(id),
        notes TEXT,
        primary_doctor_id INTEGER REFERENCES doctors(id),
        performing_doctor_id INTEGER REFERENCES doctors(id),
        room_id INTEGER REFERENCES rooms(id),
        created_by INTEGER REFERENCES users(id),
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `);
    repairDanglingUsersOldReference("audit_log", `
      CREATE TABLE audit_log_fixed (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entity_type TEXT NOT NULL,
        entity_id INTEGER NOT NULL,
        field TEXT NOT NULL,
        old_value TEXT,
        new_value TEXT,
        reason TEXT,
        changed_by INTEGER REFERENCES users(id),
        changed_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `);
    repairDanglingUsersOldReference("user_permissions", `
      CREATE TABLE user_permissions_fixed (
        user_id INTEGER NOT NULL REFERENCES users(id),
        permission_key TEXT NOT NULL,
        granted INTEGER NOT NULL,
        PRIMARY KEY (user_id, permission_key)
      );
    `);

    sqlite.exec("COMMIT");
  } catch (err) {
    sqlite.exec("ROLLBACK");
    throw err;
  } finally {
    sqlite.pragma("foreign_keys = ON");
    // Belt-and-suspenders: confirm the rebuild above didn't actually leave any dangling
    // FK references (it shouldn't, but this is cheap and this data matters).
    const violations = sqlite.pragma("foreign_key_check");
    if (Array.isArray(violations) && violations.length > 0) {
      throw new Error(`Startup migration left dangling foreign keys: ${JSON.stringify(violations)}`);
    }
  }
}
runStartupMigrations();

export const db = new Kysely<DB>({
  dialect: new SqliteDialect({ database: sqlite }),
});

export const rawSqlite = sqlite;
