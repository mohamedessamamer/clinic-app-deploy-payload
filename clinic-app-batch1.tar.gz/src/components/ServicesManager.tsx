"use client";

import { useTransition } from "react";
import { addServiceAction, updateServiceAction } from "@/app/settings/actions";

type Service = {
  id: number;
  name: string;
  default_price: number;
  code: string | null;
  prepaid: number;
};

function ServiceRow({ service }: { service: Service }) {
  const [isPending, startTransition] = useTransition();

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        const form = e.currentTarget;
        const formData = new FormData(form);
        const newPrice = Number(formData.get("default_price"));
        if (newPrice !== service.default_price) {
          const ok = window.confirm(
            `هتغيّر سعر "${service.name}" من ${service.default_price} إلى ${newPrice}. متأكد؟`
          );
          if (!ok) return;
        }
        startTransition(() => {
          updateServiceAction(formData);
        });
      }}
      className="grid grid-cols-1 sm:grid-cols-5 gap-2 items-end border-b border-border pb-3"
    >
      <input type="hidden" name="id" value={service.id} />
      <div>
        <label className="block text-xs text-muted mb-1">اسم الخدمة</label>
        <input
          name="name"
          defaultValue={service.name}
          required
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
        />
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">السعر</label>
        <input
          name="default_price"
          type="number"
          step="0.01"
          defaultValue={service.default_price}
          required
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
        />
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">الكود</label>
        <input
          name="code"
          defaultValue={service.code || ""}
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
        />
      </div>
      <div className="flex items-center gap-2 pb-2">
        <input
          id={`prepaid-${service.id}`}
          name="prepaid"
          type="checkbox"
          defaultChecked={service.prepaid === 1}
          className="h-4 w-4"
        />
        <label htmlFor={`prepaid-${service.id}`} className="text-xs text-muted">
          تُدفع مقدمًا
        </label>
      </div>
      <button
        type="submit"
        disabled={isPending}
        className="rounded-md border border-border px-3 py-1.5 text-sm hover:bg-primary-soft disabled:opacity-60"
      >
        حفظ
      </button>
    </form>
  );
}

export default function ServicesManager({ services }: { services: Service[] }) {
  return (
    <div className="space-y-4">
      <div className="space-y-3">
        {services.map((s) => (
          <ServiceRow key={s.id} service={s} />
        ))}
        {services.length === 0 && <p className="text-sm text-muted">مفيش خدمات مسجلة لسه.</p>}
      </div>

      <form action={addServiceAction} className="grid grid-cols-1 sm:grid-cols-5 gap-2 items-end pt-2">
        <div>
          <label className="block text-xs text-muted mb-1">اسم الخدمة</label>
          <input name="name" required className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
        </div>
        <div>
          <label className="block text-xs text-muted mb-1">السعر</label>
          <input
            name="default_price"
            type="number"
            step="0.01"
            defaultValue={0}
            required
            className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs text-muted mb-1">الكود</label>
          <input name="code" className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
        </div>
        <div className="flex items-center gap-2 pb-2">
          <input id="prepaid-new" name="prepaid" type="checkbox" className="h-4 w-4" />
          <label htmlFor="prepaid-new" className="text-xs text-muted">
            تُدفع مقدمًا
          </label>
        </div>
        <button
          type="submit"
          className="rounded-md bg-primary text-white px-3 py-1.5 text-sm font-medium hover:bg-primary-dark"
        >
          + إضافة خدمة
        </button>
      </form>
    </div>
  );
}
