"use client";

import { useState, useTransition } from "react";
import { clearExpensesDataAction } from "@/app/expenses/actions";

const CONFIRM_WORD = "مسح";

export default function ClearExpensesDataButton() {
  const [isPending, startTransition] = useTransition();
  const [open, setOpen] = useState(false);
  const [confirmText, setConfirmText] = useState("");

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="rounded-md border border-danger px-3 py-2 text-sm text-danger hover:bg-danger/10"
      >
        مسح كل بيانات المصروفات
      </button>
    );
  }

  return (
    <div className="card-3d rounded-xl border border-danger/40 p-4 space-y-3 w-full sm:w-auto">
      <p className="text-sm text-danger">
        هذا الإجراء يحذف نهائيًا كل المصروفات وكل كشوف رواتب HR (مسجَّلة أو مصروفة) وكل البنود المتكررة، من كل الفترات، ولا يمكن التراجع عنه. اكتب «{CONFIRM_WORD}» للتأكيد.
      </p>
      <div className="flex flex-wrap items-center gap-2">
        <input
          value={confirmText}
          onChange={(e) => setConfirmText(e.target.value)}
          placeholder={CONFIRM_WORD}
          className="rounded border border-border bg-background px-2 py-2 text-sm"
        />
        <button
          type="button"
          disabled={isPending || confirmText.trim() !== CONFIRM_WORD}
          className="rounded-md bg-danger px-3 py-2 text-sm text-white disabled:opacity-50"
          onClick={() => {
            startTransition(async () => {
              const result = await clearExpensesDataAction();
              if (!result.ok) {
                window.alert(result.reason ?? "لم يتم مسح البيانات.");
                return;
              }
              setOpen(false);
              setConfirmText("");
            });
          }}
        >
          {isPending ? "جاري المسح..." : "تأكيد المسح النهائي"}
        </button>
        <button
          type="button"
          disabled={isPending}
          className="rounded-md border border-border px-3 py-2 text-sm hover:bg-primary-soft"
          onClick={() => {
            setOpen(false);
            setConfirmText("");
          }}
        >
          إلغاء
        </button>
      </div>
    </div>
  );
}
