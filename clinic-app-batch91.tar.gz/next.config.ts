import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // رفع ملفات المرضى لم يعد يمر عبر Server Actions أو نسخة الـproxy المحفوظة
  // في الذاكرة؛ له endpoint متدفق إلى القرص، لذلك لا يحتاج حدًا مجمعًا هنا.
};

export default nextConfig;
