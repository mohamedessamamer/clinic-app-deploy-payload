export type PatientUploadProgress = {
  current: number;
  total: number;
  fileName: string;
};

type UploadOptions = {
  patientId: number;
  takenAt: string;
  label: string;
  files: File[];
  onProgress?: (progress: PatientUploadProgress) => void;
};

type UploadResponse = {
  ok?: boolean;
  complete?: boolean;
  groupId?: number;
  error?: string;
};

// أصغر من حد Nginx الافتراضي (1MB)، لذلك يظل الرفع يعمل حتى لو لم يضبط
// مزود الاستضافة client_max_body_size. كل جزء مستقل وقابل لإعادة المحاولة.
const CHUNK_SIZE = 512 * 1024;
const MAX_ATTEMPTS = 3;

function wait(milliseconds: number) {
  return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
}

function uploadError(response: Response, result: UploadResponse | null, fileName: string) {
  if (result?.error) return result.error;
  if (response.status === 413) return `الملف أكبر من الحد الذي يسمح به خادم الويب: ${fileName}`;
  if (response.status === 401) return "انتهت الجلسة. سجل الدخول ثم حاول مرة أخرى.";
  if (response.status === 403) return "ليس لديك صلاحية رفع صور المرضى.";
  if ([502, 503, 504].includes(response.status)) return "خدمة رفع الملفات غير متاحة مؤقتًا. حاول مرة أخرى.";
  return `تعذر رفع الملف (${response.status || "خطأ اتصال"}): ${fileName}`;
}

async function sendChunk(url: string, chunk: Blob, file: File) {
  let lastError: Error | null = null;
  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt += 1) {
    let response: Response;
    try {
      response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": file.type || "application/octet-stream",
          "X-File-Name": encodeURIComponent(file.name),
        },
        body: chunk,
        credentials: "same-origin",
      });
    } catch (reason) {
      lastError = reason instanceof Error ? reason : new Error(`تعذر رفع الملف: ${file.name}`);
      if (attempt < MAX_ATTEMPTS) await wait(attempt * 500);
      continue;
    }
    const result = await response.json().catch(() => null) as UploadResponse | null;
    if (response.ok && result?.ok) return result;
    lastError = new Error(uploadError(response, result, file.name));
    if (![408, 429, 502, 503, 504].includes(response.status)) throw lastError;
    if (attempt < MAX_ATTEMPTS) await wait(attempt * 500);
  }
  throw lastError || new Error(`تعذر رفع الملف: ${file.name}`);
}

// كل ملف يُرفع بالتتابع في أجزاء صغيرة. بهذا لا يتم تجميع الصور أو الأشعة في
// ذاكرة المتصفح/السيرفر، ولا يتعطل الرفع بسبب حد حجم الطلب في Nginx.
export async function uploadPatientFiles({ patientId, takenAt, label, files, onProgress }: UploadOptions) {
  let groupId: number | null = null;
  for (let index = 0; index < files.length; index += 1) {
    const file = files[index];
    onProgress?.({ current: index + 1, total: files.length, fileName: file.name });
    const uploadId = crypto.randomUUID();
    const chunkCount = Math.max(1, Math.ceil(file.size / CHUNK_SIZE));
    let completedGroupId: number | null = null;

    for (let chunkIndex = 0; chunkIndex < chunkCount; chunkIndex += 1) {
      const params = new URLSearchParams({
        patientId: String(patientId),
        takenAt,
        label,
        uploadId,
        chunkIndex: String(chunkIndex),
        chunkCount: String(chunkCount),
        fileSize: String(file.size),
      });
      if (groupId != null) params.set("groupId", String(groupId));
      const start = chunkIndex * CHUNK_SIZE;
      const chunk = file.slice(start, Math.min(start + CHUNK_SIZE, file.size), file.type);
      const result = await sendChunk(`/api/patient-files/upload?${params.toString()}`, chunk, file);
      if (result.complete && result.groupId) completedGroupId = result.groupId;
    }

    if (!completedGroupId) throw new Error(`لم يكتمل حفظ الملف: ${file.name}`);
    groupId = completedGroupId;
  }
  return groupId;
}
