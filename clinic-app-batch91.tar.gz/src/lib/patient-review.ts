import "server-only";
import crypto from "node:crypto";
import { db } from "@/lib/db/client";
import { getAllSettings } from "@/lib/settings";

const hash = (token: string) => crypto.createHash("sha256").update(token).digest("hex");

export async function issuePatientReviewLink(appointmentId: number) {
  const existing = await db.selectFrom("patient_review_invites").select("token_hash").where("appointment_id", "=", appointmentId).executeTakeFirst();
  const token = crypto.randomBytes(32).toString("base64url");
  const tokenHash = hash(token);
  const appointment = await db.selectFrom("appointments").select(["patient_id", "doctor_id"]).where("id", "=", appointmentId).executeTakeFirstOrThrow();
  const expiresAt = new Date(Date.now() + 90 * 86400000).toISOString();
  if (existing) await db.deleteFrom("patient_review_invites").where("appointment_id", "=", appointmentId).execute();
  await db.insertInto("patient_review_invites").values({ token_hash: tokenHash, appointment_id: appointmentId, patient_id: appointment.patient_id, doctor_id: appointment.doctor_id, expires_at: expiresAt }).execute();
  const settings = await getAllSettings();
  return { token, url: `${settings.clinic_public_url.replace(/\/$/, "")}/review/${token}` };
}

export async function getPatientReviewState(token: string) {
  const tokenHash = hash(token);
  const submitted = await db.selectFrom("patient_reviews").select("id").where("token_hash", "=", tokenHash).executeTakeFirst();
  if (submitted) return { state: "submitted" as const };
  const invite = await db.selectFrom("patient_review_invites").innerJoin("patients", "patients.id", "patient_review_invites.patient_id").innerJoin("doctors", "doctors.id", "patient_review_invites.doctor_id").innerJoin("appointments", "appointments.id", "patient_review_invites.appointment_id").select(["patient_review_invites.appointment_id", "patient_review_invites.patient_id", "patient_review_invites.doctor_id", "patient_review_invites.expires_at", "patients.full_name as patientName", "doctors.full_name as doctorName", "appointments.appointment_date as visitDate"]).where("patient_review_invites.token_hash", "=", tokenHash).executeTakeFirst();
  if (!invite) return { state: "invalid" as const };
  if (new Date(invite.expires_at).getTime() < Date.now()) return { state: "expired" as const };
  return { state: "ok" as const, invite };
}

export async function submitPatientReview(token: string, rating: number, comment: string, anonymous: boolean) {
  const state = await getPatientReviewState(token);
  if (state.state !== "ok") return { ok: false, error: state.state === "submitted" ? "تم إرسال هذا التقييم من قبل." : "الرابط غير صالح أو انتهت صلاحيته." };
  const tokenHash = hash(token);
  await db.transaction().execute(async (trx) => {
    await trx.insertInto("patient_reviews").values({ token_hash: tokenHash, appointment_id: anonymous ? null : state.invite.appointment_id, patient_id: anonymous ? null : state.invite.patient_id, doctor_id: state.invite.doctor_id, visit_date: state.invite.visitDate, anonymous: anonymous ? 1 : 0, rating, comment: comment || null }).execute();
    await trx.deleteFrom("patient_review_invites").where("token_hash", "=", tokenHash).execute();
  });
  return { ok: true };
}
