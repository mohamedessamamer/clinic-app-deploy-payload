import "server-only";
import { db } from "@/lib/db/client";
import { getAllSettings } from "@/lib/settings";
import { issueAppointmentLink } from "@/lib/appointment-self-service";
import { issuePatientReviewLink } from "@/lib/patient-review";
import { getActiveAccount, getAccountAccessToken } from "@/lib/whatsapp/store";
import { sendAppointmentReminderTemplate, sendGenericTemplate } from "@/lib/whatsapp/graph";
import { formatArabicAppointmentDate, formatArabicAppointmentTime } from "@/lib/whatsapp/manual-templates";

const sqlNow = () => new Date().toISOString().replace("T", " ").slice(0, 19);
const cairoParts = () => Object.fromEntries(new Intl.DateTimeFormat("en-CA", { timeZone: "Africa/Cairo", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(new Date()).map((part) => [part.type, part.value]));
const addDays = (date: string, days: number) => { const [y, m, d] = date.split("-").map(Number); return new Date(Date.UTC(y, m - 1, d + days)).toISOString().slice(0, 10); };
const whatsappNumber = (country: string, local: string) => `${country.replace(/\D/g, "")}${local.replace(/\D/g, "").replace(/^0+/, "")}`;
type Candidate = { id: number; appointment_date: string; start_time: string; completed_at: string | null; patient_name: string; phone: string | null; phone_country_code: string; doctor_name: string };
let running = false;

function bodyParameters(bodyText: string, rawMap: string, values: Record<string, string>) {
  let map: Record<string, string> = {}; try { map = JSON.parse(rawMap || "{}"); } catch {}
  const count = Math.max(0, ...Array.from(bodyText.matchAll(/\{\{(\d+)\}\}/g), (m) => Number(m[1])));
  return Array.from({ length: count }, (_, index) => values[map[String(index + 1)]] || "—");
}

export async function processDueAppointmentReminders() {
  if (running) return; running = true;
  try {
    const [account, settings] = await Promise.all([getActiveAccount(), getAllSettings()]);
    let rules = await db.selectFrom("whatsapp_automation_rules").innerJoin("whatsapp_message_templates", "whatsapp_message_templates.id", "whatsapp_automation_rules.template_id").select(["whatsapp_automation_rules.id", "whatsapp_automation_rules.trigger_type", "whatsapp_automation_rules.day_offset", "whatsapp_automation_rules.send_time", "whatsapp_automation_rules.delay_minutes", "whatsapp_automation_rules.variable_map", "whatsapp_message_templates.name as template_name", "whatsapp_message_templates.language", "whatsapp_message_templates.body_text"]).where("whatsapp_automation_rules.active", "=", 1).where("whatsapp_message_templates.status", "=", "approved").execute();
    if (!rules.length) {
      const anyRule = await db.selectFrom("whatsapp_automation_rules").select("id").executeTakeFirst();
      const template = anyRule ? null : await db.selectFrom("whatsapp_message_templates").select("id").where("name", "=", settings.whatsapp_reminder_template_name).where("status", "=", "approved").executeTakeFirst();
      if (template) {
        await db.insertInto("whatsapp_automation_rules").values({ name: "تأكيد موعد اليوم التالي", template_id: template.id, trigger_type: "appointment_relative", day_offset: -1, send_time: settings.whatsapp_reminder_time, variable_map: JSON.stringify({ 1: "patient_name", 2: "appointment_date", 3: "appointment_time", 4: "doctor_name" }) }).execute();
        rules = await db.selectFrom("whatsapp_automation_rules").innerJoin("whatsapp_message_templates", "whatsapp_message_templates.id", "whatsapp_automation_rules.template_id").select(["whatsapp_automation_rules.id", "whatsapp_automation_rules.trigger_type", "whatsapp_automation_rules.day_offset", "whatsapp_automation_rules.send_time", "whatsapp_automation_rules.delay_minutes", "whatsapp_automation_rules.variable_map", "whatsapp_message_templates.name as template_name", "whatsapp_message_templates.language", "whatsapp_message_templates.body_text"]).where("whatsapp_automation_rules.active", "=", 1).where("whatsapp_message_templates.status", "=", "approved").execute();
      }
    }
    if (!account || account.connection_status !== "connected" || !rules.length) return;
    const accessToken = await getAccountAccessToken(account.id); const parts = cairoParts(); const today = `${parts.year}-${parts.month}-${parts.day}`; const nowMinute = Number(parts.hour) * 60 + Number(parts.minute);
    for (const rule of rules) {
      let candidates: Candidate[] = [];
      if (rule.trigger_type === "appointment_relative") {
        const [h, m] = rule.send_time.split(":").map(Number); if (nowMinute < h * 60 + m) continue;
        const appointmentDate = addDays(today, -rule.day_offset);
        candidates = await db.selectFrom("appointments").innerJoin("patients", "patients.id", "appointments.patient_id").innerJoin("doctors", "doctors.id", "appointments.doctor_id").select(["appointments.id", "appointments.appointment_date", "appointments.start_time", "appointments.completed_at", "patients.full_name as patient_name", "patients.phone", "patients.phone_country_code", "doctors.full_name as doctor_name"]).where("appointments.appointment_date", "=", appointmentDate).where("appointments.status", "=", "booked").execute();
      } else {
        candidates = await db.selectFrom("appointments").innerJoin("patients", "patients.id", "appointments.patient_id").innerJoin("doctors", "doctors.id", "appointments.doctor_id").select(["appointments.id", "appointments.appointment_date", "appointments.start_time", "appointments.completed_at", "patients.full_name as patient_name", "patients.phone", "patients.phone_country_code", "doctors.full_name as doctor_name"]).where("appointments.status", "=", "done").where("appointments.completed_at", "is not", null).execute();
        candidates = candidates.filter((item) => item.completed_at && Date.now() >= new Date(item.completed_at).getTime() + rule.delay_minutes * 60000);
      }
      for (const item of candidates) {
        const scheduledFor = rule.trigger_type === "appointment_relative" ? `${today} ${rule.send_time}:00` : item.completed_at!;
        const claim = await db.insertInto("whatsapp_automation_deliveries").values({ rule_id: rule.id, appointment_id: item.id, scheduled_for: scheduledFor }).onConflict((oc) => oc.columns(["rule_id", "appointment_id"]).doNothing()).executeTakeFirst();
        if (Number(claim.numInsertedOrUpdatedRows || 0) === 0) continue;
        if (!item.phone) { await db.updateTable("whatsapp_automation_deliveries").set({ status: "failed", error_message: "لا يوجد رقم هاتف" }).where("rule_id", "=", rule.id).where("appointment_id", "=", item.id).execute(); continue; }
        try {
          const mappedVariables = Object.values(JSON.parse(rule.variable_map || "{}")) as string[];
          const appointmentLink = rule.template_name === settings.whatsapp_reminder_template_name || mappedVariables.includes("appointment_link") ? await issueAppointmentLink(item.id, "automatic") : null;
          const reviewLink = mappedVariables.includes("review_link") ? await issuePatientReviewLink(item.id) : null;
          if (rule.template_name === settings.whatsapp_reminder_template_name) {
            await sendAppointmentReminderTemplate({ phoneNumberId: account.phone_number_id, accessToken, to: whatsappNumber(item.phone_country_code, item.phone), templateName: rule.template_name, language: rule.language, patientName: item.patient_name, date: formatArabicAppointmentDate(item.appointment_date), time: formatArabicAppointmentTime(item.start_time), doctorName: item.doctor_name, token: appointmentLink!.rawToken });
          } else {
            const values = { patient_name: item.patient_name, appointment_date: formatArabicAppointmentDate(item.appointment_date), appointment_time: formatArabicAppointmentTime(item.start_time), doctor_name: item.doctor_name, appointment_link: appointmentLink ? `${settings.clinic_public_url.replace(/\/$/, "")}/appointment/manage/${appointmentLink.rawToken}` : "", review_link: reviewLink?.url || "" };
            await sendGenericTemplate({ phoneNumberId: account.phone_number_id, accessToken, to: whatsappNumber(item.phone_country_code, item.phone), templateName: rule.template_name, language: rule.language, bodyParameters: bodyParameters(rule.body_text, rule.variable_map, values) });
          }
          await db.updateTable("whatsapp_automation_deliveries").set({ status: "sent", sent_at: sqlNow(), error_message: null }).where("rule_id", "=", rule.id).where("appointment_id", "=", item.id).execute();
        } catch (error) { await db.updateTable("whatsapp_automation_deliveries").set({ status: "failed", error_message: error instanceof Error ? error.message.slice(0, 500) : "فشل الإرسال" }).where("rule_id", "=", rule.id).where("appointment_id", "=", item.id).execute(); }
      }
    }
  } finally { running = false; }
}

export function startAppointmentReminderScheduler() {
  const globalScheduler = globalThis as typeof globalThis & { __clinicReminderTimer?: ReturnType<typeof setInterval> };
  if (globalScheduler.__clinicReminderTimer) return;
  const timer = setInterval(() => processDueAppointmentReminders().catch((error) => console.error("[whatsapp-automation]", error instanceof Error ? error.message : error)), 60_000); timer.unref?.(); globalScheduler.__clinicReminderTimer = timer;
  setTimeout(() => processDueAppointmentReminders().catch(() => undefined), 5_000).unref?.();
}
