"use client";

export function preferredWhatsAppUrl(url: string) {
  if (/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent)) return url;
  try {
    const parsed = new URL(url);
    if (parsed.hostname !== "wa.me") return url;
    const phone = parsed.pathname.replace(/^\/+/, "");
    const text = parsed.searchParams.get("text") || "";
    return `https://web.whatsapp.com/send?phone=${encodeURIComponent(phone)}&text=${encodeURIComponent(text)}`;
  } catch {
    return url;
  }
}

export function reserveWhatsAppWindow() {
  const popup = window.open("about:blank", "clinic_whatsapp");
  if (popup) popup.opener = null;
  return popup;
}

export function navigateWhatsAppWindow(popup: Window | null, url: string) {
  const target = preferredWhatsAppUrl(url);
  if (popup && !popup.closed) {
    popup.location.href = target;
    popup.focus();
  } else {
    window.location.href = target;
  }
}

export function openWhatsAppWindow(url: string) {
  const popup = window.open(preferredWhatsAppUrl(url), "clinic_whatsapp");
  popup?.focus();
  return popup;
}
