import "server-only";
import { WEEKDAY_LABELS, weekdayOf } from "@/lib/settings";

export type ManualTemplateContext = {
  patientName: string;
  appointmentDate: string;
  appointmentTime: string;
  doctorName: string;
  appointmentLink: string;
  patientDebt: number;
  contactName: string;
  reviewLink: string;
};

export const MANUAL_VARIABLE_LABELS: Record<string, string> = {
  patient_name: "اسم المريض",
  appointment_date: "اليوم والتاريخ",
  appointment_time: "الساعة",
  doctor_name: "اسم الطبيب",
  appointment_link: "رابط تأكيد/تعديل الموعد",
  patient_debt: "مديونية المريض",
  contact_name: "اسم التواصل",
  review_link: "رابط تقييم الزيارة",
};

export function formatArabicAppointmentDate(date: string) {
  const [, month, day] = date.split("-");
  return `يوم ${WEEKDAY_LABELS[weekdayOf(date)]} ${Number(day)}-${Number(month)}-${date.slice(0, 4)}`;
}

export function formatArabicAppointmentTime(time: string) {
  const [hours, minutes] = time.slice(0, 5).split(":").map(Number);
  const hour = hours % 12 || 12;
  const suffix = hours < 12 ? "صباحًا" : "مساءً";
  return `${hour}${minutes ? `:${String(minutes).padStart(2, "0")}` : ""} ${suffix}`;
}

export function renderManualTemplate(header: string | null, body: string, rawMap: string, context: ManualTemplateContext) {
  let map: Record<string, string> = {};
  try { map = JSON.parse(rawMap) as Record<string, string>; } catch { map = {}; }
  const values: Record<string, string> = {
    patient_name: context.patientName,
    appointment_date: formatArabicAppointmentDate(context.appointmentDate),
    appointment_time: formatArabicAppointmentTime(context.appointmentTime),
    doctor_name: context.doctorName,
    appointment_link: context.appointmentLink,
    patient_debt: context.patientDebt.toFixed(0),
    contact_name: context.contactName,
    review_link: context.reviewLink,
  };
  const replace = (text: string) => text.replace(/\{\{(\d+)\}\}/g, (_, index: string) => values[map[index]] ?? `{{${index}}}`);
  // اسم التواصل متاح كمتغير اختياري داخل القالب، لكنه لا يُضاف كتوقيع
  // تلقائيًا حتى لا تظهر أسماء الأدوار أو المستخدمين أسفل كل رسالة.
  return [header ? `*${replace(header)}*` : "", replace(body)].filter(Boolean).join("\n");
}
