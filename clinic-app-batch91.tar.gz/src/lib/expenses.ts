import "server-only";
import { db } from "./db/client";

export const EXPENSE_CATEGORIES = [
  "salary",
  "fixed",
  "petty",
  "inventory_general",
  "inventory_orthodontic",
  "lab",
  "other",
] as const;

export type ExpenseCategory = (typeof EXPENSE_CATEGORIES)[number];

export const EXPENSE_CATEGORY_LABELS: Record<ExpenseCategory, string> = {
  salary: "مرتبات",
  fixed: "مصاريف ثابتة",
  petty: "مصروفات نثرية",
  inventory_general: "خامات عامة",
  inventory_orthodontic: "خامات تقويم",
  lab: "معامل",
  other: "أخرى",
};

export function isExpenseCategory(value: string): value is ExpenseCategory {
  return (EXPENSE_CATEGORIES as readonly string[]).includes(value);
}

export function monthBounds(month: string): { from: string; to: string } | null {
  if (!/^\d{4}-\d{2}$/.test(month)) return null;
  const [year, monthNumber] = month.split("-").map(Number);
  if (monthNumber < 1 || monthNumber > 12) return null;
  const lastDay = new Date(Date.UTC(year, monthNumber, 0)).getUTCDate();
  return { from: `${month}-01`, to: `${month}-${String(lastDay).padStart(2, "0")}` };
}

export async function getExpenseSummary(from: string, to: string) {
  const rows = await db
    .selectFrom("expenses")
    .select(["category", "amount"])
    .where("expense_date", ">=", from)
    .where("expense_date", "<=", to)
    .execute();
  const byCategory = new Map<ExpenseCategory, number>();
  for (const row of rows) {
    if (!isExpenseCategory(row.category)) continue;
    byCategory.set(row.category, Math.round(((byCategory.get(row.category) ?? 0) + row.amount) * 100) / 100);
  }
  const total = Math.round(rows.reduce((sum, row) => sum + row.amount, 0) * 100) / 100;
  return { total, byCategory };
}

// البنود المتكررة تُنشأ تلقائيًا عند فتح شهر كامل بدل زر «تسجيل في هذا
// الشهر». السجل الناتج يظل قابلًا للحذف/التصحيح مثل أي مصروف متكرر قديم.
export async function ensureRecurringExpensesForMonth(month: string, createdBy: number) {
  const range = monthBounds(month);
  if (!range) return;
  const templates = await db.selectFrom("expense_templates").selectAll().where("active", "=", 1).execute();
  for (const template of templates) {
    // مرتبات الأشخاص أصبحت تُحسب وتُصرف من HR؛ لا ننشئها مرة ثانية من بند
    // متكرر قديم حتى لا يتكرر نفس الراتب في المصروفات.
    if (template.category === "salary") continue;
    if (template.effective_from && template.effective_from > range.to) continue;
    if (template.effective_to && template.effective_to < range.from) continue;
    const existing = await db.selectFrom("expenses").select("id").where("template_id", "=", template.id).where("expense_date", ">=", range.from).where("expense_date", "<=", range.to).executeTakeFirst();
    if (existing) continue;
    const expenseDate = template.effective_from && template.effective_from > range.from ? template.effective_from : range.from;
    await db.insertInto("expenses").values({ expense_date: expenseDate, category: template.category, title: template.title, payee: template.payee, amount: template.default_amount, payment_method: null, note: template.note, source_type: "template", source_id: null, template_id: template.id, doctor_id: null, patient_id: null, service_id: null, affects_commission: 0, created_by: createdBy }).execute();
  }
}
