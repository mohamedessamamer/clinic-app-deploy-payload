import "server-only";
import { db } from "./db/client";
export { calculateHrPayroll, progressiveTargetTotal } from "./hr-payroll-math";
export type { HrRule } from "./hr-payroll-math";
import { calculateCollectedAfterAutomaticLab } from "./hr-payroll-math";

function round2(value: number) {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

export async function getCollectedAfterLab(from: string, to: string, doctorId: number | null) {
  let rootsQuery = db
    .selectFrom("invoices")
    .leftJoin("services", "services.id", "invoices.service_id")
    .select(["invoices.paid", "invoices.amount as invoice_amount", "services.lab_cost"])
    .where("invoices.parent_invoice_id", "is", null)
    .where("invoices.invoice_date", ">=", from)
    .where("invoices.invoice_date", "<=", to);
  if (doctorId != null) rootsQuery = rootsQuery.where("invoices.doctor_id", "=", doctorId);

  let followupsQuery = db
    .selectFrom("invoices")
    .innerJoin("invoices as parent_invoices", "parent_invoices.id", "invoices.parent_invoice_id")
    .leftJoin("services", "services.id", "parent_invoices.service_id")
    .select(["invoices.paid", "parent_invoices.amount as invoice_amount", "services.lab_cost"])
    .where("invoices.parent_invoice_id", "is not", null)
    .where("invoices.invoice_date", ">=", from)
    .where("invoices.invoice_date", "<=", to);
  if (doctorId != null) followupsQuery = followupsQuery.where("parent_invoices.doctor_id", "=", doctorId);

  let manualQuery = db
    .selectFrom("expenses")
    .select("amount")
    .where("category", "=", "lab")
    .where("affects_commission", "=", 1)
    .where("expense_date", ">=", from)
    .where("expense_date", "<=", to);
  if (doctorId != null) manualQuery = manualQuery.where("doctor_id", "=", doctorId);

  const [roots, followups, manualRows] = await Promise.all([rootsQuery.execute(), followupsQuery.execute(), manualQuery.execute()]);
  const payment = calculateCollectedAfterAutomaticLab([...roots, ...followups].map((row) => ({ paid: row.paid, invoiceAmount: row.invoice_amount, labCost: row.lab_cost ?? 0 })));
  const manualLab = round2(manualRows.reduce((sum, row) => sum + row.amount, 0));
  const labCost = round2(payment.automaticLab + manualLab);
  return { grossCollected: payment.grossCollected, automaticLab: payment.automaticLab, manualLab, labCost, netCollected: round2(Math.max(0, payment.grossCollected - labCost)) };
}
