import { getAppointmentManageState } from "@/lib/appointment-self-service";
import AppointmentManageClient from "@/components/AppointmentManageClient";
import type { Metadata } from "next";
import { getSetting } from "@/lib/settings";

export async function generateMetadata(): Promise<Metadata> {
  const publicUrl = (await getSetting("clinic_public_url")).replace(/\/$/, "");
  return {
    metadataBase: new URL(publicUrl),
    title: "إدارة موعد العيادة",
    description: "Designed around your comfort",
    robots: { index: false, follow: false },
    referrer: "no-referrer",
    openGraph: {
      title: "إدارة موعد العيادة",
      description: "Designed around your comfort",
      siteName: "Clinic Appointment",
      type: "website",
    },
  };
}

export default async function AppointmentManagePage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const state = await getAppointmentManageState(token);
  return <main className="min-h-screen bg-slate-50 p-4" dir="rtl"><div className="mx-auto mt-10 max-w-xl rounded-2xl bg-white p-6 shadow-lg">
    <h1 className="mb-5 text-center text-xl font-bold">إدارة موعدك</h1>
    {state.state !== "ok" ? <p className="rounded-lg bg-red-50 p-4 text-center text-red-800">{state.state === "expired" ? "انتهت صلاحية هذا الرابط. تواصل مع الاستقبال للحصول على رابط جديد." : "الرابط غير صحيح."}</p> : <>
      <div className="mb-5 rounded-xl bg-slate-50 p-4 text-sm"><p className="mb-3 text-base"><strong>أهلًا، {state.appointment.patientName}</strong></p><p><strong>الطبيب:</strong> {state.appointment.doctorName}</p><p><strong>الموعد الحالي:</strong> {state.appointment.date} — {state.appointment.time}</p></div>
      {state.appointment.responseStatus === "pending" ? <AppointmentManageClient token={token} doctorName={state.appointment.doctorName} /> : <p className="rounded-lg bg-primary-soft p-4 text-center text-primary-dark">{state.appointment.responseStatus === "confirmed" ? "تم تأكيد هذا الموعد." : state.appointment.responseStatus === "reschedule_pending" ? "تم حجز الموعد الجديد لك. برجاء التأكد من تفاصيل الموعد." : "تم اعتماد الموعد المعدل."}</p>}
    </>}
  </div></main>;
}
