"use server";

import { revalidatePath } from "next/cache";
import path from "node:path";
import fs from "node:fs/promises";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import type { Role } from "@/lib/auth";
import { findMatchingVisit } from "@/lib/visit-match";
import { FOLLOWUP_SERVICE_CODE } from "@/lib/followup";
import { isThreePartName, isValidBirthDate } from "@/lib/patient-details";
import { isValidPatientPhone, normalizePhoneNumber } from "@/lib/phone";

// الملف الطبي (سجل الزيارات) بقى مقصور على الدورين (لكل واحد نفسه) + الأدمن +
// مدير العيادة بس — الاستقبال/المحاسب اتمنعوا من الإضافة/التعديل هنا (اتسجل شكوى
// إن الملف الطبي كان بيظهر فيه محتوى مدخل من الاستقبال، وده المفروض يبقى سجل
// طبي بحت). الحماية دي لازم تكون في السيرفر نفسه مش بس إخفاء زرار في الواجهة.
function canEditMedicalRecordFor(role: string | undefined): boolean {
  return role === "doctor" || role === "admin" || role === "clinic_manager";
}

// استثناء ضيق واحد على القاعدة فوق: الاستقبال ممكن يتاخد له صلاحية "رفع صور
// فقط" (upload_ortho_photos) — بتفتح قسم Photos & X-rays بس (رفع/تدوير/حذف)
// من غير باقي الملف الطبي. دفعة 27 — طلب صريح إن الاستقبال يقدر يرفع صور في
// شارت التقويم. الفحص لازم يبقى هنا في السيرفر (مش بس إخفاء زرار في
// الواجهة)، زي نفس فلسفة الكومنت فوق بالظبط.
async function canManagePhotosFor(session: { userId: number; role: string } | null): Promise<boolean> {
  if (!session) return false;
  if (canEditMedicalRecordFor(session.role)) return true;
  return hasPermission(session.userId, session.role as Role, "upload_ortho_photos");
}

// بيسجل زيارة يدوية (من ملف المريض، مش عن طريق موعد في الجدول). الطبيب الأساسي
// (اللي بيتحسب له التحصيل المالي والمعالج المسجل في الملف الطبي) بيتحدد كالتالي:
// - لو المستخدم الحالي دكتور: هو نفسه دايمًا، حتى لو اتبعت حاجة تانية في الفورم
//   (الحماية دي في السيرفر مش بس في الواجهة).
// - غير كده (أدمن/مدير عيادة، الوحيدين اللي معاهم صلاحية الإضافة أصلاً): مش
//   اختيار حر — بيتحدد أوتوماتيك من موعد المريض المسجل من الاستقبال في نفس
//   تاريخ الزيارة (لو موجود)، عشان الاسم المسجل في الملف الطبي يطابق فعليًا مين
//   صاحب الحالة. لو مفيش حجز في اليوم ده (زيارة قديمة/تصحيح بيانات)، بيرجع
//   للاختيار اليدوي من الفورم.
// "مقدم الخدمة الفعلي" (performing_doctor_id، زي دكتور مساعد جه بدل صاحب الشيفت)
// ممكن يكون مختلف عن الطبيب الأساسي بس لو المستخدم عنده صلاحية override_visit_doctor
// — غير كده بيتساوى بيه دايمًا.
export async function addVisitAction(formData: FormData) {
  const patientId = Number(formData.get("patient_id"));
  const visit_date = String(formData.get("visit_date") || "").trim();
  const service_id = formData.get("service_id") ? Number(formData.get("service_id")) : null;
  const notes = String(formData.get("notes") || "").trim() || null;
  const session = await getSession();

  if (!patientId || !visit_date) return;
  if (!canEditMedicalRecordFor(session?.role)) return;

  const canOverrideDoctor = session ? await hasPermission(session.userId, session.role, "override_visit_doctor") : false;

  let primary_doctor_id: number | null;
  if (session?.role === "doctor" && session.doctorId) {
    primary_doctor_id = session.doctorId;
  } else {
    const todaysAppt = await db
      .selectFrom("appointments")
      .select(["doctor_id"])
      .where("patient_id", "=", patientId)
      .where("appointment_date", "=", visit_date)
      .where("status", "!=", "cancelled")
      .orderBy("start_time")
      .executeTakeFirst();
    primary_doctor_id = todaysAppt
      ? todaysAppt.doctor_id
      : formData.get("doctor_id")
        ? Number(formData.get("doctor_id"))
        : null;
  }

  const performingRaw = formData.get("performing_doctor_id");
  const explicitPerforming = canOverrideDoctor && performingRaw ? Number(performingRaw) || null : null;

  // دفعة 22 (متابعة تقرير ازدواجية الخدمات): قبل ما نسجل زيارة جديدة، ندوّر على
  // زيارة موجودة بالفعل لنفس (مريض/دكتور أساسي/تاريخ/خدمة) — ممكن تكون الاستقبال
  // سجلها الأول (من الملف المالي أو الجدول المركزي) قبل ما الطبيب يوصل لتفاصيل
  // المعالجة. لو لقينا واحدة، بنحدّث بس المعالجة (notes) والطبيب المساعد لو
  // اتحدد صراحة — من غير ما نلمس الفاتورة/المبالغ خالص (دي مسؤولية الاستقبال
  // مش الطبيب) ومن غير ما نعمل زيارة وفاتورة جديدتين مكررتين.
  if (service_id != null && primary_doctor_id != null) {
    const existingVisit = await findMatchingVisit({
      patientId,
      doctorId: primary_doctor_id,
      visitDate: visit_date,
      serviceId: service_id,
    });
    if (existingVisit) {
      await db
        .updateTable("visits")
        .set({
          notes,
          // دفعة 27 (P2.4): "المعالجة" هنا مكتوبة يدويًا من الطبيب في الملف الطبي
          // نفسه — لو كانت جاية قبل كده من مزامنة شارت التقويم، بقت دلوقتي نص
          // يدوي حقيقي، فالمزامنة مايجيش يمسحها/يستبدلها تاني لحد ما يتغيّر
          // مصدرها فعليًا من شارت التقويم.
          notes_synced_from_ortho: 0,
          performing_doctor_id: explicitPerforming ?? existingVisit.performing_doctor_id,
        })
        .where("id", "=", existingVisit.id)
        .execute();

      revalidatePath(`/patients/${patientId}`);
      revalidatePath("/invoices");
      return;
    }
  }

  const performing_doctor_id = explicitPerforming ?? primary_doctor_id;

  // دفعة 24 (تقرير ازدواجية جديد): خدمة "متابعة" (كود 0) لازم تتسجل بس عن طريق
  // فورم التحصيل المرتبط بفاتورة أصلية (findMatchingVisit فوق بيغطي حالة "فيه
  // زيارة متابعة اتعملت بالفعل من الاستقبال ولسه محتاجة معالجة") — هنا وصلنا
  // يعني مفيش زيارة متابعة موجودة بالفعل نكمّل عليها، فأي محاولة إنشاء زيارة
  // "متابعة" مستقلة جديدة من هنا هتبقى بالتعريف غير مربوطة بأي فاتورة أصلية
  // (parent_invoice_id) — وده بالظبط الشكل اللي بيسبب ازدواجية/فلوس ضايعة زي
  // اللي المستخدم اكتشفه فعليًا (خدمة "متابعة" لوحدها في الملف المالي من غير
  // ما تكون دفعة على خدمة حقيقية). فبنرفض الإدخال هنا ونوجّه لاستخدام الملف
  // المالي بدلها (اللي فيه اختيار "الخدمة الأصلية" الإجباري).
  if (service_id != null) {
    const svc = await db.selectFrom("services").select(["code"]).where("id", "=", service_id).executeTakeFirst();
    if (svc?.code === FOLLOWUP_SERVICE_CODE) return;
  }

  await db
    .insertInto("visits")
    .values({
      patient_id: patientId,
      visit_date,
      service_id,
      notes,
      primary_doctor_id,
      performing_doctor_id,
      room_id: null,
      created_by: session?.userId ?? null,
    })
    .execute();

  // الزيارة الطبية لا تفتح فاتورة تلقائيًا. التحصيل والخدمات المالية تسجل من
  // الملف المالي أو من طلب التحصيل المرتبط بالموعد، حتى لا تختلط الملاحظات
  // الطبية بالحسابات.

  revalidatePath(`/patients/${patientId}`);
  revalidatePath("/invoices");
}

// تعديل بيانات المريض الأساسية (الاسم/تاريخ الميلاد/التليفون/العنوان) من ملفه —
// دفعة 22، محصور بصلاحية edit_patient_info (الأدمن والاستقبال افتراضيًا). رقم
// الملف (file_number) عمدًا مش قابل للتعديل من هنا — ثابت من وقت إنشاء الحالة.
export async function updatePatientInfoAction(formData: FormData): Promise<{ ok: boolean; reason?: string }> {
  const session = await getSession();
  if (!session) return { ok: false, reason: "لازم تسجل دخول." };

  const canEdit = await hasPermission(session.userId, session.role, "edit_patient_info");
  if (!canEdit) return { ok: false, reason: "مفيش صلاحية لتعديل بيانات المريض." };

  const patientId = Number(formData.get("patient_id"));
  const full_name = String(formData.get("full_name") || "").trim();
  const birth_date = String(formData.get("birth_date") || "").trim() || null;
  const phone_country_code = String(formData.get("phone_country_code") || "+20").trim();
  const phone = normalizePhoneNumber(String(formData.get("phone") || "")) || null;
  const address = String(formData.get("address") || "").trim() || null;

  if (!patientId) return { ok: false, reason: "بيانات المريض ناقصة." };
  if (!isThreePartName(full_name)) return { ok: false, reason: "لازم اسم المريض يكون ثلاثيًا على الأقل." };
  if (!isValidBirthDate(birth_date)) return { ok: false, reason: "من فضلك أدخل تاريخ ميلاد صحيح." };
  if (!phone || !isValidPatientPhone(phone_country_code, phone)) {
    return { ok: false, reason: phone_country_code === "+20" ? "رقم الموبايل المصري لازم يكون 11 رقم ويبدأ بـ 01." : "رقم الهاتف للدول الأخرى لازم يكون من 10 إلى 15 رقمًا." };
  }

  await db
    .updateTable("patients")
    .set({ full_name, birth_date, phone_country_code, phone, address })
    .where("id", "=", patientId)
    .execute();

  revalidatePath(`/patients/${patientId}`);
  revalidatePath(`/patients/${patientId}/billing`);
  revalidatePath("/patients");
  revalidatePath("/front-desk");
  revalidatePath("/");
  return { ok: true };
}

// تعديل حقل "الطبيب المساعد" (performing_doctor_id) بس في زيارة موجودة بالفعل —
// دفعة 22، مستقل تمامًا عن canEditMedicalRecordFor/updateVisitAction فوق (اللي
// عمدًا مابيلمسش الحقل ده). الصلاحية هنا مزدوجة قصدًا: (1) الطبيب الأساسي صاحب
// الزيارة يقدر يعدّل حقل المساعد لزياراته هو دايمًا من غير أي صلاحية إضافية،
// (2) أي حد عنده صلاحية "edit_visit_assistant_doctor" (افتراضيًا: أدمن، مدير
// عيادة، استقبال) يقدر يعدّله لأي زيارة. الاستقبال ده بالذات هو سبب وجود الأكشن
// كحقل مستقل: هم ممنوعين تمامًا من باقي سجل الزيارات الطبي (canEditMedicalRecordFor)
// لكن مسموح لهم يحددوا/يغيّروا "مين نفّذ الخدمة فعليًا" بس، من غير ما يفتح لهم
// إضافة/تعديل أي بيانات طبية تانية.
export async function updateVisitAssistantDoctorAction(formData: FormData) {
  const session = await getSession();
  if (!session) return;

  const visitId = Number(formData.get("visit_id"));
  const patientId = Number(formData.get("patient_id"));
  if (!visitId || !patientId) return;

  const visit = await db
    .selectFrom("visits")
    .select(["id", "primary_doctor_id"])
    .where("id", "=", visitId)
    .where("patient_id", "=", patientId)
    .executeTakeFirst();
  if (!visit) return;

  const isOwnVisit = session.role === "doctor" && session.doctorId != null && session.doctorId === visit.primary_doctor_id;
  if (!isOwnVisit) {
    const canEditField = await hasPermission(session.userId, session.role, "edit_visit_assistant_doctor");
    if (!canEditField) return;
  }

  const performingRaw = formData.get("performing_doctor_id");
  const performing_doctor_id = performingRaw ? Number(performingRaw) || visit.primary_doctor_id : visit.primary_doctor_id;

  await db.updateTable("visits").set({ performing_doctor_id }).where("id", "=", visitId).execute();

  revalidatePath(`/patients/${patientId}`);
}

// عدد الأيام اللي أي حد يقدر يعدّل خلالها زيارة اتسجلت (تصحيح غلطة إدخال بسيطة).
// بعد الفترة دي، محتاج صلاحية "edit_old_visits" (دكتور معيّن أو مدير العيادة
// افتراضيًا — شوف permission-defs.ts). ده بيفرق عن primary/performing_doctor_id
// اللي التعديل ده مايلمسهاش خالص، عشان ميأثرش على التحصيل المالي المسجل بالفعل.
const VISIT_EDIT_WINDOW_DAYS = 3;

// بيعدّل تاريخ/خدمة/ملاحظات زيارة موجودة (مش الدكاترة المرتبطين بيها). لو الخدمة
// اتغيّرت وفاتورتها لسه من غير تحصيل ومن غير تعديل سعر يدوي، بيحدّث سعرها
// تلقائيًا على سعر الخدمة الجديدة (غير كده بيسيب الفاتورة زي ما هي، عشان ميأثرش
// على تحصيل مالي حصل بالفعل أو سعر اتعدل يدويًا).
export async function updateVisitAction(formData: FormData) {
  const session = await getSession();
  if (!session) return;
  if (!canEditMedicalRecordFor(session.role)) return;

  const visitId = Number(formData.get("visit_id"));
  const patientId = Number(formData.get("patient_id"));
  const visit_date = String(formData.get("visit_date") || "").trim();
  const service_id = formData.get("service_id") ? Number(formData.get("service_id")) : null;
  const notes = String(formData.get("notes") || "").trim() || null;
  if (!visitId || !patientId || !visit_date) return;

  const visit = await db
    .selectFrom("visits")
    .select(["id", "created_at", "service_id"])
    .where("id", "=", visitId)
    .where("patient_id", "=", patientId)
    .executeTakeFirst();
  if (!visit) return;

  const createdAt = new Date(visit.created_at.replace(" ", "T") + "Z");
  const ageDays = (Date.now() - createdAt.getTime()) / (1000 * 60 * 60 * 24);
  if (ageDays > VISIT_EDIT_WINDOW_DAYS) {
    const canEditOld = await hasPermission(session.userId, session.role, "edit_old_visits");
    if (!canEditOld) return;
  }

  // دفعة 24: نفس منع "متابعة مستقلة" المطبّق في addVisitAction — بس هنا بنمنع
  // بس التحويل الفعلي لخدمة تانية لـ"متابعة" (service_id مختلف عن الحالي)،
  // مش تعديل زيارة "متابعة" موجودة بالفعل (زي تصحيح المعالجة أو التاريخ بتاعتها
  // من غير ما يتغيّر نوع الخدمة أصلاً) — ده لازم يفضل شغال زي ما هو.
  if (service_id != null && service_id !== visit.service_id) {
    const newSvc = await db.selectFrom("services").select(["code"]).where("id", "=", service_id).executeTakeFirst();
    if (newSvc?.code === FOLLOWUP_SERVICE_CODE) return;
  }

  await db
    .updateTable("visits")
    .set({ visit_date, service_id, notes, notes_synced_from_ortho: 0 })
    .where("id", "=", visitId)
    .execute();

  // resync السعر بس لو الخدمة اتغيّرت، والفاتورة لسه من غير تحصيل ومن غير سعر
  // معدّل يدويًا (price_overridden) — أي حالة تانية بنسيبها زي ما هي عمدًا.
  if (service_id && service_id !== visit.service_id) {
    const invoice = await db
      .selectFrom("invoices")
      .select(["id", "paid", "price_overridden"])
      .where("visit_id", "=", visitId)
      .executeTakeFirst();
    if (invoice && Number(invoice.paid) === 0 && Number(invoice.price_overridden) === 0) {
      const service = await db
        .selectFrom("services")
        .select("default_price")
        .where("id", "=", service_id)
        .executeTakeFirst();
      if (service) {
        await db
          .updateTable("invoices")
          .set({ amount: service.default_price, original_price: service.default_price })
          .where("id", "=", invoice.id)
          .execute();
      }
    }
  }

  revalidatePath(`/patients/${patientId}`);
  revalidatePath("/invoices");
}

// بيمسح زيارة (وفاتورتها المرتبطة) نهائيًا من سجل الزيارات — لتصحيح إدخال مكرر
// أو غلط بالكامل (مش تعديل بسيط زي updateVisitAction فوق)، محصور بصلاحية
// "delete_visits" (الأدمن بس افتراضيًا — قابلة للمنح لغيره من الإعدادات لو
// المستخدم حابب). عملية لا رجعة فيها، والتأكيد بيحصل في الواجهة (window.confirm)
// قبل ما الأكشن ده يتستدعى أصلاً.
//
// دفعة 24 (سبب جذري تاني لازدواجية اتكشف): لو الفاتورة المرتبطة بالزيارة دي
// كانت "فاتورة أصلية" ليها دفعات متابعة مربوطة بيها (parent_invoice_id)، كان
// الحذف بيفك الربط ده بصمت (parent_invoice_id = null) قبل ما يمسح — يعني دفعة
// المتابعة كانت بتفضل موجودة لكن "يتيمة"، وبتظهر كخدمة "متابعة" مستقلة قائمة
// بذاتها في الملف المالي (بالظبط الشكل اللي المستخدم اكتشفه: خدمة أصلية
// اتحذفت زي المفروض بعد تنضيف تكرار قديم، لكن دفعة متابعة كانت مربوطة بيها
// فضلت معلّقة من غير فاتورة أصلية). دلوقتي الحذف ممنوع تمامًا لو فيه دفعات
// متابعة مربوطة — لازم الأدمن يمسحهم هم الأول (زرار "حذف" على صف "↳ دفعة
// متابعة" نفسه) قبل ما يقدر يمسح الفاتورة الأصلية.
export async function deleteVisitAction(
  formData: FormData
): Promise<{ ok: boolean; reason?: string } | void> {
  const session = await getSession();
  if (!session) return { ok: false, reason: "لازم تسجل دخول." };
  const canDelete = await hasPermission(session.userId, session.role, "delete_visits");
  if (!canDelete) return { ok: false, reason: "مفيش صلاحية عندك لحذف زيارات." };

  const visitId = Number(formData.get("visit_id"));
  const patientId = Number(formData.get("patient_id"));
  if (!visitId || !patientId) return { ok: false, reason: "بيانات ناقصة." };

  const visit = await db
    .selectFrom("visits")
    .select(["id"])
    .where("id", "=", visitId)
    .where("patient_id", "=", patientId)
    .executeTakeFirst();
  if (!visit) return { ok: false, reason: "الزيارة دي مش موجودة." };

  const visitInvoices = await db.selectFrom("invoices").select("id").where("visit_id", "=", visitId).execute();
  const invoiceIds = visitInvoices.map((inv) => inv.id);

  if (invoiceIds.length > 0) {
    const followupChildren = await db
      .selectFrom("invoices")
      .select(["id"])
      .where("parent_invoice_id", "in", invoiceIds)
      .execute();
    if (followupChildren.length > 0) {
      return {
        ok: false,
        reason: `مينفعش تتمسح — فيه ${followupChildren.length} دفعة متابعة مربوطة بالخدمة دي. لازم تمسحهم هم الأول (زرار "حذف" على صف "↳ دفعة متابعة" في الملف المالي)، أو لو الدفعات دي صح ومش غلط، سيب الخدمة الأصلية زي ما هي.`,
      };
    }
    await db.deleteFrom("invoices").where("visit_id", "=", visitId).execute();
  }

  await db.deleteFrom("visits").where("id", "=", visitId).execute();

  revalidatePath(`/patients/${patientId}`);
  revalidatePath(`/patients/${patientId}/billing`);
  revalidatePath("/invoices");
  revalidatePath("/front-desk");
  return { ok: true };
}

// NOTE (image-upload-404 fix, v2): two separate bugs were found here.
// (1) process.cwd() under systemd isn't guaranteed to equal the app's source
//     root, so a file could get written to one absolute path while the
//     server resolved requests against a different one — fixed by pinning
//     an absolute root via CLINIC_UPLOAD_DIR (same pattern as CLINIC_DB_PATH).
// (2) more fundamentally: Next.js's "public" folder is only scanned ONCE at
//     server boot (a snapshot of filenames used to serve static assets), so
//     writing new files into "public/..." at runtime is invisible until the
//     next deploy/restart — any photo uploaded during normal clinic hours
//     would 404 forever until then. So uploads are stored OUTSIDE "public"
//     entirely (mirroring where the sqlite db already lives, under data/,
//     which the deploy process already backs up and never overwrites) and
//     served through a dynamic route (src/app/patient-files/[...path]/route.ts)
//     that reads the file from disk on every request — no snapshot involved.
const UPLOAD_ROOT = process.env.CLINIC_UPLOAD_DIR
  ? path.join(path.resolve(process.env.CLINIC_UPLOAD_DIR), "patients")
  : path.join(process.cwd(), "data", "uploads", "patients");

// بيمسح صورة واحدة (صورة اترفعت غلط أو مكررة). التأكيد بيحصل في الطبقة
// العميلة (window.confirm) قبل ما الأكشن ده يتستدعى أصلاً، زي نفس النمط
// المتبع مع حذف المستخدمين/العيادات في الإعدادات.
export async function deleteImageAction(formData: FormData) {
  const session = await getSession();
  if (!(await canManagePhotosFor(session))) return;

  const imageId = Number(formData.get("image_id"));
  const patientId = Number(formData.get("patient_id"));
  if (!imageId || !patientId) return;

  const image = await db
    .selectFrom("patient_images")
    .select(["id", "file_path", "group_id"])
    .where("id", "=", imageId)
    .executeTakeFirst();
  if (!image) return;

  await db.deleteFrom("patient_images").where("id", "=", imageId).execute();

  // الملف نفسه على القرص - نمسحه best-effort، لو مش موجود أصلاً (اتمسح قبل
  // كده يدويًا مثلاً) منسيبش الحذف كله يفشل بسبب كده.
  if (image.file_path.startsWith("/patient-files/")) {
    // UPLOAD_ROOT فوق already بينتهي بـ "/patients"، و file_path المخزّن شكله
    // "/patient-files/patients/<id>/<name>" — يعني dirname(UPLOAD_ROOT) هو
    // نفس القاعدة اللي راوت العرض (route.ts) بيبني منها المسار.
    const relative = image.file_path.replace(/^\/patient-files\//, "");
    const filePath = path.join(path.dirname(UPLOAD_ROOT), relative);
    await fs.unlink(filePath).catch(() => {});
  }

  // لو دي كانت آخر صورة في مجموعتها، امسح المجموعة (الكارت) نفسها كمان —
  // غير كده كانت هتفضل تظهر في المعرض كمربع فاضي "لا صور" من غير أي فايدة.
  const remaining = await db
    .selectFrom("patient_images")
    .select((eb) => eb.fn.countAll<number>().as("count"))
    .where("group_id", "=", image.group_id)
    .executeTakeFirst();
  if (!remaining || Number(remaining.count) === 0) {
    await db.deleteFrom("patient_image_groups").where("id", "=", image.group_id).execute();
  }

  revalidatePath(`/patients/${patientId}`);
}

// بيمسح مجموعة صور كاملة (يوم/دفعة رفع واحدة) مرة واحدة — دفعة 27، طلب صريح
// لتسهيل مسح صور جلسة كاملة بدل ما يتمسحوا واحدة واحدة. نفس منطق حذف الصورة
// الواحدة فوق بالظبط (DB + الملف على القرص best-effort)، مكرر لكل صور
// المجموعة، ثم مسح المجموعة نفسها.
export async function deleteImageGroupAction(formData: FormData) {
  const session = await getSession();
  if (!(await canManagePhotosFor(session))) return;

  const groupId = Number(formData.get("group_id"));
  const patientId = Number(formData.get("patient_id"));
  if (!groupId || !patientId) return;

  const images = await db.selectFrom("patient_images").select(["id", "file_path"]).where("group_id", "=", groupId).execute();

  for (const image of images) {
    if (image.file_path.startsWith("/patient-files/")) {
      const relative = image.file_path.replace(/^\/patient-files\//, "");
      const filePath = path.join(path.dirname(UPLOAD_ROOT), relative);
      await fs.unlink(filePath).catch(() => {});
    }
  }

  await db.deleteFrom("patient_images").where("group_id", "=", groupId).execute();
  await db.deleteFrom("patient_image_groups").where("id", "=", groupId).execute();

  revalidatePath(`/patients/${patientId}`);
}

// بيلف الصورة 90 درجة كل ضغطة (0 -> 90 -> 180 -> 270 -> 0) وبيحفظ آخر وضع في
// قاعدة البيانات نفسها — عشان لو الدكتور قفل ورجع فتح الملف تاني الصورة تفضل
// زي ما سابها، مش ترجع تتصفّر (طلب مراجعة 2026-08-27، شارت التقويم).
export async function rotateImageAction(formData: FormData) {
  const session = await getSession();
  if (!(await canManagePhotosFor(session))) return;

  const imageId = Number(formData.get("image_id"));
  const patientId = Number(formData.get("patient_id"));
  if (!imageId || !patientId) return;

  const image = await db.selectFrom("patient_images").select(["id", "rotation"]).where("id", "=", imageId).executeTakeFirst();
  if (!image) return;

  const nextRotation = (image.rotation + 90) % 360;
  await db.updateTable("patient_images").set({ rotation: nextRotation }).where("id", "=", imageId).execute();

  revalidatePath(`/patients/${patientId}`);
}
