"use server";
import { submitPatientReview } from "@/lib/patient-review";
export async function submitPatientReviewAction(token: string, rating: number, comment: string, anonymous: boolean) {
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) return { ok: false, error: "اختر عدد النجوم أولًا." };
  return submitPatientReview(token, rating, comment.trim().slice(0, 1500), anonymous);
}
