import type { Metadata } from "next";
import { getPatientReviewState } from "@/lib/patient-review";
import { getSetting } from "@/lib/settings";
import PatientReviewForm from "@/components/PatientReviewForm";
export const metadata: Metadata = { title: "تقييم زيارتك", robots: { index: false, follow: false } };
export default async function ReviewPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params; const [state, googleReviewUrl] = await Promise.all([getPatientReviewState(token), getSetting("google_review_url")]);
  return <main className="min-h-screen bg-slate-50 p-4" dir="rtl"><div className="mx-auto mt-10 max-w-xl rounded-2xl bg-white p-6 shadow-lg"><h1 className="text-center text-xl font-bold">تقييم زيارتك</h1>{state.state === "ok" ? <><p className="my-4 text-center text-sm text-slate-600">أهلًا {state.invite.patientName}، نسعد بمعرفة رأيك في زيارتك مع د. {state.invite.doctorName}.</p><PatientReviewForm token={token} googleReviewUrl={googleReviewUrl} /></> : <p className="mt-5 rounded-xl bg-slate-100 p-4 text-center text-slate-700">{state.state === "submitted" ? "شكرًا، تم إرسال تقييمك بالفعل." : "رابط التقييم غير صالح أو انتهت صلاحيته."}</p>}</div></main>;
}
