"use server";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { setSetting } from "@/lib/settings";

export async function getPatientReviewsAction(from: string, to: string) {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "view_patient_review_report"))) return { ok: false, error: "غير مصرح", rows: [] };
  if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to)) return { ok: false, error: "اختر فترة صحيحة", rows: [] };
  const rows = await db.selectFrom("patient_reviews").innerJoin("doctors", "doctors.id", "patient_reviews.doctor_id").leftJoin("patients", "patients.id", "patient_reviews.patient_id").select(["patient_reviews.id", "patient_reviews.visit_date", "patient_reviews.rating", "patient_reviews.comment", "patient_reviews.anonymous", "patients.full_name as patient_name", "doctors.full_name as doctor_name"]).where("patient_reviews.visit_date", ">=", from).where("patient_reviews.visit_date", "<=", to).orderBy("patient_reviews.submitted_at", "desc").execute();
  return { ok: true, rows, average: rows.length ? rows.reduce((sum, row) => sum + row.rating, 0) / rows.length : 0 };
}

export async function saveGoogleReviewUrlAction(url: string) {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "manage_settings"))) return { ok: false, error: "غير مصرح" };
  const value = url.trim(); if (value && !/^https:\/\//i.test(value)) return { ok: false, error: "الرابط يجب أن يبدأ بـ https://" };
  await setSetting("google_review_url", value.slice(0, 1000)); revalidatePath("/reports"); return { ok: true };
}
