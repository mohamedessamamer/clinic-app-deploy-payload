import { NextRequest, NextResponse } from "next/server";
import { createWriteStream } from "node:fs";
import fs from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const ROOT = process.env.CLINIC_UPLOAD_DIR ? path.join(path.resolve(process.env.CLINIC_UPLOAD_DIR), "hr-documents") : path.join(process.cwd(), "data", "uploads", "hr-documents");
const EXTENSIONS = new Set([".jpg", ".jpeg", ".png", ".webp", ".pdf"]);
function error(message: string, status: number) { return NextResponse.json({ ok: false, error: message }, { status }); }
function cleanName(raw: string | null) {
  let decoded = "document";
  try { decoded = decodeURIComponent(raw || "document"); } catch {}
  return path.basename(decoded).replace(/[^a-zA-Z0-9._-]/g, "_").slice(-160) || "document";
}

export async function POST(request: NextRequest) {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "manage_hr"))) return error("ليس لديك صلاحية إدارة HR.", 403);
  const personType = request.nextUrl.searchParams.get("personType");
  const personId = Number(request.nextUrl.searchParams.get("personId"));
  const documentType = String(request.nextUrl.searchParams.get("documentType") || "other").slice(0, 80);
  const label = String(request.nextUrl.searchParams.get("label") || "").trim().slice(0, 160) || null;
  if (!["doctor", "staff"].includes(personType || "") || !Number.isInteger(personId) || personId <= 0 || !request.body) return error("بيانات المستند غير صحيحة.", 400);
  const exists = personType === "doctor"
    ? await db.selectFrom("doctors").select("id").where("id", "=", personId).executeTakeFirst()
    : await db.selectFrom("hr_staff").select("id").where("id", "=", personId).executeTakeFirst();
  if (!exists) return error("الشخص غير موجود.", 404);
  const originalName = cleanName(request.headers.get("x-file-name"));
  const extension = path.extname(originalName).toLowerCase();
  const contentType = request.headers.get("content-type")?.split(";", 1)[0].toLowerCase() || "";
  if (!EXTENSIONS.has(extension) || !(contentType.startsWith("image/") || contentType === "application/pdf")) return error("يسمح بالصور وPDF فقط.", 415);
  const folder = path.join(ROOT, personType!, String(personId));
  await fs.mkdir(folder, { recursive: true });
  const storedName = `${Date.now()}-${randomUUID()}-${originalName}`;
  const finalPath = path.join(folder, storedName);
  const temporaryPath = `${finalPath}.part`;
  try {
    await pipeline(Readable.fromWeb(request.body as import("node:stream/web").ReadableStream), createWriteStream(temporaryPath, { flags: "wx" }));
    if ((await fs.stat(temporaryPath)).size <= 0) throw new Error("empty document");
    await fs.rename(temporaryPath, finalPath);
    await db.insertInto("hr_documents").values({
      person_type: personType as "doctor" | "staff", person_id: personId,
      document_type: documentType, label, original_name: originalName,
      file_path: `/patient-files/hr-documents/${personType}/${personId}/${storedName}`,
      uploaded_by: session.userId,
    }).execute();
    return NextResponse.json({ ok: true });
  } catch (cause) {
    await fs.unlink(temporaryPath).catch(() => {});
    await fs.unlink(finalPath).catch(() => {});
    console.error("HR document upload failed", cause);
    return error("تعذر حفظ المستند.", 500);
  }
}
