import { NextRequest, NextResponse } from "next/server";
import { getWhatsappConfig } from "@/lib/whatsapp/config";
import { verifyWebhookSignature } from "@/lib/whatsapp/webhook-verify";
import {
  claimWebhookEvent,
  getActiveAccount,
  recordInboundMessage,
  recordOutboundMessage,
  getAccountAccessToken,
  touchContactLastMessage,
  updateMessageStatus,
  upsertContact,
  markManualDeliveriesResponded,
} from "@/lib/whatsapp/store";
import { confirmAppointmentByToken } from "@/lib/appointment-self-service";
import { sendTextMessage } from "@/lib/whatsapp/graph";

// Endpoint عام (بدون تسجيل دخول — شوف proxy.ts) بيستقبله Meta على:
//   https://clinicsys.revereeg.com/api/whatsapp/webhook
//
// GET  = خطوة التحقق (verification handshake) وقت ضبط الـwebhook في Meta App
//        Dashboard: بيرجّع hub.challenge لو hub.verify_token طابق القيمة اللي
//        في WHATSAPP_WEBHOOK_VERIFY_TOKEN.
// POST = الأحداث الفعلية (رسائل واردة، تحديثات حالة، إلخ). محمي بتوقيع
//        X-Hub-Signature-256 محسوب من App Secret — أي طلب توقيعه غلط أو ناقص
//        بيترفض 403 قبل أي معالجة أو لمس لقاعدة البيانات.

export async function GET(req: NextRequest) {
  const { webhookVerifyToken } = getWhatsappConfig();
  const mode = req.nextUrl.searchParams.get("hub.mode");
  const token = req.nextUrl.searchParams.get("hub.verify_token");
  const challenge = req.nextUrl.searchParams.get("hub.challenge");

  if (mode === "subscribe" && token === webhookVerifyToken && challenge) {
    return new NextResponse(challenge, { status: 200 });
  }
  return new NextResponse("Forbidden", { status: 403 });
}

interface WaChangeValue {
  messaging_product?: "whatsapp";
  metadata?: { phone_number_id?: string };
  contacts?: { profile?: { name?: string }; wa_id: string }[];
  messages?: {
    id: string;
    from: string;
    timestamp: string;
    type: string;
    text?: { body: string };
    button?: { payload?: string; text?: string };
    interactive?: { button_reply?: { id?: string; title?: string } };
    [key: string]: unknown;
  }[];
  statuses?: {
    id: string;
    status: "sent" | "delivered" | "read" | "failed";
    timestamp: string;
    errors?: { title?: string }[];
  }[];
  // smb_message_echoes: رسالة اتبعتت من تطبيق WhatsApp Business نفسه (السكرتارية
  // بتبعت من موبايلها) — بتوصلنا هنا زي أي رسالة outbound لكن من غير ما السيستم
  // يكون هو اللي بعتها.
  message_echoes?: WaChangeValue["messages"];
  event?: string; // smb_app_state_sync وأحداث تانية مالهاش شكل ثابت
}

async function handleMessagesAndEchoes(accountId: number, value: WaChangeValue, isEcho: boolean) {
  const list = isEcho ? value.message_echoes : value.messages;
  if (!list?.length) return;
  const contactName = value.contacts?.[0]?.profile?.name ?? null;
  for (const msg of list) {
    const isNew = await claimWebhookEvent(`msg:${msg.id}`, isEcho ? "message_echo" : "message");
    if (!isNew) continue;
    const confirmationPayload = msg.button?.payload ?? msg.interactive?.button_reply?.id ?? "";
    const contactId = await upsertContact(accountId, msg.from, contactName);
    if (!isEcho) await markManualDeliveriesResponded(accountId, contactId, msg.from);
    if (!isEcho && confirmationPayload.startsWith("confirm:")) {
      const confirmation = await confirmAppointmentByToken(confirmationPayload.slice("confirm:".length));
      if (confirmation.ok) {
        try {
          const account = await getActiveAccount();
          if (account?.id === accountId) {
            const sent = await sendTextMessage(account.phone_number_id, await getAccountAccessToken(account.id), msg.from, "شكرًا لتأكيد موعدك. ننتظرك في الموعد المحدد.");
            await recordOutboundMessage({ accountId, contactId, wamid: sent.messages?.[0]?.id ?? null, body: "شكرًا لتأكيد موعدك. ننتظرك في الموعد المحدد.", sentBy: null, status: "sent" });
          }
        } catch {
          // التأكيد نفسه تم؛ فشل رسالة الشكر لا يلغي تأكيد الموعد.
        }
      }
    }
    await recordInboundMessage({
      accountId,
      contactId,
      wamid: msg.id,
      messageType: msg.type,
      body: msg.type === "text" ? msg.text?.body ?? null : msg.button?.text ?? msg.interactive?.button_reply?.title ?? `[${msg.type}]`,
      waTimestamp: new Date(Number(msg.timestamp) * 1000).toISOString(),
      isEcho,
    });
    await touchContactLastMessage(contactId, new Date().toISOString());
  }
}

async function handleStatuses(value: WaChangeValue) {
  if (!value.statuses?.length) return;
  for (const status of value.statuses) {
    const isNew = await claimWebhookEvent(`status:${status.id}:${status.status}:${status.timestamp}`, "status");
    if (!isNew) continue;
    await updateMessageStatus(status.id, status.status, status.errors?.[0]?.title);
  }
}

export async function POST(req: NextRequest) {
  const { appSecret } = getWhatsappConfig();
  const rawBody = await req.text();
  const signature = req.headers.get("x-hub-signature-256");

  if (!verifyWebhookSignature(rawBody, signature, appSecret)) {
    // ما بنسجّلش الـbody هنا (ممكن يحتوي بيانات مريض حقيقية زي رقم تليفون) —
    // بس نوع الخطأ نفسه.
    console.warn("[whatsapp/webhook] رفض طلب بتوقيع غير صالح");
    return new NextResponse("Invalid signature", { status: 403 });
  }

  let payload: { entry?: { id?: string; changes?: { field: string; value: WaChangeValue }[] }[] };
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return new NextResponse("Bad request", { status: 400 });
  }

  try {
    const account = await getActiveAccount();
    // لو مفيش حساب متصل حاليًا (لسه ماحدش عمل Connect)، نرجّع 200 برضه — Meta
    // بتعتبر أي رد غير 200 فشل وتعيد المحاولة، وده مش مفيد هنا لأننا فعليًا
    // مش هنقدر نعالج الحدث من غير حساب متصل.
    if (account) {
      for (const entry of payload.entry ?? []) {
        for (const change of entry.changes ?? []) {
          const value = change.value;
          if (change.field !== "messages") {
            // history / smb_app_state_sync / أي حقل تاني مش شكله رسالة أو حالة:
            // بنسجل استلامه بس (idempotent) من غير معالجة إضافية دلوقتي — قابل
            // للتوسيع لاحقًا لو احتجنا نبني منطق عليه.
            const key = `field:${change.field}:${value?.event ?? entry.id ?? Math.random()}`;
            await claimWebhookEvent(key, change.field);
            continue;
          }
          await handleMessagesAndEchoes(account.id, value, false);
          await handleMessagesAndEchoes(account.id, value, true); // smb_message_echoes
          await handleStatuses(value);
        }
      }
    }
  } catch (err) {
    // بنسجل رسالة الخطأ بس (مفيهاش أسرار) ونرد 200 برضه — فشل معالجة داخلي
    // معناه Meta هتعيد إرسال نفس الحدث تاني، وده مطلوب فعلاً لو كانت المشكلة
    // مؤقتة (قاعدة بيانات مشغولة لحظيًا مثلاً)؛ الـidempotency فوق (claimWebhookEvent)
    // بيضمن إننا معالجاش نفس الحدث مرتين حتى لو اتكرر.
    console.error("[whatsapp/webhook] خطأ أثناء معالجة الحدث:", err instanceof Error ? err.message : err);
  }

  return NextResponse.json({ received: true });
}
