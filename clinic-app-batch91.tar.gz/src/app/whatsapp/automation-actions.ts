"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getAllSettings } from "@/lib/settings";

async function authorized() {
  const session = await getSession();
  return session && await hasPermission(session.userId, session.role, "whatsapp_automation") ? session : null;
}

export async function listAutomationDataAction() {
  const session = await authorized(); if (!session) return { templates: [], rules: [] };
  const templates = await db.selectFrom("whatsapp_message_templates").select(["id", "name", "language", "body_text"]).where("status", "=", "approved").orderBy("name").execute();
  let rules = await db.selectFrom("whatsapp_automation_rules").selectAll().orderBy("id").execute();
  if (!rules.length) {
    const settings = await getAllSettings(); const reminder = templates.find((item) => item.name === settings.whatsapp_reminder_template_name);
    if (reminder) {
      await db.insertInto("whatsapp_automation_rules").values({ name: "تأكيد موعد اليوم التالي", template_id: reminder.id, trigger_type: "appointment_relative", day_offset: -1, send_time: settings.whatsapp_reminder_time, variable_map: JSON.stringify({ 1: "patient_name", 2: "appointment_date", 3: "appointment_time", 4: "doctor_name" }), created_by: session.userId }).execute();
      rules = await db.selectFrom("whatsapp_automation_rules").selectAll().orderBy("id").execute();
    }
  }
  return { templates, rules };
}

export async function saveAutomationRuleAction(formData: FormData) {
  const session = await authorized();
  if (!session) return { ok: false, error: "غير مصرح" };
  const id = Number(formData.get("id")) || null;
  const templateId = Number(formData.get("template_id"));
  const triggerType = String(formData.get("trigger_type")) as "appointment_relative" | "appointment_completed";
  const dayOffset = Number(formData.get("day_offset") || -1);
  const sendTime = String(formData.get("send_time") || "18:00");
  const delayMinutes = Math.max(0, Number(formData.get("delay_minutes") || 0));
  const name = String(formData.get("name") || "قاعدة تلقائية").trim().slice(0, 100);
  if (!templateId || !["appointment_relative", "appointment_completed"].includes(triggerType)) return { ok: false, error: "اختر القالب وموعد الإرسال" };
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(sendTime)) return { ok: false, error: "الساعة غير صحيحة" };
  const variableMap: Record<string, string> = {};
  for (let index = 1; index <= 8; index++) {
    const value = String(formData.get(`variable_${index}`) || "");
    if (value) variableMap[String(index)] = value;
  }
  const values = { name, template_id: templateId, trigger_type: triggerType, day_offset: Math.max(-30, Math.min(30, dayOffset)), send_time: sendTime, delay_minutes: delayMinutes, variable_map: JSON.stringify(variableMap), active: formData.get("active") === "0" ? 0 : 1, updated_at: new Date().toISOString() };
  if (id) await db.updateTable("whatsapp_automation_rules").set(values).where("id", "=", id).execute();
  else await db.insertInto("whatsapp_automation_rules").values({ ...values, created_by: session.userId }).execute();
  revalidatePath("/whatsapp");
  return { ok: true };
}

export async function deleteAutomationRuleAction(id: number) {
  if (!(await authorized())) return { ok: false, error: "غير مصرح" };
  await db.deleteFrom("whatsapp_automation_rules").where("id", "=", id).execute();
  revalidatePath("/whatsapp");
  return { ok: true };
}
