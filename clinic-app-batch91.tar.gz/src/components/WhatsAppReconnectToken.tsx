"use client";

import { useState, useTransition } from "react";
import { connectTestAccountManuallyAction } from "@/app/whatsapp/actions";

// نفس نموذج الربط اليدوي في WhatsAppConnectButton، لكن متاح هنا كمان بعد ما
// الحساب يبقى متصل بالفعل — عشان التوكنات المؤقتة (24 ساعة) لازم تتحدّث من
// وقت للتاني، وصفحة الربط الأول بتختفي بمجرد ما فيه حساب متصل.
export default function WhatsAppReconnectToken() {
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [pending, startTransition] = useTransition();

  function submit(formData: FormData) {
    setError(null);
    setSuccess(false);
    startTransition(async () => {
      const result = await connectTestAccountManuallyAction(formData);
      if (!result.ok) {
        setError(result.error ?? "فشل التحديث");
      } else {
        setSuccess(true);
        setTimeout(() => window.location.reload(), 800);
      }
    });
  }

  if (!open) {
    return (
      <button type="button" onClick={() => setOpen(true)} className="text-xs text-muted underline">
        تحديث بيانات الاتصال / التوكن (لو انتهت صلاحية التوكن المؤقت)
      </button>
    );
  }

  return (
    <div className="rounded-lg border border-slate-200 p-3">
      <p className="mb-2 text-xs text-muted">
        حط WABA ID وPhone Number ID (نفس القيم الحالية عادةً) والتوكن الجديد اللي ولّدته من &quot;Generate token&quot; في
        Meta Dashboard.
      </p>
      <form action={submit} className="space-y-2">
        <input
          name="waba_id"
          placeholder="WhatsApp Business Account ID"
          required
          className="w-full rounded-md border border-slate-300 px-2 py-1.5 text-sm"
        />
        <input
          name="phone_number_id"
          placeholder="Phone Number ID"
          required
          className="w-full rounded-md border border-slate-300 px-2 py-1.5 text-sm"
        />
        <input
          name="access_token"
          type="password"
          placeholder="Access token الجديد"
          required
          className="w-full rounded-md border border-slate-300 px-2 py-1.5 text-sm"
        />
        <div className="flex gap-2">
          <button type="submit" disabled={pending} className="btn-secondary rounded-lg px-4 py-2 text-sm disabled:opacity-50">
            تحديث
          </button>
          <button type="button" onClick={() => setOpen(false)} className="rounded-lg px-4 py-2 text-sm text-muted">
            إلغاء
          </button>
        </div>
      </form>
      {error && <p className="mt-2 text-sm text-red-700">{error}</p>}
      {success && <p className="mt-2 text-sm text-primary">تم التحديث، جاري إعادة التحميل...</p>}
    </div>
  );
}
