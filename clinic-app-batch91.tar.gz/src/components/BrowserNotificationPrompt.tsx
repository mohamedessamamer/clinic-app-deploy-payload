"use client";

import { useEffect, useState } from "react";

export default function BrowserNotificationPrompt() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const mobile = window.matchMedia("(max-width: 768px)").matches;
    setShow(mobile && "Notification" in window && Notification.permission === "default");
  }, []);
  if (!show) return null;
  return (
    <aside className="fixed inset-x-3 top-20 z-[70] rounded-xl border border-border bg-surface p-3 shadow-xl" dir="rtl">
      <div className="flex items-center justify-between gap-3">
        <div><strong className="text-sm">فعّل إشعارات العيادة</strong><p className="mt-1 text-xs text-muted">لتصلك رسائل الأطباء والاستقبال أثناء وجود المتصفح في الخلفية.</p></div>
        <div className="flex gap-2"><button type="button" className="rounded-md btn-3d-primary px-3 py-2 text-sm" onClick={async () => { await Notification.requestPermission(); setShow(false); }}>السماح</button><button type="button" className="rounded-md border border-border px-3 py-2 text-sm" onClick={() => setShow(false)}>لاحقًا</button></div>
      </div>
    </aside>
  );
}
