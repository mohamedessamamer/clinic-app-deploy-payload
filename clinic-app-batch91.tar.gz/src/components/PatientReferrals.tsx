"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { completeReferralAction } from "@/app/referrals/actions";

export type ReferralRow = { id: number; request_text: string; status: "pending" | "completed"; created_at: string; completed_at: string | null; from_name: string; to_name: string; to_doctor_id: number };

export default function PatientReferrals({ referrals, currentDoctorId }: { referrals: ReferralRow[]; currentDoctorId: number | null }) {
  const [busy, startTransition] = useTransition();
  const router = useRouter();
  if (!referrals.length) return null;
  return <section className="card-3d rounded-2xl p-4 space-y-3" dir="ltr">
    <h2 className="font-semibold">Doctor referrals</h2>
    <div className="space-y-2">{referrals.map((referral) => <div key={referral.id} className={`rounded-lg border p-3 text-sm ${referral.status === "pending" ? "border-amber-300 bg-amber-50" : "border-primary bg-primary-soft"}`}>
      <div className="flex flex-wrap items-start justify-between gap-2"><strong>{referral.from_name} → {referral.to_name}</strong><span>{referral.status === "pending" ? "Pending" : "Completed"}</span></div>
      <p className="mt-1 whitespace-pre-wrap">{referral.request_text}</p>
      <p className="mt-1 text-xs text-muted">Sent: {referral.created_at}{referral.completed_at ? ` · Completed: ${referral.completed_at}` : ""}</p>
      {referral.status === "pending" && referral.to_doctor_id === currentDoctorId && <button disabled={busy} onClick={() => startTransition(async () => { const result = await completeReferralAction(referral.id); if (!result.ok) return window.alert(result.error); router.refresh(); })} className="mt-2 rounded-md bg-primary-dark px-3 py-1.5 text-white">Mark as completed</button>}
    </div>)}</div>
  </section>;
}
