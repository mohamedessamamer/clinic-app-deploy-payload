"use client";

import { useState } from "react";

const labels = { gentle_bell: "جرس هادئ", soft_chime: "نغمة قصيرة", water_drop: "قطرة خفيفة", off: "بدون صوت" } as const;

export default function ChatSoundPicker({ initialValue }: { initialValue: string }) {
  const [value, setValue] = useState(initialValue in labels ? initialValue : "gentle_bell");
  function preview() {
    if (value === "off") return;
    window.dispatchEvent(new CustomEvent("clinic-chat-sound-preview", { detail: { sound: value } }));
  }
  return <div className="flex gap-2"><select name="chat_notification_sound" value={value} onChange={(event) => setValue(event.target.value)} className="min-w-0 flex-1 rounded-md border border-border bg-background px-3 py-2 text-sm">{Object.entries(labels).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select><button type="button" disabled={value === "off"} onClick={preview} className="rounded-md border border-primary px-3 py-2 text-sm text-primary">تجربة الصوت</button></div>;
}
