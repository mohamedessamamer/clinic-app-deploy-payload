"use client";
import { useState, useTransition } from "react";
import { submitPatientReviewAction } from "@/app/review/[token]/actions";

export default function PatientReviewForm({ token, googleReviewUrl }: { token: string; googleReviewUrl: string }) {
  const [rating, setRating] = useState(0); const [done, setDone] = useState(false); const [error, setError] = useState(""); const [busy, startTransition] = useTransition();
  if (done) return <div className="space-y-4 text-center"><p className="rounded-xl bg-primary-soft p-5 text-primary-dark">شكرًا لتقييمك. رأيك يساعدنا على تحسين تجربتك.</p>{googleReviewUrl && <a href={googleReviewUrl} target="_blank" rel="noreferrer" className="inline-block rounded-xl bg-primary-dark px-5 py-3 font-semibold text-white">مشاركة رأيك على Google</a>}</div>;
  return <form action={(fd) => startTransition(async () => { const result = await submitPatientReviewAction(token, rating, String(fd.get("comment") || ""), fd.get("anonymous") === "on"); if (!result.ok) setError(result.error || "تعذر الإرسال"); else setDone(true); })} className="space-y-5">
    <div className="text-center"><p className="mb-2 text-sm text-slate-600">كيف كانت تجربتك؟</p><div className="flex justify-center gap-2" dir="ltr">{[1,2,3,4,5].map((n) => <button key={n} type="button" onClick={() => setRating(n)} aria-label={`${n} نجوم`} className={`text-4xl ${n <= rating ? "text-amber-400" : "text-slate-300"}`}>★</button>)}</div></div>
    <label className="block text-sm">ملاحظة اختيارية<textarea name="comment" rows={4} className="mt-1 w-full rounded-xl border border-slate-300 p-3" placeholder="اكتب ملاحظتك هنا" /></label>
    <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="anonymous" /> إرسال التقييم بدون إظهار اسمي</label>
    {error && <p className="text-sm text-red-700">{error}</p>}<button disabled={busy || !rating} className="w-full rounded-xl bg-primary-dark px-5 py-3 font-semibold text-white disabled:opacity-50">{busy ? "جارٍ الإرسال..." : "إرسال التقييم"}</button>
  </form>;
}
