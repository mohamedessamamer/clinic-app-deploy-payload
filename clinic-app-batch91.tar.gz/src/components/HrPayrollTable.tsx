"use client";

import { useMemo, useState } from "react";
import { createOrRefreshHrPayrollRunAction, payAllHrPayrollRunsAction, payHrPayrollRunAction } from "@/app/expenses/actions";
import { calculateHrPayroll, type HrRule } from "@/lib/hr-payroll-math";

type Run = { id: number; shift_count: number; fixed_amount: number; percentage_amount: number; incentives: number; deductions: number; total_amount: number; status: "draft" | "paid"; paid_date: string | null } | null;
type Row = { key: string; name: string; personType: "doctor" | "staff"; personId: number; group: "doctor" | "employee" | "nursing"; rule: HrRule; gross: number; lab: number; net: number; run: Run };
const groupLabels = { doctor: "الأطباء", employee: "الموظفون", nursing: "التمريض" } as const;
const paymentMethods = [{ value: "cash", label: "نقدي" }, { value: "instapay", label: "إنستاباي" }, { value: "card", label: "بطاقة" }, { value: "bank", label: "تحويل بنكي" }];

function PayrollRow({ row, from, to, today }: { row: Row; from: string; to: string; today: string }) {
  const [shifts, setShifts] = useState(row.run?.shift_count ?? 0);
  const [incentives, setIncentives] = useState(row.run?.incentives ?? 0);
  const [deductions, setDeductions] = useState(row.run?.deductions ?? 0);
  const calculated = calculateHrPayroll(row.rule, row.net, shifts);
  const total = Math.max(0, calculated.totalAmount + incentives - deductions);
  const tiny = "h-8 w-20 rounded border border-border bg-background px-1 text-xs";
  return <tr className="border-t border-border whitespace-nowrap">
    <td className="px-2 py-2 font-medium">{row.name}</td><td className="px-2 py-2">{row.net.toFixed(0)}</td>
    <td className="px-2 py-2">{row.rule.fixed_basis === "shift" ? <input name="shift_count" form={`save-${row.key}`} type="number" min="0" step="0.5" value={shifts} onChange={(e) => setShifts(Number(e.target.value) || 0)} className={tiny} /> : <span>{calculated.baseAmount.toFixed(0)}</span>} </td>
    <td className="px-2 py-2">{calculated.percentageAmount.toFixed(0)}</td>
    <td className="px-2 py-2"><input name="incentives" form={`save-${row.key}`} type="number" min="0" step="0.01" value={incentives} onChange={(e) => setIncentives(Number(e.target.value) || 0)} className={tiny} /></td>
    <td className="px-2 py-2"><input name="deductions" form={`save-${row.key}`} type="number" min="0" step="0.01" value={deductions} onChange={(e) => setDeductions(Number(e.target.value) || 0)} className={tiny} /></td>
    <td className="px-2 py-2 font-bold">{total.toFixed(0)} ج.م</td>
    <td className="px-2 py-2">{row.run?.status === "paid" ? <span className="text-primary">تم الصرف {row.run.paid_date}</span> : <div className="flex gap-1"><form id={`save-${row.key}`} action={createOrRefreshHrPayrollRunAction}><input type="hidden" name="person_type" value={row.personType} /><input type="hidden" name="person_id" value={row.personId} /><input type="hidden" name="period_from" value={from} /><input type="hidden" name="period_to" value={to} />{row.rule.fixed_basis !== "shift" && <input type="hidden" name="shift_count" value="0" />}<button className="h-8 rounded border border-border px-2 text-xs">{row.run ? "تحديث" : "حفظ"}</button></form>{row.run && <form action={payHrPayrollRunAction} className="flex gap-1"><input type="hidden" name="payroll_run_id" value={row.run.id} /><input type="hidden" name="paid_date" value={today} /><input type="hidden" name="payment_method" value="cash" /><button className="h-8 rounded btn-3d-primary px-2 text-xs">تم الصرف</button></form>}</div>}</td>
  </tr>;
}

export default function HrPayrollTable({ rows, from, to, today }: { rows: Row[]; from: string; to: string; today: string }) {
  const [method, setMethod] = useState("cash");
  const storedTotal = useMemo(() => rows.reduce((sum, row) => sum + (row.run?.total_amount ?? calculateHrPayroll(row.rule, row.net, row.run?.shift_count ?? 0).totalAmount), 0), [rows]);
  return <section className="card-3d rounded-xl p-4 space-y-3"><div className="flex flex-wrap items-end justify-between gap-3"><div><h2 className="font-semibold">استحقاقات الأطباء والموظفين</h2><p className="mt-1 text-xs text-muted">اكتب الشيفتات والحوافز والخصومات؛ الإجمالي يتغير فورًا. احفظ الصف قبل الصرف.</p></div><form action={payAllHrPayrollRunsAction} className="flex flex-wrap items-end gap-2"><input type="hidden" name="period_from" value={from} /><input type="hidden" name="period_to" value={to} /><input name="paid_date" type="date" defaultValue={today} className="h-9 rounded border border-border bg-background px-2 text-xs" /><select name="payment_method" value={method} onChange={(e) => setMethod(e.target.value)} className="h-9 rounded border border-border bg-background px-2 text-xs">{paymentMethods.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}</select><button className="h-9 rounded btn-3d-primary px-3 text-xs">تم صرف كل الكشوف المحفوظة</button></form></div>
    <div className="overflow-x-auto"><table className="w-full text-xs"><thead className="bg-primary-soft text-primary-dark"><tr><th className="p-2 text-right">الاسم</th><th className="p-2 text-right">صافي التحصيل</th><th className="p-2 text-right">الثابت/الشيفتات</th><th className="p-2 text-right">النسبة</th><th className="p-2 text-right">حوافز</th><th className="p-2 text-right">خصومات</th><th className="p-2 text-right">الإجمالي</th><th className="p-2 text-right">الصرف</th></tr></thead><tbody>{(["doctor", "employee", "nursing"] as const).map((group) => { const list = rows.filter((row) => row.group === group); if (!list.length) return null; const subtotal = list.reduce((sum, row) => sum + (row.run?.total_amount ?? calculateHrPayroll(row.rule, row.net, 0).totalAmount), 0); return [<tr key={`${group}-title`} className="border-t-2 border-primary/20 bg-background"><td colSpan={6} className="p-2 font-bold">{groupLabels[group]}</td><td className="p-2 font-bold">{subtotal.toFixed(0)} ج.م</td><td /></tr>, ...list.map((row) => <PayrollRow key={row.key} row={row} from={from} to={to} today={today} />)];})}{!rows.length && <tr><td colSpan={8} className="p-6 text-center text-muted">لا توجد قواعد HR سارية.</td></tr>}</tbody><tfoot><tr className="border-t-2 border-primary/30 font-bold"><td colSpan={6} className="p-2">الإجمالي الكلي المحفوظ/المبدئي</td><td className="p-2">{storedTotal.toFixed(0)} ج.م</td><td /></tr></tfoot></table></div>
  </section>;
}
