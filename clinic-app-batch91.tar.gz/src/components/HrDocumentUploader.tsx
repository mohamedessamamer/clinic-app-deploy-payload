"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";

export default function HrDocumentUploader({ personType, personId }: { personType: "doctor" | "staff"; personId: number }) {
  const router = useRouter();
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  async function upload() {
    const file = fileRef.current?.files?.[0];
    if (!file) return;
    setBusy(true); setMessage("جاري الرفع...");
    const form = fileRef.current?.form;
    const documentType = String(new FormData(form!).get("document_type") || "other");
    const label = String(new FormData(form!).get("label") || "");
    try {
      const query = new URLSearchParams({ personType, personId: String(personId), documentType, label });
      const response = await fetch(`/api/hr-documents/upload?${query}`, { method: "POST", headers: { "content-type": file.type || "application/octet-stream", "x-file-name": encodeURIComponent(file.name) }, body: file });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || "تعذر رفع المستند");
      setMessage("تم الرفع"); form?.reset(); router.refresh();
    } catch (cause) { setMessage(cause instanceof Error ? cause.message : "تعذر رفع المستند"); }
    finally { setBusy(false); }
  }
  return <form className="flex flex-wrap items-end gap-2" onSubmit={(event) => { event.preventDefault(); void upload(); }}>
    <select name="document_type" className="h-9 rounded border border-border bg-background px-2 text-xs"><option value="id">بطاقة شخصية</option><option value="graduation">شهادة تخرج</option><option value="license">مزاولة المهنة</option><option value="contract">عقد</option><option value="other">مستند آخر</option></select>
    <input name="label" placeholder="وصف اختياري" className="h-9 w-40 rounded border border-border bg-background px-2 text-xs" />
    <input ref={fileRef} type="file" accept="image/*,.pdf" required className="max-w-56 text-xs" />
    <button disabled={busy} className="h-9 rounded border border-primary px-3 text-xs text-primary disabled:opacity-50">رفع المستند</button>
    {message && <span className="text-xs text-muted">{message}</span>}
  </form>;
}
