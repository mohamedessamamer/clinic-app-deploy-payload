"use client";

import { useState } from "react";
import { saveHrCompensationRuleAction, stopHrCompensationRuleAction } from "@/app/hr/actions";

type Rule = {
  id: number; person_type: "doctor" | "user"; person_id: number; staff_group: "doctor" | "employee" | "nursing";
  compensation_type: "fixed" | "percentage" | "mixed"; fixed_basis: "monthly" | "shift"; fixed_amount: number;
  percentage_basis: "personal" | "clinic"; percentage_mode: "fixed" | "progressive"; percentage: number;
  effective_from: string; effective_to: string | null; active: number;
};
type Person = { personType: "doctor" | "user"; id: number; name: string; defaultGroup: "doctor" | "employee" | "nursing"; rule: Rule | null };

function RuleCard({ person, today }: { person: Person; today: string }) {
  const rule = person.rule;
  const [group, setGroup] = useState(rule?.staff_group ?? person.defaultGroup);
  const [type, setType] = useState(rule?.compensation_type ?? "fixed");
  const [fixedBasis, setFixedBasis] = useState(rule?.fixed_basis ?? "monthly");
  const [percentageBasis, setPercentageBasis] = useState(rule?.percentage_basis ?? (person.personType === "doctor" ? "personal" : "clinic"));
  const [percentageMode, setPercentageMode] = useState(rule?.percentage_mode ?? "fixed");
  const hasFixed = type === "fixed" || type === "mixed";
  const hasPercentage = type === "percentage" || type === "mixed";
  return <article className="rounded-xl border border-border bg-surface p-4 space-y-3">
    <div className="flex items-start justify-between gap-3"><div><h3 className="font-semibold">{person.name}</h3><p className="text-xs text-muted mt-1">{rule?.active ? "قاعدة نشطة" : "لم تُعرّف قاعدة راتب بعد"}</p></div>{rule?.active ? <form action={stopHrCompensationRuleAction}><input type="hidden" name="rule_id" value={rule.id} /><button className="text-xs text-danger hover:underline">إيقاف القاعدة</button></form> : null}</div>
    <form action={saveHrCompensationRuleAction} className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3 items-end">
      <input type="hidden" name="person_type" value={person.personType} /><input type="hidden" name="person_id" value={person.id} />
      {person.personType === "user" && <label><span className="block text-xs text-muted mb-1">التصنيف</span><select name="staff_group" value={group} onChange={(e) => setGroup(e.target.value as typeof group)} className="w-full rounded border border-border bg-background px-2 py-2 text-sm"><option value="employee">موظف</option><option value="nursing">تمريض</option></select></label>}
      <label><span className="block text-xs text-muted mb-1">طريقة الاستحقاق</span><select name="compensation_type" value={type} onChange={(e) => setType(e.target.value as typeof type)} className="w-full rounded border border-border bg-background px-2 py-2 text-sm"><option value="fixed">ثابت</option><option value="percentage">نسبة</option><option value="mixed">ثابت + نسبة</option></select></label>
      {hasFixed && <><label><span className="block text-xs text-muted mb-1">قاعدة الثابت</span><select name="fixed_basis" value={fixedBasis} onChange={(e) => setFixedBasis(e.target.value as typeof fixedBasis)} className="w-full rounded border border-border bg-background px-2 py-2 text-sm"><option value="monthly">شهري</option><option value="shift">بالشيفت</option></select></label><label><span className="block text-xs text-muted mb-1">{fixedBasis === "shift" ? "قيمة الشيفت" : "الراتب الشهري"}</span><input name="fixed_amount" type="number" min="0" step="0.01" required defaultValue={rule?.fixed_amount ?? 0} className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label></>}
      {!hasFixed && <><input type="hidden" name="fixed_basis" value="monthly" /><input type="hidden" name="fixed_amount" value="0" /></>}
      {hasPercentage && <><label><span className="block text-xs text-muted mb-1">أساس النسبة</span><select name="percentage_basis" value={percentageBasis} onChange={(e) => setPercentageBasis(e.target.value as typeof percentageBasis)} className="w-full rounded border border-border bg-background px-2 py-2 text-sm">{person.personType === "doctor" && <option value="personal">تحصيله الشخصي بعد المعمل</option>}<option value="clinic">إجمالي تحصيل العيادة بعد المعمل</option></select></label><label><span className="block text-xs text-muted mb-1">نوع النسبة</span><select name="percentage_mode" value={percentageMode} onChange={(e) => setPercentageMode(e.target.value as typeof percentageMode)} className="w-full rounded border border-border bg-background px-2 py-2 text-sm"><option value="fixed">نسبة ثابتة</option>{person.personType === "doctor" && <option value="progressive">تصاعدية للأطباء حتى 30%</option>}</select></label>{percentageMode === "fixed" ? <label><span className="block text-xs text-muted mb-1">النسبة %</span><input name="percentage" type="number" min="0" max="100" step="0.01" required defaultValue={rule?.percentage ?? 0} className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label> : <input type="hidden" name="percentage" value="0" />}</>}
      {!hasPercentage && <><input type="hidden" name="percentage_basis" value={person.personType === "doctor" ? "personal" : "clinic"} /><input type="hidden" name="percentage_mode" value="fixed" /><input type="hidden" name="percentage" value="0" /></>}
      <label><span className="block text-xs text-muted mb-1">تسري من</span><input name="effective_from" type="date" required defaultValue={rule?.effective_from ?? today} className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label>
      <label><span className="block text-xs text-muted mb-1">تنتهي في (اختياري)</span><input name="effective_to" type="date" defaultValue={rule?.effective_to ?? ""} className="w-full rounded border border-border bg-background px-2 py-2 text-sm" /></label>
      <button className="rounded-md btn-3d-primary px-4 py-2 text-sm">حفظ القاعدة</button>
    </form>
  </article>;
}

export default function HrRulesManager({ people, today }: { people: Person[]; today: string }) {
  const groups = [{ key: "doctor", title: "الأطباء" }, { key: "employee", title: "الموظفون" }, { key: "nursing", title: "التمريض" }] as const;
  return <div className="space-y-6">{groups.map((group) => {
    const list = people.filter((person) => (person.rule?.staff_group ?? person.defaultGroup) === group.key);
    return <section key={group.key} className="space-y-3"><div className="flex items-center gap-2"><h2 className="text-lg font-bold">{group.title}</h2><span className="rounded-full bg-primary-soft px-2 py-0.5 text-xs text-primary-dark">{list.length}</span></div>{list.length ? list.map((person) => <RuleCard key={`${person.personType}-${person.id}`} person={person} today={today} />) : <div className="rounded-lg border border-dashed border-border p-5 text-sm text-muted">لا يوجد أشخاص داخل هذا القسم حاليًا. يمكن نقل أي مستخدم إلى التمريض من خانة التصنيف داخل قاعدته.</div>}</section>;
  })}</div>;
}
