"use client";

import { useState, useTransition } from "react";
import { archiveManualTemplateAction, saveManualTemplateAction } from "@/app/whatsapp/actions";

export type ManualTemplateRow = { id: number; name: string; header_text: string | null; body_text: string; recipient_type: string; variable_map: string; quick_slot: number | null };
const variables = [
  ["", "بدون متغير"], ["patient_name", "اسم المريض"], ["appointment_date", "اليوم والتاريخ"],
  ["appointment_time", "الساعة"], ["doctor_name", "اسم الطبيب"], ["appointment_link", "رابط تأكيد/تعديل الموعد"], ["review_link", "رابط تقييم الزيارة"],
  ["patient_debt", "مديونية المريض"], ["contact_name", "اسم التواصل"],
];

function TemplateForm({ template, onSaved }: { template?: ManualTemplateRow; onSaved?: () => void }) {
  const [busy, startTransition] = useTransition();
  let map: Record<string, string> = {};
  try { map = JSON.parse(template?.variable_map || "{}"); } catch { map = {}; }
  return <form action={(form) => startTransition(async () => { const result = await saveManualTemplateAction(form); if (!result.ok) return alert(result.error); onSaved?.(); window.location.reload(); })} className="grid gap-3 sm:grid-cols-2">
    {template && <input type="hidden" name="id" value={template.id} />}
    <label className="text-sm">اسم القالب<input name="name" required defaultValue={template?.name} className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2" /></label>
    <label className="text-sm">الفئة<select name="recipient_type" defaultValue={template?.recipient_type || "patient"} className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2"><option value="patient">مريض</option><option value="doctor">طبيب</option><option value="supplier">مورد</option><option value="other">أخرى</option></select></label>
    <label className="text-sm">Header — يظهر عريضًا<input name="header_text" defaultValue={template?.header_text || ""} className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2" /></label>
    <label className="text-sm">مكان الوصول السريع<select name="quick_slot" defaultValue={template?.quick_slot || ""} className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2"><option value="">داخل كل القوالب</option>{[1,2,3,4,5].map((slot) => <option key={slot} value={slot}>رسالة سريعة رقم {slot}</option>)}</select></label>
    <label className="text-sm sm:col-span-2">نص الرسالة<textarea name="body_text" required rows={5} defaultValue={template?.body_text} placeholder="أهلًا {{1}} ..." className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2" /></label>
    <div className="sm:col-span-2"><p className="mb-2 text-xs text-muted">عرّف المتغيرات المستخدمة في النص:</p><div className="grid grid-cols-2 gap-2 sm:grid-cols-4">{[1,2,3,4,5,6,7,8].map((index) => <label key={index} className="text-xs">({index})<select name={`variable_${index}`} defaultValue={map[String(index)] || ""} className="mt-1 w-full rounded-md border border-border bg-background px-2 py-2">{variables.map(([value,label]) => <option key={value} value={value}>{label}</option>)}</select></label>)}</div></div>
    <div className="sm:col-span-2"><button disabled={busy} className="rounded-md btn-3d-primary px-4 py-2 text-sm">{busy ? "جاري الحفظ..." : template ? "حفظ التعديل" : "حفظ القالب"}</button></div>
  </form>;
}

export default function WhatsAppManualTemplates({ templates, canManage }: { templates: ManualTemplateRow[]; canManage: boolean }) {
  const [showAll, setShowAll] = useState(false);
  const quick = templates.filter((item) => item.quick_slot).sort((a,b) => (a.quick_slot || 9) - (b.quick_slot || 9));
  const shown = showAll ? templates : quick;
  return <section className="card-3d rounded-xl p-5 space-y-4" dir="rtl">
    <div className="flex flex-wrap items-center justify-between gap-3"><div><h2 className="font-semibold">القوالب اليدوية</h2><p className="mt-1 text-xs text-muted">الخمس رسائل السريعة تظهر في شاشة واتساب وفي قائمة المريض؛ الباقي محفوظ داخل «كل القوالب».</p></div><button type="button" onClick={() => setShowAll((value) => !value)} className="rounded-md border border-border px-3 py-2 text-sm">{showAll ? "الخمس السريعة" : `كل القوالب (${templates.length})`}</button></div>
    <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">{shown.map((template) => <details key={template.id} className="rounded-lg border border-border bg-background p-3"><summary className="cursor-pointer font-medium">{template.quick_slot ? `${template.quick_slot}. ` : ""}{template.name}<span className="mr-2 text-xs text-muted">{template.recipient_type}</span></summary><p className="my-3 whitespace-pre-wrap text-sm text-muted">{template.header_text ? `*${template.header_text}*\n` : ""}{template.body_text}</p>{canManage && <><TemplateForm template={template} /><button type="button" onClick={async () => { if (!confirm("إخفاء هذا القالب؟")) return; await archiveManualTemplateAction(template.id); window.location.reload(); }} className="mt-3 text-xs text-danger hover:underline">إخفاء القالب</button></>}</details>)}</div>
    {canManage && <details className="rounded-lg border border-dashed border-primary p-4"><summary className="cursor-pointer font-medium text-primary">+ إنشاء قالب يدوي جديد</summary><div className="mt-4"><TemplateForm /></div></details>}
  </section>;
}
