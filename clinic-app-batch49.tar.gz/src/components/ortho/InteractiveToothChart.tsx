"use client";

// ===================================================================
// شارت التقويم v2 — "Interactive chart" (النسخة الحقيقية، مدموجة مع قاعدة
// البيانات، دمج 2026-08-27)
// ===================================================================
// نفس السلوك بالظبط اللي كان في البروتوتايب المعزول (src/components/prototype/
// InteractiveToothChart.tsx) — الفرق الوحيد إن كل أكشن بيغيّر حالة بيستدعي
// server action حقيقي بدل useState محلي بس. الـprops (teeth/stripCounts/
// miniscrews) جايين جاهزين من الصفحة (Server Component)، مش state داخلي —
// بعد كل أكشن ناجح بنعمل router.refresh() عشان الصفحة تجيب أحدث نسخة من
// قاعدة البيانات (تشمل تحديث الـInventory list والـInteractive report في
// الأب OrthoChartV2 كمان، مش بس الشارت نفسه).
//
// bulkBond اتشال من هنا (كان معرّض عن طريق ref في البروتوتايب) — دلوقتي
// التركيب الجماعي بيحصل جوه saveOrthoVisitAction نفسها لما الخدمة تكون
// "Bonding Upper/Lower" (transaction واحدة مع حفظ الزيارة)، فمفيش داعي لربط
// منفصل بين الكومبوننتين.

import { useState, useTransition } from "react";
import { getClinicToday } from "@/lib/clinic-date";
import { useRouter } from "next/navigation";
import { UPPER_ROW, LOWER_ROW, gapsFor, type ToothMeta } from "@/lib/ortho/fdi-teeth";
import {
  manualBondToothAction,
  confirmDebondAction,
  confirmNoBracketsAction,
  confirmRebondAction,
  toggleExtractedAction,
  recordStrippingAction,
  undoStrippingAction,
  toggleMiniscrewAction,
  saveToothCommentAction,
} from "@/app/patients/[id]/orthodontics/ortho-v2-actions";

export type BracketStatus = "none" | "bonded" | "broken";

export interface ToothState {
  bracket: BracketStatus;
  debondDate: string | null;
  bondedDate: string | null;
  rebondCount: number;
  extracted: boolean;
  comment: string;
}

type ToothStateMap = Record<number, ToothState>;
type GapMode = "none" | "stripping" | "miniscrew";

function emptyToothState(): ToothState {
  return { bracket: "none", debondDate: null, bondedDate: null, rebondCount: 0, extracted: false, comment: "" };
}

function todayStr(): string {
  return getClinicToday();
}

function daysSince(dateStr: string | null): number | null {
  if (!dateStr) return null;
  const then = new Date(dateStr);
  if (Number.isNaN(then.getTime())) return null;
  return Math.floor((Date.now() - then.getTime()) / (1000 * 60 * 60 * 24));
}

const UPPER_GAPS = gapsFor(UPPER_ROW);
const LOWER_GAPS = gapsFor(LOWER_ROW);

function isMolarPosition(position: number): boolean {
  return position >= 6;
}

const ALL_TEETH = [...UPPER_ROW, ...LOWER_ROW];
const TOOTH_BY_FDI: Record<number, ToothMeta> = Object.fromEntries(ALL_TEETH.map((t) => [t.fdi, t]));

export default function InteractiveToothChart({
  patientId,
  editable,
  teeth,
  stripCounts,
  miniscrews,
  upperBulkBondingDate = null,
  lowerBulkBondingDate = null,
}: {
  patientId: number;
  editable: boolean;
  teeth: ToothStateMap;
  stripCounts: Record<string, number>;
  miniscrews: Record<string, boolean>;
  upperBulkBondingDate?: string | null;
  lowerBulkBondingDate?: string | null;
}) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();

  const [mode, setMode] = useState<GapMode>("none");
  const [rebondPrompt, setRebondPrompt] = useState<{ fdi: number } | null>(null);
  const [debondPrompt, setDebondPrompt] = useState<{ fdi: number } | null>(null);
  const [extractMenu, setExtractMenu] = useState<{ fdi: number; x: number; y: number } | null>(null);
  const [selectedTooth, setSelectedTooth] = useState<number | null>(null);
  const [commentDraft, setCommentDraft] = useState("");

  function stateFor(fdi: number): ToothState {
    return teeth[fdi] ?? emptyToothState();
  }

  function run(action: () => Promise<{ ok: boolean; reason?: string }>) {
    startTransition(async () => {
      const res = await action();
      if (!res.ok) window.alert(res.reason || "حصل خطأ، حاول تاني.");
      router.refresh();
    });
  }

  function handleBracketDoubleClick(t: ToothMeta) {
    if (!editable || isPending) return;
    const state = stateFor(t.fdi);
    if (state.bracket === "bonded") {
      setDebondPrompt({ fdi: t.fdi });
    } else if (state.bracket === "broken") {
      setRebondPrompt({ fdi: t.fdi });
    } else {
      if (state.extracted) {
        window.alert(`Tooth ${t.fdi} is marked extracted — it can't get a bracket/tube. Undo the extraction first (right-click the tooth) if this was a mistake.`);
        return;
      }
      const isMolar = isMolarPosition(t.position);
      if (window.confirm(`Bond a new ${isMolar ? "tube" : "bracket"} on tooth ${t.fdi}?`)) {
        run(() => manualBondToothAction({ patientId, fdi: t.fdi, date: todayStr() }));
      }
    }
  }

  function confirmDebonded() {
    if (!debondPrompt) return;
    const { fdi } = debondPrompt;
    run(() => confirmDebondAction({ patientId, fdi, date: todayStr() }));
    setDebondPrompt(null);
  }

  function confirmNoBrackets() {
    if (!debondPrompt) return;
    const { fdi } = debondPrompt;
    run(() => confirmNoBracketsAction({ patientId, fdi }));
    setDebondPrompt(null);
  }

  function confirmRebond(kind: "new" | "old") {
    if (!rebondPrompt) return;
    const { fdi } = rebondPrompt;
    run(() => confirmRebondAction({ patientId, fdi, kind, date: todayStr() }));
    setRebondPrompt(null);
  }

  function toggleExtracted() {
    if (!extractMenu) return;
    const { fdi } = extractMenu;
    run(() => toggleExtractedAction({ patientId, fdi }));
    setExtractMenu(null);
  }

  function handleGapClick(gapId: string) {
    if (!editable || isPending) return;
    if (mode === "stripping") {
      run(() => recordStrippingAction({ patientId, gapId }));
    } else if (mode === "miniscrew") {
      run(() => toggleMiniscrewAction({ patientId, gapId }));
    }
  }

  function handleStripUndo(gapId: string) {
    if (!editable || isPending) return;
    run(() => undoStrippingAction({ patientId, gapId }));
  }

  function saveComment() {
    if (selectedTooth == null) return;
    run(() => saveToothCommentAction({ patientId, fdi: selectedTooth, comment: commentDraft }));
  }

  function openToothDetails(fdi: number) {
    setSelectedTooth(fdi);
    setCommentDraft(stateFor(fdi).comment);
  }

  function backgroundClick() {
    if (mode !== "none") setMode("none");
    setSelectedTooth(null);
  }

  function bracketColor(status: BracketStatus) {
    // الشكل فقط هو الذي تغير: الزر نفسه والـdouble click والـstate/actions
    // كما هي. البراكيت صار مرسوماً كقطعة معدنية بدل المربع الأزرق.
    if (status === "bonded") return "ortho-bracket--bonded";
    if (status === "broken") return "ortho-bracket--broken";
    return "ortho-bracket--empty";
  }

  function useLongPress(onLongPress: (e: React.TouchEvent) => void) {
    let timer: ReturnType<typeof setTimeout> | null = null;
    let moved = false;
    let startX = 0,
      startY = 0;
    return {
      onTouchStart: (e: React.TouchEvent) => {
        moved = false;
        startX = e.touches[0].clientX;
        startY = e.touches[0].clientY;
        timer = setTimeout(() => {
          if (!moved) onLongPress(e);
        }, 550);
      },
      onTouchMove: (e: React.TouchEvent) => {
        const dx = Math.abs(e.touches[0].clientX - startX);
        const dy = Math.abs(e.touches[0].clientY - startY);
        if (dx > 10 || dy > 10) moved = true;
      },
      onTouchEnd: () => {
        if (timer) clearTimeout(timer);
      },
    };
  }

  function renderRow(row: ToothMeta[], gaps: { id: string; a: number; b: number }[], arch: "upper" | "lower") {
    const bulkBondingDate = arch === "upper" ? upperBulkBondingDate : lowerBulkBondingDate;
    return (
      <div className="relative flex justify-center ortho-arch-row">
        <div className={`ortho-bulk-bonding-date ortho-bulk-bonding-date--${arch}`}>
          <span>{arch === "upper" ? "Upper bulk bonding" : "Lower bulk bonding"}</span>
          <strong>{bulkBondingDate ? bulkBondingDate.slice(0, 10) : "Not recorded"}</strong>
        </div>
        {row.map((t, idx) => {
          const state = stateFor(t.fdi);
          const isMidline = idx === 7;
          return (
            <div key={t.fdi} className="flex items-stretch">
              <div
                className={`relative z-0 flex flex-col items-center px-0 cursor-pointer select-none ${
                  selectedTooth === t.fdi ? "ring-2 ring-primary rounded" : ""
                }`}
                style={{ opacity: state.extracted ? 0.25 : 1 }}
                onClick={(e) => {
                  e.stopPropagation();
                  openToothDetails(t.fdi);
                }}
                onContextMenu={(e) => {
                  e.stopPropagation();
                  e.preventDefault();
                  if (!editable) return;
                  setExtractMenu({ fdi: t.fdi, x: e.clientX, y: e.clientY });
                }}
                {...useLongPress(() => {
                  if (!editable) return;
                  setExtractMenu({ fdi: t.fdi, x: 200, y: 200 });
                })}
                title={`FDI ${t.fdi}`}
              >
                {/* طبقة الرسم فقط تغيّرت لتعرض تاج السن بشكل أخف وأقرب لشكل
                    الشارت الجديد. العنصر القابل للضغط وحالة كل سن ما زالا كما
                    هما، لذلك لا تتأثر وظائف الـ interactive chart. */}
                <div className={`ortho-tooth-visual ortho-tooth-visual--${arch}`}>
                  <img
                    src={`/ortho-v2/teeth/${t.image}`}
                    alt={`FDI ${t.fdi}`}
                    className={`ortho-tooth-image pointer-events-none ${t.flip ? "ortho-tooth-image--flip" : ""}`}
                    draggable={false}
                  />
                </div>

                {state.rebondCount > 0 && (
                  <span
                    className="absolute z-10 text-[9px] leading-none bg-white border border-border rounded-full w-4 h-4 flex items-center justify-center"
                    style={{ [arch === "upper" ? "top" : "bottom"]: "38%", left: "50%", transform: "translateX(-50%)" } as React.CSSProperties}
                  >
                    {state.rebondCount}
                  </span>
                )}

                <button
                  type="button"
                  onDoubleClick={(e) => {
                    e.stopPropagation();
                    handleBracketDoubleClick(t);
                  }}
                  className={`ortho-bracket absolute z-10 ${bracketColor(state.bracket)} ${!editable ? "cursor-default" : ""}`}
                  style={
                    arch === "upper"
                      ? { bottom: "30%", left: "50%", transform: "translateX(-50%)" }
                      : { top: "17%", left: "50%", transform: "translateX(-50%)" }
                  }
                  title={
                    state.bracket === "bonded"
                      ? "Bracket bonded — double-click to record a break"
                      : state.bracket === "broken"
                      ? `Broken ${state.debondDate ? "(" + state.debondDate + ")" : ""} — double-click to rebond`
                      : "No bracket"
                  }
                ><span /><i /></button>

                {state.bracket === "broken" && state.debondDate && (
                  <span
                    className="absolute z-10 text-[8px] leading-none bg-red-50 text-red-700 border border-red-300 rounded px-0.5 whitespace-nowrap"
                    style={{ [arch === "upper" ? "bottom" : "top"]: "2%", left: "50%", transform: "translateX(-50%)" } as React.CSSProperties}
                  >
                    {state.debondDate}
                  </span>
                )}

                <span className="text-[9px] text-muted mt-0.5">{t.fdi}</span>
              </div>

              {idx < row.length - 1 && (
                <div
                  role="button"
                  tabIndex={0}
                  onClick={(e) => {
                    e.stopPropagation();
                    handleGapClick(gaps[idx].id);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.stopPropagation();
                      handleGapClick(gaps[idx].id);
                    }
                  }}
                  className={`w-2.5 sm:w-3 relative z-10 cursor-pointer ${isMidline ? "mx-0.5" : ""}`}
                  title={mode === "none" ? undefined : "Click to record"}
                >
                  {isMidline && <span className="absolute inset-y-4 left-1/2 w-px bg-gray-300" />}
                  {mode === "stripping" && <span className="absolute inset-y-2 left-1/2 w-px bg-amber-500" />}
                  {mode === "miniscrew" && (
                    <span
                      className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2.5 h-2.5 rounded-full border ${
                        miniscrews[gaps[idx].id] ? "bg-blue-500 border-blue-700" : "border-muted"
                      }`}
                    />
                  )}
                  {mode !== "stripping" && stripCounts[gaps[idx].id] > 0 && <span className="absolute inset-y-2 left-1/2 w-px bg-amber-300" />}
                  {mode !== "miniscrew" && miniscrews[gaps[idx].id] && (
                    <span className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2.5 h-2.5 rounded-full bg-blue-500 border border-blue-700" />
                  )}
                  {stripCounts[gaps[idx].id] > 0 && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleStripUndo(gaps[idx].id);
                      }}
                      className="absolute z-20 -top-1.5 left-1/2 -translate-x-1/2 min-w-[15px] h-[15px] px-0.5 flex items-center justify-center text-[10px] font-semibold leading-none bg-white text-foreground border border-amber-400 rounded-full shadow-sm"
                      title="Click to undo one stripping mark"
                    >
                      {stripCounts[gaps[idx].id]}
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <div className={`space-y-4 ${isPending ? "opacity-70 pointer-events-none" : ""}`} onClick={backgroundClick}>
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-4 text-xs text-muted flex-wrap">
          <span className="flex items-center gap-1">
            <span className="w-3 h-3 inline-block bg-[#e8dcc8] border border-[#c9b892]" /> No bracket
          </span>
          <span className="flex items-center gap-1">
            <span className="w-3 h-3 inline-block bg-blue-500 border border-blue-700" /> Bonded
          </span>
          <span className="flex items-center gap-1">
            <span className="w-3 h-3 inline-block bg-red-500 border border-red-700" /> Broken
          </span>
        </div>
        {editable && (
          <div className="flex gap-2">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setMode((m) => (m === "stripping" ? "none" : "stripping"));
              }}
              className={`px-3 py-1.5 rounded-md border text-xs ${mode === "stripping" ? "bg-primary text-white border-primary" : "border-border hover:bg-primary-soft"}`}
            >
              Stripping
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setMode((m) => (m === "miniscrew" ? "none" : "miniscrew"));
              }}
              className={`px-3 py-1.5 rounded-md border text-xs ${mode === "miniscrew" ? "bg-primary text-white border-primary" : "border-border hover:bg-primary-soft"}`}
            >
              Miniscrew
            </button>
          </div>
        )}
      </div>

      {editable && (
        <p className="text-xs text-muted">
          Double-click a bracket box = record a debond / rebond (or &quot;No brackets&quot; to fix a bulk-bonding mistake within a week).
          Right-click (or long-press on mobile) anywhere else on the tooth = extraction.
        </p>
      )}

      <div className="overflow-x-auto py-2">
        <div className="min-w-[680px] space-y-3">
          {renderRow(UPPER_ROW, UPPER_GAPS, "upper")}
          <div className="border-t border-dashed border-border" />
          {renderRow(LOWER_ROW, LOWER_GAPS, "lower")}
        </div>
      </div>

      {selectedTooth != null && (
        <div className="card-3d rounded-lg p-3 text-sm space-y-2" onClick={(e) => e.stopPropagation()}>
          <div className="flex items-center justify-between">
            <span className="font-semibold">Tooth FDI {selectedTooth} details</span>
            <button type="button" className="text-xs text-muted hover:underline" onClick={() => setSelectedTooth(null)}>
              Close
            </button>
          </div>
          <textarea
            value={commentDraft}
            onChange={(e) => setCommentDraft(e.target.value)}
            onBlur={saveComment}
            placeholder="Note on this tooth..."
            rows={2}
            disabled={!editable}
            className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-xs disabled:opacity-60"
          />
        </div>
      )}

      {debondPrompt && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/30" onClick={() => setDebondPrompt(null)}>
          <div className="card-3d rounded-lg p-4 space-y-3 w-72" onClick={(e) => e.stopPropagation()}>
            <div className="text-sm font-semibold text-center">Tooth {debondPrompt.fdi}</div>
            <div className="flex flex-col gap-2">
              <button type="button" onClick={confirmDebonded} className="btn-3d-primary px-3 py-1.5 rounded-md text-xs">
                Debonded
              </button>
              {(() => {
                const days = daysSince(stateFor(debondPrompt.fdi).bondedDate);
                if (days === null || days > 7) return null;
                return (
                  <button
                    type="button"
                    onClick={confirmNoBrackets}
                    className="px-3 py-1.5 rounded-md border border-border text-xs hover:bg-primary-soft"
                    title="This tooth was actually never bonded — corrects a bulk-bonding mistake"
                  >
                    No brackets (bonding mistake)
                  </button>
                );
              })()}
              <button type="button" onClick={() => setDebondPrompt(null)} className="text-xs text-muted hover:underline">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {rebondPrompt && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/30" onClick={() => setRebondPrompt(null)}>
          <div className="card-3d rounded-lg p-4 space-y-3 w-64" onClick={(e) => e.stopPropagation()}>
            <div className="text-sm font-semibold text-center">Rebond tooth {rebondPrompt.fdi}</div>
            <div className="flex gap-2 justify-center">
              <button type="button" onClick={() => confirmRebond("new")} className="btn-3d-primary px-3 py-1.5 rounded-md text-xs">
                New bracket
              </button>
              <button type="button" onClick={() => confirmRebond("old")} className="px-3 py-1.5 rounded-md border border-border text-xs hover:bg-primary-soft">
                Old bracket
              </button>
            </div>
          </div>
        </div>
      )}

      {extractMenu && (
        <div className="fixed inset-0 z-40" onClick={() => setExtractMenu(null)}>
          <div className="absolute card-3d rounded-md shadow-lg py-1 text-sm" style={{ left: extractMenu.x, top: extractMenu.y }} onClick={(e) => e.stopPropagation()}>
            <button type="button" onClick={toggleExtracted} className="w-full text-left px-3 py-1.5 hover:bg-primary-soft whitespace-nowrap">
              {stateFor(extractMenu.fdi).extracted ? "Undo extraction" : "Extracted"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export { TOOTH_BY_FDI };
