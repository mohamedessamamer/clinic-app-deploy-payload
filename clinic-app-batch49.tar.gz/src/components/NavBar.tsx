"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ROLE_LABELS, type SessionPayload } from "@/lib/auth";
import LogoutButton from "./LogoutButton";
import AccountMenu from "./AccountMenu";
import NotificationCenter from "./NotificationCenter";
import StaffChat from "./StaffChat";
import ThemeToggle from "./ThemeToggle";
import { HomeIcon, CalendarIcon, PatientsIcon, InvoiceIcon, ExpensesIcon, InventoryIcon, ReportsIcon, SettingsIcon, ToothLogoIcon } from "./icons";

type IconComponent = (props: { className?: string }) => React.JSX.Element;

// ترتيب ثابت مطلوب صراحة من المستخدم — أي لينك ظاهر لأي حساب (سواء بحكم الدور
// الثابت أو صلاحية قابلة للمنح زي reports_full/reports_own أو manage_inventory)
// لازم يفضل بنفس الترتيب ده دايمًا، مش بس للأدمن: الرئيسية، الاستقبال، المرضى،
// الفواتير، المخزن، التقارير. "الإعدادات" (أدمن بس) مش جزء من الترتيب اللي
// المستخدم حدده فمتسيبة آخر حاجة زي ما كانت. كل لينك له لون شارة مختلف (tone)
// عشان تسهيل التمييز البصري السريع بين الصفحات — نفس فكرة نموذج التصميم (ج)
// اللي المستخدم اختاره.
function buildOrderedLinks(
  session: SessionPayload,
  canViewReports: boolean,
  canViewInventory: boolean,
  canViewExpenses: boolean,
  canViewPatients: boolean
): { href: string; label: string; icon: IconComponent; tone?: string }[] {
  const candidates: { href: string; label: string; icon: IconComponent; tone?: string; visible: boolean }[] = [
    { href: "/", label: "الرئيسية", icon: HomeIcon, visible: true },
    // للاستقبال بس: مفيش داعي للينك منفصل هنا — "الرئيسية" أصلاً بتوجّههم لنفس
    // الصفحة دي تلقائيًا (شوف src/app/page.tsx)، فاللينك المنفصل كان مكرر بصريًا.
    { href: "/front-desk", label: "الاستقبال", icon: CalendarIcon, tone: "tone-blue", visible: session.role === "admin" },
    { href: "/patients", label: "المرضى", icon: PatientsIcon, tone: "tone-purple", visible: canViewPatients },
    {
      href: "/invoices",
      label: "الفواتير",
      icon: InvoiceIcon,
      tone: "tone-amber",
      // الطبيب يدخلها كتقرير يومه الشخصي فقط؛ صفحة الفواتير نفسها بتفرض فلترة
      // الطبيب والتاريخ على السيرفر، فلا يمكنه فتح فواتير زملائه أو أيام أخرى.
      visible: ["admin", "reception", "accountant", "doctor"].includes(session.role),
    },
    { href: "/expenses", label: "المصروفات", icon: ExpensesIcon, tone: "tone-amber", visible: canViewExpenses },
    { href: "/inventory", label: "المخزن", icon: InventoryIcon, tone: "tone-teal", visible: canViewInventory },
    { href: "/reports", label: "التقارير", icon: ReportsIcon, tone: "tone-red", visible: canViewReports },
    { href: "/settings", label: "الإعدادات", icon: SettingsIcon, visible: session.role === "admin" },
  ];
  return candidates.filter((c) => c.visible).map(({ href, label, icon, tone }) => ({ href, label, icon, tone }));
}

export default function NavBar({
  session,
  canViewReports = false,
  canViewInventory = false,
  canViewExpenses = false,
  canViewPatients = false,
  medicalUiLanguage = "en",
  initialNotifications = [],
}: {
  session: SessionPayload;
  canViewReports?: boolean;
  canViewInventory?: boolean;
  canViewExpenses?: boolean;
  canViewPatients?: boolean;
  medicalUiLanguage?: "en" | "ar";
  initialNotifications?: { id: number; type: string; title: string; body: string; patient_id: number | null; notification_case_id: number | null; read_at: string | null; created_at: string }[];
}) {
  const pathname = usePathname();
  const visibleLinks = buildOrderedLinks(session, canViewReports, canViewInventory, canViewExpenses, canViewPatients);

  const navigation = visibleLinks.map((l) => {
    const Icon = l.icon;
    const active = l.href === "/" ? pathname === "/" : pathname.startsWith(l.href);
    return <Link key={l.href} href={l.href} data-active={active} className="clinic-sidebar-link"><Icon /><span>{l.label}</span></Link>;
  });

  return <>
    <aside className="clinic-sidebar">
      <div className="clinic-sidebar-brand"><ToothLogoIcon /><span>عيادتي</span><small>Dental Clinic</small></div>
      <nav className="flex flex-col gap-1">{navigation}</nav>
      <div className="clinic-sidebar-utility"><ThemeToggle /></div>
    </aside>
    <header className="clinic-mobile-header">
      <div className="flex items-center gap-2 text-primary font-bold"><ToothLogoIcon className="w-6 h-6" /><span>عيادتي</span></div>
      <nav className="clinic-mobile-nav">{visibleLinks.map((l) => { const active = l.href === "/" ? pathname === "/" : pathname.startsWith(l.href); return <Link key={l.href} href={l.href} data-active={active}>{l.label}</Link>; })}</nav>
      <ThemeToggle />
    </header>
    <div className="clinic-topbar">
      <span className="hidden sm:inline text-xs text-muted">نظام إدارة العيادة</span>
      <NotificationCenter initialNotifications={initialNotifications} canResolveFollowups={["reception", "admin", "clinic_manager"].includes(session.role)} />
      <AccountMenu fullName={session.fullName} roleLabel={ROLE_LABELS[session.role]} medicalUiLanguage={medicalUiLanguage} />
      <LogoutButton />
    </div>
    <StaffChat currentUserId={session.userId} role={session.role} />
  </>;
}
