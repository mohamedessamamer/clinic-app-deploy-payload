"use client";

import { useState, useTransition } from "react";
import { updateDoctorConsultantAction } from "@/app/settings/actions";

type Doctor = { id: number; full_name: string; is_consultant: number };

// تعريف دكتور كـ"استشاري" + ربطه بدكاترة مساعدين من قائمة الأطباء الموجودة على
// السيستم (دفعة 22) — many-to-many، استشاري واحد يقدر يختار أكتر من مساعد.
// دخل الحالة اللي بيسجلها المساعد باسمه بيتحسب لتقرير الاستشاري (اتفاق مع
// المستخدم)، مش للمساعد نفسه.
export default function DoctorConsultantManager({
  doctors,
  assistantsByConsultant,
}: {
  doctors: Doctor[];
  assistantsByConsultant: Record<number, number[]>;
}) {
  const [openId, setOpenId] = useState<number | null>(null);
  const [isPending, startTransition] = useTransition();

  return (
    <div className="space-y-2">
      {doctors.map((d) => {
        const otherDoctors = doctors.filter((x) => x.id !== d.id);
        const currentAssistants = assistantsByConsultant[d.id] ?? [];
        const isOpen = openId === d.id;
        return (
          <div key={d.id} className="border border-border rounded-md px-3 py-2 text-sm space-y-2">
            <div className="flex items-center justify-between gap-3">
              <div>
                <span className="font-medium">{d.full_name}</span>{" "}
                {d.is_consultant ? <span className="text-xs text-primary">استشاري</span> : null}
              </div>
              <button
                type="button"
                onClick={() => setOpenId(isOpen ? null : d.id)}
                className="text-xs text-primary hover:underline"
              >
                {isOpen ? "إلغاء" : "تعديل"}
              </button>
            </div>

            {isOpen && (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const fd = new FormData(e.currentTarget);
                  startTransition(() => {
                    updateDoctorConsultantAction(fd);
                  });
                  setOpenId(null);
                }}
                className="space-y-2 border-t border-border pt-2"
              >
                <input type="hidden" name="doctor_id" value={d.id} />
                <label className="flex items-center gap-2 text-sm">
                  <input type="checkbox" name="is_consultant" defaultChecked={d.is_consultant === 1} className="h-4 w-4" />
                  استشاري (عنده دكاترة مساعدين)
                </label>
                <div>
                  <label className="block text-xs text-muted mb-1">
                    الدكاترة المساعدين (Ctrl/Cmd + دوسة لاختيار أكتر من واحد)
                  </label>
                  <select
                    name="assistant_doctor_ids"
                    multiple
                    defaultValue={currentAssistants.map(String)}
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm min-h-[6rem]"
                  >
                    {otherDoctors.map((o) => (
                      <option key={o.id} value={o.id}>
                        {o.full_name}
                      </option>
                    ))}
                  </select>
                </div>
                <button
                  type="submit"
                  disabled={isPending}
                  className="rounded-md btn-3d-primary px-3 py-1.5 text-xs font-medium disabled:opacity-60"
                >
                  {isPending ? "جاري الحفظ..." : "حفظ"}
                </button>
              </form>
            )}
          </div>
        );
      })}
      {doctors.length === 0 && <p className="text-sm text-muted">مفيش دكاترة مسجلين.</p>}
    </div>
  );
}
