"use client";

import { addOrthoOptionAction, deleteOrthoOptionAction } from "@/app/settings/actions";

export type OrthoOption = { id: number; category: string; value: string };

const CATEGORY_LABELS: Record<string, string> = {
  wire_size: "مقاسات الوير",
  wire_type: "أنواع الوير",
  otie_color: "ألوان الـO-tie",
  elastic_size: "مقاسات الإيلاستكس",
  anchorage_device: "أنواع الـAnchorage",
};

function CategoryList({ category, options }: { category: string; options: OrthoOption[] }) {
  return (
    <div className="space-y-2">
      <h4 className="text-sm font-medium">{CATEGORY_LABELS[category] || category}</h4>
      <div className="flex flex-wrap gap-2">
        {options.map((o) => (
          <div
            key={o.id}
            className="flex items-center gap-1.5 border border-border rounded-md px-2.5 py-1 text-xs bg-background"
          >
            <span>{o.value}</span>
            <form action={deleteOrthoOptionAction}>
              <input type="hidden" name="id" value={o.id} />
              <button type="submit" className="text-red-600 hover:underline" title="حذف">
                ×
              </button>
            </form>
          </div>
        ))}
        {options.length === 0 && <p className="text-xs text-muted">مفيش قيم مضافة لسه.</p>}
      </div>
      <form action={addOrthoOptionAction} className="flex items-center gap-2">
        <input type="hidden" name="category" value={category} />
        <input
          name="value"
          required
          placeholder="قيمة جديدة"
          className="rounded-md border border-border bg-background px-2.5 py-1.5 text-xs w-40"
        />
        <button type="submit" className="text-xs px-3 py-1.5 rounded-md border border-dashed border-border hover:bg-primary-soft text-muted">
          + إضافة
        </button>
      </form>
    </div>
  );
}

// شارت التقويم v2 (دمج 2026-08-27) — المستخدم طلب إنه يضيف/يعدّل قوايم
// المقاسات/الألوان دي بنفسه من هنا بدل placeholders ثابتة في الكود. كل فئة
// (wire_size/wire_type/otie_color/elastic_size) عندها قايمتها المستقلة —
// القيم دي هي اللي بتتعرض في دروب داون الوير/O-tie/الإيلاستكس في شارت
// التقويم لأي مريض.
export default function OrthoOptionListsManager({ options }: { options: OrthoOption[] }) {
  const byCategory: Record<string, OrthoOption[]> = {};
  for (const o of options) {
    if (!byCategory[o.category]) byCategory[o.category] = [];
    byCategory[o.category].push(o);
  }

  return (
    <div className="space-y-5">
      {Object.keys(CATEGORY_LABELS).map((category) => (
        <CategoryList key={category} category={category} options={byCategory[category] || []} />
      ))}
    </div>
  );
}
