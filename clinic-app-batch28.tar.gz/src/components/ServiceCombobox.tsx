"use client";

import { useEffect, useMemo, useRef, useState } from "react";

type Service = { id: number; name: string; name_en?: string | null; code?: string | null; default_price?: number | null };

// اختيار خدمة بيشتغل كـ Dropdown عادي (يعرض كل الخدمات لو اتفتح من غير كتابة) وفي نفس
// الوقت قابل للكتابة فيه — بيدور بالاسم (أي جزء منه) أو بالكود (أي جزء منه) مع كل حرف.
// بديل عن <select> العادي اللي كان بياخد وقت أطول للبحث بالسكرول في قايمة طويلة.
//
// useEnglish (دفعة 22): جوه الملف الطبي بس، أسماء الخدمات المفروض تتعرض/تتبحث
// بالإنجليزي (name_en) بدل العربي — باقي أماكن استخدام المكون ده (الفواتير،
// الجدول المركزي، الملف المالي) بتفضل عربي زي ما هي (useEnglish مش متبعت = false).
// لو خدمة معينة لسه من غير name_en (بيانات قديمة لسه ماتترجمتش)، بيرجع للعربي
// كـ fallback عشان الاسم مايبانش فاضي.
export default function ServiceCombobox({
  name,
  services,
  value,
  onChange,
  placeholder = "اكتب اسم الخدمة أو كودها، أو دوس هنا لعرض القايمة كاملة...",
  useEnglish = false,
}: {
  name: string;
  services: Service[];
  value: string; // service id كـ string، "" يعني مفيش اختيار
  onChange: (id: string) => void;
  placeholder?: string;
  useEnglish?: boolean;
}) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);

  const displayName = (s: Service) => (useEnglish ? s.name_en || s.name : s.name);

  const sortedServices = useMemo(
    () => [...services].sort((a, b) => displayName(a).localeCompare(displayName(b), useEnglish ? "en" : "ar")),
    [services, useEnglish]
  );

  const selected = useMemo(() => services.find((s) => String(s.id) === value) ?? null, [services, value]);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return sortedServices;
    return sortedServices.filter((s) => displayName(s).toLowerCase().includes(q) || (s.code ?? "").includes(q));
  }, [query, sortedServices, useEnglish]);

  return (
    <div className="relative" ref={wrapRef}>
      <input type="hidden" name={name} value={value} />
      <input
        type="text"
        value={open ? query : selected ? `${displayName(selected)}${selected.code ? ` (${selected.code})` : ""}` : query}
        onChange={(e) => {
          setQuery(e.target.value);
          setOpen(true);
        }}
        onFocus={() => {
          setOpen(true);
          setQuery("");
        }}
        onKeyDown={(e) => {
          if (e.key === "Escape") {
            setOpen(false);
            (e.target as HTMLInputElement).blur();
          } else if (e.key === "Enter") {
            e.preventDefault();
            if (filtered.length > 0) {
              onChange(String(filtered[0].id));
              setQuery("");
              setOpen(false);
            }
          }
        }}
        placeholder={placeholder}
        className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
      />
      {open && (
        <div className="absolute z-10 mt-1 w-full card-3d rounded-md shadow-lg overflow-hidden max-h-56 overflow-y-auto">
          <button
            type="button"
            onClick={() => {
              onChange("");
              setQuery("");
              setOpen(false);
            }}
            className="w-full text-right px-3 py-1.5 text-sm text-muted hover:bg-primary-soft"
          >
            بدون اختيار
          </button>
          {filtered.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => {
                onChange(String(s.id));
                setQuery("");
                setOpen(false);
              }}
              className="w-full text-right px-3 py-1.5 text-sm hover:bg-primary-soft flex items-center justify-between gap-2"
            >
              <span>{displayName(s)}</span>
              <span className="text-xs text-muted shrink-0">
                {s.code ? `#${s.code}` : ""} {s.default_price != null && s.code !== "0" ? ` — ${s.default_price} ج.م` : ""}
              </span>
            </button>
          ))}
          {filtered.length === 0 && <div className="px-3 py-2 text-sm text-muted">مفيش خدمة مطابقة</div>}
        </div>
      )}
    </div>
  );
}
