"use client";

import { useState } from "react";
import { PERMISSION_DEFS, ROLE_DEFAULT_PERMISSIONS, type PermissionKey } from "@/lib/permission-defs";
import { ROLE_LABELS, type Role } from "@/lib/auth";
import { updatePermissionsAction, saveDoctorReportMaxDaysAction } from "@/app/settings/actions";

type UserRow = {
  id: number;
  username: string;
  full_name: string;
  role: Role;
};

export default function PermissionsManager({
  users,
  overridesByUser,
  doctorReportMaxDays,
}: {
  users: UserRow[];
  overridesByUser: Record<number, Record<string, boolean>>;
  doctorReportMaxDays: string;
}) {
  // الأدمن دايمًا عنده كل الصلاحيات ومش قابلة للتعديل، فمش بنعرضه في القائمة.
  const editableUsers = users.filter((u) => u.role !== "admin");
  const [selectedId, setSelectedId] = useState<number | "">("");
  const selected = editableUsers.find((u) => u.id === selectedId);
  const overrides = selected ? overridesByUser[selected.id] || {} : {};
  const defaults = selected ? ROLE_DEFAULT_PERMISSIONS[selected.role] || [] : [];

  return (
    <div className="space-y-5">
      <form action={saveDoctorReportMaxDaysAction} className="flex items-end gap-2 flex-wrap">
        <div>
          <label className="block text-xs text-muted mb-1">
            أقصى عدد أيام رجوع بالتاريخ لتقرير الدكتور الشخصي (لمن معهوش صلاحية &quot;كل التقارير&quot;)
          </label>
          <input
            type="number"
            name="doctor_report_max_days"
            min={1}
            defaultValue={doctorReportMaxDays}
            className="w-32 rounded-md border border-border bg-background px-2 py-1.5 text-sm"
          />
        </div>
        <button type="submit" className="rounded-md border border-border px-3 py-1.5 text-sm hover:bg-primary-soft">
          حفظ
        </button>
      </form>

      <div>
        <label className="block text-sm text-muted mb-1">اختر مستخدم لعرض/تعديل صلاحياته</label>
        <select
          value={selectedId}
          onChange={(e) => setSelectedId(e.target.value ? Number(e.target.value) : "")}
          className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
        >
          <option value="">-- اختر مستخدم --</option>
          {editableUsers.map((u) => (
            <option key={u.id} value={u.id}>
              {u.full_name} ({ROLE_LABELS[u.role]})
            </option>
          ))}
        </select>
        {editableUsers.length === 0 && <p className="text-sm text-muted mt-2">مفيش مستخدمين تانيين لسه.</p>}
      </div>

      {selected && (
        <form key={selected.id} action={updatePermissionsAction} className="border border-border rounded-lg p-4 space-y-3">
          <input type="hidden" name="user_id" value={selected.id} />
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-medium text-sm">{selected.full_name}</span>
            <span className="text-xs text-muted">({ROLE_LABELS[selected.role]})</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            {PERMISSION_DEFS.map((def) => {
              const effective = def.key in overrides ? overrides[def.key] : defaults.includes(def.key as PermissionKey);
              return (
                <label key={def.key} className="flex items-center gap-1.5 text-xs">
                  <input type="checkbox" name={`perm_${def.key}`} defaultChecked={effective} className="h-4 w-4" />
                  {def.label}
                </label>
              );
            })}
          </div>
          <button type="submit" className="rounded-md border border-border px-3 py-1.5 text-xs hover:bg-primary-soft">
            حفظ صلاحيات {selected.full_name}
          </button>
        </form>
      )}
    </div>
  );
}
