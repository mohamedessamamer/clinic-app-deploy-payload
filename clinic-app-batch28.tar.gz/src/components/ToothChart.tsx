"use client";

import { useState } from "react";
import { permanentTeeth, primaryTeeth, bondingZoneOf, archOfTooth, type ToothId } from "@/lib/dental-chart";
import type { InventoryItemOption } from "@/components/OrthodonticChartForm";

// الشارت الموحّد للأسنان الدائمة — كل حاجة بتحصل للسن (ناقص/خلع/تركيب لسه/
// براكت مكسورة/ريبوندينج/ملاحظة) بتتعمل من مكان واحد: دوس على السن فتفتحله
// لوحة تفاصيله تحت الشارت، بالظبط زي ما المستخدم طلب — "واكني باصص في فم المريض".

function InventorySelect({
  items,
  value,
  onChange,
  placeholder,
}: {
  items: InventoryItemOption[];
  value: number | null;
  onChange: (v: number | null) => void;
  placeholder: string;
}) {
  return (
    <select
      value={value ?? ""}
      onChange={(e) => onChange(e.target.value ? Number(e.target.value) : null)}
      className="rounded-md border border-border bg-background px-2 py-1.5 text-sm max-w-[220px]"
    >
      <option value="">{placeholder}</option>
      {items.map((it) => (
        <option key={it.id} value={it.id}>
          {it.name} (متاح {it.quantity} {it.unit ?? ""})
        </option>
      ))}
    </select>
  );
}

export interface ToothChartProps {
  editable: boolean;
  missingTeeth: string[];
  onToggleMissing: (id: ToothId) => void;
  extractionActive: boolean;
  extractionTeeth: string[];
  onToggleExtraction: (id: ToothId) => void;
  bondingUpperDate: string | null;
  bondingLowerDate: string | null;
  notBondedUpper: string[];
  notBondedLower: string[];
  onToggleNotBonded: (arch: "upper" | "lower", id: ToothId) => void;
  brokenTeeth: string[];
  onToggleBroken: (id: ToothId) => void;
  busyBroken: boolean;
  rebondingCounts: Record<string, number>;
  onConfirmRebonding: (id: ToothId, bracketItemId: number | null) => void;
  busyRebonding: boolean;
  inventoryItems: InventoryItemOption[];
  toothComments: Record<string, string>;
  onChangeComment: (id: ToothId, value: string) => void;
}

export default function ToothChart({
  editable,
  missingTeeth,
  onToggleMissing,
  extractionActive,
  extractionTeeth,
  onToggleExtraction,
  bondingUpperDate,
  bondingLowerDate,
  notBondedUpper,
  notBondedLower,
  onToggleNotBonded,
  brokenTeeth,
  onToggleBroken,
  busyBroken,
  rebondingCounts,
  onConfirmRebonding,
  busyRebonding,
  inventoryItems,
  toothComments,
  onChangeComment,
}: ToothChartProps) {
  // افتراضيًا الشارت بيعرض الأسنان الدائمة، مع إمكانية التبديل للأسنان اللبنية
  // عند الحاجة (بقرار صريح من المستخدم) — مش الاتنين مع بعض في نفس الوقت.
  const [mode, setMode] = useState<"permanent" | "primary">("permanent");
  const [selected, setSelected] = useState<ToothId | null>(null);
  const [rebondBracket, setRebondBracket] = useState<number | null>(null);
  const [commentDraft, setCommentDraft] = useState<string>("");

  function switchMode(next: "permanent" | "primary") {
    if (next === mode) return;
    setMode(next);
    setSelected(null);
  }

  function selectTooth(id: ToothId) {
    setSelected(id);
    setRebondBracket(null);
    setCommentDraft(toothComments[id] ?? "");
  }

  function renderRow(archPrefix: "U" | "L") {
    const teeth = mode === "permanent" ? permanentTeeth(archPrefix) : primaryTeeth(archPrefix);
    return (
      <div className="flex justify-center gap-0.5" dir="ltr">
        {teeth.map((t, idx) => {
          const isMidline = idx === teeth.length / 2; // بعد نص عدد الأسنان (يمين المريض) يجي خط المنتصف
          const isMissing = missingTeeth.includes(t.id);
          const isExtraction = extractionActive && extractionTeeth.includes(t.id);
          const isBroken = brokenTeeth.includes(t.id);
          const zone = bondingZoneOf(t.id);
          const arch = archOfTooth(t.id);
          const archNotBonded = arch === "U" ? notBondedUpper : notBondedLower;
          const isNotBondedNow = zone != null && archNotBonded.includes(t.id);
          const count = rebondingCounts[t.id] ?? 0;
          const hasComment = !!toothComments[t.id];
          const isSelected = selected === t.id;

          let bg = "bg-background";
          if (isMissing) bg = "bg-muted/40 opacity-50";
          if (isNotBondedNow) bg = "bg-amber-100 dark:bg-amber-900/30";
          if (isExtraction) bg = "bg-danger-soft";
          if (isBroken) bg = "bg-danger text-white";

          return (
            <div key={t.id} className="flex items-center">
              {isMidline && <div className="w-px h-8 bg-border mx-1" />}
              <button
                type="button"
                title={t.id}
                onClick={() => selectTooth(t.id)}
                className={`relative w-9 h-9 rounded-md border text-sm flex items-center justify-center transition-colors ${bg} ${
                  isSelected ? "border-primary ring-2 ring-primary" : "border-border"
                } ${isMissing ? "line-through" : ""}`}
              >
                {t.label}
                {count > 0 && (
                  <span className="absolute -top-1.5 -left-1.5 w-4 h-4 rounded-full bg-primary text-white text-[10px] flex items-center justify-center">
                    {count}
                  </span>
                )}
                {hasComment && <span className="absolute -bottom-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-primary" />}
              </button>
            </div>
          );
        })}
      </div>
    );
  }

  const detail = selected ? { id: selected, zone: bondingZoneOf(selected), arch: archOfTooth(selected) } : null;
  const detailArchBonded = detail && (detail.arch === "U" ? bondingUpperDate : bondingLowerDate);
  const detailArchNotBonded = detail ? (detail.arch === "U" ? notBondedUpper : notBondedLower).includes(detail.id) : false;
  const detailBroken = detail ? brokenTeeth.includes(detail.id) : false;
  const detailCount = detail ? rebondingCounts[detail.id] ?? 0 : 0;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-center gap-2">
        <div className="inline-flex rounded-md border border-border overflow-hidden text-sm">
          <button
            type="button"
            onClick={() => switchMode("permanent")}
            className={`px-3 py-1.5 transition-colors ${mode === "permanent" ? "bg-primary text-white" : "bg-background hover:bg-primary-soft"}`}
          >
            الأسنان الدائمة
          </button>
          <button
            type="button"
            onClick={() => switchMode("primary")}
            className={`px-3 py-1.5 transition-colors border-r border-border ${mode === "primary" ? "bg-primary text-white" : "bg-background hover:bg-primary-soft"}`}
          >
            الأسنان اللبنية
          </button>
        </div>
      </div>
      <div className="text-xs text-muted text-center">دوس على أي سن (فك علوي فوق، فك سفلي تحت) عشان تشوف/تسجّل كل حاجة خاصة بيه</div>
      <div className="space-y-2 rounded-md border border-border p-3 bg-background/50">
        {renderRow("U")}
        <div className="border-t border-dashed border-border" />
        {renderRow("L")}
      </div>

      {detail && (
        <div className="space-y-3 rounded-md border border-primary p-4 bg-primary-soft/30">
          <div className="flex items-center justify-between">
            <div className="text-sm font-semibold">تفاصيل السن {detail.id}</div>
            <button type="button" onClick={() => setSelected(null)} className="text-xs text-muted hover:underline">
              إغلاق
            </button>
          </div>

          <div className="flex flex-wrap gap-4 text-sm">
            <label className="flex items-center gap-1.5">
              <input
                type="checkbox"
                disabled={!editable}
                checked={missingTeeth.includes(detail.id)}
                onChange={() => onToggleMissing(detail.id)}
              />
              ناقص (Missing)
            </label>

            {mode === "permanent" && extractionActive && (
              <label className="flex items-center gap-1.5">
                <input
                  type="checkbox"
                  disabled={!editable}
                  checked={extractionTeeth.includes(detail.id)}
                  onChange={() => onToggleExtraction(detail.id)}
                />
                مطلوب خلعه (Extraction)
              </label>
            )}

            {detail.zone && !detailArchBonded && (
              <label className="flex items-center gap-1.5">
                <input
                  type="checkbox"
                  disabled={!editable}
                  checked={detailArchNotBonded}
                  onChange={() => onToggleNotBonded(detail.arch === "U" ? "upper" : "lower", detail.id)}
                />
                مش هيترّكب في جلسة التركيب دي
              </label>
            )}
          </div>

          {detail.zone && detailArchBonded && (
            <div className="space-y-2 border-t border-border pt-3">
              <label className="flex items-center gap-1.5 text-sm">
                <input
                  type="checkbox"
                  disabled={!editable || busyBroken}
                  checked={detailBroken}
                  onChange={() => onToggleBroken(detail.id)}
                />
                براكته مكسورة دلوقتي (لسه مترّكبتش تاني)
              </label>

              <div className="flex items-center gap-3 flex-wrap text-sm">
                <span className="text-xs text-muted">عدد مرات الريبوندينج: {detailCount}</span>
                {editable && (
                  <>
                    <InventorySelect items={inventoryItems} value={rebondBracket} onChange={setRebondBracket} placeholder="اختر نوع البراكت" />
                    <button
                      type="button"
                      disabled={busyRebonding}
                      onClick={() => onConfirmRebonding(detail.id, rebondBracket)}
                      className="btn-3d-primary px-3 py-1 rounded-md text-xs disabled:opacity-60"
                    >
                      {busyRebonding ? "جاري التسجيل..." : "سجّل ريبوندينج جديد"}
                    </button>
                  </>
                )}
              </div>
            </div>
          )}

          <div className="space-y-1 border-t border-border pt-3">
            <div className="text-xs text-muted">ملاحظة على السن ده</div>
            {editable ? (
              <textarea
                value={commentDraft}
                onChange={(e) => {
                  setCommentDraft(e.target.value);
                  onChangeComment(detail.id, e.target.value);
                }}
                rows={2}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              />
            ) : (
              <p className="text-sm whitespace-pre-wrap">{toothComments[detail.id] || <span className="text-muted">—</span>}</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
