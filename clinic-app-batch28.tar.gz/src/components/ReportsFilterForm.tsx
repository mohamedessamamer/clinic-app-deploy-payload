"use client";

import { useRef } from "react";

type Doctor = { id: number; full_name: string };
type Service = { id: number; name: string; code?: string | null };

// فورم فلاتر تقرير الإيرادات — بيبعت نفسه (GET لنفس الصفحة) تلقائيًا بمجرد أي
// تغيير، زي DateFilterForm بالظبط. اختيار "شهر كامل" مش حقل بيتبعت لوحده — بس
// أداة مساعدة بتملى حقلي "من"/"إلى" بأول وآخر يوم في الشهر المختار وتبعت الفورم.
export default function ReportsFilterForm({
  from,
  to,
  minFrom = null,
  doctorId,
  serviceId,
  doctors,
  services,
  showDoctorFilter,
}: {
  from: string;
  to: string;
  // reports_own بس: أقدم تاريخ "من" مسموح بيه (شهرين قبل "إلى") — ملحوظة بصرية
  // (min على حقل التاريخ) بس، التحقق الحقيقي والتقصير بيحصل في السيرفر دايمًا.
  minFrom?: string | null;
  doctorId: number | null;
  serviceId: number | null;
  doctors: Doctor[];
  services: Service[];
  // reports_own بس (بدون reports_full، عادة دكتور): مقفول على نفسه، من غير قايمة اختيار دكتور خالص.
  showDoctorFilter: boolean;
}) {
  const formRef = useRef<HTMLFormElement>(null);
  const fromRef = useRef<HTMLInputElement>(null);
  const toRef = useRef<HTMLInputElement>(null);

  function setRange(fromStr: string, toStr: string) {
    if (fromRef.current) fromRef.current.value = fromStr;
    if (toRef.current) toRef.current.value = toStr;
    formRef.current?.requestSubmit();
  }

  function applyMonth(monthValue: string) {
    if (!monthValue) return;
    const [y, m] = monthValue.split("-").map(Number);
    const first = new Date(Date.UTC(y, m - 1, 1)).toISOString().slice(0, 10);
    const last = new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10);
    setRange(first, last);
  }

  function applyCurrentMonth() {
    const now = new Date();
    applyMonth(`${now.getUTCFullYear()}-${String(now.getUTCMonth() + 1).padStart(2, "0")}`);
  }

  function applyPrevMonth() {
    const now = new Date();
    const prev = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 1, 1));
    applyMonth(`${prev.getUTCFullYear()}-${String(prev.getUTCMonth() + 1).padStart(2, "0")}`);
  }

  return (
    <form ref={formRef} className="card-3d rounded-xl p-4 flex items-end gap-3 flex-wrap">
      <div>
        <label className="block text-xs text-muted mb-1">من</label>
        <input
          ref={fromRef}
          type="date"
          name="from"
          defaultValue={from}
          min={minFrom ?? undefined}
          onChange={() => formRef.current?.requestSubmit()}
          className="rounded-md border border-border bg-background px-2 py-1.5 text-sm"
        />
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">إلى</label>
        <input
          ref={toRef}
          type="date"
          name="to"
          defaultValue={to}
          onChange={() => formRef.current?.requestSubmit()}
          className="rounded-md border border-border bg-background px-2 py-1.5 text-sm"
        />
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">اختيار شهر كامل</label>
        <input
          type="month"
          onChange={(e) => applyMonth(e.target.value)}
          className="rounded-md border border-border bg-background px-2 py-1.5 text-sm"
        />
      </div>
      <div className="flex gap-1">
        <button type="button" onClick={applyCurrentMonth} className="px-2 py-1.5 rounded-md border border-border text-xs hover:bg-primary-soft">
          الشهر ده
        </button>
        <button type="button" onClick={applyPrevMonth} className="px-2 py-1.5 rounded-md border border-border text-xs hover:bg-primary-soft">
          الشهر اللي فات
        </button>
      </div>

      {showDoctorFilter && (
        <div>
          <label className="block text-xs text-muted mb-1">الدكتور</label>
          <select
            name="doctor_id"
            defaultValue={doctorId ?? ""}
            onChange={() => formRef.current?.requestSubmit()}
            className="rounded-md border border-border bg-background px-2 py-1.5 text-sm"
          >
            <option value="">كل الأطباء</option>
            {doctors.map((d) => (
              <option key={d.id} value={d.id}>
                {d.full_name}
              </option>
            ))}
          </select>
        </div>
      )}

      <div>
        <label className="block text-xs text-muted mb-1">الخدمة</label>
        <select
          name="service_id"
          defaultValue={serviceId ?? ""}
          onChange={() => formRef.current?.requestSubmit()}
          className="rounded-md border border-border bg-background px-2 py-1.5 text-sm"
        >
          <option value="">كل الخدمات</option>
          {services.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
      </div>

      <button type="submit" className="px-3 py-1.5 rounded-md btn-3d-primary text-sm">
        تطبيق
      </button>
    </form>
  );
}
