import { WEEKDAY_LABELS, WEEKDAY_DISPLAY_ORDER } from "@/lib/settings";
import { addWeeklyShiftAction, deleteWeeklyShiftAction } from "@/app/settings/actions";

type Room = { id: number; name: string };
type Doctor = { id: number; full_name: string };
type WeeklyShift = {
  id: number;
  weekday: number;
  start_time: string;
  end_time: string;
  room_name: string | null;
  doctor_name: string | null;
};

export default function WeeklyShiftsManager({
  rooms,
  doctors,
  timeSlots,
  weeklyShifts,
}: {
  rooms: Room[];
  doctors: Doctor[];
  timeSlots: string[];
  weeklyShifts: WeeklyShift[];
}) {
  const byWeekday: Record<number, WeeklyShift[]> = {};
  for (const s of weeklyShifts) {
    (byWeekday[s.weekday] ||= []).push(s);
  }

  return (
    <div className="space-y-4">
      <form action={addWeeklyShiftAction} className="grid grid-cols-1 sm:grid-cols-5 gap-2 items-end">
        <div>
          <label className="block text-xs text-muted mb-1">اليوم</label>
          <select name="weekday" required className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm">
            {WEEKDAY_DISPLAY_ORDER.map((idx) => (
              <option key={idx} value={idx}>
                {WEEKDAY_LABELS[idx]}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs text-muted mb-1">الغرفة</label>
          <select name="room_id" required className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm">
            {rooms.map((r) => (
              <option key={r.id} value={r.id}>
                {r.name}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs text-muted mb-1">الدكتور</label>
          <select name="doctor_id" required className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm">
            {doctors.map((d) => (
              <option key={d.id} value={d.id}>
                {d.full_name}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs text-muted mb-1">من</label>
          <select name="start_time" required className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm">
            {timeSlots.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs text-muted mb-1">إلى</label>
          <select name="end_time" required className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm">
            {timeSlots.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>
        <div className="sm:col-span-5">
          <button type="submit" className="rounded-md btn-3d-primary px-3 py-1.5 text-sm font-medium">
            + إضافة شيفت أسبوعي
          </button>
        </div>
      </form>

      <div className="space-y-3">
        {WEEKDAY_DISPLAY_ORDER.map((idx) => (
          <div key={idx}>
            <h3 className="text-xs font-semibold text-muted mb-1">{WEEKDAY_LABELS[idx]}</h3>
            <div className="flex flex-wrap gap-2">
              {(byWeekday[idx] || []).map((s) => (
                <span
                  key={s.id}
                  className="flex items-center gap-1.5 text-xs bg-primary-soft text-primary-dark rounded-full ps-3 pe-1 py-1.5"
                >
                  {s.room_name} · {s.doctor_name} · {s.start_time}–{s.end_time}
                  <form action={deleteWeeklyShiftAction}>
                    <input type="hidden" name="id" value={s.id} />
                    <button type="submit" className="text-primary-dark/70 hover:text-red-600 leading-none px-1" title="حذف">
                      ×
                    </button>
                  </form>
                </span>
              ))}
              {!(byWeekday[idx] || []).length && <p className="text-xs text-muted">لا يوجد شيفت.</p>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
