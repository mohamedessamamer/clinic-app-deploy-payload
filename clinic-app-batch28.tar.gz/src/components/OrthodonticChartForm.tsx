"use client";

import { useState, useEffect, useTransition } from "react";
import { useRouter } from "next/navigation";
import ToothChart from "@/components/ToothChart";
import { bondingTeeth, type ToothId } from "@/lib/dental-chart";
import {
  saveOrthodonticChartAction,
  confirmBondingAction,
  toggleBrokenToothAction,
  confirmRebondingAction,
} from "@/app/patients/[id]/orthodontics/actions";

export interface InventoryItemOption {
  id: number;
  name: string;
  unit: string | null;
  quantity: number;
}

type ChoiceValue = string | null;

interface ChartState {
  sex: ChoiceValue;
  prescription: ChoiceValue;
  chief_complaint: string;
  past_medical_history: string;
  missing_teeth: string[];
  antero_posterior: ChoiceValue;
  facial_height: ChoiceValue;
  mx_incisor_inclination: ChoiceValue;
  mn_incisor_inclination: ChoiceValue;
  molar_relation_right: ChoiceValue;
  molar_relation_left: ChoiceValue;
  overbite: ChoiceValue;
  overjet: ChoiceValue;
  midline_upper_direction: ChoiceValue;
  midline_upper_mm: string;
  midline_lower_direction: ChoiceValue;
  midline_lower_mm: string;
  space_upper_type: ChoiceValue;
  space_upper_mm: string;
  space_lower_type: ChoiceValue;
  space_lower_mm: string;
  sna_case: string;
  snb_case: string;
  anb_case: string;
  mma_case: string;
  u1_pp_case: string;
  l1_mp_case: string;
  nasolabial_case: string;
  nasolabial_angle: ChoiceValue;
  lips: ChoiceValue;
  extraction_choice: ChoiceValue;
  extraction_teeth: string[];
  anchorage: ChoiceValue;
  anchorage_note: string;
  hints: string;
  tooth_comments: Record<string, string>;
}

export interface OrthodonticChartData {
  sex: string | null;
  chief_complaint: string | null;
  past_medical_history: string | null;
  missing_teeth: string | null;
  antero_posterior: string | null;
  facial_height: string | null;
  mx_incisor_inclination: string | null;
  mn_incisor_inclination: string | null;
  molar_relation_right: string | null;
  molar_relation_left: string | null;
  overbite: string | null;
  overjet: string | null;
  midline_upper_direction: string | null;
  midline_upper_mm: number | null;
  midline_lower_direction: string | null;
  midline_lower_mm: number | null;
  space_upper_type: string | null;
  space_upper_mm: number | null;
  space_lower_type: string | null;
  space_lower_mm: number | null;
  sna_case: number | null;
  snb_case: number | null;
  anb_case: number | null;
  mma_case: number | null;
  u1_pp_case: number | null;
  l1_mp_case: number | null;
  nasolabial_case: number | null;
  nasolabial_angle: string | null;
  lips: string | null;
  extraction_choice: string | null;
  extraction_teeth: string | null;
  anchorage: string | null;
  anchorage_note: string | null;
  hints: string | null;
  prescription: string | null;
  bonding_upper_bracket_item_id: number | null;
  bonding_upper_bracket_qty: number | null;
  bonding_upper_tube_item_id: number | null;
  bonding_upper_tube_qty: number | null;
  bonding_upper_date: string | null;
  bonding_upper_not_bonded_teeth: string | null;
  bonding_lower_bracket_item_id: number | null;
  bonding_lower_bracket_qty: number | null;
  bonding_lower_tube_item_id: number | null;
  bonding_lower_tube_qty: number | null;
  bonding_lower_date: string | null;
  bonding_lower_not_bonded_teeth: string | null;
  broken_teeth: string | null;
  rebonding_counts: string | null;
  tooth_comments: string | null;
}

function toStateNum(n: number | null): string {
  return n == null ? "" : String(n);
}

function fromExisting(data: OrthodonticChartData | null): ChartState {
  return {
    sex: data?.sex ?? null,
    prescription: data?.prescription ?? null,
    chief_complaint: data?.chief_complaint ?? "",
    past_medical_history: data?.past_medical_history ?? "",
    missing_teeth: data?.missing_teeth ? safeParseArray(data.missing_teeth) : [],
    antero_posterior: data?.antero_posterior ?? null,
    facial_height: data?.facial_height ?? null,
    mx_incisor_inclination: data?.mx_incisor_inclination ?? null,
    mn_incisor_inclination: data?.mn_incisor_inclination ?? null,
    molar_relation_right: data?.molar_relation_right ?? null,
    molar_relation_left: data?.molar_relation_left ?? null,
    overbite: data?.overbite ?? null,
    overjet: data?.overjet ?? null,
    midline_upper_direction: data?.midline_upper_direction ?? null,
    midline_upper_mm: toStateNum(data?.midline_upper_mm ?? null),
    midline_lower_direction: data?.midline_lower_direction ?? null,
    midline_lower_mm: toStateNum(data?.midline_lower_mm ?? null),
    space_upper_type: data?.space_upper_type ?? null,
    space_upper_mm: toStateNum(data?.space_upper_mm ?? null),
    space_lower_type: data?.space_lower_type ?? null,
    space_lower_mm: toStateNum(data?.space_lower_mm ?? null),
    sna_case: toStateNum(data?.sna_case ?? null),
    snb_case: toStateNum(data?.snb_case ?? null),
    anb_case: toStateNum(data?.anb_case ?? null),
    mma_case: toStateNum(data?.mma_case ?? null),
    u1_pp_case: toStateNum(data?.u1_pp_case ?? null),
    l1_mp_case: toStateNum(data?.l1_mp_case ?? null),
    nasolabial_case: toStateNum(data?.nasolabial_case ?? null),
    nasolabial_angle: data?.nasolabial_angle ?? null,
    lips: data?.lips ?? null,
    extraction_choice: data?.extraction_choice ?? null,
    extraction_teeth: data?.extraction_teeth ? safeParseArray(data.extraction_teeth) : [],
    anchorage: data?.anchorage ?? null,
    anchorage_note: data?.anchorage_note ?? "",
    hints: data?.hints ?? "",
    tooth_comments: safeParseStringObject(data?.tooth_comments ?? null),
  };
}

function safeParseArray(json: string): string[] {
  try {
    const parsed = JSON.parse(json);
    return Array.isArray(parsed) ? parsed.filter((x) => typeof x === "string") : [];
  } catch {
    return [];
  }
}

function safeParseStringObject(json: string | null): Record<string, string> {
  if (!json) return {};
  try {
    const parsed = JSON.parse(json);
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      const out: Record<string, string> = {};
      for (const [k, v] of Object.entries(parsed)) {
        if (typeof v === "string") out[k] = v;
      }
      return out;
    }
  } catch {
    /* ignore */
  }
  return {};
}

const CEPHALOMETRIC_ROWS: { key: keyof Pick<ChartState, "sna_case" | "snb_case" | "anb_case" | "mma_case" | "u1_pp_case" | "l1_mp_case" | "nasolabial_case">; label: string; norm: string }[] = [
  { key: "sna_case", label: "SNA", norm: "83° ± 2" },
  { key: "snb_case", label: "SNB", norm: "80° ± 2" },
  { key: "anb_case", label: "ANB", norm: "3° ± 2" },
  { key: "mma_case", label: "MMA", norm: "25° ± 3" },
  { key: "u1_pp_case", label: "U1 / pp", norm: "112° ± 5" },
  { key: "l1_mp_case", label: "L1 / MP", norm: "98° ± 6" },
  { key: "nasolabial_case", label: "Nasolabial", norm: "102° ± 8" },
];

// مجموعة اختيار واحد من عدة خيارات (زي مربعات الاختيار في الورقة) — دوسة على
// الخيار المحدد بالفعل بترجعه لغير محدد، ودوسة على خيار تاني تختاره بدله.
function ChoiceGroup({
  options,
  value,
  onChange,
  editable,
}: {
  options: { value: string; label: string }[];
  value: ChoiceValue;
  onChange: (v: ChoiceValue) => void;
  editable: boolean;
}) {
  if (!editable) {
    const selected = options.find((o) => o.value === value);
    return <span className="text-sm">{selected ? selected.label : <span className="text-muted">—</span>}</span>;
  }
  return (
    <div className="flex gap-2 flex-wrap">
      {options.map((o) => {
        const isSelected = value === o.value;
        return (
          <button
            key={o.value}
            type="button"
            onClick={() => onChange(isSelected ? null : o.value)}
            className={`px-3 py-1.5 rounded-md border text-sm transition-colors ${
              isSelected ? "bg-primary text-white border-primary" : "bg-background border-border hover:bg-primary-soft"
            }`}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <div className="text-xs text-muted">{label}</div>
      {children}
    </div>
  );
}

const PRESCRIPTION_OPTIONS = [
  { value: "Roth", label: "Roth" },
  { value: "MBT", label: "MBT" },
  { value: "Andrews", label: "Andrews" },
];

function InventorySelect({
  items,
  value,
  onChange,
  disabled,
  placeholder,
}: {
  items: InventoryItemOption[];
  value: number | null;
  onChange: (v: number | null) => void;
  disabled?: boolean;
  placeholder: string;
}) {
  return (
    <select
      disabled={disabled}
      value={value ?? ""}
      onChange={(e) => onChange(e.target.value ? Number(e.target.value) : null)}
      className="rounded-md border border-border bg-background px-2 py-1.5 text-sm max-w-[220px]"
    >
      <option value="">{placeholder}</option>
      {items.map((it) => (
        <option key={it.id} value={it.id}>
          {it.name} (متاح {it.quantity} {it.unit ?? ""})
        </option>
      ))}
    </select>
  );
}

// قسم تركيب فك واحد (علوي/سفلي) — مرة واحدة بس (بيتحول لملخص للقراءة بس بمجرد
// ما يتسجل). "الأسنان اللي متركبتش" بقت بتتحدد من الشارت الموحّد فوق (دوسة على
// السن نفسه)، القسم ده بيعرضها بس وبيحسب عدد البراكت/التيوب المقترح تلقائي.
function BondingArchSection({
  patientId,
  arch,
  title,
  bracketItemId,
  bracketQty,
  tubeItemId,
  tubeQty,
  date,
  notBondedTeeth,
  inventoryItems,
  editable,
}: {
  patientId: number;
  arch: "upper" | "lower";
  title: string;
  bracketItemId: number | null;
  bracketQty: number | null;
  tubeItemId: number | null;
  tubeQty: number | null;
  date: string | null;
  notBondedTeeth: string[];
  inventoryItems: InventoryItemOption[];
  editable: boolean;
}) {
  const teeth = bondingTeeth(arch === "upper" ? "U" : "L");
  const [bracket, setBracket] = useState<number | null>(bracketItemId);
  const [bracketQtyState, setBracketQtyState] = useState<string>(bracketQty != null ? String(bracketQty) : "10");
  const [tube, setTube] = useState<number | null>(tubeItemId);
  const [tubeQtyState, setTubeQtyState] = useState<string>(tubeQty != null ? String(tubeQty) : "2");
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  // كل ما "الأسنان اللي مش هتترّكب" تتغيّر من الشارت الموحّد، نعيد حساب العدد
  // المقترح تلقائي (10 براكت + 2 تيوب للفك الكامل، ناقص أي سن اتحدد).
  useEffect(() => {
    const bracketMissing = notBondedTeeth.filter((tid) => teeth.find((t) => t.id === tid)?.zone === "bracket").length;
    const tubeMissing = notBondedTeeth.filter((tid) => teeth.find((t) => t.id === tid)?.zone === "tube").length;
    setBracketQtyState(String(Math.max(0, 10 - bracketMissing)));
    setTubeQtyState(String(Math.max(0, 2 - tubeMissing)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [notBondedTeeth.join(",")]);

  function handleConfirm() {
    setError(null);
    const fd = new FormData();
    fd.set("patient_id", String(patientId));
    fd.set("arch", arch);
    fd.set("bracket_item_id", bracket != null ? String(bracket) : "");
    fd.set("bracket_qty", bracketQtyState);
    fd.set("tube_item_id", tube != null ? String(tube) : "");
    fd.set("tube_qty", tubeQtyState);
    fd.set("not_bonded_teeth", JSON.stringify(notBondedTeeth));
    startTransition(async () => {
      const res = await confirmBondingAction(fd);
      if (res && !res.ok) setError(res.reason ?? "حصلت مشكلة");
      else router.refresh();
    });
  }

  if (date) {
    return (
      <div className="space-y-2 rounded-md border border-border p-3">
        <div className="text-sm font-semibold">{title} — ✓ اتسجل بتاريخ {date.slice(0, 10)}</div>
        <div className="text-xs text-muted">
          براكت: {bracketQty ?? "—"} · تيوب: {tubeQty ?? "—"}
          {notBondedTeeth.length > 0 && <> · أسنان متركبتش: {notBondedTeeth.join(", ")}</>}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3 rounded-md border border-border p-3">
      <div className="text-sm font-semibold">{title}</div>
      {editable ? (
        <>
          <div className="text-xs text-muted">
            الأسنان اللي مش هتترّكب (اتحددت من الشارت فوق): {notBondedTeeth.length > 0 ? notBondedTeeth.join(", ") : "لا يوجد"}
          </div>
          <div className="flex items-end gap-3 flex-wrap">
            <div className="space-y-1">
              <div className="text-xs text-muted">نوع البراكت</div>
              <InventorySelect items={inventoryItems} value={bracket} onChange={setBracket} placeholder="اختر من المخزن" />
            </div>
            <div className="space-y-1">
              <div className="text-xs text-muted">عدد البراكت</div>
              <input
                type="number"
                value={bracketQtyState}
                onChange={(e) => setBracketQtyState(e.target.value)}
                className="w-20 rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              />
            </div>
            <div className="space-y-1">
              <div className="text-xs text-muted">نوع التيوب</div>
              <InventorySelect items={inventoryItems} value={tube} onChange={setTube} placeholder="اختر من المخزن" />
            </div>
            <div className="space-y-1">
              <div className="text-xs text-muted">عدد التيوب</div>
              <input
                type="number"
                value={tubeQtyState}
                onChange={(e) => setTubeQtyState(e.target.value)}
                className="w-20 rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              />
            </div>
          </div>
          {error && <p className="text-xs text-danger">{error}</p>}
          <button
            type="button"
            onClick={handleConfirm}
            disabled={isPending}
            className="btn-3d-primary px-4 py-1.5 rounded-md text-sm disabled:opacity-60"
          >
            {isPending ? "جاري التسجيل..." : `تسجيل ${title} وخصم المخزون`}
          </button>
        </>
      ) : (
        <p className="text-xs text-muted">لسه ماتسجلش.</p>
      )}
    </div>
  );
}

export default function OrthodonticChartForm({
  patientId,
  existing,
  editable,
  inventoryItems,
}: {
  patientId: number;
  existing: OrthodonticChartData | null;
  editable: boolean;
  inventoryItems: InventoryItemOption[];
}) {
  const [state, setState] = useState<ChartState>(() => fromExisting(existing));
  const [isPending, startTransition] = useTransition();
  const [saved, setSaved] = useState(false);
  const router = useRouter();

  // "الأسنان اللي مش هتترّكب" لكل فك — بتتحدد من الشارت الموحّد قبل ما يتسجل
  // التركيب، وبعدين بتتجمّد (الفك بيبقى مسجّل، البيانات بترجع من existing.*).
  const [notBondedUpper, setNotBondedUpper] = useState<string[]>(() =>
    existing?.bonding_upper_not_bonded_teeth ? safeParseArray(existing.bonding_upper_not_bonded_teeth) : []
  );
  const [notBondedLower, setNotBondedLower] = useState<string[]>(() =>
    existing?.bonding_lower_not_bonded_teeth ? safeParseArray(existing.bonding_lower_not_bonded_teeth) : []
  );

  const [brokenPending, startBrokenTransition] = useTransition();
  const [rebondingPending, startRebondingTransition] = useTransition();

  function set<K extends keyof ChartState>(key: K, value: ChartState[K]) {
    setState((s) => ({ ...s, [key]: value }));
    setSaved(false);
  }

  function toggleTooth(list: "missing_teeth" | "extraction_teeth", id: string) {
    setState((s) => ({
      ...s,
      [list]: s[list].includes(id) ? s[list].filter((t) => t !== id) : [...s[list], id],
    }));
    setSaved(false);
  }

  function setToothComment(id: ToothId, value: string) {
    setState((s) => ({ ...s, tooth_comments: { ...s.tooth_comments, [id]: value } }));
    setSaved(false);
  }

  function toggleNotBonded(arch: "upper" | "lower", id: ToothId) {
    const setter = arch === "upper" ? setNotBondedUpper : setNotBondedLower;
    setter((prev) => (prev.includes(id) ? prev.filter((t) => t !== id) : [...prev, id]));
  }

  function handleToggleBroken(id: ToothId) {
    if (!editable) return;
    const fd = new FormData();
    fd.set("patient_id", String(patientId));
    fd.set("tooth_id", id);
    startBrokenTransition(async () => {
      await toggleBrokenToothAction(fd);
      router.refresh();
    });
  }

  function handleConfirmRebonding(id: ToothId, bracketItemId: number | null) {
    if (!editable) return;
    const fd = new FormData();
    fd.set("patient_id", String(patientId));
    fd.set("tooth_id", id);
    if (bracketItemId != null) fd.set("bracket_item_id", String(bracketItemId));
    startRebondingTransition(async () => {
      await confirmRebondingAction(fd);
      router.refresh();
    });
  }

  function handleSave() {
    const fd = new FormData();
    fd.set("patient_id", String(patientId));
    fd.set("sex", state.sex ?? "");
    fd.set("prescription", state.prescription ?? "");
    fd.set("chief_complaint", state.chief_complaint);
    fd.set("past_medical_history", state.past_medical_history);
    fd.set("missing_teeth", JSON.stringify(state.missing_teeth));
    fd.set("antero_posterior", state.antero_posterior ?? "");
    fd.set("facial_height", state.facial_height ?? "");
    fd.set("mx_incisor_inclination", state.mx_incisor_inclination ?? "");
    fd.set("mn_incisor_inclination", state.mn_incisor_inclination ?? "");
    fd.set("molar_relation_right", state.molar_relation_right ?? "");
    fd.set("molar_relation_left", state.molar_relation_left ?? "");
    fd.set("overbite", state.overbite ?? "");
    fd.set("overjet", state.overjet ?? "");
    fd.set("midline_upper_direction", state.midline_upper_direction ?? "");
    fd.set("midline_upper_mm", state.midline_upper_mm);
    fd.set("midline_lower_direction", state.midline_lower_direction ?? "");
    fd.set("midline_lower_mm", state.midline_lower_mm);
    fd.set("space_upper_type", state.space_upper_type ?? "");
    fd.set("space_upper_mm", state.space_upper_mm);
    fd.set("space_lower_type", state.space_lower_type ?? "");
    fd.set("space_lower_mm", state.space_lower_mm);
    fd.set("sna_case", state.sna_case);
    fd.set("snb_case", state.snb_case);
    fd.set("anb_case", state.anb_case);
    fd.set("mma_case", state.mma_case);
    fd.set("u1_pp_case", state.u1_pp_case);
    fd.set("l1_mp_case", state.l1_mp_case);
    fd.set("nasolabial_case", state.nasolabial_case);
    fd.set("nasolabial_angle", state.nasolabial_angle ?? "");
    fd.set("lips", state.lips ?? "");
    fd.set("extraction_choice", state.extraction_choice ?? "");
    fd.set("extraction_teeth", JSON.stringify(state.extraction_teeth));
    fd.set("anchorage", state.anchorage ?? "");
    fd.set("anchorage_note", state.anchorage_note);
    fd.set("hints", state.hints);
    fd.set("tooth_comments", JSON.stringify(state.tooth_comments));

    startTransition(async () => {
      await saveOrthodonticChartAction(fd);
      setSaved(true);
      router.refresh();
    });
  }

  const brokenTeeth = existing?.broken_teeth ? safeParseArray(existing.broken_teeth) : [];
  const rebondingCountsNum: Record<string, number> = (() => {
    if (!existing?.rebonding_counts) return {};
    try {
      const parsed = JSON.parse(existing.rebonding_counts);
      return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
    } catch {
      return {};
    }
  })();

  return (
    <div className="space-y-6">
      <div className="grid sm:grid-cols-2 gap-4">
        <Field label="النوع">
          <ChoiceGroup
            editable={editable}
            value={state.sex}
            onChange={(v) => set("sex", v)}
            options={[
              { value: "male", label: "ذكر" },
              { value: "female", label: "أنثى" },
            ]}
          />
        </Field>
        <Field label="الوصفة (Prescription)">
          <ChoiceGroup editable={editable} value={state.prescription} onChange={(v) => set("prescription", v)} options={PRESCRIPTION_OPTIONS} />
        </Field>
      </div>

      <Field label="الشكوى الرئيسية">
        {editable ? (
          <textarea
            value={state.chief_complaint}
            onChange={(e) => set("chief_complaint", e.target.value)}
            rows={2}
            className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
          />
        ) : (
          <p className="text-sm whitespace-pre-wrap">{state.chief_complaint || <span className="text-muted">—</span>}</p>
        )}
      </Field>

      <Field label="التاريخ المرضي">
        {editable ? (
          <textarea
            value={state.past_medical_history}
            onChange={(e) => set("past_medical_history", e.target.value)}
            rows={2}
            className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
          />
        ) : (
          <p className="text-sm whitespace-pre-wrap">{state.past_medical_history || <span className="text-muted">—</span>}</p>
        )}
      </Field>

      <hr className="border-border" />
      <h3 className="font-bold text-center">شارت الأسنان (دوس على أي سن)</h3>
      <ToothChart
        editable={editable}
        missingTeeth={state.missing_teeth}
        onToggleMissing={(id) => toggleTooth("missing_teeth", id)}
        extractionActive={state.extraction_choice === "extraction"}
        extractionTeeth={state.extraction_teeth}
        onToggleExtraction={(id) => toggleTooth("extraction_teeth", id)}
        bondingUpperDate={existing?.bonding_upper_date ?? null}
        bondingLowerDate={existing?.bonding_lower_date ?? null}
        notBondedUpper={notBondedUpper}
        notBondedLower={notBondedLower}
        onToggleNotBonded={toggleNotBonded}
        brokenTeeth={brokenTeeth}
        onToggleBroken={handleToggleBroken}
        busyBroken={brokenPending}
        rebondingCounts={rebondingCountsNum}
        onConfirmRebonding={handleConfirmRebonding}
        busyRebonding={rebondingPending}
        inventoryItems={inventoryItems}
        toothComments={state.tooth_comments}
        onChangeComment={setToothComment}
      />

      <hr className="border-border" />
      <h3 className="font-bold text-center">التشخيص (Diagnosis)</h3>

      <div className="space-y-4">
        <div className="text-sm font-semibold">Skeletal</div>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Antero-Posterior">
            <ChoiceGroup
              editable={editable}
              value={state.antero_posterior}
              onChange={(v) => set("antero_posterior", v)}
              options={[
                { value: "class1", label: "Class I" },
                { value: "class2", label: "Class II" },
                { value: "class3", label: "Class III" },
              ]}
            />
          </Field>
          <Field label="Facial Height">
            <ChoiceGroup
              editable={editable}
              value={state.facial_height}
              onChange={(v) => set("facial_height", v)}
              options={[
                { value: "increased", label: "Increased" },
                { value: "average", label: "Average" },
                { value: "decreased", label: "Decreased" },
              ]}
            />
          </Field>
        </div>
      </div>

      <div className="space-y-4">
        <div className="text-sm font-semibold">Dental</div>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Mx Incisor Inclination">
            <ChoiceGroup
              editable={editable}
              value={state.mx_incisor_inclination}
              onChange={(v) => set("mx_incisor_inclination", v)}
              options={[
                { value: "proclined", label: "Proclined" },
                { value: "average", label: "Average" },
                { value: "retroclined", label: "Retroclined" },
              ]}
            />
          </Field>
          <Field label="Mn Incisor Inclination">
            <ChoiceGroup
              editable={editable}
              value={state.mn_incisor_inclination}
              onChange={(v) => set("mn_incisor_inclination", v)}
              options={[
                { value: "proclined", label: "Proclined" },
                { value: "average", label: "Average" },
                { value: "retroclined", label: "Retroclined" },
              ]}
            />
          </Field>
          <Field label="Molar Relation - Right">
            <ChoiceGroup
              editable={editable}
              value={state.molar_relation_right}
              onChange={(v) => set("molar_relation_right", v)}
              options={[
                { value: "class1", label: "Class I" },
                { value: "class2", label: "Class II" },
                { value: "class3", label: "Class III" },
              ]}
            />
          </Field>
          <Field label="Molar Relation - Left">
            <ChoiceGroup
              editable={editable}
              value={state.molar_relation_left}
              onChange={(v) => set("molar_relation_left", v)}
              options={[
                { value: "class1", label: "Class I" },
                { value: "class2", label: "Class II" },
                { value: "class3", label: "Class III" },
              ]}
            />
          </Field>
          <Field label="Overbite">
            <ChoiceGroup
              editable={editable}
              value={state.overbite}
              onChange={(v) => set("overbite", v)}
              options={[
                { value: "open_bite", label: "Open Bite" },
                { value: "average", label: "Average" },
                { value: "deep_bite", label: "Deep Bite" },
              ]}
            />
          </Field>
          <Field label="Overjet">
            <ChoiceGroup
              editable={editable}
              value={state.overjet}
              onChange={(v) => set("overjet", v)}
              options={[
                { value: "increased", label: "Increased" },
                { value: "average", label: "Average" },
                { value: "decreased", label: "Decreased" },
              ]}
            />
          </Field>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Midline shift - Upper">
            <div className="flex items-center gap-3 flex-wrap">
              <ChoiceGroup
                editable={editable}
                value={state.midline_upper_direction}
                onChange={(v) => set("midline_upper_direction", v)}
                options={[
                  { value: "right", label: "To Right" },
                  { value: "left", label: "To Left" },
                ]}
              />
              {editable ? (
                <input
                  type="number"
                  step="0.5"
                  placeholder="mm"
                  value={state.midline_upper_mm}
                  onChange={(e) => set("midline_upper_mm", e.target.value)}
                  className="w-20 rounded-md border border-border bg-background px-2 py-1 text-sm"
                />
              ) : (
                state.midline_upper_mm && <span className="text-sm text-muted">{state.midline_upper_mm} mm</span>
              )}
            </div>
          </Field>
          <Field label="Midline shift - Lower">
            <div className="flex items-center gap-3 flex-wrap">
              <ChoiceGroup
                editable={editable}
                value={state.midline_lower_direction}
                onChange={(v) => set("midline_lower_direction", v)}
                options={[
                  { value: "right", label: "To Right" },
                  { value: "left", label: "To Left" },
                ]}
              />
              {editable ? (
                <input
                  type="number"
                  step="0.5"
                  placeholder="mm"
                  value={state.midline_lower_mm}
                  onChange={(e) => set("midline_lower_mm", e.target.value)}
                  className="w-20 rounded-md border border-border bg-background px-2 py-1 text-sm"
                />
              ) : (
                state.midline_lower_mm && <span className="text-sm text-muted">{state.midline_lower_mm} mm</span>
              )}
            </div>
          </Field>
          <Field label="Space analysis - Upper">
            <div className="flex items-center gap-3 flex-wrap">
              <ChoiceGroup
                editable={editable}
                value={state.space_upper_type}
                onChange={(v) => set("space_upper_type", v)}
                options={[
                  { value: "crowding", label: "Crowding" },
                  { value: "spacing", label: "Spacing" },
                ]}
              />
              {editable ? (
                <input
                  type="number"
                  step="0.5"
                  placeholder="mm"
                  value={state.space_upper_mm}
                  onChange={(e) => set("space_upper_mm", e.target.value)}
                  className="w-20 rounded-md border border-border bg-background px-2 py-1 text-sm"
                />
              ) : (
                state.space_upper_mm && <span className="text-sm text-muted">{state.space_upper_mm} mm</span>
              )}
            </div>
          </Field>
          <Field label="Space analysis - Lower">
            <div className="flex items-center gap-3 flex-wrap">
              <ChoiceGroup
                editable={editable}
                value={state.space_lower_type}
                onChange={(v) => set("space_lower_type", v)}
                options={[
                  { value: "crowding", label: "Crowding" },
                  { value: "spacing", label: "Spacing" },
                ]}
              />
              {editable ? (
                <input
                  type="number"
                  step="0.5"
                  placeholder="mm"
                  value={state.space_lower_mm}
                  onChange={(e) => set("space_lower_mm", e.target.value)}
                  className="w-20 rounded-md border border-border bg-background px-2 py-1 text-sm"
                />
              ) : (
                state.space_lower_mm && <span className="text-sm text-muted">{state.space_lower_mm} mm</span>
              )}
            </div>
          </Field>
        </div>
      </div>

      <div className="space-y-2">
        <div className="text-sm font-semibold">Cephalometric</div>
        <div className="overflow-x-auto">
          <table className="text-sm border border-border rounded-md w-full max-w-md">
            <thead>
              <tr className="bg-primary-soft">
                <th className="px-2 py-1.5 text-right border-b border-border">القياس</th>
                <th className="px-2 py-1.5 text-right border-b border-border">Norms</th>
                <th className="px-2 py-1.5 text-right border-b border-border">Case</th>
              </tr>
            </thead>
            <tbody>
              {CEPHALOMETRIC_ROWS.map((row) => (
                <tr key={row.key}>
                  <td className="px-2 py-1.5 border-b border-border">{row.label}</td>
                  <td className="px-2 py-1.5 border-b border-border text-muted">{row.norm}</td>
                  <td className="px-2 py-1.5 border-b border-border">
                    {editable ? (
                      <input
                        type="number"
                        step="0.1"
                        value={state[row.key]}
                        onChange={(e) => set(row.key, e.target.value)}
                        className="w-20 rounded-md border border-border bg-background px-2 py-1 text-sm"
                      />
                    ) : (
                      state[row.key] || <span className="text-muted">—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="space-y-4">
        <div className="text-sm font-semibold">Facial Analysis</div>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Nasolabial angle">
            <ChoiceGroup
              editable={editable}
              value={state.nasolabial_angle}
              onChange={(v) => set("nasolabial_angle", v)}
              options={[
                { value: "acute", label: "Acute" },
                { value: "average", label: "Average" },
                { value: "obtuse", label: "Obtuse" },
              ]}
            />
          </Field>
          <Field label="Lips">
            <ChoiceGroup
              editable={editable}
              value={state.lips}
              onChange={(v) => set("lips", v)}
              options={[
                { value: "competent", label: "Competent" },
                { value: "incompetent", label: "Incompetent" },
              ]}
            />
          </Field>
        </div>
      </div>

      <hr className="border-border" />
      <h3 className="font-bold text-center">خطة العلاج (Treatment Plan)</h3>

      <Field label="Extraction / Non-Extraction">
        <ChoiceGroup
          editable={editable}
          value={state.extraction_choice}
          onChange={(v) => set("extraction_choice", v)}
          options={[
            { value: "extraction", label: "Extraction" },
            { value: "non_extraction", label: "Non-Extraction" },
          ]}
        />
      </Field>

      {state.extraction_choice === "extraction" && (
        <p className="text-xs text-muted">حدد أرقام الأسنان المطلوب خلعها من الشارت فوق (دوس على السن وحدد "مطلوب خلعه").</p>
      )}

      <Field label="Anchorage">
        <div className="flex items-center gap-3 flex-wrap">
          <ChoiceGroup
            editable={editable}
            value={state.anchorage}
            onChange={(v) => set("anchorage", v)}
            options={[
              { value: "minimal", label: "Minimal" },
              { value: "moderate", label: "Moderate" },
              { value: "maximum", label: "Maximum" },
            ]}
          />
          {editable ? (
            <input
              type="text"
              placeholder="ملحوظة (اختياري)"
              value={state.anchorage_note}
              onChange={(e) => set("anchorage_note", e.target.value)}
              className="rounded-md border border-border bg-background px-2 py-1 text-sm"
            />
          ) : (
            state.anchorage_note && <span className="text-sm text-muted">{state.anchorage_note}</span>
          )}
        </div>
      </Field>

      <Field label="Hints">
        {editable ? (
          <textarea
            value={state.hints}
            onChange={(e) => set("hints", e.target.value)}
            rows={4}
            className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
          />
        ) : (
          <p className="text-sm whitespace-pre-wrap">{state.hints || <span className="text-muted">—</span>}</p>
        )}
      </Field>

      {editable && (
        <div className="flex items-center gap-3 pt-2">
          <button type="button" onClick={handleSave} disabled={isPending} className="btn-3d-primary px-5 py-2 rounded-md text-sm disabled:opacity-60">
            {isPending ? "جاري الحفظ..." : "حفظ شارت التقويم"}
          </button>
          {saved && !isPending && <span className="text-sm text-primary">تم الحفظ ✓</span>}
        </div>
      )}

      <hr className="border-border" />
      <h3 className="font-bold text-center">تركيب التقويم (Bonding)</h3>
      <div className="grid sm:grid-cols-2 gap-4">
        <BondingArchSection
          patientId={patientId}
          arch="upper"
          title="تركيب الفك العلوي"
          bracketItemId={existing?.bonding_upper_bracket_item_id ?? null}
          bracketQty={existing?.bonding_upper_bracket_qty ?? null}
          tubeItemId={existing?.bonding_upper_tube_item_id ?? null}
          tubeQty={existing?.bonding_upper_tube_qty ?? null}
          date={existing?.bonding_upper_date ?? null}
          notBondedTeeth={notBondedUpper}
          inventoryItems={inventoryItems}
          editable={editable}
        />
        <BondingArchSection
          patientId={patientId}
          arch="lower"
          title="تركيب الفك السفلي"
          bracketItemId={existing?.bonding_lower_bracket_item_id ?? null}
          bracketQty={existing?.bonding_lower_bracket_qty ?? null}
          tubeItemId={existing?.bonding_lower_tube_item_id ?? null}
          tubeQty={existing?.bonding_lower_tube_qty ?? null}
          date={existing?.bonding_lower_date ?? null}
          notBondedTeeth={notBondedLower}
          inventoryItems={inventoryItems}
          editable={editable}
        />
      </div>
    </div>
  );
}
