"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ROLE_LABELS, type SessionPayload } from "@/lib/auth";
import LogoutButton from "./LogoutButton";
import AccountMenu from "./AccountMenu";
import { HomeIcon, CalendarIcon, PatientsIcon, InvoiceIcon, InventoryIcon, ReportsIcon, SettingsIcon, HeartIcon } from "./icons";

type IconComponent = (props: { className?: string }) => React.JSX.Element;

// ترتيب ثابت مطلوب صراحة من المستخدم — أي لينك ظاهر لأي حساب (سواء بحكم الدور
// الثابت أو صلاحية قابلة للمنح زي reports_full/reports_own أو manage_inventory)
// لازم يفضل بنفس الترتيب ده دايمًا، مش بس للأدمن: الرئيسية، الاستقبال، المرضى،
// الفواتير، المخزن، التقارير. "الإعدادات" (أدمن بس) مش جزء من الترتيب اللي
// المستخدم حدده فمتسيبة آخر حاجة زي ما كانت. كل لينك له لون شارة مختلف (tone)
// عشان تسهيل التمييز البصري السريع بين الصفحات — نفس فكرة نموذج التصميم (ج)
// اللي المستخدم اختاره.
function buildOrderedLinks(
  session: SessionPayload,
  canViewReports: boolean,
  canViewInventory: boolean
): { href: string; label: string; icon: IconComponent; tone?: string }[] {
  const candidates: { href: string; label: string; icon: IconComponent; tone?: string; visible: boolean }[] = [
    { href: "/", label: "الرئيسية", icon: HomeIcon, visible: true },
    // للاستقبال بس: مفيش داعي للينك منفصل هنا — "الرئيسية" أصلاً بتوجّههم لنفس
    // الصفحة دي تلقائيًا (شوف src/app/page.tsx)، فاللينك المنفصل كان مكرر بصريًا.
    { href: "/front-desk", label: "الاستقبال", icon: CalendarIcon, tone: "tone-blue", visible: session.role === "admin" },
    { href: "/patients", label: "المرضى", icon: PatientsIcon, tone: "tone-purple", visible: true },
    {
      href: "/invoices",
      label: "الفواتير",
      icon: InvoiceIcon,
      tone: "tone-amber",
      visible: ["admin", "reception", "accountant"].includes(session.role),
    },
    { href: "/inventory", label: "المخزن", icon: InventoryIcon, tone: "tone-teal", visible: canViewInventory },
    { href: "/reports", label: "التقارير", icon: ReportsIcon, tone: "tone-red", visible: canViewReports },
    { href: "/settings", label: "الإعدادات", icon: SettingsIcon, visible: session.role === "admin" },
  ];
  return candidates.filter((c) => c.visible).map(({ href, label, icon, tone }) => ({ href, label, icon, tone }));
}

export default function NavBar({
  session,
  canViewReports = false,
  canViewInventory = false,
}: {
  session: SessionPayload;
  canViewReports?: boolean;
  canViewInventory?: boolean;
}) {
  const pathname = usePathname();
  const visibleLinks = buildOrderedLinks(session, canViewReports, canViewInventory);

  return (
    <header className="border-b border-border bg-surface">
      <div className="max-w-6xl mx-auto px-4 py-2 flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-5 flex-wrap">
          <span className="flex items-center gap-1.5 font-bold text-primary text-lg shrink-0">
            <HeartIcon className="w-6 h-6" />
            عيادتي
          </span>
          <nav className="flex items-center gap-1 flex-wrap">
            {visibleLinks.map((l) => {
              const Icon = l.icon;
              const active = l.href === "/" ? pathname === "/" : pathname.startsWith(l.href);
              return (
                <Link
                  key={l.href}
                  href={l.href}
                  data-active={active}
                  className="nav-icon-item flex flex-col items-center gap-1 px-2 py-1.5 rounded-lg text-foreground hover:bg-primary-soft/40 transition-colors w-16"
                >
                  <span className={`icon-badge-3d ${l.tone ?? ""} w-9 h-9`}>
                    <Icon className="w-[18px] h-[18px]" />
                  </span>
                  <span className="text-[11px] text-center leading-tight">{l.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>
        <div className="flex items-center gap-3 text-sm text-muted shrink-0">
          <AccountMenu fullName={session.fullName} roleLabel={ROLE_LABELS[session.role]} />
          <LogoutButton />
        </div>
      </div>
    </header>
  );
}
