"use client";

// ===================================================================
// Orthodontic chart v2 — full page 1 (isolated prototype, mock data only)
// ===================================================================
// Built on the user's Canva design (design_id: DAHTZKEWWQI). Fully isolated
// route — not linked to nav or real data — so the user can review the shape
// and give feedback before anything is merged into the real system.
//
// 2026-08-27 fidelity pass: layout/labels/fields re-checked literally against
// Canva page 1's own element content and coordinates (not from memory).
// 2026-08-27 feedback round 2: whole chart switched to English + LTR (matches
// Canva's own coordinate system exactly, no more RTL mirroring); Follow ups
// table (page 2 design) added below the Interactive/Diagnostic card, fixed in
// place regardless of the toggle; Treatment Plan reworked — Extraction (with
// a small quadrant/position "cross" mark, per the user's own sketch) sits
// beside Anchorage, and a free-text notes box takes Anchorage's old spot;
// selecting "Bonding Upper/Lower" in a Follow-up visit now auto-bonds that
// whole arch (except the 2nd/3rd molars) on the Interactive chart; the
// Interactive/Diagnostic chart components stay mounted (hidden via CSS
// instead of unmounted) so bonding state survives the toggle; stripping-count
// badges enlarged/re-stacked so they no longer get clipped by the next tooth.
// Full history: project "Clinic mangment system" on claude.ai
// (orthodontic-chart-v2-*.md).

import { useState, useRef, useMemo, useEffect } from "react";
import InteractiveToothChart, { type MockInventoryLog, type InteractiveToothChartHandle } from "./InteractiveToothChart";
import DiagnosticChart from "./DiagnosticChart";
import FollowUpsTable from "./FollowUpsTable";

const MOCK_BRACKET_TYPES = ["American", "Ormco", "3M"];
const PRESCRIPTION_OPTIONS = ["Roth", "MBT", "Andrews"];
const SLOT_OPTIONS = ["18", "22"];
// Anchorage device type — no other source of truth for this list yet, seeded
// with "Mini-screw" (the value shown in the design) + common ortho anchorage
// types. Needs confirmation from the user before this merges for real.
const ANCHORAGE_OPTIONS = ["Mini-screw", "Headgear", "Nance appliance", "TPA", "Lingual arch", "Class II elastics", "Class III elastics"];

const POSITIONS = ["1", "2", "3", "4", "5", "6", "7", "8"];

type ChartView = "interactive" | "diagnostic";

interface MockPhoto {
  id: string;
  url: string;
  rotation: number;
  name: string;
}

// Extraction is a literal quadrant "cross" — 2 rows (Upper/Lower) × 2 columns
// (Right/Left) = 4 cells, one dropdown per cell (tooth position 1-8 within
// that quadrant). That's a hard cap of 4 teeth, matching the user's "we never
// extract more than 4 teeth in ortho" — no add/remove controls needed at all.
interface ExtractionState {
  ur: string;
  ul: string;
  lr: string;
  ll: string;
}

function emptyExtraction(): ExtractionState {
  return { ur: "", ul: "", lr: "", ll: "" };
}

interface LoggedInventoryEntry extends MockInventoryLog {
  id: string;
}

// Chronological, plain-text history of everything that happened on the
// Interactive chart (bond/debond/no-brackets/rebond/extraction/stripping/
// miniscrew) — separate from the Inventory list, per the user's request for
// an "Interactive report" they can open from a link under the Inventory list.
interface ChartEventEntry {
  id: string;
  date: string;
  text: string;
}

function todayStr(): string {
  const d = new Date();
  return `${String(d.getDate()).padStart(2, "0")}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getFullYear()).slice(2)}`;
}

// Client-side downscale + re-encode (canvas → JPEG @ ~85%) so uploaded photos
// stay high-quality but much smaller in MB — answers the user's question
// about shrinking file size without losing visible quality (same idea as
// Paint's "resize + save" trick, done automatically on upload here).
function compressImage(file: File): Promise<string> {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const maxDim = 1600;
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          const scale = maxDim / Math.max(width, height);
          width = Math.round(width * scale);
          height = Math.round(height * scale);
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve(URL.createObjectURL(file));
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        canvas.toBlob(
          (blob) => resolve(blob ? URL.createObjectURL(blob) : URL.createObjectURL(file)),
          "image/jpeg",
          0.85
        );
      };
      img.onerror = () => resolve(URL.createObjectURL(file));
      img.src = reader.result as string;
    };
    reader.onerror = () => resolve(URL.createObjectURL(file));
    reader.readAsDataURL(file);
  });
}

// Grows downward as the user types instead of scrolling internally — used
// for Chief Complaint and the Treatment Plan free-text notes, per the user's
// explicit "no scroll, let it grow" request.
function AutoGrowTextarea({
  value,
  onChange,
  placeholder,
  minRows = 3,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  minRows?: number;
}) {
  return (
    <textarea
      value={value}
      onChange={(e) => {
        onChange(e.target.value);
        e.target.style.height = "auto";
        e.target.style.height = `${e.target.scrollHeight}px`;
      }}
      placeholder={placeholder}
      rows={minRows}
      className="w-full resize-none overflow-hidden rounded-md border border-border bg-background px-2 py-1.5 text-sm placeholder:text-muted"
    />
  );
}

function Dropdown({
  value,
  onChange,
  options,
  placeholder = "—",
}: {
  value: string | null;
  onChange: (v: string) => void;
  options: string[];
  placeholder?: string;
}) {
  return (
    <select
      value={value ?? ""}
      onChange={(e) => onChange(e.target.value)}
      className="rounded-md border border-border bg-background px-2 py-1 text-xs"
    >
      <option value="">{placeholder}</option>
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  );
}

export default function OrthoChartV2({ patientName }: { patientName: string }) {
  const [bracketType, setBracketType] = useState<string | null>(null);
  const [prescription, setPrescription] = useState<string | null>(null);
  const [slot, setSlot] = useState<string | null>(null);

  const [photos, setPhotos] = useState<MockPhoto[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const [photoDescription, setPhotoDescription] = useState("");
  const [openPhotoIndex, setOpenPhotoIndex] = useState<number | null>(null);

  const [chiefComplaint, setChiefComplaint] = useState("");

  const [extraction, setExtraction] = useState<ExtractionState>(emptyExtraction());
  const [anchorage, setAnchorage] = useState<string | null>(null);
  const [treatmentNote, setTreatmentNote] = useState("");

  const [view, setView] = useState<ChartView>("interactive");
  const [inventoryLog, setInventoryLog] = useState<LoggedInventoryEntry[]>([]);
  const [showInventoryModal, setShowInventoryModal] = useState(false);
  const [chartEvents, setChartEvents] = useState<ChartEventEntry[]>([]);
  const [showReportModal, setShowReportModal] = useState(false);
  const chartRef = useRef<InteractiveToothChartHandle>(null);

  // Same functions as the real system's photo/x-ray uploader (multi-select +
  // drag&drop, click-to-preview with prev/next + download, delete with
  // confirmation) — just restyled to the new Canva strip design. Every image
  // is downscaled + re-encoded on the way in (see compressImage) so quality
  // stays high but the file size is much smaller, same idea as "resize + save"
  // in Paint.
  async function addPhotosFromFiles(files: FileList | null) {
    if (!files) return;
    const imageFiles = Array.from(files).filter((f) => f.type.startsWith("image/"));
    const next = await Promise.all(
      imageFiles.map(async (f) => ({
        id: `${Date.now()}-${f.name}-${Math.random()}`,
        url: await compressImage(f),
        rotation: 0,
        name: f.name,
      }))
    );
    setPhotos((prev) => [...prev, ...next]);
  }

  function rotatePhoto(id: string) {
    setPhotos((prev) => prev.map((p) => (p.id === id ? { ...p, rotation: (p.rotation + 90) % 360 } : p)));
  }

  function removePhoto(id: string) {
    setPhotos((prev) => prev.filter((p) => p.id !== id));
  }

  function deletePhotoWithConfirm(id: string) {
    // Same confirm-before-delete as the real gallery (PatientImageGallery) —
    // this can't be undone, so ask first.
    if (window.confirm("Delete this photo? This can't be undone.")) {
      removePhoto(id);
      setOpenPhotoIndex(null);
    }
  }

  function openPhotoAt(idx: number) {
    setOpenPhotoIndex(idx);
  }

  function closePhotoViewer() {
    setOpenPhotoIndex(null);
  }

  function prevPhoto() {
    setOpenPhotoIndex((i) => (i === null || photos.length === 0 ? i : (i - 1 + photos.length) % photos.length));
  }

  function nextPhoto() {
    setOpenPhotoIndex((i) => (i === null || photos.length === 0 ? i : (i + 1) % photos.length));
  }

  useEffect(() => {
    if (openPhotoIndex === null) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") closePhotoViewer();
      else if (e.key === "ArrowLeft") prevPhoto();
      else if (e.key === "ArrowRight") nextPhoto();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [openPhotoIndex, photos.length]);

  function updateExtraction(key: keyof ExtractionState, value: string) {
    setExtraction((prev) => ({ ...prev, [key]: value }));
  }

  function onInventoryDeduct(log: MockInventoryLog) {
    const date = log.date || todayStr();
    // Every tube bonded on the same visit date gets merged into a single
    // "N × Tubes (16,26,...)" line instead of one row per bonding action
    // (bulk-bond + any manual single-tooth tube bonding that same day).
    if (log.label === "Tubes" && log.teeth && log.teeth.length > 0) {
      setInventoryLog((prev) => {
        const idx = prev.findIndex((l) => l.label === "Tubes" && l.date === date);
        if (idx === -1) {
          return [{ ...log, id: `${Date.now()}-${Math.random()}`, date }, ...prev];
        }
        const existing = prev[idx];
        const merged: LoggedInventoryEntry = {
          ...existing,
          qty: existing.qty + log.qty,
          teeth: [...(existing.teeth || []), ...(log.teeth || [])],
        };
        const next = [...prev];
        next[idx] = merged;
        return next;
      });
      return;
    }
    setInventoryLog((prev) => [{ ...log, id: `${Date.now()}-${Math.random()}`, date }, ...prev]);
  }

  function deleteInventoryEntry(id: string) {
    // Mock-level delete for this preview — the real system should gate this
    // to admins only, per the user's explicit request ("على الاقل تبقى مع الادمن").
    setInventoryLog((prev) => prev.filter((l) => l.id !== id));
  }

  // Lets a Follow-up visit row cleanly replace its own (non-bonding)
  // deductions when it's edited after being saved — see FollowUpsTable's
  // onSaveVisit. Never touches bonding-triggered entries (those aren't
  // tagged with a visitId at all).
  function removeVisitDeductions(visitId: string) {
    setInventoryLog((prev) => prev.filter((l) => l.visitId !== visitId));
  }

  function onChartEvent(text: string, date?: string) {
    setChartEvents((prev) => [{ id: `${Date.now()}-${Math.random()}`, date: date || todayStr(), text }, ...prev]);
  }

  // Grouped-by-date view for the Inventory list modal (most recent first —
  // entries are already prepended in that order, so the map preserves it).
  const inventoryByDate = useMemo(() => {
    const map = new Map<string, LoggedInventoryEntry[]>();
    inventoryLog.forEach((l) => {
      const key = l.date || "—";
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(l);
    });
    return Array.from(map.entries());
  }, [inventoryLog]);

  // Same grouped-by-date shape for the Interactive report modal.
  const chartEventsByDate = useMemo(() => {
    const map = new Map<string, ChartEventEntry[]>();
    chartEvents.forEach((ev) => {
      const key = ev.date || "—";
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(ev);
    });
    return Array.from(map.entries());
  }, [chartEvents]);

  return (
    <div className="space-y-4">
      {/* Title + Name + Brackets/Rx/Slot — one row, matching the design */}
      <div className="card-3d rounded-xl p-5 space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h1 className="text-lg font-bold flex-1 text-center">Orthodontic chart</h1>
          <span className="text-[10px] px-2 py-1 rounded-full bg-amber-100 text-amber-800 border border-amber-300">
            Preview prototype — not connected to real data
          </span>
        </div>
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="text-sm">
            <span className="text-muted">Name: </span>
            <span className="font-semibold">{patientName}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-muted">Brackets:</span>
            <Dropdown value={bracketType} onChange={setBracketType} options={MOCK_BRACKET_TYPES} />
            <Dropdown value={prescription} onChange={setPrescription} options={PRESCRIPTION_OPTIONS} />
            <Dropdown value={slot} onChange={setSlot} options={SLOT_OPTIONS} />
          </div>
        </div>
      </div>

      {/* Photos & X-rays — + button plus a Description (Optional) field, per the design */}
      <div className="card-3d rounded-xl p-5 space-y-1.5">
        <div className="text-xs text-muted">Photos &amp; X-rays</div>
        <div className="flex gap-3 flex-wrap items-start">
          {photos.map((p, idx) => (
            <div key={p.id} className="relative w-20 h-20 rounded-md overflow-hidden border border-border bg-background group">
              <button type="button" onClick={() => openPhotoAt(idx)} className="block w-full h-full cursor-zoom-in">
                <img
                  src={p.url}
                  alt=""
                  className="w-full h-full object-cover"
                  style={{ transform: `rotate(${p.rotation}deg)` }}
                />
              </button>
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-center justify-center gap-1 opacity-0 group-hover:opacity-100 pointer-events-none">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    rotatePhoto(p.id);
                  }}
                  className="text-white text-xs bg-black/50 rounded px-1.5 py-0.5 pointer-events-auto"
                  title="Rotate"
                >
                  ↻
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    deletePhotoWithConfirm(p.id);
                  }}
                  className="text-white text-xs bg-black/50 rounded px-1.5 py-0.5 pointer-events-auto"
                  title="Delete"
                >
                  ×
                </button>
              </div>
            </div>
          ))}
          <label
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              addPhotosFromFiles(e.dataTransfer.files);
            }}
            className={`w-20 h-20 rounded-md border-2 border-dashed flex items-center justify-center cursor-pointer text-2xl text-muted transition-colors ${
              dragOver ? "border-primary bg-primary-soft" : "border-border hover:bg-primary-soft"
            }`}
          >
            +
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={(e) => addPhotosFromFiles(e.target.files)}
            />
          </label>
        </div>
        <div className="pt-1 max-w-xs">
          <div className="text-[11px] text-muted mb-1">Description (Optional)</div>
          <input
            type="text"
            value={photoDescription}
            onChange={(e) => setPhotoDescription(e.target.value)}
            placeholder="Eg.: Panorama"
            className="w-full rounded-md border border-border bg-background px-2 py-1 text-xs"
          />
        </div>
      </div>

      {/* Chief Complaint + Treatment Plan — side by side, per the design */}
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="card-3d rounded-xl p-5 space-y-1.5">
          <div className="text-sm font-semibold">Chief Complaint</div>
          <AutoGrowTextarea value={chiefComplaint} onChange={setChiefComplaint} placeholder="Eg.: Spacing" minRows={3} />
          <div className="flex flex-col items-start gap-1">
            <button
              type="button"
              onClick={() => setShowInventoryModal(true)}
              className="text-sm font-medium text-primary underline hover:no-underline"
            >
              Inventory list{inventoryLog.length > 0 ? ` (${inventoryLog.length})` : ""}
            </button>
            <button
              type="button"
              onClick={() => setShowReportModal(true)}
              className="text-sm font-medium text-primary underline hover:no-underline"
            >
              Interactive report{chartEvents.length > 0 ? ` (${chartEvents.length})` : ""}
            </button>
          </div>
        </div>

        <div className="card-3d rounded-xl p-5 space-y-3">
          <div className="text-sm font-semibold">Treatment Plan</div>

          <div className="flex items-start gap-6 flex-wrap">
            <div className="space-y-1.5">
              <div className="text-xs text-muted">Extraction:</div>
              {/* A literal quadrant "cross": 2 rows (Upper/Lower) × 2 columns
                  (Right/Left), one dropdown per quadrant — a hard cap of 4
                  teeth total (we never extract more than 4 in ortho), no
                  add/remove controls needed. Black cross lines. */}
              <div className="relative inline-block">
                <div className="grid grid-cols-2 gap-x-3">
                  <div className="pb-1.5 flex justify-center" style={{ borderBottom: "2px solid #1c2521" }}>
                    <Dropdown value={extraction.ur} onChange={(v) => updateExtraction("ur", v)} options={POSITIONS} />
                  </div>
                  <div className="pb-1.5 flex justify-center" style={{ borderBottom: "2px solid #1c2521" }}>
                    <Dropdown value={extraction.ul} onChange={(v) => updateExtraction("ul", v)} options={POSITIONS} />
                  </div>
                  <div className="pt-1.5 flex justify-center">
                    <Dropdown value={extraction.lr} onChange={(v) => updateExtraction("lr", v)} options={POSITIONS} />
                  </div>
                  <div className="pt-1.5 flex justify-center">
                    <Dropdown value={extraction.ll} onChange={(v) => updateExtraction("ll", v)} options={POSITIONS} />
                  </div>
                </div>
                <div
                  className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 pointer-events-none"
                  style={{ width: "2px", background: "#1c2521" }}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="text-xs text-muted">Anchorage:</div>
              <Dropdown value={anchorage} onChange={setAnchorage} options={ANCHORAGE_OPTIONS} />
            </div>
          </div>

          <div className="space-y-1">
            <div className="text-xs text-muted">Notes (free text)</div>
            <AutoGrowTextarea value={treatmentNote} onChange={setTreatmentNote} minRows={2} />
          </div>
        </div>
      </div>

      {/* Diagnosis / Interactive chart toggle — both stay mounted (hidden with
          CSS, not unmounted) so bonding/extraction state survives switching. */}
      <div className="card-3d rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={() => setView((v) => (v === "interactive" ? "diagnostic" : "interactive"))}
            className="text-xs text-primary underline hover:no-underline"
          >
            {view === "interactive" ? "Diagnostic chart" : "Interactive chart"}
          </button>
          <h3 className="font-bold">{view === "interactive" ? "Interactive chart" : "Diagnosis:"}</h3>
        </div>

        <div style={{ display: view === "interactive" ? "block" : "none" }}>
          <InteractiveToothChart ref={chartRef} onInventoryDeduct={onInventoryDeduct} onChartEvent={onChartEvent} />
        </div>
        <div style={{ display: view === "diagnostic" ? "block" : "none" }}>
          <DiagnosticChart />
        </div>
      </div>

      {/* Follow ups — fixed right below the Interactive chart, regardless of
          the toggle above (page 2 of the design). Picking "Bonding Upper/Lower"
          as the service auto-bonds that arch on the Interactive chart, and
          wire/elastics/O-tie/power-chain selections deduct from the shared
          mock inventory (see the "Inventory list" link + modal above, under
          Chief Complaint). */}
      <FollowUpsTable
        onBulkBond={(arch, date) => chartRef.current?.bulkBond(arch, date)}
        onInventoryDeduct={onInventoryDeduct}
        onRemoveVisitDeductions={removeVisitDeductions}
      />

      {/* Inventory list modal — full deduction history since the patient
          started treatment, with a delete/undo button per entry (mock-level
          here; the real system should gate deletion to admins only). */}
      {showInventoryModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
          onClick={() => setShowInventoryModal(false)}
        >
          <div
            className="card-3d rounded-xl p-5 w-full max-w-md max-h-[80vh] flex flex-col space-y-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold">Inventory list</h3>
              <button type="button" onClick={() => setShowInventoryModal(false)} className="text-muted text-lg leading-none px-1">
                ×
              </button>
            </div>
            <p className="text-xs text-muted">Materials used for this patient since treatment started.</p>
            <div className="overflow-y-auto space-y-3">
              {inventoryLog.length === 0 && <p className="text-xs text-muted">Nothing used yet.</p>}
              {inventoryByDate.map(([date, entries]) => (
                <div key={date} className="rounded-lg border border-border p-2 space-y-1.5">
                  <div className="text-[11px] font-semibold text-muted">📅 {date}</div>
                  {entries.map((l) => (
                    <div key={l.id} className="flex items-center justify-between gap-2 text-xs rounded-md border border-border px-2 py-1.5">
                      <span>
                        − {l.qty} × {l.label}
                        {l.teeth && l.teeth.length > 0 ? ` (${l.teeth.join(", ")})` : ""}
                      </span>
                      <button
                        type="button"
                        onClick={() => deleteInventoryEntry(l.id)}
                        className="text-muted hover:text-red-600 shrink-0"
                        title="Delete / undo this deduction"
                      >
                        Undo
                      </button>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Interactive report modal — chronological, dated history of every
          bond/debond/no-brackets/rebond/extraction/stripping/miniscrew event
          on the Interactive chart, so it's traceable who did what and when
          without digging through the tooth chart itself. */}
      {showReportModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
          onClick={() => setShowReportModal(false)}
        >
          <div
            className="card-3d rounded-xl p-5 w-full max-w-md max-h-[80vh] flex flex-col space-y-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold">Interactive report</h3>
              <button type="button" onClick={() => setShowReportModal(false)} className="text-muted text-lg leading-none px-1">
                ×
              </button>
            </div>
            <p className="text-xs text-muted">Everything that happened on the Interactive chart, by date.</p>
            <div className="overflow-y-auto space-y-3">
              {chartEvents.length === 0 && <p className="text-xs text-muted">Nothing recorded yet.</p>}
              {chartEventsByDate.map(([date, events]) => (
                <div key={date} className="rounded-lg border border-border p-2 space-y-1.5">
                  <div className="text-[11px] font-semibold text-muted">📅 {date}</div>
                  {events.map((ev) => (
                    <div key={ev.id} className="text-xs rounded-md border border-border px-2 py-1.5">
                      {ev.text}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Photo viewer — same capabilities as the real gallery (prev/next,
          keyboard nav, download, delete with confirm), new compact styling. */}
      {openPhotoIndex !== null && photos[openPhotoIndex] && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4" onClick={closePhotoViewer}>
          {photos.length > 1 && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                prevPhoto();
              }}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-white/80 hover:text-white text-4xl px-3 py-2 select-none"
              aria-label="Previous"
            >
              ‹
            </button>
          )}

          <img
            src={photos[openPhotoIndex].url}
            alt=""
            className="max-w-[90vw] max-h-[85vh] object-contain rounded shadow-2xl"
            style={{ transform: `rotate(${photos[openPhotoIndex].rotation}deg)` }}
            onClick={(e) => e.stopPropagation()}
          />

          {photos.length > 1 && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                nextPhoto();
              }}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-white/80 hover:text-white text-4xl px-3 py-2 select-none"
              aria-label="Next"
            >
              ›
            </button>
          )}

          <a
            href={photos[openPhotoIndex].url}
            download={photos[openPhotoIndex].name}
            onClick={(e) => e.stopPropagation()}
            className="absolute top-4 right-4 text-white/90 hover:text-white text-sm bg-black/40 hover:bg-black/60 rounded-md px-3 py-1.5 transition-colors"
          >
            ⬇ Download
          </a>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              deletePhotoWithConfirm(photos[openPhotoIndex].id);
            }}
            className="absolute top-4 left-4 text-white/90 hover:text-white text-sm bg-black/40 hover:bg-red-600 rounded-md px-3 py-1.5 transition-colors"
          >
            🗑 Delete
          </button>

          <div className="absolute bottom-4 inset-x-0 text-center text-white/70 text-xs">
            {openPhotoIndex + 1} / {photos.length}
          </div>
        </div>
      )}
    </div>
  );
}
