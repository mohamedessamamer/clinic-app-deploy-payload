"use client";

// شارت التقويم v2 — "Diagnostic chart" (بروتوتايب معزول، mock data بس).
// حاجة منفصلة تمامًا عن الـInteractive chart وليها زرار خاص بيها (مش Stripping/
// Miniscrew — دول جزء من الـInteractive chart نفسه). الحقول والترتيب هنا اتاخدوا
// حرفيًا من محتوى صفحة 1 في تصميم Canva (design_id: DAHTZKEWWQI، آخر مراجعة
// 2026-08-27) — شبكة 7 صفوف × عمودين بدون عناوين فرعية (زي ما هي بالظبط)، مفيش
// جدول Cephalometric لأنه مش موجود في التصميم الحالي. قيم الاختيارات نفسها زي
// الشارت الحالي (OrthodonticChartForm.tsx) عشان البيانات تفضل متوافقة وقت الدمج.

import { useState } from "react";

type V = string;

function Select({
  value,
  onChange,
  options,
  className = "",
}: {
  value: V;
  onChange: (v: V) => void;
  options: { value: string; label: string }[];
  className?: string;
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className={`rounded-md border border-border bg-background px-1.5 py-1 text-xs max-w-[110px] ${className}`}
    >
      <option value="">—</option>
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}

function MmInput({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <span className="flex items-center gap-1 text-[10px] text-muted">
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-10 rounded-md border border-border bg-background px-1 py-1 text-xs"
      />
      mm
    </span>
  );
}

const CLASS_OPTIONS = [
  { value: "class1", label: "Class I" },
  { value: "class2", label: "Class II" },
  { value: "class3", label: "Class III" },
];
const INCLINATION_OPTIONS = [
  { value: "proclined", label: "Proclined" },
  { value: "average", label: "Average" },
  { value: "retroclined", label: "Retroclined" },
];
const DIRECTION_OPTIONS = [
  { value: "right", label: "To Right" },
  { value: "left", label: "To Left" },
];
const SPACE_OPTIONS = [
  { value: "crowding", label: "Crowding" },
  { value: "spacing", label: "Spacing" },
];

// صف من الشبكة: تسمية على اليمين + Select على الشمال (مطابق لترتيب الحقول في
// الديزاين: Skeletal/Facial Height، Mx/Mn incisors، Molars Right/Left،
// Overbite/Overjet، Midline Upper/Lower (+mm)، Space Upper/Lower (+mm)،
// Facial: Nasolabial/Lips).
function Row({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-2 py-1">
      <span className="text-xs text-muted whitespace-nowrap">{label}</span>
      <div className="flex items-center gap-1.5">{children}</div>
    </div>
  );
}

export default function DiagnosticChart() {
  const [v, setV] = useState<Record<string, string>>({});
  const set = (k: string) => (val: string) => setV((p) => ({ ...p, [k]: val }));

  return (
    <div className="grid grid-cols-2 gap-x-4 text-sm">
      <Row label="Skeletal">
        <Select value={v.skeletal ?? ""} onChange={set("skeletal")} options={CLASS_OPTIONS} />
      </Row>
      <Row label="Facial Height">
        <Select
          value={v.fh ?? ""}
          onChange={set("fh")}
          options={[
            { value: "increased", label: "Increased" },
            { value: "average", label: "Average" },
            { value: "decreased", label: "Decreased" },
          ]}
        />
      </Row>

      <Row label="Mx incisors">
        <Select value={v.mx ?? ""} onChange={set("mx")} options={INCLINATION_OPTIONS} />
      </Row>
      <Row label="Mn incisors">
        <Select value={v.mn ?? ""} onChange={set("mn")} options={INCLINATION_OPTIONS} />
      </Row>

      <Row label="Molars: Right">
        <Select value={v.mrr ?? ""} onChange={set("mrr")} options={CLASS_OPTIONS} />
      </Row>
      <Row label="Left">
        <Select value={v.mrl ?? ""} onChange={set("mrl")} options={CLASS_OPTIONS} />
      </Row>

      <Row label="Overbite">
        <Select
          value={v.overbite ?? ""}
          onChange={set("overbite")}
          options={[
            { value: "open_bite", label: "Open Bite" },
            { value: "average", label: "Average" },
            { value: "deep_bite", label: "Deep Bite" },
          ]}
        />
      </Row>
      <Row label="Overjet">
        <Select
          value={v.overjet ?? ""}
          onChange={set("overjet")}
          options={[
            { value: "increased", label: "Increased" },
            { value: "average", label: "Average" },
            { value: "decreased", label: "Decreased" },
          ]}
        />
      </Row>

      <Row label="Midline: Upper">
        <Select value={v.mlu ?? ""} onChange={set("mlu")} options={DIRECTION_OPTIONS} />
        <MmInput value={v.mlu_mm ?? ""} onChange={set("mlu_mm")} />
      </Row>
      <Row label="Lower">
        <Select value={v.mll ?? ""} onChange={set("mll")} options={DIRECTION_OPTIONS} />
        <MmInput value={v.mll_mm ?? ""} onChange={set("mll_mm")} />
      </Row>

      <Row label="Space: Upper">
        <Select value={v.spu ?? ""} onChange={set("spu")} options={SPACE_OPTIONS} />
        <MmInput value={v.spu_mm ?? ""} onChange={set("spu_mm")} />
      </Row>
      <Row label="Lower">
        <Select value={v.spl ?? ""} onChange={set("spl")} options={SPACE_OPTIONS} />
        <MmInput value={v.spl_mm ?? ""} onChange={set("spl_mm")} />
      </Row>

      <Row label="Facial: Nasolabial">
        <Select
          value={v.nasolabial ?? ""}
          onChange={set("nasolabial")}
          options={[
            { value: "acute", label: "Acute" },
            { value: "average", label: "Average" },
            { value: "obtuse", label: "Obtuse" },
          ]}
        />
      </Row>
      <Row label="Lips">
        <Select
          value={v.lips ?? ""}
          onChange={set("lips")}
          options={[
            { value: "competent", label: "Competent" },
            { value: "incompetent", label: "Incompetent" },
          ]}
        />
      </Row>
    </div>
  );
}
