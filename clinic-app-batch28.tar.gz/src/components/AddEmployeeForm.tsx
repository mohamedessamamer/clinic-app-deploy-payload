"use client";

import { useActionState, useRef } from "react";
import { addEmployeeAction } from "@/app/settings/actions";

const initialState: { username?: string; password?: string; error?: string } = {};

// نفس أكواد الأخطاء المرجوعة من addDoctorAction/addEmployeeAction في actions.ts.
const ADD_USER_ERROR_LABELS: Record<string, string> = {
  missing: "لازم تملى الاسم والدور.",
  invalid_username: "اسم المستخدم لازم يكون حروف إنجليزي وأرقام و . _ - بس (من غير مسافات)، من 3 لـ 30 حرف.",
  username_taken: "اسم المستخدم ده مستخدم بالفعل — اختار اسم تاني.",
};

const ROLE_OPTIONS: { value: string; label: string }[] = [
  { value: "reception", label: "استقبال" },
  { value: "accountant", label: "محاسب" },
  { value: "clinic_manager", label: "مدير العيادة" },
];

export default function AddEmployeeForm() {
  const [state, formAction, isPending] = useActionState(addEmployeeAction, initialState);
  const formRef = useRef<HTMLFormElement>(null);

  return (
    <div className="space-y-3">
      {state.username && state.password && (
        <div className="rounded-md bg-green-50 border border-green-200 px-3 py-3 text-sm space-y-1">
          <p className="font-medium text-green-800">تم إنشاء حساب الموظف. سجّل البيانات دي دلوقتي — مش هتتعرض تاني:</p>
          <p>
            اسم المستخدم: <span className="font-mono font-semibold">{state.username}</span>
          </p>
          <p>
            كلمة السر: <span className="font-mono font-semibold">{state.password}</span>
          </p>
        </div>
      )}
      {state.error && (
        <p className="text-sm text-red-700 bg-red-50 border border-red-200 rounded-md px-3 py-2">
          {ADD_USER_ERROR_LABELS[state.error] ?? "حصل خطأ، حاول تاني."}
        </p>
      )}
      <form
        ref={formRef}
        action={(formData) => {
          formAction(formData);
          formRef.current?.reset();
        }}
        className="flex items-end gap-2 flex-wrap"
      >
        <div className="flex-1 min-w-[200px]">
          <label className="block text-xs text-muted mb-1">اسم الموظف بالكامل</label>
          <input
            name="full_name"
            required
            className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
          />
        </div>
        <div className="min-w-[160px]">
          <label className="block text-xs text-muted mb-1">اسم المستخدم (اختياري)</label>
          <input
            name="username"
            placeholder="سيبه فاضي يتولد تلقائي"
            className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs text-muted mb-1">الدور</label>
          <select name="role" required className="rounded-md border border-border bg-background px-3 py-2 text-sm">
            {ROLE_OPTIONS.map((r) => (
              <option key={r.value} value={r.value}>
                {r.label}
              </option>
            ))}
          </select>
        </div>
        <button
          type="submit"
          disabled={isPending}
          className="rounded-md btn-3d-primary px-4 py-2 text-sm font-medium transition-colors disabled:opacity-60"
        >
          {isPending ? "جارٍ الإنشاء..." : "+ إضافة موظف"}
        </button>
      </form>
    </div>
  );
}
