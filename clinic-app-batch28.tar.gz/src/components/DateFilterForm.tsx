"use client";

// فورم فلتر التاريخ ("اليوم: ...") المستخدم في أعلى صفحات الجدول/الفواتير/المواعيد.
// بيبعت (submit) نفسه تلقائيًا بمجرد اختيار تاريخ من الكاليندر — من غير ما يحتاج
// المستخدم يدوس زرار "عرض" بعدها. الزرار فاضل موجود برضه كحماية إضافية (لو ال
// onChange لأي سبب ما اتفعّلش، أو لكتابة تاريخ يدويًا بدل الكاليندر).
//
// دفعة 28: كان `<form>` HTML عادي — أي submit (تغيير تاريخ) كان بيعمل إعادة
// تحميل كاملة للصفحة (hard navigation)، مش انتقال سلس. المستخدم بلغ إن التنقل
// بين الشهور/الأيام "مش smooth". الحل: `<Form>` من next/form بدل الـ<form>
// العادي — بيعمل نفس الحاجة بالظبط (GET بيحول قيم الفورم لـquery params) لكن
// عن طريق client-side navigation (زي next/link) بدل تحميل كامل جديد للصفحة.
import Form from "next/form";

export default function DateFilterForm({ day }: { day: string }) {
  return (
    <Form action="/front-desk" className="flex items-center gap-2 flex-wrap">
      <label className="text-sm text-muted">اليوم:</label>
      <input
        type="date"
        name="date"
        defaultValue={day}
        onChange={(e) => e.currentTarget.form?.requestSubmit()}
        className="rounded-md border border-border bg-surface px-2 py-1.5 text-sm"
      />
      <button type="submit" className="px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft">
        عرض
      </button>
    </Form>
  );
}
