"use client";

import { useState, useTransition } from "react";
import { updatePatientInfoAction } from "@/app/patients/[id]/actions";
import BirthDateInput from "@/components/BirthDateInput";

// تعديل بيانات المريض الأساسية من ملفه (دفعة 22) — بيبان زرار "تعديل البيانات"
// جنب اسم المريض، ودوسته بتفتح فورم صغير مكان عرض البيانات بدل ما يفتح صفحة
// أو مودال منفصل. محصور بصلاحية edit_patient_info (الأدمن والاستقبال افتراضيًا
// — الصفحة اللي بتستخدم المكون ده أصلاً بتتأكد من الصلاحية قبل ما تعرضه،
// والتحقق الحقيقي في الأكشن نفسه على السيرفر).
export default function EditPatientForm({
  patientId,
  fullName,
  birthDate,
  phone,
  address,
}: {
  patientId: number;
  fullName: string;
  birthDate: string | null;
  phone: string | null;
  address: string | null;
}) {
  const [editing, setEditing] = useState(false);
  const [isPending, startTransition] = useTransition();

  if (!editing) {
    return (
      <button
        type="button"
        onClick={() => setEditing(true)}
        className="text-xs text-primary hover:underline"
      >
        تعديل البيانات
      </button>
    );
  }

  return (
    <form
      action={(fd) => {
        startTransition(() => {
          updatePatientInfoAction(fd);
        });
        setEditing(false);
      }}
      className="card-3d rounded-xl p-4 space-y-3 max-w-md"
    >
      <input type="hidden" name="patient_id" value={patientId} />
      <div>
        <label className="block text-xs text-muted mb-1">الاسم *</label>
        <input
          name="full_name"
          required
          defaultValue={fullName}
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
        />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-xs text-muted mb-1">تاريخ الميلاد</label>
          <BirthDateInput name="birth_date" defaultValue={birthDate} />
        </div>
        <div>
          <label className="block text-xs text-muted mb-1">رقم التليفون</label>
          <input
            name="phone"
            defaultValue={phone ?? ""}
            className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
          />
        </div>
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">العنوان</label>
        <input
          name="address"
          defaultValue={address ?? ""}
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
        />
      </div>
      <div className="flex items-center gap-2">
        <button
          type="submit"
          disabled={isPending}
          className="rounded-md btn-3d-primary px-3 py-1.5 text-xs font-medium disabled:opacity-60"
        >
          {isPending ? "جاري الحفظ..." : "حفظ"}
        </button>
        <button
          type="button"
          onClick={() => setEditing(false)}
          className="text-xs px-3 py-1.5 rounded-md border border-border hover:bg-danger-soft"
        >
          إلغاء
        </button>
      </div>
    </form>
  );
}
