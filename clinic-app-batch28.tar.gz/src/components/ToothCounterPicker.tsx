"use client";

import type { Tooth } from "@/lib/dental-chart";

// صف أسنان لشارت الريبوندينج — كل دوسة على سن بتسجل عملية ريبوندينج جديدة
// عليه (بترفع الرقم الصغير فوقه)، والسن اللي براكته مكسورة دلوقتي (لسه
// ماترّكبتش) بيبان بلون أحمر لحد ما يتسجل ريبوندينج عليه.
export default function ToothCounterPicker({
  teeth,
  counts,
  broken,
  onTap,
  disabled,
}: {
  teeth: Tooth[];
  counts: Record<string, number>;
  broken: string[];
  onTap: (id: string) => void;
  disabled?: boolean;
}) {
  const midline = teeth.length / 2;
  return (
    <div className="flex items-center gap-1.5 flex-wrap" dir="ltr">
      {teeth.map((tooth, i) => {
        const isBroken = broken.includes(tooth.id);
        const count = counts[tooth.id] ?? 0;
        return (
          <div key={tooth.id} className="flex items-center gap-1.5">
            {i === midline && <span className="w-px h-6 bg-border mx-0.5" aria-hidden />}
            <button
              type="button"
              disabled={disabled}
              onClick={() => onTap(tooth.id)}
              title={`${tooth.id}${count ? ` — اتعمل ${count} مرة` : ""}`}
              className={`relative w-7 h-7 rounded-md border text-xs font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
                isBroken ? "bg-danger text-white border-danger" : "bg-background border-border hover:bg-primary-soft"
              }`}
            >
              {tooth.label}
              {count > 0 && (
                <span className="absolute -top-1.5 -right-1.5 min-w-[14px] h-[14px] px-0.5 rounded-full bg-primary text-white text-[9px] leading-[14px] text-center">
                  {count}
                </span>
              )}
            </button>
          </div>
        );
      })}
    </div>
  );
}
