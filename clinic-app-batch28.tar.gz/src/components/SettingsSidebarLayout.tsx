"use client";

import { useState, type ReactNode } from "react";

export type SettingsSection = {
  key: string;
  label: string;
  content: ReactNode;
};

// قائمة جانبية لصفحة الإعدادات (دفعة 22) — بدل ما كل الأقسام تبقى تحت بعض في
// صفحة طويلة، بقى فيه قائمة جانبية بيختار منها القسم (الملف الشخصي/العيادات/
// الخدمات/المستخدمين/الصلاحيات) ويظهر محتواه بس. المحتوى نفسه بيتجهز في
// page.tsx (سيرفر) وبيتبعت هنا كـ ReactNode جاهز — المكون ده بس بيدير التبديل
// بين الأقسام (client-side)، من غير ما يأثر على أي queries أو منطق سيرفر.
export default function SettingsSidebarLayout({
  sections,
  initialKey,
}: {
  sections: SettingsSection[];
  initialKey?: string;
}) {
  const [activeKey, setActiveKey] = useState(initialKey && sections.some((s) => s.key === initialKey) ? initialKey : sections[0]?.key);

  const active = sections.find((s) => s.key === activeKey) ?? sections[0];

  return (
    <div className="flex flex-col sm:flex-row gap-5 items-start">
      <nav className="w-full sm:w-48 shrink-0 card-3d rounded-xl p-2 flex sm:flex-col gap-1 overflow-x-auto sm:overflow-visible">
        {sections.map((s) => (
          <button
            key={s.key}
            type="button"
            onClick={() => setActiveKey(s.key)}
            className={`text-right px-3 py-2 rounded-md text-sm whitespace-nowrap sm:whitespace-normal transition-colors ${
              activeKey === s.key ? "bg-primary text-white font-medium" : "hover:bg-primary-soft"
            }`}
          >
            {s.label}
          </button>
        ))}
      </nav>
      <div className="flex-1 min-w-0 w-full space-y-6">{active?.content}</div>
    </div>
  );
}
