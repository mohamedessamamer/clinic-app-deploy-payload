"use client";

import type { Tooth } from "@/lib/dental-chart";

// صف أسنان قابل للدوس — بيتستخدم لـ"الأسنان الناقصة" وخريطة الخلع في شارت
// التقويم. خط عمودي في النص بيمثل خط منتصف الفك (نص المصفوفة دايمًا نص العدد
// بالظبط لأن كل صف بيتبني من نص يمين + نص شمال بنفس الطول، شوف dental-chart.ts).
export default function ToothPicker({
  teeth,
  selected,
  onToggle,
  disabled,
}: {
  teeth: Tooth[];
  selected: string[];
  onToggle: (id: string) => void;
  disabled?: boolean;
}) {
  const midline = teeth.length / 2;
  return (
    <div className="flex items-center gap-1 flex-wrap" dir="ltr">
      {teeth.map((tooth, i) => {
        const isSelected = selected.includes(tooth.id);
        return (
          <div key={tooth.id} className="flex items-center gap-1">
            {i === midline && <span className="w-px h-6 bg-border mx-0.5" aria-hidden />}
            <button
              type="button"
              disabled={disabled}
              onClick={() => onToggle(tooth.id)}
              title={tooth.id}
              className={`w-7 h-7 rounded-md border text-xs font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
                isSelected
                  ? "bg-danger text-white border-danger"
                  : "bg-background border-border hover:bg-primary-soft"
              }`}
            >
              {tooth.label}
            </button>
          </div>
        );
      })}
    </div>
  );
}
