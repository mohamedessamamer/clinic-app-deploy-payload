"use client";

// شفت استثنائي — دفعة 27: تسهيل ليوم بعينه (زي "دكتور جاي في يوم غير يومه") من
// غير ما تلمس الشيفت الأسبوعي المتكرر. زرار بجنب اختيار التاريخ في الاستقبال،
// بيفتح بوكس صغير لتحديد الغرفة والدكتور لليوم المعروض حاليًا. الأثر الوحيد:
// الدكتور ده بيبقى المقترح افتراضيًا لحجوزات جديدة في نفس الغرفة/اليوم —
// إضافي مش بديل، وقابل للتغيير يدويًا لكل حجز على حدة زي أي حجز عادي.

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { setExceptionalShiftAction, clearExceptionalShiftAction } from "@/app/appointments/actions";

interface RoomOption {
  id: number;
  name: string;
}
interface DoctorOption {
  id: number;
  full_name: string;
}

export default function ExceptionalShiftButton({
  date,
  rooms,
  doctors,
  existing,
}: {
  date: string;
  rooms: RoomOption[];
  doctors: DoctorOption[];
  existing: Record<number, { doctorId: number; doctorName: string }>;
}) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [isPending, startTransition] = useTransition();
  const [roomId, setRoomId] = useState<string>(rooms[0]?.id ? String(rooms[0].id) : "");
  const [doctorId, setDoctorId] = useState<string>("");

  function save() {
    if (!roomId || !doctorId) return;
    const formData = new FormData();
    formData.set("room_id", roomId);
    formData.set("doctor_id", doctorId);
    formData.set("shift_date", date);
    startTransition(async () => {
      const res = await setExceptionalShiftAction(formData);
      if (!res.ok) {
        window.alert(res.reason || "حصل خطأ، حاول تاني.");
        return;
      }
      setDoctorId("");
      router.refresh();
    });
  }

  function clear(rId: number) {
    const formData = new FormData();
    formData.set("room_id", String(rId));
    formData.set("shift_date", date);
    startTransition(async () => {
      await clearExceptionalShiftAction(formData);
      router.refresh();
    });
  }

  const existingEntries = Object.entries(existing);

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className={`px-3 py-1.5 rounded-md border text-sm ${
          existingEntries.length > 0 ? "border-primary text-primary bg-primary-soft" : "border-border hover:bg-primary-soft"
        }`}
      >
        شفت استثنائي{existingEntries.length > 0 ? ` (${existingEntries.length})` : ""}
      </button>

      {open && (
        <div className="absolute z-30 mt-1 w-80 card-3d rounded-lg p-3 space-y-3 text-sm" onClick={(e) => e.stopPropagation()}>
          <div className="font-semibold">شفت استثنائي — {date}</div>
          <p className="text-xs text-muted">
            تعيين دكتور مختلف كصاحب شيفت الغرفة دي اليوم ده بس (مايأثرش على الشيفت الأسبوعي العادي) — بيبقى هو المقترح
            تلقائيًا لأي حجز جديد في الغرفة دي، وممكن تغيّره لأي مريض بعينه وقت الحجز عادي.
          </p>

          {existingEntries.length > 0 && (
            <div className="space-y-1 border-t border-border pt-2">
              {existingEntries.map(([rId, info]) => {
                const room = rooms.find((r) => r.id === Number(rId));
                return (
                  <div key={rId} className="flex items-center justify-between gap-2">
                    <span>
                      {room?.name ?? `غرفة ${rId}`}: <strong>{info.doctorName}</strong>
                    </span>
                    <button type="button" onClick={() => clear(Number(rId))} className="text-xs text-danger hover:underline" disabled={isPending}>
                      إلغاء
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          <div className="flex flex-col gap-2 border-t border-border pt-2">
            <select value={roomId} onChange={(e) => setRoomId(e.target.value)} className="rounded-md border border-border bg-background px-2 py-1.5 text-sm">
              {rooms.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name}
                </option>
              ))}
            </select>
            <select value={doctorId} onChange={(e) => setDoctorId(e.target.value)} className="rounded-md border border-border bg-background px-2 py-1.5 text-sm">
              <option value="">اختر الدكتور</option>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.full_name}
                </option>
              ))}
            </select>
            <div className="flex items-center gap-2">
              <button type="button" onClick={save} disabled={isPending || !doctorId} className="px-3 py-1.5 rounded-md text-xs font-medium btn-3d-primary disabled:opacity-60">
                حفظ
              </button>
              <button type="button" onClick={() => setOpen(false)} className="px-3 py-1.5 rounded-md text-xs border border-border">
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
