"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { updatePaymentAction } from "@/app/invoices/actions";
import { PAYMENT_METHODS, paymentMethodLabel } from "@/lib/payment-methods";
import DeleteInvoiceButton from "./DeleteInvoiceButton";

export type InvoiceRowData = {
  id: number;
  visit_id: number;
  patient_id: number;
  patient_name: string;
  service_name: string | null;
  doctor_name: string | null;
  amount: number;
  paid: number;
  discount_percent: number;
  price_overridden: number;
  payment_method: string | null;
  isFollowup: boolean;
  followupOfServiceName?: string | null;
  remaining: number | string; // number أو "-" لو دفعة متابعة من غير رصيد محسوب
};

// صف فاتورة واحد في /invoices — التعديل (لمين معاه صلاحية edit_invoice_payments
// بس) بقى بالدوس على رقم "السعر" أو "المدفوع" نفسه بدل خانة "تعديل" منفصلة على
// الجنب — نفس فكرة "دوسة على الرقم" اللي طلبها المستخدم، بيحوّل الصف كله لوضع
// تعديل مؤقت بدل ما يفتح فورم منفصل يشغل مساحة زيادة في الجدول.
export default function InvoiceRow({ inv, canEdit, canDelete }: { inv: InvoiceRowData; canEdit: boolean; canDelete: boolean }) {
  const [editing, setEditing] = useState(false);
  const [amount, setAmount] = useState(String(inv.amount));
  const [paid, setPaid] = useState(String(inv.paid));
  const [paymentMethod, setPaymentMethod] = useState(inv.payment_method ?? "");
  const [isPending, startTransition] = useTransition();

  function startEdit() {
    if (!canEdit) return;
    setAmount(String(inv.amount));
    setPaid(String(inv.paid));
    setPaymentMethod(inv.payment_method ?? "");
    setEditing(true);
  }

  function save() {
    const fd = new FormData();
    fd.set("id", String(inv.id));
    fd.set("amount", inv.isFollowup ? "0" : amount);
    fd.set("paid", paid);
    fd.set("payment_method", paymentMethod);
    startTransition(() => {
      updatePaymentAction(fd);
    });
    setEditing(false);
  }

  const priceDisplay = inv.isFollowup ? (
    <span className="text-muted">-</span>
  ) : (
    <>
      {inv.amount.toFixed(0)}
      {inv.discount_percent > 0 && !inv.price_overridden ? (
        <span className="text-xs text-muted"> (خصم {inv.discount_percent}%)</span>
      ) : null}
    </>
  );

  return (
    <tr className={`border-t border-border ${isPending ? "opacity-60" : ""}`}>
      <td className="px-3 py-2 font-medium">
        <Link href={`/patients/${inv.patient_id}/billing`} className="hover:text-primary hover:underline">
          {inv.patient_name}
        </Link>
      </td>
      <td className="px-3 py-2">
        {inv.isFollowup ? (
          <>
            <span className="text-muted">↳ دفعة متابعة</span> <span>({inv.followupOfServiceName ?? "-"})</span>
          </>
        ) : (
          inv.service_name ?? "-"
        )}
      </td>
      <td className={`px-3 py-2 ${canEdit && !inv.isFollowup ? "cursor-pointer hover:underline" : ""}`} onClick={!inv.isFollowup ? startEdit : undefined} title={canEdit && !inv.isFollowup ? "دوس للتعديل" : undefined}>
        {editing && !inv.isFollowup ? (
          <input
            type="number"
            step="0.01"
            autoFocus
            value={amount}
            onClick={(e) => e.stopPropagation()}
            onChange={(e) => setAmount(e.target.value)}
            className="w-20 rounded-md border border-border bg-background px-2 py-1 text-xs"
          />
        ) : (
          priceDisplay
        )}
      </td>
      <td className={`px-3 py-2 ${canEdit ? "cursor-pointer hover:underline" : ""}`} onClick={startEdit} title={canEdit ? "دوس للتعديل" : undefined}>
        {editing ? (
          <input
            type="number"
            step="0.01"
            value={paid}
            onClick={(e) => e.stopPropagation()}
            onChange={(e) => setPaid(e.target.value)}
            className="w-20 rounded-md border border-border bg-background px-2 py-1 text-xs"
          />
        ) : (
          inv.paid.toFixed(0)
        )}
      </td>
      <td className="px-3 py-2 text-danger">{typeof inv.remaining === "number" ? inv.remaining.toFixed(0) : inv.remaining}</td>
      <td className="px-3 py-2">
        {editing ? (
          <select
            value={paymentMethod}
            onClick={(e) => e.stopPropagation()}
            onChange={(e) => setPaymentMethod(e.target.value)}
            className="rounded-md border border-border bg-background px-1.5 py-1 text-xs"
          >
            <option value="">-</option>
            {PAYMENT_METHODS.map((m) => (
              <option key={m.value} value={m.value}>
                {m.label}
              </option>
            ))}
          </select>
        ) : (
          paymentMethodLabel(inv.payment_method)
        )}
      </td>
      <td className="px-3 py-2">
        {editing ? (
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={save}
              className="text-xs px-2 py-1 rounded-md btn-3d-primary"
            >
              حفظ
            </button>
            <button
              type="button"
              onClick={() => setEditing(false)}
              className="text-xs px-2 py-1 rounded-md border border-border hover:bg-danger-soft"
            >
              إلغاء
            </button>
          </div>
        ) : (
          <div className="flex items-center justify-between gap-2">
            <span>{inv.doctor_name ?? "-"}</span>
            {canDelete && (
              <DeleteInvoiceButton
                visitId={inv.visit_id}
                patientId={inv.patient_id}
                confirmLabel={inv.isFollowup ? `دفعة متابعة — ${inv.patient_name}` : `${inv.service_name ?? "خدمة"} — ${inv.patient_name}`}
              />
            )}
          </div>
        )}
      </td>
    </tr>
  );
}
