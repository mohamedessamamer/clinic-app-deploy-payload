"use client";

// شارت التقويم v2 — "Diagnostic chart" (النسخة الحقيقية، دمج 2026-08-27).
// نفس شبكة الحقول اللي كانت في البروتوتايب المعزول بالظبط، لكن دلوقتي فورم
// حقيقي (defaultValue من قاعدة البيانات) بزرار Save واحد تحت — بيبعت بس
// أعمدة الـDiagnostic (saveOrthoDiagnosticAction، تحديث جزئي، شوف تعليقها في
// ortho-v2-actions.ts ليه منفصلة عن حفظ أعلى الصفحة).

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { saveOrthoDiagnosticAction } from "@/app/patients/[id]/orthodontics/ortho-v2-actions";

function Select({
  name,
  defaultValue,
  options,
  disabled,
}: {
  name: string;
  defaultValue: string | null;
  options: { value: string; label: string }[];
  disabled?: boolean;
}) {
  return (
    <select
      name={name}
      defaultValue={defaultValue ?? ""}
      disabled={disabled}
      className="rounded-md border border-border bg-background px-1.5 py-1 text-xs max-w-[110px] disabled:opacity-60"
    >
      <option value="">—</option>
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}

function MmInput({ name, defaultValue, disabled }: { name: string; defaultValue: number | null; disabled?: boolean }) {
  return (
    <span className="flex items-center gap-1 text-[10px] text-muted">
      <input
        type="number"
        name={name}
        defaultValue={defaultValue ?? ""}
        disabled={disabled}
        className="w-10 rounded-md border border-border bg-background px-1 py-1 text-xs disabled:opacity-60"
      />
      mm
    </span>
  );
}

const CLASS_OPTIONS = [
  { value: "class1", label: "Class I" },
  { value: "class2", label: "Class II" },
  { value: "class3", label: "Class III" },
];
const INCLINATION_OPTIONS = [
  { value: "proclined", label: "Proclined" },
  { value: "average", label: "Average" },
  { value: "retroclined", label: "Retroclined" },
];
const DIRECTION_OPTIONS = [
  { value: "right", label: "To Right" },
  { value: "left", label: "To Left" },
];
const SPACE_OPTIONS = [
  { value: "crowding", label: "Crowding" },
  { value: "spacing", label: "Spacing" },
];

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-2 py-1">
      <span className="text-xs text-muted whitespace-nowrap">{label}</span>
      <div className="flex items-center gap-1.5">{children}</div>
    </div>
  );
}

export interface DiagnosticChartData {
  antero_posterior: string | null;
  facial_height: string | null;
  mx_incisor_inclination: string | null;
  mn_incisor_inclination: string | null;
  molar_relation_right: string | null;
  molar_relation_left: string | null;
  overbite: string | null;
  overjet: string | null;
  midline_upper_direction: string | null;
  midline_upper_mm: number | null;
  midline_lower_direction: string | null;
  midline_lower_mm: number | null;
  space_upper_type: string | null;
  space_upper_mm: number | null;
  space_lower_type: string | null;
  space_lower_mm: number | null;
  nasolabial_angle: string | null;
  lips: string | null;
}

export default function DiagnosticChart({ patientId, editable, data }: { patientId: number; editable: boolean; data: DiagnosticChartData }) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();

  function handleSubmit(formData: FormData) {
    startTransition(async () => {
      const res = await saveOrthoDiagnosticAction(formData);
      if (!res.ok) window.alert(res.reason || "حصل خطأ، حاول تاني.");
      router.refresh();
    });
  }

  return (
    <form action={handleSubmit} className={`space-y-3 ${isPending ? "opacity-70 pointer-events-none" : ""}`}>
      <input type="hidden" name="patient_id" value={patientId} />
      <div className="grid grid-cols-2 gap-x-4 text-sm">
        <Row label="Skeletal">
          <Select name="antero_posterior" defaultValue={data.antero_posterior} options={CLASS_OPTIONS} disabled={!editable} />
        </Row>
        <Row label="Facial Height">
          <Select
            name="facial_height"
            defaultValue={data.facial_height}
            options={[
              { value: "increased", label: "Increased" },
              { value: "average", label: "Average" },
              { value: "decreased", label: "Decreased" },
            ]}
            disabled={!editable}
          />
        </Row>

        <Row label="Mx incisors">
          <Select name="mx_incisor_inclination" defaultValue={data.mx_incisor_inclination} options={INCLINATION_OPTIONS} disabled={!editable} />
        </Row>
        <Row label="Mn incisors">
          <Select name="mn_incisor_inclination" defaultValue={data.mn_incisor_inclination} options={INCLINATION_OPTIONS} disabled={!editable} />
        </Row>

        <Row label="Molars: Right">
          <Select name="molar_relation_right" defaultValue={data.molar_relation_right} options={CLASS_OPTIONS} disabled={!editable} />
        </Row>
        <Row label="Left">
          <Select name="molar_relation_left" defaultValue={data.molar_relation_left} options={CLASS_OPTIONS} disabled={!editable} />
        </Row>

        <Row label="Overbite">
          <Select
            name="overbite"
            defaultValue={data.overbite}
            options={[
              { value: "open_bite", label: "Open Bite" },
              { value: "average", label: "Average" },
              { value: "deep_bite", label: "Deep Bite" },
            ]}
            disabled={!editable}
          />
        </Row>
        <Row label="Overjet">
          <Select
            name="overjet"
            defaultValue={data.overjet}
            options={[
              { value: "increased", label: "Increased" },
              { value: "average", label: "Average" },
              { value: "decreased", label: "Decreased" },
            ]}
            disabled={!editable}
          />
        </Row>

        <Row label="Midline: Upper">
          <Select name="midline_upper_direction" defaultValue={data.midline_upper_direction} options={DIRECTION_OPTIONS} disabled={!editable} />
          <MmInput name="midline_upper_mm" defaultValue={data.midline_upper_mm} disabled={!editable} />
        </Row>
        <Row label="Lower">
          <Select name="midline_lower_direction" defaultValue={data.midline_lower_direction} options={DIRECTION_OPTIONS} disabled={!editable} />
          <MmInput name="midline_lower_mm" defaultValue={data.midline_lower_mm} disabled={!editable} />
        </Row>

        <Row label="Space: Upper">
          <Select name="space_upper_type" defaultValue={data.space_upper_type} options={SPACE_OPTIONS} disabled={!editable} />
          <MmInput name="space_upper_mm" defaultValue={data.space_upper_mm} disabled={!editable} />
        </Row>
        <Row label="Lower">
          <Select name="space_lower_type" defaultValue={data.space_lower_type} options={SPACE_OPTIONS} disabled={!editable} />
          <MmInput name="space_lower_mm" defaultValue={data.space_lower_mm} disabled={!editable} />
        </Row>

        <Row label="Facial: Nasolabial">
          <Select
            name="nasolabial_angle"
            defaultValue={data.nasolabial_angle}
            options={[
              { value: "acute", label: "Acute" },
              { value: "average", label: "Average" },
              { value: "obtuse", label: "Obtuse" },
            ]}
            disabled={!editable}
          />
        </Row>
        <Row label="Lips">
          <Select
            name="lips"
            defaultValue={data.lips}
            options={[
              { value: "competent", label: "Competent" },
              { value: "incompetent", label: "Incompetent" },
            ]}
            disabled={!editable}
          />
        </Row>
      </div>
      {editable && (
        <button type="submit" className="px-3 py-1.5 rounded-md text-xs font-medium btn-3d-primary">
          Save
        </button>
      )}
    </form>
  );
}
