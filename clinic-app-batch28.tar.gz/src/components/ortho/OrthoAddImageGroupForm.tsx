"use client";

// Upload widget for the v2 chart's Photos & X-rays section — same real
// addImageGroupAction as the patient file's AddImageGroupForm (real storage,
// real patient_image_groups/patient_images rows), styled to match the "+" tile
// from the v2 design, always English/LTR.
//
// Two-step staged flow (2026-08-27 review round), matching how the original
// system's AddImageGroupForm already behaves: picking files does NOT upload
// them immediately — they sit staged here as thumbnails first (with a second
// "+" tile next to them to add more, and an "x" to drop one before sending),
// and only the explicit "Upload" button actually calls the server action.
// Each staged image is also downscaled/re-encoded client-side first (see
// compressImageFile) so the upload is smaller without a visible quality hit.

import { useEffect, useMemo, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { addImageGroupAction } from "@/app/patients/[id]/actions";
import { compressImageFile } from "@/lib/image-compress";
import { getClinicToday } from "@/lib/clinic-date";

type StagedFile = { id: string; file: File; previewUrl: string | null };

export default function OrthoAddImageGroupForm({ patientId }: { patientId: number }) {
  const router = useRouter();
  const [, startTransition] = useTransition();
  const today = useMemo(() => getClinicToday(), []);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const [date, setDate] = useState(today);
  const [description, setDescription] = useState("");
  const [staged, setStaged] = useState<StagedFile[]>([]);
  const [compressing, setCompressing] = useState(false);
  const [uploading, setUploading] = useState(false);

  // بيمسح الـ object URLs لما الكومبوننت يتشال أو الملف يتشال من القايمة —
  // عشان منسربش memory (كل صورة معاينة بتاخد blob URL منفصل).
  useEffect(() => {
    return () => {
      staged.forEach((s) => s.previewUrl && URL.revokeObjectURL(s.previewUrl));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function stageFiles(files: FileList | File[] | null) {
    if (!files || files.length === 0) return;
    setCompressing(true);
    const list = Array.from(files);
    const compressed = await Promise.all(
      list.map(async (file) => {
        const finalFile = await compressImageFile(file);
        const previewUrl = finalFile.type.startsWith("image/") ? URL.createObjectURL(finalFile) : null;
        const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
        return { id, file: finalFile, previewUrl } as StagedFile;
      })
    );
    setStaged((prev) => [...prev, ...compressed]);
    setCompressing(false);
  }

  function removeStaged(id: string) {
    setStaged((prev) => {
      const target = prev.find((s) => s.id === id);
      if (target?.previewUrl) URL.revokeObjectURL(target.previewUrl);
      return prev.filter((s) => s.id !== id);
    });
  }

  function upload() {
    if (staged.length === 0 || uploading) return;
    const formData = new FormData();
    formData.set("patient_id", String(patientId));
    formData.set("taken_at", date);
    formData.set("label", description);
    for (const s of staged) formData.append("files", s.file, s.file.name);
    setUploading(true);
    startTransition(async () => {
      await addImageGroupAction(formData);
      router.refresh();
      staged.forEach((s) => s.previewUrl && URL.revokeObjectURL(s.previewUrl));
      setStaged([]);
      setDescription("");
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    });
  }

  const busy = compressing || uploading;

  return (
    <div dir="ltr" className="space-y-2">
      <div className="flex gap-2 flex-wrap items-start">
        {staged.map((s) => (
          <div key={s.id} className="relative w-20 h-20 rounded-md overflow-hidden border border-border bg-background group">
            {s.previewUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={s.previewUrl} alt={s.file.name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-[10px] text-muted p-1 text-center">{s.file.name}</div>
            )}
            <button
              type="button"
              onClick={() => removeStaged(s.id)}
              className="absolute top-0.5 right-0.5 w-5 h-5 rounded-full bg-black/60 hover:bg-red-600 text-white text-xs leading-none flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
              title="Remove"
              aria-label="Remove"
            >
              ×
            </button>
          </div>
        ))}

        <label
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            stageFiles(e.dataTransfer.files);
          }}
          className={`w-20 h-20 rounded-md border-2 border-dashed flex items-center justify-center cursor-pointer text-2xl text-muted transition-colors ${
            dragOver ? "border-primary bg-primary-soft" : "border-border hover:bg-primary-soft"
          } ${busy ? "opacity-60 pointer-events-none" : ""}`}
          title="Add photos"
        >
          {compressing ? "…" : "+"}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*,.pdf"
            multiple
            className="hidden"
            onChange={(e) => {
              stageFiles(e.target.files);
              e.target.value = "";
            }}
          />
        </label>
      </div>

      <div className="flex gap-3 flex-wrap items-end max-w-md">
        <div>
          <div className="text-[11px] text-muted mb-1">Date</div>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="rounded-md border border-border bg-background px-2 py-1 text-xs"
          />
        </div>
        <div className="flex-1 min-w-[160px]">
          <div className="text-[11px] text-muted mb-1">Description (Optional)</div>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Eg.: Panorama"
            className="w-full rounded-md border border-border bg-background px-2 py-1 text-xs"
          />
        </div>
        {staged.length > 0 && (
          <button
            type="button"
            onClick={upload}
            disabled={busy}
            className="rounded-md btn-3d-primary px-3 py-1.5 text-xs font-medium disabled:opacity-60"
          >
            {uploading ? "Uploading…" : `Upload (${staged.length})`}
          </button>
        )}
      </div>
    </div>
  );
}
