"use client";

import { PAYMENT_METHODS } from "@/lib/payment-methods";

type Doctor = { id: number; full_name: string };

// فلاتر صفحة الفواتير: التاريخ (كان موجود، DateFilterForm سابقًا) + دكتور +
// طريقة دفع — الفورم بيبعت نفسه تلقائيًا (submit) عند تغيير أي فلتر، من غير
// حاجة لزرار "عرض" منفصل لكل واحد.
export default function InvoicesFilterForm({
  day,
  doctors,
  doctorId,
  paymentMethod,
}: {
  day: string;
  doctors: Doctor[];
  doctorId: string;
  paymentMethod: string;
}) {
  return (
    <form className="flex items-center gap-2 flex-wrap">
      <label className="text-sm text-muted">اليوم:</label>
      <input
        type="date"
        name="date"
        defaultValue={day}
        onChange={(e) => e.currentTarget.form?.requestSubmit()}
        className="rounded-md border border-border bg-surface px-2 py-1.5 text-sm"
      />
      <select
        name="doctor_id"
        defaultValue={doctorId}
        onChange={(e) => e.currentTarget.form?.requestSubmit()}
        className="rounded-md border border-border bg-surface px-2 py-1.5 text-sm"
      >
        <option value="">كل الدكاترة</option>
        {doctors.map((d) => (
          <option key={d.id} value={d.id}>
            {d.full_name}
          </option>
        ))}
      </select>
      <select
        name="payment_method"
        defaultValue={paymentMethod}
        onChange={(e) => e.currentTarget.form?.requestSubmit()}
        className="rounded-md border border-border bg-surface px-2 py-1.5 text-sm"
      >
        <option value="">كل وسائل الدفع</option>
        {PAYMENT_METHODS.map((m) => (
          <option key={m.value} value={m.value}>
            {m.label}
          </option>
        ))}
      </select>
      <button type="submit" className="px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft">
        عرض
      </button>
    </form>
  );
}
