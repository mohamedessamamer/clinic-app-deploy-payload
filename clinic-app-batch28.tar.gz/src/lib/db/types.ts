import type { ColumnType, Generated } from "kysely";

export interface DoctorsTable {
  id: Generated<number>;
  full_name: string;
  active: Generated<number>;
  // دفعة 22: هل الدكتور ده "استشاري" (عنده دكاترة مساعدين معرفين تحته، جدول
  // consultant_assistants تحت) — 0/1.
  is_consultant: Generated<number>;
  created_at: Generated<string>;
}

// ربط استشاري بدكاترة مساعدين (many-to-many، دفعة 22) — استشاري واحد ممكن
// يكون عنده أكتر من مساعد، ومساعد نظريًا ممكن يشتغل تحت أكتر من استشاري.
export interface ConsultantAssistantsTable {
  consultant_doctor_id: number;
  assistant_doctor_id: number;
}

export interface UsersTable {
  id: Generated<number>;
  username: string;
  password_hash: string;
  full_name: string;
  role: "admin" | "doctor" | "reception" | "accountant" | "clinic_manager";
  doctor_id: number | null;
  active: Generated<number>;
  created_at: Generated<string>;
}

export interface RoomsTable {
  id: Generated<number>;
  name: string;
  created_at: Generated<string>;
}

export interface ShiftsTable {
  id: Generated<number>;
  room_id: number;
  doctor_id: number;
  shift_date: string;
  start_time: string;
  end_time: string;
  created_at: Generated<string>;
}

export interface DoctorWeeklyShiftsTable {
  id: Generated<number>;
  room_id: number;
  weekday: number;
  doctor_id: number;
  start_time: string;
  end_time: string;
  created_at: Generated<string>;
}

export interface DoctorDateShiftsTable {
  id: Generated<number>;
  room_id: number;
  doctor_id: number;
  shift_date: string;
  created_by: number | null;
  created_at: Generated<string>;
}

export interface ServicesTable {
  id: Generated<number>;
  name: string;
  name_en: string | null;
  category: string | null;
  default_price: Generated<number>;
  code: string | null;
  price_note: string | null;
  prepaid: Generated<number>;
  created_at: Generated<string>;
}

export interface ServiceDoctorsTable {
  service_id: number;
  doctor_id: number;
}

export interface PatientsTable {
  id: Generated<number>;
  file_number: string;
  full_name: string;
  age: number | null; // قديم — للمرضى اللي اتسجلوا قبل ما نبدأ نطلب تاريخ الميلاد.
  birth_date: string | null; // YYYY-MM-DD — المصدر الحالي لحساب السن، شوف src/lib/age.ts.
  phone: string | null;
  address: string | null;
  created_at: Generated<string>;
}

export interface AppointmentsTable {
  id: Generated<number>;
  patient_id: number;
  room_id: number;
  doctor_id: number;
  appointment_date: string;
  start_time: string;
  duration_minutes: number | null;
  status: Generated<"booked" | "attended" | "done" | "cancelled" | "no_show">;
  notes: string | null;
  pending_service_id: number | null;
  pending_price: number | null;
  pending_discount_percent: number | null;
  // "المريض جاي يعمل إيه" — دفعة 26. شوف التعليق فوق tryAddColumn في client.ts.
  purpose_type: "bonding_upper" | "bonding_lower" | "service" | null;
  purpose_service_id: number | null;
  // دفعة 27 (P3.2): ربط بفاتورة مفتوحة فعلية — شوف التعليق فوق tryAddColumn.
  purpose_linked_invoice_id: number | null;
  created_at: Generated<string>;
}

export interface VisitsTable {
  id: Generated<number>;
  patient_id: number;
  visit_date: ColumnType<string, string | undefined, string>;
  service_id: number | null;
  notes: string | null;
  primary_doctor_id: number | null;
  performing_doctor_id: number | null;
  room_id: number | null;
  created_by: number | null;
  appointment_id: number | null;
  created_at: Generated<string>;
  notes_synced_from_ortho: Generated<number>;
}

export interface InvoicesTable {
  id: Generated<number>;
  visit_id: number;
  amount: Generated<number>;
  paid: Generated<number>;
  discount_percent: Generated<number>;
  price_overridden: Generated<number>;
  payment_method: string | null;
  parent_invoice_id: number | null;
  original_price: number | null;
  created_at: Generated<string>;
}

export interface ClinicSettingsTable {
  key: string;
  value: string;
}

export interface AuditLogTable {
  id: Generated<number>;
  entity_type: string;
  entity_id: number;
  field: string;
  old_value: string | null;
  new_value: string | null;
  reason: string | null;
  changed_by: number | null;
  changed_at: Generated<string>;
  // تاريخ الحدث الفعلي (زي تاريخ زيارة اتسجلت بأثر رجعي) لو مختلف عن changed_at
  // (وقت الحفظ الفعلي). اختياري — NULL يعني ارجع لـchanged_at.
  event_date: string | null;
}

export interface PatientImageGroupsTable {
  id: Generated<number>;
  patient_id: number;
  label: string | null;
  taken_at: Generated<string>;
  created_at: Generated<string>;
}

export interface PatientImagesTable {
  id: Generated<number>;
  group_id: number;
  file_path: string;
  rotation: Generated<number>;
  created_at: Generated<string>;
}

export interface InventoryItemsTable {
  id: Generated<number>;
  name: string;
  quantity: Generated<number>;
  unit: string | null;
  expiry_date: string | null;
  low_stock_threshold: Generated<number>;
  created_at: Generated<string>;
}

export interface UserPermissionsTable {
  user_id: number;
  permission_key: string;
  granted: number;
}

// شارت تشخيص وخطة علاج التقويم — سجل واحد بس لكل مريض (patient_id UNIQUE).
// شوف التعليق فوق CREATE TABLE في schema.sql للتفاصيل.
export interface OrthodonticChartsTable {
  id: Generated<number>;
  patient_id: number;
  sex: "male" | "female" | null;
  chief_complaint: string | null;
  past_medical_history: string | null;
  missing_teeth: string | null; // JSON array نصي
  antero_posterior: "class1" | "class2" | "class3" | null;
  facial_height: "increased" | "average" | "decreased" | null;
  mx_incisor_inclination: "proclined" | "average" | "retroclined" | null;
  mn_incisor_inclination: "proclined" | "average" | "retroclined" | null;
  molar_relation_right: "class1" | "class2" | "class3" | null;
  molar_relation_left: "class1" | "class2" | "class3" | null;
  overbite: "open_bite" | "average" | "deep_bite" | null;
  overjet: "increased" | "average" | "decreased" | null;
  midline_upper_direction: "right" | "left" | null;
  midline_upper_mm: number | null;
  midline_lower_direction: "right" | "left" | null;
  midline_lower_mm: number | null;
  space_upper_type: "crowding" | "spacing" | null;
  space_upper_mm: number | null;
  space_lower_type: "crowding" | "spacing" | null;
  space_lower_mm: number | null;
  sna_case: number | null;
  snb_case: number | null;
  anb_case: number | null;
  mma_case: number | null;
  u1_pp_case: number | null;
  l1_mp_case: number | null;
  nasolabial_case: number | null;
  nasolabial_angle: "acute" | "average" | "obtuse" | null;
  lips: "competent" | "incompetent" | null;
  extraction_choice: "extraction" | "non_extraction" | null;
  extraction_teeth: string | null; // JSON array نصي
  anchorage: "minimal" | "moderate" | "maximum" | null;
  anchorage_note: string | null;
  hints: string | null;
  // تركيب التقويم (bonding) والريبوندينج — دفعة 25 (تكملة). فك علوي/سفلي كل
  // واحد بيتسجل مرة واحدة بس (الأكشن نفسه بيرفض أي محاولة تانية لو bonding_*_date
  // متسجل بالفعل)، وبيخصم من المخزون وقت التسجيل. الريبوندينج تكراري لأي سن،
  // شوف rebonding_counts/broken_teeth.
  prescription: string | null; // "Roth" / "MBT" / "Andrews" أو نص حر تاني
  bonding_upper_bracket_item_id: number | null;
  bonding_upper_bracket_qty: number | null;
  bonding_upper_tube_item_id: number | null;
  bonding_upper_tube_qty: number | null;
  bonding_upper_date: string | null;
  bonding_upper_not_bonded_teeth: string | null; // JSON array نصي
  bonding_lower_bracket_item_id: number | null;
  bonding_lower_bracket_qty: number | null;
  bonding_lower_tube_item_id: number | null;
  bonding_lower_tube_qty: number | null;
  bonding_lower_date: string | null;
  bonding_lower_not_bonded_teeth: string | null; // JSON array نصي
  // broken_teeth: أسنان براكتها مكسورة/واقعة دلوقتي (لسه ماترّكبتش تاني) — علم
  // حالة، مش سجل تاريخي. بيتصفّر أوتوماتيك للسن لما يتسجل ريبوندينج عليه.
  broken_teeth: string | null; // JSON array نصي
  // rebonding_counts: عدد مرات الريبوندينج التراكمي لكل سن — JSON object نصي
  // {"UR6": 2, "LL4": 1}. بيزيد واحد كل مرة confirmRebondingAction بينفذ.
  rebonding_counts: string | null;
  // tooth_comments: ملاحظة نصية حرة لأي سن — JSON object نصي {"UR6": "..."}.
  // بيتحفظ مع باقي الشارت (زرار الحفظ العادي)، مش أكشن فوري.
  tooth_comments: string | null;
  // شارت التقويم v2 (دمج 2026-08-27) — شوف التعليق في schema.sql/client.ts.
  // tooth_states: JSON object نصي {"16": {"bracket":"bonded","extracted":false,
  // "debondDate":null,"bondedDate":"...","rebondCount":0}, ...} — مصدر الحقيقة
  // لحالة كل سن في الشارت التفاعلي (أدق من bonding_upper/lower_* اللي بتاعة
  // الفك ككل فوق).
  tooth_states: string | null;
  strip_counts: string | null; // JSON object نصي {gapId: عدد}
  miniscrews: string | null; // JSON object نصي {gapId: true}
  // شارت التقويم v2 — حقول أعلى الصفحة الجديدة، شوف التعليق في client.ts.
  bracket_type: string | null;
  slot: string | null;
  extraction_quadrants: string | null; // JSON object نصي {ur,ul,lr,ll}
  anchorage_device: string | null;
  treatment_note: string | null;
  created_by: number | null;
  updated_by: number | null;
  created_at: Generated<string>;
  updated_at: Generated<string>;
}

// شارت التقويم v2 — زيارات الـFollow up (صف واحد لكل زيارة). شوف التعليق في
// schema.sql فوق CREATE TABLE ortho_visits للتفاصيل الكاملة.
export interface OrthoVisitsTable {
  id: Generated<number>;
  patient_id: number;
  visit_date: string;
  service: string | null;
  upper_wire_size: string | null;
  upper_wire_type: string | null;
  lower_wire_size: string | null;
  lower_wire_type: string | null;
  note: string | null;
  elastics_dispensed: Generated<number>;
  elastics_size: string | null;
  otie_color: string | null;
  power_chain_qty: number | null;
  buttons_qty: number | null;
  compressed_coil_mm: number | null;
  doctor_id: number | null;
  bonding_applied: Generated<number>;
  created_by: number | null;
  updated_by: number | null;
  created_at: Generated<string>;
  updated_at: Generated<string>;
}

// شارت التقويم v2 — سجل خصومات المخزون القابل للـUndo. شوف التعليق في
// schema.sql فوق CREATE TABLE ortho_inventory_deductions.
export interface OrthoInventoryDeductionsTable {
  id: Generated<number>;
  patient_id: number;
  visit_id: number | null;
  item_id: number | null;
  label: string;
  qty: number;
  teeth: string | null; // JSON array نصي لأرقام FDI (خصومات التيوبز المجمّعة)
  deduction_date: string;
  created_by: number | null;
  created_at: Generated<string>;
  undone_by: number | null;
  undone_at: string | null;
}

// شارت التقويم v2 — قوايم الاختيارات القابلة للتعديل من الإعدادات (مقاسات/أنواع
// الوير، ألوان الـO-tie، مقاسات الإيلاستكس).
export interface OrthoOptionListsTable {
  id: Generated<number>;
  category: "wire_size" | "wire_type" | "otie_color" | "elastic_size" | "anchorage_device";
  value: string;
  sort_order: Generated<number>;
  active: Generated<number>;
  created_at: Generated<string>;
}

export interface Database {
  doctors: DoctorsTable;
  consultant_assistants: ConsultantAssistantsTable;
  users: UsersTable;
  user_permissions: UserPermissionsTable;
  rooms: RoomsTable;
  shifts: ShiftsTable;
  doctor_weekly_shifts: DoctorWeeklyShiftsTable;
  doctor_date_shifts: DoctorDateShiftsTable;
  services: ServicesTable;
  service_doctors: ServiceDoctorsTable;
  patients: PatientsTable;
  appointments: AppointmentsTable;
  visits: VisitsTable;
  invoices: InvoicesTable;
  patient_image_groups: PatientImageGroupsTable;
  patient_images: PatientImagesTable;
  inventory_items: InventoryItemsTable;
  clinic_settings: ClinicSettingsTable;
  audit_log: AuditLogTable;
  orthodontic_charts: OrthodonticChartsTable;
  ortho_visits: OrthoVisitsTable;
  ortho_inventory_deductions: OrthoInventoryDeductionsTable;
  ortho_option_lists: OrthoOptionListsTable;
}
