// شارت التقويم v2 (بروتوتايب معزول) — نظام ترقيم FDI + ربط كل رقم سن بصورة
// فوتوغرافية حقيقية من ملف الباوربوينت اللي بعته المستخدم (14 صورة أصلية بس،
// الجانب التاني بتاع كل فك بيستخدم نفس الصورة معكوسة أفقيًا — بالظبط زي ما
// المستخدم عامل الأصل في الباوربوينت نفسه، اتأكدنا من كده بفحص ملف الـ.pptx).
//
// الترقيم: 11-18 فوق يمين، 21-28 فوق شمال، 31-38 تحت شمال، 41-48 تحت يمين
// (نفس معيار FDI/ISO 3950 القياسي).

export type Arch = "upper" | "lower";
export type Side = "right" | "left";

export interface ToothMeta {
  fdi: number;
  arch: Arch;
  side: Side;
  position: number; // 1 (قاطعة مركزية) إلى 8 (ضرس العقل)
  image: string; // اسم ملف الصورة تحت /public/ortho-v2/teeth/
  flip: boolean; // الجانب الشمال بيستخدم نفس صورة اليمين معكوسة
}

// خريطة الموضع (1-8) للصورة الأصلية — مستخرجة من ملف الباوربوينت نفسه (شوف
// orthodontic-chart-v2-interactive-chart-spec.md في مشروع العيادة للتفاصيل).
const UPPER_IMAGE_BY_POSITION: Record<number, string> = {
  1: "image3.png",
  2: "image2.png",
  3: "image4.png",
  4: "image6.png",
  5: "image7.png",
  6: "image5.png",
  7: "image1.png",
  8: "image1.png",
};

const LOWER_IMAGE_BY_POSITION: Record<number, string> = {
  1: "image13.png",
  2: "image12.png",
  3: "image14.png",
  4: "image8.png",
  5: "image11.png",
  6: "image10.png",
  7: "image9.png",
  8: "image9.png",
};

function buildTooth(fdi: number): ToothMeta {
  const quadrant = Math.floor(fdi / 10);
  const position = fdi % 10;
  const arch: Arch = quadrant === 1 || quadrant === 2 ? "upper" : "lower";
  const side: Side = quadrant === 1 || quadrant === 4 ? "right" : "left";
  const image = (arch === "upper" ? UPPER_IMAGE_BY_POSITION : LOWER_IMAGE_BY_POSITION)[position];
  return { fdi, arch, side, position, image, flip: side === "left" };
}

// ترتيب العرض القياسي: فوق يمين للشمال، تحت شمال للفوق يمين (نفس اتجاه القراءة
// المعتاد في شارت الأسنان — ضرس العقل بره، القواطع في النص).
export const UPPER_ROW: ToothMeta[] = [18, 17, 16, 15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 26, 27, 28].map(buildTooth);
export const LOWER_ROW: ToothMeta[] = [48, 47, 46, 45, 44, 43, 42, 41, 31, 32, 33, 34, 35, 36, 37, 38].map(buildTooth);

export const ALL_TEETH: ToothMeta[] = [...UPPER_ROW, ...LOWER_ROW];

export function gapsFor(row: ToothMeta[]): { id: string; a: number; b: number }[] {
  const gaps: { id: string; a: number; b: number }[] = [];
  for (let i = 0; i < row.length - 1; i++) {
    gaps.push({ id: `${row[i].fdi}-${row[i + 1].fdi}`, a: row[i].fdi, b: row[i + 1].fdi });
  }
  return gaps;
}
