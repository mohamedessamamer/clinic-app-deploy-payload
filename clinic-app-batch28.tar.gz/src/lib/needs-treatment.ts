import { db } from "@/lib/db/client";

// دفعة 27 (P2.4) — الفصل الكامل بين الملف الطبي والمالي: تنبيه "محتاج إدخال
// معالجة" هو عكس تنبيه "محتاج تحصيل" الحالي (ده للدكتور بدل الاستقبال). موعد
// "تم" لسه الدكتور مدخلش المعالجة الطبية بتاعته (لا في سجل الزيارات بالملف
// الطبي ولا في شارت التقويم) بيظهرله التنبيه ده.
//
// معيار "دخل معالجة" بيختلف حسب نوع المريض بالظبط زي باقي أماكن النظام
// (front-desk/page.tsx و app/page.tsx بيستخدموا نفس الفكرة لـis_ortho_patient):
// - مريض تقويم (عنده شارت تقويم فعلي بالفعل): كفاية إن فيه زيارة متابعة
//   (ortho_visits) اتسجلت لنفس التاريخ.
// - غير كده: لازم تكون فيه زيارة (visits) لنفس المريض/التاريخ وليها "معالجة"
//   (notes) مكتوبة فعليًا — مجرد وجود زيارة بس (من غير notes، زي اللي
//   الاستقبال بيسجلها وقت التحصيل) مايكفيش. المطابقة بـ(patient_id + visit_date)
//   مش بـappointment_id عمدًا: زيارة مسجلة من الدكتور مباشرة عن طريق "+ إضافة
//   زيارة" في الملف الطبي (addVisitAction) مالهاش appointment_id خالص أصلاً —
//   ده المسار الطبيعي والأكتر شيوعًا اللي الدكتور بيدخل بيه المعالجة.
export async function computeNeedsTreatmentMap(
  appointments: { id: number; patient_id: number; appointment_date: string; status: string }[]
): Promise<Map<number, boolean>> {
  const map = new Map<number, boolean>();
  const doneAppts = appointments.filter((a) => a.status === "done");
  if (doneAppts.length === 0) return map;

  const patientIds = [...new Set(doneAppts.map((a) => a.patient_id))];

  const [orthoPatientRows, generalVisits, orthoVisitRows] = await Promise.all([
    db.selectFrom("orthodontic_charts").select("patient_id").where("patient_id", "in", patientIds).execute(),
    db.selectFrom("visits").select(["patient_id", "visit_date", "notes"]).where("patient_id", "in", patientIds).execute(),
    db.selectFrom("ortho_visits").select(["patient_id", "visit_date"]).where("patient_id", "in", patientIds).execute(),
  ]);

  const orthoPatientIds = new Set(orthoPatientRows.map((r) => r.patient_id));
  const hasNotesKeys = new Set(
    generalVisits.filter((v) => v.notes && v.notes.trim()).map((v) => `${v.patient_id}|${v.visit_date}`)
  );
  const orthoVisitKeys = new Set(orthoVisitRows.map((v) => `${v.patient_id}|${v.visit_date}`));

  for (const a of doneAppts) {
    const key = `${a.patient_id}|${a.appointment_date}`;
    map.set(a.id, orthoPatientIds.has(a.patient_id) ? !orthoVisitKeys.has(key) : !hasNotesKeys.has(key));
  }
  return map;
}
