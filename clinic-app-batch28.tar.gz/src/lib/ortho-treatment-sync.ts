import type { Transaction } from "kysely";
import type { Database } from "@/lib/db/types";

// دفعة 27 (P2.4) — الفصل الكامل بين الملف الطبي والمالي: لو الدكتور دخل
// المعالجة من شارت التقويم (خدمة + مقاسات الأسلاك + الملاحظة الحرة)، تتنسخ
// تلقائيًا لحقل "تفاصيل المعالجة" (notes) في زيارة الملف الطبي المقابلة —
// كباراجراف واحد من غير فواصل، بالظبط زي ما اتفق مع المستخدم.
export function buildOrthoTreatmentParagraph(input: {
  service: string | null;
  upperWireSize: string | null;
  upperWireType: string | null;
  lowerWireSize: string | null;
  lowerWireType: string | null;
  note: string | null;
}): string | null {
  const parts: string[] = [];
  if (input.service) parts.push(input.service);
  if (input.upperWireSize && input.upperWireSize !== "Same") {
    parts.push(`Upper wire ${input.upperWireSize} ${input.upperWireType ?? ""}`.trim());
  }
  if (input.lowerWireSize && input.lowerWireSize !== "Same") {
    parts.push(`Lower wire ${input.lowerWireSize} ${input.lowerWireType ?? ""}`.trim());
  }
  if (input.note) parts.push(input.note);
  if (parts.length === 0) return null;
  return parts.join(" ");
}

// "الزيارة المقابلة" في الملف الطبي العادي — بنفس المريض والتاريخ بس. شارت
// التقويم مالوش مفهوم "خدمة" مربوطة بجدول services زي الملف الطبي (service
// هنا نص حر زي "Follow up")، فمنقدرش نستخدم findMatchingVisit العادي
// (اللي محتاج service_id). لو فيه أكتر من زيارة لنفس المريض في نفس اليوم،
// بناخد الأحدث.
async function findCorrespondingMedicalVisit(trx: Transaction<Database>, params: { patientId: number; visitDate: string }) {
  return trx
    .selectFrom("visits")
    .select(["id", "notes", "notes_synced_from_ortho"])
    .where("patient_id", "=", params.patientId)
    .where("visit_date", "=", params.visitDate)
    .orderBy("id", "desc")
    .executeTakeFirst();
}

// بيتنادى بعد حفظ (إضافة/تعديل) زيارة متابعة في شارت التقويم. بينسخ الباراجراف
// لحقل notes بتاع الزيارة المقابلة — بس لو مفيش نص يدوي حقيقي مكتوب هناك
// بالفعل (notes فاضي، أو آخر نص كان هو نفسه جاي من مزامنة سابقة). نص كتبه
// الطبيب يدويًا في الملف الطبي نفسه (notes_synced_from_ortho=0) مايتلمسش خالص
// — من غير ما نرفض العملية لو الزيارة المقابلة مش موجودة أصلاً (وقتها ببساطة
// مفيش حاجة تتزامن، زي ما هو متفق).
export async function syncOrthoNoteToMedicalVisit(
  trx: Transaction<Database>,
  params: { patientId: number; visitDate: string; paragraph: string | null }
) {
  const visit = await findCorrespondingMedicalVisit(trx, params);
  if (!visit) return;
  if (visit.notes && !visit.notes_synced_from_ortho) return;
  await trx
    .updateTable("visits")
    .set({ notes: params.paragraph, notes_synced_from_ortho: params.paragraph ? 1 : 0 })
    .where("id", "=", visit.id)
    .execute();
}

// بيتنادى بعد حذف زيارة متابعة من شارت التقويم (deleteOrthoVisitAction) —
// بيمسح النص من الزيارة المقابلة بس لو هو نفسه اللي كان جاي من المزامنة.
export async function clearSyncedOrthoNote(trx: Transaction<Database>, params: { patientId: number; visitDate: string }) {
  const visit = await findCorrespondingMedicalVisit(trx, params);
  if (!visit) return;
  if (!visit.notes_synced_from_ortho) return;
  await trx.updateTable("visits").set({ notes: null, notes_synced_from_ortho: 0 }).where("id", "=", visit.id).execute();
}
