import { db } from "./db/client";

export async function logOverride(params: {
  entityType: string;
  entityId: number;
  field: string;
  oldValue: string | number | null;
  newValue: string | number | null;
  changedBy: number | null;
  reason?: string | null;
}) {
  await db
    .insertInto("audit_log")
    .values({
      entity_type: params.entityType,
      entity_id: params.entityId,
      field: params.field,
      old_value: params.oldValue === null ? null : String(params.oldValue),
      new_value: params.newValue === null ? null : String(params.newValue),
      changed_by: params.changedBy,
      reason: params.reason ?? null,
    })
    .execute();
}
