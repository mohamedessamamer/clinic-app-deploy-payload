// ضغط الصور على المتصفح قبل الرفع — نفس فكرة الـ compressImage اللي في
// البروتوتايب المعزول (src/components/prototype/OrthoChartV2.tsx)، لكن هنا
// بترجع Blob/File حقيقي يتبعت فعلاً في FormData بدل object URL للمعاينة بس.
//
// الهدف (رد على سؤال المستخدم 2026-08-27): تصغير حجم الملف من غير ما الجودة
// أو أبعاد الصورة الأصلية تتأثر بشكل ملحوظ:
// - لو الصورة أصلاً صغيرة (أبعاد وحجم معقولين) بترجع زي ما هي من غير أي لمس.
// - غير كده بيتم تصغير أكبر بعد لحد MAX_DIM بحد أقصى (2000px — كبير كفاية إن
//   الجودة المرئية ما تتأثرش عمليًا، حتى على شاشات عالية الدقة) وإعادة الترميز
//   JPEG بجودة 0.92 (عالية جدًا، الفرق البصري شبه معدوم لكن بيوفر مساحة كبيرة
//   خصوصًا لو الأصل PNG أو صورة كاميرا موبايل كبيرة).
// - ملفات PDF أو أي حاجة مش image/* بترجع زي ما هي (مفيش canvas ينفع يضغطها).
const MAX_DIM = 2000;
const JPEG_QUALITY = 0.92;
const SKIP_IF_UNDER_BYTES = 400 * 1024; // ملفات أصغر من كده أصلاً مفيش داعي نلمسها

export function compressImageFile(file: File): Promise<File> {
  return new Promise((resolve) => {
    if (!file.type.startsWith("image/") || file.type === "image/svg+xml") {
      resolve(file);
      return;
    }
    if (file.size <= SKIP_IF_UNDER_BYTES) {
      resolve(file);
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        const needsResize = width > MAX_DIM || height > MAX_DIM;
        if (needsResize) {
          const scale = MAX_DIM / Math.max(width, height);
          width = Math.round(width * scale);
          height = Math.round(height * scale);
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve(file);
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        canvas.toBlob(
          (blob) => {
            if (!blob) {
              resolve(file);
              return;
            }
            // لو الناتج المضغوط طلع أكبر من الأصلي (نادر، بيحصل مع صور
            // مضغوطة أصلاً جدًا) بنسيب الأصلي زي ما هو.
            if (blob.size >= file.size) {
              resolve(file);
              return;
            }
            const newName = file.name.replace(/\.[a-zA-Z0-9]+$/, "") + ".jpg";
            resolve(new File([blob], newName, { type: "image/jpeg", lastModified: Date.now() }));
          },
          "image/jpeg",
          JPEG_QUALITY
        );
      };
      img.onerror = () => resolve(file);
      img.src = reader.result as string;
    };
    reader.onerror = () => resolve(file);
    reader.readAsDataURL(file);
  });
}
