import bcrypt from "bcryptjs";
import { SignJWT, jwtVerify } from "jose";

const SECRET = new TextEncoder().encode(
  process.env.SESSION_SECRET || "dev-only-secret-change-in-production-please"
);

export const SESSION_COOKIE = "clinic_session";

export type Role = "admin" | "doctor" | "reception" | "accountant" | "clinic_manager";

export interface SessionPayload {
  userId: number;
  username: string;
  fullName: string;
  role: Role;
  doctorId: number | null;
}

export async function hashPassword(plain: string) {
  return bcrypt.hash(plain, 10);
}

export async function verifyPassword(plain: string, hash: string) {
  return bcrypt.compare(plain, hash);
}

export async function createSessionToken(payload: SessionPayload) {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("12h")
    .sign(SECRET);
}

export async function verifySessionToken(token: string): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, SECRET);
    return payload as unknown as SessionPayload;
  } catch {
    return null;
  }
}

// Role labels in Arabic for display in the UI.
export const ROLE_LABELS: Record<Role, string> = {
  admin: "مدير النظام",
  doctor: "دكتور",
  reception: "استقبال",
  accountant: "محاسب",
  clinic_manager: "مدير العيادة",
};
