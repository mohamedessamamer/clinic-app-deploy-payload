// معرّفات وترتيب عرض الأسنان لشارت التقويم (صف "الأسنان الناقصة" وخريطة الخلع
// في خطة العلاج) — نفس ترتيب الورقة الأصلية: يمين المريض في أقصى الشمال بصريًا
// (بعيد عن خط المنتصف) لحد خط المنتصف، وبعدين شمال المريض من خط المنتصف لحد
// أقصى اليمين بصريًا. مطابق لطريقة عرض شارت الأسنان القياسية (الشخص قصادك).
//
// المعرّف: <U|L><R|L><1-8 أو a-e> — مثلاً "UR6" (سن رقم 6 علوي يمين)، "LLc" (سن
// لبني c سفلي شمال). القيم دي بتتخزّن كـ JSON array نصي في العمودين
// missing_teeth وextraction_teeth بجدول orthodontic_charts.

export type ToothId = string;

export interface Tooth {
  id: ToothId;
  label: string; // النص المعروض على الزرار (رقم أو حرف بس)
}

// نسخة الشارت الموحّد (الأسنان الدائمة كلها، 16 سن لكل فك) — الشارت التفاعلي
// الرئيسي (ToothChart) بيستخدمها، ودوسة على أي سن بتفتح لوحة تفاصيله (ناقص/
// خلع/تركيب/ريبوندينج/ملاحظة كلهم مكان واحد، بدل شارتات منفصلة لكل حاجة).
export function permanentTeeth(archPrefix: "U" | "L"): Tooth[] {
  return permanentRow(archPrefix);
}

// نفس الفكرة بس للأسنان اللبنية (a-e) — الشارت التفاعلي بيبدّل بينها وبين
// الأسنان الدائمة بزرار تبديل فوقه (افتراضيًا دائم، وتحويل للبني عند الحاجة).
export function primaryTeeth(archPrefix: "U" | "L"): Tooth[] {
  return primaryRow(archPrefix);
}

// لو السن ده جوه نطاق "التركيب" (bonding) — سن 1-5 بتاخد براكت، سن 6 بتاخد
// تيوب، غير كده (7، 8) مش جزء من التركيب العادي فبترجع null.
export function bondingZoneOf(toothId: ToothId): "bracket" | "tube" | null {
  const match = /^[UL][RL](\d)$/.exec(toothId);
  if (!match) return null;
  const n = Number(match[1]);
  if (n < 1 || n > 6) return null;
  return n === 6 ? "tube" : "bracket";
}

// الفك اللي السن ده تابع له، من أول حرف في المعرّف ("U".."L").
export function archOfTooth(toothId: ToothId): "U" | "L" {
  return toothId.startsWith("U") ? "U" : "L";
}

function permanentRow(archPrefix: "U" | "L"): Tooth[] {
  const right: Tooth[] = [8, 7, 6, 5, 4, 3, 2, 1].map((n) => ({
    id: `${archPrefix}R${n}`,
    label: String(n),
  }));
  const left: Tooth[] = [1, 2, 3, 4, 5, 6, 7, 8].map((n) => ({
    id: `${archPrefix}L${n}`,
    label: String(n),
  }));
  return [...right, ...left];
}

function primaryRow(archPrefix: "U" | "L"): Tooth[] {
  const right: Tooth[] = ["e", "d", "c", "b", "a"].map((l) => ({
    id: `${archPrefix}R${l}`,
    label: l.toUpperCase(),
  }));
  const left: Tooth[] = ["a", "b", "c", "d", "e"].map((l) => ({
    id: `${archPrefix}L${l}`,
    label: l.toUpperCase(),
  }));
  return [...right, ...left];
}

// الصفوف الأربعة المستخدمة في صف "الأسنان الناقصة" (علوي دائم، علوي لبني، سفلي دائم، سفلي لبني)
export const MISSING_TEETH_ROWS: { title: string; teeth: Tooth[] }[] = [
  { title: "علوي (دائم)", teeth: permanentRow("U") },
  { title: "علوي (لبني)", teeth: primaryRow("U") },
  { title: "سفلي (دائم)", teeth: permanentRow("L") },
  { title: "سفلي (لبني)", teeth: primaryRow("L") },
];

// خريطة الخلع في خطة العلاج — أسنان دائمة بس (الخلع لخطة التقويم بيكون على
// الأسنان الدائمة عادةً)، بترتيب 4 أرباع حوالين علامة "+".
export const EXTRACTION_QUADRANTS: { title: string; teeth: Tooth[] }[] = [
  { title: "يمين علوي", teeth: [8, 7, 6, 5, 4, 3, 2, 1].map((n) => ({ id: `UR${n}`, label: String(n) })) },
  { title: "شمال علوي", teeth: [1, 2, 3, 4, 5, 6, 7, 8].map((n) => ({ id: `UL${n}`, label: String(n) })) },
  { title: "يمين سفلي", teeth: [8, 7, 6, 5, 4, 3, 2, 1].map((n) => ({ id: `LR${n}`, label: String(n) })) },
  { title: "شمال سفلي", teeth: [1, 2, 3, 4, 5, 6, 7, 8].map((n) => ({ id: `LL${n}`, label: String(n) })) },
];

// أسنان "التركيب" (bonding) لكل فك — سن 1 لـ5 كل ناحية بتاخد براكت، سن 6
// (الضرس الأول) بتاخد تيوب. ده أساس حساب العدد الافتراضي (10 براكت + 2 تيوب
// للفك الكامل) وتقليله أوتوماتيك حسب الأسنان اللي اتحددت "ملهاش تركيب".
export interface BondingTooth extends Tooth {
  zone: "bracket" | "tube";
}

export function bondingTeeth(archPrefix: "U" | "L"): BondingTooth[] {
  const right: BondingTooth[] = [6, 5, 4, 3, 2, 1].map((n) => ({
    id: `${archPrefix}R${n}`,
    label: String(n),
    zone: n === 6 ? "tube" : "bracket",
  }));
  const left: BondingTooth[] = [1, 2, 3, 4, 5, 6].map((n) => ({
    id: `${archPrefix}L${n}`,
    label: String(n),
    zone: n === 6 ? "tube" : "bracket",
  }));
  return [...right, ...left];
}

// كل أسنان التركيب في الفكين (لشارت الريبوندينج — أي سن ليه تركيب ممكن يحتاج
// ريبوندينج لاحقًا، في أي فك).
export const REBONDING_ROWS: { title: string; teeth: Tooth[] }[] = [
  { title: "علوي", teeth: bondingTeeth("U") },
  { title: "سفلي", teeth: bondingTeeth("L") },
];

export function parseToothList(json: string | null): ToothId[] {
  if (!json) return [];
  try {
    const parsed = JSON.parse(json);
    return Array.isArray(parsed) ? parsed.filter((x) => typeof x === "string") : [];
  } catch {
    return [];
  }
}
