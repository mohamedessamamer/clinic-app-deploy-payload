import { db } from "@/lib/db/client";

// دفعة 22 (متابعة تقرير ازدواجية الخدمات): بيدوّر على زيارة موجودة بالفعل لنفس
// (مريض + دكتور أساسي + تاريخ + خدمة) — ده المعيار اللي اتفقنا عليه مع المستخدم
// لتحديد "هي نفس الخدمة الحقيقية" بغض النظر مين دخلها الأول: الطبيب من سجل
// الزيارات بالملف الطبي (addVisitAction)، أو الاستقبال من الملف المالي
// (addPatientServiceAction) أو الجدول المركزي (recordAppointmentBillingAction).
//
// عمدًا من غير قيد على appointment_id (خلاف الاستعلام الداخلي في
// recordAppointmentBillingAction اللي بيتطلب appointment_id فاضي تحديدًا لأسباب
// خاصة بربط موعد معيّن بيه) — الهدف هنا أعم وأشمل: أي مكان في السيستم يحاول
// يسجل نفس الخدمة (لنفس المريض/الدكتور/اليوم) يلاقيها ويكمل عليها بدل ما يعمل
// زيارة وفاتورة مستقلة تانية، عشان الخدمة متتكررش في الملف الطبي والدين
// المستحق على المريض ميتضاعفش في الملف المالي.
export async function findMatchingVisit(params: { patientId: number; doctorId: number; visitDate: string; serviceId: number }) {
  return db
    .selectFrom("visits")
    .select(["id", "notes", "performing_doctor_id", "appointment_id", "room_id"])
    .where("patient_id", "=", params.patientId)
    .where("primary_doctor_id", "=", params.doctorId)
    .where("visit_date", "=", params.visitDate)
    .where("service_id", "=", params.serviceId)
    .orderBy("id", "desc")
    .executeTakeFirst();
}
