// حساب سن المريض — بالسنين الكاملة بس (مش شهور ولا أيام)، من تاريخ الميلاد.
// مفيش استيراد لطبقة قاعدة البيانات هنا عشان يصلح للاستخدام في مكونات العميل كمان.

// بيرجع السن بالسنين من تاريخ ميلاد (YYYY-MM-DD)، أو null لو التاريخ مش موجود/غلط.
export function ageFromBirthDate(birthDate: string | null | undefined): number | null {
  if (!birthDate) return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(birthDate);
  if (!m) return null;
  const birthYear = Number(m[1]);
  const birthMonth = Number(m[2]);
  const birthDay = Number(m[3]);

  const today = new Date();
  const todayYear = today.getUTCFullYear();
  const todayMonth = today.getUTCMonth() + 1;
  const todayDay = today.getUTCDate();

  let age = todayYear - birthYear;
  if (todayMonth < birthMonth || (todayMonth === birthMonth && todayDay < birthDay)) {
    age -= 1;
  }
  return age >= 0 ? age : null;
}

// السن اللي يتعرض للمريض: لو عنده birth_date نحسبه بالسنين منه، وإلا نرجع لعمود
// "age" القديم (لمرضى اتسجلوا قبل إضافة تاريخ الميلاد) — عشان بيانات قديمة
// متتفقدش من الواجهة.
export function displayAge(patient: { age?: number | null; birth_date?: string | null }): number | null {
  const fromBirthDate = ageFromBirthDate(patient.birth_date);
  if (fromBirthDate != null) return fromBirthDate;
  return patient.age ?? null;
}
