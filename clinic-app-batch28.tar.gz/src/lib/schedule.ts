import "server-only";
import { db } from "./db/client";
import { weekdayOf } from "./settings";

// الغرف/العيادات اللي لدكتور معيّن شيفت فيها في يوم معيّن (حسب الشيفت الأسبوعي
// المتكرر) — مستخدمة عشان نقيّد الجدول المركزي على شيفت الدكتور بس لمن معهوش
// صلاحية "schedule_all_rooms".
export async function getDoctorRoomIdsForDate(doctorId: number, date: string): Promise<number[]> {
  const weekday = weekdayOf(date);
  const rows = await db
    .selectFrom("doctor_weekly_shifts")
    .select("room_id")
    .where("doctor_id", "=", doctorId)
    .where("weekday", "=", weekday)
    .execute();
  return [...new Set(rows.map((r) => r.room_id))];
}
