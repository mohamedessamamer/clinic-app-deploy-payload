// وسائل الدفع المتاحة عند تحصيل فاتورة — نفس القائمة مستخدمة في بوكس التحصيل
// (CentralSchedule.tsx) وفي عرض/تعديل صفحة الفواتير، عشان القيم والتسميات
// تفضل متطابقة في كل مكان (ومفيدة لاحقًا في التقارير: "إجماليات حسب وسيلة الدفع").
export const PAYMENT_METHODS = [
  { value: "cash", label: "نقدي" },
  { value: "visa", label: "فيزا" },
  { value: "instapay", label: "انستاباي" },
] as const;

export type PaymentMethodValue = (typeof PAYMENT_METHODS)[number]["value"];

export function paymentMethodLabel(value: string | null | undefined): string {
  if (!value) return "-";
  return PAYMENT_METHODS.find((m) => m.value === value)?.label ?? value;
}
