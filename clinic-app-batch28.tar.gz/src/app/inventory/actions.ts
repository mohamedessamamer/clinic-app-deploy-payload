"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";

// تحقق حقيقي من الصلاحية جوه الأكشن نفسه — مش بس إخفاء الفورم في الصفحة، عشان
// نداء مباشر للأكشن ده (من غير المرور بواجهة /inventory) ميعديش الحماية.
async function requireManageInventory(): Promise<boolean> {
  const session = await getSession();
  if (!session) return false;
  return hasPermission(session.userId, session.role, "manage_inventory");
}

export async function addItemAction(formData: FormData) {
  if (!(await requireManageInventory())) return;

  const name = String(formData.get("name") || "").trim();
  const quantity = Number(formData.get("quantity") || 0);
  const unit = String(formData.get("unit") || "").trim() || null;
  const expiry_date = String(formData.get("expiry_date") || "").trim() || null;
  const low_stock_threshold = Number(formData.get("low_stock_threshold") || 0);

  if (!name) return;

  await db
    .insertInto("inventory_items")
    .values({ name, quantity, unit, expiry_date, low_stock_threshold })
    .execute();
  revalidatePath("/inventory");
}

export async function updateQuantityAction(formData: FormData) {
  if (!(await requireManageInventory())) return;

  const id = Number(formData.get("id"));
  const quantity = Number(formData.get("quantity"));
  if (!id || Number.isNaN(quantity)) return;

  await db.updateTable("inventory_items").set({ quantity }).where("id", "=", id).execute();
  revalidatePath("/inventory");
}
