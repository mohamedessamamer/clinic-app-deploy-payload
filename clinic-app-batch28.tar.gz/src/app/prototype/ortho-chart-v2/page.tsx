// راوت معزول تمامًا للمعاينة — من غير أي ربط بالـnav أو الداتا الحقيقية،
// من غير أي تسجيل دخول لازم (بروتوتايب للمراجعة بس، هيتشال أو يترّبط بالسيستم
// الحقيقي بعد الموافقة النهائية على الشكل). شوف orthodontic-chart-v2-*.md في
// مشروع "Clinic mangment system" على claude.ai للتفاصيل الكاملة.

import OrthoChartV2 from "@/components/prototype/OrthoChartV2";

export default function OrthoChartV2PreviewPage() {
  return (
    <div className="min-h-screen bg-background p-4 sm:p-8 max-w-5xl mx-auto" dir="ltr">
      <div className="mb-4 text-xs text-muted">
        Preview prototype — Orthodontic chart v2 (page 1) — <span className="font-semibold">not the published live chart, and nothing here is actually saved</span>
      </div>
      <OrthoChartV2 patientName="Test patient (preview prototype)" />
    </div>
  );
}
