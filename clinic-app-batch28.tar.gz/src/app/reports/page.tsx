import Link from "next/link";
import { getSession } from "@/lib/session";
import { paymentMethodLabel } from "@/lib/payment-methods";
import { getReportsData, type ReportsSearchParams } from "@/lib/reports-data";
import ReportsFilterForm from "@/components/ReportsFilterForm";

// تقرير الإيرادات — صفحة/صلاحية مستقلة (reports_full / reports_own، شوف
// permission-defs.ts) بتجمّع بيانات الفواتير الموجودة فعلاً (نفس مصدر بيانات
// /invoices والملف المالي لكل مريض) بفلاتر فترة/دكتور/خدمة، بدل ما تبقى صفحة
// منفصلة بمنطق حسابي مختلف. عمدًا بيربط رجوع لصفوف اليوم التفصيلية في /invoices
// (شوف "ربط الشاشات" في رابط عمود التاريخ تحت).
//
// منطق الجلب/التجميع الفعلي منقول لـ src/lib/reports-data.ts عشان يُستخدم هنا
// وفي تصدير الـ Excel (src/app/reports/export/route.ts) من غير تكرار.

export default async function ReportsPage({ searchParams }: { searchParams: Promise<ReportsSearchParams> }) {
  const session = await getSession();
  const sp = await searchParams;
  const data = await getReportsData(session, sp);

  if (!data.ok) {
    const message =
      data.reason === "no_session"
        ? "لازم تسجل دخول عشان توصل للتقارير."
        : data.reason === "no_permission"
          ? "مفيش صلاحية عندك لعرض التقارير — كلم الأدمن لو محتاج توصل للصفحة دي."
          : "الحساب ده مالوش دكتور مرتبط بيه، فمفيش تقرير شخصي نقدر نعرضه ليك.";
    return <div className="card-3d rounded-xl p-5 text-sm text-muted">{message}</div>;
  }

  const {
    reportsFull,
    from,
    to,
    dateRangeClamped,
    reportsOwnMinFrom,
    doctorId,
    serviceId,
    doctors,
    services,
    newAmount,
    collected,
    visitCount,
    byMethod,
    byDoctor,
    byService,
    byDay,
  } = data;

  const qs = (overrides: Record<string, string | null>) => {
    const params = new URLSearchParams();
    params.set("from", from);
    params.set("to", to);
    if (doctorId) params.set("doctor_id", String(doctorId));
    if (serviceId) params.set("service_id", String(serviceId));
    for (const [k, v] of Object.entries(overrides)) {
      if (v == null) params.delete(k);
      else params.set(k, v);
    }
    return params.toString();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-xl font-bold">تقرير الإيرادات</h1>
          {dateRangeClamped && (
            <p className="text-xs text-muted mt-1">الفترة اتقصّرت لآخر شهرين — الحد الأقصى للتقرير الشخصي.</p>
          )}
        </div>
        <div className="flex items-center gap-3">
          <a href={`/reports/export?${qs({})}`} className="text-sm px-3 py-1.5 rounded-md border border-border hover:bg-primary-soft">
            تصدير Excel
          </a>
          <Link href={`/invoices?date=${to}`} className="text-sm text-primary hover:underline">
            فتح فواتير يوم {to} بالتفصيل
          </Link>
        </div>
      </div>

      <ReportsFilterForm
        from={from}
        to={to}
        minFrom={reportsOwnMinFrom}
        doctorId={reportsFull ? doctorId : null}
        serviceId={serviceId}
        doctors={doctors}
        services={services}
        showDoctorFilter={reportsFull}
      />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="card-3d rounded-xl p-4">
          <div className="text-xs text-muted">إجمالي الفواتير الجديدة في الفترة</div>
          <div className="text-2xl font-bold">{newAmount.toFixed(0)} ج.م</div>
        </div>
        <div className="card-3d rounded-xl p-4">
          <div className="text-xs text-muted">المحصّل في الفترة</div>
          <div className="text-2xl font-bold text-primary">{collected.toFixed(0)} ج.م</div>
          <div className="text-[10px] text-muted mt-0.5">شامل أي دفعات متابعة اتحصّلت في الفترة دي على فواتير أقدم</div>
        </div>
        <div className="card-3d rounded-xl p-4">
          <div className="text-xs text-muted">عدد الزيارات المفوترة</div>
          <div className="text-2xl font-bold">{visitCount}</div>
        </div>
      </div>

      {byMethod.length > 0 && (
        <div className="card-3d rounded-xl p-4">
          <div className="text-sm font-semibold mb-2">المحصّل حسب وسيلة الدفع</div>
          <div className="flex flex-wrap gap-4">
            {byMethod.map(([method, amount]) => (
              <div key={method} className="text-sm">
                <span className="text-muted">{paymentMethodLabel(method)}: </span>
                <span className="font-semibold">{amount.toFixed(0)} ج.م</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {byDoctor.length > 0 && (
        <div className="card-3d rounded-xl overflow-hidden">
          <div className="px-4 py-2 font-semibold text-sm bg-primary-soft text-primary-dark">حسب الدكتور</div>
          <table className="w-full text-sm">
            <thead className="bg-primary-soft/50 text-muted">
              <tr>
                <th className="text-right px-3 py-2 font-medium">الدكتور</th>
                <th className="text-right px-3 py-2 font-medium">عدد الزيارات</th>
                <th className="text-right px-3 py-2 font-medium">الفواتير الجديدة</th>
                <th className="text-right px-3 py-2 font-medium">المحصّل</th>
              </tr>
            </thead>
            <tbody>
              {byDoctor.map((row) => (
                <tr key={row.key} className="border-t border-border">
                  <td className="px-3 py-2 font-medium">
                    <Link href={`/reports?${qs({ doctor_id: String(row.key) })}`} className="text-primary hover:underline">
                      {row.label}
                    </Link>
                  </td>
                  <td className="px-3 py-2">{row.visits}</td>
                  <td className="px-3 py-2">{row.amount.toFixed(0)}</td>
                  <td className="px-3 py-2 text-primary">{row.paid.toFixed(0)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {byService.length > 0 && (
        <div className="card-3d rounded-xl overflow-hidden">
          <div className="px-4 py-2 font-semibold text-sm bg-primary-soft text-primary-dark">حسب الخدمة</div>
          <table className="w-full text-sm">
            <thead className="bg-primary-soft/50 text-muted">
              <tr>
                <th className="text-right px-3 py-2 font-medium">الخدمة</th>
                <th className="text-right px-3 py-2 font-medium">عدد الزيارات</th>
                <th className="text-right px-3 py-2 font-medium">الفواتير الجديدة</th>
                <th className="text-right px-3 py-2 font-medium">المحصّل</th>
              </tr>
            </thead>
            <tbody>
              {byService.map((row) => (
                <tr key={row.key} className="border-t border-border">
                  <td className="px-3 py-2 font-medium">
                    <Link href={`/reports?${qs({ service_id: String(row.key) })}`} className="text-primary hover:underline">
                      {row.label}
                    </Link>
                  </td>
                  <td className="px-3 py-2">{row.visits}</td>
                  <td className="px-3 py-2">{row.amount.toFixed(0)}</td>
                  <td className="px-3 py-2 text-primary">{row.paid.toFixed(0)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="card-3d rounded-xl overflow-hidden">
        <div className="px-4 py-2 font-semibold text-sm bg-primary-soft text-primary-dark">تفصيل يومي</div>
        <table className="w-full text-sm">
          <thead className="bg-primary-soft/50 text-muted">
            <tr>
              <th className="text-right px-3 py-2 font-medium">اليوم</th>
              <th className="text-right px-3 py-2 font-medium">عدد الزيارات</th>
              <th className="text-right px-3 py-2 font-medium">الفواتير الجديدة</th>
              <th className="text-right px-3 py-2 font-medium">المحصّل</th>
              <th className="text-right px-3 py-2 font-medium" />
            </tr>
          </thead>
          <tbody>
            {byDay.map((row) => (
              <tr key={row.date} className="border-t border-border">
                <td className="px-3 py-2 whitespace-nowrap">{row.date}</td>
                <td className="px-3 py-2">{row.visits}</td>
                <td className="px-3 py-2">{row.amount.toFixed(0)}</td>
                <td className="px-3 py-2 text-primary">{row.paid.toFixed(0)}</td>
                <td className="px-3 py-2">
                  <Link href={`/invoices?date=${row.date}`} className="text-xs text-primary hover:underline whitespace-nowrap">
                    تفاصيل الفواتير ←
                  </Link>
                </td>
              </tr>
            ))}
            {byDay.length === 0 && (
              <tr>
                <td colSpan={5} className="px-3 py-6 text-center text-muted">
                  لا يوجد بيانات في الفترة المختارة.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
