import ExcelJS from "exceljs";
import { getSession } from "@/lib/session";
import { paymentMethodLabel } from "@/lib/payment-methods";
import { getReportsData, type ReportsSearchParams } from "@/lib/reports-data";

// تصدير تقرير الإيرادات لملف Excel — بيستخدم نفس منطق الفلترة/التجميع بتاع
// صفحة /reports (عبر src/lib/reports-data.ts) عشان الأرقام في الملف تكون
// مطابقة تمامًا للي ظاهر على الشاشة. GET بسيطة بنفس query params بتاعة الصفحة
// (from/to/doctor_id/service_id).

export async function GET(request: Request) {
  const session = await getSession();
  const url = new URL(request.url);
  const sp: ReportsSearchParams = {
    from: url.searchParams.get("from") ?? undefined,
    to: url.searchParams.get("to") ?? undefined,
    doctor_id: url.searchParams.get("doctor_id") ?? undefined,
    service_id: url.searchParams.get("service_id") ?? undefined,
  };

  const data = await getReportsData(session, sp);
  if (!data.ok) {
    const message =
      data.reason === "no_session"
        ? "لازم تسجل دخول عشان توصل للتقارير."
        : data.reason === "no_permission"
          ? "مفيش صلاحية عندك لعرض التقارير."
          : "الحساب ده مالوش دكتور مرتبط بيه.";
    return new Response(message, { status: 403, headers: { "Content-Type": "text/plain; charset=utf-8" } });
  }

  const { from, to, newAmount, collected, visitCount, byMethod, byDoctor, byService, byDay } = data;

  const workbook = new ExcelJS.Workbook();
  workbook.creator = "عيادتي";
  workbook.created = new Date();

  // ---- ملخص ----
  const summarySheet = workbook.addWorksheet("ملخص");
  summarySheet.views = [{ rightToLeft: true }];
  summarySheet.columns = [
    { header: "البند", key: "label", width: 32 },
    { header: "القيمة", key: "value", width: 20 },
  ];
  summarySheet.addRows([
    { label: "الفترة من", value: from },
    { label: "الفترة إلى", value: to },
    { label: "إجمالي الفواتير الجديدة في الفترة", value: newAmount },
    { label: "المحصّل في الفترة", value: collected },
    { label: "عدد الزيارات المفوترة", value: visitCount },
  ]);
  summarySheet.addRow({});
  summarySheet.addRow({ label: "المحصّل حسب وسيلة الدفع", value: "" });
  for (const [method, amount] of byMethod) {
    summarySheet.addRow({ label: paymentMethodLabel(method), value: amount });
  }
  summarySheet.getRow(1).font = { bold: true };

  // ---- حسب الدكتور ----
  if (byDoctor.length > 0) {
    const doctorSheet = workbook.addWorksheet("حسب الدكتور");
    doctorSheet.views = [{ rightToLeft: true }];
    doctorSheet.columns = [
      { header: "الدكتور", key: "label", width: 28 },
      { header: "عدد الزيارات", key: "visits", width: 14 },
      { header: "الفواتير الجديدة", key: "amount", width: 18 },
      { header: "المحصّل", key: "paid", width: 18 },
    ];
    for (const row of byDoctor) {
      doctorSheet.addRow({ label: row.label, visits: row.visits, amount: row.amount, paid: row.paid });
    }
    doctorSheet.getRow(1).font = { bold: true };
  }

  // ---- حسب الخدمة ----
  const serviceSheet = workbook.addWorksheet("حسب الخدمة");
  serviceSheet.views = [{ rightToLeft: true }];
  serviceSheet.columns = [
    { header: "الخدمة", key: "label", width: 28 },
    { header: "عدد الزيارات", key: "visits", width: 14 },
    { header: "الفواتير الجديدة", key: "amount", width: 18 },
    { header: "المحصّل", key: "paid", width: 18 },
  ];
  for (const row of byService) {
    serviceSheet.addRow({ label: row.label, visits: row.visits, amount: row.amount, paid: row.paid });
  }
  serviceSheet.getRow(1).font = { bold: true };

  // ---- تفصيل يومي ----
  const daySheet = workbook.addWorksheet("تفصيل يومي");
  daySheet.views = [{ rightToLeft: true }];
  daySheet.columns = [
    { header: "اليوم", key: "date", width: 14 },
    { header: "عدد الزيارات", key: "visits", width: 14 },
    { header: "الفواتير الجديدة", key: "amount", width: 18 },
    { header: "المحصّل", key: "paid", width: 18 },
  ];
  for (const row of byDay) {
    daySheet.addRow({ date: row.date, visits: row.visits, amount: row.amount, paid: row.paid });
  }
  daySheet.getRow(1).font = { bold: true };

  const buffer = await workbook.xlsx.writeBuffer();
  const filename = `reports-${from}-to-${to}.xlsx`;

  return new Response(buffer, {
    status: 200,
    headers: {
      "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "Content-Disposition": `attachment; filename="${filename}"`,
    },
  });
}
