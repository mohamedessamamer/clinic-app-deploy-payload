"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { logOverride } from "@/lib/audit";

// تعديل "المدفوع" و/أو "المبلغ" (سعر الخدمة) و/أو "طريقة الدفع" في فاتورة
// اتسجلت بالفعل — بمجرد ما يتسجل مبلغ مدفوع، المفروض يفضل ثابت وميتغيرش
// عشوائيًا؛ التعديل بعد كده محصور بصلاحية `edit_invoice_payments` (مدير
// العيادة/المحاسب/الأدمن افتراضيًا، قابلة للمنح لغيرهم من الإعدادات) — أساسًا
// لتصحيح غلطة إدخال رقم من الاستقبال، أو لتحديد طريقة الدفع لفاتورة اتسجلت من
// غير ما تُحدَّد (زي الزيارات المضافة يدويًا من الملف الطبي، اللي مالهاش بوكس
// تحصيل بيسأل عن طريقة الدفع). أي تغيير بيتسجل في audit_log (تقرير "تعديلات
// اليوم" في نفس الصفحة).
export async function updatePaymentAction(formData: FormData) {
  const session = await getSession();
  if (!session) return;
  const canEdit = await hasPermission(session.userId, session.role, "edit_invoice_payments");
  if (!canEdit) return;

  const id = Number(formData.get("id"));
  const paid = Number(formData.get("paid"));
  const amount = Number(formData.get("amount"));
  const paymentMethod = String(formData.get("payment_method") || "").trim() || null;
  if (!id || Number.isNaN(paid) || Number.isNaN(amount)) return;

  const invoice = await db
    .selectFrom("invoices")
    .innerJoin("visits", "visits.id", "invoices.visit_id")
    .select(["invoices.paid", "invoices.amount", "invoices.payment_method", "visits.patient_id"])
    .where("invoices.id", "=", id)
    .executeTakeFirst();
  if (!invoice) return;

  const priceChanged = amount !== invoice.amount;
  const paymentMethodChanged = paymentMethod !== invoice.payment_method;
  await db
    .updateTable("invoices")
    .set({
      paid,
      amount,
      payment_method: paymentMethod,
      // بنعلّمها "متعدّلة يدويًا" لو السعر اتغيّر، عشان لو حد عدّل خدمة الزيارة
      // بعد كده (خلال نافذة الـ3 أيام) الـ resync الأوتوماتيكي (updateVisitAction)
      // ميكتبش فوق التصحيح اليدوي ده بالغلط.
      ...(priceChanged ? { price_overridden: 1 } : {}),
    })
    .where("id", "=", id)
    .execute();

  if (paid !== invoice.paid) {
    await logOverride({
      entityType: "invoice_payment",
      entityId: id,
      field: "المدفوع",
      oldValue: invoice.paid,
      newValue: paid,
      changedBy: session.userId,
      reason: "تعديل يدوي من صفحة الفواتير",
    });
  }
  if (priceChanged) {
    await logOverride({
      entityType: "invoice_price",
      entityId: id,
      field: "المبلغ",
      oldValue: invoice.amount,
      newValue: amount,
      changedBy: session.userId,
      reason: "تعديل يدوي من صفحة الفواتير",
    });
  }
  if (paymentMethodChanged) {
    await logOverride({
      entityType: "invoice_payment_method",
      entityId: id,
      field: "طريقة الدفع",
      oldValue: invoice.payment_method,
      newValue: paymentMethod,
      changedBy: session.userId,
      reason: "تعديل يدوي من صفحة الفواتير",
    });
  }

  revalidatePath("/invoices");
  revalidatePath("/front-desk");
  revalidatePath(`/patients/${invoice.patient_id}/billing`);
}
