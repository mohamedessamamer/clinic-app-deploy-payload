import Link from "next/link";
import { db } from "@/lib/db/client";
import DateFilterForm from "@/components/DateFilterForm";
import ExceptionalShiftButton from "@/components/ExceptionalShiftButton";
import CentralSchedule from "@/components/CentralSchedule";
import { getAllSettings, buildTimeSlots, weekdayOf } from "@/lib/settings";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getDoctorRoomIdsForDate } from "@/lib/schedule";
import { computeNeedsNewPhotosMap } from "@/lib/photo-reminder";
import { computeNeedsTreatmentMap } from "@/lib/needs-treatment";
import { getClinicToday } from "@/lib/clinic-date";

export default async function FrontDeskPage({
  searchParams,
}: {
  searchParams: Promise<{ date?: string }>;
}) {
  const { date } = await searchParams;
  const day = date && /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : getClinicToday();
  const weekday = weekdayOf(day);

  const session = await getSession();
  const [canEditSchedule, canSeeAllRooms, canCollectPayments, canEditAssistantDoctor, canSeeNeedsTreatment, canQuickAddService, canBackdateInvoice] = session
    ? await Promise.all([
        hasPermission(session.userId, session.role, "schedule_edit"),
        hasPermission(session.userId, session.role, "schedule_all_rooms"),
        hasPermission(session.userId, session.role, "collect_payments"),
        // دفعة 22: حقل "الطبيب المساعد" الاختياري جوه بوكس التحصيل — نفس صلاحية
        // سجل الزيارات بالملف الطبي.
        hasPermission(session.userId, session.role, "edit_visit_assistant_doctor").then(
          async (v) => v || (await hasPermission(session.userId, session.role, "override_visit_doctor"))
        ),
        // دفعة 27 (P2.4): تنبيه "محتاج إدخال معالجة" — للدكتور افتراضيًا.
        hasPermission(session.userId, session.role, "view_needs_treatment_reminder"),
        // دفعة 27 (P3.1): بوكس "إضافة خدمة للتحصيل" السريع (كليك يمين على اسم
        // المريض) — نفس صلاحية عرض الملف المالي نفسه.
        hasPermission(session.userId, session.role, "view_patient_billing"),
        hasPermission(session.userId, session.role, "edit_invoice_payments"),
      ])
    : [false, false, false, false, false, false, false];

  const rooms = await db.selectFrom("rooms").selectAll().execute();

  // لو المستخدم معهوش صلاحية "كل الغرف" وهو دكتور، الجدول المركزي بيتقيد على
  // الغرفة/الغرف اللي شيفته فيها النهاردة بس. أي دور تاني (استقبال/محاسب...) من
  // غير الصلاحية دي حالة نادرة (الأدمن يقدر يقيّدها يدويًا) فبيشوف كل الغرف برضه
  // لعدم وجود مفهوم "شيفت" له.
  const doctorRoomIds =
    !canSeeAllRooms && session?.doctorId ? await getDoctorRoomIdsForDate(session.doctorId, day) : null;
  const visibleRooms = doctorRoomIds ? rooms.filter((r) => doctorRoomIds.includes(r.id)) : rooms;

  const [patients, services, doctors, roomShiftsToday, appointmentsRaw, billedApptRows, settings, exceptionalShiftsToday] = await Promise.all([
    db.selectFrom("patients").select(["id", "full_name", "file_number"]).orderBy("id", "desc").limit(500).execute(),
    db.selectFrom("services").select(["id", "name", "default_price", "code"]).execute(),
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).execute(),
    // أول شيفت (بالوقت) لكل غرفة ظاهرة النهاردة — عشان بوكس الحجز في الجدول
    // المركزي (CentralSchedule) يقدر يحدد صاحب شيفت أي غرفة فيها تلقائيًا.
    visibleRooms.length > 0
      ? db
          .selectFrom("doctor_weekly_shifts")
          .select(["room_id", "doctor_id", "start_time"])
          .where(
            "room_id",
            "in",
            visibleRooms.map((r) => r.id)
          )
          .where("weekday", "=", weekday)
          .orderBy("start_time")
          .execute()
      : Promise.resolve([]),
    db
      .selectFrom("appointments")
      .innerJoin("patients", "patients.id", "appointments.patient_id")
      .leftJoin("doctors", "doctors.id", "appointments.doctor_id")
      .leftJoin("services", "services.id", "appointments.pending_service_id")
      .leftJoin("services as purpose_services", "purpose_services.id", "appointments.purpose_service_id")
      .select([
        "appointments.id",
        "appointments.patient_id",
        "patients.full_name as patient_name",
        "appointments.doctor_id",
        "doctors.full_name as doctor_name",
        "appointments.room_id",
        "appointments.start_time",
        "appointments.duration_minutes",
        "appointments.status",
        "appointments.notes",
        "appointments.pending_service_id",
        "appointments.pending_price",
        "appointments.pending_discount_percent",
        "services.name as pending_service_name",
        "appointments.purpose_type",
        "appointments.purpose_service_id",
        "purpose_services.name as purpose_service_name",
        "purpose_services.category as purpose_service_category",
        "appointments.purpose_linked_invoice_id",
      ])
      .where("appointment_date", "=", day)
      .where("status", "!=", "cancelled")
      .orderBy("appointments.start_time")
      .execute(),
    db
      .selectFrom("visits")
      .select("appointment_id")
      .where("visit_date", "=", day)
      .where("appointment_id", "is not", null)
      .execute(),
    getAllSettings(),
    // شفت استثنائي مسجّل لليوم/الغرف الظاهرة دي — دفعة 27. بياخد أولوية على
    // الشيفت الأسبوعي العادي في تحديد الدكتور المقترح افتراضيًا (تحت).
    visibleRooms.length > 0
      ? db
          .selectFrom("doctor_date_shifts")
          .innerJoin("doctors", "doctors.id", "doctor_date_shifts.doctor_id")
          .select(["doctor_date_shifts.room_id", "doctor_date_shifts.doctor_id", "doctors.full_name as doctor_name"])
          .where(
            "doctor_date_shifts.room_id",
            "in",
            visibleRooms.map((r) => r.id)
          )
          .where("doctor_date_shifts.shift_date", "=", day)
          .execute()
      : Promise.resolve([]),
  ]);

  // أول شيفت (بالوقت) لكل غرفة النهاردة — بيحدد صاحب الشيفت المقترح افتراضيًا
  // وقت الحجز من الجدول المركزي. الشفت الاستثنائي (لو موجود لنفس الغرفة/اليوم)
  // بياخد أولوية عليه — طلب صريح من المستخدم.
  const roomShiftDoctorIds: Record<number, number> = {};
  for (const s of roomShiftsToday) {
    if (!(s.room_id in roomShiftDoctorIds)) roomShiftDoctorIds[s.room_id] = s.doctor_id;
  }
  const exceptionalShifts: Record<number, { doctorId: number; doctorName: string }> = {};
  for (const s of exceptionalShiftsToday) {
    exceptionalShifts[s.room_id] = { doctorId: s.doctor_id, doctorName: s.doctor_name };
    roomShiftDoctorIds[s.room_id] = s.doctor_id;
  }
  const slotMinutes = Number(settings.slot_minutes);
  const timeSlots = buildTimeSlots(settings.day_start, settings.day_end, slotMinutes);

  // موعد "تم" وليه زيارة مرتبطة بيه (appointment_id) يبقى اتحصّل عليه أصلاً؛ لو "تم"
  // من غير زيارة مرتبطة، يبقى محتاج تحصيل (شوف needs_billing تحت). تسجيل التحصيل
  // نفسه بقى إما من الجدول المركزي (كليك يمين/دوسة طويلة على الموعد) أو من "إضافة
  // خدمة" جوه الملف المالي للمريض (دفعة 20).
  const billedApptIds = new Set(billedApptRows.map((r) => r.appointment_id).filter((id): id is number => id != null));
  const needsPhotosMap = await computeNeedsNewPhotosMap(appointmentsRaw.map((a) => a.patient_id));
  // دفعة 27 (P2.4): تنبيه "محتاج إدخال معالجة" — بيتحسب دايمًا (رخيص) لكن
  // بيوصل للواجهة بـfalse لمين معهوش صلاحية view_needs_treatment_reminder،
  // تحقق حقيقي هنا مش مجرد إخفاء في الواجهة.
  const needsTreatmentMap = canSeeNeedsTreatment
    ? await computeNeedsTreatmentMap(
        appointmentsRaw.map((a) => ({ id: a.id, patient_id: a.patient_id, appointment_date: day, status: a.status }))
      )
    : new Map<number, boolean>();

  // دفعة المراجعة 2026-08-27: أي مريض تقويم (عنده شارت تقويم فعلي بالفعل، حتى
  // لو الموعد النهاردة معلمش عليه "المريض جاي يعمل إيه") — دوسة على الموعد بتاعه
  // تفتح شارت التقويم على طول بدل الملف الطبي العادي، بدون ما يحتاج حد يحدد
  // الغرض من كل موعد يدويًا في كل مرة.
  const orthoPatientIds =
    appointmentsRaw.length > 0
      ? new Set(
          (
            await db
              .selectFrom("orthodontic_charts")
              .select("patient_id")
              .where(
                "patient_id",
                "in",
                Array.from(new Set(appointmentsRaw.map((a) => a.patient_id)))
              )
              .execute()
          ).map((r) => r.patient_id)
        )
      : new Set<number>();

  const appointments = appointmentsRaw.map((a) => ({
    id: a.id,
    patient_id: a.patient_id,
    patient_name: a.patient_name,
    doctor_id: a.doctor_id,
    doctor_name: a.doctor_name ?? "-",
    room_id: a.room_id,
    start_time: a.start_time,
    duration_minutes: a.duration_minutes,
    status: a.status as "booked" | "attended" | "done" | "cancelled" | "no_show",
    notes: a.notes,
    needs_billing: a.status === "done" && !billedApptIds.has(a.id),
    pending_service_id: a.pending_service_id,
    pending_service_name: a.pending_service_name,
    pending_price: a.pending_price,
    pending_discount_percent: a.pending_discount_percent,
    needs_new_photos: needsPhotosMap.get(a.patient_id) ?? false,
    needs_treatment: needsTreatmentMap.get(a.id) ?? false,
    purpose_type: a.purpose_type,
    purpose_service_id: a.purpose_service_id,
    purpose_service_name: a.purpose_service_name,
    purpose_service_category: a.purpose_service_category,
    purpose_linked_invoice_id: a.purpose_linked_invoice_id,
    is_ortho_patient: orthoPatientIds.has(a.patient_id),
  }));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h1 className="text-xl font-bold">الاستقبال</h1>
        <div className="flex items-center gap-2 flex-wrap">
          {/* أسرع طريق لتسجيل مريض جديد من نفس شاشة الاستقبال الرئيسية، من غير ما
              يحتاج يروح لصفحة "ملفات المرضى" الأول. من دفعة 21: التنقل بقى في نفس
              التاب (طلب المستخدم صراحة إن السيستم كله تاب واحد) — بعد الحفظ بيرجّع
              لملف المريض، وممكن الرجوع لجدول الاستقبال بزرار الرجوع في المتصفح أو
              لينك "الاستقبال" في القايمة العلوية. */}
          <Link
            href="/patients/new"
            className="px-3 py-1.5 rounded-md btn-3d-primary text-sm"
          >
            + مريض جديد
          </Link>
          <DateFilterForm day={day} />
          {canEditSchedule && visibleRooms.length > 0 && (
            <ExceptionalShiftButton date={day} rooms={visibleRooms} doctors={doctors} existing={exceptionalShifts} />
          )}
        </div>
      </div>

      {/* الجدول المركزي: كل الغرف/العيادات في مكان واحد، بيتزامن أوتوماتيك بين أي شاشات استقبال تانية مفتوحة */}
      <section className="space-y-2">
        {visibleRooms.length === 0 ? (
          <div className="text-sm bg-danger-soft text-danger rounded-md px-3 py-2">
            مفيش شيفت أسبوعي مسجل ليك في يوم النهاردة — كلم الأدمن لو محتاج تشوف الجدول برضه.
          </div>
        ) : (
          <CentralSchedule
            date={day}
            rooms={visibleRooms}
            timeSlots={timeSlots}
            slotMinutes={slotMinutes}
            appointments={appointments}
            patients={patients}
            doctors={doctors}
            services={services}
            canEdit={canEditSchedule}
            canCollectPayments={canCollectPayments}
            canEditAssistantDoctor={canEditAssistantDoctor}
            isDoctorView={session?.role === "doctor"}
            roomShiftDoctorIds={roomShiftDoctorIds}
            canQuickAddService={canQuickAddService}
            canBackdateInvoice={canBackdateInvoice}
          />
        )}
      </section>
    </div>
  );
}
