"use server";

import { cookies, headers } from "next/headers";
import { db } from "@/lib/db/client";
import { SESSION_COOKIE, createSessionToken, verifyPassword } from "@/lib/auth";

export type LoginState = {
  error?: "missing" | "invalid";
  redirectTo?: string;
};

// NOTE: We intentionally do NOT call redirect() from inside this Server
// Action. Next.js's fetch-based Server Action redirect path (used whenever
// the client has JS enabled) resolves the redirect via an internal loopback
// request and then copies that loopback response's headers onto the outer
// response - but it explicitly excludes `set-cookie` when doing so. That
// silently drops the session cookie we just set a few lines above, which is
// why the browser looked logged-out immediately after a successful login.
// Returning state and letting the client navigate avoids that code path
// entirely: the Set-Cookie header rides on this action's own direct
// response, which does not go through the loopback-and-strip logic.
export async function loginAction(
  _prevState: LoginState,
  formData: FormData
): Promise<LoginState> {
  const username = String(formData.get("username") || "").trim();
  const password = String(formData.get("password") || "");
  const next = String(formData.get("next") || "/");

  if (!username || !password) {
    return { error: "missing" };
  }

  const user = await db
    .selectFrom("users")
    .selectAll()
    .where("username", "=", username)
    .where("active", "=", 1)
    .executeTakeFirst();

  if (!user || !(await verifyPassword(password, user.password_hash))) {
    return { error: "invalid" };
  }

  const token = await createSessionToken({
    userId: user.id,
    username: user.username,
    fullName: user.full_name,
    role: user.role,
    doctorId: user.doctor_id,
  });

  // Only mark the cookie Secure when the request actually arrived over HTTPS.
  // Browsers silently refuse to store Secure cookies on a plain-HTTP connection,
  // which (before this fix) caused every post-login request to look logged-out.
  const hdrs = await headers();
  const isHttps = hdrs.get("x-forwarded-proto") === "https";

  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: isHttps,
    path: "/",
    maxAge: 60 * 60 * 12,
  });

  return { redirectTo: next && next.startsWith("/") ? next : "/" };
}
