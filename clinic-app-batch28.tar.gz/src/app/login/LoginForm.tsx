"use client";

import { useActionState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { loginAction, type LoginState } from "./actions";

const ERROR_MESSAGES: Record<string, string> = {
  invalid: "اسم المستخدم أو كلمة السر غير صحيحة.",
  missing: "من فضلك أدخل اسم المستخدم وكلمة السر.",
};

const initialState: LoginState = {};

export default function LoginForm({ next }: { next: string }) {
  const router = useRouter();
  const [state, formAction, isPending] = useActionState(loginAction, initialState);

  useEffect(() => {
    if (state.redirectTo) {
      // Full navigation (not router.push) so the browser re-requests the
      // destination with the session cookie the login action just set,
      // guaranteeing proxy.ts sees it on the very first load.
      window.location.assign(state.redirectTo);
    }
  }, [state.redirectTo]);

  return (
    <form action={formAction} className="space-y-4">
      <input type="hidden" name="next" value={next} />

      {state.error && (
        <div className="mb-4 rounded-md bg-danger-soft text-danger text-sm px-3 py-2">
          {ERROR_MESSAGES[state.error] || "حصل خطأ، حاول تاني."}
        </div>
      )}

      <div>
        <label className="block text-sm text-muted mb-1" htmlFor="username">
          اسم المستخدم
        </label>
        <input
          id="username"
          name="username"
          autoComplete="username"
          required
          className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>
      <div>
        <label className="block text-sm text-muted mb-1" htmlFor="password">
          كلمة السر
        </label>
        <input
          id="password"
          name="password"
          type="password"
          autoComplete="current-password"
          required
          className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>
      <button
        type="submit"
        disabled={isPending}
        className="w-full rounded-md btn-3d-primary py-2 text-sm font-medium transition-colors disabled:opacity-60"
      >
        {isPending ? "جارٍ الدخول..." : "دخول"}
      </button>
    </form>
  );
}
