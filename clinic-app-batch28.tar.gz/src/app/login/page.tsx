import LoginForm from "./LoginForm";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string }>;
}) {
  const { next } = await searchParams;

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="w-full max-w-sm card-3d rounded-xl shadow-sm p-8">
        <div className="text-center mb-6">
          <div className="text-2xl font-bold text-primary">عيادتي</div>
          <div className="text-sm text-muted mt-1">تسجيل الدخول إلى نظام إدارة العيادة</div>
        </div>

        <LoginForm next={next || "/"} />
      </div>
    </div>
  );
}
