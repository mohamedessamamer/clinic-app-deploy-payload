"use server";

import { cookies } from "next/headers";
import { SESSION_COOKIE } from "@/lib/auth";

// NOTE: Logout used to be a plain GET route (`/logout`) reached via a normal
// <Link href="/logout">. That was the real cause of "login works, but
// clicking any nav link sends me back to login": Next.js's <Link> automatically
// prefetches every link visible on the page (not just the one the user clicks),
// so the moment the dashboard rendered, it silently prefetched /logout in the
// background - and the GET handler unconditionally deleted the session cookie
// on every request, logged-in user or not. The fix is the same pattern used
// for login: make logout a Server Action (only runs on an explicit form
// submit, never prefetched) instead of a GET-able route, and let the client
// navigate to /login only after the action's own response has cleared the
// cookie.
export async function logoutAction() {
  const store = await cookies();
  store.delete(SESSION_COOKIE);
}
