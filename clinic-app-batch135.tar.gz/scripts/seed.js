// Seed script — creates demo data so the app is clickable immediately.
// Run with: node scripts/seed.js
const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");

const DB_PATH = process.env.CLINIC_DB_PATH || path.join(process.cwd(), "data", "clinic.db");
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);
db.pragma("foreign_keys = ON");
db.exec(fs.readFileSync(path.join(process.cwd(), "src", "lib", "db", "schema.sql"), "utf-8"));

function upsertDoctor(name) {
  const existing = db.prepare("SELECT id FROM doctors WHERE full_name = ?").get(name);
  if (existing) return existing.id;
  return db.prepare("INSERT INTO doctors (full_name) VALUES (?)").run(name).lastInsertRowid;
}

function upsertRoom(name) {
  const existing = db.prepare("SELECT id FROM rooms WHERE name = ?").get(name);
  if (existing) return existing.id;
  return db.prepare("INSERT INTO rooms (name) VALUES (?)").run(name).lastInsertRowid;
}

function upsertService(name, price) {
  const existing = db.prepare("SELECT id FROM services WHERE name = ?").get(name);
  if (existing) return existing.id;
  return db.prepare("INSERT INTO services (name, default_price) VALUES (?, ?)").run(name, price).lastInsertRowid;
}

function linkServiceDoctor(serviceId, doctorId) {
  db.prepare(
    "INSERT OR IGNORE INTO service_doctors (service_id, doctor_id) VALUES (?, ?)"
  ).run(serviceId, doctorId);
}

function upsertUser({ username, password, fullName, role, doctorId }) {
  const existing = db.prepare("SELECT id FROM users WHERE username = ?").get(username);
  if (existing) return existing.id;
  const hash = bcrypt.hashSync(password, 10);
  return db
    .prepare(
      "INSERT INTO users (username, password_hash, full_name, role, doctor_id) VALUES (?, ?, ?, ?, ?)"
    )
    .run(username, hash, fullName, role, doctorId || null).lastInsertRowid;
}

const drMohamed = upsertDoctor("د. محمد");
const drKareem = upsertDoctor("د. كريم");

const room1 = upsertRoom("عيادة رقم ١");
const room2 = upsertRoom("عيادة رقم ٢");

const svcCheckup = upsertService("كشف عام", 150);
const svcFilling = upsertService("حشو", 300);
const svcCleaning = upsertService("تنظيف", 200);

[svcCheckup, svcFilling, svcCleaning].forEach((s) => {
  linkServiceDoctor(s, drMohamed);
});
linkServiceDoctor(svcCheckup, drKareem);
linkServiceDoctor(svcFilling, drKareem);

upsertUser({ username: "admin", password: "admin123", fullName: "مدير النظام", role: "admin" });
upsertUser({ username: "reception", password: "reception123", fullName: "موظف الاستقبال", role: "reception" });
upsertUser({ username: "dr.mohamed", password: "doctor123", fullName: "د. محمد", role: "doctor", doctorId: drMohamed });
upsertUser({ username: "dr.kareem", password: "doctor123", fullName: "د. كريم", role: "doctor", doctorId: drKareem });

// A demo patient with a visit + invoice so the UI isn't empty on first run.
let patient = db.prepare("SELECT id FROM patients WHERE file_number = ?").get("P-0001");
if (!patient) {
  const id = db
    .prepare(
      "INSERT INTO patients (file_number, full_name, age, phone, address) VALUES (?, ?, ?, ?, ?)"
    )
    .run("P-0001", "أحمد علي", 34, "01000000000", "القاهرة").lastInsertRowid;
  patient = { id };

  const visitId = db
    .prepare(
      `INSERT INTO visits (patient_id, visit_date, service_id, notes, primary_doctor_id, performing_doctor_id, room_id)
       VALUES (?, date('now'), ?, ?, ?, ?, ?)`
    )
    .run(patient.id, svcCheckup, "كشف أولي، الحالة عادية.", drMohamed, drMohamed, room1).lastInsertRowid;

  // Batch 124: الفاتورة بقت سجل مالي مستقل مربوط بالمريض (patient_id مطلوب)،
  // وربط الزيارة اختياري — السطر القديم كان بيكسر seed على السكيمة الحالية.
  db.prepare(
    "INSERT INTO invoices (visit_id, patient_id, doctor_id, service_id, amount, paid) VALUES (?, ?, ?, ?, ?, ?)"
  ).run(visitId, patient.id, drMohamed, svcCheckup, 150, 100);
}

console.log("Seed complete.");
console.log("Users: admin/admin123, reception/reception123, dr.mohamed/doctor123, dr.kareem/doctor123");
