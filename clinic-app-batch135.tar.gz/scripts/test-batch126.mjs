// Batch 126 browser integration test (local only).
// Checks, on the real app with real clinic photos:
//   1. one upload => ONE group (no Photos/Xray split any more),
//   2. the gallery order is Extra-Oral -> Intra-Oral -> X-ray -> Templates,
//      and inside each section the agreed order (frontal, profile, 45°, ...),
//   3. the patient file photo is an INDEPENDENT smaller copy: deleting the
//      image it came from works without a crash and the photo stays,
//   4. the template sheet shows 3 cells per row with a fixed ratio (no stretch),
//   5. staged files in the upload dialog show real thumbnails.
//
// Run: CLINIC_DB_PATH=test-data/clinic.db npx next start -p 3126, then
//      FIXTURES=<folder> node scripts/test-batch126.mjs
import assert from "node:assert/strict";
import path from "node:path";
import fs from "node:fs";
import Database from "better-sqlite3";
import { SignJWT } from "jose";
import { chromium } from "playwright";

// نفس ترتيب src/lib/images/order.ts (متكرر هنا عشان السكربت يشتغل بـnode عادي).
const KIND_ORDER = ["face_frontal","face_smile","face_profile","face_oblique","intraoral_front","intraoral_right","intraoral_left","intraoral_upper","intraoral_lower","xray_pano","xray_ceph","xray_other","template_sheet","other"];
const SECTION_ORDER = ["extraoral", "intraoral", "xray", "templates"];
function sectionOf(kind) {
  if (kind === "template_sheet") return "templates";
  if (kind && kind.startsWith("xray")) return "xray";
  if (kind && kind.startsWith("intraoral")) return "intraoral";
  return "extraoral";
}
function imageSortRank(kind) {
  const index = KIND_ORDER.indexOf(kind);
  return SECTION_ORDER.indexOf(sectionOf(kind)) * 100 + (index === -1 ? KIND_ORDER.length : index);
}

const BASE = process.env.TEST_BASE_URL || "http://localhost:3126";
const SECRET = process.env.TEST_SESSION_SECRET || "batch122-local-test-only-secret-at-least-32";
const FIXTURES = process.env.FIXTURES || "test-data/fixtures";
const dbPath = path.resolve("test-data/clinic.db");
assert(dbPath.includes(path.sep + "test-data" + path.sep), "test DB only");
const db = new Database(dbPath);
const suffix = Date.now();
const adminId = Number(db.prepare("INSERT INTO users(username,password_hash,full_name,role,must_change_password) VALUES (?, 'unused', 'admin', 'admin', 0)").run("admin126_" + suffix).lastInsertRowid);
db.prepare("INSERT OR REPLACE INTO user_permissions VALUES (?, 'view_home_dashboard', 1)").run(adminId);
const patientId = Number(db.prepare("INSERT INTO patients(file_number,full_name,phone,birth_date) VALUES (?,?,?,?)").run("T126-" + suffix, "مريض ترتيب الصور", "01000000004", "2008-01-01").lastInsertRowid);

const files = fs.readdirSync(FIXTURES).filter((name) => /\.(png|jpe?g)$/i.test(name)).sort().map((name) => path.resolve(FIXTURES, name));
assert(files.length >= 6, "need sample images in " + FIXTURES);

const rows = () => db.prepare(
  "SELECT pi.*, g.label FROM patient_images pi JOIN patient_image_groups g ON g.id = pi.group_id WHERE g.patient_id = ? ORDER BY pi.id"
).all(patientId);
const patient = () => db.prepare("SELECT * FROM patients WHERE id = ?").get(patientId);
const uploadDir = process.env.CLINIC_UPLOAD_DIR || "data/uploads";
const diskOf = (publicPath) => path.join(uploadDir, publicPath.replace("/patient-files/", ""));
async function until(predicate, message) {
  for (let n = 0; n < 400; n += 1) { if (predicate()) return; await new Promise((r) => setTimeout(r, 200)); }
  assert(predicate(), message);
}

const browser = await chromium.launch({ headless: true, ...(process.env.CHROME_PATH ? { executablePath: process.env.CHROME_PATH } : {}) });
fs.mkdirSync("test-data/screenshots", { recursive: true });
const errors = [];
try {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  const token = await new SignJWT({ userId: adminId, username: "admin126", fullName: "admin", role: "admin", doctorId: null, sessionVersion: 0 })
    .setProtectedHeader({ alg: "HS256" }).setIssuedAt().setExpirationTime("1h").sign(new TextEncoder().encode(SECRET));
  await context.addCookies([{ name: "clinic_session", value: token, url: BASE }]);
  const page = await context.newPage();
  page.on("pageerror", (e) => errors.push(e.message));

  await page.goto(`${BASE}/patients/${patientId}/orthodontics`);
  const input = page.locator('input[type="file"]').first();
  await input.waitFor({ state: "attached" });
  await input.setInputFiles(files);

  // 5) staged thumbnails are real previews, not empty boxes
  const thumbs = page.locator('img[src^="blob:"]');
  await thumbs.first().waitFor();
  assert.equal(await thumbs.count(), files.length, "every staged file shows a thumbnail");
  const thumbBox = await thumbs.first().boundingBox();
  assert(thumbBox && thumbBox.width > 20 && thumbBox.height > 20, "thumbnail is actually rendered");

  await page.locator('input[placeholder="Eg.: Panorama"]').first().fill("Pre");
  await page.getByRole("button", { name: /Upload \(/ }).first().click();
  await until(() => rows().length === files.length, "all files uploaded");

  // 1) exactly one group, named as typed (no " - Photos" / " - Xray" suffix)
  const labels = [...new Set(rows().map((row) => row.label))];
  assert.deepEqual(labels, ["Pre"], "one group only: " + JSON.stringify(labels));
  const groupIds = [...new Set(rows().map((row) => row.group_id))];
  assert.equal(groupIds.length, 1, "one group id");

  // 2) ordering rule: sections in order and the agreed order inside each
  const ranks = rows().map((row) => imageSortRank(row.image_kind));
  const sections = rows().map((row) => sectionOf(row.image_kind));
  console.log("sections:", JSON.stringify(sections));
  const sortedRanks = [...ranks].sort((a, b) => a - b);
  assert(ranks.length === sortedRanks.length, "rank list built");
  // the gallery renders in this sorted order — check it in the DOM below.

  await page.reload();
  const galleryKinds = await page.locator("[data-image-kind]").evaluateAll((nodes) => nodes.map((node) => node.getAttribute("data-image-kind")));
  if (galleryKinds.length) {
    const galleryRanks = galleryKinds.map((kind) => imageSortRank(kind));
    assert.deepEqual(galleryRanks, [...galleryRanks].sort((a, b) => a - b), "gallery strip follows the agreed order: " + JSON.stringify(galleryKinds));
  }

  // 3) file photo is an independent smaller copy
  await until(() => patient().avatar_path, "patient file photo created");
  const avatarPath = patient().avatar_path;
  const sourceId = patient().avatar_image_id;
  const source = db.prepare("SELECT * FROM patient_images WHERE id = ?").get(sourceId);
  assert(fs.existsSync(diskOf(avatarPath)), "file photo written: " + avatarPath);
  assert.notEqual(diskOf(avatarPath), diskOf(source.file_path), "file photo is a separate file");
  assert(fs.statSync(diskOf(avatarPath)).size < fs.statSync(diskOf(source.file_path)).size, "file photo is smaller than the original");

  // deleting the source image must not crash and must not break the file photo
  await page.goto(`${BASE}/patients/${patientId}`);
  const beforeDelete = rows().length;
  page.once("dialog", (dialog) => dialog.accept());
  const deleteButton = page.locator(`[data-delete-image="${sourceId}"]`).first();
  await deleteButton.click({ force: true });
  await until(() => rows().length === beforeDelete - 1, "source image deleted without a crash");
  assert.equal(patient().avatar_path, avatarPath, "file photo survives deleting its source image");
  assert(fs.existsSync(diskOf(avatarPath)), "file photo file still on disk");
  assert.deepEqual(errors, [], "no page errors: " + JSON.stringify(errors));

  // 4) template sheet: 3 per row, fixed ratio, image never stretched
  await page.goto(`${BASE}/patients/${patientId}/orthodontics`);
  const templateButton = page.getByRole("button", { name: /template/i }).first();
  await templateButton.click();
  await page.locator(".image-template-sheet").first().waitFor();
  const columns = await page.locator(".image-template-sheet").first().evaluate((node) => getComputedStyle(node).gridTemplateColumns.split(" ").length);
  assert.equal(columns, 3, "three images per row, got " + columns);
  const cellStyle = await page.locator(".image-template-cell img").first().evaluate((node) => {
    const style = getComputedStyle(node);
    return { fit: style.objectFit, ratio: style.aspectRatio };
  });
  assert.equal(cellStyle.fit, "contain", "images keep their real proportions (never stretched)");
  assert(cellStyle.ratio.replace(/\s/g, "") === "4/3", "every cell has the same fixed ratio: " + cellStyle.ratio);
  const titles = await page.locator(".image-template-section-title").evaluateAll((nodes) => nodes.map((node) => node.textContent.trim()));
  const expectedOrder = ["Extra-Oral", "Intra-Oral", "X-ray", "Templates"].filter((title) => titles.includes(title));
  assert.deepEqual(titles, expectedOrder, "sections in order: " + JSON.stringify(titles));
  await page.screenshot({ path: "test-data/screenshots/b126-template.png", fullPage: false });

  assert.deepEqual(errors, [], "no page errors");
  const summary = rows().reduce((counts, row) => ({ ...counts, [row.image_kind || "unknown"]: (counts[row.image_kind || "unknown"] || 0) + 1 }), {});
  console.log("kinds:", JSON.stringify(summary));
  console.log("PASS batch 126: one ordered group, independent file photo, 3-per-row fixed-ratio template, real upload thumbnails.");
} finally { await browser.close(); db.close(); }
