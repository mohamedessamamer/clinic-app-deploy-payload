// Batch 125 diagnostic: prints the image-analysis numbers for a folder of images.
// No image data leaves the machine - only measurements and the guessed type.
//
// Run (from the app folder):
//   node --experimental-strip-types scripts/classify-report.mjs "C:\path\to\photos"
//
// Then paste the table back so the thresholds can be tuned on real clinic photos.
import fs from "node:fs";
import path from "node:path";
import { extractFeatures, familyOf, kindOf } from "../src/lib/images/classify.ts";

const dir = process.argv[2];
if (!dir) {
  console.error('usage: node --experimental-strip-types scripts/classify-report.mjs "<folder with images>"');
  process.exit(1);
}

const files = fs.readdirSync(dir)
  .filter((name) => /\.(jpe?g|png|webp|gif)$/i.test(name))
  .sort();
if (!files.length) {
  console.error("no images found in " + dir);
  process.exit(1);
}

const pad = (value, width) => String(value).padEnd(width);
const num = (value, digits = 3) => Number(value).toFixed(digits);

// Batch 127: ضيفنا الأعمدة اللي كانت ناقصة (balance, teethWhite, gridBands,
// mixedCells) — دي بالظبط اللي بتفرق بين face_frontal/face_smile وface_oblique،
// وبين template (تمبلت جاهز) وباقي التصنيفات. من غيرهم مينفعش نشخّص ليه صورة
// وش واضحة اتصنفت 45 درجة، أو ليه تمبلت جاهز مااتكشفش.
console.log(pad("file", 28), pad("family", 10), pad("kind", 16), "asp   color skin  faceBlob red   redC  dark  sym   bal   mouth bright tTop  tLeft tWhite grid mixed");
console.log("-".repeat(160));

for (const name of files) {
  try {
    const { features: f } = await extractFeatures(path.join(dir, name));
    const family = familyOf(f);
    const { kind } = kindOf(f);
    console.log(
      pad(name.slice(0, 27), 28),
      pad(family, 10),
      pad(kind, 16),
      [num(f.aspect, 2), num(f.colorRatio), num(f.skinRatio), num(f.faceBlobRatio), num(f.redStrong),
       num(f.redCenter), num(f.darkRatio), num(f.symmetry), num(f.balance), num(f.mouthBright), num(f.brightCenter),
       num(f.teethTopHeavy, 2), num(f.teethLeftHeavy, 2), num(f.teethWhite), String(f.gridBands), String(f.mixedCells)].join(" ")
    );
  } catch (error) {
    console.log(pad(name.slice(0, 27), 28), "ERROR", error.message);
  }
}

console.log("\nIf you can, add a short note next to each row with what it really is");
console.log("(pano / ceph / face-frontal / face-smile / face-profile / intraoral-front / upper / lower / right / left).");
