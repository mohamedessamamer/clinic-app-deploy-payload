import { NextRequest, NextResponse } from "next/server";
import fs from "node:fs/promises";
import { createReadStream } from "node:fs";
import path from "node:path";
import { Readable } from "node:stream";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";

// بيقرأ صور/أشعة المرضى من القرص وقت الطلب نفسه، بدل ما يعتمد على مجلد "public"
// اللي Next.js بياخد له "لقطة" (snapshot) لأسماء الملفات مرة واحدة بس وقت ما
// السيرفر يشتغل — يعني أي صورة تترفع بعد كده (من غير إعادة تشغيل/نشر) كانت
// هترجع 404 دايمًا لحد أول إعادة تشغيل تالية. الراوت ده بيتجنب المشكلة دي
// تمامًا لأنه بيقرأ من القرص فعليًا في كل طلب.
const UPLOAD_ROOT = process.env.CLINIC_UPLOAD_DIR
  ? path.resolve(process.env.CLINIC_UPLOAD_DIR)
  : path.join(process.cwd(), "data", "uploads");

const CONTENT_TYPES: Record<string, string> = {
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".gif": "image/gif",
  ".webp": "image/webp",
  ".pdf": "application/pdf",
};

export async function GET(_req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  const session = await getSession();
  if (!session) {
    return new NextResponse("غير مصرح", { status: 401 });
  }

  const { path: segments } = await params;

  // مستندات HR (عقود، صور بطاقات، مستندات رواتب) بتتخزن تحت نفس جذر الرفع
  // وبيخدمها نفس الراوت ده. رفعها بيطلب manage_hr — فقراءتها لازم تطلبها كمان،
  // وإلا أي مستخدم مسجّل دخول يقدر يفتحها بمجرد معرفة الرابط.
  // صور وأشعة المرضى لها صلاحية مستقلة؛ الأدوار الطبية والاستقبال تأخذها
  // افتراضيًا، بينما الحسابات مثل المحاسب لا ترى الملف الطبي لمجرد تسجيل الدخول.
  if (segments[0] === "hr-documents") {
    if (!(await hasPermission(session.userId, session.role, "manage_hr"))) {
      return new NextResponse("غير مصرح", { status: 403 });
    }
  } else if (segments[0] !== "patients" || !(await hasPermission(session.userId, session.role, "view_patient_files"))) {
    return new NextResponse("غير مصرح", { status: 403 });
  }

  // امنع أي محاولة صعود لمجلد أعلى (زي "..") عشان محدش يقدر يقرأ ملفات برة
  // مجلد الرفع المخصص.
  if (!segments.length || segments.some((s) => !s || s === "." || s === "..")) {
    return new NextResponse("غير موجود", { status: 404 });
  }

  const filePath = path.join(UPLOAD_ROOT, ...segments);
  if (filePath !== UPLOAD_ROOT && !filePath.startsWith(UPLOAD_ROOT + path.sep)) {
    return new NextResponse("غير موجود", { status: 404 });
  }

  try {
    const stat = await fs.stat(filePath);
    if (!stat.isFile()) return new NextResponse("غير موجود", { status: 404 });

    // Batch 128: كان الـCache-Control قديمًا "max-age=3600" من غير أي مُتحقّق
    // (ETag/Last-Modified) — يعني المتصفح كان بيعتبر الصورة "طازة" لمدة ساعة
    // كاملة ومش حتى بيبعت طلب للسيرفر يتأكد، حتى لو عمل المستخدم refresh
    // عادي أو قفل التطبيق وفتحه تاني (الكاش ده بيفضل محفوظ على مستوى
    // المتصفح، مش التاب). ده كان بيخلي أي تعديل حقيقي على بايتات الصورة
    // (زي التدوير اليدوي اللي بيكتب فوق نفس المسار) يفضل مستخبي عن المستخدم
    // لحد ما الساعة تعدي أو يعمل hard refresh (Ctrl+Shift+R) — يعني ممكن
    // يبان إن "التدوير مابيعملش حاجة" وهو في الحقيقة اتنفذ صح على السيرفر.
    // الإصلاح: ETag/Last-Modified مبنيين على وقت آخر تعديل فعلي للملف (mtime)
    // + حجمه، والمتصفح بقى لازم يتأكد (revalidate) في كل مرة — لو الملف زي
    // ما هو بنرجّع 304 (رخيصة، من غير بايتات)، ولو اتغيّر (بعد تدوير مثلًا)
    // الـmtime بيتغيّر تلقائيًا فالـETag يختلف والمتصفح بيجيب النسخة الجديدة
    // فورًا.
    const etag = `"${stat.mtimeMs.toString(36)}-${stat.size.toString(36)}"`;
    const lastModified = stat.mtime.toUTCString();
    const ifNoneMatch = _req.headers.get("if-none-match");
    const ifModifiedSince = _req.headers.get("if-modified-since");
    const notModified =
      (ifNoneMatch && ifNoneMatch === etag) ||
      (!ifNoneMatch && ifModifiedSince && new Date(ifModifiedSince).getTime() >= Math.floor(stat.mtimeMs / 1000) * 1000);
    if (notModified) {
      return new NextResponse(null, {
        status: 304,
        headers: {
          "Cache-Control": "private, no-cache, must-revalidate",
          ETag: etag,
          "Last-Modified": lastModified,
        },
      });
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = CONTENT_TYPES[ext] || "application/octet-stream";
    const stream = Readable.toWeb(createReadStream(filePath));
    return new NextResponse(stream as unknown as BodyInit, {
      headers: {
        "Content-Type": contentType,
        "Content-Length": String(stat.size),
        "Cache-Control": "private, no-cache, must-revalidate",
        ETag: etag,
        "Last-Modified": lastModified,
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch {
    return new NextResponse("غير موجود", { status: 404 });
  }
}
