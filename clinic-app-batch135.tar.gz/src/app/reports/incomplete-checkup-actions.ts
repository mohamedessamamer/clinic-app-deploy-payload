"use server";

import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getClinicToday } from "@/lib/clinic-date";

// تقرير "الكشوفات غير المكتملة": مرضى عملوا كشف في الفترة المختارة لكن معندهمش
// أي خدمة تانية مسجّلة طول تاريخهم — يعني اتكشفوا وما رجعوش يكملوا علاج.
//
// دفعة 134 — إعادة بناء بعد ثلاث مشاكل اتكشفت في الاستخدام الحقيقي:
//
// 1) التعريف كان بالاسم (`services.name = 'كشف'`). العيادة فصلت الكشف لنوعين
//    بأسماء جديدة (كشف استشاري / كشف عام)، فالتقرير فضل يدوّر على اسم مابقاش
//    موجود ورجع فاضي من غير أي رسالة. دلوقتي التعريف بالكود (1 و 5) — الكود هو
//    الهوية الثابتة للخدمة، والاسم بيتغير. CHECKUP_SERVICE_CODES تحت هي المكان
//    الوحيد اللي بيتعدّل لو اتضافت خدمة كشف تالتة.
//
// 2) الشرط كان `invoices.paid > 0`. الكشف ساعات بيبقى مجاني أو بيتقفل بـ"تم
//    بدون دفع" — والحالتين دول بالظبط هما اللي محتاجين متابعة أكتر من غيرهم،
//    وكانوا بيتشالوا من التقرير. دلوقتي الكشف بيتحسب من أي مصدر: زيارة، أو
//    فاتورة، أو موعد اتقفل بـ«تم بدون دفع» (ده مابيعملش زيارة ولا فاتورة أصلاً،
//    فكان بيختفي تمامًا).
//
// 3) الكشف كان بيظهر في التقرير من يومه. دلوقتي في مهلة 3 أيام — طبيعي إن
//    المريض ياخد كام يوم قبل ما يبدأ علاج، فمن غير المهلة دي التقرير بيمتلي
//    بحالات لسه مابقتش "متأخرة" فعلاً.

/** أكواد خدمات الكشف. الكود هو المعرّف الثابت — الأسماء بتتغير. */
const CHECKUP_SERVICE_CODES = ["1", "5"];

/** عدد الأيام اللي لازم تعدي على الكشف قبل ما يتحسب "غير مكتمل". */
const GRACE_DAYS = 3;

export type IncompleteCheckupRow = {
  /** مفتاح مركّب (مريض + تاريخ) — الكشف ممكن يكون جاي من زيارة أو فاتورة أو
   *  موعد، فمفيش رقم صف واحد يصلح كمعرّف عبر المصادر التلاتة. */
  key: string;
  patientId: number;
  patientName: string;
  fileNumber: string;
  checkupDate: string;
  checkupName: string;
  doctorName: string;
  phone: string;
  /** إزاي اتسجّل الكشف — بيساعد الاستقبال يفهم الصف اللي مالوش فاتورة. */
  source: "زيارة" | "فاتورة" | "تم بدون دفع";
};

export type IncompleteCheckupResult =
  | { ok: false; error: string }
  | { ok: true; rows: IncompleteCheckupRow[]; effectiveTo: string; graceDays: number };

const DATE = /^\d{4}-\d{2}-\d{2}$/;

/** تاريخ "اليوم ناقص n" بتوقيت العيادة، بصيغة YYYY-MM-DD. */
function clinicDateMinusDays(days: number): string {
  const [y, m, d] = getClinicToday().split("-").map(Number);
  const shifted = new Date(Date.UTC(y, m - 1, d - days));
  return shifted.toISOString().slice(0, 10);
}

export async function getIncompleteCheckupReportAction(params: { from: string; to: string }): Promise<IncompleteCheckupResult> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "view_patient_reports"))) {
    return { ok: false, error: "مفيش صلاحية عندك لعرض تقرير الكشوفات غير المكتملة." };
  }
  if (!DATE.test(params.from) || !DATE.test(params.to)) {
    return { ok: false, error: "التاريخ غير صحيح." };
  }
  if (params.to < params.from) {
    return { ok: false, error: "تاريخ النهاية لازم يكون بعد تاريخ البداية." };
  }

  // مهلة الـ3 أيام: أي كشف أحدث من كده لسه في وقته، فبنقص نهاية الفترة عندها.
  // بنرجّع effectiveTo للواجهة عشان توضّح للمستخدم إن الفترة اتقصّت — من غير
  // كده الرقم بيبان ناقص من غير سبب ظاهر.
  const cutoff = clinicDateMinusDays(GRACE_DAYS);
  const effectiveTo = params.to < cutoff ? params.to : cutoff;
  if (effectiveTo < params.from) {
    return { ok: true, rows: [], effectiveTo, graceDays: GRACE_DAYS };
  }

  const checkupServices = await db
    .selectFrom("services")
    .select(["id", "name"])
    .where("code", "in", CHECKUP_SERVICE_CODES)
    .execute();
  const checkupServiceIds = checkupServices.map((service) => service.id);
  if (!checkupServiceIds.length) {
    return { ok: false, error: `مفيش خدمة كشف معرّفة بالأكواد (${CHECKUP_SERVICE_CODES.join("، ")}). راجع أكواد الخدمات في الإعدادات.` };
  }
  const checkupNames = new Map(checkupServices.map((service) => [service.id, service.name]));

  // الكشف ممكن يتسجّل بتلات طرق مختلفة، وكل واحدة منها لوحدها ناقصة:
  //   - زيارة: الحالة العادية.
  //   - فاتورة من غير زيارة: تحصيل اتسجّل من الاستقبال مباشرة.
  //   - موعد اتقفل بـ«تم بدون دفع»: مابيعملش زيارة ولا فاتورة خالص.
  // بنجيب التلاتة وبنوحّدهم، والتكرار بيتشال بمفتاح (مريض + تاريخ).
  const [checkupVisits, checkupInvoices, checkupAppointments] = await Promise.all([
    db
      .selectFrom("visits")
      .innerJoin("patients", "patients.id", "visits.patient_id")
      .leftJoin("doctors", "doctors.id", "visits.performing_doctor_id")
      .select([
        "visits.patient_id",
        "visits.visit_date as event_date",
        "visits.service_id",
        "patients.full_name as patient_name",
        "patients.file_number",
        "patients.phone",
        "doctors.full_name as doctor_name",
      ])
      .where("visits.service_id", "in", checkupServiceIds)
      .where("visits.visit_date", ">=", params.from)
      .where("visits.visit_date", "<=", `${effectiveTo} 23:59:59`)
      .execute(),

    db
      .selectFrom("invoices")
      .innerJoin("patients", "patients.id", "invoices.patient_id")
      .leftJoin("doctors", "doctors.id", "invoices.doctor_id")
      .select([
        "invoices.patient_id",
        "invoices.invoice_date as event_date",
        "invoices.service_id",
        "patients.full_name as patient_name",
        "patients.file_number",
        "patients.phone",
        "doctors.full_name as doctor_name",
      ])
      .where("invoices.service_id", "in", checkupServiceIds)
      .where("invoices.parent_invoice_id", "is", null)
      .where("invoices.invoice_date", ">=", params.from)
      .where("invoices.invoice_date", "<=", `${effectiveTo} 23:59:59`)
      .execute(),

    db
      .selectFrom("appointments")
      .innerJoin("patients", "patients.id", "appointments.patient_id")
      .leftJoin("doctors", "doctors.id", "appointments.doctor_id")
      .select([
        "appointments.patient_id",
        "appointments.appointment_date as event_date",
        "appointments.pending_service_id as service_id",
        "patients.full_name as patient_name",
        "patients.file_number",
        "patients.phone",
        "doctors.full_name as doctor_name",
      ])
      .where("appointments.pending_service_id", "in", checkupServiceIds)
      .where("appointments.completed_without_payment", "=", 1)
      .where("appointments.appointment_date", ">=", params.from)
      .where("appointments.appointment_date", "<=", effectiveTo)
      .execute(),
  ]);

  // ترتيب الأولوية مقصود: الزيارة أدق من الفاتورة (فيها الطبيب اللي عمل الخدمة
  // فعلاً)، والفاتورة أدق من الموعد. أول مصدر بيكتب المفتاح هو اللي بيفضل.
  type Event = { patientId: number; date: string; serviceId: number | null; name: string; file: string; phone: string | null; doctor: string | null; source: IncompleteCheckupRow["source"] };
  const events = new Map<string, Event>();
  const push = (rows: typeof checkupVisits, source: IncompleteCheckupRow["source"]) => {
    for (const row of rows) {
      const date = String(row.event_date).slice(0, 10);
      const key = `${row.patient_id}|${date}`;
      if (events.has(key)) continue;
      events.set(key, {
        patientId: row.patient_id,
        date,
        serviceId: row.service_id,
        name: row.patient_name,
        file: row.file_number,
        phone: row.phone,
        doctor: row.doctor_name,
        source,
      });
    }
  };
  push(checkupVisits, "زيارة");
  push(checkupInvoices as typeof checkupVisits, "فاتورة");
  push(checkupAppointments as typeof checkupVisits, "تم بدون دفع");

  if (!events.size) return { ok: true, rows: [], effectiveTo, graceDays: GRACE_DAYS };

  const patientIds = [...new Set([...events.values()].map((event) => event.patientId))];

  // "ماكملش علاج" = مفيش أي خدمة غير الكشف طول تاريخه، مش بس في الفترة
  // المختارة. وبنفحص التلات مصادر برضه — مريض بدأ علاج اتسجّل بفاتورة من غير
  // زيارة كان هيفضل ظاهر في التقرير بالغلط قبل كده.
  const [otherVisits, otherInvoices, otherAppointments] = await Promise.all([
    db
      .selectFrom("visits")
      .select(["patient_id"])
      .where("patient_id", "in", patientIds)
      .where((eb) => eb.or([eb("service_id", "is", null), eb("service_id", "not in", checkupServiceIds)]))
      .execute(),
    db
      .selectFrom("invoices")
      .select(["patient_id"])
      .where("patient_id", "in", patientIds)
      .where("parent_invoice_id", "is", null)
      .where("service_id", "is not", null)
      .where("service_id", "not in", checkupServiceIds)
      .execute(),
    db
      .selectFrom("appointments")
      .select(["patient_id"])
      .where("patient_id", "in", patientIds)
      .where("completed_without_payment", "=", 1)
      .where("pending_service_id", "is not", null)
      .where("pending_service_id", "not in", checkupServiceIds)
      .execute(),
  ]);
  const started = new Set<number>();
  for (const row of [...otherVisits, ...otherInvoices, ...otherAppointments]) {
    if (row.patient_id != null) started.add(row.patient_id);
  }

  const rows: IncompleteCheckupRow[] = [...events.values()]
    .filter((event) => !started.has(event.patientId))
    .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0))
    .map((event) => ({
      key: `${event.patientId}|${event.date}`,
      patientId: event.patientId,
      patientName: event.name,
      fileNumber: event.file,
      checkupDate: event.date,
      checkupName: (event.serviceId != null ? checkupNames.get(event.serviceId) : null) ?? "كشف",
      doctorName: event.doctor || "—",
      phone: event.phone || "—",
      source: event.source,
    }));

  return { ok: true, rows, effectiveTo, graceDays: GRACE_DAYS };
}
