"use server";

import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import {
  aggregate,
  getStatisticsSeries,
  halfMonths,
  monthLabel,
  quarterMonths,
  yearMonths,
  ARABIC_MONTHS,
  type Bucket,
  type MonthPoint,
} from "@/lib/statistics";

// دفعة 134 — تقرير الإحصائيات.
//
// كل الأوضاع بتقرا من سلسلة شهرية واحدة (lib/statistics.ts)، فالأرقام متطابقة
// بين الأوضاع بالضرورة. الوضع هنا بيحدّد بس إزاي الشهور بتتقسّم لفترات.

export type StatisticsMode =
  | "month"        // شهر مقابل شهر
  | "quarter"      // ربع مقابل ربع
  | "half"         // نص سنة مقابل نص سنة
  | "year"         // سنة بسنة — آخر N سنة
  | "same_month"   // نفس الشهر عبر السنين
  | "within_year"; // الشهر مقابل شهور سنته

export type StatisticsMetric = "collected" | "expenses" | "netCash";

export type StatisticsInsights = {
  /** أعلى 3 شهور في المؤشر المختار عبر المدى المعروض. */
  best: { ym: string; label: string; value: number }[];
  worst: { ym: string; label: string; value: number }[];
  /** متوسط الفترات المكتملة (بدون الفترة الجارية). */
  average: number | null;
  /** متوسط النمو من فترة للي بعدها، كنسبة مئوية. */
  averageGrowth: number | null;
};

export type StatisticsResult =
  | { ok: false; error: string }
  | {
      ok: true;
      mode: StatisticsMode;
      metric: StatisticsMetric;
      buckets: Bucket[];
      /** السلسلة الشهرية الخام — للخريطة الحرارية والرسوم التفصيلية. */
      months: MonthPoint[];
      expensesFrom: string | null;
      years: number[];
      insights: StatisticsInsights;
      /** المؤشر المطلوب مش متاح للمدى ده (مصروفات قبل ما تتسجّل). */
      metricUnavailable: boolean;
    };

export type StatisticsParams = {
  mode: StatisticsMode;
  metric: StatisticsMetric;
  /** سنة الفترة الأساسية. */
  year: number;
  /** الشهر (1..12) — للأوضاع اللي محتاجاه. */
  month: number;
  /** الربع (1..4) لوضع quarter، أو النص (1..2) لوضع half. */
  part: number;
  /** كام فترة تتعرض جنب بعض (سنوات في year/same_month). */
  span: number;
};

function valueOf(bucket: Bucket, metric: StatisticsMetric): number | null {
  return metric === "collected" ? bucket.collected : metric === "expenses" ? bucket.expenses : bucket.netCash;
}

/** الشهر السابق لـ"YYYY-MM". */
function previousMonth(ym: string): string {
  const [year, month] = ym.split("-").map(Number);
  return month === 1 ? `${year - 1}-12` : `${year}-${String(month - 1).padStart(2, "0")}`;
}

export async function getStatisticsReportAction(params: StatisticsParams): Promise<StatisticsResult> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "view_statistics_reports"))) {
    return { ok: false, error: "مفيش صلاحية عندك لعرض الإحصائيات." };
  }

  const series = await getStatisticsSeries();
  if (!series.months.length) return { ok: false, error: "مفيش بيانات كفاية لعرض إحصائيات." };

  const year = Number.isInteger(params.year) ? params.year : Number(series.lastMonth?.slice(0, 4));
  const month = Math.min(12, Math.max(1, Math.round(params.month || 1)));
  const part = Math.max(1, Math.round(params.part || 1));
  const span = Math.min(10, Math.max(2, Math.round(params.span || 5)));
  const metric: StatisticsMetric = params.metric ?? "collected";

  const yearsWithData = [...new Set(series.months.map((point) => Number(point.ym.slice(0, 4))))].sort((a, b) => b - a);

  let buckets: Bucket[] = [];

  if (params.mode === "month") {
    // الشهر المختار وقبله 5 شهور — الاتجاه القصير بيبان أوضح من مقارنة
    // شهرين لوحدهم، والمقارنة مع نفس الشهر السنة اللي فاتت موجودة في
    // وضع same_month.
    const base = `${year}-${String(month).padStart(2, "0")}`;
    const chain: string[] = [base];
    for (let index = 0; index < 5; index += 1) chain.unshift(previousMonth(chain[0]));
    buckets = chain.map((ym) => aggregate(series, ym, monthLabel(ym), [ym]));
  } else if (params.mode === "quarter") {
    const quarter = Math.min(4, part);
    buckets = Array.from({ length: span }, (_, index) => {
      const targetYear = year - (span - 1 - index);
      return aggregate(series, `${targetYear}-Q${quarter}`, `الربع ${quarter} ${targetYear}`, quarterMonths(targetYear, quarter));
    });
  } else if (params.mode === "half") {
    const half = Math.min(2, part);
    buckets = Array.from({ length: span }, (_, index) => {
      const targetYear = year - (span - 1 - index);
      return aggregate(series, `${targetYear}-H${half}`, `${half === 1 ? "النص الأول" : "النص التاني"} ${targetYear}`, halfMonths(targetYear, half));
    });
  } else if (params.mode === "year") {
    buckets = Array.from({ length: span }, (_, index) => {
      const targetYear = year - (span - 1 - index);
      return aggregate(series, String(targetYear), String(targetYear), yearMonths(targetYear));
    });
  } else if (params.mode === "same_month") {
    buckets = Array.from({ length: span }, (_, index) => {
      const targetYear = year - (span - 1 - index);
      const ym = `${targetYear}-${String(month).padStart(2, "0")}`;
      return aggregate(series, ym, `${ARABIC_MONTHS[month - 1]} ${targetYear}`, [ym]);
    });
  } else {
    // within_year: كل شهور السنة لحد الشهر المختار.
    buckets = Array.from({ length: month }, (_, index) => {
      const ym = `${year}-${String(index + 1).padStart(2, "0")}`;
      return aggregate(series, ym, ARABIC_MONTHS[index], [ym]);
    });
  }

  // فترة مالهاش أي شهر في السلسلة (سنة قبل ما العيادة تبدأ) بتتشال — عرضها
  // كصفر بيضلّل، وعرضها فاضية بيزحم الرسم.
  const firstMonth = series.firstMonth ?? "";
  buckets = buckets.filter((bucket) => bucket.months.some((ym) => ym >= firstMonth));

  // هل المؤشر المطلوب أصلاً متاح لكل الفترات المعروضة؟ لو لأ، الواجهة بتقول
  // السبب بدل ما تعرض جدول أعمدته فاضية من غير تفسير.
  const metricUnavailable = metric !== "collected" && buckets.every((bucket) => valueOf(bucket, metric) == null);

  // التحليلات بتتحسب على المؤشر المختار، وبتستثني الفترات الجارية (الشهر
  // الحالي ناقص بطبيعته، فحسابه في "أقل شهر" بيدي نتيجة غلط دايمًا).
  const complete = buckets.filter((bucket) => !bucket.partial && valueOf(bucket, metric) != null);
  const values = complete.map((bucket) => ({ ym: bucket.months[0], label: bucket.label, value: valueOf(bucket, metric) as number }));
  const sorted = [...values].sort((a, b) => b.value - a.value);

  let averageGrowth: number | null = null;
  if (complete.length >= 2) {
    const steps: number[] = [];
    for (let index = 1; index < complete.length; index += 1) {
      const before = valueOf(complete[index - 1], metric) as number;
      const after = valueOf(complete[index], metric) as number;
      if (before > 0) steps.push(((after - before) / before) * 100);
    }
    if (steps.length) averageGrowth = Math.round((steps.reduce((sum, step) => sum + step, 0) / steps.length) * 10) / 10;
  }

  const insights: StatisticsInsights = {
    best: sorted.slice(0, 3),
    worst: sorted.slice(-3).reverse(),
    average: values.length ? Math.round((values.reduce((sum, item) => sum + item.value, 0) / values.length) * 100) / 100 : null,
    averageGrowth,
  };

  return {
    ok: true,
    mode: params.mode,
    metric,
    buckets,
    months: series.months,
    expensesFrom: series.expensesFrom,
    years: yearsWithData,
    insights,
    metricUnavailable,
  };
}
