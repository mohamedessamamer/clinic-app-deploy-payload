import { Fragment } from "react";
import { notFound } from "next/navigation";
import Link from "next/link";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { paymentMethodLabel } from "@/lib/payment-methods";
import { displayAge } from "@/lib/age";
import { getClinicToday } from "@/lib/clinic-date";
import { formatPatientPhone } from "@/lib/phone";
import AddPatientServiceForm from "@/components/AddPatientServiceForm";
import PendingCollectionCard from "@/components/PendingCollectionCard";
import DeleteInvoiceButton from "@/components/DeleteInvoiceButton";
import EditInvoiceButton from "@/components/EditInvoiceButton";
import AdvancePaymentForm from "@/components/AdvancePaymentForm";
import EditPatientForm from "@/components/EditPatientForm";
import PatientAvatar from "@/components/PatientAvatar";

export default async function PatientBillingPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const patientId = Number(id);
  if (!patientId) notFound();

  const session = await getSession();
  if (!session) {
    return (
      <div className="card-3d rounded-xl p-5 text-sm text-muted">لازم تسجل دخول عشان توصل للملف المالي.</div>
    );
  }

  // الوصول للملف المالي محصور بصلاحية view_patient_billing الصريحة.
  // ماعدا الدكتور، عشان الدكتور ميشوفش بيانات مالية إلا لو اتمنحله الصلاحية دي
  // لوحده من الإعدادات. تحقق حقيقي هنا (مش بس إخفاء زرار "الملف المالي" في صفحة
  // الملف الطبي) عشان دخول مباشر بالرابط ميعديش الحماية.
  const canViewBilling = await hasPermission(session.userId, session.role, "view_patient_billing");
  if (!canViewBilling) {
    return (
      <div className="card-3d rounded-xl p-5 text-sm text-muted">
        مفيش صلاحية عندك لعرض الملف المالي — كلم الأدمن لو محتاج توصل له.
      </div>
    );
  }

  const patient = await db.selectFrom("patients").selectAll().where("id", "=", patientId).executeTakeFirst();
  if (!patient) notFound();
  const canViewPersonalData = await hasPermission(session.userId, session.role, "view_patient_personal_data");
  const canEditPatientInfo = canViewPersonalData && (await hasPermission(session.userId, session.role, "edit_patient_info"));

  // Doctors only ever see the services where they are the primary (revenue) doctor on the visit —
  // never the full financial picture across every doctor who treated this patient.
  const isDoctorScoped = session?.role === "doctor" && !!session.doctorId;

  // حذف خدمة/فاتورة اتسجلت غلط مباشرة من هنا (دفعة 21) — نفس صلاحية delete_visits
  // المستخدمة أصلاً لحذف زيارة من سجل الزيارات بالملف الطبي، مش صلاحية جديدة.
  const canDelete = await hasPermission(session.userId, session.role, "delete_visits");
  // تعديل صف الملف المالي (دفعة 106) — صلاحية منفصلة عن الحذف، الأدمن دايمًا عنده.
  const canEditBillingEntry = await hasPermission(session.userId, session.role, "edit_patient_billing_entry");

  // دفعة 27 (P2.3): "الطبيب المساعد" اتشال من عرض الملف المالي — الفصل الكامل
  // بين الملف الطبي والمالي بيقول إن الاستقبال يشوف بيانات التحصيل بس، ومين
  // نفّذ الخدمة فعليًا (performing_doctor_id) تفصيلة طبية مش مالية. العمود بقى
  // مش موجود هنا، فمفيش داعي لجوين جدول الأطباء التاني بتاعه أصلاً.
  let query = db
    .selectFrom("invoices")
    .leftJoin("services", "services.id", "invoices.service_id")
    .leftJoin("doctors", "doctors.id", "invoices.doctor_id")
    .select([
      "invoices.id",
      "invoices.visit_id",
      "invoices.amount",
      "invoices.paid",
      "invoices.discount_percent",
      "invoices.original_price",
      "invoices.payment_method",
      "invoices.parent_invoice_id",
      "invoices.invoice_date",
      "invoices.doctor_id",
      "invoices.service_id",
      "services.name as service_name",
      "doctors.full_name as doctor_name",
    ])
    .where("invoices.patient_id", "=", patientId)
    .orderBy("invoices.invoice_date", "desc");

  if (isDoctorScoped) {
    query = query.where("invoices.doctor_id", "=", session!.doctorId!);
  }

  const allInvoices = await query.execute();

  // فواتير "دفعات المتابعة" (amount=0, مربوطة بـ parent_invoice_id) بتتحط تحت فاتورتها
  // الأصلية بدل ما تتعرض كصف مستقل، وبتتخصم من "الباقي" بتاع الفاتورة الأصلية تحديدًا.
  const rootInvoices = allInvoices.filter((inv) => inv.parent_invoice_id == null);
  const followupsByParent = new Map<number, typeof allInvoices>();
  for (const inv of allInvoices) {
    if (inv.parent_invoice_id == null) continue;
    if (!followupsByParent.has(inv.parent_invoice_id)) followupsByParent.set(inv.parent_invoice_id, []);
    followupsByParent.get(inv.parent_invoice_id)!.push(inv);
  }

  const invoices = rootInvoices.map((inv) => {
    const followups = followupsByParent.get(inv.id) ?? [];
    const followupPaid = followups.reduce((sum, f) => sum + f.paid, 0);
    return { ...inv, followups, effectivePaid: inv.paid + followupPaid };
  });

  const totals = invoices.reduce(
    (acc, inv) => {
      acc.amount += inv.amount;
      acc.paid += inv.effectivePaid;
      return acc;
    },
    { amount: 0, paid: 0 }
  );

  // عدادات الخدمات فوق الجدول (دفعة 21) — "منتهية" يعني اتدفعت بالكامل (الباقي
  // صفر تقريبًا)، "جارية" يعني لسه عليها متبقي. دفعات المتابعة مش بتتحسب كخدمة
  // مستقلة (هي جزء من الفاتورة الأصلية اللي بتقفل رصيدها)، فالعدّاد بيتحسب من
  // rootInvoices بس زي ما هو ظاهر فعليًا كصف رئيسي في الجدول تحت.
  const serviceCounts = invoices.reduce(
    (acc, inv) => {
      acc.total += 1;
      if (inv.amount - inv.effectivePaid <= 0.01) acc.completed += 1;
      else acc.ongoing += 1;
      return acc;
    },
    { total: 0, completed: 0, ongoing: 0 }
  );

  // بيانات بوكس "إضافة خدمة" تحت — محصور بنفس صلاحية عرض الصفحة (view_patient_billing).
  const canAddService = canViewBilling;
  // دفعة 22: تحديد "الطبيب المساعد" وقت إضافة خدمة من هنا — نفس صلاحية سجل
  // الزيارات بالملف الطبي (edit_visit_assistant_doctor أو override_visit_doctor).
  const canEditAssistantDoctor =
    (await hasPermission(session.userId, session.role, "edit_visit_assistant_doctor")) ||
    (await hasPermission(session.userId, session.role, "override_visit_doctor"));
  // دفعة 21: بانر الموعد المعلّق بقى كارت مستقل بتفاصيل كاملة وفورم تحصيل خاص
  // بيه (PendingCollectionCard تحت) — مش بيتربط تلقائيًا ببوكس "إضافة خدمة" العادي
  // زي الأول. السبب: لو المريض جه تاني يعمل خدمة تانية خالص، الإضافة العادية
  // كانت (قبل كده) بتربط نفسها بالموعد المعلّق القديم وتقفل تنبيهه تلقائيًا حتى
  // لو الخدمة الجديدة مش هي نفسها المطلوبة أصلاً — يعني الدين القديم كان بيضيع
  // من غير ما حد ياخد باله. دلوقتي الاتنين مستقلين تمامًا: الكارت المعلّق بيتقفل
  // بس لما حد يحصّله هو نفسه بالتحديد، وبوكس "إضافة خدمة" العادي دايمًا بيسجل
  // زيارة جديدة مستقلة (appointment_id فاضي) بغض النظر عن وجود موعد معلّق.
  type PendingAppointmentData = {
    id: number;
    appointmentDate: string;
    doctorName: string | null;
    serviceId: number | null;
    serviceName: string | null;
    price: number | null;
    discountPercent: number | null;
  } | null;
  let addServiceData: {
    services: { id: number; name: string; code: string | null; default_price: number }[];
    doctors: { id: number; full_name: string }[];
    billableInvoices: { id: number; service_name: string; visit_date: string; balance: number }[];
    invoiceTargets: { id: number; service_name: string; visit_date: string; balance: number }[];
    canBackdate: boolean;
    today: string;
  } | null = null;
  let pendingAppointment: PendingAppointmentData = null;

  if (canAddService) {
    const [services, doctors, canBackdate] = await Promise.all([
      db.selectFrom("services").select(["id", "name", "code", "default_price"]).where("active", "=", 1).execute(),
      db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).execute(),
      hasPermission(session.userId, session.role, "edit_invoice_payments"),
    ]);

    // فواتير المريض اللي لسه عليها مبلغ مستحق (لخدمة "متابعة") — من نفس
    // قايمة invoices المحسوبة فوق (بعد أي تصفية لدور الدكتور)، عشان تفضل متسقة
    // مع الأرقام الظاهرة فعليًا في الجدول تحت.
    const billableInvoices = invoices
      .filter((inv) => inv.amount - inv.effectivePaid > 0.01)
      .map((inv) => ({
        id: inv.id,
        service_name: inv.service_name ?? "-",
        visit_date: inv.invoice_date,
        balance: Math.round((inv.amount - inv.effectivePaid) * 100) / 100,
      }));
    // شاشة التعديل تحتاج الأصل الحالي حتى لو دفعة المتابعة سددته بالكامل؛
    // المكون نفسه يخفي باقي الفواتير ذات الرصيد الصفري.
    const invoiceTargets = invoices.map((inv) => ({
      id: inv.id,
      service_name: inv.service_name ?? "-",
      visit_date: inv.invoice_date,
      balance: Math.round((inv.amount - inv.effectivePaid) * 100) / 100,
    }));

    // طلب تحصيل أنشأه الطبيب/المساعد ولم يتحول بعد إلى فاتورة. يظل منفصلًا عن
    // حالة الموعد وعن الملف الطبي حتى تستكمل الاستقبال التحصيل.
    const pendingRequest = await db
      .selectFrom("collection_requests")
      .innerJoin("appointments", "appointments.id", "collection_requests.appointment_id")
      .leftJoin("doctors", "doctors.id", "collection_requests.doctor_id")
      .leftJoin("services", "services.id", "collection_requests.service_id")
      .select([
        "appointments.id",
        "appointments.appointment_date",
        "collection_requests.service_id",
        "collection_requests.requested_amount",
        "doctors.full_name as doctor_name",
        "services.name as service_name",
      ])
      .where("collection_requests.patient_id", "=", patientId)
      .where("collection_requests.status", "=", "pending")
      .orderBy("collection_requests.requested_at", "desc")
      .executeTakeFirst();
    if (pendingRequest) {
      pendingAppointment = {
        id: pendingRequest.id,
        appointmentDate: pendingRequest.appointment_date,
        doctorName: pendingRequest.doctor_name,
        serviceId: pendingRequest.service_id,
        serviceName: pendingRequest.service_name,
        price: pendingRequest.requested_amount,
        discountPercent: null,
      };
    }

    addServiceData = {
      services,
      doctors,
      billableInvoices,
      invoiceTargets,
      canBackdate,
      today: getClinicToday(),
    };
  }

  return (
    <div className="billing-layout space-y-5">
      <div className="billing-identity card-3d rounded-2xl p-4">
        <div className="flex items-center gap-3">
          {/* Batch 127: نفس صورة الملف بتاعة الملف الطبي وشارت التقويم — كانت الصفحة دي
              لسه بترسم حرف أول الاسم بس، من غير ما توصلها صورة الملف (batch 126). */}
          <PatientAvatar patientId={patientId} patientName={patient.full_name} avatarPath={patient.avatar_path ?? null} editable={false} />
          <div>
          {/* نفس تخطيط رأس الملف الطبي (patients/[id]/page.tsx): رقم الملف بخط صغير،
              اسم المريض BOLD وكبير، وتحته السن/التليفون/العنوان — "الملف المالي"
              بقى جزء من السطر الصغير بدل ما يشارك العنوان الكبير مع اسم المريض. */}
          <div className="text-xs text-muted">
            ملف رقم {patient.file_number} — الملف المالي
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-xl font-bold">{patient.full_name}</h1>
            {canEditPatientInfo && (
              <EditPatientForm
                patientId={patientId}
                fullName={patient.full_name}
                birthDate={patient.birth_date}
                phone={patient.phone}
                phoneCountryCode={patient.phone_country_code}
                address={patient.address}
                language="ar"
              />
            )}
          </div>
          <div className="text-sm text-muted mt-1 flex gap-4 flex-wrap items-center">
            {canViewPersonalData && displayAge(patient) != null && <span>السن: {displayAge(patient)}</span>}
            {canViewPersonalData && patient.phone && <span>التليفون: <bdi dir="ltr">{formatPatientPhone(patient.phone_country_code, patient.phone)}</bdi></span>}
          </div>
          {isDoctorScoped && (
            <p className="text-xs text-muted mt-1">
              بيظهرلك بس الخدمات اللي أنت الدكتور الأساسي فيها (اللي بيتحسب لك دخلها).
            </p>
          )}
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Link href={`/patients/${patientId}`} className="self-center rounded-lg border border-border px-4 py-2 text-base font-semibold text-primary-dark hover:bg-primary-soft transition-colors">الملف الطبي</Link>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="billing-total-card card-3d rounded-xl p-4">
          <div className="text-xs text-muted">إجمالي المستحق</div>
          <div className="text-2xl font-bold">{totals.amount.toFixed(0)} ج.م</div>
        </div>
        <div className="billing-total-card card-3d rounded-xl p-4">
          <div className="text-xs text-muted">المدفوع</div>
          <div className="text-2xl font-bold text-primary">{totals.paid.toFixed(0)} ج.م</div>
        </div>
        <div className="billing-total-card card-3d rounded-xl p-4">
          <div className="text-xs text-muted">الباقي عليه</div>
          <div className="text-2xl font-bold text-danger">{(totals.amount - totals.paid).toFixed(0)} ج.م</div>
        </div>
      </div>

      {pendingAppointment && addServiceData && (
        <PendingCollectionCard
          patientId={patientId}
          appointmentId={pendingAppointment.id}
          appointmentDate={pendingAppointment.appointmentDate}
          doctorName={pendingAppointment.doctorName}
          serviceId={pendingAppointment.serviceId}
          serviceName={pendingAppointment.serviceName}
          price={pendingAppointment.price}
          discountPercent={pendingAppointment.discountPercent}
          services={addServiceData.services}
          doctors={addServiceData.doctors}
          canEditAssistantDoctor={canEditAssistantDoctor}
          billableInvoices={addServiceData.billableInvoices}
          canBackdate={addServiceData.canBackdate}
          today={addServiceData.today}
        />
      )}

      {addServiceData && <details id="record-payment" className="card-3d rounded-xl p-4"><summary className="cursor-pointer font-semibold">تسجيل تحصيل / دفعة مقدمة</summary><div className="mt-4"><AdvancePaymentForm patientId={patientId} /></div></details>}

      {addServiceData && (<details id="new-invoice" className="card-3d rounded-xl p-4"><summary className="cursor-pointer font-semibold">إضافة خدمة جديدة</summary><div className="mt-4"><AddPatientServiceForm
          patientId={patientId}
          services={addServiceData.services}
          doctors={addServiceData.doctors}
          billableInvoices={addServiceData.billableInvoices}
          canBackdate={addServiceData.canBackdate}
          canEditAssistantDoctor={canEditAssistantDoctor}
          today={addServiceData.today}
        /></div></details>)}

      {/* عدادات الخدمات فوق الجدول (دفعة 21) — عشان الاستقبال/الأدمن يعرفوا بسرعة
          إيه اللي اتقفل خالص وإيه اللي لسه عليه متبقي من غير ما يفوتوا في الجدول
          صف صف. */}
      <div className="flex items-center gap-4 flex-wrap text-sm px-1">
        <span>
          الخدمات: <span className="font-semibold">{serviceCounts.total}</span>
        </span>
        <span className="text-primary">
          الخدمات المنتهية: <span className="font-semibold">{serviceCounts.completed}</span>
        </span>
        <span className="text-danger">
          الخدمات الجارية: <span className="font-semibold">{serviceCounts.ongoing}</span>
        </span>
      </div>

      <div className="card-3d rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-primary-soft text-primary-dark">
            <tr>
              <th className="text-right px-3 py-2 font-medium">التاريخ</th>
              <th className="text-right px-3 py-2 font-medium">الخدمة</th>
              {!isDoctorScoped && <th className="text-right px-3 py-2 font-medium">الدكتور</th>}
              <th className="text-right px-3 py-2 font-medium">السعر الأصلي</th>
              <th className="text-right px-3 py-2 font-medium">الخصم</th>
              <th className="text-right px-3 py-2 font-medium">المبلغ</th>
              <th className="text-right px-3 py-2 font-medium">المدفوع</th>
              <th className="text-right px-3 py-2 font-medium">الباقي</th>
              <th className="text-right px-3 py-2 font-medium">طريقة الدفع</th>
              {(canDelete || canEditBillingEntry) && <th className="px-3 py-2"></th>}
            </tr>
          </thead>
          <tbody>
            {invoices.map((inv) => (
              <Fragment key={inv.id}>
                <tr className="border-t border-border">
                  <td className="px-3 py-2 text-muted whitespace-nowrap">{inv.invoice_date}</td>
                  <td className="px-3 py-2">{inv.service_name ?? "-"}</td>
                  {!isDoctorScoped && <td className="px-3 py-2">{inv.doctor_name ?? "-"}</td>}
                  <td className="px-3 py-2 text-muted">{inv.original_price != null ? inv.original_price.toFixed(0) : "-"}</td>
                  <td className="px-3 py-2">{inv.discount_percent ? `${inv.discount_percent}%` : "-"}</td>
                  <td className="px-3 py-2">{inv.amount.toFixed(0)}</td>
                  <td className="px-3 py-2">{inv.effectivePaid.toFixed(0)}</td>
                  <td className="px-3 py-2 text-danger">{(inv.amount - inv.effectivePaid).toFixed(0)}</td>
                  <td className="px-3 py-2">{paymentMethodLabel(inv.payment_method)}</td>
                  {(canDelete || canEditBillingEntry) && (
                    <td className="px-3 py-2 whitespace-nowrap">
                      {canEditBillingEntry && addServiceData && (
                        <EditInvoiceButton
                          invoiceId={inv.id}
                          patientId={patientId}
                          initial={{
                            doctorId: inv.doctor_id,
                            invoiceDate: inv.invoice_date,
                            paymentMethod: inv.payment_method,
                            paid: inv.paid,
                            serviceId: inv.service_id,
                            originalPrice: inv.original_price,
                            discountPercent: inv.discount_percent,
                            parentInvoiceId: inv.parent_invoice_id,
                          }}
                          services={addServiceData.services}
                          doctors={addServiceData.doctors}
                          billableInvoices={addServiceData.invoiceTargets}
                        />
                      )}
                      {canDelete && (
                        <DeleteInvoiceButton
                          visitId={inv.visit_id}
                          invoiceId={inv.visit_id == null ? inv.id : undefined}
                          patientId={patientId}
                          confirmLabel={`${inv.service_name ?? "خدمة"} — ${inv.invoice_date}`}
                        />
                      )}
                    </td>
                  )}
                </tr>
                {inv.followups.map((f) => (
                  <tr key={f.id} className="border-t border-border bg-background/50 text-xs text-muted">
                    <td className="px-3 py-1.5 whitespace-nowrap">{f.invoice_date}</td>
                    <td className="px-3 py-1.5">
                      ↳ دفعة متابعة ({inv.service_name ?? "-"})
                    </td>
                    {!isDoctorScoped && <td className="px-3 py-1.5"></td>}
                    <td className="px-3 py-1.5">-</td>
                    <td className="px-3 py-1.5">-</td>
                    <td className="px-3 py-1.5">-</td>
                    <td className="px-3 py-1.5">{f.paid.toFixed(0)}</td>
                    <td className="px-3 py-1.5">-</td>
                    <td className="px-3 py-1.5">{paymentMethodLabel(f.payment_method)}</td>
                    {(canDelete || canEditBillingEntry) && (
                      <td className="px-3 py-1.5 whitespace-nowrap">
                        {canEditBillingEntry && addServiceData && (
                          <EditInvoiceButton
                            invoiceId={f.id}
                            patientId={patientId}
                            initial={{
                              doctorId: f.doctor_id,
                              invoiceDate: f.invoice_date,
                              paymentMethod: f.payment_method,
                              paid: f.paid,
                              serviceId: f.service_id,
                              originalPrice: f.original_price,
                              discountPercent: f.discount_percent,
                              parentInvoiceId: f.parent_invoice_id,
                            }}
                            services={addServiceData.services}
                            doctors={addServiceData.doctors}
                            billableInvoices={addServiceData.invoiceTargets}
                          />
                        )}
                        {canDelete && (
                          <DeleteInvoiceButton
                            visitId={f.visit_id}
                            invoiceId={f.visit_id == null ? f.id : undefined}
                            patientId={patientId}
                            confirmLabel={`دفعة متابعة — ${f.invoice_date}`}
                          />
                        )}
                      </td>
                    )}
                  </tr>
                ))}
              </Fragment>
            ))}
            {invoices.length === 0 && (
              <tr>
                <td colSpan={(isDoctorScoped ? 8 : 9) + (canDelete || canEditBillingEntry ? 1 : 0)} className="px-3 py-6 text-center text-muted">
                  لا يوجد فواتير مسجلة.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
