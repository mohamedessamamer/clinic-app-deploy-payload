import "server-only";
import { db } from "./db/client";
import { getClinicToday } from "./clinic-date";

// دفعة 134 — محرّك تقرير الإحصائيات.
//
// التقرير بيقارن فترات ببعضها بست طرق مختلفة (شهر، ربع، نص سنة، سنة، نفس
// الشهر عبر السنين، الشهر مقابل شهور سنته). الطريقة الساذجة إن كل وضع يعمل
// استعلاماته بنفسه — ودي بتودّي لحاجتين وحشين: الأداء بيسوء كل ما التاريخ
// يكبر، والأهم إن الأوضاع بتبدأ تدّي أرقام مختلفة لنفس الفترة لأن كل واحد
// بيحسب بطريقته.
//
// بدل كده: استعلامين بس بيجمّعوا كل تاريخ العيادة شهريًا (سلسلة شهرية واحدة)،
// وكل الأوضاع مجرد تجميعة للسلسلة دي في الذاكرة. الأداء ثابت مهما زاد
// التاريخ، والأرقام متطابقة بين الأوضاع بالضرورة لأن مصدرها واحد.
//
// المحصّل هو المؤشر الأساسي لأنه الرقم الوحيد الموثوق عبر كل التاريخ —
// بيتقرا من الفواتير نفسها. المصروفات اتسجّلت في السيستم من شهر معيّن وبس،
// فأي شهر قبل كده بيرجع `null` مش صفر: صفر كان هيبان كأن العيادة مصرفتش
// حاجة والصافي هيطلع مضروب لفوق. `expensesFrom` تحت بيحدّد أول شهر فيه
// مصروفات فعلاً، وأي شهر أقدم منه بياخد null تلقائيًا.

export type MonthPoint = {
  /** "YYYY-MM" */
  ym: string;
  collected: number;
  /** null = مفيش سجل مصروفات للشهر ده أصلاً (مش صفر). */
  expenses: number | null;
  /** المحصّل − المصروفات، أو null لو المصروفات مش معروفة. */
  netCash: number | null;
  invoiceCount: number;
};

export type StatisticsSeries = {
  months: MonthPoint[];
  /** أول شهر فيه سجل مصروفات — قبله الأعمدة دي فاضية بشكل مقصود. */
  expensesFrom: string | null;
  /** أول وآخر شهر فيه أي بيانات. */
  firstMonth: string | null;
  lastMonth: string | null;
};

function round2(value: number) {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

/** كل الشهور من `from` لـ`to` شاملة، بصيغة "YYYY-MM". */
function monthRange(from: string, to: string): string[] {
  const out: string[] = [];
  let [year, month] = from.split("-").map(Number);
  const [endYear, endMonth] = to.split("-").map(Number);
  while (year < endYear || (year === endYear && month <= endMonth)) {
    out.push(`${year}-${String(month).padStart(2, "0")}`);
    month += 1;
    if (month > 12) {
      month = 1;
      year += 1;
    }
  }
  return out;
}

/**
 * السلسلة الشهرية الكاملة لتاريخ العيادة.
 *
 * المحصّل = مجموع `paid` على كل الفواتير بتاريخ الفاتورة. فواتير دفعات
 * المتابعة (اللي ليها parent_invoice_id) بتتحسب هنا عن قصد: هي فلوس اتحصّلت
 * فعلاً في الشهر ده، حتى لو الاستحقاق الأصلي كان في شهر أقدم — وده نفس تعريف
 * "المحصّل في الفترة" المستخدم في تقرير الإيرادات، فالرقمين بيطابقوا بعض.
 */
export async function getStatisticsSeries(): Promise<StatisticsSeries> {
  const [collectionRows, expenseRows] = await Promise.all([
    db
      .selectFrom("invoices")
      .select((eb) => [
        eb.fn<string>("substr", ["invoices.invoice_date", eb.val(1), eb.val(7)]).as("ym"),
        eb.fn.sum<number>("invoices.paid").as("collected"),
        eb.fn.countAll<number>().as("invoice_count"),
      ])
      .groupBy("ym")
      .execute(),
    db
      .selectFrom("expenses")
      .select((eb) => [
        eb.fn<string>("substr", ["expenses.expense_date", eb.val(1), eb.val(7)]).as("ym"),
        eb.fn.sum<number>("expenses.amount").as("total"),
      ])
      .groupBy("ym")
      .execute(),
  ]);

  const collected = new Map(collectionRows.map((row) => [row.ym, { total: Number(row.collected ?? 0), count: Number(row.invoice_count ?? 0) }]));
  const spent = new Map(expenseRows.map((row) => [row.ym, Number(row.total ?? 0)]));

  const allKeys = [...new Set([...collected.keys(), ...spent.keys()])].filter((key) => /^\d{4}-\d{2}$/.test(key)).sort();
  if (!allKeys.length) return { months: [], expensesFrom: null, firstMonth: null, lastMonth: null };

  // أول شهر فيه مصروفات فعلية. بنستخدمه كحد: قبله المصروفات غير معروفة (null)،
  // ومن عنده أي شهر فاضي بيبقى صفر حقيقي (شهر مصرفش فيه حاجة) مش نقص بيانات.
  const expenseKeys = [...spent.keys()].filter((key) => /^\d{4}-\d{2}$/.test(key)).sort();
  const expensesFrom = expenseKeys.length ? expenseKeys[0] : null;

  const firstMonth = allKeys[0];
  // بنمدّ السلسلة لحد الشهر الحالي حتى لو مفيش بيانات فيه، عشان المقارنة مع
  // شهر جاري فاضي تبان كصفر مش كشهر ناقص من الرسم.
  const lastMonth = [allKeys[allKeys.length - 1], getClinicToday().slice(0, 7)].sort()[1];

  const months: MonthPoint[] = monthRange(firstMonth, lastMonth).map((ym) => {
    const money = collected.get(ym);
    const collectedTotal = round2(money?.total ?? 0);
    const knowExpenses = expensesFrom != null && ym >= expensesFrom;
    const expenses = knowExpenses ? round2(spent.get(ym) ?? 0) : null;
    return {
      ym,
      collected: collectedTotal,
      expenses,
      netCash: expenses == null ? null : round2(collectedTotal - expenses),
      invoiceCount: money?.count ?? 0,
    };
  });

  return { months, expensesFrom, firstMonth, lastMonth };
}

// ---------------------------------------------------------------------------
// تجميع السلسلة في فترات
// ---------------------------------------------------------------------------

export type Bucket = {
  /** معرّف الفترة، بيستخدم كمفتاح في العرض. */
  key: string;
  label: string;
  /** الشهور اللي جوه الفترة دي. */
  months: string[];
  collected: number;
  /** null لو أي شهر في الفترة مصروفاته غير معروفة — الجمع الجزئي بيضلّل. */
  expenses: number | null;
  netCash: number | null;
  invoiceCount: number;
  /** الفترة لسه شغالة (بتضم الشهر الحالي) — الرقم بتاعها ناقص بطبيعته. */
  partial: boolean;
};

export const ARABIC_MONTHS = [
  "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر",
];

export function monthLabel(ym: string): string {
  const [year, month] = ym.split("-").map(Number);
  return `${ARABIC_MONTHS[month - 1]} ${year}`;
}

/**
 * يجمّع مجموعة شهور في فترة واحدة.
 *
 * المصروفات بترجع null لو أي شهر جوه الفترة مصروفاته غير معروفة — جمع نص
 * الفترة بس وعرضه كإجمالي الفترة كان هيدّي رقم أصغر من الحقيقة من غير أي
 * إشارة إنه ناقص، وده أسوأ من ما يبانش خالص.
 */
export function aggregate(series: StatisticsSeries, key: string, label: string, months: string[]): Bucket {
  const byMonth = new Map(series.months.map((point) => [point.ym, point]));
  const points = months.map((ym) => byMonth.get(ym)).filter((point): point is MonthPoint => point != null);
  const currentMonth = getClinicToday().slice(0, 7);

  const collected = round2(points.reduce((sum, point) => sum + point.collected, 0));
  const anyUnknown = points.some((point) => point.expenses == null) || points.length < months.length;
  const expenses = anyUnknown ? null : round2(points.reduce((sum, point) => sum + (point.expenses ?? 0), 0));

  return {
    key,
    label,
    months,
    collected,
    expenses,
    netCash: expenses == null ? null : round2(collected - expenses),
    invoiceCount: points.reduce((sum, point) => sum + point.invoiceCount, 0),
    partial: months.includes(currentMonth),
  };
}

/** شهور الربع (1..4) لسنة. */
export function quarterMonths(year: number, quarter: number): string[] {
  const start = (quarter - 1) * 3 + 1;
  return [0, 1, 2].map((offset) => `${year}-${String(start + offset).padStart(2, "0")}`);
}

/** شهور نص السنة (1 أو 2). */
export function halfMonths(year: number, half: number): string[] {
  const start = half === 1 ? 1 : 7;
  return [0, 1, 2, 3, 4, 5].map((offset) => `${year}-${String(start + offset).padStart(2, "0")}`);
}

/** كل شهور سنة. */
export function yearMonths(year: number): string[] {
  return Array.from({ length: 12 }, (_, index) => `${year}-${String(index + 1).padStart(2, "0")}`);
}
