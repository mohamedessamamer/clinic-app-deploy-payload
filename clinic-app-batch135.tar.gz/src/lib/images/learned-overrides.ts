import { db } from "@/lib/db/client";
import { getSetting } from "@/lib/settings";
import { isImageKind, type ImageKind } from "@/lib/images/kinds";
import type { ImageFeatures } from "@/lib/images/classify";

// Batch 130: أول استخدام فعلي لبيانات patient_image_corrections (كانت log-only
// بس من دفعة 127 — طلب صريح من المستخدم دلوقتي إنه "يستفيد" منها).
//
// درجتين من "التعلم"، حسب الطلب الصريح بعد ما اتسأل تحديدًا عن الحالة اللي
// السيستم فيها "واثق بس غلطان" (مش بس الحالات الغامضة زي "غير محدد"):
//
//  1) تصنيف غامض أصلًا (ثقة <= UNCERTAIN_CONFIDENCE_THRESHOLD، زي "other"):
//     عتبة منخفضة نسبيًا — 3 تصحيحات متفقة على صور قريبة الشكل كفاية.
//     خطر منخفض جدًا: أصلًا مفيش تصنيف واثق بيتلغى، الصورة كانت هتفضل
//     "من غير مكان" على أي حال.
//
//  2) تصنيف واثق لكن بيتكرر غلطه بنفس الشكل بالظبط: عتبة أعلى بكتير —
//     CONFIDENT_MIN_CORRECTIONS تصحيح متفق (مش 3)، وتشابه أضيق بكتير في
//     الخصائص (CONFIDENT_DISTANCE_THRESHOLD)، + شرط إضافي: التصحيحات المعتبرة
//     لازم يكون كان تصنيفها القديم (old_kind) نفس النوع اللي السيستم مقترحه
//     دلوقتي بالظبط — يعني مش أي تصحيح قريب الشكل، لازم يكون "نفس الغلطة"
//     اتكررت وانصلحت لنفس النوع الصح كل مرة.
//
// في الحالتين: مفيش أي تغيير على classify.ts نفسها (familyOf/kindOf/
// isFrontalFace) — طبقة إضافية بعد التصنيف الأساسي، مش تعديل في عتباته.
// أي تعارض بين التصحيحات القريبة (نوعين مختلفين) بيلغي الاقتراح تمامًا —
// أحسن نسيب الصورة زي ما هي من إننا نخمن غلط بثقة. الميزة كلها افتراضيًا
// مقفولة (auto_learn_from_corrections=0) لحد ما الأدمن يفعّلها بنفسه من
// الإعدادات، وأي صورة اتصنفت بالطريقة دي بتاخد علامة kind_learned=1 عشان
// تبان في الواجهة ("🤖") وتفرق عن تصنيف السيستم العادي أو تصحيح بشري.

const UNCERTAIN_CONFIDENCE_THRESHOLD = 0.35;
const UNCERTAIN_MIN_CORRECTIONS = 3;
const UNCERTAIN_DISTANCE_THRESHOLD = 0.12;

// أعلى بكتير من الحالة الغامضة — إحنا هنا بنبدّل تصنيف كان السيستم واثق فيه،
// فمحتاجين أدلة أقوى بكتير قبل ما نصدّق إنها غلطة متكررة مش استثناء.
const CONFIDENT_MIN_CORRECTIONS = 6;
const CONFIDENT_DISTANCE_THRESHOLD = 0.07;

const LEARNED_CONFIDENCE = 0.4;

/** خصائص محدودة لمدى 0..1 تقريبًا — بعيدًا عن aspect/mixedCells/gridBands
 * (مقاييس مختلفة تمامًا كانت هتفسد حساب المسافة). */
const DISTANCE_KEYS: (keyof ImageFeatures)[] = [
  "colorRatio", "skinRatio", "faceBlobRatio", "redStrong", "redCenter",
  "darkRatio", "symmetry", "balance", "teethWhite", "mouthBright",
  "teethTopHeavy", "teethLeftHeavy", "brightCenter",
];

function featureDistance(a: ImageFeatures, b: ImageFeatures): number {
  let sumSquares = 0;
  for (const key of DISTANCE_KEYS) {
    const diff = (a[key] ?? 0) - (b[key] ?? 0);
    sumSquares += diff * diff;
  }
  return Math.sqrt(sumSquares / DISTANCE_KEYS.length);
}

export async function isAutoLearnEnabled(): Promise<boolean> {
  const value = await getSetting("auto_learn_from_corrections");
  return value === "1";
}

/**
 * بيرجع اقتراح نوع "متعلّم" بس لو فيه تصحيحات بشرية كافية (العدد بيختلف حسب
 * درجة ثقة السيستم في نفسه) ومتفقة كلها على نفس النوع لصور شبيهة جدًا اتصنفت
 * بنفس الطريقة قبل كده. غير كده بيرجع null من غير أي أثر جانبي — التصنيف
 * الأساسي بيفضل زي ما هو تمامًا.
 */
export async function findLearnedOverride(
  currentKind: string | null,
  currentConfidence: number | null,
  features: ImageFeatures
): Promise<{ kind: ImageKind; confidence: number } | null> {
  if (!(await isAutoLearnEnabled())) return null;

  const uncertain = currentConfidence == null || currentConfidence <= UNCERTAIN_CONFIDENCE_THRESHOLD;
  const minCorrections = uncertain ? UNCERTAIN_MIN_CORRECTIONS : CONFIDENT_MIN_CORRECTIONS;
  const distanceThreshold = uncertain ? UNCERTAIN_DISTANCE_THRESHOLD : CONFIDENT_DISTANCE_THRESHOLD;

  const rows = await db
    .selectFrom("patient_image_corrections")
    .select(["new_kind", "features_json"])
    .where("features_json", "is not", null)
    // الحالة الواثقة بس: لازم يكون نفس "الغلطة" بالظبط اتكررت (نفس old_kind)،
    // مش أي تصحيح قريب الشكل صدفة — أضيق وأأمن.
    .$if(!uncertain, (query) =>
      currentKind == null ? query.where("old_kind", "is", null) : query.where("old_kind", "=", currentKind)
    )
    .orderBy("id", "desc")
    .limit(500)
    .execute();

  const nearby: string[] = [];
  for (const row of rows) {
    if (!row.features_json) continue;
    let parsed: ImageFeatures;
    try {
      parsed = JSON.parse(row.features_json) as ImageFeatures;
    } catch {
      continue;
    }
    if (featureDistance(features, parsed) <= distanceThreshold) nearby.push(row.new_kind);
  }

  if (nearby.length < minCorrections) return null;
  // أي خلاف بين التصحيحات القريبة (نوعين مختلفين) = مش واضح كفاية، نسيبها.
  const distinctKinds = new Set(nearby);
  if (distinctKinds.size !== 1) return null;

  const [kind] = distinctKinds;
  if (!isImageKind(kind) || kind === currentKind) return null;

  return { kind, confidence: LEARNED_CONFIDENCE };
}
