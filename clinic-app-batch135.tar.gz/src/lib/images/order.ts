import { isImageKind, type ImageKind } from "@/lib/images/kinds";

// Batch 126: ترتيب صور المريض المتفق عليه — نفس الترتيب في شريط المعرض وفي
// التمبلت وفي أي عرض تاني:
//   1) Extra-Oral: أمامي (وابتسامة) ← جانبي ← 45 درجة ← أي صورة وش تانية
//   2) Intra-Oral: أمامي ← يمين ← شمال ← الفك العلوي ← الفك السفلي ← الباقي
//   3) X-ray: بانوراما ← سيفالومتري ← أي أشعة تانية
//   4) Templates: أي تمبلت جاهز اتعمل برة السيستم واترفع مع الصور

export type ImageSection = "extraoral" | "intraoral" | "xray" | "templates";

export const SECTION_ORDER: ImageSection[] = ["extraoral", "intraoral", "xray", "templates"];

export const SECTION_LABELS: Record<ImageSection, string> = {
  extraoral: "Extra-Oral",
  intraoral: "Intra-Oral",
  xray: "X-ray",
  templates: "Templates",
};

const KIND_ORDER: ImageKind[] = [
  "face_frontal",
  "face_smile",
  "face_profile",
  "face_profile_smile",
  "face_oblique",
  "face_oblique_smile",
  "intraoral_front",
  "intraoral_right",
  "intraoral_left",
  "intraoral_upper",
  "intraoral_lower",
  "xray_pano",
  "xray_ceph",
  "xray_other",
  "template_sheet",
  "other",
];

export function sectionOf(kind: string | null | undefined): ImageSection {
  if (!isImageKind(kind)) return "extraoral";
  if (kind === "template_sheet") return "templates";
  if (kind.startsWith("xray")) return "xray";
  if (kind.startsWith("intraoral")) return "intraoral";
  return "extraoral";
}

/** رقم الترتيب لكل صورة: القسم الأول، وجوه القسم ترتيب النوع. */
export function imageSortRank(kind: string | null | undefined): number {
  const section = SECTION_ORDER.indexOf(sectionOf(kind));
  const inSection = isImageKind(kind) ? KIND_ORDER.indexOf(kind) : KIND_ORDER.length;
  return section * 100 + (inSection === -1 ? KIND_ORDER.length : inSection);
}

export function sortImagesByKind<T extends { image_kind?: string | null; id: number }>(images: T[]): T[] {
  return [...images].sort((a, b) => imageSortRank(a.image_kind) - imageSortRank(b.image_kind) || a.id - b.id);
}
