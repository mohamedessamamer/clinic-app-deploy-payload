// Batch 130 (Phase 5): أنواع صور "مخصّصة" يضيفها الأدمن بنفسه من الإعدادات —
// طلب صريح لما لقى نفسه محتاج نوع مش موجود في القايمة الثابتة (IMAGE_KINDS)،
// زي "12 O'clock" في الإكسترا أورال أو "Tracing" في الأشعة.
//
// مهم جدًا: النوع المخصّص ده اختياري يدوي بس — أبدًا مبيتكتشفش تلقائيًا وقت
// الرفع (classify.ts مش بيعرفه ومش هيتعدّل عشانه). المستخدم هو اللي بيحدده
// يدويًا من دروب داون التصحيح في شاشة الصور (ImageTemplateBoard) أو وقت ما
// يعمل خانة تمبلت جديدة من الإعدادات. بيتخزن كـJSON array في clinic_settings
// تحت مفتاح CUSTOM_KIND_SETTING_KEY.

import { getSetting } from "@/lib/settings";

export type CustomKindFamily = "face" | "intraoral" | "xray" | "template" | "other";

export type CustomImageKind = {
  /** مفتاح فريد يبدأ بـ"custom_" — نفس الدور اللي بيلعبه ImageKind العادي. */
  key: string;
  label: string;
  family: CustomKindFamily;
};

export const CUSTOM_KIND_SETTING_KEY = "ortho_custom_image_kinds";

const CUSTOM_KIND_KEY_PATTERN = /^custom_[a-z0-9_]{1,40}$/;
const CUSTOM_FAMILIES: CustomKindFamily[] = ["face", "intraoral", "xray", "template", "other"];

export function isCustomKindKey(value: string | null | undefined): boolean {
  return !!value && CUSTOM_KIND_KEY_PATTERN.test(value);
}

function isCustomFamily(value: unknown): value is CustomKindFamily {
  return typeof value === "string" && (CUSTOM_FAMILIES as string[]).includes(value);
}

/** تحويل الاسم اللي كتبه المستخدم لمفتاح إنجليزي آمن — يقبل عربي وإنجليزي،
 * ولو النتيجة فاضية (مثلاً اسم عربي بالكامل) بيرجع فاضي والكولر بيولّد رقم بدل. */
function slugify(label: string): string {
  return label
    .trim()
    .toLowerCase()
    .replace(/['"]/g, "")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 30);
}

export function generateCustomKindKey(label: string, existing: Set<string>): string {
  const base = slugify(label) || "type";
  let candidate = `custom_${base}`;
  let attempt = 1;
  while (!isCustomKindKey(candidate) || existing.has(candidate)) {
    attempt += 1;
    candidate = `custom_${base}_${attempt}`;
  }
  return candidate;
}

export function parseCustomImageKinds(raw: string | null | undefined): CustomImageKind[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    const seen = new Set<string>();
    const result: CustomImageKind[] = [];
    for (const item of parsed) {
      if (
        !item ||
        typeof item !== "object" ||
        typeof (item as { key?: unknown }).key !== "string" ||
        !isCustomKindKey((item as { key: string }).key) ||
        typeof (item as { label?: unknown }).label !== "string" ||
        !isCustomFamily((item as { family?: unknown }).family)
      ) {
        continue;
      }
      const key = (item as { key: string }).key;
      if (seen.has(key)) continue;
      seen.add(key);
      result.push({ key, label: (item as { label: string }).label.slice(0, 60), family: (item as { family: CustomKindFamily }).family });
    }
    return result.slice(0, 60);
  } catch {
    return [];
  }
}

export function serializeCustomImageKinds(kinds: CustomImageKind[]): string {
  return JSON.stringify(kinds);
}

export async function loadCustomImageKinds(): Promise<CustomImageKind[]> {
  const raw = await getSetting(CUSTOM_KIND_SETTING_KEY);
  return parseCustomImageKinds(raw);
}
