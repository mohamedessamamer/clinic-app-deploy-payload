import { IMAGE_KINDS, type ImageKind, isImageKind } from "@/lib/images/kinds";

// ملحوظة: التحقق من مفتاح النوع المخصّص هنا نمط مستقل (مش import من
// custom-kinds.ts) عمدًا — custom-kinds.ts بيستورد getSetting من
// @/lib/settings اللي بدورها بتستورد db/client (better-sqlite3، server-only).
// الملف ده (template.ts) بيتستورد من OrthoImageTemplateForm.tsx وهو "use
// client"، فأي استيراد سيرفر-أونلي هنا كان هيكسر بناء الكلاينت بالكامل.
const CUSTOM_KIND_KEY_PATTERN = /^custom_[a-z0-9_]{1,40}$/;
function isCustomKindKey(value: string): boolean {
  return CUSTOM_KIND_KEY_PATTERN.test(value);
}

// Batch 124: تمبلت صور التقويم — خانات قابلة للتظبيط من الإعدادات (تبويب شارت
// التقويم). بيتخزن في clinic_settings.ortho_image_template كـ JSON.

// Batch 130 (Phase 5): "kind" ممكن يبقى كمان مفتاح نوع مخصّص (custom_...) —
// راجع src/lib/images/custom-kinds.ts. التحقق هنا بس من شكل المفتاح (نمط
// custom_xxx)، مش من كونه مسجّل فعلًا في الإعدادات — الصفحة اللي بتعرض
// التمبلت هي اللي بتترجم المفتاح لاسمه المعروض باستخدام قايمة الأنواع
// المخصّصة الحالية وقت العرض.
export type TemplateSlotKind = ImageKind | "any" | string;

export type TemplateSlot = {
  key: string;
  label: string;
  kind: TemplateSlotKind;
};

export type ImageTemplate = {
  columns: number;
  slots: TemplateSlot[];
};

export const TEMPLATE_SETTING_KEY = "ortho_image_template";

export const DEFAULT_TEMPLATE: ImageTemplate = {
  columns: 3,
  slots: [
    { key: "face_profile", label: "وش جانبي", kind: "face_profile" },
    { key: "face_frontal", label: "وش أمامي", kind: "face_frontal" },
    { key: "face_smile", label: "وش مبتسم", kind: "face_smile" },
    { key: "intraoral_upper", label: "الفك العلوي", kind: "intraoral_upper" },
    { key: "intraoral_front", label: "أسنان أمامي", kind: "intraoral_front" },
    { key: "intraoral_lower", label: "الفك السفلي", kind: "intraoral_lower" },
    { key: "intraoral_right", label: "أسنان يمين", kind: "intraoral_right" },
    { key: "xray_pano", label: "بانوراما", kind: "xray_pano" },
    { key: "intraoral_left", label: "أسنان شمال", kind: "intraoral_left" },
    { key: "xray_ceph", label: "سيفالومتري", kind: "xray_ceph" },
    { key: "xray_extra_1", label: "أشعة إضافية", kind: "xray_other" },
    { key: "extra_1", label: "صورة إضافية", kind: "any" },
  ],
};

const SLOT_KEY_PATTERN = /^[a-z0-9_]{1,40}$/;

function isSlotKind(value: unknown): value is TemplateSlotKind {
  if (typeof value !== "string") return false;
  return value === "any" || isImageKind(value) || isCustomKindKey(value);
}

/** قراءة التمبلت من الإعدادات مع الرجوع للافتراضي لو القيمة ناقصة أو تالفة. */
export function parseImageTemplate(raw: string | null | undefined): ImageTemplate {
  if (!raw) return DEFAULT_TEMPLATE;
  try {
    const parsed = JSON.parse(raw) as Partial<ImageTemplate>;
    const slots = Array.isArray(parsed.slots)
      ? parsed.slots
          .filter((slot): slot is TemplateSlot =>
            !!slot && typeof slot.key === "string" && SLOT_KEY_PATTERN.test(slot.key) && typeof slot.label === "string" && isSlotKind(slot.kind))
          .map((slot) => ({ key: slot.key, label: slot.label.slice(0, 60) || slot.key, kind: slot.kind }))
      : [];
    const unique: TemplateSlot[] = [];
    const seen = new Set<string>();
    for (const slot of slots) {
      if (seen.has(slot.key)) continue;
      seen.add(slot.key);
      unique.push(slot);
    }
    if (!unique.length) return DEFAULT_TEMPLATE;
    const columns = Number(parsed.columns);
    return { columns: Number.isFinite(columns) && columns >= 1 && columns <= 6 ? Math.round(columns) : 3, slots: unique.slice(0, 40) };
  } catch {
    return DEFAULT_TEMPLATE;
  }
}

export function serializeImageTemplate(template: ImageTemplate): string {
  return JSON.stringify({ columns: template.columns, slots: template.slots });
}

export const TEMPLATE_KIND_OPTIONS: TemplateSlotKind[] = ["any", ...IMAGE_KINDS.filter((kind) => kind !== "other")];
