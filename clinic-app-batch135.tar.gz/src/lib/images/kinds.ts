// Batch 124: أنواع صور المريض اللي السيستم بيتعرف عليها تلقائيًا وقت الرفع.
// ملف عادي (من غير sharp ولا server-only) عشان الواجهة تستورد الأسماء والتسميات.

export const IMAGE_KINDS = [
  "face_profile",
  "face_profile_smile",
  "face_oblique",
  "face_oblique_smile",
  "face_frontal",
  "face_smile",
  "intraoral_front",
  "intraoral_right",
  "intraoral_left",
  "intraoral_upper",
  "intraoral_lower",
  "xray_pano",
  "xray_ceph",
  "xray_other",
  // Batch 126: تمبلت جاهز متعمول برة السيستم (صورة مجمّعة فيها كذا صورة).
  "template_sheet",
  "other",
] as const;

export type ImageKind = (typeof IMAGE_KINDS)[number];

export const IMAGE_KIND_LABELS: Record<ImageKind, string> = {
  face_profile: "وش جانبي",
  face_profile_smile: "وش جانبي مبتسم",
  face_oblique: "وش 45 درجة",
  face_oblique_smile: "وش 45 درجة مبتسم",
  face_frontal: "وش أمامي",
  face_smile: "وش مبتسم",
  intraoral_front: "أسنان أمامي",
  intraoral_right: "أسنان يمين",
  intraoral_left: "أسنان شمال",
  intraoral_upper: "الفك العلوي (سقف الفم)",
  intraoral_lower: "الفك السفلي",
  xray_pano: "بانوراما",
  xray_ceph: "سيفالومتري",
  xray_other: "أشعة أخرى",
  template_sheet: "تمبلت جاهز",
  other: "غير محدد",
};

/** Batch 126: نفس الأسماء بالإنجليزي — شارت التقويم والتمبلت إنجليزي دايمًا. */
export const IMAGE_KIND_LABELS_EN: Record<ImageKind, string> = {
  face_profile: "Profile",
  face_profile_smile: "Profile smiling",
  face_oblique: "45\u00B0 view",
  face_oblique_smile: "45\u00B0 view smiling",
  face_frontal: "Frontal",
  face_smile: "Frontal smiling",
  intraoral_front: "Frontal occlusion",
  intraoral_right: "Right side",
  intraoral_left: "Left side",
  intraoral_upper: "Upper occlusal",
  intraoral_lower: "Lower occlusal",
  xray_pano: "Panorama",
  xray_ceph: "Cephalometric",
  xray_other: "Other X-ray",
  template_sheet: "Ready-made template",
  other: "Unclassified",
};

export const FACE_KINDS: ImageKind[] = [
  "face_frontal", "face_smile", "face_profile", "face_profile_smile", "face_oblique", "face_oblique_smile",
];
export const INTRAORAL_KINDS: ImageKind[] = ["intraoral_front", "intraoral_right", "intraoral_left", "intraoral_upper", "intraoral_lower"];
export const XRAY_KINDS: ImageKind[] = ["xray_pano", "xray_ceph", "xray_other"];

/** المجموعة العامة — التصنيف التلقائي بيبقى واثق فيها أكتر من النوع التفصيلي. */
export function imageKindFamily(kind: ImageKind): "face" | "intraoral" | "xray" | "template" | "other" {
  if (FACE_KINDS.includes(kind)) return "face";
  if (INTRAORAL_KINDS.includes(kind)) return "intraoral";
  if (XRAY_KINDS.includes(kind)) return "xray";
  if (kind === "template_sheet") return "template";
  return "other";
}

export function isImageKind(value: string | null | undefined): value is ImageKind {
  return !!value && (IMAGE_KINDS as readonly string[]).includes(value);
}
