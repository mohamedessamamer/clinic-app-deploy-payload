// Batch 127: بصمة محتوى الملف (SHA-256)، مستخدمة في مكانين: كشف تكرار الصور
// وقت الرفع (upload/route.ts)، وإعادة حساب البصمة بعد أي عملية بتغيّر بايتات
// الصورة الفعلية زي التدوير الحقيقي (patients/[id]/actions.ts). ملف واحد
// مشترك بدل ما نكرر نفس الدالة في مكانين ويختلفوا مع الوقت.

import { createHash } from "node:crypto";
import { createReadStream } from "node:fs";

export function fileSha256(filePath: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const hash = createHash("sha256");
    const stream = createReadStream(filePath);
    stream.on("data", (chunk) => hash.update(chunk));
    stream.on("end", () => resolve(hash.digest("hex")));
    stream.on("error", reject);
  });
}
