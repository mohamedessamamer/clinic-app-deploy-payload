import sharp from "sharp";
import { extractFeatures, familyOf, isFrontalFace, type ImageFeatures } from "@/lib/images/classify";

// Batch 127 (الجولة التانية): تخمين اتجاه الصورة وقت الرفع، للصور اللي من غير
// EXIF بس. الفكرة: نجرب الصورة في 4 اتجاهات (0/90/180/270)، ونشغّل نفس دوال
// استخراج الخصائص على كل واحد.
//
// Batch 128 (تصحيح مهم بعد النشر): النسخة الأولى كانت بتقيس "شكل وش طبيعي"
// بمعادلة (تماثل + توازن + بشرة) وتطبّق التخمين لو أي اتجاه غير 0 حسّن
// النتيجة دي بفارق واضح. المشكلة: التماثل/التوازن مقياس صحيح للوش **الأمامي**
// بس — صورة Profile حقيقية (جانبية) طبيعي جدًا يكون تماثلها وتوازنها واطي؛
// ده مش عيب في الصورة، ده شكل الوش الجانبي الطبيعي. فلما التخمين كان بيدوّر
// الصور الجانبية بحثًا عن "أعلى تماثل ممكن"، كان بيلقط اتجاه غلط بيرفع
// التماثل بالصدفة ويطبّقه فعليًا — وده بالظبط اللي سبب صور "Profile
// smiling" المقلوبة/المايلة اللي ظهرت بعد نشر 127 (شوف صور المريض 504).
//
// الإصلاح: التخمين بقى بيتطبق بس لو الاتجاه الفايز بيعدّي فعليًا عتبة
// isFrontalFace (نفس المعيار المستخدم في التصنيف النهائي لصورة الملف)
// **والاتجاه الأصلي (0 درجة) لأ**. يعني التخمين بقى مقصور فعليًا على الحالة
// المقصودة بس: صورة وش أمامية حقيقية اترفعت مقلوبة/جانبية بسبب غياب EXIF —
// مش أي صورة وش عمومًا. صورة Profile حقيقية (جانبية فعلًا) مستحيل تعدّي
// isFrontalFace في أي اتجاه من الأربعة (التماثل العالي المطلوب فيها مش موجود
// أصلًا بغض النظر عن اتجاه التأطير)، فمابتتلمسش خالص — أأمن بكتير من مقياس
// "أعلى تماثل نسبي".

const CANDIDATE_ROTATIONS = [0, 90, 180, 270] as const;
type Rotation = (typeof CANDIDATE_ROTATIONS)[number];

export type OrientationGuess = {
  /** الاتجاه اللي طلع أحسن نتيجة (بالنسبة للصورة زي ما اترفعت، 0 = زي ما هي). */
  rotation: Rotation;
  /** لو true يبقى فيه اتجاه غير 0 فاز بفارق واضح واتطبق فعليًا على البافر. */
  applied: boolean;
  /** البافر بعد تطبيق الدوران (أو نفس البافر الأصلي لو applied=false). */
  buffer: Buffer;
};

/**
 * بتتنفذ فقط لما نكون عارفين إن الصورة من غير EXIF orientation (فحص EXIF
 * بيحصل قبل النداء ده في upload/route.ts). بتحاول الـ4 اتجاهات، وبترجع أفضل
 * واحد بس لو:
 *   (أ) الاتجاه ده عدّى عتبة isFrontalFace (وش أمامي واضح بثقة عالية)، و
 *   (ب) الاتجاه الأصلي (0 درجة) ماعداش نفس العتبة.
 * يعني التخمين بيتجنّب أي صورة أصلًا مصنّفة صح (أمامية أو جانبية) — بيتدخل
 * بس لما يكون شبه مؤكد إن الصورة أمامية حقيقية بس اترفعت لفة غلط.
 */
export async function guessAndBakeOrientation(buffer: Buffer): Promise<OrientationGuess> {
  const rotatedBuffers = new Map<Rotation, Buffer>();
  const featuresByRotation = new Map<Rotation, ImageFeatures>();

  for (const rotation of CANDIDATE_ROTATIONS) {
    try {
      const candidate =
        rotation === 0 ? buffer : await sharp(buffer, { failOn: "none" }).rotate(rotation).toBuffer();
      rotatedBuffers.set(rotation, candidate);
      const { features } = await extractFeatures(candidate);
      featuresByRotation.set(rotation, features);
    } catch (error) {
      console.error("[images] guessAndBakeOrientation: failed rotation", rotation, error);
    }
  }

  const baseFeatures = featuresByRotation.get(0);
  // مش قادرين نحلل الصورة الأصلية أصلًا — مفيش أساس نقيس عليه، منطبقش تخمين.
  if (!baseFeatures) {
    return { rotation: 0, applied: false, buffer };
  }
  // الصورة أصلًا مش من عيلة "وش" (أشعة/جوه الفم/تمبلت جاهز) — مش مجال
  // التخمين ده خالص.
  if (familyOf(baseFeatures) !== "face") {
    return { rotation: 0, applied: false, buffer };
  }
  // الوضع الأصلي أصلًا وش أمامي واضح (0 درجة) — مفيش داعي لأي تخمين.
  if (isFrontalFace(baseFeatures)) {
    return { rotation: 0, applied: false, buffer };
  }

  // من بين 90/180/270، أول اتجاه بيعدّي عتبة "وش أمامي واضح" فعلًا (مش أعلى
  // نتيجة نسبية — عتبة مطلقة، زي ما التصنيف النهائي بيعمل بالظبط).
  for (const rotation of [90, 180, 270] as const) {
    const features = featuresByRotation.get(rotation);
    if (features && isFrontalFace(features)) {
      const bakedBuffer = await sharp(rotatedBuffers.get(rotation)!, { failOn: "none" }).rotate().toBuffer();
      return { rotation, applied: true, buffer: bakedBuffer };
    }
  }

  // ولا اتجاه عدّى العتبة (يشمل صور Profile/45° الحقيقية — طبيعي عندها
  // تماثل واطي في كل الاتجاهات) — منطبقش أي تخمين، نسيب الصورة زي ما هي.
  return { rotation: 0, applied: false, buffer };
}

// re-export مساعد بسيط للاستخدام في actions.ts (rotateImageAction) عشان محتاج
// نفس منطق "خد بافر وطبّق دوران محدد بالدرجة ثم رجّع بافر جديد" من غير ما
// نكرره.
export async function bakeRotation(buffer: Buffer, degrees: number): Promise<Buffer> {
  const normalized = ((degrees % 360) + 360) % 360;
  if (normalized === 0) {
    // لسه بنطبع rotate() من غير args عشان نصفّي أي EXIF orientation متبقي
    // ونضمن إن البايتات المحفوظة متطابقة مع اللي هيتعرض.
    return sharp(buffer, { failOn: "none" }).rotate().toBuffer();
  }
  return sharp(buffer, { failOn: "none" }).rotate().rotate(normalized).toBuffer();
}
