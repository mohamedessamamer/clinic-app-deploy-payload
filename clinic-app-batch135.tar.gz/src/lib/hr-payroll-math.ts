export type HrRule = {
  compensation_type: "fixed" | "percentage" | "mixed";
  fixed_basis: "monthly" | "shift";
  fixed_amount: number;
  // 'personal' = تحصيل الطبيب نفسه بعد المعمل · 'clinic' = تحصيل العيادة بعد
  // المعمل · 'clinic_net_cash' = صافي النقدية (للموظفين والتمريض فقط).
  percentage_basis: "personal" | "clinic" | "clinic_net_cash";
  percentage_mode: "fixed" | "progressive";
  percentage: number;
  // أيام الأسبوع مفصولة بفاصلة بترقيم weekdayOf (0=الأحد .. 6=السبت).
  shift_weekdays?: string | null;
};

function round2(value: number) {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

// دفعة 132: عدد أيام الشيفت الفعلية في فترة. بنعد مرات ظهور كل يوم من أيام
// الأسبوع المختارة بين التاريخين (شاملين الطرفين)، فشهر فيه 5 آحاد بيطلع رقم
// أكبر من شهر فيه 4 لوحده من غير أي إدخال من المحاسب.
//
// الحساب بالـUTC من أجزاء التاريخ نفسها (زي weekdayOf في settings.ts) عشان
// النتيجة ماتتأثرش بالتايم زون بتاع السيرفر — نفس السبب اللي خلى weekdayOf
// تتكتب كده أصلاً.
export function parseShiftWeekdays(raw: string | null | undefined): number[] {
  if (!raw) return [];
  const seen = new Set<number>();
  for (const part of raw.split(",")) {
    const value = Number(part.trim());
    if (Number.isInteger(value) && value >= 0 && value <= 6) seen.add(value);
  }
  return [...seen].sort((a, b) => a - b);
}

export function countShiftDaysInPeriod(raw: string | null | undefined, from: string, to: string): number {
  const weekdays = parseShiftWeekdays(raw);
  if (!weekdays.length || !from || !to || from > to) return 0;
  const wanted = new Set(weekdays);
  const [fromYear, fromMonth, fromDay] = from.split("-").map(Number);
  const [toYear, toMonth, toDay] = to.split("-").map(Number);
  const start = Date.UTC(fromYear, fromMonth - 1, fromDay);
  const end = Date.UTC(toYear, toMonth - 1, toDay);
  if (!Number.isFinite(start) || !Number.isFinite(end)) return 0;
  const DAY_MS = 24 * 60 * 60 * 1000;
  let count = 0;
  for (let stamp = start; stamp <= end; stamp += DAY_MS) {
    if (wanted.has(new Date(stamp).getUTCDay())) count += 1;
  }
  return count;
}

// إجمالي مستحق الطبيب المستهدف عند نقاط ملف الـProgressive Production Bonus.
// نحسب بين النقط بخط مستقيم كي تعمل القاعدة مع أي مبلغ، لا مضاعفات 5,000 فقط.
// من 100,000 فما فوق إجمالي المستحق يساوي 30% من صافي التحصيل.
const PROGRESSIVE_TOTAL_POINTS: readonly [number, number][] = [
  [0, 0], [10_000, 3_000], [15_000, 3_750], [20_000, 5_000],
  [25_000, 6_250], [30_000, 7_500], [35_000, 8_750], [40_000, 10_000],
  [45_000, 11_250], [50_000, 12_500], [55_000, 14_000], [60_000, 15_500],
  [65_000, 17_000], [70_000, 18_500], [75_000, 20_250], [80_000, 22_000],
  [85_000, 24_000], [90_000, 26_000], [95_000, 28_000], [100_000, 30_000],
] as const;

export function progressiveTargetTotal(netCollected: number) {
  const net = Math.max(0, netCollected);
  if (net >= 100_000) return round2(net * 0.3);
  for (let index = 1; index < PROGRESSIVE_TOTAL_POINTS.length; index += 1) {
    const [upperIncome, upperTotal] = PROGRESSIVE_TOTAL_POINTS[index];
    if (net > upperIncome) continue;
    const [lowerIncome, lowerTotal] = PROGRESSIVE_TOTAL_POINTS[index - 1];
    const ratio = (net - lowerIncome) / (upperIncome - lowerIncome);
    return round2(lowerTotal + ratio * (upperTotal - lowerTotal));
  }
  return 0;
}

export function calculateHrPayroll(rule: HrRule, netCollected: number, shiftCount: number) {
  const safeNet = round2(Math.max(0, netCollected));
  const safeShifts = Math.max(0, shiftCount);
  const baseAmount = rule.compensation_type === "percentage"
    ? 0
    : round2(rule.fixed_basis === "shift" ? rule.fixed_amount * safeShifts : rule.fixed_amount);

  if (rule.compensation_type === "fixed") {
    return { baseAmount, percentageAmount: 0, totalAmount: baseAmount, effectivePercentage: safeNet > 0 ? round2((baseAmount / safeNet) * 100) : 0 };
  }

  if (rule.percentage_mode === "progressive") {
    const targetTotal = progressiveTargetTotal(safeNet);
    const totalAmount = round2(Math.max(baseAmount, targetTotal));
    return {
      baseAmount,
      percentageAmount: round2(Math.max(0, totalAmount - baseAmount)),
      totalAmount,
      effectivePercentage: safeNet > 0 ? round2((totalAmount / safeNet) * 100) : 0,
    };
  }

  const percentageAmount = round2(safeNet * (rule.percentage / 100));
  const totalAmount = round2(baseAmount + percentageAmount);
  return { baseAmount, percentageAmount, totalAmount, effectivePercentage: safeNet > 0 ? round2((totalAmount / safeNet) * 100) : 0 };
}

export function calculateCollectedAfterAutomaticLab(lines: Array<{ paid: number; invoiceAmount: number; labCost: number }>) {
  let grossCollected = 0;
  let automaticLab = 0;
  for (const line of lines) {
    const paid = Math.max(0, Number(line.paid) || 0);
    const invoiceAmount = Math.max(0, Number(line.invoiceAmount) || 0);
    const labCost = Math.max(0, Number(line.labCost) || 0);
    grossCollected += paid;
    // عند الدفع الجزئي نخصم من المعمل بنفس نسبة المدفوع من سعر الخدمة.
    if (paid > 0 && invoiceAmount > 0 && labCost > 0) {
      automaticLab += Math.min(paid, paid * (labCost / invoiceAmount));
    }
  }
  const gross = round2(grossCollected);
  const lab = round2(automaticLab);
  return { grossCollected: gross, automaticLab: lab, netCollected: round2(Math.max(0, gross - lab)) };
}
