import "server-only";
import { db } from "./db/client";
export { calculateHrPayroll, progressiveTargetTotal, countShiftDaysInPeriod, parseShiftWeekdays } from "./hr-payroll-math";
export type { HrRule } from "./hr-payroll-math";
import { calculateCollectedAfterAutomaticLab, calculateHrPayroll, countShiftDaysInPeriod, type HrRule } from "./hr-payroll-math";

function round2(value: number) {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

export async function getCollectedAfterLab(from: string, to: string, doctorId: number | null) {
  let rootsQuery = db
    .selectFrom("invoices")
    .leftJoin("services", "services.id", "invoices.service_id")
    .select(["invoices.paid", "invoices.amount as invoice_amount", "services.lab_cost"])
    .where("invoices.parent_invoice_id", "is", null)
    .where("invoices.invoice_date", ">=", from)
    .where("invoices.invoice_date", "<=", to);
  if (doctorId != null) rootsQuery = rootsQuery.where("invoices.doctor_id", "=", doctorId);

  let followupsQuery = db
    .selectFrom("invoices")
    .innerJoin("invoices as parent_invoices", "parent_invoices.id", "invoices.parent_invoice_id")
    .leftJoin("services", "services.id", "parent_invoices.service_id")
    .select(["invoices.paid", "parent_invoices.amount as invoice_amount", "services.lab_cost"])
    .where("invoices.parent_invoice_id", "is not", null)
    .where("invoices.invoice_date", ">=", from)
    .where("invoices.invoice_date", "<=", to);
  if (doctorId != null) followupsQuery = followupsQuery.where("parent_invoices.doctor_id", "=", doctorId);

  let manualQuery = db
    .selectFrom("expenses")
    .select("amount")
    .where("category", "=", "lab")
    .where("affects_commission", "=", 1)
    .where("expense_date", ">=", from)
    .where("expense_date", "<=", to);
  if (doctorId != null) manualQuery = manualQuery.where("doctor_id", "=", doctorId);

  const [roots, followups, manualRows] = await Promise.all([rootsQuery.execute(), followupsQuery.execute(), manualQuery.execute()]);
  const payment = calculateCollectedAfterAutomaticLab([...roots, ...followups].map((row) => ({ paid: row.paid, invoiceAmount: row.invoice_amount, labCost: row.lab_cost ?? 0 })));
  const manualLab = round2(manualRows.reduce((sum, row) => sum + row.amount, 0));
  const labCost = round2(payment.automaticLab + manualLab);
  return { grossCollected: payment.grossCollected, automaticLab: payment.automaticLab, manualLab, labCost, netCollected: round2(Math.max(0, payment.grossCollected - labCost)) };
}

// ---------------------------------------------------------------------------
// دفعة 132 — حساب موحّد لكشف الرواتب والنسب.
//
// قبل كده الحساب كان متكرر في /expenses وفي تقرير الرواتب، والمجاميع كانت
// بتقرا `hr_payroll_runs.total_amount` المتجمّد وقت الحفظ بينما الصف بيعيد
// الحساب لحظيًا — فأي تحصيل بعد الحفظ كان بيخلي الاتنين مختلفين (ده سبب فرق
// الـ5,160 في كشف سبتمبر). دلوقتي المصدر واحد: المدخلات بتتخزن (شيفتات/حوافز/
// خصومات) والفلوس بتتحسب من الأول كل مرة.
//
// ترتيب الحساب مقصود وبيكسر الدائرية:
//   1. الرواتب (ثابت ± حوافز/خصومات) — مش بتعتمد على أي وعاء.
//   2. وعاء «صافي النقدية» = المحصّل − المصروفات العادية − الرواتب المستحقة
//      كاملة. بنستخدم المستحق مش المدفوع عشان الرقم مايتغيرش مع كل دفعة سداد
//      جزئية، وبنستثني سداد النسب نفسه (excluded_from_commission_base) وإلا
//      النسبة بتقلل الوعاء اللي هي متحسبة منه.
//   3. النسب = نسبة × الوعاء المناسب لكل قاعدة.
// ---------------------------------------------------------------------------

export type PayrollPersonRow = {
  key: string;
  personType: "doctor" | "staff";
  personId: number;
  name: string;
  group: "doctor" | "employee" | "nursing";
  rule: HrRule;
  runId: number | null;
  /** وعاء النسبة المطبّق على الصف ده (شخصي / عيادة بعد المعمل / صافي نقدية). */
  base: number;
  /** تحصيل الطبيب الشخصي بعد المعمل — ثابت مهما اتغيرت المدخلات، فبيتبعت
   *  للعميل عشان يقدر يعيد الحساب لحظيًا بنفس أرقام السيرفر بالظبط. */
  personalBase: number;
  /** العدد المحسوب من أيام الشيفت — بيتعرض كمرجع حتى لو المحاسب عدّله. */
  computedShifts: number;
  shiftCountOverride: number | null;
  shiftCount: number;
  incentives: number;
  deductions: number;
  fixedAmount: number;
  salary: number;
  commission: number;
  total: number;
};

export type PayrollPeriod = {
  from: string;
  to: string;
  rows: PayrollPersonRow[];
  salaryTotal: number;
  commissionTotal: number;
  grandTotal: number;
  clinicNetCash: number;
  /** إجمالي محصّل العيادة قبل أي خصم. */
  clinicGross: number;
  /** تحصيل العيادة بعد المعمل — وعاء قاعدة 'clinic'. */
  clinicAfterLab: number;
  /** المصروفات اللي بتدخل وعاء صافي النقدية (بدون الرواتب وبدون سداد النسب). */
  otherExpenses: number;
};

/**
 * إجمالي المصروفات في الفترة اللي بتدخل وعاء «صافي النقدية».
 * بنستبعد بند الرواتب (`salary`) لأن الرواتب المستحقة بتتحسب من قواعد HR مش من
 * سجل المصروفات، وبنستبعد أي مصروف متعلّم `excluded_from_commission_base` — وده
 * بالظبط سداد النسب، اللي لو دخل الوعاء يبقى بيقلل نفسه.
 */
async function getCommissionBaseExpenses(from: string, to: string) {
  const rows = await db
    .selectFrom("expenses")
    .select(["amount"])
    .where("expense_date", ">=", from)
    .where("expense_date", "<=", to)
    .where("category", "!=", "salary")
    .where("excluded_from_commission_base", "=", 0)
    .execute();
  return round2(rows.reduce((sum, row) => sum + row.amount, 0));
}

export async function getPayrollPeriod(from: string, to: string): Promise<PayrollPeriod> {
  const [doctors, staff, rules, runs] = await Promise.all([
    db.selectFrom("doctors").select(["id", "full_name", "active"]).orderBy("full_name").execute(),
    db.selectFrom("hr_staff").select(["id", "full_name", "active"]).orderBy("full_name").execute(),
    db
      .selectFrom("hr_compensation_rules")
      .selectAll()
      .where("active", "=", 1)
      .where("effective_from", "<=", to)
      .where((eb) => eb.or([eb("effective_to", "is", null), eb("effective_to", ">=", from)]))
      .execute(),
    db.selectFrom("hr_payroll_runs").selectAll().where("period_from", "=", from).where("period_to", "=", to).execute(),
  ]);

  // الكشف بيعرض النشطين بس. مين اتوقف بيختفي من هنا، ومصروفاته المصروفة فعلاً
  // محفوظة في سجل expenses بشكل مستقل ومابتتأثرش بده.
  const doctorNames = new Map(doctors.filter((person) => person.active === 1).map((person) => [person.id, person.full_name]));
  const staffNames = new Map(staff.filter((person) => person.active === 1).map((person) => [person.id, person.full_name]));
  const runMap = new Map(runs.map((run) => [`${run.person_type}-${run.person_id}`, run]));

  // الخطوة 1: المدخلات والرواتب — مفيش أي وعاء داخل هنا.
  const draft = rules
    .map((rule) => {
      const key = `${rule.person_type}-${rule.person_id}`;
      const name = rule.person_type === "doctor" ? doctorNames.get(rule.person_id) : staffNames.get(rule.person_id);
      if (!name) return null;
      const run = runMap.get(key);
      const computedShifts = rule.fixed_basis === "shift" ? countShiftDaysInPeriod(rule.shift_weekdays, from, to) : 0;
      const shiftCountOverride = run?.shift_count_override ?? null;
      const shiftCount = shiftCountOverride ?? computedShifts;
      const incentives = run?.incentives ?? 0;
      const deductions = run?.deductions ?? 0;
      const fixedAmount =
        rule.compensation_type === "percentage"
          ? 0
          : round2(rule.fixed_basis === "shift" ? rule.fixed_amount * Math.max(0, shiftCount) : rule.fixed_amount);
      return {
        key,
        name,
        rule: rule as HrRule,
        personType: rule.person_type,
        personId: rule.person_id,
        group: rule.staff_group,
        runId: run?.id ?? null,
        computedShifts,
        shiftCountOverride,
        shiftCount,
        incentives,
        deductions,
        fixedAmount,
        salary: round2(Math.max(0, fixedAmount + incentives - deductions)),
      };
    })
    .filter((row): row is NonNullable<typeof row> => row !== null);

  // الخطوة 2: الوعاءات. تحصيل العيادة بيتجاب مرة واحدة ويتشارك، وتحصيل الطبيب
  // الشخصي بيتجاب بس للقواعد اللي محتاجاه فعلاً.
  const needsClinic = draft.some((row) => row.rule.percentage_basis !== "personal");
  const needsNetCash = draft.some((row) => row.rule.percentage_basis === "clinic_net_cash");
  // بنجيب أرقام العيادة دايمًا (مش بس لما قاعدة محتاجاها) عشان تتبعت للعميل
  // ويقدر يعيد حساب الوعاء لحظيًا وهو بيكتب، بنفس معادلة السيرفر بالظبط.
  const clinicCollection = await getCollectedAfterLab(from, to, null);
  const otherExpenses = await getCommissionBaseExpenses(from, to);
  const accruedSalaries = round2(draft.reduce((sum, row) => sum + row.salary, 0));
  const clinicNetCash = round2(Math.max(0, clinicCollection.grossCollected - otherExpenses - accruedSalaries));
  void needsClinic;
  void needsNetCash;

  const personalIds = [...new Set(draft.filter((row) => row.rule.percentage_basis === "personal" && row.personType === "doctor").map((row) => row.personId))];
  const personalCollections = new Map<number, number>();
  await Promise.all(
    personalIds.map(async (doctorId) => {
      const collection = await getCollectedAfterLab(from, to, doctorId);
      personalCollections.set(doctorId, collection.netCollected);
    })
  );

  // الخطوة 3: النسب.
  const rows: PayrollPersonRow[] = draft.map((row) => {
    const base =
      row.rule.percentage_basis === "clinic_net_cash"
        ? clinicNetCash
        : row.rule.percentage_basis === "clinic"
          ? clinicCollection.netCollected
          : personalCollections.get(row.personId) ?? 0;
    const calculated = calculateHrPayroll(row.rule, base, row.shiftCount);
    const commission = round2(Math.max(0, calculated.percentageAmount));
    return { ...row, base, personalBase: personalCollections.get(row.personId) ?? 0, commission, total: round2(row.salary + commission) };
  });

  return {
    from,
    to,
    rows,
    salaryTotal: round2(rows.reduce((sum, row) => sum + row.salary, 0)),
    commissionTotal: round2(rows.reduce((sum, row) => sum + row.commission, 0)),
    grandTotal: round2(rows.reduce((sum, row) => sum + row.total, 0)),
    clinicNetCash,
    clinicGross: clinicCollection.grossCollected,
    clinicAfterLab: clinicCollection.netCollected,
    otherExpenses,
  };
}

/** دفعات سداد الرواتب/النسب المسجّلة لفترة، مرتّبة بتاريخ السداد الفعلي. */
export async function getPeriodSettlements(from: string, to: string) {
  return db
    .selectFrom("hr_period_settlements")
    .selectAll()
    .where("period_from", "=", from)
    .where("period_to", "=", to)
    .orderBy("paid_date")
    .orderBy("id")
    .execute();
}
