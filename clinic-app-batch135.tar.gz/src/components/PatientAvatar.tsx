"use client";

// Batch 126: صورة ملف المريض — نسخة صغيرة مستقلة عن صور المريض نفسها.
// الدوسة عليها بتفتح بوكس فيه الصورة كبيرة وتحتها: تغييرها من صور المريض،
// رفع صورة من الكمبيوتر، أو شيلها (وترجع الحروف الأولى).

import { useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  clearPatientAvatarAction,
  listAvatarCandidatesAction,
  setPatientAvatarAction,
  type TemplateImage,
} from "@/app/patients/[id]/images/template-actions";
import { uploadPatientFiles } from "@/lib/patient-file-upload";
import { getClinicToday } from "@/lib/clinic-date";
import { IMAGE_KIND_LABELS, isImageKind } from "@/lib/images/kinds";

type Props = {
  patientId: number;
  patientName: string;
  avatarPath: string | null;
  /** شكل الدائرة: هيدر الملف الطبي أو هيدر شارت التقويم. */
  className?: string;
  editable?: boolean;
};

export default function PatientAvatar({ patientId, patientName, avatarPath, className = "patient-initial-avatar", editable = true }: Props) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [candidates, setCandidates] = useState<TemplateImage[] | null>(null);
  const [busy, startTransition] = useTransition();
  const [error, setError] = useState("");
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const initials = patientName.trim().split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase() || "P";

  useEffect(() => {
    if (!open || candidates) return;
    listAvatarCandidatesAction(patientId).then(setCandidates).catch(() => setCandidates([]));
  }, [open, candidates, patientId]);

  function choose(imageId: number) {
    setError("");
    startTransition(async () => {
      const result = await setPatientAvatarAction(patientId, imageId);
      if (!result.ok) { setError(result.error || "تعذر تحديث صورة الملف."); return; }
      router.refresh();
      setOpen(false);
    });
  }

  function remove() {
    setError("");
    startTransition(async () => {
      const result = await clearPatientAvatarAction(patientId);
      if (!result.ok) { setError(result.error || "تعذر حذف صورة الملف."); return; }
      router.refresh();
      setOpen(false);
    });
  }

  async function uploadFromComputer(file: File) {
    setError("");
    setUploading(true);
    try {
      // بتترفع كصورة عادية للمريض (مجموعة "صورة الملف") وبعدين تتحدد كصورة ملف.
      const result = await uploadPatientFiles({ patientId, takenAt: getClinicToday(), label: "صورة الملف", files: [file] });
      if (result.duplicates.length) {
        setError("الصورة دي مرفوعة قبل كده لنفس المريض — اختارها من صور المريض تحت بدل ما ترفعها تاني.");
        return;
      }
      const list = await listAvatarCandidatesAction(patientId);
      setCandidates(list);
      const newest = list.reduce<TemplateImage | null>((best, image) => (!best || image.id > best.id ? image : best), null);
      if (newest) choose(newest.id);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "تعذر رفع الصورة.");
    } finally {
      setUploading(false);
    }
  }

  return (
    <>
      {avatarPath ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={avatarPath}
          alt={patientName}
          onClick={() => editable && setOpen(true)}
          className={`${className} patient-photo-avatar ${editable ? "is-clickable" : ""}`}
          title={editable ? "دوس لتغيير صورة الملف" : undefined}
        />
      ) : (
        <div
          className={`${className} ${editable ? "is-clickable" : ""}`}
          onClick={() => editable && setOpen(true)}
          title={editable ? "دوس لاختيار صورة الملف" : undefined}
        >
          {initials}
        </div>
      )}

      {open && (
        <div className="fixed inset-0 z-[85] flex items-center justify-center bg-black/50 p-4" role="dialog" aria-modal="true" aria-label="صورة ملف المريض" onClick={() => setOpen(false)}>
          <div className="card-3d w-full max-w-2xl max-h-[92vh] overflow-y-auto rounded-xl p-4 text-right" onClick={(event) => event.stopPropagation()}>
            <div className="flex items-center justify-between gap-2">
              <h3 className="font-semibold">صورة ملف المريض</h3>
              <button type="button" onClick={() => setOpen(false)} className="rounded-md border border-border px-3 py-1.5 text-sm hover:bg-primary-soft">إغلاق</button>
            </div>

            {avatarPath ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={avatarPath} alt={patientName} className="patient-avatar-large" />
            ) : (
              <p className="mt-4 text-sm text-muted">مفيش صورة ملف حاليًا — اختر واحدة من صور المريض أو ارفع صورة.</p>
            )}

            {error && <p className="mt-2 text-sm text-danger">{error}</p>}

            <div className="mt-4 flex flex-wrap gap-2">
              <button type="button" disabled={busy || uploading} onClick={() => fileInputRef.current?.click()} className="rounded-md border border-border px-3 py-2 text-sm hover:bg-primary-soft disabled:opacity-50">
                {uploading ? "جارٍ الرفع…" : "رفع صورة من الكمبيوتر"}
              </button>
              {avatarPath && (
                <button type="button" disabled={busy || uploading} onClick={remove} className="rounded-md bg-danger-soft px-3 py-2 text-sm text-danger hover:opacity-85 disabled:opacity-50">
                  حذف صورة الملف
                </button>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  event.target.value = "";
                  if (file) uploadFromComputer(file);
                }}
              />
            </div>

            <h4 className="mt-5 text-sm font-semibold">اختيار من صور المريض</h4>
            {candidates === null ? (
              <p className="mt-2 text-sm text-muted">جارٍ تحميل الصور…</p>
            ) : candidates.length === 0 ? (
              <p className="mt-2 text-sm text-muted">مفيش صور مرفوعة للمريض ده.</p>
            ) : (
              <div className="patient-avatar-picker mt-2">
                {candidates.map((image) => (
                  <button key={image.id} type="button" disabled={busy} onClick={() => choose(image.id)} title={image.kind && isImageKind(image.kind) ? IMAGE_KIND_LABELS[image.kind] : "صورة"}>
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={image.filePath} alt={image.kind && isImageKind(image.kind) ? IMAGE_KIND_LABELS[image.kind] : "صورة"} />
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
