"use client";

import { useEffect, useRef, useState } from "react";
import ServiceCombobox from "./ServiceCombobox";
import {
  addExpenseAction,
  findLabInvoiceDoctorAction,
  searchPatientsForExpenseAction,
  type ExpensePatientSearchResult,
} from "@/app/expenses/actions";

// دفعة 134 — فورم مصروف المعمل اليدوي بقى Client Component.
//
// كان فورم سيرفر عادي بخانتين <select> (مريض / خدمة) بيتحمّلوا كاملين مع كل
// فتحة للصفحة. التحويل هنا بيحل تلات حاجات مع بعض:
//   1. المريض: بحث على السيرفر بأي جزء من الاسم أو رقم الملف أو الهاتف، بدل
//      البحث بالحرف الأول اللي بيعمله <select> لوحده. والصفحة بقت أخف لأن
//      قايمة المرضى مابقتش بتتبعت أصلاً.
//   2. الخدمة: ServiceCombobox الموجود في السيستم — بيدور بالاسم العربي
//      والإنجليزي والكود، زي الفواتير والجدول المركزي بالظبط.
//   3. الطبيب: بيتملى من فاتورة نفس المريض/الخدمة، مع تحذير لو المستخدم غيّره.

type Doctor = { id: number; full_name: string; active: number };
type Service = { id: number; name: string; code: string | null; has_lab_cost: number; lab_cost: number };

const field = "w-full rounded border border-border bg-background px-2 py-2 text-sm";

export default function ManualLabExpenseForm({ doctors, services, today }: { doctors: Doctor[]; services: Service[]; today: string }) {
  const [patientQuery, setPatientQuery] = useState("");
  const [patientResults, setPatientResults] = useState<ExpensePatientSearchResult[]>([]);
  const [patient, setPatient] = useState<ExpensePatientSearchResult | null>(null);
  const [patientOpen, setPatientOpen] = useState(false);

  const [serviceId, setServiceId] = useState("");
  const [doctorId, setDoctorId] = useState("");
  // الطبيب المقترح من الفاتورة — بنحتفظ بيه عشان نقارن بيه لو المستخدم غيّر
  // الاختيار، مش عشان نمنعه.
  const [invoiceDoctor, setInvoiceDoctor] = useState<{ doctorId: number; doctorName: string } | null>(null);

  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onClickOutside(event: MouseEvent) {
      if (wrapRef.current && !wrapRef.current.contains(event.target as Node)) setPatientOpen(false);
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  // تأخير بسيط قبل السؤال عشان ماتبعتش طلب مع كل حرف. 250ms قريبة من سرعة
  // الكتابة الطبيعية فالنتايج بتحس إنها فورية.
  // ملحوظة: مفيش setState متزامن جوه الـeffect (ولا حتى لتفضية النتايج) —
  // القاعدة دي مفروضة على مستوى المشروع في react-hooks/set-state-in-effect.
  // بدل التفضية، شرط العرض نفسه تحت بيتحقق من طول النص، فالنتايج القديمة
  // مابتظهرش أصلاً لما المستخدم يمسح اللي كتبه.
  useEffect(() => {
    const term = patientQuery.trim();
    if (patient || term.length < 2) return;
    let cancelled = false;
    const timer = setTimeout(() => {
      searchPatientsForExpenseAction(term).then((rows) => {
        if (!cancelled) setPatientResults(rows);
      });
    }, 250);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [patientQuery, patient]);

  // أول ما المريض والخدمة يتحددوا، نجيب الطبيب من الفاتورة ونملاه.
  useEffect(() => {
    if (!patient || !serviceId) return;
    let cancelled = false;
    findLabInvoiceDoctorAction(patient.id, Number(serviceId)).then((found) => {
      if (cancelled) return;
      setInvoiceDoctor(found);
      // مابنكتبش فوق اختيار المستخدم غير لو الخانة لسه فاضية — لو هو اختار
      // طبيب بنفسه قبل ما يحدد الخدمة، اختياره بيفضل والتحذير بيظهر بدلاً منه.
      if (found) setDoctorId((current) => (current === "" ? String(found.doctorId) : current));
    });
    return () => {
      cancelled = true;
    };
  }, [patient, serviceId]);

  // الاقتراح بيتحسب عند العرض بس لما المريض والخدمة الاتنين متحددين — كده
  // اقتراح قديم مابيفضلش ظاهر بعد ما المستخدم يمسح اختياره.
  const suggestion = patient && serviceId ? invoiceDoctor : null;
  const mismatch = suggestion != null && doctorId !== "" && Number(doctorId) !== suggestion.doctorId;
  const showPatientResults = patientOpen && !patient && patientQuery.trim().length >= 2 && patientResults.length > 0;
  const selectedService = services.find((service) => String(service.id) === serviceId);

  function reset() {
    setPatient(null);
    setPatientQuery("");
    setPatientResults([]);
    setServiceId("");
    setDoctorId("");
    setInvoiceDoctor(null);
  }

  return (
    <form
      action={async (formData) => {
        await addExpenseAction(formData);
        reset();
      }}
      className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 items-end"
    >
      <input type="hidden" name="category" value="lab" />

      <label>
        <span className="block text-xs text-muted mb-1">التاريخ</span>
        <input name="expense_date" type="date" required defaultValue={today} className={field} />
      </label>

      <div ref={wrapRef} className="relative">
        <span className="block text-xs text-muted mb-1">المريض (اختياري)</span>
        <input type="hidden" name="patient_id" value={patient?.id ?? ""} />
        {patient ? (
          <div className="flex items-center justify-between gap-2 rounded border border-border bg-background px-2 py-2 text-sm">
            <span className="truncate">
              {patient.full_name} — {patient.file_number}
            </span>
            <button
              type="button"
              onClick={() => {
                setPatient(null);
                setPatientQuery("");
              }}
              className="shrink-0 text-xs text-muted hover:text-danger"
            >
              تغيير
            </button>
          </div>
        ) : (
          <input
            type="text"
            value={patientQuery}
            onChange={(event) => {
              setPatientQuery(event.target.value);
              setPatientOpen(true);
            }}
            onFocus={() => setPatientOpen(true)}
            placeholder="ابحث بالاسم أو رقم الملف أو الهاتف..."
            className={field}
          />
        )}
        {showPatientResults && (
          <div className="absolute z-20 mt-1 w-full card-3d rounded-md overflow-hidden max-h-56 overflow-y-auto">
            {patientResults.map((row) => (
              <button
                key={row.id}
                type="button"
                onClick={() => {
                  setPatient(row);
                  setPatientOpen(false);
                }}
                className="block w-full text-right border-b border-border last:border-0 px-3 py-2 hover:bg-primary-soft"
              >
                <strong className="text-sm">{row.full_name}</strong>
                <span className="block text-xs text-muted">
                  {row.file_number}
                  {row.phone ? ` — ${row.phone}` : ""}
                </span>
              </button>
            ))}
          </div>
        )}
      </div>

      <div>
        <span className="block text-xs text-muted mb-1">الخدمة (اختياري)</span>
        <ServiceCombobox
          name="service_id"
          services={services}
          value={serviceId}
          onChange={setServiceId}
          placeholder="اكتب اسم الخدمة أو كودها..."
        />
        {selectedService?.has_lab_cost === 1 && selectedService.lab_cost > 0 && (
          <p className="mt-1 text-xs text-danger">
            الخدمة دي تكلفة معملها معرّفة جواها ({selectedService.lab_cost} ج.م) وبتتخصم تلقائيًا — تسجيلها هنا كمان هيخصمها مرتين.
          </p>
        )}
      </div>

      <label>
        <span className="block text-xs text-muted mb-1">الطبيب *</span>
        <select name="doctor_id" required value={doctorId} onChange={(event) => setDoctorId(event.target.value)} className={field}>
          <option value="">اختر الطبيب</option>
          {doctors
            .filter((doctor) => doctor.active === 1)
            .map((doctor) => (
              <option key={doctor.id} value={doctor.id}>
                {doctor.full_name}
              </option>
            ))}
        </select>
        {suggestion && !mismatch && <p className="mt-1 text-xs text-muted">اتملى من فاتورة المريض.</p>}
        {mismatch && (
          <p className="mt-1 text-xs text-warning">
            تنبيه: الفاتورة دي مسجّلة على د. {suggestion.doctorName} — التكلفة هتتخصم من نسبة الطبيب اللي اخترته.
          </p>
        )}
      </label>

      <label>
        <span className="block text-xs text-muted mb-1">البيان *</span>
        <input name="title" required placeholder="مثال: معمل كراون زيركون" className={field} />
      </label>

      <label>
        <span className="block text-xs text-muted mb-1">التكلفة *</span>
        <input name="amount" type="number" min="0.01" step="0.01" required className={field} />
      </label>

      <label>
        <span className="block text-xs text-muted mb-1">المعمل</span>
        <input name="payee" placeholder="اسم المعمل" className={field} />
      </label>

      <label>
        <span className="block text-xs text-muted mb-1">ملاحظة</span>
        <input name="note" className={field} />
      </label>

      <button className="rounded-md btn-3d-primary px-4 py-2 text-sm">حفظ تكلفة المعمل</button>
    </form>
  );
}
