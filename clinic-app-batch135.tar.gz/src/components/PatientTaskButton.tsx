"use client";

import { useEffect, useState, useTransition } from "react";
import { createTaskAction, getTaskRecipientsAction } from "@/app/tasks/actions";

type Recipient = { id: number; full_name: string; role: string };

export default function PatientTaskButton({ patientId, patientName }: { patientId: number; patientName: string }) {
  const [open, setOpen] = useState(false);
  const [recipients, setRecipients] = useState<Recipient[]>([]);
  const [busy, startTransition] = useTransition();
  useEffect(() => { if (open && !recipients.length) getTaskRecipientsAction().then(setRecipients).catch(() => undefined); }, [open, recipients.length]);
  function create(formData: FormData) {
    startTransition(async () => {
      const recipient = String(formData.get("recipient") || "reception");
      const result = await createTaskAction({ taskText: String(formData.get("task_text") || ""), recipientType: recipient === "reception" ? "reception" : "user", recipientUserId: recipient === "reception" ? null : Number(recipient), patientId });
      if (!result.ok) return window.alert(result.reason || "تعذر حفظ المهمة.");
      setOpen(false);
    });
  }
  return <div className="relative"><button type="button" onClick={() => setOpen((value) => !value)} className="px-3 py-2 rounded-md border border-border text-sm hover:bg-primary-soft whitespace-nowrap">Tasks</button>{open && <div className="absolute z-40 right-0 top-full mt-2 w-[min(24rem,calc(100vw-2rem))] max-w-[calc(100vw-2rem)] card-3d rounded-xl p-3 shadow-xl" dir="rtl"><div className="mb-2 text-sm font-semibold">مهمة مرتبطة بـ {patientName}</div><form action={create} className="space-y-2"><textarea name="task_text" required maxLength={2000} rows={3} placeholder="اكتب المهمة المطلوبة" className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" /><select name="recipient" defaultValue="reception" className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"><option value="reception">فريق الاستقبال</option>{recipients.map((user) => <option key={user.id} value={user.id}>{user.full_name}</option>)}</select><div className="flex gap-2"><button disabled={busy} className="rounded-md btn-3d-primary px-3 py-1.5 text-sm">إرسال</button><button type="button" onClick={() => setOpen(false)} className="rounded-md border border-border px-3 py-1.5 text-sm">إلغاء</button></div></form></div>}</div>;
}
