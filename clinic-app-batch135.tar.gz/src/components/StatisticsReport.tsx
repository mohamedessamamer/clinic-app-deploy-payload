"use client";

import { useEffect, useMemo, useState, useTransition } from "react";
import {
  getStatisticsReportAction,
  type StatisticsMetric,
  type StatisticsMode,
  type StatisticsResult,
} from "@/app/reports/statistics-actions";
import { CLINIC_TIMEZONE } from "@/lib/clinic-date";

// دفعة 134 — واجهة تقرير الإحصائيات.
//
// المحصّل هو المؤشر الافتراضي عن قصد: هو الرقم الوحيد الموثوق عبر كل تاريخ
// العيادة. المصروفات اتسجّلت في السيستم من شهر معيّن، فأي فترة أقدم بتعرض
// «—» مش صفر — صفر كان هيبان كأن العيادة مصرفتش حاجة والصافي هيطلع مضروب.

const MODES: { key: StatisticsMode; label: string }[] = [
  { key: "month", label: "شهر بشهر" },
  { key: "quarter", label: "ربع بربع" },
  { key: "half", label: "نص سنة" },
  { key: "year", label: "سنة بسنة" },
  { key: "same_month", label: "نفس الشهر عبر السنين" },
  { key: "within_year", label: "الشهر مقابل شهور سنته" },
];

const METRICS: { key: StatisticsMetric; label: string }[] = [
  { key: "collected", label: "المحصّل" },
  { key: "expenses", label: "المصروفات" },
  { key: "netCash", label: "صافي النقدية" },
];

const ARABIC_MONTHS = [
  "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر",
];

const clinicTodayFormatter = new Intl.DateTimeFormat("en-CA", {
  timeZone: CLINIC_TIMEZONE,
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});

function money(value: number | null): string {
  if (value == null) return "—";
  return Math.round(value).toLocaleString("en-US");
}

/** نسبة التغيّر، أو null لو المقارنة مالهاش معنى (أساس صفر أو قيمة ناقصة). */
function changePercent(current: number | null, previous: number | null): number | null {
  if (current == null || previous == null || previous === 0) return null;
  return Math.round(((current - previous) / previous) * 1000) / 10;
}

const chipBase = "rounded-md border px-3 py-1.5 text-sm transition-colors";
const chipOn = "border-primary bg-primary text-white font-medium";
const chipOff = "border-border hover:bg-primary-soft";
const selectClass = "rounded border border-border bg-background px-2 py-1.5 text-sm";

export default function StatisticsReport() {
  const today = clinicTodayFormatter.format(new Date());
  const currentYear = Number(today.slice(0, 4));
  const currentMonth = Number(today.slice(5, 7));

  const [mode, setMode] = useState<StatisticsMode>("month");
  const [metric, setMetric] = useState<StatisticsMetric>("collected");
  const [year, setYear] = useState(currentYear);
  const [month, setMonth] = useState(currentMonth);
  const [part, setPart] = useState(Math.ceil(currentMonth / 3));
  const [span, setSpan] = useState(5);
  const [result, setResult] = useState<StatisticsResult | null>(null);
  const [isPending, startTransition] = useTransition();

  // التقرير بيتحدّث لوحده مع أي تغيير في الاختيارات — مفيش زرار "تطبيق".
  // الحساب كله بيتعمل على سلسلة شهرية واحدة محمّلة مرة واحدة، فالتكلفة تافهة
  // والانتظار بيبقى مالوش مبرر.
  useEffect(() => {
    let cancelled = false;
    startTransition(async () => {
      const data = await getStatisticsReportAction({ mode, metric, year, month, part, span });
      if (!cancelled) setResult(data);
    });
    return () => {
      cancelled = true;
    };
  }, [mode, metric, year, month, part, span]);

  // في useMemo عشان المرجع مايتغيرش كل رندر — من غيره الـuseMemo اللي تحته
  // بيعيد الحساب كل مرة ومابيبقاش ليه لازمة.
  const buckets = useMemo(() => (result?.ok ? result.buckets : []), [result]);
  const values = useMemo(
    () => buckets.map((bucket) => (metric === "collected" ? bucket.collected : metric === "expenses" ? bucket.expenses : bucket.netCash)),
    [buckets, metric]
  );
  const maxValue = useMemo(() => Math.max(1, ...values.map((value) => value ?? 0)), [values]);

  const latest = buckets.length ? buckets[buckets.length - 1] : null;
  const previous = buckets.length > 1 ? buckets[buckets.length - 2] : null;

  const years = result?.ok && result.years.length ? result.years : [currentYear];
  const needsMonth = mode === "month" || mode === "same_month" || mode === "within_year";
  const needsSpan = mode === "quarter" || mode === "half" || mode === "year" || mode === "same_month";

  return (
    <section className="card-3d rounded-xl p-5 space-y-5">
      <div>
        <h2 className="font-semibold">الإحصائيات</h2>
        <p className="mt-1 text-xs text-muted">
          مقارنة الفترات ببعضها والاتجاه عبر السنين. المحصّل متاح لكل تاريخ العيادة؛ المصروفات وصافي النقدية بيظهروا من أول شهر اتسجّلت فيه مصروفات
          {result?.ok && result.expensesFrom ? ` (${result.expensesFrom})` : ""}، وقبل كده بيتعرضوا «—» مش صفر.
        </p>
      </div>

      {/* الاختيارات */}
      <div className="space-y-3 rounded-lg border border-border p-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-muted w-20 shrink-0">وحدة المقارنة</span>
          {MODES.map((item) => (
            <button
              key={item.key}
              type="button"
              aria-pressed={mode === item.key}
              onClick={() => setMode(item.key)}
              className={`${chipBase} ${mode === item.key ? chipOn : chipOff}`}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-muted w-20 shrink-0">المؤشر</span>
          {METRICS.map((item) => (
            <button
              key={item.key}
              type="button"
              aria-pressed={metric === item.key}
              onClick={() => setMetric(item.key)}
              className={`${chipBase} ${metric === item.key ? chipOn : chipOff}`}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-end gap-3 border-t border-border pt-3">
          <label className="text-xs text-muted">
            السنة
            <select value={year} onChange={(event) => setYear(Number(event.target.value))} className={`${selectClass} mt-1 block`}>
              {years.map((item) => (
                <option key={item} value={item}>{item}</option>
              ))}
            </select>
          </label>

          {needsMonth && (
            <label className="text-xs text-muted">
              الشهر
              <select value={month} onChange={(event) => setMonth(Number(event.target.value))} className={`${selectClass} mt-1 block`}>
                {ARABIC_MONTHS.map((label, index) => (
                  <option key={label} value={index + 1}>{label}</option>
                ))}
              </select>
            </label>
          )}

          {mode === "quarter" && (
            <label className="text-xs text-muted">
              الربع
              <select value={part} onChange={(event) => setPart(Number(event.target.value))} className={`${selectClass} mt-1 block`}>
                {[1, 2, 3, 4].map((item) => (
                  <option key={item} value={item}>الربع {item}</option>
                ))}
              </select>
            </label>
          )}

          {mode === "half" && (
            <label className="text-xs text-muted">
              النص
              <select value={part} onChange={(event) => setPart(Number(event.target.value))} className={`${selectClass} mt-1 block`}>
                <option value={1}>النص الأول</option>
                <option value={2}>النص التاني</option>
              </select>
            </label>
          )}

          {needsSpan && (
            <label className="text-xs text-muted">
              عدد السنوات المعروضة
              <select value={span} onChange={(event) => setSpan(Number(event.target.value))} className={`${selectClass} mt-1 block`}>
                {[2, 3, 4, 5, 6, 7, 8, 9, 10].map((item) => (
                  <option key={item} value={item}>{item}</option>
                ))}
              </select>
            </label>
          )}

          {isPending && <span className="text-xs text-muted pb-2">بيحسب...</span>}
        </div>
      </div>

      {result && !result.ok && (
        <p className="rounded-md border border-danger bg-danger-soft px-3 py-2 text-sm text-danger">{result.error}</p>
      )}

      {result?.ok && result.metricUnavailable && (
        <p className="rounded-md border border-warning bg-warning-soft px-3 py-2 text-sm text-warning">
          المؤشر ده مش متاح للفترات المعروضة — المصروفات في السيستم بتبدأ من {result.expensesFrom ?? "—"}. جرّب «المحصّل» أو فترة أحدث.
        </p>
      )}

      {result?.ok && buckets.length > 0 && !result.metricUnavailable && (
        <>
          {/* بطاقات آخر فترة مقابل اللي قبلها */}
          {latest && (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
              <StatCard title="المحصّل" current={latest.collected} previous={previous?.collected ?? null} higherIsBetter />
              <StatCard title="المصروفات" current={latest.expenses} previous={previous?.expenses ?? null} higherIsBetter={false} />
              <StatCard title="صافي النقدية" current={latest.netCash} previous={previous?.netCash ?? null} higherIsBetter />
              <StatCard title="عدد الفواتير" current={latest.invoiceCount} previous={previous?.invoiceCount ?? null} higherIsBetter plain />
            </div>
          )}

          {/* الرسم */}
          <div className="rounded-lg border border-border p-4">
            <div className="flex items-baseline justify-between gap-3 mb-4">
              <h3 className="text-sm font-semibold">{METRICS.find((item) => item.key === metric)?.label} لكل فترة</h3>
              {latest?.partial && <span className="text-xs text-warning">آخر عمود لفترة لسه شغالة — رقمه ناقص بطبيعته.</span>}
            </div>
            <div className="flex items-end gap-2 overflow-x-auto pb-1" style={{ minHeight: "200px" }}>
              {buckets.map((bucket, index) => {
                const value = values[index];
                const height = value == null ? 0 : Math.round((value / maxValue) * 160);
                return (
                  <div key={bucket.key} className="flex min-w-16 flex-1 flex-col items-center gap-1.5">
                    <span className="text-xs font-semibold whitespace-nowrap">{money(value)}</span>
                    {value == null ? (
                      <div className="w-full rounded-t border border-dashed border-border" style={{ height: "24px" }} />
                    ) : (
                      <div
                        className={`w-full rounded-t ${bucket.partial ? "bg-primary/45" : "bg-primary"}`}
                        style={{ height: `${Math.max(3, height)}px` }}
                      />
                    )}
                    <span className="text-xs text-muted text-center whitespace-nowrap">{bucket.label}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* الجدول */}
          <div className="overflow-x-auto rounded-lg border border-border">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-primary-soft text-right">
                  <th className="p-2 whitespace-nowrap">الفترة</th>
                  <th className="p-2 whitespace-nowrap">المحصّل</th>
                  <th className="p-2 whitespace-nowrap">المصروفات</th>
                  <th className="p-2 whitespace-nowrap">صافي النقدية</th>
                  <th className="p-2 whitespace-nowrap">الفواتير</th>
                  <th className="p-2 whitespace-nowrap">التغيّر</th>
                </tr>
              </thead>
              <tbody>
                {buckets.map((bucket, index) => {
                  const value = values[index];
                  const before = index > 0 ? values[index - 1] : null;
                  const change = changePercent(value, before);
                  const good = change == null ? null : metric === "expenses" ? change < 0 : change > 0;
                  return (
                    <tr key={bucket.key} className="border-t border-border">
                      <td className="p-2 font-medium whitespace-nowrap">
                        {bucket.label}
                        {bucket.partial && <span className="mr-1 text-xs text-warning">(جارية)</span>}
                      </td>
                      <td className="p-2 font-bold whitespace-nowrap">{money(bucket.collected)}</td>
                      <td className={`p-2 whitespace-nowrap ${bucket.expenses == null ? "text-muted" : "text-danger"}`}>{money(bucket.expenses)}</td>
                      <td className="p-2 font-bold whitespace-nowrap">{money(bucket.netCash)}</td>
                      <td className="p-2 text-muted whitespace-nowrap">{bucket.invoiceCount}</td>
                      <td className={`p-2 font-semibold whitespace-nowrap ${good == null ? "text-muted" : good ? "text-success" : "text-danger"}`}>
                        {change == null ? "—" : `${change > 0 ? "+" : ""}${change}%`}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* التحليلات */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
            <InsightList title="أعلى الفترات" rows={result.insights.best} tone="success" />
            <InsightList title="أقل الفترات" rows={result.insights.worst} tone="danger" />
            <div className="rounded-lg border border-border p-4 space-y-3">
              <h3 className="text-sm font-semibold">الملخص</h3>
              <div>
                <span className="block text-xs text-muted">متوسط الفترات المكتملة</span>
                <span className="text-xl font-bold">{money(result.insights.average)}</span>
              </div>
              <div>
                <span className="block text-xs text-muted">متوسط التغيّر من فترة للي بعدها</span>
                <span className={`text-xl font-bold ${result.insights.averageGrowth == null ? "text-muted" : result.insights.averageGrowth >= 0 ? "text-success" : "text-danger"}`}>
                  {result.insights.averageGrowth == null ? "—" : `${result.insights.averageGrowth > 0 ? "+" : ""}${result.insights.averageGrowth}%`}
                </span>
              </div>
              <p className="text-xs text-muted">الفترات الجارية مستثناة من الحسابين دول — رقمها ناقص فبيلخبط المتوسط والترتيب.</p>
            </div>
          </div>

          <Heatmap months={result.months} metric={metric} />
        </>
      )}
    </section>
  );
}

function StatCard({
  title,
  current,
  previous,
  higherIsBetter,
  plain = false,
}: {
  title: string;
  current: number | null;
  previous: number | null;
  higherIsBetter: boolean;
  plain?: boolean;
}) {
  const change = changePercent(current, previous);
  const good = change == null ? null : higherIsBetter ? change > 0 : change < 0;
  return (
    <div className="rounded-lg border border-border p-3">
      <div className="text-xs text-muted">{title}</div>
      <div className={`mt-1 text-2xl font-bold ${!plain && title === "المصروفات" && current != null ? "text-danger" : ""}`}>
        {plain ? (current ?? "—") : money(current)}
      </div>
      <div className="mt-1 flex items-center gap-2 text-xs">
        <span className={`font-semibold ${good == null ? "text-muted" : good ? "text-success" : "text-danger"}`}>
          {change == null ? "—" : `${change > 0 ? "+" : ""}${change}%`}
        </span>
        <span className="text-muted">مقابل {plain ? (previous ?? "—") : money(previous)}</span>
      </div>
    </div>
  );
}

function InsightList({ title, rows, tone }: { title: string; rows: { ym: string; label: string; value: number }[]; tone: "success" | "danger" }) {
  return (
    <div className="rounded-lg border border-border p-4 space-y-2">
      <h3 className="text-sm font-semibold">{title}</h3>
      {rows.length === 0 && <p className="text-xs text-muted">مفيش فترات مكتملة كفاية للترتيب.</p>}
      {rows.map((row) => (
        <div key={row.ym} className="flex items-center justify-between gap-2 border-b border-border pb-1.5 last:border-0">
          <span className="text-sm">{row.label}</span>
          <span className={`text-sm font-bold ${tone === "success" ? "text-success" : "text-danger"}`}>{money(row.value)}</span>
        </div>
      ))}
    </div>
  );
}

/**
 * خريطة الموسمية: شهر × سنة.
 *
 * الغرض منها إن الموسمية تبان بنظرة واحدة — أي شهر بيقع كل سنة وأي شهر بيعلا،
 * وده حاجة الجدول العادي بيخفيها لأنه بيعرض فترة واحدة في المرة.
 */
function Heatmap({ months, metric }: { months: { ym: string; collected: number; expenses: number | null; netCash: number | null }[]; metric: StatisticsMetric }) {
  const rows = useMemo(() => {
    const byYear = new Map<number, (number | null)[]>();
    for (const point of months) {
      const year = Number(point.ym.slice(0, 4));
      const index = Number(point.ym.slice(5, 7)) - 1;
      if (!byYear.has(year)) byYear.set(year, Array(12).fill(null));
      const value = metric === "collected" ? point.collected : metric === "expenses" ? point.expenses : point.netCash;
      byYear.get(year)![index] = value;
    }
    return [...byYear.entries()].sort((a, b) => a[0] - b[0]);
  }, [months, metric]);

  const max = useMemo(() => {
    const all = rows.flatMap(([, cells]) => cells).filter((value): value is number => value != null);
    return all.length ? Math.max(...all) : 0;
  }, [rows]);

  if (!rows.length || max <= 0) return null;

  return (
    <div className="rounded-lg border border-border p-4 space-y-3">
      <h3 className="text-sm font-semibold">خريطة الموسمية — {METRICS.find((item) => item.key === metric)?.label} بالشهر والسنة</h3>
      <div className="overflow-x-auto">
        <table className="w-full border-separate" style={{ borderSpacing: "3px" }}>
          <thead>
            <tr>
              <th className="w-12" />
              {ARABIC_MONTHS.map((label) => (
                <th key={label} className="pb-1 text-xs font-medium text-muted">{label.slice(0, 3)}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map(([year, cells]) => (
              <tr key={year}>
                <th className="pl-1 text-right text-xs font-bold">{year}</th>
                {cells.map((value, index) => {
                  const intensity = value == null || value <= 0 ? 0 : value / max;
                  return (
                    <td
                      key={index}
                      title={value == null ? "مفيش بيانات" : money(value)}
                      className="h-8 rounded text-center text-[10px] font-semibold"
                      style={
                        value == null
                          ? { background: "var(--primary-soft)", opacity: 0.35, color: "var(--muted)" }
                          : { background: "var(--primary)", opacity: 0.15 + intensity * 0.85, color: intensity > 0.55 ? "#fff" : "var(--foreground)" }
                      }
                    >
                      {value == null ? "—" : Math.round(value / 1000)}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-muted">الأرقام بالألف. الخانة الفاضية معناها مفيش بيانات للشهر ده، مش صفر.</p>
    </div>
  );
}
