"use client";

// Batch 124: تظبيط تمبلت صور التقويم من الإعدادات (تبويب شارت التقويم).
// كل خانة ليها اسم ونوع الصورة المتوقع فيها؛ الترتيب هنا هو ترتيب العرض،
// وعدد الأعمدة بيحدد شكل الشبكة.

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { addCustomImageKindAction, saveAutoLearnSettingAction, saveOrthoImageTemplateAction } from "@/app/settings/actions";
import { IMAGE_KIND_LABELS, imageKindFamily, isImageKind } from "@/lib/images/kinds";
import type { CustomImageKind } from "@/lib/images/custom-kinds";
import { DEFAULT_TEMPLATE, TEMPLATE_KIND_OPTIONS, type ImageTemplate, type TemplateSlot, type TemplateSlotKind } from "@/lib/images/template";

// دفعة 130 (مرحلة 5): تقسيم خانات التمبلت لـ4 أقسام بصريًا في شاشة الإعدادات
// (طلب صريح من المستخدم) — من غير أي تغيير في شكل البيانات المحفوظة (لسه
// Array مسطّح من slots بنفس ترتيبها القديم). كل خانة بتتحدد قسمها تلقائيًا
// من نوعها (kind) المختار، فمفيش حقل قسم إضافي محتاج يتخزن أو يتهجّر من
// تمبلتات قديمة.
//
// أنواع مخصّصة (custom_...): مضافة من نفس الشاشة دي (زرار "+ نوع جديد" في كل
// قسم) — بتتخزن منفصلة في ortho_custom_image_kinds، ودايمًا يدوية بس (مفيش
// تصنيف تلقائي ليها في classify.ts). المكوّن محتاج يعرف قسمها من الإعداد
// المخزّن نفسه (family) بدل ما يحاول يستنتجه من الاسم.
type TemplateSection = "face" | "intraoral" | "xray" | "template" | "other";

export default function OrthoImageTemplateForm({
  template,
  autoLearnEnabled,
  customKinds,
}: {
  template: ImageTemplate;
  autoLearnEnabled: boolean;
  customKinds: CustomImageKind[];
}) {
  const router = useRouter();
  const [columns, setColumns] = useState(template.columns);
  const [slots, setSlots] = useState<TemplateSlot[]>(template.slots);
  const [message, setMessage] = useState("");
  const [saving, startSaving] = useTransition();
  const [autoLearn, setAutoLearn] = useState(autoLearnEnabled);
  const [autoLearnBusy, startAutoLearnSaving] = useTransition();
  const [customKindList, setCustomKindList] = useState<CustomImageKind[]>(customKinds);
  const [addingSection, setAddingSection] = useState<TemplateSection | null>(null);
  const [newKindLabel, setNewKindLabel] = useState("");
  const [addKindBusy, startAddKindSaving] = useTransition();
  const [addKindError, setAddKindError] = useState("");

  const customKindByKey = useMemo(() => new Map(customKindList.map((k) => [k.key, k])), [customKindList]);

  const kindLabel = (kind: TemplateSlotKind): string => {
    if (kind === "any") return "أي صورة";
    if (isImageKind(kind)) return IMAGE_KIND_LABELS[kind];
    const custom = customKindByKey.get(kind);
    return custom ? custom.label : kind;
  };

  const sectionOf = (kind: TemplateSlotKind): TemplateSection => {
    if (kind === "any") return "other";
    if (isImageKind(kind)) return imageKindFamily(kind);
    const custom = customKindByKey.get(kind);
    return custom ? custom.family : "other";
  };

  const SECTIONS: { key: TemplateSection; label: string; defaultKind: TemplateSlotKind }[] = [
    { key: "face", label: "خارج الفم — Extra-Oral", defaultKind: "face_frontal" },
    { key: "intraoral", label: "داخل الفم — Intra-Oral", defaultKind: "intraoral_front" },
    { key: "xray", label: "الأشعة — X-ray", defaultKind: "xray_pano" },
    { key: "template", label: "تمبلت جاهز — Ready-made Template", defaultKind: "template_sheet" },
    { key: "other", label: "أخرى", defaultKind: "any" },
  ];

  // خيارات الدروب داون لكل خانة: الأنواع الثابتة + أي أنواع مخصّصة مسجّلة،
  // كل نوع تحت قسمه (custom kinds بيتحطوا بعد آخر نوع ثابت في نفس القسم).
  const kindOptionsBySection = useMemo(() => {
    const map = new Map<TemplateSection, TemplateSlotKind[]>();
    for (const section of SECTIONS) map.set(section.key, []);
    for (const kind of TEMPLATE_KIND_OPTIONS) {
      const section: TemplateSection = kind === "any" ? "other" : isImageKind(kind) ? imageKindFamily(kind) : "other";
      map.get(section)?.push(kind);
    }
    for (const custom of customKindList) {
      map.get(custom.family)?.push(custom.key);
    }
    return map;
    // eslint-disable-next-line react-hooks/exhaustive-deps -- SECTIONS ثابتة المحتوى، بتتعرّف من جديد كل render بس نفس القيم بالظبط
  }, [customKindList]);

  function addCustomKind(section: TemplateSection) {
    const label = newKindLabel.trim();
    if (!label) { setAddKindError("لازم تكتب اسم النوع."); return; }
    setAddKindError("");
    startAddKindSaving(async () => {
      const result = await addCustomImageKindAction(label, section);
      if (!result.ok || !result.kind) { setAddKindError(result.error || "تعذر الإضافة."); return; }
      setCustomKindList((current) => [...current, result.kind!]);
      setNewKindLabel("");
      setAddingSection(null);
    });
  }

  // دفعة 130: تفعيل/إيقاف "التعلم المحافظ" — راجع src/lib/images/learned-overrides.ts
  // للشروط. مفصول عن حفظ التمبلت لأنه إعداد فوري (checkbox) مش جزء من مسودة الخانات.
  function toggleAutoLearn(next: boolean) {
    setAutoLearn(next);
    const fd = new FormData();
    fd.set("enabled", next ? "1" : "0");
    startAutoLearnSaving(async () => {
      const result = await saveAutoLearnSettingAction(fd);
      if (!result.ok) setAutoLearn(!next); // فشل الحفظ — رجّع الحالة القديمة
    });
  }

  function updateSlot(index: number, patch: Partial<TemplateSlot>) {
    setSlots((current) => current.map((slot, position) => (position === index ? { ...slot, ...patch } : slot)));
  }

  // دفعة 130: التحريك بقى بيبدّل مع أقرب خانة "من نفس القسم" (مش أي خانة
  // جاورتها في القايمة)، عشان الترتيب داخل كل section يفضل مستقل عن باقي
  // الأقسام حتى لو متداخلين في الـArray الأصلي.
  function move(index: number, direction: -1 | 1) {
    setSlots((current) => {
      const family = sectionOf(current[index].kind);
      let target = index + direction;
      while (target >= 0 && target < current.length && sectionOf(current[target].kind) !== family) {
        target += direction;
      }
      if (target < 0 || target >= current.length) return current;
      const next = [...current];
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  }

  // بيضيف الخانة الجديدة جوه نفس القسم (بعد آخر خانة من نفس النوع في
  // الـArray)، عشان تفضل مبانة جنب باقي خانات قسمها.
  function addSlot(section: TemplateSection, defaultKind: TemplateSlotKind) {
    // مفتاح فريد للخانة الجديدة بس — بيتنفذ في event handler وقت الضغط على
    // الزرار، مش وقت الـrender، فمفيش أي مشكلة عدم استقرار حقيقية هنا.
    // eslint-disable-next-line react-hooks/purity
    const key = `slot_${Date.now().toString(36)}`;
    setSlots((current) => {
      let insertAt = current.length;
      for (let i = current.length - 1; i >= 0; i--) {
        if (sectionOf(current[i].kind) === section) { insertAt = i + 1; break; }
      }
      const newSlot: TemplateSlot = { key, label: kindLabel(defaultKind), kind: defaultKind };
      const next = [...current];
      next.splice(insertAt, 0, newSlot);
      return next;
    });
  }

  function save() {
    setMessage("");
    startSaving(async () => {
      const result = await saveOrthoImageTemplateAction({ columns, slots });
      setMessage(result.ok ? "اتحفظ." : result.error || "تعذر الحفظ.");
      if (result.ok) router.refresh();
    });
  }

  return (
    <div className="space-y-3">
      <div>
        <h3 className="font-semibold">تمبلت صور التقويم</h3>
        <p className="text-sm text-muted mt-1">
          لما يترفع طقم صور للمريض، السيستم بيتعرف على نوع كل صورة ويحطها في خانتها هنا، وبيعرض شاشة مراجعة قبل الحفظ.
        </p>
      </div>

      <div className="rounded-lg border border-border/70 p-3 space-y-1.5 bg-primary-soft/30">
        <label className="flex items-center gap-2 text-sm font-semibold cursor-pointer">
          <input
            type="checkbox"
            checked={autoLearn}
            disabled={autoLearnBusy}
            onChange={(event) => toggleAutoLearn(event.target.checked)}
          />
          تفعيل التعلّم المحافظ من التصحيحات
        </label>
        <p className="text-xs text-muted">
          لما تكون مفعّلة، السيستم بيستفيد من تصحيحاتك اليدوية على صورتين:
        </p>
        <ul className="text-xs text-muted list-disc pr-4 space-y-0.5">
          <li>
            تصنيف غامض أصلًا (زي &quot;غير محدد&quot;): 3 تصحيحات بشرية سابقة على الأقل على صور شكلها قريب جدًا،
            متفقة كلها على نفس النوع الصح — كافية إنه يقترح نفس النوع تلقائيًا.
          </li>
          <li>
            تصنيف كان السيستم واثق فيه لكن غلطان بشكل متكرر: هنا الشرط أعلى بكتير — 6 تصحيحات على الأقل، كلها
            نفس &quot;الغلطة&quot; بالظبط (نفس النوع القديم) واتصححت لنفس النوع الصح، وتشابه أضيق في شكل الصورة.
          </li>
        </ul>
        <p className="text-xs text-muted">
          في الحالتين: أي صورة اتصنفت بالطريقة دي بتاخد علامة &quot;🤖 تعلم تلقائي&quot; في شاشة التمبلت عشان
          تفرق عن تصنيف السيستم العادي أو تصحيح بشري، وأي خلاف بين التصحيحات القريبة بيلغي الاقتراح تمامًا.
        </p>
      </div>

      <label className="block text-sm">
        <span className="text-muted">عدد الأعمدة</span>
        <input
          type="number"
          min={1}
          max={6}
          value={columns}
          onChange={(event) => setColumns(Math.min(6, Math.max(1, Number(event.target.value) || 1)))}
          className="mt-1 w-24 rounded-md border border-border bg-background px-2 py-1.5 text-sm"
        />
      </label>

      <div className="space-y-5">
        {SECTIONS.map((section) => {
          const rows = slots.map((slot, index) => ({ slot, index })).filter(({ slot }) => sectionOf(slot.kind) === section.key);
          if (!rows.length && section.key === "other") return null; // "أخرى" ما تتعرضش لو فاضية أصلاً
          return (
            <div key={section.key} className="rounded-lg border border-border/70 p-2.5 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <h4 className="text-sm font-semibold text-muted">{section.label}</h4>
                <div className="flex gap-1.5">
                  <button
                    type="button"
                    onClick={() => { setAddingSection(section.key); setNewKindLabel(""); setAddKindError(""); }}
                    className="rounded-md border border-border px-2 py-1 text-xs hover:bg-primary-soft"
                  >
                    + نوع جديد
                  </button>
                  <button
                    type="button"
                    onClick={() => addSlot(section.key, section.defaultKind)}
                    className="rounded-md border border-border px-2 py-1 text-xs hover:bg-primary-soft"
                  >
                    + خانة في القسم ده
                  </button>
                </div>
              </div>

              {addingSection === section.key && (
                <div className="flex flex-wrap items-center gap-2 rounded-md border border-dashed border-border p-2 bg-primary-soft/20">
                  <input
                    value={newKindLabel}
                    onChange={(event) => setNewKindLabel(event.target.value)}
                    placeholder={`اسم النوع الجديد (مثال: ${section.key === "xray" ? "Tracing" : "12 O'clock"})`}
                    className="flex-1 min-w-[10rem] rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                  <button
                    type="button"
                    disabled={addKindBusy}
                    onClick={() => addCustomKind(section.key)}
                    className="rounded-md btn-3d-primary px-3 py-1.5 text-xs disabled:opacity-50"
                  >
                    {addKindBusy ? "جارٍ الإضافة…" : "إضافة"}
                  </button>
                  <button
                    type="button"
                    onClick={() => { setAddingSection(null); setAddKindError(""); }}
                    className="rounded-md border border-border px-2 py-1.5 text-xs hover:bg-primary-soft"
                  >
                    إلغاء
                  </button>
                  {addKindError && <p className="w-full text-xs text-danger">{addKindError}</p>}
                  <p className="w-full text-xs text-muted">
                    النوع ده هيفضل اختياري يدوي بس — السيستم مش هيتعرف عليه تلقائيًا وقت رفع الصور، بس هتقدر
                    تحدده يدويًا من هنا أو من شاشة تصحيح نوع الصورة.
                  </p>
                </div>
              )}

              <div className="space-y-2">
                {rows.map(({ slot, index }) => (
                  <div key={slot.key} className="flex flex-wrap items-center gap-2 rounded-md border border-border p-2">
                    <input
                      value={slot.label}
                      onChange={(event) => updateSlot(index, { label: event.target.value })}
                      placeholder="اسم الخانة"
                      className="flex-1 min-w-[10rem] rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                    />
                    <select
                      value={slot.kind}
                      onChange={(event) => updateSlot(index, { kind: event.target.value as TemplateSlotKind })}
                      className="rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                    >
                      {(kindOptionsBySection.get(section.key) ?? []).map((kind) => (
                        <option key={kind} value={kind}>{kindLabel(kind)}</option>
                      ))}
                      {/* لو الخانة متخزّنة بنوع من قسم تاني (تمبلت قديم قبل التعديل)، نضيفه في آخر القايمة عشان مايختفيش من الـselect. */}
                      {!(kindOptionsBySection.get(section.key) ?? []).includes(slot.kind) && (
                        <option value={slot.kind}>{kindLabel(slot.kind)}</option>
                      )}
                    </select>
                    <button type="button" onClick={() => move(index, -1)} className="rounded-md border border-border px-2 py-1 text-sm hover:bg-primary-soft" title="لفوق داخل القسم">▲</button>
                    <button type="button" onClick={() => move(index, 1)} className="rounded-md border border-border px-2 py-1 text-sm hover:bg-primary-soft" title="لتحت داخل القسم">▼</button>
                    <button type="button" onClick={() => setSlots((current) => current.filter((_, position) => position !== index))} className="rounded-md bg-danger-soft px-2 py-1 text-sm text-danger hover:opacity-85">حذف</button>
                  </div>
                ))}
                {!rows.length && <p className="text-xs text-muted">مفيش خانات في القسم ده لسه.</p>}
              </div>
            </div>
          );
        })}
        {!slots.length && <p className="text-sm text-muted">مفيش خانات خالص — ضيف خانة أو ارجع للتمبلت الافتراضي.</p>}
      </div>

      <div className="flex flex-wrap gap-2">
        <button type="button" onClick={() => { setSlots(DEFAULT_TEMPLATE.slots); setColumns(DEFAULT_TEMPLATE.columns); }} className="rounded-md border border-border px-3 py-2 text-sm hover:bg-primary-soft">التمبلت الافتراضي</button>
        <button type="button" disabled={saving} onClick={save} className="rounded-md btn-3d-primary px-4 py-2 text-sm disabled:opacity-50">{saving ? "جارٍ الحفظ…" : "حفظ التمبلت"}</button>
        {message && <span className="self-center text-sm text-muted">{message}</span>}
      </div>
    </div>
  );
}
