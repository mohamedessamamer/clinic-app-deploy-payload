"use client";

import { useState, useTransition } from "react";
import { addServiceAction, updateServiceAction, deleteServiceAction, reactivateServiceAction } from "@/app/settings/actions";

type Service = {
  id: number;
  name: string;
  name_en: string | null;
  category: string | null;
  default_price: number;
  code: string | null;
  price_note: string | null;
  prepaid: number;
  has_lab_cost: number;
  lab_cost: number;
  active: number;
};

const CATEGORY_LABELS: Record<string, string> = {
  General: "عام",
  Filling: "حشوات",
  Endodontics: "علاج عصب",
  Implant: "زراعة",
  Prosthodontics: "تركيبات",
  Surgery: "جراحة",
  Periodontics: "لثة",
  Laser: "ليزر",
  Pedodontics: "أسنان أطفال",
  Orthodontics: "تقويم",
};

function categoryLabel(cat: string | null): string {
  if (!cat) return "بدون تصنيف";
  return CATEGORY_LABELS[cat] || cat;
}

export default function ServicesManager({ services }: { services: Service[] }) {
  const [selectedId, setSelectedId] = useState<number | "">("");
  const [isPending, startTransition] = useTransition();
  // نتيجة آخر عملية حذف/تعطيل — الأكشن بيرجّع نتيجة بدل ما يعمل redirect عشان
  // نقدر نفرّق للمستخدم بين "اتحذفت خلاص" و"اتعطّلت لأن ليها تاريخ".
  const [notice, setNotice] = useState<{ tone: "ok" | "warn" | "error"; text: string } | null>(null);
  const selected = services.find((s) => s.id === selectedId);

  const grouped = services.reduce<Record<string, Service[]>>((acc, s) => {
    const key = s.category || "__none__";
    (acc[key] ||= []).push(s);
    return acc;
  }, {});

  return (
    <div className="space-y-5">
      <datalist id="service-categories">
        {Object.entries(CATEGORY_LABELS).map(([cat, label]) => (
          <option key={cat} value={cat}>
            {label}
          </option>
        ))}
      </datalist>

      <div>
        <label className="block text-sm text-muted mb-1">اختر خدمة لعرض/تعديل بياناتها</label>
        <select
          value={selectedId}
          onChange={(e) => setSelectedId(e.target.value ? Number(e.target.value) : "")}
          className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
        >
          <option value="">-- اختر خدمة --</option>
          {Object.entries(grouped).map(([cat, list]) => (
            <optgroup key={cat} label={categoryLabel(cat === "__none__" ? null : cat)}>
              {list.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.code ? `[${s.code}] ` : ""}
                  {s.name}
                  {s.name_en ? ` — ${s.name_en}` : ""} ({s.default_price} ج){s.active === 0 ? " — متوقفة" : ""}
                </option>
              ))}
            </optgroup>
          ))}
        </select>
        {services.length === 0 && <p className="text-sm text-muted mt-2">مفيش خدمات مسجلة لسه.</p>}
      </div>

      {selected && (
        <form
          key={selected.id}
          onSubmit={(e) => {
            e.preventDefault();
            const form = e.currentTarget;
            const formData = new FormData(form);
            const newPrice = Number(formData.get("default_price"));
            if (newPrice !== selected.default_price) {
              const ok = window.confirm(
                `هتغيّر سعر "${selected.name}" من ${selected.default_price} إلى ${newPrice}. متأكد؟`
              );
              if (!ok) return;
            }
            startTransition(() => {
              updateServiceAction(formData);
            });
          }}
          className="border border-border rounded-lg p-4 space-y-3"
        >
          <input type="hidden" name="id" value={selected.id} />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-muted mb-1">اسم الخدمة (عربي)</label>
              <input
                name="name"
                defaultValue={selected.name}
                required
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-muted mb-1">اسم الخدمة (إنجليزي)</label>
              <input
                name="name_en"
                defaultValue={selected.name_en || ""}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-muted mb-1">التصنيف</label>
              <input
                name="category"
                defaultValue={selected.category || ""}
                list="service-categories"
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-muted mb-1">الكود</label>
              <input
                name="code"
                defaultValue={selected.code || ""}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-muted mb-1">السعر</label>
              <input
                name="default_price"
                type="number"
                step="0.01"
                defaultValue={selected.default_price}
                required
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-muted mb-1">ملاحظة على السعر (اختياري)</label>
              <input
                name="price_note"
                defaultValue={selected.price_note || ""}
                placeholder="مثلاً: يبدأ من ... حسب الحالة"
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              />
            </div>
          </div>
          <label className="flex items-center gap-2 text-xs text-muted">
            <input name="prepaid" type="checkbox" defaultChecked={selected.prepaid === 1} className="h-4 w-4" />
            تُدفع مقدمًا
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 rounded-lg border border-border bg-primary-soft/20 p-3">
            <label className="flex items-center gap-2 text-sm font-medium">
              <input name="has_lab_cost" type="checkbox" defaultChecked={selected.has_lab_cost === 1} className="h-4 w-4" />
              الخدمة لها تكلفة معمل
            </label>
            <label>
              <span className="block text-xs text-muted mb-1">تكلفة المعمل الافتراضية</span>
              <input name="lab_cost" type="number" min="0" step="0.01" defaultValue={selected.lab_cost || 0} className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
            </label>
            <p className="sm:col-span-2 text-xs text-muted">تُخصم تكلفة المعمل بنسبة ما تم تحصيله فعليًا من المريض قبل حساب نسبة الطبيب.</p>
          </div>
          <div className="flex flex-wrap items-center gap-3 border-t border-border pt-3">
            <button
              type="submit"
              disabled={isPending}
              className="rounded-md btn-3d-primary px-4 py-2 text-sm font-medium disabled:opacity-60"
            >
              حفظ التعديلات
            </button>

            {selected.active === 1 ? (
              <button
                type="button"
                disabled={isPending}
                onClick={() => {
                  // الرسالة مش بتوعد بحذف نهائي: السيرفر هو اللي بيقرر حسب
                  // الاستخدام الفعلي، والمستخدم لازم يعرف ده قبل ما يوافق.
                  if (!window.confirm(`هتحذف خدمة "${selected.name}". لو ليها زيارات أو فواتير مسجّلة هتتعطّل بدل ما تتحذف عشان السجلات القديمة ماتبوظش. تكمّل؟`)) return;
                  setNotice(null);
                  startTransition(async () => {
                    const fd = new FormData();
                    fd.set("id", String(selected.id));
                    const result = await deleteServiceAction(fd);
                    if (!result.ok) {
                      setNotice({ tone: "error", text: result.error ?? "حصلت مشكلة في الحذف." });
                      return;
                    }
                    if (result.deactivated) {
                      setNotice({ tone: "warn", text: `"${selected.name}" اتعطّلت بدل ما تتحذف — عندها ${result.usage} سجل مرتبط. اختفت من قوايم الاختيار والسجلات القديمة زي ما هي.` });
                    } else {
                      setNotice({ tone: "ok", text: `"${selected.name}" اتحذفت نهائيًا — مكانش عليها أي استخدام.` });
                      setSelectedId("");
                    }
                  });
                }}
                className="rounded-md border border-danger px-4 py-2 text-sm font-medium text-danger disabled:opacity-60"
              >
                حذف الخدمة
              </button>
            ) : (
              <button
                type="button"
                disabled={isPending}
                onClick={() => {
                  setNotice(null);
                  startTransition(async () => {
                    const fd = new FormData();
                    fd.set("id", String(selected.id));
                    const result = await reactivateServiceAction(fd);
                    setNotice(result.ok ? { tone: "ok", text: `"${selected.name}" رجعت للعمل.` } : { tone: "error", text: result.error ?? "حصلت مشكلة." });
                  });
                }}
                className="rounded-md border border-primary px-4 py-2 text-sm font-medium text-primary disabled:opacity-60"
              >
                إرجاع الخدمة للعمل
              </button>
            )}

            {selected.active === 0 && (
              <span className="text-xs text-warning">الخدمة دي متوقفة — مش بتظهر في قوايم الاختيار.</span>
            )}
          </div>
        </form>
      )}

      {notice && (
        <p
          className={`rounded-md border px-3 py-2 text-sm ${
            notice.tone === "error"
              ? "border-danger bg-danger-soft text-danger"
              : notice.tone === "warn"
                ? "border-warning bg-warning-soft text-warning"
                : "border-primary bg-primary-soft/40 text-foreground"
          }`}
        >
          {notice.text}
        </p>
      )}

      <details className="border border-border rounded-lg p-4">
        <summary className="font-medium text-sm cursor-pointer select-none">+ إضافة خدمة جديدة</summary>
        <form action={addServiceAction} className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
          <div>
            <label className="block text-xs text-muted mb-1">اسم الخدمة (عربي)</label>
            <input name="name" required className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">اسم الخدمة (إنجليزي)</label>
            <input name="name_en" className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">التصنيف</label>
            <input name="category" list="service-categories" className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">الكود</label>
            <input name="code" className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">السعر</label>
            <input
              name="default_price"
              type="number"
              step="0.01"
              defaultValue={0}
              required
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
            />
          </div>
          <div className="flex items-center gap-2 pb-2">
            <input id="prepaid-new" name="prepaid" type="checkbox" className="h-4 w-4" />
            <label htmlFor="prepaid-new" className="text-xs text-muted">
              تُدفع مقدمًا
            </label>
          </div>
          <div className="rounded-lg border border-border p-3 sm:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <label className="flex items-center gap-2 text-sm"><input name="has_lab_cost" type="checkbox" className="h-4 w-4" /> الخدمة لها تكلفة معمل</label>
            <label><span className="block text-xs text-muted mb-1">تكلفة المعمل الافتراضية</span><input name="lab_cost" type="number" min="0" step="0.01" defaultValue={0} className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" /></label>
          </div>
          <div className="sm:col-span-2">
            <button
              type="submit"
              className="rounded-md btn-3d-primary px-4 py-2 text-sm font-medium"
            >
              + إضافة خدمة
            </button>
          </div>
        </form>
      </details>
    </div>
  );
}
