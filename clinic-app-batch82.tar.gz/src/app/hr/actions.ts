"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getClinicToday } from "@/lib/clinic-date";

function value(formData: FormData, key: string) { return String(formData.get(key) ?? "").trim(); }
function amount(formData: FormData, key: string) {
  const number = Number(formData.get(key));
  return Number.isFinite(number) && number >= 0 ? Math.round(number * 100) / 100 : null;
}
function validDate(date: string) { return /^\d{4}-\d{2}-\d{2}$/.test(date); }

async function canManageHr() {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "manage_hr"))) return null;
  return session;
}

function refresh() { revalidatePath("/hr"); revalidatePath("/expenses"); }

export async function saveHrCompensationRuleAction(formData: FormData) {
  const session = await canManageHr();
  if (!session) return;
  const personType = value(formData, "person_type");
  const personId = Number(formData.get("person_id"));
  const staffGroup = personType === "doctor" ? "doctor" : value(formData, "staff_group");
  const compensationType = value(formData, "compensation_type");
  const fixedBasis = value(formData, "fixed_basis");
  const fixedAmount = amount(formData, "fixed_amount");
  const percentageBasis = value(formData, "percentage_basis");
  let percentageMode = value(formData, "percentage_mode");
  const percentage = amount(formData, "percentage");
  const effectiveFrom = value(formData, "effective_from");
  const effectiveTo = value(formData, "effective_to") || null;
  if (!Number.isInteger(personId) || personId <= 0 || !["doctor", "user"].includes(personType)) return;
  if (!["doctor", "employee", "nursing"].includes(staffGroup) || !["fixed", "percentage", "mixed"].includes(compensationType)) return;
  if (!["monthly", "shift"].includes(fixedBasis) || !["personal", "clinic"].includes(percentageBasis) || !["fixed", "progressive"].includes(percentageMode)) return;
  if (fixedAmount == null || percentage == null || percentage > 100 || !validDate(effectiveFrom) || (effectiveTo && !validDate(effectiveTo))) return;
  if (effectiveTo && effectiveTo < effectiveFrom) return;
  if (personType !== "doctor" && percentageBasis === "personal") return;
  if (personType !== "doctor" && percentageMode === "progressive") percentageMode = "fixed";
  if (compensationType === "fixed" && fixedAmount <= 0) return;
  if (compensationType !== "fixed" && percentageMode === "fixed" && percentage <= 0) return;
  if (compensationType === "mixed" && fixedAmount <= 0) return;
  const exists = personType === "doctor"
    ? await db.selectFrom("doctors").select("id").where("id", "=", personId).where("active", "=", 1).executeTakeFirst()
    : await db.selectFrom("users").select("id").where("id", "=", personId).where("active", "=", 1).executeTakeFirst();
  if (!exists) return;
  await db.insertInto("hr_compensation_rules").values({
    person_type: personType as "doctor" | "user", person_id: personId,
    staff_group: staffGroup as "doctor" | "employee" | "nursing",
    compensation_type: compensationType as "fixed" | "percentage" | "mixed",
    fixed_basis: fixedBasis as "monthly" | "shift", fixed_amount: compensationType === "percentage" ? 0 : fixedAmount,
    percentage_basis: percentageBasis as "personal" | "clinic", percentage_mode: percentageMode as "fixed" | "progressive",
    percentage: compensationType === "fixed" || percentageMode === "progressive" ? 0 : percentage,
    effective_from: effectiveFrom, effective_to: effectiveTo, active: 1, created_by: session.userId,
  }).onConflict((oc) => oc.columns(["person_type", "person_id"]).doUpdateSet({
    staff_group: staffGroup as "doctor" | "employee" | "nursing",
    compensation_type: compensationType as "fixed" | "percentage" | "mixed",
    fixed_basis: fixedBasis as "monthly" | "shift", fixed_amount: compensationType === "percentage" ? 0 : fixedAmount,
    percentage_basis: percentageBasis as "personal" | "clinic", percentage_mode: percentageMode as "fixed" | "progressive",
    percentage: compensationType === "fixed" || percentageMode === "progressive" ? 0 : percentage,
    effective_from: effectiveFrom, effective_to: effectiveTo, active: 1, created_by: session.userId, updated_at: new Date().toISOString(),
  })).execute();
  refresh();
}

export async function stopHrCompensationRuleAction(formData: FormData) {
  const session = await canManageHr();
  if (!session) return;
  const id = Number(formData.get("rule_id"));
  if (!Number.isInteger(id) || id <= 0) return;
  await db.updateTable("hr_compensation_rules").set({ active: 0, effective_to: getClinicToday(), updated_at: new Date().toISOString() }).where("id", "=", id).execute();
  refresh();
}
