import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getClinicToday } from "@/lib/clinic-date";
import HrRulesManager from "@/components/HrRulesManager";

export default async function HrPage() {
  const session = await getSession();
  const allowed = session ? await hasPermission(session.userId, session.role, "manage_hr") : false;
  if (!allowed) return <div className="card-3d rounded-xl p-5 text-sm text-muted">مفيش صلاحية عندك لإدارة HR.</div>;
  const [doctors, users, rules] = await Promise.all([
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).orderBy("full_name").execute(),
    db.selectFrom("users").select(["id", "full_name", "role"]).where("active", "=", 1).where("doctor_id", "is", null).where("role", "!=", "admin").orderBy("full_name").execute(),
    db.selectFrom("hr_compensation_rules").selectAll().execute(),
  ]);
  const ruleMap = new Map(rules.map((rule) => [`${rule.person_type}-${rule.person_id}`, rule]));
  const people = [
    ...doctors.map((doctor) => ({ personType: "doctor" as const, id: doctor.id, name: doctor.full_name, defaultGroup: "doctor" as const, rule: ruleMap.get(`doctor-${doctor.id}`) ?? null })),
    ...users.map((user) => ({ personType: "user" as const, id: user.id, name: user.full_name, defaultGroup: "employee" as const, rule: ruleMap.get(`user-${user.id}`) ?? null })),
  ];
  return <div className="space-y-6"><div><h1 className="text-2xl font-bold">HR وقواعد الرواتب</h1><p className="mt-1 text-sm text-muted">عرّف طريقة حساب كل شخص مرة واحدة. الحساب الفعلي وعدد الشيفتات والصرف يظهرون داخل المصروفات.</p></div><div className="rounded-xl border border-primary/20 bg-primary-soft/30 p-4 text-sm leading-7"><b>قاعدة نسبة الطبيب:</b> النسبة تُحسب على ما دفعه المرضى فعليًا بعد خصم تكلفة المعمل. الدفع الجزئي يخصم الجزء المقابل فقط من تكلفة المعمل.</div><HrRulesManager people={people} today={getClinicToday()} /></div>;
}
