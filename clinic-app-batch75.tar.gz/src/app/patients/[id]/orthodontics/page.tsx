import { notFound } from "next/navigation";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { displayAge } from "@/lib/age";
import { hasPermission } from "@/lib/permissions";
import type { Role } from "@/lib/auth";
import { formatPatientPhone } from "@/lib/phone";
import { getTodayPurposeContext } from "@/lib/purpose-context";
import { getClinicToday } from "@/lib/clinic-date";
import OrthoChartV2 from "@/components/ortho/OrthoChartV2";
import type { OrthoStockItem } from "@/components/ortho/FollowUpsTable";
import type { ToothState } from "@/components/ortho/InteractiveToothChart";
import { ALL_TEETH } from "@/lib/ortho/fdi-teeth";
import { computeConsultantReminderMap, CONSULTANT_REMINDER_MONTHS } from "@/lib/consultant-reminder";

// شارت تقويم v2 — دمج البروتوتايب المعزول مع السيستم الحقيقي (2026-08-27).
// نفس صلاحية التعديل القديمة بالظبط (دكتور + أدمن + مدير عيادة).
function canEditMedicalRecordFor(role: string | undefined): boolean {
  return role === "doctor" || role === "admin" || role === "clinic_manager";
}

// تنبيه "محتاج صور جديدة" — نفس فكرة الملف الطبي العادي (شوف
// src/app/patients/[id]/page.tsx و src/lib/photo-reminder.ts، الاتنين فيهم
// نفس الثابت PHOTO_REMINDER_MONTHS ولازم يتغيروا مع بعض لو الرقم اتغيّر)،
// لكن معيار "بيعمل متابعة" هنا هو وجود زيارة متابعة في شارت التقويم نفسه
// (ortho_visits)، مش خدمة كودها "0" في جدول visits العام — التقويم بيتسجل
// في جدول منفصل تمامًا، فمعيار الملف الطبي العادي مايتطبقش عليه حرفيًا.
const PHOTO_REMINDER_MONTHS = 6;

function parseJsonObject<T>(raw: string | null, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export default async function OrthodonticChartPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const patientId = Number(id);
  if (!patientId) notFound();

  const patient = await db.selectFrom("patients").selectAll().where("id", "=", patientId).executeTakeFirst();
  if (!patient) notFound();

  const session = await getSession();
  const editable = canEditMedicalRecordFor(session?.role);
  const canViewPersonalData = session
    ? await hasPermission(session.userId, session.role as Role, "view_patient_personal_data")
    : false;

  const [chartRow, doctors, orthoStockRows, visitRows, deductionRows, bracketMovementRows, eventRows, imageGroups, canEditAfterSave, canUndoInventory, canUploadPhotos, canDeleteVisit] = await Promise.all([
    db.selectFrom("orthodontic_charts").selectAll().where("patient_id", "=", patientId).executeTakeFirst(),
    db.selectFrom("doctors").select(["id", "full_name", "is_consultant"]).where("active", "=", 1).orderBy("full_name").execute(),
    db
      .selectFrom("inventory_items")
      .select(["id", "name", "quantity", "unit", "ortho_usage"])
      .where("ortho_usage", "is not", null)
      .where("active", "=", 1)
      .where("available_in_clinical_selection", "=", 1)
      .orderBy("name")
      .execute(),
    db
      .selectFrom("ortho_visits")
      .selectAll()
      .where("patient_id", "=", patientId)
      .orderBy("id", "desc")
      .execute(),
    db
      .selectFrom("ortho_inventory_deductions")
      .selectAll()
      .where("patient_id", "=", patientId)
      .orderBy("deduction_date", "desc")
      .orderBy("id", "desc")
      .execute(),
    db
      .selectFrom("orthodontic_bracket_stock_movements")
      .select(["visit_id", "quantity", "movement_date", "created_at"])
      .where("patient_id", "=", patientId)
      .where("movement_type", "in", ["ortho_use", "return"])
      .execute(),
    db
      .selectFrom("audit_log")
      .selectAll()
      .where("entity_type", "=", "orthodontic_chart")
      .where("entity_id", "=", patientId)
      .orderBy("id", "desc")
      .execute(),
    db
      .selectFrom("patient_image_groups")
      .selectAll()
      .where("patient_id", "=", patientId)
      .orderBy("taken_at", "desc")
      .execute(),
    session ? hasPermission(session.userId, session.role as Role, "edit_ortho_visit_after_save") : Promise.resolve(false),
    session ? hasPermission(session.userId, session.role as Role, "undo_ortho_inventory_deduction") : Promise.resolve(false),
    session ? hasPermission(session.userId, session.role as Role, "upload_ortho_photos") : Promise.resolve(false),
    // نفس صلاحية حذف زيارات الملف الطبي العادي — تأكيد المستخدم إنها تتطبق
    // على شارت التقويم كمان بدل ما تتعمل صلاحية جديدة مخصوصة.
    session ? hasPermission(session.userId, session.role as Role, "delete_visits") : Promise.resolve(false),
  ]);

  const imageGroupsWithFiles = await Promise.all(
    imageGroups.map(async (g) => ({
      ...g,
      images: await db.selectFrom("patient_images").selectAll().where("group_id", "=", g.id).execute(),
    }))
  );

  const toothStates = parseJsonObject<Record<number, ToothState>>(chartRow?.tooth_states ?? null, {});
  // الـO-tie يخصم للبراكتس فقط: Position 1–5. الـTube على الضرس (6+) لا
  // يدخل في العدد، والسن الذي حصل له Debonding حالته لم تعد bonded.
  const activeBracketCount = ALL_TEETH.filter((tooth) => tooth.position < 6 && toothStates[tooth.fdi]?.bracket === "bonded").length;
  const stripCounts = parseJsonObject<Record<string, number>>(chartRow?.strip_counts ?? null, {});
  const miniscrews = parseJsonObject<Record<string, boolean>>(chartRow?.miniscrews ?? null, {});
  const extractionQuadrants = parseJsonObject<{ ur: string; ul: string; lr: string; ll: string } | null>(chartRow?.extraction_quadrants ?? null, null);

  const bracketCountByVisit = new Map<number, number>();
  const unlinkedBracketCountByDate = new Map<string, number>();
  for (const movement of bracketMovementRows) {
    const count = -movement.quantity;
    if (movement.visit_id) bracketCountByVisit.set(movement.visit_id, (bracketCountByVisit.get(movement.visit_id) ?? 0) + count);
    else {
      const movementDate = movement.movement_date ?? movement.created_at.slice(0, 10);
      unlinkedBracketCountByDate.set(movementDate, (unlinkedBracketCountByDate.get(movementDate) ?? 0) + count);
    }
  }

  const visits = visitRows.map((v) => ({
    id: v.id,
    date: v.visit_date,
    service: v.service ?? "",
    upperSize: v.upper_wire_size ?? "",
    upperType: v.upper_wire_type ?? "",
    lowerSize: v.lower_wire_size ?? "",
    lowerType: v.lower_wire_type ?? "",
    note: v.note ?? "",
    elasticsDispensed: v.elastics_dispensed === 1,
    elasticsSize: v.elastics_size ?? "",
    otieColor: v.otie_color ?? "",
    powerChainQty: v.power_chain_qty != null ? String(v.power_chain_qty) : "",
    buttonsQty: v.buttons_qty != null ? String(v.buttons_qty) : "",
    compressedCoilMm: v.compressed_coil_mm != null ? String(v.compressed_coil_mm) : "",
    upperWireItemId: v.upper_wire_item_id,
    lowerWireItemId: v.lower_wire_item_id,
    elasticItemId: v.elastic_item_id,
    otieItemId: v.otie_item_id,
    powerChainItemId: v.power_chain_item_id,
    buttonsItemId: v.buttons_item_id,
    compressedCoilItemId: v.compressed_coil_item_id,
    bondingBracketItemId: v.bonding_bracket_item_id,
    bondingBracketBrand: v.bonding_bracket_brand,
    bondingTubeItemId: v.bonding_tube_item_id,
    doctorId: v.doctor_id,
    seenByConsultant: v.seen_by_consultant === 1,
    consultantDoctorId: v.consultant_doctor_id,
    bracketCount: Math.max(0, (bracketCountByVisit.get(v.id) ?? 0) + (unlinkedBracketCountByDate.get(v.visit_date) ?? 0)),
    bondingApplied: v.bonding_applied === 1,
  }));

  const inventoryLog = deductionRows.map((d) => ({
    id: d.id,
    label: d.label,
    qty: d.qty,
    teeth: d.teeth ? (JSON.parse(d.teeth) as number[]) : null,
    date: d.deduction_date,
    undoneAt: d.undone_at,
  }));
  const orthoStockItems: OrthoStockItem[] = orthoStockRows
    .filter((item): item is typeof item & { ortho_usage: OrthoStockItem["usage"] } => item.ortho_usage != null)
    .filter((item) => ["wire", "bracket", "tube", "elastic", "otie", "power_chain", "button", "compressed_coil"].includes(item.ortho_usage))
    .map((item) => ({ id: item.id, name: item.name, quantity: item.quantity, unit: item.unit, usage: item.ortho_usage }));

  const chartEvents = eventRows.map((e) => ({
    id: e.id,
    date: e.event_date || e.changed_at.slice(0, 10),
    text: e.reason || "",
  }));

  // تقييد قائمة "الدكتور" في صفوف المتابعة — دفعة 27، قرار نهائي بعد نقاش
  // مطوّل مع المستخدم: الأساس هو الدكتور المتحدد على موعد المريض النهاردة
  // (مش تخزين ثابت على الشارت) — implicit lookup بالتاريخ، من غير أي عمود
  // جديد على ortho_visits. لو الدكتور ده استشاري، القائمة تتقيد بيه + مساعديه
  // (consultant_assistants). لو مش استشاري، تتقفل عليه بس. لو مفيش موعد
  // للمريض النهاردة أصلاً، القائمة تفضل زي ما هي (كل الأطباء النشطين) —
  // Fallback مؤكد من المستخدم صراحة، عشان الشارت يفضل قابل للاستخدام حتى من
  // غير موعد مرتبط (زيارة قديمة بترجع تتعدل مثلًا).
  const today = getClinicToday();
  const todaysAppointment = await db
    .selectFrom("appointments")
    .select(["doctor_id"])
    .where("patient_id", "=", patientId)
    .where("appointment_date", "=", today)
    .where("status", "!=", "cancelled")
    .orderBy("start_time", "asc")
    .executeTakeFirst();

  let scopedDoctors = doctors;
  // لا نضع طبيبًا افتراضيًا على الإطلاق. اختيار مقدم الخدمة مطلوب صراحة في
  // بطاقة Visit Details قبل الحفظ، حتى لو كان المستخدم طبيبًا مسجّل الدخول.
  let scopedDefaultDoctorId: number | null = null;
  if (todaysAppointment) {
    const apptDoctor = await db
      .selectFrom("doctors")
      .select(["id", "full_name", "is_consultant"])
      .where("id", "=", todaysAppointment.doctor_id)
      .executeTakeFirst();
    if (apptDoctor) {
      if (apptDoctor.is_consultant === 1) {
        const assistants = await db
          .selectFrom("consultant_assistants")
          .innerJoin("doctors", "doctors.id", "consultant_assistants.assistant_doctor_id")
          .select(["doctors.id", "doctors.full_name", "doctors.is_consultant"])
          .where("consultant_assistants.consultant_doctor_id", "=", apptDoctor.id)
          .where("doctors.active", "=", 1)
          .execute();
        scopedDoctors = [{ id: apptDoctor.id, full_name: apptDoctor.full_name, is_consultant: apptDoctor.is_consultant }, ...assistants];
      } else {
        scopedDoctors = [{ id: apptDoctor.id, full_name: apptDoctor.full_name, is_consultant: apptDoctor.is_consultant }];
      }
    }
  }
  // تنبيه "محتاج صور جديدة" (شوف الكومنت فوق) — imageGroups أصلاً مرتبة desc
  // بالـtaken_at، فأول عنصر هو آخر صورة اتسجلت.
  const hasOrthoFollowup = visitRows.length > 0;
  const lastPhotoTakenAt = imageGroups[0]?.taken_at ?? null;
  const photoReminderCutoff = new Date();
  photoReminderCutoff.setMonth(photoReminderCutoff.getMonth() - PHOTO_REMINDER_MONTHS);
  const photoReminderCutoffStr = photoReminderCutoff.toISOString().slice(0, 10);
  const needsNewPhotos = hasOrthoFollowup && (!lastPhotoTakenAt || lastPhotoTakenAt < photoReminderCutoffStr);
  const consultantReminder = (await computeConsultantReminderMap([patientId])).get(patientId);

  // دفعة 27 (P3.2): سياق "متابعة: <اسم الخدمة>" — بس لمين يقدر يعدّل الشارت أصلاً.
  const purposeContext = editable ? await getTodayPurposeContext(patientId, today) : null;

  return (
    <OrthoChartV2
        patientId={patientId}
        patientName={patient.full_name}
        fileNumber={patient.file_number}
        // السن معلومة علاجية لازمة داخل الشارت، أما الهاتف فيبقى ضمن البيانات
        // الشخصية ولا يظهر إلا لمن مُنح صلاحية عرضها.
        patientAge={displayAge(patient)}
        patientPhone={canViewPersonalData ? formatPatientPhone(patient.phone_country_code, patient.phone) : null}
        editable={editable}
        canEditAfterSave={canEditAfterSave}
        canUndoInventory={canUndoInventory}
        defaultDoctorId={scopedDefaultDoctorId}
        doctors={scopedDoctors.map((doctor) => ({ id: doctor.id, full_name: doctor.full_name, isConsultant: doctor.is_consultant === 1 }))}
        stockItems={orthoStockItems}
        activeBracketCount={activeBracketCount}
        unlinkedBracketCountToday={Math.max(0, unlinkedBracketCountByDate.get(today) ?? 0)}
        options={{
          wireSizes: [],
          wireTypes: [],
          otieColors: [],
          elasticSizes: [],
          anchorageDevices: orthoStockRows.filter((item) => item.ortho_usage === "anchorage_device").map((item) => item.name),
        }}
        chart={{
          bracket_type: chartRow?.bracket_type ?? null,
          prescription: chartRow?.prescription ?? null,
          slot: chartRow?.slot ?? null,
          chief_complaint: chartRow?.chief_complaint ?? null,
          extraction_quadrants: extractionQuadrants,
          anchorage_device: chartRow?.anchorage_device ?? null,
          treatment_note: chartRow?.treatment_note ?? null,
        }}
        toothStates={toothStates}
        stripCounts={stripCounts}
        miniscrews={miniscrews}
        diagnostic={{
          antero_posterior: chartRow?.antero_posterior ?? null,
          facial_height: chartRow?.facial_height ?? null,
          mx_incisor_inclination: chartRow?.mx_incisor_inclination ?? null,
          mn_incisor_inclination: chartRow?.mn_incisor_inclination ?? null,
          molar_relation_right: chartRow?.molar_relation_right ?? null,
          molar_relation_left: chartRow?.molar_relation_left ?? null,
          overbite: chartRow?.overbite ?? null,
          overjet: chartRow?.overjet ?? null,
          midline_upper_direction: chartRow?.midline_upper_direction ?? null,
          midline_upper_mm: chartRow?.midline_upper_mm ?? null,
          midline_lower_direction: chartRow?.midline_lower_direction ?? null,
          midline_lower_mm: chartRow?.midline_lower_mm ?? null,
          space_upper_type: chartRow?.space_upper_type ?? null,
          space_upper_mm: chartRow?.space_upper_mm ?? null,
          space_lower_type: chartRow?.space_lower_type ?? null,
          space_lower_mm: chartRow?.space_lower_mm ?? null,
          nasolabial_angle: chartRow?.nasolabial_angle ?? null,
          lips: chartRow?.lips ?? null,
        }}
        visits={visits}
        inventoryLog={inventoryLog}
        chartEvents={chartEvents}
        imageGroups={imageGroupsWithFiles}
        needsNewPhotos={needsNewPhotos}
        needsConsultantVisit={consultantReminder?.needsConsultantVisit ?? false}
        consultantName={consultantReminder?.consultantName ?? null}
        consultantReminderMonths={CONSULTANT_REMINDER_MONTHS}
        lastPhotoTakenAt={lastPhotoTakenAt}
        photoReminderMonths={PHOTO_REMINDER_MONTHS}
        canUploadPhotos={canUploadPhotos}
        canDeleteVisit={canDeleteVisit}
        purposeContext={purposeContext}
        upperBulkBondingDate={chartRow?.bonding_upper_date ?? null}
        lowerBulkBondingDate={chartRow?.bonding_lower_date ?? null}
      />
  );
}
