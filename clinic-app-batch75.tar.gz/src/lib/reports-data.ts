import "server-only";
import { db } from "./db/client";
import { hasPermission } from "./permissions";
import type { SessionPayload } from "./auth";
import { getClinicToday } from "./clinic-date";

// منطق جلب/تجميع بيانات تقرير الإيرادات — منقول من src/app/reports/page.tsx
// لملف مشترك عشان يُستخدم من مكانين: صفحة العرض نفسها، وتصدير Excel
// (src/app/reports/export/route.ts) — من غير ما نكرر نفس منطق الفلترة/التجميع
// (خصوصًا إسناد دفعات المتابعة لدكتور/خدمة الفاتورة الأصلية) في مكانين ممكن
// يتفرقوا عن بعض بمرور الوقت.

export type ReportsSearchParams = { from?: string; to?: string; doctor_id?: string; service_id?: string; applied?: string };

export type ReportRow = { key: string | number; label: string; amount: number; paid: number; visits: number };
export type ReportDayRow = { date: string; amount: number; paid: number; visits: number };

export type ReportsDataResult =
  | { ok: false; reason: "no_session" | "no_permission" | "no_doctor_linked" }
  | {
      ok: true;
      reportsFull: boolean;
      from: string;
      to: string;
      dateRangeClamped: boolean;
      reportsOwnMinFrom: string | null;
      doctorId: number | null;
      serviceId: number | null;
      doctors: { id: number; full_name: string }[];
      services: { id: number; name: string; code: string | null }[];
      newAmount: number;
      collected: number;
      visitCount: number;
      byMethod: [string, number][];
      byDoctor: ReportRow[];
      byService: ReportRow[];
      byDay: ReportDayRow[];
    };

function isValidDate(s: string | undefined): s is string {
  return !!s && /^\d{4}-\d{2}-\d{2}$/.test(s);
}

function firstDayOfMonth(d: Date) {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1)).toISOString().slice(0, 10);
}

function round2(n: number) {
  return Math.round(n * 100) / 100;
}

const REPORTS_OWN_MAX_MONTHS = 2;

export async function getReportsData(session: SessionPayload | null, sp: ReportsSearchParams): Promise<ReportsDataResult> {
  if (!session) return { ok: false, reason: "no_session" };

  const [reportsFull, reportsOwn] = await Promise.all([
    hasPermission(session.userId, session.role, "reports_full"),
    hasPermission(session.userId, session.role, "reports_own"),
  ]);

  if (!reportsFull && !reportsOwn) return { ok: false, reason: "no_permission" };
  if (!reportsFull && !session.doctorId) return { ok: false, reason: "no_doctor_linked" };

  const today = getClinicToday();
  let from = isValidDate(sp.from) ? sp.from : firstDayOfMonth(new Date());
  const to = isValidDate(sp.to) ? sp.to : today;

  // reports_own (من غير reports_full، عادة دكتور): الفترة مقفولة بحد أقصى شهرين.
  let dateRangeClamped = false;
  let reportsOwnMinFrom: string | null = null;
  if (!reportsFull) {
    const toDate = new Date(`${to}T00:00:00Z`);
    toDate.setUTCMonth(toDate.getUTCMonth() - REPORTS_OWN_MAX_MONTHS);
    const minFrom = toDate.toISOString().slice(0, 10);
    reportsOwnMinFrom = minFrom;
    if (from < minFrom) {
      from = minFrom;
      dateRangeClamped = true;
    }
  }

  const requestedDoctorId = sp.doctor_id ? Number(sp.doctor_id) : null;
  const doctorId = reportsFull ? requestedDoctorId : session.doctorId!;
  const serviceId = sp.service_id ? Number(sp.service_id) : null;

  const [doctors, allServices] = await Promise.all([
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).execute(),
    db.selectFrom("services").select(["id", "name", "code"]).execute(),
  ]);
  const services = allServices.filter((s) => s.code !== "0");

  let rootQuery = db
    .selectFrom("invoices")
    .leftJoin("doctors", "doctors.id", "invoices.doctor_id")
    .leftJoin("services", "services.id", "invoices.service_id")
    .select([
      "invoices.id",
      "invoices.amount",
      "invoices.paid",
      "invoices.payment_method",
      "invoices.invoice_date as visit_date",
      "invoices.doctor_id",
      "doctors.full_name as doctor_name",
      "invoices.service_id",
      "services.name as service_name",
    ])
    .where("invoices.parent_invoice_id", "is", null)
    .where("invoices.invoice_date", ">=", from)
    .where("invoices.invoice_date", "<=", to);
  if (doctorId) rootQuery = rootQuery.where("invoices.doctor_id", "=", doctorId);
  if (serviceId) rootQuery = rootQuery.where("invoices.service_id", "=", serviceId);
  const rootInvoices = await rootQuery.execute();

  const followupRaw = await db
    .selectFrom("invoices")
    .select(["invoices.id", "invoices.paid", "invoices.payment_method", "invoices.parent_invoice_id", "invoices.invoice_date as visit_date"])
    .where("invoices.parent_invoice_id", "is not", null)
    .where("invoices.invoice_date", ">=", from)
    .where("invoices.invoice_date", "<=", to)
    .execute();

  const parentIds = [...new Set(followupRaw.map((f) => f.parent_invoice_id).filter((id): id is number => id != null))];
  const parentInfoById = new Map<number, { doctor_id: number | null; doctor_name: string | null; service_id: number | null; service_name: string | null }>();
  if (parentIds.length > 0) {
    const parents = await db
      .selectFrom("invoices")
      .leftJoin("doctors", "doctors.id", "invoices.doctor_id")
      .leftJoin("services", "services.id", "invoices.service_id")
      .select(["invoices.id", "invoices.doctor_id", "doctors.full_name as doctor_name", "invoices.service_id", "services.name as service_name"])
      .where("invoices.id", "in", parentIds)
      .execute();
    for (const p of parents) {
      parentInfoById.set(p.id, { doctor_id: p.doctor_id, doctor_name: p.doctor_name, service_id: p.service_id, service_name: p.service_name });
    }
  }

  const followups = followupRaw
    .map((f) => {
      const parent = f.parent_invoice_id != null ? parentInfoById.get(f.parent_invoice_id) : undefined;
      return {
        id: f.id,
        paid: f.paid,
        payment_method: f.payment_method,
        visit_date: f.visit_date,
        doctor_id: parent?.doctor_id ?? null,
        doctor_name: parent?.doctor_name ?? null,
        service_id: parent?.service_id ?? null,
        service_name: parent?.service_name ?? null,
      };
    })
    .filter((f) => (doctorId ? f.doctor_id === doctorId : true))
    .filter((f) => (serviceId ? f.service_id === serviceId : true));

  const newAmount = round2(rootInvoices.reduce((s, i) => s + i.amount, 0));
  const collected = round2(rootInvoices.reduce((s, i) => s + i.paid, 0) + followups.reduce((s, f) => s + f.paid, 0));
  const visitCount = rootInvoices.length;

  const byMethodMap = new Map<string, number>();
  for (const i of rootInvoices) {
    if (i.paid <= 0) continue;
    const key = i.payment_method ?? "غير محدد";
    byMethodMap.set(key, round2((byMethodMap.get(key) ?? 0) + i.paid));
  }
  for (const f of followups) {
    if (f.paid <= 0) continue;
    const key = f.payment_method ?? "غير محدد";
    byMethodMap.set(key, round2((byMethodMap.get(key) ?? 0) + f.paid));
  }

  function aggregate<T extends { paid: number }>(
    rootRows: (T & { amount: number; visit_date: string })[],
    followupRows: T[],
    keyOf: (r: T) => string | number | null,
    labelOf: (r: T) => string
  ): ReportRow[] {
    const map = new Map<string | number, ReportRow>();
    for (const r of rootRows) {
      const k = keyOf(r);
      if (k == null) continue;
      const cur = map.get(k) ?? { key: k, label: labelOf(r), amount: 0, paid: 0, visits: 0 };
      cur.amount = round2(cur.amount + r.amount);
      cur.paid = round2(cur.paid + r.paid);
      cur.visits += 1;
      map.set(k, cur);
    }
    for (const r of followupRows) {
      const k = keyOf(r);
      if (k == null) continue;
      const cur = map.get(k) ?? { key: k, label: labelOf(r), amount: 0, paid: 0, visits: 0 };
      cur.paid = round2(cur.paid + r.paid);
      map.set(k, cur);
    }
    return [...map.values()].sort((a, b) => b.paid - a.paid);
  }

  const byDoctor =
    reportsFull && !doctorId
      ? aggregate(rootInvoices, followups, (r) => r.doctor_id, (r) => r.doctor_name ?? "بدون دكتور")
      : [];

  const byService = aggregate(rootInvoices, followups, (r) => r.service_id, (r) => r.service_name ?? "بدون خدمة");

  const byDayMap = new Map<string, ReportDayRow>();
  for (const r of rootInvoices) {
    const cur = byDayMap.get(r.visit_date) ?? { date: r.visit_date, amount: 0, paid: 0, visits: 0 };
    cur.amount = round2(cur.amount + r.amount);
    cur.paid = round2(cur.paid + r.paid);
    cur.visits += 1;
    byDayMap.set(r.visit_date, cur);
  }
  for (const f of followups) {
    const cur = byDayMap.get(f.visit_date) ?? { date: f.visit_date, amount: 0, paid: 0, visits: 0 };
    cur.paid = round2(cur.paid + f.paid);
    byDayMap.set(f.visit_date, cur);
  }
  const byDay = [...byDayMap.values()].sort((a, b) => (a.date < b.date ? 1 : -1));

  return {
    ok: true,
    reportsFull,
    from,
    to,
    dateRangeClamped,
    reportsOwnMinFrom,
    doctorId,
    serviceId,
    doctors,
    services,
    newAmount,
    collected,
    visitCount,
    byMethod: [...byMethodMap.entries()],
    byDoctor,
    byService,
    byDay,
  };
}
