import "server-only";
import { SignJWT, jwtVerify } from "jose";

const REPORT_ACCESS_SECRET = new TextEncoder().encode(
  `${process.env.SESSION_SECRET || "dev-only-secret-change-in-production-please"}:doctor-report-access`
);

export const DOCTOR_REPORT_ACCESS_COOKIE = "clinic_doctor_report_access";

export type DoctorReportAccess = {
  userId: number;
  from: string;
  to: string;
  doctorId: number | null;
  serviceId: number | null;
};

export async function createDoctorReportAccessToken(access: DoctorReportAccess) {
  return new SignJWT(access)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("10m")
    .sign(REPORT_ACCESS_SECRET);
}

export async function verifyDoctorReportAccessToken(token: string | undefined, expected: DoctorReportAccess) {
  if (!token) return false;
  try {
    const { payload } = await jwtVerify(token, REPORT_ACCESS_SECRET);
    return (
      Number(payload.userId) === expected.userId &&
      payload.from === expected.from &&
      payload.to === expected.to &&
      (payload.doctorId == null ? null : Number(payload.doctorId)) === expected.doctorId &&
      (payload.serviceId == null ? null : Number(payload.serviceId)) === expected.serviceId
    );
  } catch {
    return false;
  }
}
