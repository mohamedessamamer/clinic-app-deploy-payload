import { db } from "@/lib/db/client";
import { getClinicToday } from "@/lib/clinic-date";

export const CONSULTANT_REMINDER_MONTHS = 3;

export interface ConsultantReminder {
  needsConsultantVisit: boolean;
  consultantDoctorId: number | null;
  consultantName: string | null;
  lastSeenAt: string | null;
}

function monthsAgo(date: string, months: number): string {
  const value = new Date(`${date}T00:00:00Z`);
  value.setUTCMonth(value.getUTCMonth() - months);
  return value.toISOString().slice(0, 10);
}

// يحسب تنبيه الاستشاري لمجموعة مرضى مرة واحدة حتى لا يتحول جدول الاستقبال
// إلى استعلام منفصل لكل خلية. الزيارات القديمة التي كان Doctor فيها استشارياً
// تُعامل كزيارة استشاري تلقائياً، حتى قبل إضافة عمود Seen by consultant.
export async function computeConsultantReminderMap(patientIds: number[]): Promise<Map<number, ConsultantReminder>> {
  const result = new Map<number, ConsultantReminder>();
  const ids = [...new Set(patientIds)].filter((id) => Number.isInteger(id) && id > 0);
  if (ids.length === 0) return result;

  const [charts, visits, doctors, links, appointments] = await Promise.all([
    db.selectFrom("orthodontic_charts").select(["patient_id", "created_at"]).where("patient_id", "in", ids).execute(),
    db
      .selectFrom("ortho_visits")
      .select(["patient_id", "visit_date", "doctor_id", "seen_by_consultant", "consultant_doctor_id"])
      .where("patient_id", "in", ids)
      .orderBy("visit_date", "asc")
      .orderBy("id", "asc")
      .execute(),
    db.selectFrom("doctors").select(["id", "full_name", "is_consultant"]).where("active", "=", 1).execute(),
    db.selectFrom("consultant_assistants").selectAll().execute(),
    db
      .selectFrom("appointments")
      .select(["patient_id", "doctor_id", "appointment_date", "id"])
      .where("patient_id", "in", ids)
      .where("status", "!=", "cancelled")
      .orderBy("appointment_date", "desc")
      .orderBy("id", "desc")
      .execute(),
  ]);

  const doctorById = new Map(doctors.map((doctor) => [doctor.id, doctor]));
  const consultantsByAssistant = new Map<number, number[]>();
  for (const link of links) {
    const list = consultantsByAssistant.get(link.assistant_doctor_id) ?? [];
    list.push(link.consultant_doctor_id);
    consultantsByAssistant.set(link.assistant_doctor_id, list);
  }
  const consultantForDoctor = (doctorId: number | null): number | null => {
    if (!doctorId) return null;
    if (doctorById.get(doctorId)?.is_consultant === 1) return doctorId;
    return consultantsByAssistant.get(doctorId)?.[0] ?? null;
  };

  const chartStartByPatient = new Map(charts.map((chart) => [chart.patient_id, chart.created_at.slice(0, 10)]));
  const visitsByPatient = new Map<number, typeof visits>();
  for (const visit of visits) {
    const list = visitsByPatient.get(visit.patient_id) ?? [];
    list.push(visit);
    visitsByPatient.set(visit.patient_id, list);
  }
  const latestAppointmentDoctor = new Map<number, number>();
  for (const appointment of appointments) {
    if (!latestAppointmentDoctor.has(appointment.patient_id)) latestAppointmentDoctor.set(appointment.patient_id, appointment.doctor_id);
  }

  const cutoff = monthsAgo(getClinicToday(), CONSULTANT_REMINDER_MONTHS);
  for (const patientId of ids) {
    const chartStart = chartStartByPatient.get(patientId);
    const patientVisits = visitsByPatient.get(patientId) ?? [];
    if (!chartStart && patientVisits.length === 0) {
      result.set(patientId, { needsConsultantVisit: false, consultantDoctorId: null, consultantName: null, lastSeenAt: null });
      continue;
    }

    let lastSeenAt: string | null = null;
    let consultantDoctorId: number | null = null;
    for (const visit of patientVisits) {
      const selectedDoctorIsConsultant = doctorById.get(visit.doctor_id ?? -1)?.is_consultant === 1;
      if (visit.seen_by_consultant === 1 || selectedDoctorIsConsultant) {
        lastSeenAt = visit.visit_date;
        consultantDoctorId = visit.consultant_doctor_id ?? consultantForDoctor(visit.doctor_id);
      }
    }

    if (!consultantDoctorId) {
      const latestVisitDoctorId = patientVisits.at(-1)?.doctor_id ?? null;
      consultantDoctorId = consultantForDoctor(latestVisitDoctorId) ?? consultantForDoctor(latestAppointmentDoctor.get(patientId) ?? null);
    }
    const trackingStart = patientVisits[0]?.visit_date ?? chartStart!;
    const needsConsultantVisit = lastSeenAt ? lastSeenAt <= cutoff : trackingStart <= cutoff;
    result.set(patientId, {
      needsConsultantVisit,
      consultantDoctorId,
      consultantName: consultantDoctorId ? doctorById.get(consultantDoctorId)?.full_name ?? null : null,
      lastSeenAt,
    });
  }

  return result;
}
