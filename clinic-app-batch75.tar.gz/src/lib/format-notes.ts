/**
 * Keeps multi-line clinical notes readable wherever HTML would otherwise
 * collapse the line breaks into one run-on sentence.
 */
export function formatNoteLines(value: string | null | undefined): string {
  if (!value) return "";
  return value
    .split(/\r?\n/)
    .map((line) => line.trim().replace(/^[-–—]\s*/, ""))
    .filter(Boolean)
    .join(" - ");
}
