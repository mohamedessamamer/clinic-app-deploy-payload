import type { Transaction } from "kysely";
import type { Database } from "@/lib/db/types";

// نفس ترتيب نموذج الجرد الذي أرسله المستخدم: عشرة أسنان علوي ثم عشرة سفلي.
export const BRACKET_TEETH = [15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 45, 44, 43, 42, 41, 31, 32, 33, 34, 35] as const;
export const BRACKET_BRANDS = ["American", "Ormco"] as const;
export type BracketBrand = typeof BRACKET_BRANDS[number];

export function isBracketBrand(value: string | null | undefined): value is BracketBrand {
  return BRACKET_BRANDS.includes(value as BracketBrand);
}

export async function deductBracketTooth(
  trx: Transaction<Database>,
  params: { brand: BracketBrand; fdi: number; patientId: number; visitId?: number | null; date?: string | null; createdBy: number; note?: string }
) {
  await trx.updateTable("orthodontic_bracket_stock")
    .set((eb) => ({ quantity: eb("quantity", "-", 1), updated_at: new Date().toISOString() }))
    .where("brand", "=", params.brand).where("fdi", "=", params.fdi).execute();
  await trx.insertInto("orthodontic_bracket_stock_movements").values({
    brand: params.brand, fdi: params.fdi, quantity: -1, movement_type: "ortho_use",
    patient_id: params.patientId, visit_id: params.visitId ?? null, movement_date: params.date ?? null, created_by: params.createdBy,
    note: params.note ?? "استخدام من شارت التقويم",
  }).execute();
}

export async function returnBracketTooth(
  trx: Transaction<Database>,
  params: { brand: BracketBrand; fdi: number; patientId: number; visitId?: number | null; date?: string | null; createdBy: number; note?: string }
) {
  await trx.updateTable("orthodontic_bracket_stock")
    .set((eb) => ({ quantity: eb("quantity", "+", 1), updated_at: new Date().toISOString() }))
    .where("brand", "=", params.brand).where("fdi", "=", params.fdi).execute();
  await trx.insertInto("orthodontic_bracket_stock_movements").values({
    brand: params.brand, fdi: params.fdi, quantity: 1, movement_type: "return",
    patient_id: params.patientId, visit_id: params.visitId ?? null, movement_date: params.date ?? null, created_by: params.createdBy,
    note: params.note ?? "إرجاع من شارت التقويم",
  }).execute();
}
