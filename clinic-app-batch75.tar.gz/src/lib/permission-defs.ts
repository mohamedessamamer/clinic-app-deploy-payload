import type { Role } from "./auth";

// ثوابت الصلاحيات فقط — من غير أي استيراد لطبقة قاعدة البيانات، عشان يصلح
// للاستخدام في مكونات العميل (client components) زي PermissionsManager كمان.
// الدوال اللي بتلمس قاعدة البيانات (getPermissionOverrides..) موجودة في lib/permissions.ts.
export const PERMISSION_GROUPS = [
  { key: "appointments", label: "الاستقبال والمواعيد" },
  { key: "medical", label: "الصلاحيات الطبية" },
  { key: "financial", label: "الصلاحيات المالية والتقارير" },
  { key: "inventory", label: "صلاحيات المخزن" },
  { key: "administration", label: "الإدارة والتواصل" },
] as const;

export const PERMISSION_DEFS = [
  { key: "schedule_all_rooms", group: "appointments", title: "عرض كل العيادات", description: "يعرض الجدول المركزي لكل الغرف بدل شيفت المستخدم فقط." },
  { key: "schedule_edit", group: "appointments", title: "تعديل المواعيد", description: "حجز موعد وتغيير حالته من الجدول المركزي." },
  { key: "mark_appointment_done", group: "appointments", title: "إنهاء الموعد", description: "يسمح للطبيب بتحديد مواعيده اليوم كحالة تم، بعيدًا عن التحصيل." },
  { key: "view_needs_treatment_reminder", group: "appointments", title: "تنبيه المعالجة الناقصة", description: "يعرض تنبيه الموعد الذي تم بدون تسجيل المعالجة." },
  { key: "create_collection_requests_all_doctors", group: "appointments", title: "طلبات تحصيل كل الأطباء", description: "يسجل طلب التحصيل نيابة عن أي طبيب مع حفظ اسم طبيب الموعد." },

  { key: "view_patients_list", group: "medical", title: "قائمة المرضى", description: "يعرض قائمة المرضى للطبيب، وليس مرضى مواعيده فقط." },
  { key: "view_patient_personal_data", group: "medical", title: "البيانات الشخصية", description: "يعرض السن والهاتف وتاريخ الميلاد والعنوان." },
  { key: "edit_patient_info", group: "medical", title: "تعديل بيانات المريض", description: "تعديل الاسم والميلاد والهاتف والعنوان." },
  { key: "override_visit_doctor", group: "medical", title: "اختيار طبيب مساعد", description: "يحدد مقدم خدمة مختلف بدون تغيير صاحب التحصيل." },
  { key: "edit_old_visits", group: "medical", title: "تعديل الزيارات القديمة", description: "يعدل زيارات الملف الطبي بعد انتهاء مهلة الثلاثة أيام." },
  { key: "edit_visit_assistant_doctor", group: "medical", title: "تعديل الطبيب المساعد", description: "يعدل الطبيب المساعد في زيارة محفوظة فقط." },
  { key: "edit_ortho_visit_after_save", group: "medical", title: "تعديل زيارات التقويم القديمة", description: "يفعّل زر Edit للزيارات المحفوظة في شارت التقويم." },
  { key: "upload_ortho_photos", group: "medical", title: "صور وأشعة التقويم", description: "رفع وتدوير وحذف صور التقويم بدون صلاحية تعديل الشارت كاملًا." },
  { key: "delete_visits", group: "medical", title: "حذف الزيارات", description: "يحذف الزيارة وفاتورتها نهائيًا لتصحيح الإدخال الخاطئ." },

  { key: "reports_full", group: "financial", title: "كل التقارير", description: "يعرض تقارير كل الأطباء والفترات." },
  { key: "reports_own", group: "financial", title: "التقرير الشخصي", description: "يعرض تقرير الطبيب نفسه ضمن الحد الزمني المحدد." },
  { key: "collect_payments", group: "financial", title: "تحصيل المدفوعات", description: "يسجل التحصيل من شاشة الاستقبال." },
  { key: "view_patient_billing", group: "financial", title: "الملف المالي للمريض", description: "يعرض فواتير ومدفوعات المريض وإضافة خدمة مالية." },
  { key: "edit_invoice_payments", group: "financial", title: "تصحيح الفواتير", description: "يعدل السعر أو المدفوع ويسمح بالتسجيل بتاريخ قديم." },
  { key: "view_invoice_totals", group: "financial", title: "إجماليات الفواتير", description: "يعرض إجمالي الفواتير والمحصّل والمتبقي." },
  { key: "manage_expenses", group: "financial", title: "المصروفات والمرتبات", description: "إدارة المصروفات وكشوف رواتب الأطباء." },

  { key: "manage_inventory", group: "inventory", title: "استخدام المخزن", description: "فتح المخزن وتسجيل الجرد والتوريدات." },
  { key: "edit_inventory_catalog", group: "inventory", title: "تعديل كتالوج المخزن", description: "إضافة وتعديل الأصناف والتخصصات وإعداداتها." },
  { key: "delete_inventory_records", group: "inventory", title: "حذف بيانات المخزن", description: "يحذف أو يلغي بيانات المخزن المسجلة بالخطأ." },
  { key: "undo_ortho_inventory_deduction", group: "inventory", title: "إلغاء خصم التقويم", description: "يلغي خصمًا مسجلًا من Inventory list في شارت التقويم." },

  { key: "manage_settings", group: "administration", title: "صفحة الإعدادات", description: "يسمح بالدخول إلى إعدادات النظام." },
  { key: "send_staff_chat_to_doctors", group: "administration", title: "مراسلة الأطباء", description: "يسمح للطبيب بإرسال رسالة لطبيب أو لكل الأطباء." },
] as const;

export type PermissionKey = (typeof PERMISSION_DEFS)[number]["key"];

export const ROLE_DEFAULT_PERMISSIONS: Record<Role, PermissionKey[]> = {
  admin: [
    "reports_full",
    "collect_payments",
    "manage_inventory",
    "edit_inventory_catalog",
    "delete_inventory_records",
    "manage_expenses",
    "manage_settings",
    "schedule_all_rooms",
    "schedule_edit",
    "override_visit_doctor",
    "edit_old_visits",
    "edit_invoice_payments",
    "delete_visits",
    "view_invoice_totals",
    "view_patient_billing",
    "edit_patient_info",
    "edit_visit_assistant_doctor",
    "edit_ortho_visit_after_save",
    "undo_ortho_inventory_deduction",
  ],
  clinic_manager: [
    "reports_full",
    "manage_inventory",
    "schedule_all_rooms",
    "override_visit_doctor",
    "edit_old_visits",
    "edit_invoice_payments",
    "view_invoice_totals",
    "view_patient_billing",
    "edit_visit_assistant_doctor",
  ],
  accountant: [
    "reports_full",
    "collect_payments",
    "manage_expenses",
    "edit_invoice_payments",
    "view_invoice_totals",
    "view_patient_billing",
  ],
  // manage_inventory ضمن الافتراضي هنا عشان الاستقبال كان عنده وصول للمخزون
  // أصلاً (رابط ثابت في القائمة قبل ما يبقى صلاحية) — عشان التحويل للنظام
  // الجديد ميقفلش حاجة كانت شغالة بالفعل. لسه ممكن تُسحب من مستخدم استقبال
  // معيّن من الإعدادات لو حابب.
  reception: [
    "collect_payments",
    "schedule_all_rooms",
    "schedule_edit",
    "view_patient_billing",
    "manage_inventory",
    "edit_patient_info",
    "view_patient_personal_data",
    "edit_visit_assistant_doctor",
    "upload_ortho_photos",
  ],
  // الدكتور افتراضيًا يشوف الجدول المركزي لشيفته/غرفته بس النهاردة، وبشكل عرض فقط
  // (من غير حجز أو تغيير حالة) — الأدمن يقدر يوسّع الصلاحيات دي لدكتور معيّن من
  // صفحة الإعدادات لو حابب (schedule_all_rooms و/أو schedule_edit).
  doctor: ["reports_own", "view_needs_treatment_reminder", "mark_appointment_done"],
};
