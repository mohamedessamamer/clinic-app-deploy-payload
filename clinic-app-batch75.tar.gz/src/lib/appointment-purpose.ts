export type AppointmentPurposeRouting = {
  purpose_type?: "bonding_upper" | "bonding_lower" | "service" | null;
  purpose_service_category?: string | null;
  purpose_linked_invoice_id?: number | null;
  purpose_linked_service_category?: string | null;
};

function isOrthodonticCategory(value: string | null | undefined): boolean {
  const category = (value ?? "").trim().toLowerCase();
  return category === "orthodontics" || category === "تقويم" || category.includes("orthodont");
}

// Route by what this appointment is for, never merely because the patient has
// an orthodontic chart. A generic follow-up inherits its clinical context from
// the original invoice selected when the appointment purpose was recorded.
export function isOrthodonticAppointmentPurpose(appointment: AppointmentPurposeRouting): boolean {
  if (appointment.purpose_type === "bonding_upper" || appointment.purpose_type === "bonding_lower") return true;
  if (appointment.purpose_type !== "service") return false;
  if (isOrthodonticCategory(appointment.purpose_service_category)) return true;
  return Boolean(appointment.purpose_linked_invoice_id) && isOrthodonticCategory(appointment.purpose_linked_service_category);
}
