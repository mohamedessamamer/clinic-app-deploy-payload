import { formatNoteLines } from "@/lib/format-notes";

type Visit = { id:number; visit_date:string; service_name:string|null; service_name_en?:string|null; notes:string|null; doctor_name:string|null; ortho_visit_id?:number|null };

function kindFor(visit: Visit) {
  const label = visit.service_name_en || visit.service_name || (visit.ortho_visit_id ? "Orthodontic chart" : "Clinical visit");
  const low = label.toLowerCase();
  if (visit.ortho_visit_id || low.includes("ortho") || label.includes("تقويم")) return "Orthodontics";
  if (low.includes("consult") || label.includes("استشارة")) return "Consultation";
  return "Treatment";
}

export default function MedicalTimeline({ visits }: { visits: Visit[] }) {
  if (!visits.length) return <p className="text-sm text-muted py-8 text-center">No medical visits recorded yet.</p>;
  return <div className="medical-timeline">
    {visits.slice(0, 4).map((visit) => (
      <article className="timeline-item" key={visit.id}>
        <time className="timeline-date">{visit.visit_date}</time>
        <span className="timeline-dot" />
        <div className="timeline-card">
          <span className="visit-kind">{kindFor(visit)}</span>
          <div className="font-semibold pr-28">{visit.doctor_name || "Clinic team"}</div>
          <p className="text-sm text-muted mt-2 pr-28">{formatNoteLines(visit.notes) || "No treatment notes added."}</p>
          <p className="text-sm mt-2 font-medium">{visit.service_name_en || visit.service_name || (visit.ortho_visit_id ? "Orthodontic chart" : "Clinical visit")}</p>
        </div>
      </article>
    ))}
  </div>;
}
