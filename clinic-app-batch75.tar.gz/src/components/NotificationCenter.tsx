"use client";

import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { getNotificationCenterAction, markNotificationsReadAction, updateFollowupCaseAction } from "@/app/notifications/actions";

type Notification = {
  id: number;
  type: string;
  title: string;
  body: string;
  patient_id: number | null;
  notification_case_id: number | null;
  read_at: string | null;
  created_at: string;
};

export default function NotificationCenter({ initialNotifications, canResolveFollowups }: { initialNotifications: Notification[]; canResolveFollowups: boolean }) {
  const router = useRouter();
  const [items, setItems] = useState(initialNotifications);
  const [open, setOpen] = useState(false);
  const [busy, startTransition] = useTransition();
  const unread = items.filter((item) => !item.read_at).length;

  useEffect(() => {
    const timer = window.setInterval(() => {
      getNotificationCenterAction().then(setItems).catch(() => undefined);
    }, 30_000);
    return () => window.clearInterval(timer);
  }, []);

  function openPanel() {
    setOpen((wasOpen) => !wasOpen);
    if (!open && unread) {
      setItems((current) => current.map((item) => ({ ...item, read_at: item.read_at ?? new Date().toISOString() })));
      markNotificationsReadAction().catch(() => undefined);
    }
  }

  function resolveCase(form: FormData) {
    startTransition(async () => {
      const result = await updateFollowupCaseAction(form);
      if (!result.ok) return window.alert(result.reason || "تعذر حفظ الإجراء.");
      const rows = await getNotificationCenterAction();
      setItems(rows);
      router.refresh();
    });
  }

  return (
    <div className="relative clinic-notifications">
      <button type="button" onClick={openPanel} className="clinic-notification-trigger" title="الإشعارات" aria-label="الإشعارات">
        🔔
        <span className="absolute -top-1.5 -left-1.5 h-4 min-w-4 px-1 rounded-full bg-red-600 text-white text-[10px] leading-4 font-bold" hidden={!unread}>
          {unread > 99 ? "99+" : unread}
        </span>
      </button>
      {open && (
        <div className="clinic-notifications-panel absolute z-50 left-0 mt-2 w-[min(24rem,calc(100vw-2rem))] max-h-[75vh] overflow-y-auto card-3d rounded-xl p-3 shadow-xl text-right">
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-semibold">الإشعارات</h2>
            <span className="text-xs text-muted">تُحفظ 48 ساعة</span>
          </div>
          {!items.length ? (
            <p className="text-sm text-muted py-5 text-center">لا توجد إشعارات حالية.</p>
          ) : (
            <div className="space-y-2">
              {items.map((item) => (
                <article key={item.id} className={`clinic-notification-card rounded-lg border p-2.5 text-sm ${item.read_at ? "is-read" : "is-unread"}`}>
                  <div className="font-medium">{item.title}</div>
                  <p className="text-xs text-muted mt-1 leading-5">{item.body}</p>
                  {item.patient_id && (
                    <button type="button" onClick={() => router.push(`/patients/${item.patient_id}`)} className="text-xs text-primary hover:underline mt-2">
                      فتح ملف المريض
                    </button>
                  )}
                  {canResolveFollowups && item.notification_case_id && item.type === "ortho_followup" && (
                    <form action={resolveCase} className="mt-3 border-t border-border pt-2 space-y-2">
                      <input type="hidden" name="case_id" value={item.notification_case_id} />
                      <select name="status" defaultValue="resolved" className="w-full rounded border border-border bg-background px-2 py-1.5 text-xs">
                        <option value="resolved">إغلاق الحالة بسبب</option>
                        <option value="snoozed">تأجيل المتابعة إلى تاريخ</option>
                      </select>
                      <input name="reason" required placeholder="مثال: مسافر / لا يرد / حجز موعد جديد" className="w-full rounded border border-border bg-background px-2 py-1.5 text-xs" />
                      <input name="next_review_date" type="date" className="w-full rounded border border-border bg-background px-2 py-1.5 text-xs" />
                      <button disabled={busy} className="px-2 py-1 rounded border border-primary text-primary text-xs hover:bg-primary-soft">حفظ الإجراء</button>
                    </form>
                  )}
                </article>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
