"use client";

import { useEffect, useMemo, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import ServiceCombobox from "./ServiceCombobox";
import { PAYMENT_METHODS } from "@/lib/payment-methods";
import { FOLLOWUP_SERVICE_CODE } from "@/lib/followup";
import {
  recordAppointmentBillingAction,
  recordPendingBillingAction,
  getPatientBillableInvoicesAction,
} from "@/app/appointments/billing-actions";
import { updateAppointmentStatusAction } from "@/app/appointments/actions";

type Service = { id: number; name: string; code?: string | null; default_price?: number | null };
type Doctor = { id: number; full_name: string };
type BillableInvoice = { id: number; service_name: string; visit_date: string; balance: number };

// كارت "موعد استثنائي" — بيظهر للدكتور لما يكون معهوش شيفت أسبوعي مسجل النهاردة
// (دفعة 24، طلب المستخدم صراحة)، بس الاستقبال حجزت له مريض في يوم مش يوم شيفته
// العادي (حالة طارئة/استثنائية). عمدًا مش بيستخدم الجدول المركزي الكامل (اللي
// كان هيعرض كل حجوزات الغرفة في اليوم ده من دكاترة/مرضى تانيين معاه في نفس
// الغرفة) — بيعرض بس اسم المريض ده والساعة المحجوزة، وزرار "تم" مبسّط بيسجل
// نفس تدفق الجدول المركزي (بوكس "المطلوب دفعه" لمين معهوش صلاحية تحصيل، أو
// تحصيل فعلي لمين معاه الصلاحية).
export default function AdHocAppointmentCard({
  appointmentId,
  patientId,
  patientName,
  startTime,
  roomName,
  status,
  needsBilling,
  needsNewPhotos,
  needsConsultantVisit,
  pendingServiceName,
  patientHref,
  services,
  doctors,
  canEdit,
  canMarkDone,
  canCollectPayments,
  canEditAssistantDoctor,
  isDoctorView,
}: {
  appointmentId: number;
  patientId: number;
  patientName: string;
  startTime: string;
  roomName: string;
  status: "booked" | "attended" | "done" | "cancelled" | "no_show";
  needsBilling: boolean;
  needsNewPhotos: boolean;
  needsConsultantVisit: boolean;
  pendingServiceName: string | null;
  patientHref: string;
  services: Service[];
  doctors: Doctor[];
  canEdit: boolean;
  canMarkDone: boolean;
  canCollectPayments: boolean;
  canEditAssistantDoctor: boolean;
  isDoctorView: boolean;
}) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [serviceId, setServiceId] = useState("");
  const [price, setPrice] = useState("0");
  const [discountPercent, setDiscountPercent] = useState("0");
  const [amountNow, setAmountNow] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("cash");
  const [performingDoctorId, setPerformingDoctorId] = useState("");
  const [targetInvoiceId, setTargetInvoiceId] = useState("");
  const [billableInvoices, setBillableInvoices] = useState<BillableInvoice[] | null>(null);
  const [isPending, startTransition] = useTransition();

  function markDone() {
    const fd = new FormData();
    fd.set("id", String(appointmentId));
    fd.set("status", "done");
    startTransition(async () => {
      await updateAppointmentStatusAction(fd);
      router.refresh();
    });
  }

  const selectedService = useMemo(() => services.find((s) => String(s.id) === serviceId) ?? null, [services, serviceId]);
  const isFollowup = selectedService?.code === FOLLOWUP_SERVICE_CODE;

  function selectService(nextServiceId: string) {
    setServiceId(nextServiceId);
    const service = services.find((item) => String(item.id) === nextServiceId);
    setPrice(String(service?.default_price ?? 0));
    setDiscountPercent("0");
    setAmountNow("");
    setTargetInvoiceId("");
  }

  useEffect(() => {
    if (!isFollowup) return;
    getPatientBillableInvoicesAction(patientId).then(setBillableInvoices);
  }, [isFollowup, patientId]);

  function submit() {
    if (!selectedService) return;
    if (isFollowup && !targetInvoiceId) return;
    if (canCollectPayments && !amountNow.trim()) return;

    if (canCollectPayments) {
      const fd = new FormData();
      fd.set("appointment_id", String(appointmentId));
      fd.set("service_id", selectedService.id.toString());
      fd.set("payment_method", paymentMethod);
      fd.set("amount_now", String(Number(amountNow) || 0));
      if (isFollowup) {
        fd.set("target_invoice_id", targetInvoiceId);
      } else {
        fd.set("price", String(Number(price) || 0));
        fd.set("discount_percent", String(Number(discountPercent) || 0));
      }
      if (performingDoctorId) fd.set("performing_doctor_id", performingDoctorId);
      startTransition(() => {
        recordAppointmentBillingAction(fd);
      });
    } else {
      const fd = new FormData();
      fd.set("appointment_id", String(appointmentId));
      fd.set("service_id", selectedService.id.toString());
      fd.set("price", String(Number(price) || 0));
      fd.set("discount_percent", String(Number(discountPercent) || 0));
      startTransition(() => {
        recordPendingBillingAction(fd);
      });
    }
    setOpen(false);
  }

  return (
    <div className={`card-3d rounded-xl p-4 space-y-2 ${status === "done" ? "schedule-appointment-cell--done" : ""}`}>
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <Link
            href={patientHref}
            className="font-semibold hover:underline"
          >
            {patientName}
          </Link>
          <div className="text-xs text-muted">
            {roomName} — {startTime}
          </div>
          {needsBilling && (
            <div className="text-xs font-semibold text-danger mt-0.5">
              محتاج تحصيل{pendingServiceName ? ` — ${pendingServiceName}` : ""}
            </div>
          )}
          {(needsConsultantVisit || needsNewPhotos) && (
            <div className="schedule-card-alerts mt-0.5">
              {[needsConsultantVisit ? "زيارة استشاري" : null, needsNewPhotos ? "يحتاج إلى صور" : null].filter(Boolean).join(" - ")}
            </div>
          )}
        </div>
        <div className="flex items-center gap-2">
          {status !== "done" && (canEdit || canMarkDone) && (
            <button type="button" onClick={markDone} disabled={isPending} className="rounded-md btn-3d-primary px-3 py-1.5 text-xs font-medium disabled:opacity-60">تم</button>
          )}
          {isDoctorView && (
            <button type="button" onClick={() => setOpen((v) => !v)} className="rounded-md border border-border px-3 py-1.5 text-xs font-medium hover:bg-primary-soft">طلب تحصيل</button>
          )}
        </div>
      </div>

      {open && (
        <div className="space-y-2 border-t border-border pt-3">
          <div>
            <label className="block text-xs text-muted mb-1">الخدمة</label>
            <ServiceCombobox name="service_id_display" services={services} value={serviceId} onChange={selectService} />
          </div>

          {selectedService && isFollowup && (
            <div>
              <label className="block text-xs text-muted mb-1">الخدمة الأصلية (اللي هتتخصم منها الدفعة)</label>
              {billableInvoices === null ? (
                <div className="text-xs text-muted">جاري التحميل...</div>
              ) : billableInvoices.length > 0 ? (
                <select
                  value={targetInvoiceId}
                  onChange={(e) => setTargetInvoiceId(e.target.value)}
                  className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                >
                  <option value="">اختر خدمة</option>
                  {billableInvoices.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.service_name} — {b.visit_date} — الباقي {b.balance.toFixed(0)} ج.م
                    </option>
                  ))}
                </select>
              ) : (
                <div className="text-xs text-danger">مفيش فواتير سابقة لسه عليها مبلغ مستحق لهذا المريض.</div>
              )}
            </div>
          )}

          {selectedService && !isFollowup && (
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs text-muted mb-1">السعر</label>
                <input
                  type="number"
                  step="0.01"
                  min={0}
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs text-muted mb-1">خصم (%)</label>
                <input
                  type="number"
                  step="1"
                  min={0}
                  max={100}
                  value={discountPercent}
                  onChange={(e) => setDiscountPercent(e.target.value)}
                  className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                />
              </div>
            </div>
          )}

          {selectedService && canEditAssistantDoctor && (
            <div>
              <label className="block text-xs text-muted mb-1">الطبيب المساعد (لو مختلف)</label>
              <select
                value={performingDoctorId}
                onChange={(e) => setPerformingDoctorId(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              >
                <option value="">نفس دكتور الموعد</option>
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.full_name}
                  </option>
                ))}
              </select>
            </div>
          )}

          {selectedService && canCollectPayments && (
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs text-emerald-700 font-medium mb-1">المبلغ المدفوع دلوقتي *</label>
                <input
                  type="number"
                  step="0.01"
                  min={0}
                  required
                  value={amountNow}
                  onChange={(e) => {
                    setAmountNow(e.target.value);
                  }}
                  className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs text-muted mb-1">وسيلة الدفع</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                >
                  {PAYMENT_METHODS.map((m) => (
                    <option key={m.value} value={m.value}>
                      {m.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          <div className="flex gap-2">
            <button
              type="button"
              disabled={isPending || !selectedService || (canCollectPayments && !amountNow.trim()) || (isFollowup && !targetInvoiceId)}
              onClick={submit}
              className="rounded-md btn-3d-primary px-3 py-1.5 text-xs font-medium disabled:opacity-60"
            >
              {isPending ? "جاري الحفظ..." : "حفظ"}
            </button>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="text-xs px-3 py-1.5 rounded-md border border-border hover:bg-primary-soft"
            >
              إلغاء
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
