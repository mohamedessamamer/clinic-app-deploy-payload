"use client";

import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";

const HISTORY_KEY = "clinic-app-page-history";

export default function HeaderBackButton() {
  const pathname = usePathname();
  const router = useRouter();
  const [canGoBack, setCanGoBack] = useState(false);

  useEffect(() => {
    let history: string[] = [];
    try {
      history = JSON.parse(window.sessionStorage.getItem(HISTORY_KEY) || "[]") as string[];
    } catch {
      history = [];
    }
    if (history.at(-2) === pathname) history.pop();
    else if (history.at(-1) !== pathname) history.push(pathname);
    history = history.slice(-30);
    window.sessionStorage.setItem(HISTORY_KEY, JSON.stringify(history));
    setCanGoBack(history.length > 1);
  }, [pathname]);

  function goBack() {
    if (!canGoBack) return;
    const history = JSON.parse(window.sessionStorage.getItem(HISTORY_KEY) || "[]") as string[];
    history.pop();
    const target = history.at(-1);
    window.sessionStorage.setItem(HISTORY_KEY, JSON.stringify(history));
    if (target) router.push(target);
    setCanGoBack(history.length > 1);
  }

  return (
    <button type="button" onClick={goBack} disabled={!canGoBack} className="clinic-header-back" aria-label="الرجوع للصفحة السابقة" title="رجوع">
      <span aria-hidden="true">←</span><span>رجوع</span>
    </button>
  );
}
