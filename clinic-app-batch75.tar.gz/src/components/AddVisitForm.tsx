"use client";

import { useMemo, useState } from "react";
import { addVisitAction } from "@/app/patients/[id]/actions";
import ServiceCombobox from "@/components/ServiceCombobox";
import { getClinicToday } from "@/lib/clinic-date";

type Service = { id: number; name: string; name_en?: string | null; code?: string | null; default_price?: number | null };
type Doctor = { id: number; full_name: string };

export default function AddVisitForm({
  patientId,
  services,
  doctors,
  currentDoctorId = null,
  canOverrideDoctor = false,
  todaysApptDoctorId = null,
  todaysApptDoctorName = null,
  language = "en",
}: {
  patientId: number;
  services: Service[];
  doctors: Doctor[];
  // لو المستخدم الحالي دكتور (داخل بأكونته هو)، بيبقى هو الطبيب الأساسي (اللي
  // بيتحسب له ماليًا) أوتوماتيك من غير ما يحتاج يختار نفسه من قايمة أصلًا.
  currentDoctorId?: number | null;
  // صلاحية "اختيار مقدم خدمة مختلف" — بتفتح حقل تاني اختياري لتحديد مين اللي نفّذ
  // الخدمة فعليًا لو مختلف عن الطبيب الأساسي (زي دكتور مساعد)، من غير ما ده يأثر
  // على مين بيتحسب له التحصيل المالي (ده بيفضل الطبيب الأساسي/صاحب الشيفت دايمًا).
  canOverrideDoctor?: boolean;
  // للأدمن/مدير العيادة بس (مش دكتور): دكتور موعد المريض المسجل من الاستقبال
  // النهاردة، لو موجود — لو موجود، الطبيب المعالج بيتثبت عليه (مش اختيار حر)
  // وبيبقى متاح بس اختيار "الطبيب المساعد". لو مفيش حجز النهاردة، الفورم بيرجع
  // للاختيار اليدوي العادي (شوف addVisitAction اللي بيعمل نفس التحقق في السيرفر).
  todaysApptDoctorId?: number | null;
  todaysApptDoctorName?: string | null;
  language?: "en" | "ar";
}) {
  const today = useMemo(() => getClinicToday(), []);
  const [serviceId, setServiceId] = useState<string>("");
  const [notes, setNotes] = useState("");

  const isDoctorAccount = currentDoctorId != null;
  const en = language === "en";
  const currentDoctorName = doctors.find((doctor) => doctor.id === currentDoctorId)?.full_name ?? "—";

  return (
    <form action={addVisitAction} className="medical-add-treatment-form space-y-3">
      <input type="hidden" name="patient_id" value={patientId} />
      <div>
        <label className="block text-xs text-muted mb-1">{en ? "Date" : "التاريخ"}</label>
        <input
          type="date"
          name="visit_date"
          defaultValue={today}
          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>

      {isDoctorAccount ? (
        <>
          <input type="hidden" name="doctor_id" value={currentDoctorId ?? ""} />
          <div>
            <label className="block text-xs text-muted mb-1">{en ? "Treating doctor" : "الطبيب المعالج"}</label>
            <div className="medical-add-treatment-readonly">{currentDoctorName}</div>
          </div>
          {canOverrideDoctor && (
            <div>
              <label className="block text-xs text-muted mb-1">{en ? "Treating doctor (if different)" : "الطبيب المساعد (لو مختلف)"}</label>
              <select
                name="performing_doctor_id"
                defaultValue=""
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="">{en ? "Primary doctor (me)" : "نفس الطبيب الأساسي (أنا)"}</option>
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.full_name}
                  </option>
                ))}
              </select>
            </div>
          )}
        </>
      ) : todaysApptDoctorId ? (
        <>
          <input type="hidden" name="doctor_id" value={todaysApptDoctorId} />
          <div>
            <label className="block text-xs text-muted mb-1">{en ? "Treating doctor" : "الطبيب المعالج"}</label>
            <div className="medical-add-treatment-readonly">
              {todaysApptDoctorName ?? "—"}
            </div>
            <p className="text-[10px] text-muted mt-0.5">{en ? "From today’s reception booking" : "حسب حجز الاستقبال النهاردة"}</p>
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">{en ? "Treating doctor (if different)" : "الطبيب المساعد (لو مختلف)"}</label>
            <select
              name="performing_doctor_id"
              defaultValue=""
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="">{en ? "Same as primary doctor" : "نفس الطبيب المعالج فوق"}</option>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.full_name}
                </option>
              ))}
            </select>
          </div>
        </>
      ) : (
        <>
          <div>
            <label className="block text-xs text-muted mb-1">{en ? "Treating doctor" : "الطبيب المعالج"}</label>
            <select
              name="doctor_id"
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="">{en ? "Select a doctor" : "اختر دكتور"}</option>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.full_name}
                </option>
              ))}
            </select>
          </div>
          {canOverrideDoctor && (
            <div>
              <label className="block text-xs text-muted mb-1">{en ? "Treating doctor (if different)" : "الطبيب المساعد (لو مختلف)"}</label>
              <select
                name="performing_doctor_id"
                defaultValue=""
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="">{en ? "Same as selected doctor" : "نفس الدكتور المختار فوق"}</option>
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.full_name}
                  </option>
                ))}
              </select>
            </div>
          )}
        </>
      )}

      <div>
        <label className="block text-xs text-muted mb-1">{en ? "Visit type" : "نوع الزيارة"}</label>
        <ServiceCombobox
          name="service_id"
          services={services}
          value={serviceId}
          onChange={setServiceId}
          useEnglish={en}
          placeholder={en ? "Select visit type..." : undefined}
        />
      </div>

      <div>
        <label className="block text-xs text-muted mb-1">{en ? "Treatment note" : "ملاحظة العلاج"}</label>
        <textarea
          name="notes"
          value={notes}
          onChange={(event) => setNotes(event.target.value)}
          maxLength={500}
          placeholder={en ? "Write treatment notes..." : "اكتب ملاحظات العلاج..."}
          rows={5}
          className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary resize-y"
        />
        <div className="mt-1 text-[10px] text-muted" dir="ltr">{notes.length}/500</div>
      </div>

      <button type="submit" className="w-full rounded-md btn-3d-primary px-4 py-2 text-sm font-medium transition-colors">
        {en ? "+ Add visit" : "+ إضافة زيارة"}
      </button>
    </form>
  );
}
