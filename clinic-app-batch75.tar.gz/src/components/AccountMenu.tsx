"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ChevronDownIcon } from "./icons";
import { setMedicalUiLanguageAction } from "@/app/account/actions";

// قايمة اسم الحساب في القايمة العلوية — بدل ما كان مجرد نص ثابت، بقى زرار
// بيفتح قايمة صغيرة فيها "تغيير كلمة السر" (بيوديك مباشرة لصفحة الإعدادات
// وبيفتحلك سكشن تغيير كلمة السر على طول، مش محتاج تدور عليه).
export default function AccountMenu({
  fullName,
  roleLabel,
  medicalUiLanguage,
}: {
  fullName: string;
  roleLabel: string;
  medicalUiLanguage: "en" | "ar";
}) {
  const [open, setOpen] = useState(false);
  const [isPending, startTransition] = useTransition();
  const router = useRouter();
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  return (
    <div className="relative clinic-account-menu-wrap" ref={wrapRef}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft/40 transition-colors"
      >
        <span>
          {fullName} · {roleLabel}
        </span>
        <ChevronDownIcon className="w-3.5 h-3.5" />
      </button>
      {open && (
        <div className="clinic-account-menu absolute left-0 z-50 mt-1 w-56 card-3d rounded-md shadow-lg overflow-hidden text-sm">
          <Link
            href="/settings?openpw=1"
            onClick={() => setOpen(false)}
            className="block px-3 py-2 hover:bg-primary-soft"
          >
            تغيير كلمة السر
          </Link>
          <button
            type="button"
            disabled={isPending}
            onClick={() => {
              const next = medicalUiLanguage === "en" ? "ar" : "en";
              startTransition(async () => {
                await setMedicalUiLanguageAction(next);
                router.refresh();
              });
            }}
            className="block w-full px-3 py-2 text-right hover:bg-primary-soft disabled:opacity-60"
          >
            لغة الملف الطبي: {medicalUiLanguage === "en" ? "English" : "العربية"}
          </button>
        </div>
      )}
    </div>
  );
}
