globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/3t7cGjzCTlpTBlCImD-uN/_buildManifest.js",
    "static/3t7cGjzCTlpTBlCImD-uN/_ssgManifest.js",
    "static/3t7cGjzCTlpTBlCImD-uN/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/1c6aptmytnu6q.js",
    "static/chunks/3e4keds9ktjdu.js",
    "static/chunks/2o1mrcqyza_ve.js",
    "static/chunks/0ay527mnq1105.js",
    "static/chunks/turbopack-0rbb6zv0yiiq9.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
