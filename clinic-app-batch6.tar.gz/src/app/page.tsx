import Link from "next/link";
import { redirect } from "next/navigation";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { ROLE_LABELS } from "@/lib/auth";
import { getAllSettings, buildTimeSlots } from "@/lib/settings";
import { hasPermission } from "@/lib/permissions";
import { getDoctorRoomIdsForDate } from "@/lib/schedule";
import CentralSchedule from "@/components/CentralSchedule";

async function DoctorHome({ userId, doctorId }: { userId: number; doctorId: number }) {
  const today = new Date().toISOString().slice(0, 10);

  const [canEditSchedule, canSeeAllRooms] = await Promise.all([
    hasPermission(userId, "doctor", "schedule_edit"),
    hasPermission(userId, "doctor", "schedule_all_rooms"),
  ]);

  const allRooms = await db.selectFrom("rooms").selectAll().execute();
  const myRoomIds = canSeeAllRooms ? null : await getDoctorRoomIdsForDate(doctorId, today);
  const visibleRooms = myRoomIds ? allRooms.filter((r) => myRoomIds.includes(r.id)) : allRooms;

  const [appointmentsRaw, patients, doctors, settings] = await Promise.all([
    db
      .selectFrom("appointments")
      .innerJoin("patients", "patients.id", "appointments.patient_id")
      .leftJoin("doctors", "doctors.id", "appointments.doctor_id")
      .select([
        "appointments.id",
        "appointments.patient_id",
        "patients.full_name as patient_name",
        "appointments.doctor_id",
        "doctors.full_name as doctor_name",
        "appointments.room_id",
        "appointments.start_time",
        "appointments.duration_minutes",
        "appointments.status",
        "appointments.notes",
      ])
      .where("appointment_date", "=", today)
      .where("status", "!=", "cancelled")
      .orderBy("appointments.start_time")
      .execute(),
    db.selectFrom("patients").select(["id", "full_name", "file_number"]).orderBy("id", "desc").limit(500).execute(),
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).execute(),
    getAllSettings(),
  ]);

  const slotMinutes = Number(settings.slot_minutes);
  const timeSlots = buildTimeSlots(settings.day_start, settings.day_end, slotMinutes);

  const appointments = appointmentsRaw.map((a) => ({
    id: a.id,
    patient_id: a.patient_id,
    patient_name: a.patient_name,
    doctor_id: a.doctor_id,
    doctor_name: a.doctor_name ?? "-",
    room_id: a.room_id,
    start_time: a.start_time,
    duration_minutes: a.duration_minutes,
    status: a.status as "booked" | "attended" | "done" | "cancelled" | "no_show",
    notes: a.notes,
  }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold">جدول اليوم</h1>
        <p className="text-muted text-sm mt-1">
          {canSeeAllRooms ? "الجدول المركزي لكل العيادات — بيتزامن أوتوماتيك مع الاستقبال." : "جدول شيفتك النهاردة — بيتزامن أوتوماتيك مع الاستقبال."}
        </p>
      </div>

      {visibleRooms.length === 0 ? (
        <div className="text-sm bg-danger-soft text-danger rounded-md px-3 py-2">
          مفيش شيفت أسبوعي مسجل ليك في يوم النهاردة — كلم الأدمن لو محتاج تتأكد من شيفتاتك.
        </div>
      ) : (
        <CentralSchedule
          date={today}
          rooms={visibleRooms}
          timeSlots={timeSlots}
          slotMinutes={slotMinutes}
          appointments={appointments}
          patients={patients}
          doctors={doctors}
          canEdit={canEditSchedule}
        />
      )}
    </div>
  );
}

async function getStats() {
  const [{ count: patients } = { count: 0 }] = await db
    .selectFrom("patients")
    .select((eb) => eb.fn.countAll<number>().as("count"))
    .execute();

  const [{ count: todayAppointments } = { count: 0 }] = await db
    .selectFrom("appointments")
    .select((eb) => eb.fn.countAll<number>().as("count"))
    .where("appointment_date", "=", new Date().toISOString().slice(0, 10))
    .execute();

  const [{ count: todayVisits } = { count: 0 }] = await db
    .selectFrom("visits")
    .select((eb) => eb.fn.countAll<number>().as("count"))
    .where("visit_date", "=", new Date().toISOString().slice(0, 10))
    .execute();

  return { patients, todayAppointments, todayVisits };
}

export default async function HomePage() {
  const session = await getSession();

  if (session?.role === "doctor" && session.doctorId) {
    return <DoctorHome userId={session.userId} doctorId={session.doctorId} />;
  }

  // الاستقبال: صفحته الرئيسية هي الجدول المركزي مباشرة (مفيش داعي لصفحة إحصائيات
  // وسيطة قبله)، بدل ما يضطر يدوس "جدول الاستقبال" من القايمة كل مرة يسجل دخول.
  if (session?.role === "reception") {
    redirect("/front-desk");
  }

  const stats = await getStats();

  const cards = [
    { label: "إجمالي المرضى", value: stats.patients, href: "/patients" },
    { label: "مواعيد اليوم", value: stats.todayAppointments, href: "/appointments" },
    { label: "زيارات اليوم", value: stats.todayVisits, href: "/patients" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold">لوحة التحكم</h1>
        <p className="text-muted text-sm mt-1">
          نظرة سريعة على العيادة اليوم — {ROLE_LABELS[session!.role]}
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {cards.map((c) => (
          <Link
            key={c.label}
            href={c.href}
            className="bg-surface border border-border rounded-xl p-5 hover:border-primary transition-colors"
          >
            <div className="text-3xl font-bold text-primary">{c.value}</div>
            <div className="text-sm text-muted mt-1">{c.label}</div>
          </Link>
        ))}
      </div>

      <div className="bg-surface border border-border rounded-xl p-5">
        <h2 className="font-semibold mb-3">روابط سريعة</h2>
        <div className="flex flex-wrap gap-2">
          <Link href="/patients/new" className="px-3 py-2 rounded-md bg-primary text-white text-sm hover:bg-primary-dark">
            + مريض جديد
          </Link>
          <Link href="/front-desk" className="px-3 py-2 rounded-md border border-border text-sm hover:bg-primary-soft">
            جدول الاستقبال
          </Link>
          <Link href="/appointments" className="px-3 py-2 rounded-md border border-border text-sm hover:bg-primary-soft">
            حجز موعد
          </Link>
          <Link href="/invoices" className="px-3 py-2 rounded-md border border-border text-sm hover:bg-primary-soft">
            الفواتير
          </Link>
        </div>
      </div>
    </div>
  );
}
