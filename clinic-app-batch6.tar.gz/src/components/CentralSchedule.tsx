"use client";

import { useEffect, useMemo, useRef, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { addAppointmentAction, updateAppointmentStatusAction } from "@/app/appointments/actions";

type Room = { id: number; name: string };
type Patient = { id: number; full_name: string; file_number: string };
type Doctor = { id: number; full_name: string };
type Appt = {
  id: number;
  patient_id: number;
  patient_name: string;
  doctor_id: number;
  doctor_name: string;
  room_id: number;
  start_time: string;
  duration_minutes: number | null;
  status: "booked" | "attended" | "done" | "cancelled" | "no_show";
  notes: string | null;
};

const STATUS_LABELS: Record<Appt["status"], string> = {
  booked: "محجوز",
  attended: "حضر",
  done: "تم",
  cancelled: "ملغي",
  no_show: "لم يحضر",
};

function statusClasses(status: Appt["status"]): string {
  switch (status) {
    case "booked":
      return "bg-primary-soft text-primary-dark border-primary/40";
    case "attended":
      return "bg-amber-100 text-amber-900 border-amber-300";
    case "done":
      return "bg-emerald-100 text-emerald-900 border-emerald-300";
    case "no_show":
      return "bg-danger-soft text-danger border-danger/40";
    default:
      return "bg-background text-foreground border-border";
  }
}

type CellPlan = { kind: "empty" } | { kind: "skip" } | { kind: "start"; appt: Appt; span: number };

export default function CentralSchedule({
  date,
  rooms,
  timeSlots,
  slotMinutes,
  appointments,
  patients,
  doctors,
  canEdit = true,
}: {
  date: string;
  rooms: Room[];
  timeSlots: string[];
  slotMinutes: number;
  appointments: Appt[];
  patients: Patient[];
  doctors: Doctor[];
  // لو false، الجدول بيبقى عرض بس — من غير حجز خانة فاضية أو تغيير حالة موعد
  // بالزر اليمين (حسب صلاحية "schedule_edit"). التزامن التلقائي بيفضل شغال زي ما هو.
  canEdit?: boolean;
}) {
  const router = useRouter();
  const [, startTransition] = useTransition();
  const [contextMenu, setContextMenu] = useState<{ apptId: number; x: number; y: number; patientName: string } | null>(null);
  const [bookingModal, setBookingModal] = useState<{ roomId: number; roomName: string; startTime: string } | null>(null);
  const [highlightApptId, setHighlightApptId] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const menuRef = useRef<HTMLDivElement>(null);

  // تزامن الجدول بين أكتر من جهاز/شاشة في الاستقبال — كل 4.5 ثانية، وطالما مفيش
  // مودال حجز أو قايمة يمين مفتوحة (عشان مايقطعش حد وهو بيدخل بيانات)، وطالما
  // التاب ده ظاهر فعليًا (مش تاب تاني مفتوح في الخلفية).
  useEffect(() => {
    const interval = setInterval(() => {
      if (document.visibilityState !== "visible") return;
      if (contextMenu || bookingModal) return;
      router.refresh();
    }, 4500);
    return () => clearInterval(interval);
  }, [router, contextMenu, bookingModal]);

  useEffect(() => {
    if (!contextMenu) return;
    function onClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setContextMenu(null);
    }
    window.addEventListener("click", onClickOutside);
    return () => window.removeEventListener("click", onClickOutside);
  }, [contextMenu]);

  useEffect(() => {
    if (highlightApptId === null) return;
    const t = setTimeout(() => setHighlightApptId(null), 2500);
    return () => clearTimeout(t);
  }, [highlightApptId]);

  const liveAppointments = useMemo(() => appointments.filter((a) => a.status !== "cancelled"), [appointments]);

  // خطة كل خانة لكل غرفة: تبدأ موعد (وبتاخد rowSpan) أو خانة اتغطت بموعد فوقها (skip،
  // ملهاش <td> خالص) أو خانة فاضية قابلة للحجز.
  const plans = useMemo(() => {
    const result: Record<number, CellPlan[]> = {};
    for (const room of rooms) {
      const cells: CellPlan[] = timeSlots.map(() => ({ kind: "empty" }));
      const roomAppts = liveAppointments
        .filter((a) => a.room_id === room.id)
        .sort((a, b) => a.start_time.localeCompare(b.start_time));
      for (const appt of roomAppts) {
        const startIdx = timeSlots.indexOf(appt.start_time);
        if (startIdx === -1) continue;
        const span = Math.max(1, Math.round((appt.duration_minutes || slotMinutes) / slotMinutes));
        cells[startIdx] = { kind: "start", appt, span };
        for (let i = startIdx + 1; i < Math.min(startIdx + span, timeSlots.length); i++) {
          cells[i] = { kind: "skip" };
        }
      }
      result[room.id] = cells;
    }
    return result;
  }, [rooms, timeSlots, liveAppointments, slotMinutes]);

  const apptByPatient = useMemo(() => {
    const map = new Map<number, Appt[]>();
    for (const a of liveAppointments) {
      if (!map.has(a.patient_id)) map.set(a.patient_id, []);
      map.get(a.patient_id)!.push(a);
    }
    return map;
  }, [liveAppointments]);

  const searchResults = useMemo(() => {
    const q = search.trim();
    if (!q) return [];
    return patients
      .filter((p) => p.full_name.includes(q) || p.file_number.includes(q))
      .slice(0, 8);
  }, [search, patients]);

  function jumpToAppointment(apptId: number) {
    setHighlightApptId(apptId);
    setSearch("");
    setTimeout(() => {
      document.getElementById(`appt-cell-${apptId}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 50);
  }

  function submitBooking(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!bookingModal) return;
    const fd = new FormData(e.currentTarget);
    startTransition(() => {
      addAppointmentAction(fd);
    });
    setBookingModal(null);
  }

  function setStatus(id: number, status: string) {
    const fd = new FormData();
    fd.set("id", String(id));
    fd.set("status", status);
    startTransition(() => {
      updateAppointmentStatusAction(fd);
    });
    setContextMenu(null);
  }

  const durationOptions = [1, 2, 3, 4].map((n) => n * slotMinutes);

  return (
    <div className="space-y-3">
      {/* بحث فوري عن مريض */}
      <div className="relative max-w-sm">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="بحث عن مريض بالاسم أو رقم الملف..."
          className="w-full rounded-md border border-border bg-background px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
        {searchResults.length > 0 && (
          <div className="absolute z-20 mt-1 w-full bg-surface border border-border rounded-md shadow-lg overflow-hidden">
            {searchResults.map((p) => {
              const todays = apptByPatient.get(p.id) ?? [];
              return (
                <div key={p.id} className="flex items-center justify-between gap-2 px-3 py-2 text-sm border-b border-border last:border-b-0 hover:bg-primary-soft">
                  <div>
                    <div className="font-medium">{p.full_name}</div>
                    <div className="text-xs text-muted">ملف {p.file_number}</div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    {todays.map((a) => (
                      <button
                        key={a.id}
                        type="button"
                        onClick={() => jumpToAppointment(a.id)}
                        className="text-xs px-2 py-1 rounded-md bg-primary-soft text-primary-dark hover:bg-primary hover:text-white"
                        title="روح لموعده في الجدول"
                      >
                        {a.start_time}
                      </button>
                    ))}
                    <Link
                      href={`/patients/${p.id}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs px-2 py-1 rounded-md border border-border hover:bg-primary-soft whitespace-nowrap"
                    >
                      فتح الملف
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* legend */}
      <div className="flex flex-wrap items-center gap-3 text-xs text-muted">
        {(["booked", "attended", "done", "no_show"] as const).map((s) => (
          <span key={s} className="flex items-center gap-1">
            <span className={`inline-block w-3 h-3 rounded-sm border ${statusClasses(s)}`} />
            {STATUS_LABELS[s]}
          </span>
        ))}
        {canEdit ? (
          <span className="text-muted">دوس على خانة فاضية للحجز، أو دوس بالزر اليمين على موعد لتغيير حالته.</span>
        ) : (
          <span className="text-muted">عرض فقط — التعديل في الجدول (حجز/تغيير حالة) مقصور على الاستقبال.</span>
        )}
      </div>

      {/* central grid */}
      <div className="bg-surface border border-border rounded-xl overflow-auto max-h-[70vh]">
        <table className="w-full text-xs border-collapse">
          <thead className="sticky top-0 z-10">
            <tr className="bg-primary-soft text-primary-dark">
              <th className="sticky right-0 z-20 bg-primary-soft px-2 py-2 font-medium whitespace-nowrap">الوقت</th>
              {rooms.map((r) => (
                <th key={r.id} className="px-2 py-2 font-medium whitespace-nowrap min-w-[140px]">
                  {r.name}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {timeSlots.map((time, rowIdx) => (
              <tr key={time}>
                <td className="sticky right-0 bg-surface z-10 px-2 py-1 text-muted whitespace-nowrap border-e border-border">{time}</td>
                {rooms.map((room) => {
                  const plan = plans[room.id]?.[rowIdx] ?? { kind: "empty" as const };
                  if (plan.kind === "skip") return null;
                  if (plan.kind === "start") {
                    const appt = plan.appt;
                    const highlighted = highlightApptId === appt.id;
                    return (
                      <td
                        key={room.id}
                        id={`appt-cell-${appt.id}`}
                        rowSpan={plan.span}
                        onContextMenu={(e) => {
                          if (!canEdit) return;
                          e.preventDefault();
                          setContextMenu({ apptId: appt.id, x: e.clientX, y: e.clientY, patientName: appt.patient_name });
                        }}
                        className={`align-top p-1.5 border ${statusClasses(appt.status)} transition-shadow ${
                          canEdit ? "cursor-context-menu" : "cursor-default"
                        } ${highlighted ? "ring-2 ring-primary ring-offset-1" : ""}`}
                      >
                        <div className="font-semibold truncate">{appt.patient_name}</div>
                        <div className="text-[10px] truncate">{appt.doctor_name}</div>
                        <div className="text-[10px] opacity-80">{STATUS_LABELS[appt.status]}</div>
                        {appt.notes && <div className="text-[10px] opacity-70 truncate">{appt.notes}</div>}
                      </td>
                    );
                  }
                  return (
                    <td
                      key={room.id}
                      onClick={canEdit ? () => setBookingModal({ roomId: room.id, roomName: room.name, startTime: time }) : undefined}
                      className={`border border-border h-7 ${canEdit ? "cursor-pointer hover:bg-primary-soft/50" : ""}`}
                      title={canEdit ? "دوس للحجز" : undefined}
                    />
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* right-click context menu */}
      {contextMenu && (
        <div
          ref={menuRef}
          style={{ position: "fixed", top: contextMenu.y, left: contextMenu.x }}
          className="z-50 bg-surface border border-border rounded-md shadow-lg py-1 text-sm min-w-[140px]"
        >
          <div className="px-3 py-1.5 text-xs text-muted border-b border-border truncate">{contextMenu.patientName}</div>
          <button type="button" onClick={() => setStatus(contextMenu.apptId, "attended")} className="w-full text-right px-3 py-1.5 hover:bg-primary-soft">
            حضر
          </button>
          <button type="button" onClick={() => setStatus(contextMenu.apptId, "done")} className="w-full text-right px-3 py-1.5 hover:bg-primary-soft">
            تم
          </button>
          <button
            type="button"
            onClick={() => setStatus(contextMenu.apptId, "cancelled")}
            className="w-full text-right px-3 py-1.5 hover:bg-danger-soft text-danger"
          >
            إلغاء (تفضية الخانة)
          </button>
        </div>
      )}

      {/* booking modal */}
      {bookingModal && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => setBookingModal(null)}>
          <form
            onClick={(e) => e.stopPropagation()}
            onSubmit={submitBooking}
            className="bg-surface border border-border rounded-xl p-5 w-full max-w-sm space-y-3"
          >
            <h3 className="font-semibold">
              حجز — {bookingModal.roomName} · {bookingModal.startTime}
            </h3>
            <input type="hidden" name="appointment_date" value={date} />
            <input type="hidden" name="room_id" value={bookingModal.roomId} />
            <input type="hidden" name="start_time" value={bookingModal.startTime} />

            <div>
              <label className="block text-xs text-muted mb-1">المريض</label>
              <select name="patient_id" required autoFocus className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm">
                <option value="">اختر مريض</option>
                {patients.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.full_name} ({p.file_number})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-muted mb-1">الدكتور</label>
              <select name="doctor_id" required className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm">
                <option value="">اختر دكتور</option>
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.full_name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-muted mb-1">المدة</label>
              <select name="duration_minutes" defaultValue={slotMinutes} className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm">
                {durationOptions.map((m) => (
                  <option key={m} value={m}>
                    {m} دقيقة
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-muted mb-1">ملاحظات (اختياري)</label>
              <input name="notes" className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
            </div>

            <div className="flex gap-2 justify-end pt-1">
              <button type="button" onClick={() => setBookingModal(null)} className="px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft">
                إلغاء
              </button>
              <button type="submit" className="px-3 py-1.5 rounded-md bg-primary text-white text-sm font-medium hover:bg-primary-dark">
                + حجز
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
