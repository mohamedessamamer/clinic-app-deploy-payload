import type { Role } from "./auth";

// ثوابت الصلاحيات فقط — من غير أي استيراد لطبقة قاعدة البيانات، عشان يصلح
// للاستخدام في مكونات العميل (client components) زي PermissionsManager كمان.
// الدوال اللي بتلمس قاعدة البيانات (getPermissionOverrides..) موجودة في lib/permissions.ts.
export const PERMISSION_GROUPS = [
  { key: "appointments", label: "الاستقبال والمواعيد" },
  { key: "medical", label: "الصلاحيات الطبية" },
  { key: "financial", label: "الصلاحيات المالية" },
  { key: "reports", label: "التقارير" },
  { key: "inventory", label: "صلاحيات المخزن" },
  { key: "whatsapp_manual", label: "واتساب يدوي" },
  { key: "whatsapp_meta", label: "Meta WhatsApp API" },
  { key: "administration", label: "الإدارة والتواصل" },
] as const;

// دفعة 143: عناوين فرعية جوه مجموعة "التقارير". كل صلاحية تقرير ليها
// `subgroup`، وصلاحية "الإجماليات" بتاعتها ليها `totalsOf` = مفتاح التقرير —
// شاشة الصلاحيات بتعرضها جنبه. `settingOf` = إعداد تابع للتقرير.
export const REPORT_SUBGROUPS = [
  { key: "financial_reports", label: "تقارير مالية" },
  { key: "patient_reports", label: "تقارير المرضى" },
  { key: "system_reports", label: "تقارير النظام" },
] as const;

export const PERMISSION_DEFS = [
  { key: "schedule_all_rooms", group: "appointments", title: "عرض كل العيادات", description: "يعرض الجدول المركزي لكل الغرف بدل شيفت المستخدم فقط." },
  { key: "schedule_edit", group: "appointments", title: "تعديل المواعيد", description: "حجز موعد وتغيير حالته من الجدول المركزي." },
  { key: "mark_appointment_done", group: "appointments", title: "إنهاء الموعد", description: "يسمح للطبيب بتحديد مواعيده اليوم كحالة تم، بعيدًا عن التحصيل." },
  { key: "view_needs_treatment_reminder", group: "appointments", title: "تنبيه المعالجة الناقصة", description: "يعرض تنبيه الموعد الذي تم بدون تسجيل المعالجة." },
  { key: "create_collection_requests_all_doctors", group: "appointments", title: "طلبات تحصيل كل الأطباء", description: "يسجل طلب التحصيل نيابة عن أي طبيب مع حفظ اسم طبيب الموعد." },
  { key: "view_whatsapp_reminder_report", group: "appointments", title: "متابعة تأكيد المواعيد", description: "يعرض ردود تذكير المواعيد ويعتمد طلبات التعديل." },

  { key: "view_patients_list", group: "medical", title: "قائمة المرضى", description: "يعرض قائمة المرضى للطبيب، وليس مرضى مواعيده فقط." },
  { key: "view_patient_personal_data", group: "medical", title: "البيانات الشخصية", description: "يعرض السن والهاتف وتاريخ الميلاد والعنوان." },
  { key: "edit_patient_info", group: "medical", title: "تعديل بيانات المريض", description: "تعديل الاسم والميلاد والهاتف والعنوان." },
  { key: "override_visit_doctor", group: "medical", title: "اختيار طبيب مساعد", description: "يحدد مقدم خدمة مختلف بدون تغيير صاحب التحصيل." },
  { key: "edit_old_visits", group: "medical", title: "تعديل الزيارات القديمة", description: "يعدل زيارات الملف الطبي بعد انتهاء مهلة الثلاثة أيام." },
  { key: "edit_visit_assistant_doctor", group: "medical", title: "تعديل الطبيب المساعد", description: "يعدل الطبيب المساعد في زيارة محفوظة فقط." },
  { key: "edit_ortho_visit_after_save", group: "medical", title: "تعديل زيارات التقويم القديمة", description: "يفعّل زر Edit للزيارات المحفوظة في شارت التقويم." },
  { key: "upload_ortho_photos", group: "medical", title: "صور وأشعة التقويم", description: "رفع وتدوير وحذف صور التقويم بدون صلاحية تعديل الشارت كاملًا." },
  { key: "view_patient_files", group: "medical", title: "عرض ملفات المرضى", description: "يعرض الصور والأشعة والملفات الطبية المرفوعة." },
  { key: "delete_visits", group: "medical", title: "حذف الزيارات", description: "يحذف الزيارة وفاتورتها نهائيًا لتصحيح الإدخال الخاطئ." },
  { key: "manage_ortho_chart_options", group: "medical", title: "قوائم ملخص شارت التقويم", description: "يعدل خيارات Chief complaint وTreatment وDiagnosis في إعدادات شارت التقويم." },

  { key: "collect_payments", group: "financial", title: "تحصيل المدفوعات", description: "يسجل التحصيل من شاشة الاستقبال." },
  { key: "view_patient_billing", group: "financial", title: "الملف المالي للمريض", description: "يعرض فواتير ومدفوعات المريض وإضافة خدمة مالية." },
  { key: "edit_invoice_payments", group: "financial", title: "تصحيح الفواتير", description: "يعدل السعر أو المدفوع ويسمح بالتسجيل بتاريخ قديم." },
  { key: "edit_patient_billing_entry", group: "financial", title: "تعديل صف الملف المالي", description: "يعدل خدمة/دفعة مسجلة في الملف المالي للمريض (المبلغ والخصم وطريقة الدفع والدكتور والتاريخ والخدمة المرتبطة) بدل حذفها وإعادة تسجيلها." },
  { key: "view_invoice_totals", group: "financial", title: "إجماليات الفواتير", description: "يعرض إجمالي الفواتير والمحصّل والمتبقي." },
  { key: "manage_expenses", group: "financial", title: "المصروفات والمرتبات", description: "إدارة المصروفات وكشوف رواتب الأطباء." },
  { key: "manage_hr", group: "financial", title: "إدارة HR وقواعد الرواتب", description: "تعريف الرواتب الثابتة والشيفتات والنسب الثابتة أو التصاعدية للأطباء والموظفين والتمريض." },
  { key: "clear_expenses_data", group: "financial", title: "مسح كل بيانات المصروفات", description: "حذف كل المصروفات وكشوف رواتب HR والبنود المتكررة نهائيًا من شاشة المصروفات. للأدمن فقط، ولا يمكن التراجع عنه." },
  { key: "view_payroll_commission_base", group: "financial", title: "عرض وعاء النسبة في كشف الرواتب", description: "إظهار عمود «صافي التحصيل» (وعاء حساب النسبة) في كشف الرواتب. باقي الكشف يظهر لأي حساب له صلاحية المصروفات." },

  { key: "manage_inventory", group: "inventory", title: "استخدام المخزن", description: "فتح المخزن وتسجيل الجرد والتوريدات." },
  { key: "edit_inventory_catalog", group: "inventory", title: "تعديل كتالوج المخزن", description: "إضافة وتعديل الأصناف والتخصصات وإعداداتها." },
  { key: "delete_inventory_records", group: "inventory", title: "حذف بيانات المخزن", description: "يحذف أو يلغي بيانات المخزن المسجلة بالخطأ." },
  { key: "toggle_inventory_deductions", group: "inventory", title: "تشغيل وإيقاف خصم المخزن", description: "يتحكم في المفتاح العام لخصم المستهلكات من كل المخزن بعد رسالة تأكيد." },
  { key: "undo_ortho_inventory_deduction", group: "inventory", title: "إلغاء خصم التقويم", description: "يلغي خصمًا مسجلًا من Inventory list في شارت التقويم." },
  { key: "receive_low_stock_alerts", group: "inventory", title: "استقبال تنبيهات نقص المخزون", description: "يصل لصاحب الصلاحية إشعار عند وصول أي صنف لحد الطلب أو الحد الحرج." },
  { key: "manage_suppliers", group: "inventory", title: "إدارة الموردين", description: "إضافة وتعديل الموردين من المخزن، وتسجيل فواتيرهم ودفعاتهم من شاشة الموردين تحت المصروفات." },

  { key: "whatsapp_manual_send", group: "whatsapp_manual", title: "إرسال رسائل يدوية", description: "يفتح واتساب لإرسال القوالب اليدوية للمستلمين." },
  { key: "whatsapp_manual_templates", group: "whatsapp_manual", title: "إدارة القوالب اليدوية", description: "ينشئ ويعدل القوالب والفئات والمتغيرات والخمس رسائل السريعة." },
  { key: "whatsapp_bulk_send", group: "whatsapp_manual", title: "إرسال جماعي", description: "يجهز أو يرسل رسائل مجموعة مرضى لفترة محددة." },
  { key: "whatsapp_automation", group: "whatsapp_meta", title: "قواعد الإرسال التلقائي", description: "ينشئ ويعدل قواعد إرسال قوالب Meta تلقائيًا." },

  { key: "whatsapp_meta_connection", group: "whatsapp_meta", title: "اتصال Meta", description: "يعرض ويربط حساب ورقم WhatsApp Cloud API." },
  { key: "whatsapp_meta_conversations", group: "whatsapp_meta", title: "محادثات Meta", description: "يعرض المحادثات ويرسل منها." },
  { key: "whatsapp_meta_templates", group: "whatsapp_meta", title: "إنشاء قوالب Meta", description: "ينشئ قوالب رسمية لإرسالها إلى Meta." },
  { key: "whatsapp_meta_sync", group: "whatsapp_meta", title: "مزامنة قوالب Meta", description: "يحدث الحالات ويحذف محليًا ما حُذف من Meta." },

  { key: "manage_settings", group: "administration", title: "صفحة الإعدادات", description: "يسمح بالدخول إلى إعدادات النظام." },
  { key: "view_home_dashboard", group: "administration", title: "عرض الشاشة الرئيسية", description: "يعرض لوحة الرئيسية وملخص اليوم وحالة العيادات." },
  { key: "view_home_daily_totals", group: "administration", title: "إجمالي اليوم في الرئيسية", description: "يعرض بطاقتي إجمالي مواعيد اليوم وزيارات مكتملة في الشاشة الرئيسية." },
  { key: "send_staff_chat_to_doctors", group: "administration", title: "مراسلة الأطباء", description: "يسمح للطبيب بإرسال رسالة لطبيب أو لكل الأطباء." },
  { key: "manage_whatsapp", group: "administration", title: "واتساب", description: "ربط حساب واتساب وعرض/إرسال الرسائل وإدارة القوالب." },

  // ---- التقارير (دفعة 143) ----
  // تقارير مالية. reports_full/reports_own أساميهم القديمة اتسابت زي ما هي
  // (مستخدمين في صفحة الفواتير والرئيسية) — اللي اتغير العنوان والمكان بس.
  { key: "reports_full", group: "reports", subgroup: "financial_reports", title: "إيرادات كل الأطباء", description: "تقرير الإيرادات لكل الأطباء والخدمات وأي فترة." },
  { key: "reports_own", group: "reports", subgroup: "financial_reports", title: "إيراداتي فقط", description: "الطبيب يشوف إيراداته هو بس، بكلمة السر وبالحد الزمني المحدد. إجمالياته بصلاحية «إجماليات الإيرادات»." },
  { key: "view_revenue_totals", group: "reports", subgroup: "financial_reports", totalsOf: "reports_full", title: "إجماليات الإيرادات", description: "كروت إجمالي الفترة (الفواتير الجديدة، المحصّل، عدد الزيارات)، إجمالي كل طريقة دفع، صافي الفترة، وسطر المجموع. من غيرها: جدول الأيام والأطباء والخدمات بس." },
  { key: "view_expenses_report", group: "reports", subgroup: "financial_reports", title: "المصروفات", description: "تفاصيل مصروفات الفترة: الرواتب، الموردين، النثريات. بيستخدم فلتر فترة تقرير الإيرادات." },
  { key: "view_expenses_totals", group: "reports", subgroup: "financial_reports", totalsOf: "view_expenses_report", title: "إجماليات المصروفات", description: "إجمالي المصروفات وصافي الفترة وسطر المجموع." },
  { key: "view_statistics_reports", group: "reports", subgroup: "financial_reports", title: "الإحصائيات", description: "مقارنة الفترات ببعضها، الاتجاه عبر السنين، وموسمية الشهور." },
  { key: "view_statistics_totals", group: "reports", subgroup: "financial_reports", totalsOf: "view_statistics_reports", title: "إجماليات الإحصائيات", description: "قسم «الملخص»: المتوسطات وترتيب الفترات." },
  { key: "view_unpaid_report", group: "reports", subgroup: "financial_reports", title: "تم بدون دفع", description: "المواعيد اللي اتقفلت من غير تحصيل ومديونية كل واحد." },
  { key: "view_unpaid_totals", group: "reports", subgroup: "financial_reports", totalsOf: "view_unpaid_report", title: "إجماليات تم بدون دفع", description: "عدد الحالات ومجموع المديونية." },
  // تقارير المرضى — كل تقرير بصلاحية (كانوا تحت view_patient_reports واحدة).
  { key: "view_ortho_late_report", group: "reports", subgroup: "patient_reports", title: "متابعة تقويم متأخرة", description: "مرضى التقويم المتأخرين عن المتابعة." },
  { key: "view_ortho_late_totals", group: "reports", subgroup: "patient_reports", totalsOf: "view_ortho_late_report", title: "إجماليات متابعة التقويم", description: "كروت أعداد المتأخرين والمراحل واللي خلّصوا والموقوف علاجهم." },
  { key: "configure_followup_thresholds", group: "reports", subgroup: "patient_reports", settingOf: "view_ortho_late_report", title: "تعديل مدد المتابعة", description: "يغير حدود المرحلة الأولى والتانية في تقرير متابعة التقويم." },
  { key: "stop_ortho_treatment", group: "reports", subgroup: "patient_reports", settingOf: "view_ortho_late_report", title: "إيقاف العلاج", description: "زرار إيقاف العلاج جنب المريض في التقرير (بسبب اختياري)، وإلغاء الإيقاف من تقرير إيقاف العلاج. الإيقاف بيتشال لوحده لو المريض رجع." },
  { key: "view_referrals_report", group: "reports", subgroup: "patient_reports", title: "التحويلات", description: "التحويلات الطبية بين الأطباء وحالتها." },
  { key: "view_duration_report", group: "reports", subgroup: "patient_reports", title: "مدة المريض في العيادة", description: "مدة انتظار ومدة جلسة كل مريض." },
  { key: "view_duration_totals", group: "reports", subgroup: "patient_reports", totalsOf: "view_duration_report", title: "إجماليات مدة المريض", description: "المتوسطات والأعداد." },
  { key: "view_incomplete_checkups_report", group: "reports", subgroup: "patient_reports", title: "الكشوفات غير المكتملة", description: "مرضى كشفوا ومكملوش علاج." },
  { key: "view_incomplete_checkups_totals", group: "reports", subgroup: "patient_reports", totalsOf: "view_incomplete_checkups_report", title: "إجماليات الكشوفات", description: "العدد الإجمالي." },
  { key: "view_patient_debts_report", group: "reports", subgroup: "patient_reports", title: "مديونيات المرضى", description: "كل مريض ومديونيته وتاريخ أقدم مديونية، وتذكير واتساب مباشر." },
  { key: "view_patient_debts_totals", group: "reports", subgroup: "patient_reports", totalsOf: "view_patient_debts_report", title: "إجماليات المديونيات", description: "إجمالي المديونية وعدد المرضى المديونين، وكارت المديونيات المجمدة." },
  { key: "freeze_patient_debt", group: "reports", subgroup: "patient_reports", settingOf: "view_patient_debts_report", title: "تجميد المديونية", description: "زرار تجميد جنب المريض في المديونيات، وفك التجميد من تقرير المديونيات المجمدة. التجميد بيتفك لوحده لو اتعملت فاتورة جديدة أو موعد حضر/تم." },
  { key: "settle_patient_debt", group: "reports", subgroup: "patient_reports", settingOf: "view_patient_debts_report", title: "تسوية المديونية", description: "يقفل الباقي على المريض من غير تحصيل (الإيرادات والتحصيل مابيتغيروش)، ويلغي التسوية من تقرير التسويات. للأدمن." },
  { key: "view_frozen_debts_report", group: "reports", subgroup: "patient_reports", title: "مديونيات مجمدة", description: "المرضى المجمدة مديونيتهم (يدوي أو بسبب إيقاف علاج): المبلغ والتاريخ والسبب." },
  { key: "view_frozen_debts_totals", group: "reports", subgroup: "patient_reports", totalsOf: "view_frozen_debts_report", title: "إجماليات المديونيات المجمدة", description: "عدد المرضى ومجموع المديونية المجمدة." },
  { key: "view_debt_settlements_report", group: "reports", subgroup: "patient_reports", title: "تسويات المديونية", description: "التسويات الفعّالة: المريض والمبلغ والتاريخ والسبب ومين عملها." },
  { key: "view_debt_settlements_totals", group: "reports", subgroup: "patient_reports", totalsOf: "view_debt_settlements_report", title: "إجماليات التسويات", description: "عدد التسويات ومجموعها." },
  { key: "view_stopped_treatment_report", group: "reports", subgroup: "patient_reports", title: "إيقاف العلاج", description: "مرضى التقويم الموقوف علاجهم حاليًا: تاريخ الإيقاف والسبب ومين وقّف." },
  { key: "view_stopped_treatment_totals", group: "reports", subgroup: "patient_reports", totalsOf: "view_stopped_treatment_report", title: "إجماليات إيقاف العلاج", description: "عدد الموقوفين والعدد لكل سبب." },
  { key: "view_patient_review_report", group: "reports", subgroup: "patient_reports", title: "تقييمات المرضى", description: "تقييمات المرضى وتعليقاتهم." },
  { key: "view_patient_review_totals", group: "reports", subgroup: "patient_reports", totalsOf: "view_patient_review_report", title: "إجماليات التقييمات", description: "متوسط التقييم." },
  { key: "configure_google_review_link", group: "reports", subgroup: "patient_reports", settingOf: "view_patient_review_report", title: "رابط تقييم جوجل", description: "يعدل رابط تقييم جوجل اللي بيتبعت للمرضى." },
  // تقارير النظام
  { key: "view_system_log", group: "reports", subgroup: "system_reports", title: "سجل النظام", description: "كل ما يحدث في النظام: من عدّل أو حذف ماذا ومتى، بفترة تاريخية." },
] as const;

export type PermissionKey = (typeof PERMISSION_DEFS)[number]["key"];

// دفعة 143: الصلاحيات اللي حلّت محل view_patient_reports (التقارير الأربعة +
// إجمالياتهم) واللي اتفصلت من view_whatsapp_reminder_report ("تم بدون دفع").
// دفعة 145: "إجماليات تم بدون دفع" و"إجماليات الكشوفات" اتشالوا من الافتراضي —
// الإجماليات دي اتضافت جديدة في 143 (ماكانتش موجودة قبلها)، فمكانش المفروض
// تتفتح لحد غير الأدمن من غير ما يتمنحها. شوف migration 145 في db/client.ts.
const PATIENT_REPORT_KEYS: PermissionKey[] = [
  "view_ortho_late_report", "view_ortho_late_totals", "view_referrals_report",
  "view_duration_report", "view_duration_totals", "view_incomplete_checkups_report",
];
const UNPAID_REPORT_KEYS: PermissionKey[] = ["view_unpaid_report"];

// دفعة 143: التحويل من الصلاحيات القديمة للجديدة — كل مستخدم ياخد نفس اللي
// بيشوفه قبل النشر بالظبط. `has` = هل المستخدم كان معاه الصلاحية القديمة
// (افتراضي الدور القديم + أي استثناء عنده). بيستخدمها migration 143 في db/client.ts.
export const LEGACY_VIEW_PATIENT_REPORTS_ROLES: Role[] = ["admin", "clinic_manager", "reception"];
export function deriveReportPermissions(has: (key: string) => boolean): Partial<Record<PermissionKey, boolean>> {
  const revenue = has("reports_full") || has("reports_own");
  const expenses = has("reports_full") && has("manage_expenses");
  const patient = has("view_patient_reports");
  const unpaid = has("view_whatsapp_reminder_report");
  return {
    view_revenue_totals: revenue,
    view_expenses_report: expenses,
    view_expenses_totals: expenses,
    view_statistics_totals: has("view_statistics_reports"),
    view_unpaid_report: unpaid,
    view_unpaid_totals: false, // دفعة 145: جديدة في 143، مش افتراضية لحد.
    view_ortho_late_report: patient,
    view_ortho_late_totals: patient,
    view_referrals_report: patient,
    view_duration_report: patient,
    view_duration_totals: patient,
    view_incomplete_checkups_report: patient,
    view_incomplete_checkups_totals: false, // دفعة 145: جديدة في 143، مش افتراضية لحد.
    view_patient_debts_totals: has("view_patient_debts_report"),
    view_patient_review_totals: has("view_patient_review_report"),
    configure_google_review_link: has("manage_settings"),
  };
}

export const ROLE_DEFAULT_PERMISSIONS: Record<Role, PermissionKey[]> = {
  admin: [
    "view_system_log",
    "reports_full",
    "collect_payments",
    "manage_inventory",
    "edit_inventory_catalog",
    "delete_inventory_records",
    "manage_suppliers",
    "manage_expenses",
    "manage_hr",
    "clear_expenses_data",
    "view_payroll_commission_base",
    "view_statistics_reports",
    "manage_settings",
    "view_home_dashboard",
    "view_home_daily_totals",
    "schedule_all_rooms",
    "schedule_edit",
    "override_visit_doctor",
    "edit_old_visits",
    "edit_invoice_payments",
    "edit_patient_billing_entry",
    "delete_visits",
    "edit_patient_info",
    "edit_visit_assistant_doctor",
    "edit_ortho_visit_after_save",
    "view_patient_files",
    "undo_ortho_inventory_deduction",
    "manage_whatsapp",
    "view_whatsapp_reminder_report",
    "view_patient_debts_report",
    "view_patient_debts_totals",
    "configure_followup_thresholds",
    "view_patient_review_report",
    "view_patient_review_totals",
    "freeze_patient_debt",
    "settle_patient_debt",
    "view_frozen_debts_report",
    "view_frozen_debts_totals",
    "view_debt_settlements_report",
    "view_debt_settlements_totals",
    "stop_ortho_treatment",
    "view_stopped_treatment_report",
    "view_stopped_treatment_totals",
    "configure_google_review_link",
    "view_revenue_totals",
    "view_expenses_report",
    "view_expenses_totals",
    "view_statistics_totals",
    ...PATIENT_REPORT_KEYS,
    ...UNPAID_REPORT_KEYS,
    "whatsapp_manual_send",
    "whatsapp_manual_templates",
    "whatsapp_bulk_send",
    "whatsapp_automation",
    "whatsapp_meta_connection",
    "whatsapp_meta_conversations",
    "whatsapp_meta_templates",
    "whatsapp_meta_sync",
    "view_unpaid_totals",
    "view_incomplete_checkups_totals",
  ],
  clinic_manager: [
    "reports_full",
    "manage_inventory",
    "schedule_all_rooms",
    "override_visit_doctor",
    "edit_old_visits",
    "edit_invoice_payments",
    "edit_visit_assistant_doctor",
    "view_patient_files",
    "view_whatsapp_reminder_report",
    ...UNPAID_REPORT_KEYS,
    ...PATIENT_REPORT_KEYS,
    "view_revenue_totals",
  ],
  accountant: [
    "reports_full",
    "view_revenue_totals",
    "view_expenses_report",
    "view_expenses_totals",
    "collect_payments",
    "manage_expenses",
    "manage_hr",
    "edit_invoice_payments",
  ],
  // manage_inventory ضمن الافتراضي هنا عشان الاستقبال كان عنده وصول للمخزون
  // أصلاً (رابط ثابت في القائمة قبل ما يبقى صلاحية) — عشان التحويل للنظام
  // الجديد ميقفلش حاجة كانت شغالة بالفعل. لسه ممكن تُسحب من مستخدم استقبال
  // معيّن من الإعدادات لو حابب.
  reception: [
    "collect_payments",
    "schedule_all_rooms",
    "schedule_edit",
    "manage_inventory",
    "edit_patient_info",
    "view_patient_personal_data",
    "edit_visit_assistant_doctor",
    "upload_ortho_photos",
    "view_patient_files",
    "view_whatsapp_reminder_report",
    ...UNPAID_REPORT_KEYS,
    ...PATIENT_REPORT_KEYS,
    "whatsapp_manual_send",
    "whatsapp_bulk_send",
  ],
  // الدكتور افتراضيًا يشوف الجدول المركزي لشيفته/غرفته بس النهاردة، وبشكل عرض فقط
  // (من غير حجز أو تغيير حالة) — الأدمن يقدر يوسّع الصلاحيات دي لدكتور معيّن من
  // صفحة الإعدادات لو حابب (schedule_all_rooms و/أو schedule_edit).
  doctor: ["reports_own", "view_revenue_totals", "view_needs_treatment_reminder", "mark_appointment_done", "view_patient_files"],
};
