import "server-only";

import { db } from "@/lib/db/client";
import { getActiveOrthoStops } from "@/lib/ortho-treatment-stops";

// دفعة 145 — تجميد المديونية (على المريض كله).
//
// المريض مديونيته مجمدة لو:
//   1) علاجه موقوف حاليًا (إيقاف العلاج من تقرير المتأخرين) — تلقائي، والسبب
//      والتاريخ ومين عمله بييجوا من الإيقاف نفسه. بيتفك مع الإيقاف.
//   2) أو عنده تجميد يدوي فعّال: آخر صف ليه في debt_freezes، مااتفكش يدوي
//      (cleared_at فاضي)، ومفيش بعد تاريخ التجميد:
//        - أي فاتورة/دفعة جديدة (invoice_date أكبر من تاريخ التجميد)
//        - أو موعد حالته حضر/تم (الحجز لوحده أو الإلغاء أو "ماجاش" مش بيفك).
// الحساب بيحصل وقت العرض — مفيش حاجة بتتكتب في الداتابيز وقت الرجوع.

export type FrozenDebtInfo = {
  kind: "stop" | "manual";
  since: string;
  reason: string | null;
  byName: string | null;
  /** رقم صف التجميد اليدوي (للفك اليدوي) — null لو التجميد جاي من إيقاف العلاج. */
  freezeId: number | null;
};

export async function getFrozenPatients(): Promise<Map<number, FrozenDebtInfo>> {
  const [stops, freezes] = await Promise.all([
    getActiveOrthoStops(),
    db.selectFrom("debt_freezes")
      .leftJoin("users", "users.id", "debt_freezes.frozen_by")
      .select(["debt_freezes.id", "debt_freezes.patient_id", "debt_freezes.frozen_date", "debt_freezes.reason", "debt_freezes.cleared_at", "users.full_name as by_name"])
      .orderBy("debt_freezes.id", "asc")
      .execute(),
  ]);

  const frozen = new Map<number, FrozenDebtInfo>();

  const latest = new Map<number, (typeof freezes)[number]>();
  for (const row of freezes) latest.set(row.patient_id, row);
  const manual = [...latest.values()].filter((row) => row.cleared_at == null);
  if (manual.length) {
    const ids = manual.map((row) => row.patient_id);
    const [invoices, appointments] = await Promise.all([
      db.selectFrom("invoices").select(["patient_id", (eb) => eb.fn.max("invoice_date").as("last")]).where("patient_id", "in", ids).groupBy("patient_id").execute(),
      db.selectFrom("appointments").select(["patient_id", (eb) => eb.fn.max("appointment_date").as("last")])
        .where("patient_id", "in", ids).where("status", "in", ["attended", "done"]).groupBy("patient_id").execute(),
    ]);
    const lastActivity = new Map<number, string>();
    for (const row of [...invoices, ...appointments]) {
      if (row.patient_id == null || !row.last) continue;
      const day = String(row.last).slice(0, 10);
      if (!lastActivity.has(row.patient_id) || day > lastActivity.get(row.patient_id)!) lastActivity.set(row.patient_id, day);
    }
    for (const row of manual) {
      const returned = lastActivity.get(row.patient_id);
      if (returned && returned > row.frozen_date) continue;
      frozen.set(row.patient_id, { kind: "manual", since: row.frozen_date, reason: row.reason, byName: row.by_name, freezeId: row.id });
    }
  }

  // إيقاف العلاج له الأولوية في العرض (سببه وتاريخه)؛ التجميد اليدوي بيفضل
  // محفوظ تحته لو الإيقاف اتشال والمريض لسه مارجعش.
  for (const stop of stops.values()) {
    frozen.set(stop.patientId, { kind: "stop", since: stop.stoppedDate, reason: stop.reason, byName: stop.stoppedByName, freezeId: null });
  }
  return frozen;
}

export type PatientDebt = {
  patientId: number;
  debt: number;
  invoices: { id: number; balance: number }[];
};

/**
 * مديونية كل مريض بعد دفعات المتابعة والتسويات: لكل فاتورة أصلية
 * الباقي = amount - paid - مجموع دفعات المتابعة - settled_amount (لو موجب).
 */
export async function getPatientDebts(patientIds?: number[]): Promise<Map<number, PatientDebt>> {
  if (patientIds && !patientIds.length) return new Map();
  let rootsQuery = db.selectFrom("invoices")
    .select(["id", "patient_id", "amount", "paid", "settled_amount"])
    .where("parent_invoice_id", "is", null);
  let followupsQuery = db.selectFrom("invoices")
    .select(["parent_invoice_id", "paid"])
    .where("parent_invoice_id", "is not", null);
  if (patientIds) {
    rootsQuery = rootsQuery.where("patient_id", "in", patientIds);
    followupsQuery = followupsQuery.where("patient_id", "in", patientIds);
  }
  const [roots, followups] = await Promise.all([rootsQuery.execute(), followupsQuery.execute()]);
  const followupPaid = new Map<number, number>();
  for (const row of followups) {
    if (row.parent_invoice_id == null) continue;
    followupPaid.set(row.parent_invoice_id, (followupPaid.get(row.parent_invoice_id) ?? 0) + row.paid);
  }
  const result = new Map<number, PatientDebt>();
  for (const invoice of roots) {
    if (invoice.patient_id == null) continue;
    const balance = Math.round((invoice.amount - invoice.paid - (followupPaid.get(invoice.id) ?? 0) - (invoice.settled_amount ?? 0)) * 100) / 100;
    if (balance <= 0.01) continue;
    const entry = result.get(invoice.patient_id) ?? { patientId: invoice.patient_id, debt: 0, invoices: [] };
    entry.debt = Math.round((entry.debt + balance) * 100) / 100;
    entry.invoices.push({ id: invoice.id, balance });
    result.set(invoice.patient_id, entry);
  }
  return result;
}
