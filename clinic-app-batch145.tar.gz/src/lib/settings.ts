import { db } from "./db/client";

export const SETTINGS_DEFAULTS = {
  slot_minutes: "15", // وحدة الزمن الافتراضية للعيادة (طول فترة الموعد بالدقايق)
  day_start: "09:00",
  day_end: "22:00",
  // أرقام أيام الأسبوع اللي العيادة إجازة فيها، مفصولة بفاصلة (0=الأحد ... 6=السبت).
  holiday_weekdays: "",
  // أقصى عدد أيام رجوع بالتاريخ يقدر الدكتور (غير صاحب الصلاحية الكاملة) يشوف تقريره الشخصي فيها.
  // قابل للتغيير من "إعدادات الصلاحيات" بدل ما يكون رقم ثابت بالكود.
  doctor_report_max_days: "60",
  // إعدادات مركز الإشعارات قابلة للتعديل من لوحة الإعدادات، وليست أرقامًا ثابتة.
  notification_ortho_stages_days: "40,60,90",
  notification_ortho_final_repeat_days: "7",
  notification_photo_days: "180",
  notification_retention_hours: "48",
  chat_retention_hours: "48",
  // مكتبة أصوات الشات: soft_chime / gentle_bell / water_drop / off.
  chat_notification_sound: "gentle_bell",
  // عدد بطاقات المواعيد الظاهرة في الرئيسية؛ الأدمن يضبطه من الإشعارات والشات.
  home_dashboard_appointment_limit: "3",
  whatsapp_reminder_time: "18:00",
  whatsapp_reminder_valid_hours: "3",
  whatsapp_reminder_template_name: "appointment_reminder",
  whatsapp_confirmation_template_name: "appointment_reschedule_confirmed",
  whatsapp_template_language: "ar",
  ortho_followup_first_days: "45",
  ortho_followup_second_days: "90",
  clinic_public_url: "https://clinicsys.revereeg.com",
  google_review_url: "",
  // Batch 111 starts paused until the first physical stocktake is complete.
  inventory_deductions_enabled: "0",
  // قوائم الملخص السريع في شارت التقويم. تظل فارغة عند أول تشغيل؛ تُخزّن
  // كـJSON arrays كي يبقى ترتيب العناصر هو ترتيب كتابتها في الإعدادات.
  ortho_chart_chief_complaint_options: "[]",
  ortho_chart_treatment_options: "[]",
  ortho_chart_diagnosis_options: "[]",
  // Batch 124: تمبلت صور التقويم (خانات الصور وترتيبها) — JSON، فاضي يعني
  // استخدم التمبلت الافتراضي في src/lib/images/template.ts.
  ortho_image_template: "",
  // Batch 130: تفعيل "التعلم المحافظ" من تصحيحات التصنيف اليدوية (راجع
  // src/lib/images/learned-overrides.ts). مقفول افتراضيًا — قرار الأدمن
  // لحاله من الإعدادات، مش جزء من أي نشر.
  auto_learn_from_corrections: "0",
  // Batch 130 (Phase 5): أنواع صور مخصّصة يضيفها الأدمن بنفسه (يدوي بس، مفيش
  // تصنيف تلقائي ليها أبدًا) — راجع src/lib/images/custom-kinds.ts.
  ortho_custom_image_kinds: "[]",
};

// اتنقلوا لـ`weekdays.ts` (ملف نقي من غير اعتماد على قاعدة البيانات) عشان
// الـClient Components تقدر تستوردهم من غير ما تجر طبقة better-sqlite3 معاها
// وتكسر البناء. معادين التصدير هنا فكل الاستيرادات القديمة شغالة زي ما هي.
export { WEEKDAY_LABELS, WEEKDAY_DISPLAY_ORDER, weekdayOf } from "./weekdays";

export type SettingKey = keyof typeof SETTINGS_DEFAULTS;

export async function getSetting(key: SettingKey): Promise<string> {
  const row = await db.selectFrom("clinic_settings").select("value").where("key", "=", key).executeTakeFirst();
  return row?.value ?? SETTINGS_DEFAULTS[key];
}

export async function getAllSettings(): Promise<Record<SettingKey, string>> {
  const rows = await db.selectFrom("clinic_settings").selectAll().execute();
  const map = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  return { ...SETTINGS_DEFAULTS, ...map } as Record<SettingKey, string>;
}

export async function setSetting(key: SettingKey, value: string) {
  await db
    .insertInto("clinic_settings")
    .values({ key, value })
    .onConflict((oc) => oc.column("key").doUpdateSet({ value }))
    .execute();
}

// Generates ["09:00", "09:15", "09:30", ...] between start/end using the clinic's configured slot length.
export function buildTimeSlots(startTime: string, endTime: string, slotMinutes: number): string[] {
  const slots: string[] = [];
  const [sh, sm] = startTime.split(":").map(Number);
  const [eh, em] = endTime.split(":").map(Number);
  let cursor = sh * 60 + sm;
  const end = eh * 60 + em;
  const step = Math.max(5, slotMinutes || 15);
  while (cursor <= end) {
    const h = String(Math.floor(cursor / 60)).padStart(2, "0");
    const m = String(cursor % 60).padStart(2, "0");
    slots.push(`${h}:${m}`);
    cursor += step;
  }
  return slots;
}
