import "server-only";

import { db } from "@/lib/db/client";

// دفعة 144 — "إيقاف العلاج" في تقرير متابعة التقويم المتأخرة.
//
// الإيقاف الفعّال لمريض = آخر صف ليه في ortho_treatment_stops بشرط:
//   1) مااتلغاش يدوي (cleared_at فاضي)، و
//   2) مفيش بعد تاريخ الإيقاف (stopped_date) أي حاجة من دول:
//      - زيارة تقويم في الشارت (ortho_visits.visit_date)
//      - فاتورة أو دفعة على خدمة تقويم (invoice_date) — سواء فاتورة جديدة،
//        أو الفاتورة القديمة، أو دفعة متابعة مربوطة بفاتورة تقويم.
// الشرط التاني بيتحسب وقت العرض (مش بيتكتب في الداتابيز): أول ما المريض يرجع،
// الإيقاف بيتشال لوحده ويرجع يتحسب في المتابعة عادي. المقارنة بالتاريخ
// (أكبر من تاريخ الإيقاف)، فحضور في نفس يوم الإيقاف مش بيلغيه.

export function isOrthoService(category: string | null | undefined, name: string | null | undefined): boolean {
  const c = (category ?? "").trim().toLowerCase();
  return c === "orthodontics" || c === "تقويم" || c.includes("orthodont") || (name ?? "").includes("تقويم");
}

export type ActiveOrthoStop = {
  id: number;
  patientId: number;
  stoppedDate: string;
  reason: string | null;
  stoppedByName: string | null;
};

export async function getActiveOrthoStops(): Promise<Map<number, ActiveOrthoStop>> {
  const rows = await db
    .selectFrom("ortho_treatment_stops")
    .leftJoin("users", "users.id", "ortho_treatment_stops.stopped_by")
    .select([
      "ortho_treatment_stops.id",
      "ortho_treatment_stops.patient_id",
      "ortho_treatment_stops.stopped_date",
      "ortho_treatment_stops.reason",
      "ortho_treatment_stops.cleared_at",
      "users.full_name as stopped_by_name",
    ])
    .orderBy("ortho_treatment_stops.id", "asc")
    .execute();

  // آخر صف لكل مريض بس هو اللي بيحدد حالته.
  const latest = new Map<number, (typeof rows)[number]>();
  for (const row of rows) latest.set(row.patient_id, row);
  const candidates = [...latest.values()].filter((row) => row.cleared_at == null);
  if (!candidates.length) return new Map();

  const ids = candidates.map((row) => row.patient_id);
  const [visits, invoices] = await Promise.all([
    db.selectFrom("ortho_visits")
      .select(["patient_id", (eb) => eb.fn.max("visit_date").as("last")])
      .where("patient_id", "in", ids)
      .groupBy("patient_id")
      .execute(),
    db.selectFrom("invoices")
      .leftJoin("services", "services.id", "invoices.service_id")
      .leftJoin("invoices as parent", "parent.id", "invoices.parent_invoice_id")
      .leftJoin("services as parent_service", "parent_service.id", "parent.service_id")
      .select([
        "invoices.patient_id",
        "invoices.invoice_date",
        "services.category",
        "services.name",
        "parent_service.category as parent_category",
        "parent_service.name as parent_name",
      ])
      .where("invoices.patient_id", "in", ids)
      .execute(),
  ]);

  const lastOrthoActivity = new Map<number, string>();
  const bump = (patientId: number | null, date: string | null) => {
    if (patientId == null || !date) return;
    const day = String(date).slice(0, 10);
    const current = lastOrthoActivity.get(patientId);
    if (!current || day > current) lastOrthoActivity.set(patientId, day);
  };
  for (const visit of visits) bump(visit.patient_id, visit.last as string | null);
  for (const invoice of invoices) {
    if (isOrthoService(invoice.category, invoice.name) || isOrthoService(invoice.parent_category, invoice.parent_name)) {
      bump(invoice.patient_id, invoice.invoice_date);
    }
  }

  const active = new Map<number, ActiveOrthoStop>();
  for (const row of candidates) {
    const returned = lastOrthoActivity.get(row.patient_id);
    if (returned && returned > row.stopped_date) continue;
    active.set(row.patient_id, {
      id: row.id,
      patientId: row.patient_id,
      stoppedDate: row.stopped_date,
      reason: row.reason,
      stoppedByName: row.stopped_by_name,
    });
  }
  return active;
}
