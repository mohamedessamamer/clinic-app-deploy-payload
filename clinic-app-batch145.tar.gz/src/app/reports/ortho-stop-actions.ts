"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { logAdminEvent } from "@/lib/audit";
import { getClinicToday } from "@/lib/clinic-date";
import { getActiveOrthoStops } from "@/lib/ortho-treatment-stops";

// دفعة 144 — إيقاف علاج التقويم وإلغاء الإيقاف وتقرير الموقوفين.
// الإيقاف بيتشال لوحده لو المريض رجع (شوف src/lib/ortho-treatment-stops.ts).
// logAdminEvent بيتنادى بره أي transaction (قاعدة دفعة 108).

const DATE = /^\d{4}-\d{2}-\d{2}$/;
const NO_REASON = "بدون سبب";

export async function stopOrthoTreatmentAction(params: { patientId: number; reason?: string }): Promise<{ ok: true } | { ok: false; error: string }> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "stop_ortho_treatment"))) {
    return { ok: false, error: "مفيش صلاحية عندك لإيقاف العلاج." };
  }
  const patientId = Math.floor(Number(params.patientId));
  if (!patientId) return { ok: false, error: "مريض غير صحيح." };
  const patient = await db.selectFrom("patients").select(["id", "full_name", "file_number"]).where("id", "=", patientId).executeTakeFirst();
  if (!patient) return { ok: false, error: "المريض مش موجود." };

  if ((await getActiveOrthoStops()).has(patientId)) return { ok: true };

  const reason = String(params.reason ?? "").trim().slice(0, 300) || null;
  const stoppedDate = getClinicToday();
  await db.insertInto("ortho_treatment_stops").values({
    patient_id: patientId,
    stopped_date: stoppedDate,
    reason,
    stopped_by: session.userId,
    cleared_at: null,
    cleared_by: null,
  }).execute();
  await logAdminEvent({
    entityType: "patient",
    entityId: patientId,
    event: "stop_ortho_treatment",
    details: `إيقاف علاج التقويم — ${patient.full_name} (ملف ${patient.file_number})${reason ? ` — السبب: ${reason}` : ""}`,
    changedBy: session.userId,
  });
  revalidatePath("/reports");
  return { ok: true };
}

export async function resumeOrthoTreatmentAction(params: { patientId: number }): Promise<{ ok: true } | { ok: false; error: string }> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "stop_ortho_treatment"))) {
    return { ok: false, error: "مفيش صلاحية عندك لإلغاء إيقاف العلاج." };
  }
  const patientId = Math.floor(Number(params.patientId));
  const stop = (await getActiveOrthoStops()).get(patientId);
  if (!stop) return { ok: true };
  const patient = await db.selectFrom("patients").select(["full_name", "file_number"]).where("id", "=", patientId).executeTakeFirst();
  await db.updateTable("ortho_treatment_stops")
    .set({ cleared_at: new Date().toISOString().replace("T", " ").slice(0, 19), cleared_by: session.userId })
    .where("id", "=", stop.id)
    .execute();
  await logAdminEvent({
    entityType: "patient",
    entityId: patientId,
    event: "resume_ortho_treatment",
    details: `إلغاء إيقاف علاج التقويم — ${patient?.full_name ?? ""} (ملف ${patient?.file_number ?? ""})، كان موقوف من ${stop.stoppedDate}`,
    changedBy: session.userId,
  });
  revalidatePath("/reports");
  return { ok: true };
}

export type StoppedTreatmentRow = {
  patientId: number;
  patientName: string;
  fileNumber: string;
  doctorName: string;
  lastAttendance: string | null;
  stoppedDate: string;
  reason: string | null;
  stoppedBy: string;
};

export type StoppedTreatmentResult =
  | { ok: false; error: string }
  | {
      ok: true;
      rows: StoppedTreatmentRow[];
      canResume: boolean;
      // null من غير صلاحية view_stopped_treatment_totals.
      totals: { total: number; byReason: { reason: string; count: number }[] } | null;
    };

export async function getStoppedTreatmentReportAction(params: { from?: string | null; to?: string | null }): Promise<StoppedTreatmentResult> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "view_stopped_treatment_report"))) {
    return { ok: false, error: "مفيش صلاحية عندك لعرض تقرير إيقاف العلاج." };
  }
  const from = params.from && DATE.test(params.from) ? params.from : null;
  const to = params.to && DATE.test(params.to) ? params.to : null;
  if (from && to && to < from) return { ok: false, error: "تاريخ النهاية لازم يكون بعد تاريخ البداية." };

  const stops = [...(await getActiveOrthoStops()).values()]
    .filter((stop) => (!from || stop.stoppedDate >= from) && (!to || stop.stoppedDate <= to));
  const [canResume, canTotals] = await Promise.all([
    hasPermission(session.userId, session.role, "stop_ortho_treatment"),
    hasPermission(session.userId, session.role, "view_stopped_treatment_totals"),
  ]);
  if (!stops.length) return { ok: true, rows: [], canResume, totals: canTotals ? { total: 0, byReason: [] } : null };

  const ids = stops.map((stop) => stop.patientId);
  const [patients, orthoVisits, medical, invoices, appointments] = await Promise.all([
    db.selectFrom("patients").select(["id", "full_name", "file_number"]).where("id", "in", ids).execute(),
    db.selectFrom("ortho_visits").leftJoin("doctors", "doctors.id", "ortho_visits.doctor_id")
      .select(["ortho_visits.patient_id", "ortho_visits.visit_date", "doctors.full_name as doctor_name"])
      .where("ortho_visits.patient_id", "in", ids).orderBy("ortho_visits.visit_date", "desc").execute(),
    db.selectFrom("visits").select(["patient_id", (eb) => eb.fn.max("visit_date").as("last")]).where("patient_id", "in", ids).groupBy("patient_id").execute(),
    db.selectFrom("invoices").select(["patient_id", (eb) => eb.fn.max("invoice_date").as("last")]).where("patient_id", "in", ids).groupBy("patient_id").execute(),
    db.selectFrom("appointments").select(["patient_id", (eb) => eb.fn.max("appointment_date").as("last")])
      .where("patient_id", "in", ids).where("status", "in", ["attended", "done"]).groupBy("patient_id").execute(),
  ]);

  const patientById = new Map(patients.map((p) => [p.id, p]));
  const doctorBy = new Map<number, string>();
  const last = new Map<number, string>();
  const bump = (id: number | null, date: unknown) => {
    if (id == null || !date) return;
    const day = String(date).slice(0, 10);
    if (!last.has(id) || day > last.get(id)!) last.set(id, day);
  };
  for (const visit of orthoVisits) {
    if (!doctorBy.has(visit.patient_id) && visit.doctor_name) doctorBy.set(visit.patient_id, visit.doctor_name);
    bump(visit.patient_id, visit.visit_date);
  }
  for (const row of [...medical, ...invoices, ...appointments]) bump(row.patient_id, row.last);

  const rows: StoppedTreatmentRow[] = stops.map((stop) => ({
    patientId: stop.patientId,
    patientName: patientById.get(stop.patientId)?.full_name ?? "—",
    fileNumber: patientById.get(stop.patientId)?.file_number ?? "",
    doctorName: doctorBy.get(stop.patientId) ?? "—",
    lastAttendance: last.get(stop.patientId) ?? null,
    stoppedDate: stop.stoppedDate,
    reason: stop.reason,
    stoppedBy: stop.stoppedByName ?? "—",
  })).sort((a, b) => (a.stoppedDate < b.stoppedDate ? 1 : a.stoppedDate > b.stoppedDate ? -1 : a.patientName.localeCompare(b.patientName, "ar")));

  let totals: { total: number; byReason: { reason: string; count: number }[] } | null = null;
  if (canTotals) {
    const counts = new Map<string, number>();
    for (const row of rows) {
      const key = row.reason?.trim() || NO_REASON;
      counts.set(key, (counts.get(key) ?? 0) + 1);
    }
    totals = { total: rows.length, byReason: [...counts.entries()].map(([reason, count]) => ({ reason, count })).sort((a, b) => b.count - a.count) };
  }
  return { ok: true, rows, canResume, totals };
}
