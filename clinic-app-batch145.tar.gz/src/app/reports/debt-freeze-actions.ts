"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { logAdminEvent } from "@/lib/audit";
import { getClinicToday } from "@/lib/clinic-date";
import { getFrozenPatients, getPatientDebts } from "@/lib/debt-freezes";

// دفعة 145 — تجميد المديونية وتسويتها.
// logAdminEvent بيتنادى بعد الـ transaction مش جواها (قاعدة دفعة 108).

type Result = { ok: true } | { ok: false; error: string };
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const nowSql = () => new Date().toISOString().replace("T", " ").slice(0, 19);
const cleanReason = (value: unknown) => String(value ?? "").trim().slice(0, 300) || null;

async function patientLabel(patientId: number) {
  const patient = await db.selectFrom("patients").select(["full_name", "file_number"]).where("id", "=", patientId).executeTakeFirst();
  return patient ? `${patient.full_name} (ملف ${patient.file_number})` : null;
}

function revalidateDebtViews(patientId: number) {
  revalidatePath("/reports");
  revalidatePath(`/patients/${patientId}/billing`);
  revalidatePath("/invoices");
}

// ---------------- تجميد ----------------

export async function freezePatientDebtAction(params: { patientId: number; reason?: string }): Promise<Result> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "freeze_patient_debt"))) return { ok: false, error: "مفيش صلاحية عندك لتجميد المديونية." };
  const patientId = Math.floor(Number(params.patientId));
  const label = patientId ? await patientLabel(patientId) : null;
  if (!label) return { ok: false, error: "المريض مش موجود." };
  const frozen = (await getFrozenPatients()).get(patientId);
  if (frozen?.kind === "manual") return { ok: true };
  const reason = cleanReason(params.reason);
  await db.insertInto("debt_freezes").values({ patient_id: patientId, frozen_date: getClinicToday(), reason, frozen_by: session.userId, cleared_at: null, cleared_by: null }).execute();
  await logAdminEvent({ entityType: "patient", entityId: patientId, event: "freeze_patient_debt", details: `تجميد مديونية — ${label}${reason ? ` — السبب: ${reason}` : ""}`, changedBy: session.userId });
  revalidateDebtViews(patientId);
  return { ok: true };
}

export async function unfreezePatientDebtAction(params: { patientId: number }): Promise<Result> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "freeze_patient_debt"))) return { ok: false, error: "مفيش صلاحية عندك لفك التجميد." };
  const patientId = Math.floor(Number(params.patientId));
  const frozen = (await getFrozenPatients()).get(patientId);
  if (!frozen) return { ok: true };
  if (frozen.kind === "stop") return { ok: false, error: "التجميد ده جاي من إيقاف العلاج — بيتفك من تقرير إيقاف العلاج." };
  await db.updateTable("debt_freezes").set({ cleared_at: nowSql(), cleared_by: session.userId }).where("id", "=", frozen.freezeId!).execute();
  await logAdminEvent({ entityType: "patient", entityId: patientId, event: "unfreeze_patient_debt", details: `فك تجميد مديونية — ${await patientLabel(patientId)}، كانت مجمدة من ${frozen.since}`, changedBy: session.userId });
  revalidateDebtViews(patientId);
  return { ok: true };
}

// ---------------- تسوية ----------------

export async function settlePatientDebtAction(params: { patientId: number; reason?: string }): Promise<{ ok: true; amount: number } | { ok: false; error: string }> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "settle_patient_debt"))) return { ok: false, error: "مفيش صلاحية عندك لتسوية المديونية." };
  const patientId = Math.floor(Number(params.patientId));
  const label = patientId ? await patientLabel(patientId) : null;
  if (!label) return { ok: false, error: "المريض مش موجود." };
  const reason = cleanReason(params.reason);

  const debt = (await getPatientDebts([patientId])).get(patientId);
  if (!debt || debt.debt <= 0.01) return { ok: false, error: "مفيش مديونية على المريض ده." };

  await db.transaction().execute(async (trx) => {
    const header = await trx.insertInto("debt_settlements").values({
      patient_id: patientId, settled_date: getClinicToday(), total_amount: debt.debt, reason, settled_by: session.userId, cancelled_at: null, cancelled_by: null,
    }).executeTakeFirst();
    const settlementId = Number(header.insertId);
    for (const invoice of debt.invoices) {
      await trx.insertInto("debt_settlement_lines").values({ settlement_id: settlementId, invoice_id: invoice.id, amount: invoice.balance }).execute();
      await trx.updateTable("invoices")
        .set((eb) => ({ settled_amount: eb("settled_amount", "+", invoice.balance) }))
        .where("id", "=", invoice.id)
        .execute();
    }
  });
  await logAdminEvent({ entityType: "patient", entityId: patientId, event: "settle_patient_debt", details: `تسوية مديونية بدون تحصيل — ${label} — ${debt.debt.toFixed(0)} ج.م على ${debt.invoices.length} فاتورة${reason ? ` — السبب: ${reason}` : ""}`, changedBy: session.userId });
  revalidateDebtViews(patientId);
  return { ok: true, amount: debt.debt };
}

export async function cancelDebtSettlementAction(params: { settlementId: number }): Promise<Result> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "settle_patient_debt"))) return { ok: false, error: "مفيش صلاحية عندك لإلغاء التسوية." };
  const settlementId = Math.floor(Number(params.settlementId));
  const settlement = await db.selectFrom("debt_settlements").selectAll().where("id", "=", settlementId).executeTakeFirst();
  if (!settlement) return { ok: false, error: "التسوية مش موجودة." };
  if (settlement.cancelled_at) return { ok: true };
  const lines = await db.selectFrom("debt_settlement_lines").select(["invoice_id", "amount"]).where("settlement_id", "=", settlementId).execute();
  await db.transaction().execute(async (trx) => {
    for (const line of lines) {
      // MAX(0, ...) عشان لو الفاتورة اتعدلت بعد التسوية ماينزلش تحت الصفر.
      await trx.updateTable("invoices")
        .set((eb) => ({ settled_amount: eb.fn("max", [eb.val(0), eb("settled_amount", "-", line.amount)]) }))
        .where("id", "=", line.invoice_id)
        .execute();
    }
    await trx.updateTable("debt_settlements").set({ cancelled_at: nowSql(), cancelled_by: session.userId }).where("id", "=", settlementId).execute();
  });
  await logAdminEvent({ entityType: "patient", entityId: settlement.patient_id, event: "cancel_debt_settlement", details: `إلغاء تسوية مديونية — ${await patientLabel(settlement.patient_id)} — ${settlement.total_amount.toFixed(0)} ج.م (كانت بتاريخ ${settlement.settled_date})`, changedBy: session.userId });
  revalidateDebtViews(settlement.patient_id);
  return { ok: true };
}

// ---------------- تقرير المديونيات المجمدة ----------------

export type FrozenDebtRow = {
  patientId: number;
  patientName: string;
  fileNumber: string;
  debt: number;
  since: string;
  reason: string | null;
  kind: "stop" | "manual";
  byName: string;
};

export type FrozenDebtsResult =
  | { ok: false; error: string }
  | { ok: true; rows: FrozenDebtRow[]; canUnfreeze: boolean; canSettle: boolean; totals: { count: number; debt: number } | null };

export async function getFrozenDebtsReportAction(): Promise<FrozenDebtsResult> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "view_frozen_debts_report"))) return { ok: false, error: "مفيش صلاحية عندك لعرض المديونيات المجمدة." };
  const frozen = await getFrozenPatients();
  const ids = [...frozen.keys()];
  const [debts, patients, canUnfreeze, canSettle, canTotals] = await Promise.all([
    getPatientDebts(ids),
    ids.length ? db.selectFrom("patients").select(["id", "full_name", "file_number"]).where("id", "in", ids).execute() : Promise.resolve([]),
    hasPermission(session.userId, session.role, "freeze_patient_debt"),
    hasPermission(session.userId, session.role, "settle_patient_debt"),
    hasPermission(session.userId, session.role, "view_frozen_debts_totals"),
  ]);
  const patientById = new Map(patients.map((p) => [p.id, p]));
  // المريض المجمد اللي مالوش مديونية (مثلًا موقوف علاجه ومش مديون) مش بيظهر.
  const rows: FrozenDebtRow[] = [...debts.values()].map((entry) => {
    const info = frozen.get(entry.patientId)!;
    return {
      patientId: entry.patientId,
      patientName: patientById.get(entry.patientId)?.full_name ?? "—",
      fileNumber: patientById.get(entry.patientId)?.file_number ?? "",
      debt: entry.debt,
      since: info.since,
      reason: info.reason,
      kind: info.kind,
      byName: info.byName ?? "—",
    };
  }).sort((a, b) => b.debt - a.debt);
  return {
    ok: true, rows, canUnfreeze, canSettle,
    totals: canTotals ? { count: rows.length, debt: Math.round(rows.reduce((sum, row) => sum + row.debt, 0) * 100) / 100 } : null,
  };
}

// ---------------- تقرير التسويات ----------------

export type DebtSettlementRow = {
  id: number;
  patientId: number;
  patientName: string;
  fileNumber: string;
  amount: number;
  date: string;
  reason: string | null;
  byName: string;
};

export type DebtSettlementsResult =
  | { ok: false; error: string }
  | { ok: true; rows: DebtSettlementRow[]; canCancel: boolean; totals: { count: number; amount: number } | null };

export async function getDebtSettlementsReportAction(params: { from?: string | null; to?: string | null }): Promise<DebtSettlementsResult> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "view_debt_settlements_report"))) return { ok: false, error: "مفيش صلاحية عندك لعرض تسويات المديونية." };
  const from = params.from && DATE.test(params.from) ? params.from : null;
  const to = params.to && DATE.test(params.to) ? params.to : null;
  if (from && to && to < from) return { ok: false, error: "تاريخ النهاية لازم يكون بعد تاريخ البداية." };
  const [settlements, canCancel, canTotals] = await Promise.all([
    db.selectFrom("debt_settlements")
      .innerJoin("patients", "patients.id", "debt_settlements.patient_id")
      .leftJoin("users", "users.id", "debt_settlements.settled_by")
      .select(["debt_settlements.id", "debt_settlements.patient_id", "debt_settlements.total_amount", "debt_settlements.settled_date", "debt_settlements.reason", "patients.full_name", "patients.file_number", "users.full_name as by_name"])
      .where("debt_settlements.cancelled_at", "is", null)
      .$if(!!from, (qb) => qb.where("debt_settlements.settled_date", ">=", from!))
      .$if(!!to, (qb) => qb.where("debt_settlements.settled_date", "<=", to!))
      .orderBy("debt_settlements.id", "desc")
      .execute(),
    hasPermission(session.userId, session.role, "settle_patient_debt"),
    hasPermission(session.userId, session.role, "view_debt_settlements_totals"),
  ]);
  const rows: DebtSettlementRow[] = settlements.map((s) => ({
    id: s.id, patientId: s.patient_id, patientName: s.full_name, fileNumber: s.file_number,
    amount: s.total_amount, date: s.settled_date, reason: s.reason, byName: s.by_name ?? "—",
  }));
  return {
    ok: true, rows, canCancel,
    totals: canTotals ? { count: rows.length, amount: Math.round(rows.reduce((sum, row) => sum + row.amount, 0) * 100) / 100 } : null,
  };
}
