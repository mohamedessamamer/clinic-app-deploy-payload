"use server";

import { sql } from "kysely";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";

type ChatMessage = { id: number; body: string; created_at: string; sender_user_id: number; sender_name: string; recipient_user_id: number | null; audience: "reception" | "doctor" | "all_doctors" };

async function cleanExpiredMessages() {
  // مدة الاحتفاظ 48 ساعة حسب طلب المستخدم. التنظيف يحصل مع استعمال الشات؛
  // لا نحتاج خدمة خارجية أو WebSocket لتنفيذه.
  await db.deleteFrom("chat_messages").where(sql<boolean>`created_at <= datetime('now', '-48 hours')`).execute();
}

export async function getStaffChatAction(): Promise<ChatMessage[]> {
  const session = await getSession();
  if (!session) return [];
  await cleanExpiredMessages();
  const query = db
    .selectFrom("chat_messages")
    .innerJoin("users as senders", "senders.id", "chat_messages.sender_user_id")
    .select([
      "chat_messages.id",
      "chat_messages.body",
      "chat_messages.created_at",
      "chat_messages.sender_user_id",
      "senders.full_name as sender_name",
      "chat_messages.recipient_user_id",
      "chat_messages.audience",
    ])
    .orderBy("chat_messages.id", "asc")
    .limit(250);

  if (session.role === "reception" || session.role === "admin" || session.role === "clinic_manager") {
    return query.execute();
  }
  // الطبيب يرى رسائله إلى الاستقبال، رد الاستقبال المباشر له، وأي رسالة لكل الأطباء.
  return query.where((eb) =>
    eb.or([
      eb("chat_messages.sender_user_id", "=", session.userId),
      eb("chat_messages.recipient_user_id", "=", session.userId),
      eb("chat_messages.audience", "=", "all_doctors"),
    ])
  ).execute();
}

export async function getStaffChatUnreadCountAction(): Promise<number> {
  const session = await getSession();
  if (!session) return 0;
  const [messages, state] = await Promise.all([
    getStaffChatAction(),
    db.selectFrom("chat_read_states").select("last_read_message_id").where("user_id", "=", session.userId).executeTakeFirst(),
  ]);
  const lastRead = state?.last_read_message_id ?? 0;
  return messages.filter((message) => message.id > lastRead && message.sender_user_id !== session.userId).length;
}

export async function markStaffChatReadAction() {
  const session = await getSession();
  if (!session) return;
  const messages = await getStaffChatAction();
  const lastMessageId = messages.at(-1)?.id ?? 0;
  await db
    .insertInto("chat_read_states")
    .values({ user_id: session.userId, last_read_message_id: lastMessageId, updated_at: sql<string>`datetime('now')` })
    .onConflict((oc) => oc.column("user_id").doUpdateSet({ last_read_message_id: lastMessageId, updated_at: sql<string>`datetime('now')` }))
    .execute();
}

export async function getChatDoctorsAction() {
  const session = await getSession();
  if (!session) return [];
  const allowed =
    ["reception", "admin", "clinic_manager"].includes(session.role) ||
    (session.role === "doctor" && (await hasPermission(session.userId, session.role, "send_staff_chat_to_doctors")));
  if (!allowed) return [];
  return db
    .selectFrom("users")
    .innerJoin("doctors", "doctors.id", "users.doctor_id")
    .select(["users.id", "users.full_name"])
    .where("users.active", "=", 1)
    .where("doctors.active", "=", 1)
    .orderBy("users.full_name")
    .execute();
}

export async function sendStaffChatAction(formData: FormData): Promise<{ ok: boolean; reason?: string }> {
  const session = await getSession();
  if (!session) return { ok: false, reason: "سجل الدخول أولًا." };
  const body = String(formData.get("body") || "").trim().slice(0, 2000);
  if (!body) return { ok: false, reason: "اكتب رسالة أولًا." };

  const broadcast = formData.get("broadcast") === "1";
  const recipientUserId = Number(formData.get("recipient_user_id")) || null;
  let audience: "reception" | "doctor" | "all_doctors" = "reception";
  let recipient_user_id: number | null = null;

  if (session.role === "doctor") {
    const canTargetDoctors = await hasPermission(session.userId, session.role, "send_staff_chat_to_doctors");
    // الرسالة الافتراضية للطبيب تذهب للاستقبال. الصلاحية الفردية فقط هي التي
    // تفتح له اختيار طبيب محدد أو إعلانًا لكل الأطباء.
    if (!canTargetDoctors || (!broadcast && !recipientUserId)) {
      audience = "reception";
    } else if (broadcast) {
      audience = "all_doctors";
    } else {
      const recipient = await db.selectFrom("users").select(["id", "role", "active"]).where("id", "=", recipientUserId).executeTakeFirst();
      if (!recipient || !recipient.active || recipient.role !== "doctor") return { ok: false, reason: "اختر طبيبًا نشطًا." };
      audience = "doctor";
      recipient_user_id = recipient.id;
    }
  } else if (broadcast) {
    audience = "all_doctors";
  } else if (recipientUserId) {
    const recipient = await db.selectFrom("users").select(["id", "role", "active"]).where("id", "=", recipientUserId).executeTakeFirst();
    if (!recipient || !recipient.active || recipient.role !== "doctor") return { ok: false, reason: "اختر طبيبًا نشطًا." };
    audience = "doctor";
    recipient_user_id = recipient.id;
  } else {
    return { ok: false, reason: "اختر طبيبًا أو أرسل الرسالة لكل الأطباء." };
  }

  await cleanExpiredMessages();
  await db.insertInto("chat_messages").values({ sender_user_id: session.userId, recipient_user_id, audience, body }).execute();
  return { ok: true };
}
