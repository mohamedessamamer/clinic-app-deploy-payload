"use client";

import { Suspense, useEffect, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";

// دفعة 141 — السبب الحقيقي لمشكلة "رجوع" بيودّي لصفحة التقارير الرئيسية:
//
// الزرار ده بيحتفظ بسجل صفحات خاص بيه في sessionStorage، وكان بيسجّل
// الـ pathname بس (مثلًا "/reports") ويرمي كل اللي بعد علامة "?" — واللي هو
// بالظبط المكان اللي فيه التبويب المفتوح والفلاتر (tab=patients&report=debts&
// debts_specialty=...). فدفعات 138/139/140 كانت بتسجّل الحالة في الرابط صح،
// لكن الزرار نفسه كان بيرجع لـ "/reports" حاف => الصفحة الرئيسية للتقارير.
//
// القاعدة العامة دلوقتي (على مستوى السيستم كله):
//   1) السجل بيحفظ الرابط الكامل (pathname + query string).
//   2) لو الرابط اتغيّر وإحنا لسه في نفس الصفحة (نفس الـ pathname) — زي اختيار
//      تبويب أو تطبيق فلتر أو تغيير صفحة في جدول — بنحدّث آخر خانة في السجل
//      بدل ما نضيف خانة جديدة. يعني "رجوع" بيرجعك للشاشة اللي قبلها
//      بآخر حالة كنت سايبها عليها، مش بيمشي خطوة خطوة جوه الفلاتر.
//   3) أي صفحة بتسجّل حالتها في الرابط (راجع src/lib/url-report-state.ts)
//      بتستفيد من ده تلقائيًا من غير أي كود إضافي.
const HISTORY_KEY = "clinic-app-page-history-v2";
const MAX_ENTRIES = 30;

function readHistory(): string[] {
  try {
    const parsed = JSON.parse(window.sessionStorage.getItem(HISTORY_KEY) || "[]");
    return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === "string") : [];
  } catch {
    return [];
  }
}

function writeHistory(history: string[]) {
  try {
    window.sessionStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(-MAX_ENTRIES)));
  } catch {
    // sessionStorage ممكن يكون مقفول (وضع خاص/إعدادات المتصفح) — الزرار
    // بيفضل شغال في الجلسة الحالية من غير حفظ.
  }
}

function pathOf(url: string) {
  const index = url.indexOf("?");
  return index === -1 ? url : url.slice(0, index);
}

function BackButtonView({ canGoBack, onClick }: { canGoBack: boolean; onClick?: () => void }) {
  return (
    <button type="button" onClick={onClick} disabled={!canGoBack} className="clinic-header-back" aria-label="الرجوع للصفحة السابقة" title="رجوع">
      <span aria-hidden="true">←</span><span>رجوع</span>
    </button>
  );
}

function TrackedBackButton() {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const router = useRouter();
  const [canGoBack, setCanGoBack] = useState(false);
  const search = searchParams.toString();
  const current = search ? `${pathname}?${search}` : pathname;

  useEffect(() => {
    const history = readHistory();
    const top = history.at(-1);
    if (top === current) {
      // نفس الرابط — مفيش حاجة تتغير (مثلًا نسخة الموبايل من الزرار اتفتحت).
    } else if (history.at(-2) === current) {
      // رجوع بزرار المتصفح لنفس الصفحة اللي قبلها بالظبط.
      history.pop();
    } else if (top !== undefined && pathOf(top) === pathname) {
      // نفس الصفحة، الحالة بس اللي اتغيرت (تبويب/فلتر/صفحة جدول) — حدّث آخر
      // خانة عشان "رجوع" من الصفحة الجاية يرجع لآخر حالة.
      history[history.length - 1] = current;
    } else {
      history.push(current);
    }
    writeHistory(history);
    setCanGoBack(history.length > 1);
  }, [pathname, current]);

  function goBack() {
    const history = readHistory();
    if (history.length < 2) return;
    history.pop();
    const target = history.at(-1);
    writeHistory(history);
    setCanGoBack(history.length > 1);
    if (target) router.push(target);
  }

  return <BackButtonView canGoBack={canGoBack} onClick={goBack} />;
}

export default function HeaderBackButton() {
  // useSearchParams لازم يبقى جوه Suspense عشان ما يوقفش الـ prerender بتاع
  // أي صفحة ثابتة؛ لحد ما يجهز بيظهر نفس الزرار مقفول.
  return (
    <Suspense fallback={<BackButtonView canGoBack={false} />}>
      <TrackedBackButton />
    </Suspense>
  );
}
