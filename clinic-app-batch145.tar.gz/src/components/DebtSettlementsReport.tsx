"use client";

import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { cancelDebtSettlementAction, getDebtSettlementsReportAction, type DebtSettlementsResult } from "@/app/reports/debt-freeze-actions";
import { useUrlReportParams, writeUrlReportParams } from "@/lib/url-report-state";
import ConfirmReasonDialog from "@/components/ConfirmReasonDialog";

// دفعة 145 — تقرير "تسويات المديونية" (التسويات الفعّالة). الفلاتر والصفحة في الرابط.
const input = "rounded border border-border bg-background px-2 py-1.5 text-sm";
const PAGE_SIZE = 50;
const urlKeys = ["settle_from", "settle_to", "settle_page", "settle_applied"];

export default function DebtSettlementsReport() {
  const router = useRouter();
  const initialUrl = useUrlReportParams(urlKeys);
  const [from, setFrom] = useState(initialUrl.settle_from ?? "");
  const [to, setTo] = useState(initialUrl.settle_to ?? "");
  const [page, setPage] = useState(() => Math.max(1, Number(initialUrl.settle_page) || 1));
  const [result, setResult] = useState<DebtSettlementsResult | null>(null);
  const [cancelTarget, setCancelTarget] = useState<{ id: number; name: string; amount: number } | null>(null);
  const [cancelError, setCancelError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  function run(nextPage = 1) {
    setPage(nextPage);
    writeUrlReportParams(router, { settle_from: from || null, settle_to: to || null, settle_page: String(nextPage), settle_applied: "1" });
    startTransition(async () => setResult(await getDebtSettlementsReportAction({ from: from || null, to: to || null })));
  }
  useEffect(() => {
    if (initialUrl.settle_applied === "1") run(Number(initialUrl.settle_page) || 1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  function goToPage(next: number) {
    setPage(next);
    writeUrlReportParams(router, { settle_page: String(next) });
  }
  function confirmCancel() {
    if (!cancelTarget) return;
    startTransition(async () => {
      const response = await cancelDebtSettlementAction({ settlementId: cancelTarget.id });
      if (!response.ok) { setCancelError(response.error); return; }
      setCancelTarget(null); setCancelError(null);
      setResult(await getDebtSettlementsReportAction({ from: from || null, to: to || null }));
    });
  }

  const rows = result?.ok ? result.rows : [];
  const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const pageRows = rows.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
  const canCancel = result?.ok ? result.canCancel : false;

  return (
    <section className="card-3d rounded-xl p-5 space-y-4" dir="rtl">
      <div>
        <h2 className="font-semibold">تسويات المديونية</h2>
        <p className="mt-1 text-xs text-muted">مديونيات اتقفلت من غير تحصيل (مدفوعة قبل السيستم أو مش حقيقية). التسوية مابتأثرش على الإيرادات ولا التحصيل.</p>
      </div>

      <div className="flex flex-wrap items-end gap-2">
        <label className="text-xs text-muted">من تاريخ<input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className={`${input} mt-1 block w-40`} /></label>
        <label className="text-xs text-muted">إلى تاريخ<input type="date" value={to} onChange={(e) => setTo(e.target.value)} className={`${input} mt-1 block w-40`} /></label>
        <button type="button" onClick={() => run(1)} disabled={isPending} className="h-9 rounded-md btn-3d-primary px-4 text-sm font-medium disabled:opacity-50">{isPending ? "..." : "عرض التقرير"}</button>
      </div>

      {result && !result.ok && <p className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{result.error}</p>}

      {result?.ok && result.totals && (
        <div className="flex flex-wrap gap-3">
          <div className="rounded-xl border border-border px-4 py-3 text-center">
            <div className="text-xs text-muted">مجموع التسويات</div>
            <div className="text-2xl font-extrabold">{result.totals.amount.toFixed(0)} ج.م</div>
          </div>
          <div className="rounded-xl border border-border px-4 py-3 text-center">
            <div className="text-xs text-muted">عدد التسويات</div>
            <div className="text-2xl font-extrabold">{result.totals.count}</div>
          </div>
        </div>
      )}

      {result?.ok && (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-right">
                <th className="p-2">المريض</th>
                <th className="p-2 whitespace-nowrap">رقم الملف</th>
                <th className="p-2 whitespace-nowrap">المبلغ</th>
                <th className="p-2 whitespace-nowrap">التاريخ</th>
                <th className="p-2">السبب</th>
                <th className="p-2 whitespace-nowrap">بواسطة</th>
                {canCancel && <th className="p-2 whitespace-nowrap">إلغاء</th>}
              </tr>
            </thead>
            <tbody>
              {pageRows.map((row) => (
                <tr key={row.id} className="border-b border-border">
                  <td className="p-2 font-medium"><Link href={`/patients/${row.patientId}/billing`} className="text-primary hover:underline">{row.patientName}</Link></td>
                  <td className="p-2 whitespace-nowrap">{row.fileNumber}</td>
                  <td className="p-2 whitespace-nowrap font-semibold">{row.amount.toFixed(0)} ج.م</td>
                  <td className="p-2 whitespace-nowrap">{row.date}</td>
                  <td className="p-2">{row.reason || <span className="text-muted">—</span>}</td>
                  <td className="p-2 whitespace-nowrap">{row.byName}</td>
                  {canCancel && <td className="p-2"><button type="button" onClick={() => { setCancelTarget({ id: row.id, name: row.patientName, amount: row.amount }); setCancelError(null); }} className="rounded border border-danger/60 px-2 py-1 text-xs text-danger hover:bg-danger/5">إلغاء التسوية</button></td>}
                </tr>
              ))}
            </tbody>
          </table>
          {!rows.length && <p className="py-6 text-center text-sm text-muted">مفيش تسويات.</p>}
        </div>
      )}

      {result?.ok && totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 text-sm">
          <button type="button" disabled={currentPage <= 1} onClick={() => goToPage(currentPage - 1)} className="rounded border border-border px-3 py-1 disabled:opacity-50">السابق</button>
          <span>صفحة {currentPage} / {totalPages}</span>
          <button type="button" disabled={currentPage >= totalPages} onClick={() => goToPage(currentPage + 1)} className="rounded border border-border px-3 py-1 disabled:opacity-50">التالي</button>
        </div>
      )}

      {cancelTarget && (
        <ConfirmReasonDialog
          title={`إلغاء تسوية ${cancelTarget.name}؟`}
          description={<>المديونية (<b>{cancelTarget.amount.toFixed(0)} ج.م</b>) هترجع على المريض — في قايمة المديونيات، أو المجمدات لو المريض لسه مجمد.</>}
          confirmLabel="تأكيد إلغاء التسوية"
          tone="danger"
          busy={isPending}
          error={cancelError}
          onConfirm={confirmCancel}
          onCancel={() => { setCancelTarget(null); setCancelError(null); }}
        />
      )}
    </section>
  );
}
