"use client";

import { useMemo, useState } from "react";
import { useFormStatus } from "react-dom";
import ServiceCombobox from "./ServiceCombobox";
import { PAYMENT_METHODS } from "@/lib/payment-methods";
import { addPatientServiceAction } from "@/app/patients/[id]/billing/actions";

type Service = { id: number; name: string; code?: string | null; default_price?: number | null };
type Doctor = { id: number; full_name: string };
type BillableInvoice = { id: number; service_name: string; visit_date: string; balance: number };

const FOLLOWUP_SERVICE_CODE = "0";

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      disabled={pending}
      className="rounded-md btn-3d-primary px-4 py-1.5 text-sm font-medium transition-colors disabled:opacity-60"
    >
      {pending ? "جاري الحفظ..." : "+ إضافة الخدمة"}
    </button>
  );
}

// بوكس "إضافة خدمة" جوه الملف المالي للمريض — بديل بوكس "إضافة خدمة" اللي كان
// تحت الجدول المركزي في /front-desk (دفعة 20)، بنفس منطق بوكس التحصيل بالجدول
// المركزي (السعر/الخصم/المبلغ المدفوع دلوقتي بيتحدث تلقائي معاهم لحد ما يتلمس
// يدويًا/طريقة الدفع/خدمة "متابعة" بتتخصم من فاتورة سابقة) عشان التجربة تفضل
// متسقة في كل أماكن التحصيل بالتطبيق.
export default function AddPatientServiceForm({
  patientId,
  services,
  doctors,
  billableInvoices,
  canBackdate,
  canEditAssistantDoctor = false,
  today,
}: {
  patientId: number;
  services: Service[];
  doctors: Doctor[];
  billableInvoices: BillableInvoice[];
  canBackdate: boolean;
  // دفعة 22: إضافة "الطبيب المساعد" وقت تسجيل خدمة من الملف المالي مباشرة —
  // نفس صلاحية edit_visit_assistant_doctor/override_visit_doctor المستخدمة في
  // سجل الزيارات بالملف الطبي، عشان الاستقبال يقدر يحددها من هنا كمان لو محتاجة.
  canEditAssistantDoctor?: boolean;
  today: string;
}) {
  const [serviceId, setServiceId] = useState<string>("");
  const [price, setPrice] = useState<string>("0");
  const [discountPercent, setDiscountPercent] = useState<string>("0");
  const [amountNow, setAmountNow] = useState<string>("");
  const [paymentMethod, setPaymentMethod] = useState<string>("cash");
  const [doctorId, setDoctorId] = useState<string>("");
  const [performingDoctorId, setPerformingDoctorId] = useState<string>("");
  const [visitDate, setVisitDate] = useState<string>(today);
  const [targetInvoiceId, setTargetInvoiceId] = useState<string>("");

  const selectedService = useMemo(() => services.find((s) => String(s.id) === serviceId) ?? null, [services, serviceId]);
  const isFollowup = selectedService?.code === FOLLOWUP_SERVICE_CODE;

  const computedTotal = useMemo(() => {
    const p = Number(price) || 0;
    const d = Math.min(100, Math.max(0, Number(discountPercent) || 0));
    return Math.max(0, p * (1 - d / 100));
  }, [price, discountPercent]);

  function selectService(nextServiceId: string) {
    setServiceId(nextServiceId);
    const service = services.find((item) => String(item.id) === nextServiceId);
    setPrice(String(service?.default_price ?? 0));
    setDiscountPercent("0");
    setAmountNow("");
    setTargetInvoiceId("");
  }

  const selectedTargetBalance = useMemo(
    () => billableInvoices.find((b) => String(b.id) === targetInvoiceId) ?? null,
    [billableInvoices, targetInvoiceId]
  );

  return (
    <div className="card-3d rounded-xl p-5 space-y-3">
      <h2 className="font-semibold">إضافة خدمة جديدة</h2>

      <form action={addPatientServiceAction} className="space-y-3">
        <input type="hidden" name="patient_id" value={patientId} />
        <input type="hidden" name="visit_date" value={visitDate} />
        <input type="hidden" name="payment_method" value={paymentMethod} />
        {isFollowup ? (
          <input type="hidden" name="target_invoice_id" value={targetInvoiceId} />
        ) : (
          <>
            <input type="hidden" name="price" value={price} />
            <input type="hidden" name="discount_percent" value={discountPercent} />
          </>
        )}
        <input type="hidden" name="amount_now" value={amountNow} />

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs text-muted mb-1">الخدمة</label>
            <ServiceCombobox name="service_id" services={services} value={serviceId} onChange={selectService} />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1">
              التاريخ {!canBackdate && <span className="text-muted">(النهاردة بس)</span>}
            </label>
            <input
              type="date"
              value={visitDate}
              max={today}
              disabled={!canBackdate}
              onChange={(e) => setVisitDate(e.target.value)}
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm disabled:opacity-60 disabled:cursor-not-allowed"
            />
          </div>
        </div>

        {selectedService && isFollowup && (
          <div>
            <label className="block text-xs text-muted mb-1">الخدمة الأصلية (اللي هتتخصم منها الدفعة)</label>
            {billableInvoices.length > 0 ? (
              <select
                value={targetInvoiceId}
                onChange={(e) => setTargetInvoiceId(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              >
                <option value="">اختر خدمة</option>
                {billableInvoices.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.service_name} — {b.visit_date} — الباقي {b.balance.toFixed(0)} ج.م
                  </option>
                ))}
              </select>
            ) : (
              <div className="text-xs text-danger">مفيش فواتير سابقة لسه عليها مبلغ مستحق لهذا المريض.</div>
            )}
            {selectedTargetBalance && (
              <div className="text-sm mt-1">
                الباقي المستحق: <span className="text-danger font-semibold">{selectedTargetBalance.balance.toFixed(0)} ج.م</span>
              </div>
            )}
          </div>
        )}

        {selectedService && !isFollowup && (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-muted mb-1">السعر</label>
              <input
                type="number"
                step="0.01"
                min={0}
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-muted mb-1">خصم (%)</label>
              <input
                type="number"
                step="1"
                min={0}
                max={100}
                value={discountPercent}
                onChange={(e) => setDiscountPercent(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              />
            </div>
            <div className="col-span-2 text-sm">
              المطلوب دفعه: <span className="font-semibold">{computedTotal.toFixed(0)} ج.م</span>
            </div>
          </div>
        )}

        {selectedService && (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-primary font-medium mb-1">المبلغ المدفوع دلوقتي *</label>
              <input
                type="number"
                step="0.01"
                min={0}
                required
                value={amountNow}
                onChange={(e) => {
                  setAmountNow(e.target.value);
                }}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-muted mb-1">وسيلة الدفع</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              >
                {PAYMENT_METHODS.map((m) => (
                  <option key={m.value} value={m.value}>
                    {m.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        )}

        <div className={canEditAssistantDoctor ? "grid grid-cols-2 gap-3" : ""}>
          <div>
            <label className="block text-xs text-muted mb-1">الدكتور</label>
            <select
              name="doctor_id"
              required
              value={doctorId}
              onChange={(e) => setDoctorId(e.target.value)}
              className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
            >
              <option value="">اختر دكتور</option>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.full_name}
                </option>
              ))}
            </select>
          </div>
          {canEditAssistantDoctor && (
            <div>
              <label className="block text-xs text-muted mb-1">الطبيب المساعد (لو مختلف)</label>
              <select
                name="performing_doctor_id"
                value={performingDoctorId}
                onChange={(e) => setPerformingDoctorId(e.target.value)}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              >
                <option value="">نفس الدكتور المختار</option>
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.full_name}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        <SubmitButton />
      </form>
    </div>
  );
}
