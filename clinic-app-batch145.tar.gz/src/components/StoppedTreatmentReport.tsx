"use client";

import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { getStoppedTreatmentReportAction, resumeOrthoTreatmentAction, type StoppedTreatmentResult } from "@/app/reports/ortho-stop-actions";
import { useUrlReportParams, writeUrlReportParams } from "@/lib/url-report-state";

// دفعة 144 — تقرير "إيقاف العلاج": مرضى التقويم الموقوف علاجهم حاليًا.
// الفلاتر والصفحة في الرابط (القاعدة العامة: "رجوع" بيرجع لنفس الحالة).
const input = "rounded border border-border bg-background px-2 py-1.5 text-sm";
const PAGE_SIZE = 50;
const urlKeys = ["stopped_from", "stopped_to", "stopped_page", "stopped_applied"];

export default function StoppedTreatmentReport() {
  const router = useRouter();
  const initialUrl = useUrlReportParams(urlKeys);
  const [from, setFrom] = useState(initialUrl.stopped_from ?? "");
  const [to, setTo] = useState(initialUrl.stopped_to ?? "");
  const [page, setPage] = useState(() => Math.max(1, Number(initialUrl.stopped_page) || 1));
  const [result, setResult] = useState<StoppedTreatmentResult | null>(null);
  const [resumeTarget, setResumeTarget] = useState<{ patientId: number; name: string } | null>(null);
  const [resumeError, setResumeError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  function run(nextPage = 1) {
    setPage(nextPage);
    writeUrlReportParams(router, { stopped_from: from || null, stopped_to: to || null, stopped_page: String(nextPage), stopped_applied: "1" });
    startTransition(async () => setResult(await getStoppedTreatmentReportAction({ from: from || null, to: to || null })));
  }

  useEffect(() => {
    if (initialUrl.stopped_applied === "1") run(Number(initialUrl.stopped_page) || 1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function goToPage(next: number) {
    setPage(next);
    writeUrlReportParams(router, { stopped_page: String(next) });
  }

  const confirmResume = () => startTransition(async () => {
    if (!resumeTarget) return;
    const response = await resumeOrthoTreatmentAction({ patientId: resumeTarget.patientId });
    if (!response.ok) { setResumeError(response.error); return; }
    setResumeTarget(null); setResumeError(null);
    setResult(await getStoppedTreatmentReportAction({ from: from || null, to: to || null }));
  });

  const rows = result?.ok ? result.rows : [];
  const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const pageRows = rows.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
  const canResume = result?.ok ? result.canResume : false;

  return (
    <section className="card-3d rounded-xl p-5 space-y-4" dir="rtl">
      <div>
        <h2 className="font-semibold">إيقاف العلاج</h2>
        <p className="mt-1 text-xs text-muted">
          مرضى التقويم الموقوف علاجهم حاليًا. لو المريض رجع وعمل زيارة تقويم أو اتسجلت له فاتورة/دفعة تقويم بعد تاريخ الإيقاف، بيختفي من هنا ويرجع لتقرير المتأخرين لوحده.
        </p>
      </div>

      <div className="flex flex-wrap items-end gap-2">
        <label className="text-xs text-muted">
          موقوف من تاريخ
          <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className={`${input} mt-1 block w-40`} />
        </label>
        <label className="text-xs text-muted">
          إلى تاريخ
          <input type="date" value={to} onChange={(e) => setTo(e.target.value)} className={`${input} mt-1 block w-40`} />
        </label>
        <button type="button" onClick={() => run(1)} disabled={isPending} className="h-9 rounded-md btn-3d-primary px-4 text-sm font-medium disabled:opacity-50">
          {isPending ? "..." : "عرض التقرير"}
        </button>
      </div>

      {result && !result.ok && <p className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{result.error}</p>}

      {result?.ok && result.totals && (
        <div className="flex flex-wrap gap-3">
          <div className="rounded-xl border border-amber-300/60 bg-amber-50/40 px-4 py-3 text-center">
            <div className="text-xs text-muted">إجمالي الموقوفين</div>
            <div className="text-2xl font-extrabold text-amber-700">{result.totals.total}</div>
          </div>
          {result.totals.byReason.map((item) => (
            <div key={item.reason} className="rounded-xl border border-border px-4 py-3 text-center">
              <div className="text-xs text-muted">{item.reason}</div>
              <div className="text-xl font-bold">{item.count}</div>
            </div>
          ))}
        </div>
      )}

      {result?.ok && (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-right">
                <th className="p-2">المريض</th>
                <th className="p-2 whitespace-nowrap">رقم الملف</th>
                <th className="p-2">الطبيب</th>
                <th className="p-2 whitespace-nowrap">آخر حضور</th>
                <th className="p-2 whitespace-nowrap">تاريخ الإيقاف</th>
                <th className="p-2">السبب</th>
                <th className="p-2 whitespace-nowrap">أوقفه</th>
                {canResume && <th className="p-2 whitespace-nowrap">إلغاء الإيقاف</th>}
              </tr>
            </thead>
            <tbody>
              {pageRows.map((row) => (
                <tr key={row.patientId} className="border-b border-border">
                  <td className="p-2 font-medium"><Link href={`/patients/${row.patientId}/billing`} className="text-primary hover:underline">{row.patientName}</Link></td>
                  <td className="p-2 whitespace-nowrap">{row.fileNumber}</td>
                  <td className="p-2">{row.doctorName}</td>
                  <td className="p-2 whitespace-nowrap">{row.lastAttendance ?? "—"}</td>
                  <td className="p-2 whitespace-nowrap">{row.stoppedDate}</td>
                  <td className="p-2">{row.reason || <span className="text-muted">—</span>}</td>
                  <td className="p-2 whitespace-nowrap">{row.stoppedBy}</td>
                  {canResume && (
                    <td className="p-2">
                      <button type="button" onClick={() => { setResumeTarget({ patientId: row.patientId, name: row.patientName }); setResumeError(null); }} className="rounded border border-primary px-2 py-1 text-xs text-primary hover:bg-primary-soft">
                        إلغاء الإيقاف
                      </button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
          {!rows.length && <p className="py-6 text-center text-sm text-muted">مفيش مرضى موقوف علاجهم.</p>}
        </div>
      )}

      {result?.ok && totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 text-sm">
          <button type="button" disabled={currentPage <= 1} onClick={() => goToPage(currentPage - 1)} className="rounded border border-border px-3 py-1 disabled:opacity-50">السابق</button>
          <span>صفحة {currentPage} / {totalPages}</span>
          <button type="button" disabled={currentPage >= totalPages} onClick={() => goToPage(currentPage + 1)} className="rounded border border-border px-3 py-1 disabled:opacity-50">التالي</button>
        </div>
      )}

      {resumeTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" role="dialog" aria-modal="true" aria-labelledby="resume-treatment-title">
          <div className="w-full max-w-md space-y-3 rounded-xl border border-border bg-background p-5 shadow-xl">
            <h3 id="resume-treatment-title" className="font-semibold">إلغاء إيقاف علاج {resumeTarget.name}؟</h3>
            <p className="text-xs text-muted">المريض هيرجع يتحسب في تقرير متابعة التقويم المتأخرة من تاني.</p>
            {resumeError && <p className="text-sm text-danger">{resumeError}</p>}
            <div className="flex justify-end gap-2">
              <button type="button" disabled={isPending} onClick={() => { setResumeTarget(null); setResumeError(null); }} className="rounded-md border border-border px-4 py-2 text-sm">تراجع</button>
              <button type="button" disabled={isPending} onClick={confirmResume} className="rounded-md btn-3d-primary px-4 py-2 text-sm font-medium disabled:opacity-60">{isPending ? "..." : "تأكيد إلغاء الإيقاف"}</button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
