"use client";

import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { getFrozenDebtsReportAction, settlePatientDebtAction, unfreezePatientDebtAction, type FrozenDebtsResult } from "@/app/reports/debt-freeze-actions";
import { useUrlReportParams, writeUrlReportParams } from "@/lib/url-report-state";
import ConfirmReasonDialog from "@/components/ConfirmReasonDialog";

// دفعة 145 — تقرير "مديونيات مجمدة". الصفحة في الرابط (قاعدة "رجوع").
const PAGE_SIZE = 50;
const urlKeys = ["frozen_page", "frozen_applied"];

export default function FrozenDebtsReport() {
  const router = useRouter();
  const initialUrl = useUrlReportParams(urlKeys);
  const [page, setPage] = useState(() => Math.max(1, Number(initialUrl.frozen_page) || 1));
  const [result, setResult] = useState<FrozenDebtsResult | null>(null);
  const [action, setAction] = useState<{ kind: "unfreeze" | "settle"; patientId: number; name: string; debt: number } | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  function run(nextPage = 1) {
    setPage(nextPage);
    writeUrlReportParams(router, { frozen_page: String(nextPage), frozen_applied: "1" });
    startTransition(async () => setResult(await getFrozenDebtsReportAction()));
  }
  useEffect(() => {
    if (initialUrl.frozen_applied === "1") run(Number(initialUrl.frozen_page) || 1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  function goToPage(next: number) {
    setPage(next);
    writeUrlReportParams(router, { frozen_page: String(next) });
  }
  function confirmAction(reason: string) {
    if (!action) return;
    startTransition(async () => {
      const response = action.kind === "unfreeze"
        ? await unfreezePatientDebtAction({ patientId: action.patientId })
        : await settlePatientDebtAction({ patientId: action.patientId, reason });
      if (!response.ok) { setActionError(response.error); return; }
      setAction(null); setActionError(null);
      setResult(await getFrozenDebtsReportAction());
    });
  }

  const rows = result?.ok ? result.rows : [];
  const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const pageRows = rows.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
  const showActions = result?.ok && (result.canUnfreeze || result.canSettle);

  return (
    <section className="card-3d rounded-xl p-5 space-y-4" dir="rtl">
      <div>
        <h2 className="font-semibold">مديونيات مجمدة</h2>
        <p className="mt-1 text-xs text-muted">
          مرضى مديونيتهم مجمدة — يدوي من تقرير المديونيات، أو تلقائي لأن علاجهم موقوف. مابيظهروش في قايمة المديونيات.
          التجميد اليدوي بيتفك لوحده لو اتعملت فاتورة جديدة أو موعد حضر/تم، وتجميد إيقاف العلاج بيتفك مع الإيقاف.
        </p>
      </div>
      <button type="button" onClick={() => run(1)} disabled={isPending} className="h-9 rounded-md btn-3d-primary px-4 text-sm font-medium disabled:opacity-50">
        {isPending ? "..." : "عرض التقرير"}
      </button>

      {result && !result.ok && <p className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{result.error}</p>}

      {result?.ok && result.totals && (
        <div className="flex flex-wrap gap-3">
          <div className="rounded-xl border border-sky-300/60 bg-sky-50/50 px-4 py-3 text-center">
            <div className="text-xs text-muted">مجموع المديونية المجمدة</div>
            <div className="text-2xl font-extrabold text-sky-900">{result.totals.debt.toFixed(0)} ج.م</div>
          </div>
          <div className="rounded-xl border border-border px-4 py-3 text-center">
            <div className="text-xs text-muted">عدد المرضى</div>
            <div className="text-2xl font-extrabold">{result.totals.count}</div>
          </div>
        </div>
      )}

      {result?.ok && (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-right">
                <th className="p-2">المريض</th>
                <th className="p-2 whitespace-nowrap">رقم الملف</th>
                <th className="p-2 whitespace-nowrap">المديونية</th>
                <th className="p-2 whitespace-nowrap">مجمدة من</th>
                <th className="p-2">النوع</th>
                <th className="p-2">السبب</th>
                <th className="p-2 whitespace-nowrap">بواسطة</th>
                {showActions && <th className="p-2 whitespace-nowrap">إجراءات</th>}
              </tr>
            </thead>
            <tbody>
              {pageRows.map((row) => (
                <tr key={row.patientId} className="border-b border-border">
                  <td className="p-2 font-medium"><Link href={`/patients/${row.patientId}/billing`} className="text-primary hover:underline">{row.patientName}</Link></td>
                  <td className="p-2 whitespace-nowrap">{row.fileNumber}</td>
                  <td className="p-2 whitespace-nowrap font-semibold">{row.debt.toFixed(0)} ج.م</td>
                  <td className="p-2 whitespace-nowrap">{row.since}</td>
                  <td className="p-2 whitespace-nowrap">{row.kind === "stop" ? "إيقاف علاج" : "يدوي"}</td>
                  <td className="p-2">{row.reason || <span className="text-muted">—</span>}</td>
                  <td className="p-2 whitespace-nowrap">{row.byName}</td>
                  {showActions && (
                    <td className="p-2 whitespace-nowrap space-x-1 space-x-reverse">
                      {result.canUnfreeze && row.kind === "manual" && <button type="button" onClick={() => { setAction({ kind: "unfreeze", patientId: row.patientId, name: row.patientName, debt: row.debt }); setActionError(null); }} className="rounded border border-primary px-2 py-1 text-xs text-primary hover:bg-primary-soft">فك التجميد</button>}
                      {result.canSettle && <button type="button" onClick={() => { setAction({ kind: "settle", patientId: row.patientId, name: row.patientName, debt: row.debt }); setActionError(null); }} className="rounded border border-danger/60 px-2 py-1 text-xs text-danger hover:bg-danger/5">تسوية</button>}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
          {!rows.length && <p className="py-6 text-center text-sm text-muted">مفيش مديونيات مجمدة.</p>}
        </div>
      )}

      {result?.ok && totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 text-sm">
          <button type="button" disabled={currentPage <= 1} onClick={() => goToPage(currentPage - 1)} className="rounded border border-border px-3 py-1 disabled:opacity-50">السابق</button>
          <span>صفحة {currentPage} / {totalPages}</span>
          <button type="button" disabled={currentPage >= totalPages} onClick={() => goToPage(currentPage + 1)} className="rounded border border-border px-3 py-1 disabled:opacity-50">التالي</button>
        </div>
      )}

      {action && (
        <ConfirmReasonDialog
          title={action.kind === "unfreeze" ? `فك تجميد مديونية ${action.name}؟` : `تسوية مديونية ${action.name}؟`}
          description={action.kind === "unfreeze"
            ? "المريض هيرجع يظهر في قايمة المديونيات بمديونيته."
            : <>هيتقفل الباقي كله على المريض (<b>{action.debt.toFixed(0)} ج.م</b>) من غير ما يتسجل تحصيل — الإيرادات والتحصيل مابيتغيروش. لو التسوية اتلغت، المديونية بترجع للمجمدات طول ما التجميد قائم.</>}
          withReason={action.kind === "settle"}
          confirmLabel={action.kind === "unfreeze" ? "تأكيد فك التجميد" : "تأكيد التسوية"}
          tone={action.kind === "unfreeze" ? "primary" : "danger"}
          busy={isPending}
          error={actionError}
          onConfirm={confirmAction}
          onCancel={() => { setAction(null); setActionError(null); }}
        />
      )}
    </section>
  );
}
