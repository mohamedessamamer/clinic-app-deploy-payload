"use client";

import { useState } from "react";
import { PERMISSION_DEFS, PERMISSION_GROUPS, REPORT_SUBGROUPS, ROLE_DEFAULT_PERMISSIONS, type PermissionKey } from "@/lib/permission-defs";
import { ROLE_LABELS, type Role } from "@/lib/auth";
import { updatePermissionsAction, saveDoctorReportMaxDaysAction } from "@/app/settings/actions";

type Def = (typeof PERMISSION_DEFS)[number];
const attachedTo = (def: Def): string | null => ("totalsOf" in def ? def.totalsOf : "settingOf" in def ? def.settingOf : null) ?? null;
const subgroupOf = (def: Def): string | null => ("subgroup" in def ? def.subgroup : null) ?? null;

type UserRow = {
  id: number;
  username: string;
  full_name: string;
  role: Role;
};

export default function PermissionsManager({
  users,
  overridesByUser,
  doctorReportMaxDays,
}: {
  users: UserRow[];
  overridesByUser: Record<number, Record<string, boolean>>;
  doctorReportMaxDays: string;
}) {
  // الأدمن دايمًا عنده كل الصلاحيات ومش قابلة للتعديل، فمش بنعرضه في القائمة.
  const editableUsers = users.filter((u) => u.role !== "admin");
  const [selectedId, setSelectedId] = useState<number | "">("");
  const selected = editableUsers.find((u) => u.id === selectedId);
  const overrides = selected ? overridesByUser[selected.id] || {} : {};
  const defaults = selected ? ROLE_DEFAULT_PERMISSIONS[selected.role] || [] : [];

  return (
    <div className="space-y-5">
      <form action={saveDoctorReportMaxDaysAction} className="flex items-end gap-2 flex-wrap">
        <div>
          <label className="block text-xs text-muted mb-1">
            أقصى عدد أيام رجوع بالتاريخ لتقرير الدكتور الشخصي (لمن معهوش صلاحية &quot;إيرادات كل الأطباء&quot;)
          </label>
          <input
            type="number"
            name="doctor_report_max_days"
            min={1}
            defaultValue={doctorReportMaxDays}
            className="w-32 rounded-md border border-border bg-background px-2 py-1.5 text-sm"
          />
        </div>
        <button type="submit" className="rounded-md border border-border px-3 py-1.5 text-sm hover:bg-primary-soft">
          حفظ
        </button>
      </form>

      <div>
        <label className="block text-sm text-muted mb-1">اختر مستخدم لعرض/تعديل صلاحياته</label>
        <select
          value={selectedId}
          onChange={(e) => setSelectedId(e.target.value ? Number(e.target.value) : "")}
          className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
        >
          <option value="">-- اختر مستخدم --</option>
          {editableUsers.map((u) => (
            <option key={u.id} value={u.id}>
              {u.full_name} ({ROLE_LABELS[u.role]})
            </option>
          ))}
        </select>
        {editableUsers.length === 0 && <p className="text-sm text-muted mt-2">مفيش مستخدمين تانيين لسه.</p>}
      </div>

      {selected && (
        <form key={selected.id} action={updatePermissionsAction} className="border border-border rounded-lg p-4 space-y-3">
          <input type="hidden" name="user_id" value={selected.id} />
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-medium text-sm">{selected.full_name}</span>
            <span className="text-xs text-muted">({ROLE_LABELS[selected.role]})</span>
          </div>
          <div className="permissions-groups">
            {PERMISSION_GROUPS.map((group) => {
              const isChecked = (def: Def) => def.key in overrides ? overrides[def.key] : defaults.includes(def.key as PermissionKey);
              const option = (def: Def) => (
                <label key={def.key} className="permission-option">
                  <input type="checkbox" name={`perm_${def.key}`} defaultChecked={isChecked(def)} />
                  <span><strong>{def.title}</strong><small>{def.description}</small></span>
                </label>
              );
              const groupDefs = PERMISSION_DEFS.filter((def) => def.group === group.key);
              if (group.key !== "reports") {
                return (
                  <section key={group.key} className="permissions-group">
                    <h3>{group.label}</h3>
                    <div className="permissions-group-grid">{groupDefs.map(option)}</div>
                  </section>
                );
              }
              // دفعة 143: التقارير بعناوين فرعية، وصلاحية الإجماليات/الإعداد
              // التابعة لكل تقرير بتظهر جوه نفس الكارت تحته.
              return (
                <section key={group.key} className="permissions-group">
                  <h3>{group.label}</h3>
                  {REPORT_SUBGROUPS.map((sub) => {
                    const mains = groupDefs.filter((def) => subgroupOf(def) === sub.key && !attachedTo(def));
                    return (
                      <div key={sub.key} className="permissions-subgroup">
                        <h4>{sub.label}</h4>
                        <div className="permissions-group-grid">
                          {mains.map((main) => {
                            const children = groupDefs.filter((def) => attachedTo(def) === main.key);
                            return (
                              <div key={main.key} className="permission-card">
                                <label className="flex items-start gap-2">
                                  <input type="checkbox" name={`perm_${main.key}`} defaultChecked={isChecked(main)} />
                                  <span><strong>{main.title}</strong><small>{main.description}</small></span>
                                </label>
                                {children.map((child) => (
                                  <label key={child.key} className="ms-6 flex items-start gap-2 rounded-md border border-border/60 bg-primary-soft/20 px-2 py-1.5 text-xs">
                                    <input type="checkbox" name={`perm_${child.key}`} defaultChecked={isChecked(child)} />
                                    <span><strong>{"totalsOf" in child ? "↳ " : "⚙ "}{child.title}</strong><small className="block text-muted">{child.description}</small></span>
                                  </label>
                                ))}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </section>
              );
            })}
          </div>
          <button type="submit" className="rounded-md border border-border px-3 py-1.5 text-xs hover:bg-primary-soft">
            حفظ صلاحيات {selected.full_name}
          </button>
        </form>
      )}
    </div>
  );
}
