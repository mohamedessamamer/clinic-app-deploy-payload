"use client";

import { useState } from "react";

// دفعة 145: رسالة تأكيد موحّدة للإجراءات الحساسة في التقارير (تجميد، فك تجميد،
// تسوية، إلغاء تسوية). فيها سبب اختياري لو withReason، و"تراجع" بيقفلها من غير
// ما يحصل أي حاجة — عشان محدش يضغط بالغلط.
export default function ConfirmReasonDialog({
  title,
  description,
  withReason = false,
  confirmLabel,
  tone = "primary",
  busy,
  error,
  onConfirm,
  onCancel,
}: {
  title: string;
  description?: React.ReactNode;
  withReason?: boolean;
  confirmLabel: string;
  tone?: "primary" | "amber" | "danger";
  busy: boolean;
  error: string | null;
  onConfirm: (reason: string) => void;
  onCancel: () => void;
}) {
  const [reason, setReason] = useState("");
  const confirmClass = tone === "danger" ? "bg-danger text-white" : tone === "amber" ? "bg-amber-600 text-white" : "btn-3d-primary";
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" role="dialog" aria-modal="true" aria-label={title}>
      <div className="w-full max-w-md space-y-3 rounded-xl border border-border bg-background p-5 shadow-xl" dir="rtl">
        <h3 className="font-semibold">{title}</h3>
        {description && <div className="text-xs text-muted">{description}</div>}
        {withReason && (
          <label className="block text-sm">السبب (اختياري)
            <textarea value={reason} onChange={(e) => setReason(e.target.value)} maxLength={300} rows={3} className="mt-1 block w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
          </label>
        )}
        {error && <p className="text-sm text-danger">{error}</p>}
        <div className="flex justify-end gap-2">
          <button type="button" disabled={busy} onClick={onCancel} className="rounded-md border border-border px-4 py-2 text-sm">تراجع</button>
          <button type="button" disabled={busy} onClick={() => onConfirm(reason)} className={`rounded-md px-4 py-2 text-sm font-medium disabled:opacity-60 ${confirmClass}`}>{busy ? "..." : confirmLabel}</button>
        </div>
      </div>
    </div>
  );
}
