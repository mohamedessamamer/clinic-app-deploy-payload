"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { getClinicToday } from "@/lib/clinic-date";
import { uploadPatientFiles, type PatientUploadProgress } from "@/lib/patient-file-upload";

export default function AddImageGroupForm({ patientId, language = "en" }: { patientId: number; language?: "en" | "ar" }) {
  const router = useRouter();
  const today = useMemo(() => getClinicToday(), []);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<File[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState<PatientUploadProgress | null>(null);
  const [error, setError] = useState("");
  // Batch 127: أسماء الملفات اللي اتكشفت مكررة (نفس صورة موجودة قبل كده لنفس
  // المريض) ومااترفعتش — بتتعرض كرسالة بعد الرفع، مش خطأ يوقف الباقي.
  const [duplicateNotice, setDuplicateNotice] = useState("");
  const en = language === "en";

  // Batch 126: معاينة مصغّرة حقيقية للملفات قبل الرفع بدل الاسم بس.
  const [previews, setPreviews] = useState<{ name: string; url: string | null }[]>([]);
  const previewsRef = useRef(previews);
  useEffect(() => { previewsRef.current = previews; }, [previews]);
  useEffect(() => () => { for (const item of previewsRef.current) if (item.url) URL.revokeObjectURL(item.url); }, []);

  function releasePreviews() {
    setPreviews((prev) => { for (const item of prev) if (item.url) URL.revokeObjectURL(item.url); return []; });
  }

  function chooseFiles(selected: FileList | File[]) {
    const list = Array.from(selected);
    releasePreviews();
    setFiles(list);
    setPreviews(list.map((file) => ({ name: file.name, url: file.type.startsWith("image/") ? URL.createObjectURL(file) : null })));
    setError("");
  }

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!files.length || uploading) return;
    const form = new FormData(event.currentTarget);
    setUploading(true);
    setError("");
    setDuplicateNotice("");
    try {
      const result = await uploadPatientFiles({
        patientId,
        takenAt: String(form.get("taken_at") || today),
        label: String(form.get("label") || ""),
        files,
        onProgress: setProgress,
      });
      if (result.duplicates.length) {
        setDuplicateNotice(
          en
            ? (result.duplicates.length === 1
                ? `"${result.duplicates[0]}" already exists for this patient — not uploaded.`
                : `${result.duplicates.length} files already exist for this patient and were not uploaded: ${result.duplicates.join(", ")}`)
            : (result.duplicates.length === 1
                ? `صورة "${result.duplicates[0]}" موجودة قبل كده لنفس المريض — مااترفعتش.`
                : `${result.duplicates.length} صور موجودة قبل كده لنفس المريض ومااترفعتش: ${result.duplicates.join("، ")}`)
        );
      }
      setFiles([]);
      releasePreviews();
      setProgress(null);
      if (fileInputRef.current) fileInputRef.current.value = "";
      router.refresh();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : (en ? "Upload failed." : "فشل رفع الملف."));
    } finally {
      setUploading(false);
    }
  }

  return (
    <form onSubmit={submit} className="flex flex-wrap items-end gap-2 border-t border-dashed border-border pt-3 mt-1">
      <div>
        <label className="block text-xs text-muted mb-1">{en ? "Date" : "التاريخ"}</label>
        <input type="date" name="taken_at" defaultValue={today} required className="rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">{en ? "Description (optional)" : "وصف (اختياري)"}</label>
        <input name="label" placeholder={en ? "Example: panoramic X-ray" : "مثال: أشعة بانوراما"} className="rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
      </div>
      <div className="flex-1 min-w-[240px]">
        <label className="block text-xs text-muted mb-1">{en ? "Photos / X-rays" : "الصور/الأشعة"}</label>
        <div
          role="button"
          tabIndex={0}
          onClick={() => !uploading && fileInputRef.current?.click()}
          onKeyDown={(event) => { if (!uploading && (event.key === "Enter" || event.key === " ")) fileInputRef.current?.click(); }}
          onDragOver={(event) => { event.preventDefault(); setIsDragging(true); }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={(event) => { event.preventDefault(); setIsDragging(false); chooseFiles(event.dataTransfer.files); }}
          className={`rounded-md border-2 border-dashed px-3 py-2.5 text-xs text-center cursor-pointer transition-colors ${isDragging ? "border-primary bg-primary-soft" : "border-border hover:bg-primary-soft/40"}`}
        >
          {uploading && progress ? (
            <span className="text-primary-dark font-medium">{en ? `Uploading ${progress.current}/${progress.total}: ${progress.fileName}` : `جاري رفع ${progress.current}/${progress.total}: ${progress.fileName}`}</span>
          ) : files.length ? (
            <span className="text-primary-dark font-medium">{en ? `${files.length} file(s) selected — ` : `${files.length} صورة/ملف محدد — `}{files.slice(0, 2).map((file) => file.name).join("، ")}{files.length > 2 ? "…" : ""}</span>
          ) : (
            <span className="text-muted">{en ? "Drag files here or click to select. Files upload one by one without compression." : "اسحب الملفات هنا أو اضغط للاختيار. يتم الرفع ملفًا ملفًا بدون ضغط."}</span>
          )}
          <input ref={fileInputRef} type="file" multiple accept="image/*,.pdf" onChange={(event) => { if (event.target.files) chooseFiles(event.target.files); }} className="hidden" />
        </div>
        {previews.length > 0 && (
          <div className="mt-2 flex gap-2 overflow-x-auto pb-1">
            {previews.map((item, index) => (
              <div key={`${item.name}-${index}`} className="h-16 w-16 shrink-0 overflow-hidden rounded-md border border-border bg-background">
                {item.url ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={item.url} alt={item.name} className="h-full w-full object-cover" />
                ) : (
                  <div className="flex h-full w-full items-center justify-center p-1 text-center text-[10px] text-muted break-all">{item.name}</div>
                )}
              </div>
            ))}
          </div>
        )}
        {error && <p className="mt-1 text-xs text-danger">{error}</p>}
        {duplicateNotice && <p className="mt-1 text-xs text-muted">{duplicateNotice}</p>}
      </div>
      <button type="submit" disabled={uploading || files.length === 0} className="rounded-md btn-3d-primary px-4 py-1.5 text-sm font-medium transition-colors disabled:opacity-60">
        {uploading ? (en ? "Uploading…" : "جاري الرفع…") : (en ? "+ Add group" : "+ إضافة مجموعة")}
      </button>
    </form>
  );
}
