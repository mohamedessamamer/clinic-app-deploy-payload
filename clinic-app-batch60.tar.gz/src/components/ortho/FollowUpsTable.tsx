"use client";

// شارت التقويم v2 — "Follow ups" (النسخة الحقيقية، دمج 2026-08-27). نفس
// السلوك بالظبط اللي كان في البروتوتايب المعزول: خدمة الـBonding بتتقفل
// نهائيًا بمجرد ما تتطبق، الوير لازم مقاس ونوع مع بعض أو Same/فاضي، زرار Save
// واحد بيطبق كل حاجة مرة واحدة، وزرار Edit بعد الحفظ (لو معاك الصلاحية) بيفتح
// باقي الحقول تاني من غير الـService. الفرق: الزيارات دلوقتي صفوف حقيقية في
// ortho_visits — "+ New visit" بيضيف صف مسودة محلي (draft-...) لحد ما تدوس
// Save، وبعدها بيتحول لصف حقيقي بمعرف رقمي حقيقي.

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { saveOrthoVisitAction, deleteOrthoVisitAction } from "@/app/patients/[id]/orthodontics/ortho-v2-actions";
import { elastomericColorForItemName } from "@/lib/ortho/elastomeric-colors";

const MOCK_SERVICES = ["Follow up", "Bonding Upper", "Bonding Lower", "Debonding", "Retainer delivery", "Consultation"];

export interface OrthoDoctorOption {
  id: number;
  full_name: string;
}

export interface OrthoOptionLists {
  wireSizes: string[];
  wireTypes: string[];
  otieColors: string[];
  elasticSizes: string[];
}

// الصنف الفعلي من مخزن التقويم، وليس اسمًا حرًا أو قيمة من قائمة مستقلة.
export interface OrthoStockItem {
  id: number;
  name: string;
  quantity: number;
  unit: string | null;
  usage: "wire" | "bracket" | "tube" | "elastic" | "otie" | "power_chain" | "button" | "compressed_coil";
}

export interface OrthoVisitRow {
  id: number;
  date: string;
  service: string;
  upperSize: string;
  upperType: string;
  lowerSize: string;
  lowerType: string;
  note: string;
  elasticsDispensed: boolean;
  elasticsSize: string;
  otieColor: string;
  powerChainQty: string;
  buttonsQty: string;
  compressedCoilMm: string;
  upperWireItemId: number | null;
  lowerWireItemId: number | null;
  elasticItemId: number | null;
  otieItemId: number | null;
  powerChainItemId: number | null;
  buttonsItemId: number | null;
  compressedCoilItemId: number | null;
  bondingBracketItemId: number | null;
  bondingBracketBrand: string | null;
  bondingTubeItemId: number | null;
  doctorId: number | null;
  bondingApplied: boolean;
}

interface DraftRow {
  id: string; // "draft-..."
  date: string;
  service: string;
  upperSize: string;
  upperType: string;
  lowerSize: string;
  lowerType: string;
  note: string;
  elasticsDispensed: boolean;
  elasticsSize: string;
  otieColor: string;
  powerChainQty: string;
  buttonsQty: string;
  compressedCoilMm: string;
  upperWireItemId: number | null;
  lowerWireItemId: number | null;
  elasticItemId: number | null;
  otieItemId: number | null;
  powerChainItemId: number | null;
  buttonsItemId: number | null;
  compressedCoilItemId: number | null;
  bondingBracketItemId: number | null;
  bondingBracketBrand: string | null;
  bondingTubeItemId: number | null;
  doctorId: number | null;
  upperSizeInvalid: boolean;
  upperTypeInvalid: boolean;
  lowerSizeInvalid: boolean;
  lowerTypeInvalid: boolean;
  doctorMissing: boolean;
}

function todayStr(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function makeDraftRow(defaultDoctorId: number | null): DraftRow {
  return {
    id: `draft-${Date.now()}-${Math.random()}`,
    date: "",
    service: "",
    upperSize: "",
    upperType: "",
    lowerSize: "",
    lowerType: "",
    note: "",
    elasticsDispensed: false,
    elasticsSize: "",
    otieColor: "",
    powerChainQty: "",
    buttonsQty: "",
    compressedCoilMm: "",
    upperWireItemId: null,
    lowerWireItemId: null,
    elasticItemId: null,
    otieItemId: null,
    powerChainItemId: null,
    buttonsItemId: null,
    compressedCoilItemId: null,
    bondingBracketItemId: null,
    bondingBracketBrand: null,
    bondingTubeItemId: null,
    doctorId: defaultDoctorId,
    upperSizeInvalid: false,
    upperTypeInvalid: false,
    lowerSizeInvalid: false,
    lowerTypeInvalid: false,
    doctorMissing: false,
  };
}

function AutoGrowTextarea({
  value,
  onChange,
  placeholder,
  disabled = false,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  disabled?: boolean;
}) {
  return (
    <textarea
      value={value}
      onChange={(e) => {
        onChange(e.target.value);
        e.target.style.height = "auto";
        e.target.style.height = `${e.target.scrollHeight}px`;
      }}
      placeholder={placeholder}
      rows={1}
      disabled={disabled}
      className="w-full min-w-0 resize-none overflow-hidden rounded-md border border-border bg-background px-2 py-1 text-sm font-bold disabled:opacity-60 disabled:cursor-not-allowed"
    />
  );
}

function Dropdown({
  value,
  onChange,
  options,
  placeholder = "—",
  className = "",
  disabled = false,
  error = false,
}: {
  value: string;
  onChange: (v: string) => void;
  options: string[];
  placeholder?: string;
  className?: string;
  disabled?: boolean;
  error?: boolean;
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      disabled={disabled}
      className={`rounded-md border bg-background px-1.5 py-1 text-xs disabled:opacity-60 disabled:cursor-not-allowed ${
        error ? "border-red-500 ring-1 ring-red-500" : "border-border"
      } ${className}`}
    >
      <option value="">{placeholder}</option>
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  );
}

function StockDropdown({
  value,
  onChange,
  items,
  placeholder,
  disabled = false,
}: {
  value: number | null;
  onChange: (id: number | null) => void;
  items: OrthoStockItem[];
  placeholder: string;
  disabled?: boolean;
}) {
  return (
    <select value={value ?? ""} onChange={(event) => onChange(event.target.value ? Number(event.target.value) : null)} disabled={disabled} className="rounded-md border border-border bg-background px-1.5 py-1 text-xs disabled:opacity-60 disabled:cursor-not-allowed max-w-[150px]">
      <option value="">{placeholder}</option>
      {items.map((item) => <option key={item.id} value={item.id}>{item.name} ({item.quantity} {item.unit ?? ""})</option>)}
    </select>
  );
}

// قائمة ألوان خاصة بدل الـselect التقليدي: يظهر الاسم بلونه الحقيقي والكود
// بجانبه، فتظل الألوان المتقاربة قابلة للتمييز أثناء اختيار O-tie.
function ColorStockDropdown({ value, onChange, items, disabled = false }: {
  value: number | null;
  onChange: (id: number | null) => void;
  items: OrthoStockItem[];
  disabled?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const selected = items.find((item) => item.id === value) ?? null;
  const selectedColor = selected ? elastomericColorForItemName(selected.name) : null;
  return <div className="relative">
    <button type="button" disabled={disabled} onClick={() => setOpen((current) => !current)} className="min-w-32 rounded-md border border-border bg-background px-2 py-1 text-left text-xs disabled:opacity-60 disabled:cursor-not-allowed flex items-center gap-1.5">
      {selectedColor ? <><span className="h-3 w-3 rounded-full border border-black/20 shrink-0" style={{ backgroundColor: selectedColor.hex }} /><span className="font-medium" style={{ color: selectedColor.hex }}>{selectedColor.name}</span><span className="text-[10px] text-muted">({selectedColor.code})</span></> : <span className="text-muted">Select color</span>}
    </button>
    {open && !disabled && <div className="absolute z-30 mt-1 max-h-56 w-56 overflow-y-auto rounded-md border border-border bg-background p-1 shadow-lg">
      <button type="button" onClick={() => { onChange(null); setOpen(false); }} className="w-full rounded px-2 py-1.5 text-left text-xs text-muted hover:bg-primary-soft">Clear selection</button>
      {items.map((item) => {
        const color = elastomericColorForItemName(item.name);
        return <button key={item.id} type="button" onClick={() => { onChange(item.id); setOpen(false); }} className="w-full rounded px-2 py-1.5 text-left text-xs hover:bg-primary-soft flex items-center gap-2">
          <span className="h-3 w-3 rounded-full border border-black/20 shrink-0" style={{ backgroundColor: color?.hex ?? "#94a3b8" }} />
          <span className="font-medium" style={{ color: color?.hex ?? undefined }}>{color?.name ?? item.name}</span>
          {color && <span className="text-[10px] text-muted">({color.code})</span>}
          <span className="ml-auto text-[10px] text-muted">{item.quantity} {item.unit ?? ""}</span>
        </button>;
      })}
    </div>}
  </div>;
}

export default function FollowUpsTable({
  patientId,
  editable,
  canEditAfterSave,
  canDeleteVisit,
  defaultDoctorId,
  doctors,
  stockItems,
  activeBracketCount,
  visits,
}: {
  patientId: number;
  editable: boolean;
  canEditAfterSave: boolean;
  canDeleteVisit: boolean;
  defaultDoctorId: number | null;
  doctors: OrthoDoctorOption[];
  stockItems: OrthoStockItem[];
  activeBracketCount: number;
  visits: OrthoVisitRow[];
}) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [drafts, setDrafts] = useState<DraftRow[]>([]);
  const [unlockedIds, setUnlockedIds] = useState<Set<number>>(new Set());
  const [editBuffers, setEditBuffers] = useState<Record<number, OrthoVisitRow>>({});

  function addVisit() {
    setDrafts((prev) => [makeDraftRow(defaultDoctorId), ...prev]);
  }

  function patchDraft(id: string, patch: Partial<DraftRow>) {
    setDrafts((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  }

  function onWireChangeDraft(id: string, patch: Partial<DraftRow>) {
    const clears: Partial<DraftRow> = {};
    if ("upperSize" in patch || "upperType" in patch) {
      clears.upperSizeInvalid = false;
      clears.upperTypeInvalid = false;
    }
    if ("lowerSize" in patch || "lowerType" in patch) {
      clears.lowerSizeInvalid = false;
      clears.lowerTypeInvalid = false;
    }
    patchDraft(id, { ...patch, ...clears });
  }

  function startEdit(v: OrthoVisitRow) {
    setEditBuffers((prev) => ({ ...prev, [v.id]: { ...v } }));
    setUnlockedIds((prev) => new Set(prev).add(v.id));
  }

  function patchEditBuffer(id: number, patch: Partial<OrthoVisitRow>) {
    setEditBuffers((prev) => ({ ...prev, [id]: { ...prev[id], ...patch } }));
  }

  function validateWire() {
    return {
      upperSizeInvalid: false,
      upperTypeInvalid: false,
      lowerSizeInvalid: false,
      lowerTypeInvalid: false,
    };
  }

  function saveDraft(id: string) {
    const r = drafts.find((row) => row.id === id);
    if (!r) return;
    const invalid = validateWire();
    const doctorMissing = !r.doctorId;
    if (invalid.upperSizeInvalid || invalid.upperTypeInvalid || invalid.lowerSizeInvalid || invalid.lowerTypeInvalid || doctorMissing) {
      patchDraft(id, { ...invalid, doctorMissing });
      return;
    }
    const date = r.date || todayStr();
    startTransition(async () => {
      const res = await saveOrthoVisitAction({
        patientId,
        date,
        service: r.service,
        upperWireSize: r.upperSize,
        upperWireType: r.upperType,
        lowerWireSize: r.lowerSize,
        lowerWireType: r.lowerType,
        note: r.note,
        elasticsDispensed: r.elasticsDispensed,
        elasticsSize: r.elasticsSize,
        otieColor: r.otieColor,
        powerChainQty: r.powerChainQty,
        buttonsQty: r.buttonsQty,
        compressedCoilMm: r.compressedCoilMm,
        upperWireItemId: r.upperWireItemId,
        lowerWireItemId: r.lowerWireItemId,
        elasticItemId: r.elasticItemId,
        otieItemId: r.otieItemId,
        powerChainItemId: r.powerChainItemId,
        buttonsItemId: r.buttonsItemId,
        compressedCoilItemId: r.compressedCoilItemId,
        bondingBracketItemId: r.bondingBracketItemId,
        bondingBracketBrand: r.bondingBracketBrand,
        bondingTubeItemId: r.bondingTubeItemId,
        doctorId: r.doctorId,
      });
      if (!res.ok) {
        window.alert(res.reason || "حصل خطأ، حاول تاني.");
        return;
      }
      setDrafts((prev) => prev.filter((row) => row.id !== id));
      router.refresh();
    });
  }

  function saveEdit(id: number) {
    const r = editBuffers[id];
    if (!r) return;
    const invalid = validateWire();
    if (invalid.upperSizeInvalid || invalid.upperTypeInvalid || invalid.lowerSizeInvalid || invalid.lowerTypeInvalid) {
      window.alert("Wire needs both a size and a type — or leave it as \"Same\"");
      return;
    }
    if (!r.doctorId) {
      window.alert("Please select a doctor before saving");
      return;
    }
    startTransition(async () => {
      const res = await saveOrthoVisitAction({
        patientId,
        visitId: id,
        date: r.date || todayStr(),
        service: r.service,
        upperWireSize: r.upperSize,
        upperWireType: r.upperType,
        lowerWireSize: r.lowerSize,
        lowerWireType: r.lowerType,
        note: r.note,
        elasticsDispensed: r.elasticsDispensed,
        elasticsSize: r.elasticsSize,
        otieColor: r.otieColor,
        powerChainQty: r.powerChainQty,
        buttonsQty: r.buttonsQty,
        compressedCoilMm: r.compressedCoilMm,
        upperWireItemId: r.upperWireItemId,
        lowerWireItemId: r.lowerWireItemId,
        elasticItemId: r.elasticItemId,
        otieItemId: r.otieItemId,
        powerChainItemId: r.powerChainItemId,
        buttonsItemId: r.buttonsItemId,
        compressedCoilItemId: r.compressedCoilItemId,
        bondingBracketItemId: r.bondingBracketItemId,
        bondingBracketBrand: r.bondingBracketBrand,
        bondingTubeItemId: r.bondingTubeItemId,
        doctorId: r.doctorId,
      });
      if (!res.ok) {
        window.alert(res.reason || "حصل خطأ، حاول تاني.");
        return;
      }
      setUnlockedIds((prev) => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
      router.refresh();
    });
  }

  // حذف زيارة بالكامل — دفعة 27، بصلاحية delete_visits (نفس صلاحية حذف زيارات
  // الملف الطبي العادي). السيرفر بيرجّع أي خصم مخزون/تغيير حالة أسنان اتسبب
  // فيه (شوف deleteOrthoVisitAction).
  function deleteVisit(v: OrthoVisitRow) {
    const ok = window.confirm(
      v.bondingApplied
        ? "Delete this visit entirely? This will also revert the bonding it applied (tooth states + inventory) for any tooth still attributed to it. This can't be undone."
        : "Delete this visit entirely? Any inventory it consumed (elastics/O-ties/power chain/etc) will be refunded. This can't be undone."
    );
    if (!ok) return;
    startTransition(async () => {
      const res = await deleteOrthoVisitAction({ patientId, visitId: v.id });
      if (!res.ok) {
        window.alert(res.reason || "حصل خطأ، حاول تاني.");
        return;
      }
      router.refresh();
    });
  }

  const allRows: Array<{ kind: "draft"; row: DraftRow } | { kind: "saved"; row: OrthoVisitRow }> = [
    ...drafts.map((row) => ({ kind: "draft" as const, row })),
    ...visits.map((row) => ({ kind: "saved" as const, row })),
  ];
  const previousVisitCards = visits.slice(0, 5);

  return (
    <div className={`card-3d rounded-xl p-5 space-y-3 ${isPending ? "opacity-70 pointer-events-none" : ""}`}>
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h3 className="font-bold">Follow ups</h3>
        {editable && (
          <button
            type="button"
            onClick={addVisit}
            className="text-xs px-3 py-1.5 rounded-md border border-dashed border-border hover:bg-primary-soft text-muted"
          >
            + New visit
          </button>
        )}
      </div>

      {previousVisitCards.length > 0 && (
        <section className="ortho-previous-visits" aria-label="Previous visits">
          <div className="flex items-center justify-between">
            <h4>Previous visits</h4>
            <span>{visits.length} recorded</span>
          </div>
          <div className="ortho-previous-visits-grid">
            {previousVisitCards.map((visit) => {
              const doctor = doctors.find((item) => item.id === visit.doctorId)?.full_name;
              return (
                <article key={visit.id} className="ortho-previous-visit-card">
                  <div className="flex items-center justify-between gap-2">
                    <strong>{visit.date}</strong>
                    <span>{visit.service || "Visit"}</span>
                  </div>
                  {(visit.upperSize || visit.lowerSize) && <p>U: {visit.upperSize || "—"} · L: {visit.lowerSize || "—"}</p>}
                  <p className="ortho-previous-free-text">{visit.note?.trim() || "No free text recorded."}</p>
                  {doctor && <small>{doctor}</small>}
                </article>
              );
            })}
          </div>
        </section>
      )}

      {allRows.length === 0 && <p className="text-xs text-muted">No visits recorded yet.</p>}

      <div>
        {allRows.map((entry, idx) => {
          const isDraft = entry.kind === "draft";
          const saved = entry.kind === "saved";
          const unlocked = saved && unlockedIds.has(entry.row.id);
          const locked = saved && !unlocked;
          const r = isDraft ? entry.row : unlocked ? editBuffers[entry.row.id] ?? entry.row : entry.row;
          const bondingApplied = saved && entry.row.bondingApplied;

          const patch = (p: Record<string, unknown>) => {
            if (isDraft) patchDraft(entry.row.id, p);
            else if (unlocked) patchEditBuffer(entry.row.id, p);
          };
          const patchWire = (p: Record<string, unknown>) => {
            if (isDraft) onWireChangeDraft(entry.row.id, p);
            else if (unlocked) patchEditBuffer(entry.row.id, p);
          };
          const fieldsDisabled = !editable || (saved && !unlocked);
          const wireErrors = isDraft ? entry.row : { upperSizeInvalid: false, upperTypeInvalid: false, lowerSizeInvalid: false, lowerTypeInvalid: false };
          const powerChainPieces = Math.max(0, Number(r.powerChainQty) || 0);
          const calculatedOtieQty = Math.max(0, activeBracketCount - powerChainPieces);
          const otieColor = r.otieItemId ? elastomericColorForItemName(stockItems.find((item) => item.id === r.otieItemId)?.name ?? "") : null;

          return (
            <div key={isDraft ? entry.row.id : `v-${entry.row.id}`}>
              {idx > 0 && <div className="my-3 border-t-2 border-dashed border-border" />}
              <div className={`rounded-lg border border-border p-3 space-y-2 ${locked ? "bg-primary-soft/20" : ""}`}>
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <div className="flex items-center gap-3 flex-wrap">
                    <input
                      type="date"
                      value={r.date}
                      disabled={fieldsDisabled}
                      onChange={(e) => patch({ date: e.target.value })}
                      className="text-xs px-2 py-1 rounded-md border border-border disabled:opacity-60 disabled:cursor-not-allowed"
                    />
                    <Dropdown
                      value={r.service}
                      onChange={(v) => patch({ service: v })}
                      options={MOCK_SERVICES}
                      placeholder="Service"
                      disabled={fieldsDisabled || bondingApplied}
                      className="!text-sm !font-bold"
                    />

                    {(r.service === "Bonding Upper" || r.service === "Bonding Lower") && (
                      <>
                        <select value={r.bondingBracketBrand ?? ""} onChange={(event) => patch({ bondingBracketBrand: event.target.value || null })} disabled={fieldsDisabled || bondingApplied} className="rounded-md border border-border bg-background px-2 py-1 text-xs disabled:opacity-60">
                          <option value="">Select Bracket Company</option><option value="American">American</option><option value="Ormco">Ormco</option>
                        </select>
                        <span className="rounded-md border border-border bg-primary-soft px-2 py-1 text-xs text-muted">Tube: automatic</span>
                      </>
                    )}

                    <div className="flex items-center gap-1.5 text-sm">
                      <span className="font-bold text-foreground w-4 shrink-0">U</span>
                      <StockDropdown value={r.upperWireItemId} onChange={(id) => { const item = stockItems.find((entry) => entry.id === id); patchWire({ upperWireItemId: id, upperSize: item?.name ?? "", upperType: "" }); }} items={stockItems.filter((item) => item.usage === "wire")} placeholder="Select Wire" disabled={fieldsDisabled} />
                    </div>
                    <div className="flex items-center gap-1.5 text-sm">
                      <span className="font-bold text-foreground w-4 shrink-0">L</span>
                      <StockDropdown value={r.lowerWireItemId} onChange={(id) => { const item = stockItems.find((entry) => entry.id === id); patchWire({ lowerWireItemId: id, lowerSize: item?.name ?? "", lowerType: "" }); }} items={stockItems.filter((item) => item.usage === "wire")} placeholder="Select Wire" disabled={fieldsDisabled} />
                    </div>
                  </div>
                  <select
                    value={r.doctorId != null ? String(r.doctorId) : ""}
                    onChange={(e) => patch({ doctorId: e.target.value ? Number(e.target.value) : null, doctorMissing: false })}
                    disabled={fieldsDisabled}
                    className={`rounded-md border bg-background px-1.5 py-1 text-xs disabled:opacity-60 disabled:cursor-not-allowed min-w-[110px] ${
                      "doctorMissing" in wireErrors && wireErrors.doctorMissing ? "border-red-500 ring-1 ring-red-500" : "border-border"
                    }`}
                  >
                    <option value="">Doctor</option>
                    {doctors.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.full_name}
                      </option>
                    ))}
                  </select>
                </div>

                <AutoGrowTextarea value={r.note} onChange={(v) => patch({ note: v })} placeholder="e.g.: retraction 13 & 23" disabled={fieldsDisabled} />

                <div className="flex items-center gap-2 flex-wrap xl:flex-nowrap text-xs pt-1 border-t border-border">
                  <label className="flex items-center gap-1.5">
                    <input
                      type="checkbox"
                      checked={r.elasticsDispensed}
                      disabled={fieldsDisabled}
                      onChange={(e) => patch({ elasticsDispensed: e.target.checked, elasticsSize: e.target.checked ? r.elasticsSize : "" })}
                    />
                    Elastics dispensed
                    {r.elasticsDispensed && (
                      <StockDropdown value={r.elasticItemId} onChange={(id) => { const item = stockItems.find((entry) => entry.id === id); patch({ elasticItemId: id, elasticsSize: item?.name ?? "" }); }} items={stockItems.filter((item) => item.usage === "elastic")} placeholder="Select Elastic" disabled={fieldsDisabled} />
                    )}
                  </label>
                  {/* دي كانت whitespace-nowrap — طلعت الصف ده كله كتلة واحدة
                      مش قابلة للف بالنسبة للحاوية الأكبر (flex-wrap فوق)،
                      فبتفيض برة حدود الكارت على شاشة ضيقة (O-tie/Power
                      chain/Buttons/Compressed coil بتتقطع). flex-wrap هنا
                      بدل منها يخلي كل حقل يقدر يقع سطر لوحده لو المساحة
                      ضاقت، بدون ما يأثر على العرض العادي (desktop) لأن
                      المساحة أصلاً كافية فمش هيحصل لف. */}
                  <div className="flex items-center gap-2 flex-wrap xl:flex-nowrap">
                    <label className="flex items-center gap-1.5">
                      O-tie
                      <ColorStockDropdown value={r.otieItemId} onChange={(id) => { const item = stockItems.find((entry) => entry.id === id); patch({ otieItemId: id, otieColor: item?.name ?? "", powerChainItemId: null }); }} items={stockItems.filter((item) => item.usage === "otie")} disabled={fieldsDisabled} />
                      <input value={r.otieItemId ? calculatedOtieQty : ""} readOnly aria-label="Calculated O-tie pieces" placeholder="Auto" title={`${activeBracketCount} active brackets − ${powerChainPieces} power-chain pieces`} className="w-12 rounded-md border border-primary/40 bg-primary-soft px-1 py-1 text-center text-xs font-semibold" />
                    </label>
                    <label className="flex items-center gap-1.5">
                      Power chain
                      <span className="min-w-28 rounded-md border border-border bg-primary-soft px-2 py-1 text-xs flex items-center gap-1" title="لون الـPower chain يتبع لون الـO-tie تلقائياً">
                        {otieColor ? <><span className="h-3 w-3 rounded-full border border-black/20" style={{ backgroundColor: otieColor.hex }} /><span style={{ color: otieColor.hex }}>{otieColor.name}</span><span className="text-[10px] text-muted">({otieColor.code})</span></> : <span className="text-muted">Same as O-tie</span>}
                      </span>
                      <input
                        type="number"
                        min={0}
                        value={r.powerChainQty}
                        disabled={fieldsDisabled}
                        onChange={(e) => patch({ powerChainQty: e.target.value })}
                        placeholder="0"
                        className="w-12 rounded-md border border-border bg-background px-1 py-1 text-xs disabled:opacity-60 disabled:cursor-not-allowed"
                      />
                    </label>
                    <label className="flex items-center gap-1.5">
                      Buttons
                      <StockDropdown value={r.buttonsItemId} onChange={(id) => patch({ buttonsItemId: id })} items={stockItems.filter((item) => item.usage === "button")} placeholder="Select Button" disabled={fieldsDisabled} />
                      <input
                        type="number"
                        min={0}
                        value={r.buttonsQty}
                        disabled={fieldsDisabled}
                        onChange={(e) => patch({ buttonsQty: e.target.value })}
                        placeholder="0"
                        className="w-12 rounded-md border border-border bg-background px-1 py-1 text-xs disabled:opacity-60 disabled:cursor-not-allowed"
                      />
                    </label>
                    <label className="flex items-center gap-1.5">
                      Coil (mm)
                      <StockDropdown value={r.compressedCoilItemId} onChange={(id) => patch({ compressedCoilItemId: id })} items={stockItems.filter((item) => item.usage === "compressed_coil")} placeholder="Select Coil" disabled={fieldsDisabled} />
                      <input
                        type="number"
                        min={0}
                        value={r.compressedCoilMm}
                        disabled={fieldsDisabled}
                        onChange={(e) => patch({ compressedCoilMm: e.target.value })}
                        placeholder="0"
                        className="w-12 rounded-md border border-border bg-background px-1 py-1 text-xs disabled:opacity-60 disabled:cursor-not-allowed"
                      />
                    </label>
                  </div>

                  {isDraft && (wireErrors.upperSizeInvalid || wireErrors.upperTypeInvalid || wireErrors.lowerSizeInvalid || wireErrors.lowerTypeInvalid) && (
                    <span className="text-red-600 text-xs">Wire needs both a size and a type — or leave it as &quot;Same&quot;</span>
                  )}
                  {isDraft && "doctorMissing" in wireErrors && wireErrors.doctorMissing && (
                    <span className="text-red-600 text-xs">Please select a doctor before saving</span>
                  )}

                  {editable && isDraft && (
                    <button type="button" onClick={() => saveDraft(entry.row.id)} className="ml-auto px-3 py-1.5 rounded-md text-xs font-medium shrink-0 btn-3d-primary">
                      Save
                    </button>
                  )}
                  {saved && locked && (
                    <div className="ml-auto flex items-center gap-2 shrink-0">
                      <span className="px-3 py-1.5 rounded-md text-xs font-medium border border-green-300 bg-green-50 text-green-700 cursor-default" title="This visit is saved">
                        ✓ Saved
                      </span>
                      {editable && canEditAfterSave && (
                        <button
                          type="button"
                          onClick={() => startEdit(entry.row)}
                          className="text-xs text-primary underline hover:no-underline"
                          title={
                            entry.row.bondingApplied
                              ? "Fix wire/elastics/O-tie/power chain/etc — the bonding itself is corrected on the chart, not here"
                              : "Fix this visit's details"
                          }
                        >
                          Edit
                        </button>
                      )}
                      {canDeleteVisit && (
                        <button
                          type="button"
                          onClick={() => deleteVisit(entry.row)}
                          className="text-xs text-red-600 underline hover:no-underline"
                          title="Delete this visit entirely and reverse whatever it caused in inventory/chart"
                        >
                          Delete
                        </button>
                      )}
                    </div>
                  )}
                  {saved && unlocked && (
                    <button type="button" onClick={() => saveEdit(entry.row.id)} className="ml-auto px-3 py-1.5 rounded-md text-xs font-medium shrink-0 btn-3d-primary">
                      Save
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
