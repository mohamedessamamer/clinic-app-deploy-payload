// دفعة 138 — قاعدة عامة: أي مكوّن فيه فلاتر ونتيجة تقرير/بحث لازم يسجّل حالته
// في رابط الصفحة (URL) بدل ما يسيبها في ذاكرة الصفحة (React state) بس. الفايدة
// إن زرار "رجوع" في المتصفح بيرجّعك لنفس الـ URL اللي كنت عليه بالظبط - فلو
// الفلاتر والنتيجة متسجلين في الرابط، بتقدر تعيد بناء نفس الحالة منه أول ما
// المكوّن يتحمّل تاني، مش يرجع لقيمه الافتراضية.
//
// ده نفس الأسلوب اللي كان مستخدم يدويًا في ReportsWorkspace.tsx (اختيار
// التبويب) - هنا بس بقى أداة عامة تتستخدم في أي تقرير فيه فلاتر (تاريخ، فرز،
// تخصص...) بدل ما كل مكوّن يعيد كتابة نفس الكود.
//
// طريقة الاستخدام في أي مكوّن "use client":
//   const initial = readUrlReportParams(["fromDate", "toDate", "specialty"]);
//   const [fromDate, setFromDate] = useState(initial.fromDate ?? "");
//   ...
//   function run() {
//     writeUrlReportParams({ fromDate, toDate, specialty, applied: "1" });
//     startTransition(async () => { ... });
//   }
//   useEffect(() => { if (initial.applied === "1") run(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
//
// ملحوظة: القراءة والكتابة بيتعاملوا مع window مباشرة (زي ReportsWorkspace
// بالظبط) بدل useSearchParams/useRouter، عشان history.replaceState هنا محتاج
// يحصل من غير ما يعمل re-render أو navigation فعلي - إحنا بس بنعلّم على الرابط
// الحالي، مش بننقل المستخدم لرابط جديد.

export function readUrlReportParams(keys: string[]): Record<string, string | null> {
  const result: Record<string, string | null> = {};
  if (typeof window === "undefined") {
    for (const key of keys) result[key] = null;
    return result;
  }
  const params = new URLSearchParams(window.location.search);
  for (const key of keys) result[key] = params.get(key);
  return result;
}

export function writeUrlReportParams(values: Record<string, string | null | undefined>): void {
  if (typeof window === "undefined") return;
  const url = new URL(window.location.href);
  for (const [key, value] of Object.entries(values)) {
    if (value === null || value === undefined || value === "") url.searchParams.delete(key);
    else url.searchParams.set(key, value);
  }
  window.history.replaceState(null, "", url);
}
