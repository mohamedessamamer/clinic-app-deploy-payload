import type { Transaction } from "kysely";
import type { Database } from "@/lib/db/types";

// دفعة 27 (P2.4) — الفصل الكامل بين الملف الطبي والمالي: لو الدكتور دخل
// المعالجة من شارت التقويم (خدمة + مقاسات الأسلاك + الملاحظة الحرة)، تتنسخ
// تلقائيًا لحقل "تفاصيل المعالجة" (notes) في زيارة الملف الطبي المقابلة —
// كباراجراف واحد، وكل بند مفصول بشرطة واضحة. السلك مع الفك (المقاس + النوع)
// يظل بندًا واحدًا، مثل: Upper wire 12 NiTi.
export function buildOrthoTreatmentParagraph(input: {
  service: string | null;
  upperWireSize: string | null;
  upperWireType: string | null;
  lowerWireSize: string | null;
  lowerWireType: string | null;
  elastics: string | null;
  otie: string | null;
  powerChainQty: number | null;
  buttonsQty: number | null;
  compressedCoilMm: number | null;
  note: string | null;
}): string | null {
  const parts: string[] = [];
  if (input.service) parts.push(input.service);
  const wireText = (size: string | null, type: string | null, arch: "Upper" | "Lower") => {
    if (!size || size === "Same") return null;
    const cleanSize = size.replace(/^(upper|lower)\s+wire\s*/i, "").trim();
    const cleanType = type && type !== "Same" ? type.trim() : "";
    return `${[cleanSize, cleanType].filter(Boolean).join(" ")} ${arch}`.trim();
  };
  const wires = [
    wireText(input.upperWireSize, input.upperWireType, "Upper"),
    wireText(input.lowerWireSize, input.lowerWireType, "Lower"),
  ].filter(Boolean);
  if (wires.length) parts.push(wires.join(", "));
  // خامات الاستهلاك (O-tie، Power chain، Buttons… إلخ) تبقى في شارت
  // التقويم والمخزن فقط. الملف الطبي يحتاج ملخص العلاج: الخدمة، الأسلاك،
  // وأي ملاحظة حرة كتبها الطبيب.
  if (input.note) parts.push(input.note);
  if (parts.length === 0) return null;
  return parts.join(" - ");
}

// كل زيارة تقويم لها سطر طبي واحد ثابت. الربط برقم الزيارة يمنع أن يقوم حفظ
// زيارة جديدة بتعديل أو مسح سطر أقدم لمجرد أن التاريخ واحد.
async function findCorrespondingMedicalVisit(trx: Transaction<Database>, params: { patientId: number; orthoVisitId: number }) {
  return trx
    .selectFrom("visits")
    .select(["id", "notes", "notes_synced_from_ortho"])
    .where("patient_id", "=", params.patientId)
    .where("ortho_visit_id", "=", params.orthoVisitId)
    .orderBy("id", "desc")
    .executeTakeFirst();
}

// للسجلات القديمة التي سبقت عمود ortho_visit_id: نربط سطر نفس اليوم مرة
// واحدة فقط، ثم يصبح له رابط ثابت فيما بعد. لا نستخدمه للزيارات الجديدة إذا
// كان هناك سطر مخصص بالفعل.
async function findLegacyMedicalVisit(trx: Transaction<Database>, params: { patientId: number; visitDate: string }) {
  return trx
    .selectFrom("visits")
    .select(["id", "notes", "notes_synced_from_ortho"])
    .where("patient_id", "=", params.patientId)
    .where("visit_date", "=", params.visitDate)
    .where("ortho_visit_id", "is", null)
    .orderBy("id", "desc")
    .executeTakeFirst();
}

// بيتنادى بعد حفظ (إضافة/تعديل) زيارة متابعة في شارت التقويم. بينسخ الباراجراف
// لحقل notes بتاع الزيارة المقابلة — بس لو مفيش نص يدوي حقيقي مكتوب هناك
// بالفعل (notes فاضي، أو آخر نص كان هو نفسه جاي من مزامنة سابقة). نص كتبه
// الطبيب يدويًا في الملف الطبي نفسه (notes_synced_from_ortho=0) مايتلمسش خالص
// — من غير ما نرفض العملية لو الزيارة المقابلة مش موجودة أصلاً (وقتها ببساطة
// مفيش حاجة تتزامن، زي ما هو متفق).
export async function syncOrthoNoteToMedicalVisit(
  trx: Transaction<Database>,
  params: { patientId: number; orthoVisitId: number; visitDate: string; paragraph: string | null; performingDoctorId: number }
) {
  let visit = await findCorrespondingMedicalVisit(trx, params);
  if (!visit) visit = await findLegacyMedicalVisit(trx, params);
  // زيارة التقويم هي سجل طبي أيضًا. في السابق كنا نحدّث زيارة عامة موجودة فقط؛
  // لذلك كان إدخال الشارت يختفي تمامًا لو الطبيب لم ينشئ سطرًا يدويًا قبله.
  // الآن ننشئ السطر تلقائيًا حتى لو لم يوجد موعد استقبال في اليوم نفسه؛ وعند
  // وجود موعد نرث منه الخدمة والطبيب الأساسي والغرفة. أما مقدم الخدمة الفعلي
  // فهو الطبيب الذي اختاره المستخدم في شارت التقويم، وليس بالضرورة صاحب الموعد.
  // لا ننشئ سطرًا فارغًا إذا لم يكتب الطبيب أي تفاصيل.
  if (!visit && params.paragraph) {
    const appointment = await trx
      .selectFrom("appointments")
      .select(["id", "doctor_id", "room_id", "purpose_service_id"])
      .where("patient_id", "=", params.patientId)
      .where("appointment_date", "=", params.visitDate)
      .where("status", "!=", "cancelled")
      .orderBy("start_time")
      .executeTakeFirst();
    const inserted = await trx
      .insertInto("visits")
      .values({
        patient_id: params.patientId,
        visit_date: params.visitDate,
        service_id: appointment?.purpose_service_id ?? null,
        notes: params.paragraph,
        notes_synced_from_ortho: 1,
        primary_doctor_id: appointment?.doctor_id ?? params.performingDoctorId,
        performing_doctor_id: params.performingDoctorId,
        room_id: appointment?.room_id ?? null,
        appointment_id: appointment?.id ?? null,
        ortho_visit_id: params.orthoVisitId,
        created_by: null,
      })
      .executeTakeFirst();
    visit = { id: Number(inserted.insertId), notes: params.paragraph, notes_synced_from_ortho: 1 };
  }
  if (!visit) return;
  // اختيار الطبيب داخل شارت التقويم هو مصدر الحقيقة لمقدم الخدمة الفعلي؛ نحدّثه
  // حتى لو كانت ملاحظة الزيارة العامة مكتوبة يدويًا، لكن لا نمسح تلك الملاحظة.
  if (visit.notes && !visit.notes_synced_from_ortho) {
    // الحماية القديمة كانت تمنع المزامنة بالكامل عند وجود ملاحظة يدوية، وده
    // سبب اختفاء تعديلات الشارت. نحافظ على النص اليدوي ونبدّل فقط جزء الشارت
    // المميز، حتى يستمر التحديث كل مرة من غير فقد أي كتابة موجودة.
    const marker = "Orthodontic chart: ";
    const markerIndex = visit.notes.indexOf(marker);
    const manualPart = markerIndex >= 0 ? visit.notes.slice(0, markerIndex).trimEnd() : visit.notes.trimEnd();
    const mergedNotes = params.paragraph ? `${manualPart}${manualPart ? "\n" : ""}${marker}${params.paragraph}` : manualPart || null;
    await trx.updateTable("visits").set({ notes: mergedNotes, performing_doctor_id: params.performingDoctorId, visit_date: params.visitDate, ortho_visit_id: params.orthoVisitId }).where("id", "=", visit.id).execute();
    return;
  }
  await trx
    .updateTable("visits")
    .set({
      notes: params.paragraph,
      notes_synced_from_ortho: params.paragraph ? 1 : 0,
      performing_doctor_id: params.performingDoctorId,
      visit_date: params.visitDate,
      ortho_visit_id: params.orthoVisitId,
    })
    .where("id", "=", visit.id)
    .execute();
}

// بيتنادى بعد حذف زيارة متابعة من شارت التقويم (deleteOrthoVisitAction) —
// بيمسح النص من الزيارة المقابلة بس لو هو نفسه اللي كان جاي من المزامنة.
export async function clearSyncedOrthoNote(trx: Transaction<Database>, params: { patientId: number; orthoVisitId: number }) {
  const visit = await findCorrespondingMedicalVisit(trx, params);
  if (!visit) return;
  if (!visit.notes_synced_from_ortho) {
    const marker = "Orthodontic chart: ";
    const markerIndex = visit.notes?.indexOf(marker) ?? -1;
    if (markerIndex >= 0) {
      await trx.updateTable("visits").set({ notes: visit.notes!.slice(0, markerIndex).trimEnd() || null, ortho_visit_id: null }).where("id", "=", visit.id).execute();
    }
    return;
  }
  await trx.updateTable("visits").set({ notes: null, notes_synced_from_ortho: 0, ortho_visit_id: null }).where("id", "=", visit.id).execute();
}
