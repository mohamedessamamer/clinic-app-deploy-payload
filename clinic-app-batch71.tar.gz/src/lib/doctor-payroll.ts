import "server-only";
import { db } from "./db/client";
import { monthBounds } from "./expenses";

function round2(value: number) {
  return Math.round(value * 100) / 100;
}

// نفس منطق تقرير الإيرادات: الدفعة اللاحقة تنسب للطبيب الموجود على الفاتورة
// الأصلية، وليس لمن أنشأ دفعة المتابعة، حتى تكون نسبة الطبيب متسقة مع تقاريره.
export async function getDoctorCollectedForMonth(doctorId: number, month: string) {
  const range = monthBounds(month);
  if (!range) return 0;
  const roots = await db
    .selectFrom("invoices")
    .select(["id", "paid"])
    .where("doctor_id", "=", doctorId)
    .where("parent_invoice_id", "is", null)
    .where("invoice_date", ">=", range.from)
    .where("invoice_date", "<=", range.to)
    .execute();
  const followups = await db
    .selectFrom("invoices")
    .innerJoin("invoices as parent_invoices", "parent_invoices.id", "invoices.parent_invoice_id")
    .select("invoices.paid")
    .where("parent_invoices.doctor_id", "=", doctorId)
    .where("invoices.parent_invoice_id", "is not", null)
    .where("invoices.invoice_date", ">=", range.from)
    .where("invoices.invoice_date", "<=", range.to)
    .execute();
  return round2(roots.reduce((sum, row) => sum + row.paid, 0) + followups.reduce((sum, row) => sum + row.paid, 0));
}

export function calculateDoctorPayroll(rule: { fixed_amount: number; percentage: number }, collectedAmount: number) {
  const percentageAmount = round2(collectedAmount * (rule.percentage / 100));
  return {
    collectedAmount: round2(collectedAmount),
    fixedAmount: round2(rule.fixed_amount),
    percentageAmount,
    totalAmount: round2(rule.fixed_amount + percentageAmount),
  };
}
