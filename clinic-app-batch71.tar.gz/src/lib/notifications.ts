import "server-only";

import { sql } from "kysely";
import { db } from "@/lib/db/client";
import { getClinicToday } from "@/lib/clinic-date";
import { getAllSettings } from "@/lib/settings";
import { evaluateInventoryReorderNeeds } from "@/lib/inventory-reorder";

const SQL_DATE = (date = new Date()) => date.toISOString().replace("T", " ").slice(0, 19);

function plusHours(hours: number): string {
  return SQL_DATE(new Date(Date.now() + Math.max(1, hours) * 60 * 60 * 1000));
}

function daysBetween(from: string, to: string): number {
  const start = new Date(`${from}T00:00:00Z`).getTime();
  const end = new Date(`${to}T00:00:00Z`).getTime();
  return Math.max(0, Math.floor((end - start) / 86_400_000));
}

function parsePositiveList(value: string, fallback: number[]): number[] {
  const result = value
    .split(",")
    .map((part) => Number(part.trim()))
    .filter((value) => Number.isFinite(value) && value > 0)
    .map((value) => Math.round(value));
  return Array.from(new Set(result)).sort((a, b) => a - b).slice(0, 8).length ? Array.from(new Set(result)).sort((a, b) => a - b).slice(0, 8) : fallback;
}

async function activeReceptionUserIds(): Promise<number[]> {
  const rows = await db.selectFrom("users").select("id").where("active", "=", 1).where("role", "=", "reception").execute();
  return rows.map((row) => row.id);
}

async function doctorUserIds(doctorId: number | null): Promise<number[]> {
  if (!doctorId) return [];
  const rows = await db.selectFrom("users").select("id").where("active", "=", 1).where("doctor_id", "=", doctorId).execute();
  return rows.map((row) => row.id);
}

export type NotificationRow = {
  id: number;
  type: string;
  title: string;
  body: string;
  patient_id: number | null;
  notification_case_id: number | null;
  read_at: string | null;
  created_at: string;
};

export async function createNotifications(input: {
  recipientUserIds: number[];
  type: string;
  title: string;
  body: string;
  patientId?: number | null;
  notificationCaseId?: number | null;
  dedupeKey: string;
  retentionHours?: number;
}) {
  const recipients = Array.from(new Set(input.recipientUserIds)).filter(Boolean);
  if (!recipients.length) return;
  const settings = await getAllSettings();
  const retentionHours = input.retentionHours ?? Math.max(1, Number(settings.notification_retention_hours) || 48);
  const expires_at = plusHours(retentionHours);
  await db
    .insertInto("notifications")
    .values(
      recipients.map((recipient_user_id) => ({
        recipient_user_id,
        type: input.type,
        title: input.title,
        body: input.body,
        patient_id: input.patientId ?? null,
        notification_case_id: input.notificationCaseId ?? null,
        dedupe_key: input.dedupeKey,
        expires_at,
      }))
    )
    .onConflict((oc) => oc.columns(["recipient_user_id", "dedupe_key"]).doNothing())
    .execute();
}

export async function cleanupNotificationCenter() {
  await Promise.all([
    db.deleteFrom("notifications").where(sql<boolean>`expires_at <= datetime('now')`).execute(),
    db.deleteFrom("chat_messages").where(sql<boolean>`created_at <= datetime('now', '-48 hours')`).execute(),
  ]);
}

// يتم تشغيل هذا الفحص عند فتح النظام. لا يرسل نفس المرحلة مرتين: حالة المتابعة
// تحفظ آخر مرحلة أُرسلت، وتسمح بتذكير المرحلة النهائية فقط بعد الفترة المحددة.
export async function evaluateRoutineNotifications() {
  const [settings, charts] = await Promise.all([
    getAllSettings(),
    db.selectFrom("orthodontic_charts").select(["patient_id", "created_at"]).execute(),
  ]);
  const today = getClinicToday();
  const stages = parsePositiveList(settings.notification_ortho_stages_days, [40, 60, 90]);
  const finalStage = stages[stages.length - 1];
  const finalRepeatDays = Math.max(1, Number(settings.notification_ortho_final_repeat_days) || 7);
  const receptionIds = await activeReceptionUserIds();

  for (const chart of charts) {
    const [patient, lastVisit] = await Promise.all([
      db.selectFrom("patients").select("full_name").where("id", "=", chart.patient_id).executeTakeFirst(),
      db
        .selectFrom("ortho_visits")
        .select(["visit_date", "doctor_id"])
        .where("patient_id", "=", chart.patient_id)
        .orderBy("visit_date", "desc")
        .orderBy("id", "desc")
        .executeTakeFirst(),
    ]);
    if (!patient) continue;
    const lastVisitDate = lastVisit?.visit_date ?? chart.created_at.slice(0, 10);
    const elapsed = daysBetween(lastVisitDate, today);
    const dueStage = [...stages].reverse().find((stage) => elapsed >= stage);
    if (!dueStage) continue;

    let followupCase = await db
      .selectFrom("notification_cases")
      .selectAll()
      .where("rule_key", "=", "ortho_followup")
      .where("patient_id", "=", chart.patient_id)
      .executeTakeFirst();

    if (!followupCase) {
      const inserted = await db
        .insertInto("notification_cases")
        .values({ rule_key: "ortho_followup", patient_id: chart.patient_id, doctor_id: lastVisit?.doctor_id ?? null, last_visit_date: lastVisitDate })
        .executeTakeFirstOrThrow();
      followupCase = await db.selectFrom("notification_cases").selectAll().where("id", "=", Number(inserted.insertId)).executeTakeFirstOrThrow();
    } else if (followupCase.last_visit_date !== lastVisitDate) {
      await db
        .updateTable("notification_cases")
        .set({ doctor_id: lastVisit?.doctor_id ?? null, last_visit_date: lastVisitDate, status: "open", last_stage_days: 0, last_notified_at: null, reason: null, next_review_date: null, resolved_by: null, resolved_at: null, updated_at: SQL_DATE() })
        .where("id", "=", followupCase.id)
        .execute();
      followupCase = await db.selectFrom("notification_cases").selectAll().where("id", "=", followupCase.id).executeTakeFirstOrThrow();
    }

    if (followupCase.status === "resolved") continue;
    if (followupCase.status === "snoozed" && followupCase.next_review_date && followupCase.next_review_date > today) continue;

    const lastSentAge = followupCase.last_notified_at ? daysBetween(followupCase.last_notified_at.slice(0, 10), today) : Number.POSITIVE_INFINITY;
    const shouldNotify = dueStage > followupCase.last_stage_days || (dueStage === finalStage && lastSentAge >= finalRepeatDays);
    if (!shouldNotify) continue;

    const recipients = [...receptionIds, ...(await doctorUserIds(lastVisit?.doctor_id ?? null))];
    const isFinal = dueStage === finalStage;
    const cycleKey = isFinal && followupCase.last_stage_days === finalStage ? `${today}` : `${dueStage}`;
    await createNotifications({
      recipientUserIds: recipients,
      type: "ortho_followup",
      title: isFinal ? "متابعة تقويم تحتاج إجراء" : "متابعة تقويم متأخرة",
      body: `${patient.full_name}: آخر متابعة ${lastVisitDate}، والتأخير الآن ${elapsed} يومًا.${isFinal ? " مطلوب تسجيل سبب أو موعد متابعة." : ""}`,
      patientId: chart.patient_id,
      notificationCaseId: followupCase.id,
      dedupeKey: `ortho_followup:${followupCase.id}:${cycleKey}`,
    });
    await db.updateTable("notification_cases").set({ status: "open", last_stage_days: dueStage, last_notified_at: SQL_DATE(), updated_at: SQL_DATE() }).where("id", "=", followupCase.id).execute();
  }

  // تنبيه الصور: للطبيب صاحب موعد اليوم فقط، مرة واحدة لكل موعد في اليوم.
  const photoDays = Math.max(1, Number(settings.notification_photo_days) || 180);
  const todayAppointments = await db
    .selectFrom("appointments")
    .innerJoin("patients", "patients.id", "appointments.patient_id")
    .select(["appointments.id", "appointments.patient_id", "appointments.doctor_id", "patients.full_name as patient_name"])
    .where("appointments.appointment_date", "=", today)
    .where("appointments.status", "!=", "cancelled")
    .execute();
  for (const appointment of todayAppointments) {
    const latestPhoto = await db
      .selectFrom("patient_image_groups")
      .select("taken_at")
      .where("patient_id", "=", appointment.patient_id)
      .orderBy("taken_at", "desc")
      .executeTakeFirst();
    const photoAge = latestPhoto ? daysBetween(latestPhoto.taken_at, today) : Number.POSITIVE_INFINITY;
    if (photoAge < photoDays) continue;
    await createNotifications({
      recipientUserIds: await doctorUserIds(appointment.doctor_id),
      type: "photos_due",
      title: "صور المريض تحتاج تحديثًا",
      body: latestPhoto ? `${appointment.patient_name}: آخر صور بتاريخ ${latestPhoto.taken_at}.` : `${appointment.patient_name}: لا توجد صور مسجلة له.`,
      patientId: appointment.patient_id,
      dedupeKey: `photos_due:${appointment.id}:${today}`,
    });
  }
}

export async function getNotificationCenter(userId: number): Promise<NotificationRow[]> {
  await cleanupNotificationCenter();
  await Promise.all([evaluateRoutineNotifications(), evaluateInventoryReorderNeeds()]);
  return db
    .selectFrom("notifications")
    .select(["id", "type", "title", "body", "patient_id", "notification_case_id", "read_at", "created_at"])
    .where("recipient_user_id", "=", userId)
    .where(sql<boolean>`expires_at > datetime('now')`)
    .orderBy("created_at", "desc")
    .limit(60)
    .execute();
}

export async function notifyDoctorOfCancellation(appointmentId: number) {
  const appointment = await db
    .selectFrom("appointments")
    .innerJoin("patients", "patients.id", "appointments.patient_id")
    .select(["appointments.doctor_id", "appointments.patient_id", "appointments.appointment_date", "appointments.start_time", "patients.full_name as patient_name"])
    .where("appointments.id", "=", appointmentId)
    .executeTakeFirst();
  if (!appointment || appointment.appointment_date !== getClinicToday()) return;
  await createNotifications({
    recipientUserIds: await doctorUserIds(appointment.doctor_id),
    type: "appointment_cancelled",
    title: "تم إلغاء موعد اليوم",
    body: `${appointment.patient_name} — موعد ${appointment.start_time}.`,
    patientId: appointment.patient_id,
    dedupeKey: `appointment_cancelled:${appointmentId}`,
  });
}

export async function notifyReceptionOfCollectionRequest(input: { appointmentId: number; patientId: number; doctorId: number; patientName: string }) {
  await createNotifications({
    recipientUserIds: await activeReceptionUserIds(),
    type: "collection_request",
    title: "طلب تحصيل من الطبيب",
    body: `${input.patientName}: يوجد طلب تحصيل جديد من الطبيب صاحب الموعد.`,
    patientId: input.patientId,
    dedupeKey: `collection_request:${input.appointmentId}`,
  });
}
