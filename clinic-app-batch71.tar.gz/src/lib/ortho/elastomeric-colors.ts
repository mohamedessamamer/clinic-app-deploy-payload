export const ELASTOMERIC_COLORS = [
  ["ELC-001", "Clear", "#8FA1B2"], ["ELC-002", "White", "#B6BEC7"], ["ELC-003", "Pearl", "#C8B9A6"],
  ["ELC-004", "Silver", "#9CA3AF"], ["ELC-005", "Grey", "#6B7280"], ["ELC-006", "Black", "#111827"],
  ["ELC-007", "Light Blue", "#7DD3FC"], ["ELC-008", "Aqua", "#2DD4BF"], ["ELC-009", "Teal", "#0F766E"],
  ["ELC-010", "Royal Blue", "#2563EB"], ["ELC-011", "Navy", "#1E3A8A"], ["ELC-012", "Lavender", "#C4B5FD"],
  ["ELC-013", "Lilac", "#A78BFA"], ["ELC-014", "Purple", "#7E22CE"], ["ELC-015", "Bubble Gum", "#F9A8D4"],
  ["ELC-016", "Pink", "#EC4899"], ["ELC-017", "Coral", "#FB7185"], ["ELC-018", "Rose", "#E11D48"],
  ["ELC-019", "Fire Red", "#DC2626"], ["ELC-020", "Red", "#B91C1C"], ["ELC-021", "Burgundy", "#7F1D1D"],
  ["ELC-022", "Yellow", "#EAB308"], ["ELC-023", "Gold Rush", "#CA8A04"], ["ELC-024", "Orange", "#F97316"],
  ["ELC-025", "Dark Orange", "#C2410C"], ["ELC-026", "Lime", "#84CC16"], ["ELC-027", "Shamrock", "#16A34A"],
  ["ELC-028", "Green", "#15803D"],
] as const;

export type ElastomericColor = { code: string; name: string; hex: string };

export function elastomericColorForItemName(itemName: string): ElastomericColor | null {
  const color = ELASTOMERIC_COLORS.find((entry) => itemName.includes(`— ${entry[1]}`));
  return color ? { code: color[0], name: color[1], hex: color[2] } : null;
}

export function elastomericItemName(kind: "O-tie" | "Power chain", color: ElastomericColor): string {
  return `${kind} — ${color.name} (${color.code})`;
}
