import "server-only";
import { db } from "./db/client";

export const EXPENSE_CATEGORIES = [
  "salary",
  "fixed",
  "petty",
  "inventory_general",
  "inventory_orthodontic",
  "other",
] as const;

export type ExpenseCategory = (typeof EXPENSE_CATEGORIES)[number];

export const EXPENSE_CATEGORY_LABELS: Record<ExpenseCategory, string> = {
  salary: "مرتبات",
  fixed: "مصاريف ثابتة",
  petty: "مصروفات نثرية",
  inventory_general: "خامات عامة",
  inventory_orthodontic: "خامات تقويم",
  other: "أخرى",
};

export function isExpenseCategory(value: string): value is ExpenseCategory {
  return (EXPENSE_CATEGORIES as readonly string[]).includes(value);
}

export function monthBounds(month: string): { from: string; to: string } | null {
  if (!/^\d{4}-\d{2}$/.test(month)) return null;
  const [year, monthNumber] = month.split("-").map(Number);
  if (monthNumber < 1 || monthNumber > 12) return null;
  const lastDay = new Date(Date.UTC(year, monthNumber, 0)).getUTCDate();
  return { from: `${month}-01`, to: `${month}-${String(lastDay).padStart(2, "0")}` };
}

export async function getExpenseSummary(from: string, to: string) {
  const rows = await db
    .selectFrom("expenses")
    .select(["category", "amount"])
    .where("expense_date", ">=", from)
    .where("expense_date", "<=", to)
    .execute();
  const byCategory = new Map<ExpenseCategory, number>();
  for (const row of rows) {
    if (!isExpenseCategory(row.category)) continue;
    byCategory.set(row.category, Math.round(((byCategory.get(row.category) ?? 0) + row.amount) * 100) / 100);
  }
  const total = Math.round(rows.reduce((sum, row) => sum + row.amount, 0) * 100) / 100;
  return { total, byCategory };
}
