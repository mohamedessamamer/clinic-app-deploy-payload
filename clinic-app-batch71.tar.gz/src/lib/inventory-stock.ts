import "server-only";

import type { Transaction } from "kysely";
import { db } from "@/lib/db/client";
import type { Database } from "@/lib/db/types";

type StockTransaction = Transaction<Database>;

function sqlNow() {
  return new Date().toISOString().replace("T", " ").slice(0, 19);
}

/**
 * يخصم من الخامة العلاجية أولاً ثم يوزع الخصم تلقائياً على أقدم التوريدات
 * المتاحة. لذلك شارت التقويم يتعامل مع Wire 0.012 فقط، مع بقاء معرفة الشركة
 * والمورد والسعر محفوظة في دفتر المخزن.
 */
export async function deductInventoryItem(
  trx: StockTransaction,
  input: {
    itemId: number;
    quantity: number;
    movementType: "ortho_use" | "general_consumption" | "count_adjustment";
    appointmentId?: number | null;
    note: string;
    createdBy?: number | null;
  }
) {
  if (!Number.isFinite(input.quantity) || input.quantity <= 0) return 0;

  // الحركة المرتبطة بموعد واحد يجب ألا تتكرر حتى لو استدعى الكود أكثر من مرة.
  if (input.appointmentId) {
    const existing = await trx
      .selectFrom("inventory_stock_movements")
      .select("id")
      .where("appointment_id", "=", input.appointmentId)
      .where("item_id", "=", input.itemId)
      .where("movement_type", "=", input.movementType)
      .executeTakeFirst();
    if (existing) return 0;
  }

  const item = await trx.selectFrom("inventory_items").select("quantity").where("id", "=", input.itemId).executeTakeFirst();
  if (!item) return 0;

  const batches = await trx
    .selectFrom("inventory_supply_batches")
    .select(["id", "quantity_remaining"])
    .where("item_id", "=", input.itemId)
    .where("quantity_remaining", ">", 0)
    .orderBy("received_at", "asc")
    .orderBy("id", "asc")
    .execute();

  let remaining = input.quantity;
  for (const batch of batches) {
    if (remaining <= 0) break;
    const taken = Math.min(remaining, batch.quantity_remaining);
    await trx.updateTable("inventory_supply_batches").set({ quantity_remaining: batch.quantity_remaining - taken }).where("id", "=", batch.id).execute();
    await trx
      .insertInto("inventory_stock_movements")
      .values({
        item_id: input.itemId,
        batch_id: batch.id,
        appointment_id: input.appointmentId ?? null,
        movement_type: input.movementType,
        quantity: -taken,
        note: input.note,
        created_by: input.createdBy ?? null,
      })
      .execute();
    remaining -= taken;
  }

  // توريدات قديمة قبل هذا التصميم قد لا يكون لها batch؛ نسجل الجزء المتبقي
  // في الدفتر أيضاً حتى لا يمنع التحويل القديم الخصم من الشارت.
  if (remaining > 0) {
    await trx
      .insertInto("inventory_stock_movements")
      .values({
        item_id: input.itemId,
        batch_id: null,
        appointment_id: input.appointmentId ?? null,
        movement_type: input.movementType,
        quantity: -remaining,
        note: `${input.note} (رصيد قديم بلا توريد مفصل)`,
        created_by: input.createdBy ?? null,
      })
      .execute();
  }

  await trx
    .updateTable("inventory_items")
    .set({ quantity: item.quantity - input.quantity })
    .where("id", "=", input.itemId)
    .execute();
  return input.quantity;
}

/** يرجع كمية للمخزون كسطر تصحيح واضح، بدلاً من تخمين الشركة الأصلية بعد Undo. */
export async function returnInventoryItem(
  trx: StockTransaction,
  input: { itemId: number; quantity: number; note: string; createdBy?: number | null }
) {
  if (!Number.isFinite(input.quantity) || input.quantity <= 0) return;
  const inserted = await trx
    .insertInto("inventory_supply_batches")
    .values({
      item_id: input.itemId,
      supplier_id: null,
      brand: "مرتجع / تصحيح",
      quantity_received: input.quantity,
      quantity_remaining: input.quantity,
      total_cost: null,
      received_at: new Date().toISOString().slice(0, 10),
      note: input.note,
      created_by: input.createdBy ?? null,
    })
    .executeTakeFirstOrThrow();
  const batchId = Number(inserted.insertId);
  await trx.updateTable("inventory_items").set({ quantity: (eb) => eb("quantity", "+", input.quantity) }).where("id", "=", input.itemId).execute();
  await trx
    .insertInto("inventory_stock_movements")
    .values({ item_id: input.itemId, batch_id: batchId, appointment_id: null, movement_type: "return", quantity: input.quantity, note: input.note, created_by: input.createdBy ?? null })
    .execute();
}

/** يطبق متوسط استهلاك المستهلكات العامة مرة واحدة فقط لكل موعد تم. */
export async function applyGeneralConsumablesForCompletedAppointment(appointmentId: number) {
  const appointment = await db.selectFrom("appointments").select("id").where("id", "=", appointmentId).where("status", "=", "done").executeTakeFirst();
  if (!appointment) return;

  await db.transaction().execute(async (trx) => {
    const rules = await trx
      .selectFrom("inventory_consumable_rules")
      .innerJoin("inventory_items", "inventory_items.id", "inventory_consumable_rules.item_id")
      .select(["inventory_consumable_rules.item_id", "inventory_consumable_rules.quantity_per_completed_appointment", "inventory_items.name"])
      .where("inventory_consumable_rules.active", "=", 1)
      .where("inventory_consumable_rules.quantity_per_completed_appointment", ">", 0)
      .where("inventory_items.is_general_consumable", "=", 1)
      .execute();

    for (const rule of rules) {
      await deductInventoryItem(trx, {
        itemId: rule.item_id,
        quantity: rule.quantity_per_completed_appointment,
        movementType: "general_consumption",
        appointmentId,
        note: `استهلاك تلقائي عند إتمام الموعد: ${rule.name}`,
        createdBy: null,
      });
    }
  });
}

export { sqlNow };
