import Database from "better-sqlite3";
import { ELASTOMERIC_COLORS, elastomericItemName } from "@/lib/ortho/elastomeric-colors";

type ClinicalItem = {
  name: string;
  category: string;
  unit: string;
  orthoUsage: string | null;
  group: string | null;
  autoDeductionKey?: string | null;
  autoDeductionPerAttachment?: number;
  legacyName?: string;
};

// مصدر واحد لكتالوج التقويم. يُشغَّل مع النشر تلقائياً، وليس محتاجاً أن
// يعرّف الموظف Wire أو لون أو مقاس يدوياً. لا يلمس الكميات أو الموردين أو
// حالة إتاحة الصنف التي ضبطها المستخدم؛ يضيف الناقص وينظم الموجود فقط.
export function seedOrthodonticInventoryCatalog(sqlite: InstanceType<typeof Database>) {
  const categories = ["TADS", "BRACKETS", "TUBES", "BANDS", "WIRES", "AUXILIARIES", "ELASTICS", "O-TIES", "POWER CHAINS", "ADHESIVES"];
  sqlite.prepare("INSERT INTO inventory_specialties (name) VALUES (?) ON CONFLICT(name) DO NOTHING").run("تقويم");
  const specialty = sqlite.prepare("SELECT id FROM inventory_specialties WHERE name = ?").get("تقويم") as { id: number };
  const addCategory = sqlite.prepare("INSERT INTO inventory_categories (specialty_id, name) VALUES (?, ?) ON CONFLICT(specialty_id, name) DO NOTHING");
  categories.forEach((name) => addCategory.run(specialty.id, name));
  const categoryRows = sqlite.prepare("SELECT id, name FROM inventory_categories WHERE specialty_id = ?").all(specialty.id) as Array<{ id: number; name: string }>;
  const categoryIds = new Map(categoryRows.map((row) => [row.name, row.id]));

  const items: ClinicalItem[] = [
    { name: "TAD 1.6 × 8", category: "TADS", unit: "screw", orthoUsage: "anchorage_device", group: "TAD" },
    { name: "TAD 1.6 × 10", category: "TADS", unit: "screw", orthoUsage: "anchorage_device", group: "TAD" },
    // الـTube نوع موحد في كل الحالات؛ لا نطلب شركة أو prescription من الطبيب.
    { name: "Orthodontic tube", category: "TUBES", unit: "tube", orthoUsage: "tube", group: "Tube" },
    ...["0.012", "0.014", "0.016", "0.016 × 0.022", "0.017 × 0.025", "0.019 × 0.025"].map((size) => ({ name: `NiTi ${size}`, category: "WIRES", unit: "wire", orthoUsage: "wire", group: "NiTi" })),
    ...["0.012", "0.016", "0.018", "0.016 × 0.022", "0.017 × 0.025", "0.019 × 0.025"].map((size) => ({ name: `St.St ${size}`, category: "WIRES", unit: "wire", orthoUsage: "wire", group: "St.St" })),
    { name: "Elastic 1/8", category: "ELASTICS", unit: "packet", orthoUsage: "elastic", group: "Elastics" },
    { name: "Elastic 3/16", category: "ELASTICS", unit: "packet", orthoUsage: "elastic", group: "Elastics" },
    { name: "Elastic 5/16", category: "ELASTICS", unit: "packet", orthoUsage: "elastic", group: "Elastics" },
    ...ELASTOMERIC_COLORS.flatMap(([code, name, hex]) => {
      const color = { code, name, hex };
      return [
        { name: elastomericItemName("O-tie", color), legacyName: `O-tie — ${name}`, category: "O-TIES", unit: "circle", orthoUsage: "otie", group: "O-tie" },
        { name: elastomericItemName("Power chain", color), legacyName: `Power chain — ${name}`, category: "POWER CHAINS", unit: "piece", orthoUsage: "power_chain", group: "Power chain" },
      ];
    }),
    { name: "Compressed coil", category: "AUXILIARIES", unit: "mm", orthoUsage: "compressed_coil", group: "Coils" },
    { name: "Button", category: "AUXILIARIES", unit: "piece", orthoUsage: "button", group: "Buttons" },
    { name: "Stripping paper", category: "AUXILIARIES", unit: "mm", orthoUsage: null, group: "Stripping" },
    { name: "Ligature wire", category: "AUXILIARIES", unit: "piece", orthoUsage: null, group: "Ligature wire" },
    { name: "Orthodontic composite", category: "ADHESIVES", unit: "mg", orthoUsage: null, group: "Composite", autoDeductionKey: "orthodontic_composite", autoDeductionPerAttachment: 30 },
  ];

  const byName = sqlite.prepare("SELECT id FROM inventory_items WHERE name = ?");
  const insert = sqlite.prepare(`INSERT INTO inventory_items (name, quantity, unit, specialty_id, category_id, catalog_group, ortho_usage, auto_deduction_key, auto_deduction_per_attachment)
    VALUES (?, 0, ?, ?, ?, ?, ?, ?, ?)`);
  const update = sqlite.prepare("UPDATE inventory_items SET name = ?, unit = ?, specialty_id = ?, category_id = ?, catalog_group = ?, ortho_usage = ?, auto_deduction_key = ? WHERE id = ?");
  for (const item of items) {
    const existing = byName.get(item.name) as { id: number } | undefined;
    const legacy = !existing && item.legacyName ? byName.get(item.legacyName) as { id: number } | undefined : undefined;
    const categoryId = categoryIds.get(item.category);
    if (!categoryId) continue;
    if (existing || legacy) {
      update.run(item.name, item.unit, specialty.id, categoryId, item.group, item.orthoUsage, item.autoDeductionKey ?? null, (existing ?? legacy)!.id);
    } else {
      insert.run(item.name, item.unit, specialty.id, categoryId, item.group, item.orthoUsage, item.autoDeductionKey ?? null, item.autoDeductionPerAttachment ?? 0);
    }
  }

  // ترتيب النسخ التجريبية القديمة من الكتالوج: ننقل أي خامة تحت فئتها
  // المعتمدة، ثم نحذف الفئات/المنتجات المتكررة غير المستخدمة في الواجهة.
  // لا تلمس هذه الخطوة أرصدة الخامات أو حركاتها.
  const categoryAliases: Record<string, string[]> = {
    TADS: ["ANCHORAGE"],
    BRACKETS: ["BRACKET"],
    TUBES: ["TUBE"],
    WIRES: ["WIRE"],
    ELASTICS: ["ELASTIC"],
    AUXILIARIES: ["AUXILIARY", "BUTTONS", "COMPRESSED COIL"],
  };
  const allCategories = sqlite.prepare("SELECT id, name FROM inventory_categories WHERE specialty_id = ?").all(specialty.id) as Array<{ id: number; name: string }>;
  const removeProductsForCategory = (oldCategoryId: number) => {
    sqlite.prepare("UPDATE inventory_items SET product_id = NULL WHERE product_id IN (SELECT id FROM inventory_products WHERE category_id = ?)").run(oldCategoryId);
    sqlite.prepare("DELETE FROM inventory_attribute_values WHERE attribute_group_id IN (SELECT id FROM inventory_attribute_groups WHERE product_id IN (SELECT id FROM inventory_products WHERE category_id = ?))").run(oldCategoryId);
    sqlite.prepare("DELETE FROM inventory_attribute_groups WHERE product_id IN (SELECT id FROM inventory_products WHERE category_id = ?)").run(oldCategoryId);
    sqlite.prepare("DELETE FROM inventory_products WHERE category_id = ?").run(oldCategoryId);
  };
  for (const [canonical, aliases] of Object.entries(categoryAliases)) {
    const targetId = categoryIds.get(canonical);
    if (!targetId) continue;
    for (const old of allCategories) {
      if (old.id === targetId || ![canonical, ...aliases].includes(old.name.toUpperCase())) continue;
      sqlite.prepare("UPDATE inventory_items SET category_id = ? WHERE category_id = ?").run(targetId, old.id);
      removeProductsForCategory(old.id);
      sqlite.prepare("DELETE FROM inventory_categories WHERE id = ?").run(old.id);
    }
  }
  // اسم Elastomerics كان غامضاً ويخفي الفرق العملي بين O-tie وPower chain.
  // بعد نقل الأصناف لفئتيهما الجديدتين نحذف الفئة القديمة فقط، من دون حذف أي
  // لون أو رصيد أو سجل حركة.
  for (const old of allCategories) {
    if (old.name.toUpperCase() !== "ELASTOMERICS") continue;
    removeProductsForCategory(old.id);
    sqlite.prepare("DELETE FROM inventory_categories WHERE id = ?").run(old.id);
  }
  // أنابيب الشركات/الـprescriptions القديمة لا تظهر للطبيب. نحتفظ بها فقط
  // كسجل مخزون قديم، بينما الاختيار في الشارت هو Orthodontic tube الواحد.
  sqlite.prepare("UPDATE inventory_items SET active = 0, available_in_clinical_selection = 0 WHERE ortho_usage = 'tube' AND name <> 'Orthodontic tube'").run();
  // البراكتس لا تتعامل كصنف إجمالي. كل شركة × سن لها رصيد مستقل في الجدول
  // المخصص أدناه، ولذلك نخفي الكتالوج القديم (Roth/MBT/slot) من الواجهة.
  sqlite.prepare("UPDATE inventory_items SET active = 0, available_in_clinical_selection = 0 WHERE ortho_usage = 'bracket'").run();
  const bracketTeeth = [15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 45, 44, 43, 42, 41, 31, 32, 33, 34, 35];
  const addBracketCell = sqlite.prepare("INSERT INTO orthodontic_bracket_stock (brand, fdi, quantity) VALUES (?, ?, 0) ON CONFLICT(brand, fdi) DO NOTHING");
  for (const brand of ["American", "Ormco"]) for (const fdi of bracketTeeth) addBracketCell.run(brand, fdi);

  // مستهلكات عامة: لا ترتبط بخدمة تقويم بعينها، لكنها جاهزة لتحديد متوسط
  // الاستهلاك لكل مريض «تم» من صفحة المخزن (Gloves مثلاً = 2 pair).
  sqlite.prepare("INSERT INTO inventory_specialties (name) VALUES (?) ON CONFLICT(name) DO NOTHING").run("مستهلكات عامة");
  const consumablesSpecialty = sqlite.prepare("SELECT id FROM inventory_specialties WHERE name = ?").get("مستهلكات عامة") as { id: number };
  sqlite.prepare("INSERT INTO inventory_categories (specialty_id, name) VALUES (?, ?) ON CONFLICT(specialty_id, name) DO NOTHING").run(consumablesSpecialty.id, "GENERAL CONSUMABLES");
  const consumablesCategory = sqlite.prepare("SELECT id FROM inventory_categories WHERE specialty_id = ? AND name = ?").get(consumablesSpecialty.id, "GENERAL CONSUMABLES") as { id: number };
  const consumables = [
    ["Gloves", "pair"], ["Napkins", "piece"], ["Suction tips", "piece"], ["Air tips", "piece"],
    ["Cups", "piece"], ["Over gloves", "pair"], ["Tissues", "piece"], ["Sleeves", "piece"],
  ] as const;
  const findGeneral = sqlite.prepare("SELECT id FROM inventory_items WHERE name = ?");
  const insertGeneral = sqlite.prepare(`INSERT INTO inventory_items (name, quantity, unit, specialty_id, category_id, catalog_group, is_general_consumable)
    VALUES (?, 0, ?, ?, ?, 'General consumables', 1)`);
  const updateGeneral = sqlite.prepare("UPDATE inventory_items SET unit = ?, specialty_id = ?, category_id = ?, catalog_group = 'General consumables', is_general_consumable = 1 WHERE id = ?");
  for (const [name, unit] of consumables) {
    const existing = findGeneral.get(name) as { id: number } | undefined;
    if (existing) updateGeneral.run(unit, consumablesSpecialty.id, consumablesCategory.id, existing.id);
    else insertGeneral.run(name, unit, consumablesSpecialty.id, consumablesCategory.id);
  }
}
