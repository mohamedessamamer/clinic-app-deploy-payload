"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { isExpenseCategory, monthBounds } from "@/lib/expenses";
import { calculateDoctorPayroll, getDoctorCollectedForMonth } from "@/lib/doctor-payroll";
import { getClinicToday } from "@/lib/clinic-date";

function text(formData: FormData, key: string) {
  return String(formData.get(key) ?? "").trim();
}

function positiveAmount(formData: FormData, key: string) {
  const value = Number(formData.get(key));
  return Number.isFinite(value) && value > 0 ? Math.round(value * 100) / 100 : null;
}

function validDate(value: string) {
  return /^\d{4}-\d{2}-\d{2}$/.test(value);
}

async function canManageExpenses() {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "manage_expenses"))) return null;
  return session;
}

function refreshExpenses() {
  revalidatePath("/expenses");
  revalidatePath("/reports");
}

export async function addExpenseAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const category = text(formData, "category");
  const title = text(formData, "title");
  const amount = positiveAmount(formData, "amount");
  const expenseDate = text(formData, "expense_date");
  if (!isExpenseCategory(category) || !title || !amount || !validDate(expenseDate)) return;
  await db
    .insertInto("expenses")
    .values({
      expense_date: expenseDate,
      category,
      title,
      payee: text(formData, "payee") || null,
      amount,
      payment_method: text(formData, "payment_method") || null,
      note: text(formData, "note") || null,
      source_type: "manual",
      source_id: null,
      template_id: null,
      created_by: session.userId,
    })
    .execute();
  refreshExpenses();
}

export async function addExpenseTemplateAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const category = text(formData, "category");
  const title = text(formData, "title");
  const amount = positiveAmount(formData, "default_amount");
  if (!isExpenseCategory(category) || !title || !amount) return;
  await db
    .insertInto("expense_templates")
    .values({
      title,
      category,
      payee: text(formData, "payee") || null,
      default_amount: amount,
      note: text(formData, "note") || null,
      created_by: session.userId,
    })
    .execute();
  refreshExpenses();
}

export async function recordExpenseTemplateAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const templateId = Number(formData.get("template_id"));
  const expenseDate = text(formData, "expense_date");
  if (!Number.isInteger(templateId) || templateId <= 0 || !validDate(expenseDate)) return;
  const [template, range] = await Promise.all([
    db.selectFrom("expense_templates").selectAll().where("id", "=", templateId).where("active", "=", 1).executeTakeFirst(),
    Promise.resolve(monthBounds(expenseDate.slice(0, 7))),
  ]);
  if (!template || !range) return;
  const existing = await db
    .selectFrom("expenses")
    .select("id")
    .where("template_id", "=", template.id)
    .where("expense_date", ">=", range.from)
    .where("expense_date", "<=", range.to)
    .executeTakeFirst();
  if (existing) return;
  await db
    .insertInto("expenses")
    .values({
      expense_date: expenseDate,
      category: template.category,
      title: template.title,
      payee: template.payee,
      amount: template.default_amount,
      payment_method: text(formData, "payment_method") || "cash",
      note: template.note,
      source_type: "template",
      source_id: null,
      template_id: template.id,
      created_by: session.userId,
    })
    .execute();
  refreshExpenses();
}

export async function deleteExpenseAction(formData: FormData): Promise<{ ok: boolean; reason?: string }> {
  const session = await canManageExpenses();
  if (!session) return { ok: false, reason: "مفيش صلاحية لإدارة المصروفات." };
  const id = Number(formData.get("expense_id"));
  if (!Number.isInteger(id) || id <= 0) return { ok: false, reason: "بيان المصروف غير صالح." };
  const expense = await db.selectFrom("expenses").select(["id", "source_type"]).where("id", "=", id).executeTakeFirst();
  if (!expense) return { ok: false, reason: "المصروف غير موجود." };
  if (expense.source_type === "inventory_supply") {
    return { ok: false, reason: "هذا المصروف جاء من توريد مخزن؛ صحّح التوريد من المخزن حتى يظل الجرد والتقارير متطابقين." };
  }
  if (expense.source_type === "doctor_payroll") {
    return { ok: false, reason: "هذا المصروف جاء من كشف راتب طبيب؛ صحّح كشف الراتب حتى يظل الاستحقاق والمصروف متطابقين." };
  }
  await db.deleteFrom("expenses").where("id", "=", id).execute();
  refreshExpenses();
  return { ok: true };
}

export async function saveDoctorCompensationRuleAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const doctorId = Number(formData.get("doctor_id"));
  const compensationType = text(formData, "compensation_type");
  const fixedAmount = nonNegativeAmount(formData, "fixed_amount");
  const percentage = nonNegativeAmount(formData, "percentage");
  const effectiveFrom = text(formData, "effective_from");
  if (!Number.isInteger(doctorId) || doctorId <= 0 || !["fixed", "percentage", "mixed"].includes(compensationType) || fixedAmount == null || percentage == null || percentage > 100 || !validDate(effectiveFrom)) return;
  if ((compensationType === "fixed" && fixedAmount <= 0) || (compensationType === "percentage" && percentage <= 0) || (compensationType === "mixed" && fixedAmount <= 0 && percentage <= 0)) return;
  const doctor = await db.selectFrom("doctors").select("id").where("id", "=", doctorId).where("active", "=", 1).executeTakeFirst();
  if (!doctor) return;
  await db
    .insertInto("doctor_compensation_rules")
    .values({ doctor_id: doctorId, compensation_type: compensationType as "fixed" | "percentage" | "mixed", fixed_amount: compensationType === "percentage" ? 0 : fixedAmount, percentage: compensationType === "fixed" ? 0 : percentage, effective_from: effectiveFrom, created_by: session.userId })
    .onConflict((oc) => oc.column("doctor_id").doUpdateSet({ compensation_type: compensationType as "fixed" | "percentage" | "mixed", fixed_amount: compensationType === "percentage" ? 0 : fixedAmount, percentage: compensationType === "fixed" ? 0 : percentage, effective_from: effectiveFrom, active: 1, created_by: session.userId, updated_at: new Date().toISOString() }))
    .execute();
  refreshExpenses();
}

function nonNegativeAmount(formData: FormData, key: string) {
  const value = Number(formData.get(key));
  return Number.isFinite(value) && value >= 0 ? Math.round(value * 100) / 100 : null;
}

async function payrollValuesForRule(doctorId: number, month: string) {
  const rule = await db.selectFrom("doctor_compensation_rules").selectAll().where("doctor_id", "=", doctorId).where("active", "=", 1).executeTakeFirst();
  if (!rule) return null;
  const collectedAmount = await getDoctorCollectedForMonth(doctorId, month);
  return { rule, ...calculateDoctorPayroll(rule, collectedAmount) };
}

export async function createDoctorPayrollRunAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const doctorId = Number(formData.get("doctor_id"));
  const month = text(formData, "period_month");
  if (!Number.isInteger(doctorId) || doctorId <= 0 || !monthBounds(month)) return;
  const values = await payrollValuesForRule(doctorId, month);
  if (!values) return;
  await db
    .insertInto("doctor_payroll_runs")
    .values({ doctor_id: doctorId, period_month: month, fixed_amount: values.fixedAmount, percentage: values.rule.percentage, collected_amount: values.collectedAmount, percentage_amount: values.percentageAmount, total_amount: values.totalAmount, status: "draft", paid_date: null, expense_id: null, created_by: session.userId, paid_by: null })
    .onConflict((oc) => oc.columns(["doctor_id", "period_month"]).doNothing())
    .execute();
  refreshExpenses();
}

export async function refreshDoctorPayrollRunAction(formData: FormData) {
  const session = await canManageExpenses();
  if (!session) return;
  const runId = Number(formData.get("payroll_run_id"));
  if (!Number.isInteger(runId) || runId <= 0) return;
  const run = await db.selectFrom("doctor_payroll_runs").select(["id", "doctor_id", "period_month", "status"]).where("id", "=", runId).executeTakeFirst();
  if (!run || run.status !== "draft") return;
  const values = await payrollValuesForRule(run.doctor_id, run.period_month);
  if (!values) return;
  await db.updateTable("doctor_payroll_runs").set({ fixed_amount: values.fixedAmount, percentage: values.rule.percentage, collected_amount: values.collectedAmount, percentage_amount: values.percentageAmount, total_amount: values.totalAmount }).where("id", "=", run.id).execute();
  refreshExpenses();
}

export async function payDoctorPayrollRunAction(formData: FormData): Promise<void> {
  const session = await canManageExpenses();
  if (!session) return;
  const runId = Number(formData.get("payroll_run_id"));
  const paidDate = text(formData, "paid_date") || getClinicToday();
  const paymentMethod = text(formData, "payment_method") || "cash";
  if (!Number.isInteger(runId) || runId <= 0 || !validDate(paidDate)) return;
  const result = await db.transaction().execute(async (trx) => {
    const run = await trx
      .selectFrom("doctor_payroll_runs")
      .innerJoin("doctors", "doctors.id", "doctor_payroll_runs.doctor_id")
      .select(["doctor_payroll_runs.id", "doctor_payroll_runs.period_month", "doctor_payroll_runs.total_amount", "doctor_payroll_runs.status", "doctors.full_name as doctor_name"])
      .where("doctor_payroll_runs.id", "=", runId)
      .executeTakeFirst();
    if (!run) return { ok: false, reason: "كشف الراتب غير موجود." };
    if (run.status === "paid") return { ok: false, reason: "تم صرف هذا الكشف بالفعل." };
    if (run.total_amount <= 0) return { ok: false, reason: "لا يوجد استحقاق موجب لصرفه في هذا الكشف." };
    const inserted = await trx
      .insertInto("expenses")
      .values({ expense_date: paidDate, category: "salary", title: `استحقاق ${run.doctor_name} — ${run.period_month}`, payee: run.doctor_name, amount: run.total_amount, payment_method: paymentMethod, note: "تم إنشاؤه تلقائياً من كشف راتب الطبيب", source_type: "doctor_payroll", source_id: run.id, template_id: null, created_by: session.userId })
      .executeTakeFirstOrThrow();
    await trx
      .updateTable("doctor_payroll_runs")
      .set({ status: "paid", paid_date: paidDate, expense_id: Number(inserted.insertId), paid_by: session.userId })
      .where("id", "=", run.id)
      .execute();
    return { ok: true };
  });
  if (result.ok) refreshExpenses();
}
