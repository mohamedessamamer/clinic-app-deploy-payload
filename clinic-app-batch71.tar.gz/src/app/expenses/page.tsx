import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { getClinicToday } from "@/lib/clinic-date";
import { EXPENSE_CATEGORIES, EXPENSE_CATEGORY_LABELS, getExpenseSummary, monthBounds } from "@/lib/expenses";
import { calculateDoctorPayroll, getDoctorCollectedForMonth } from "@/lib/doctor-payroll";
import { PAYMENT_METHODS, paymentMethodLabel } from "@/lib/payment-methods";
import { addExpenseAction, addExpenseTemplateAction, createDoctorPayrollRunAction, payDoctorPayrollRunAction, recordExpenseTemplateAction, refreshDoctorPayrollRunAction, saveDoctorCompensationRuleAction } from "./actions";
import DeleteExpenseButton from "@/components/DeleteExpenseButton";

export default async function ExpensesPage({ searchParams }: { searchParams: Promise<{ month?: string }> }) {
  const session = await getSession();
  const canManage = session ? await hasPermission(session.userId, session.role, "manage_expenses") : false;
  if (!canManage) return <div className="card-3d rounded-xl p-5 text-sm text-muted">مفيش صلاحية عندك لعرض المصروفات — كلم الأدمن لو محتاج توصل لها.</div>;

  const { month: requestedMonth } = await searchParams;
  const today = getClinicToday();
  const month = monthBounds(requestedMonth ?? "") ? requestedMonth! : today.slice(0, 7);
  const range = monthBounds(month)!;
  const [expenses, templates, summary, collectedRow, doctors, rules, payrollRuns] = await Promise.all([
    db.selectFrom("expenses").selectAll().where("expense_date", ">=", range.from).where("expense_date", "<=", range.to).orderBy("expense_date", "desc").orderBy("id", "desc").execute(),
    db.selectFrom("expense_templates").selectAll().where("active", "=", 1).orderBy("category").orderBy("title").execute(),
    getExpenseSummary(range.from, range.to),
    db.selectFrom("invoices").select((eb) => eb.fn.sum<number>("paid").as("collected")).where("invoice_date", ">=", range.from).where("invoice_date", "<=", range.to).executeTakeFirst(),
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).orderBy("full_name").execute(),
    db.selectFrom("doctor_compensation_rules").innerJoin("doctors", "doctors.id", "doctor_compensation_rules.doctor_id").select(["doctor_compensation_rules.id", "doctor_compensation_rules.doctor_id", "doctor_compensation_rules.compensation_type", "doctor_compensation_rules.fixed_amount", "doctor_compensation_rules.percentage", "doctor_compensation_rules.effective_from", "doctors.full_name as doctor_name"]).where("doctor_compensation_rules.active", "=", 1).orderBy("doctors.full_name").execute(),
    db.selectFrom("doctor_payroll_runs").innerJoin("doctors", "doctors.id", "doctor_payroll_runs.doctor_id").select(["doctor_payroll_runs.id", "doctor_payroll_runs.doctor_id", "doctor_payroll_runs.period_month", "doctor_payroll_runs.fixed_amount", "doctor_payroll_runs.percentage", "doctor_payroll_runs.collected_amount", "doctor_payroll_runs.percentage_amount", "doctor_payroll_runs.total_amount", "doctor_payroll_runs.status", "doctor_payroll_runs.paid_date", "doctors.full_name as doctor_name"]).where("doctor_payroll_runs.period_month", "=", month).orderBy("doctors.full_name").execute(),
  ]);
  const collected = Number(collectedRow?.collected ?? 0);
  const templateIdsRecorded = new Set(expenses.map((expense) => expense.template_id).filter((id): id is number => id != null));
  const runByDoctor = new Map(payrollRuns.map((run) => [run.doctor_id, run]));
  const payrollPreview = await Promise.all(
    rules
      .filter((rule) => rule.effective_from <= range.to)
      .map(async (rule) => ({ rule, values: calculateDoctorPayroll(rule, await getDoctorCollectedForMonth(rule.doctor_id, month)), run: runByDoctor.get(rule.doctor_id) }))
  );

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-xl font-bold">المصروفات</h1>
          <p className="text-sm text-muted mt-1">المصاريف اليدوية وتوريدات المخزن تظهر في سجل واحد؛ توريد المخزن لا يُسجّل مرتين.</p>
        </div>
        <form className="flex items-center gap-2 text-sm">
          <label className="text-muted" htmlFor="expense-month">الشهر:</label>
          <input id="expense-month" name="month" type="month" defaultValue={month} className="rounded-md border border-border bg-surface px-2 py-1.5" />
          <button className="rounded-md border border-border px-3 py-1.5 hover:bg-primary-soft">عرض</button>
        </form>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="card-3d rounded-xl p-4"><div className="text-xs text-muted">المحصّل في الشهر</div><div className="text-2xl font-bold text-primary">{collected.toFixed(0)} ج.م</div></div>
        <div className="card-3d rounded-xl p-4"><div className="text-xs text-muted">إجمالي المصروفات</div><div className="text-2xl font-bold text-danger">{summary.total.toFixed(0)} ج.م</div></div>
        <div className="card-3d rounded-xl p-4"><div className="text-xs text-muted">صافي النقدية</div><div className={`text-2xl font-bold ${collected - summary.total >= 0 ? "text-primary" : "text-danger"}`}>{(collected - summary.total).toFixed(0)} ج.م</div></div>
      </div>

      <div className="card-3d rounded-xl p-4">
        <div className="text-sm font-semibold mb-3">ملخص حسب البند</div>
        <div className="flex flex-wrap gap-x-5 gap-y-2 text-sm">
          {EXPENSE_CATEGORIES.map((category) => <div key={category}><span className="text-muted">{EXPENSE_CATEGORY_LABELS[category]}: </span><b>{(summary.byCategory.get(category) ?? 0).toFixed(0)} ج.م</b></div>)}
        </div>
      </div>

      <section className="card-3d rounded-xl p-5 space-y-3">
        <div><h2 className="font-semibold">تسجيل مصروف</h2><p className="text-xs text-muted mt-1">استخدمه للمصاريف اليومية، الفواتير، والبيانات القديمة. الخامات الجديدة القادمة من المخزن ستُضاف تلقائيًا.</p></div>
        <form action={addExpenseAction} className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 items-end">
          <label><span className="block text-xs text-muted mb-1">التاريخ *</span><input name="expense_date" type="date" required defaultValue={today} className="w-full rounded border border-border bg-background px-2 py-1.5 text-sm" /></label>
          <label><span className="block text-xs text-muted mb-1">التصنيف *</span><select name="category" defaultValue="petty" className="w-full rounded border border-border bg-background px-2 py-1.5 text-sm">{EXPENSE_CATEGORIES.map((category) => <option key={category} value={category}>{EXPENSE_CATEGORY_LABELS[category]}</option>)}</select></label>
          <label><span className="block text-xs text-muted mb-1">البند *</span><input name="title" required placeholder="مثال: فاتورة مياه أو إيجار" className="w-full rounded border border-border bg-background px-2 py-1.5 text-sm" /></label>
          <label><span className="block text-xs text-muted mb-1">المبلغ *</span><input name="amount" type="number" min="0.01" step="0.01" required className="w-full rounded border border-border bg-background px-2 py-1.5 text-sm" /></label>
          <label><span className="block text-xs text-muted mb-1">المدفوع له / المورد</span><input name="payee" placeholder="اختياري" className="w-full rounded border border-border bg-background px-2 py-1.5 text-sm" /></label>
          <label><span className="block text-xs text-muted mb-1">وسيلة الدفع</span><select name="payment_method" defaultValue="cash" className="w-full rounded border border-border bg-background px-2 py-1.5 text-sm"><option value="">غير محدد</option>{PAYMENT_METHODS.map((method) => <option key={method.value} value={method.value}>{method.label}</option>)}</select></label>
          <label className="sm:col-span-2"><span className="block text-xs text-muted mb-1">ملاحظة</span><input name="note" placeholder="اختياري" className="w-full rounded border border-border bg-background px-2 py-1.5 text-sm" /></label>
          <button className="rounded-md btn-3d-primary px-4 py-2 text-sm">حفظ المصروف</button>
        </form>
      </section>

      <section className="card-3d rounded-xl p-5 space-y-3">
        <div><h2 className="font-semibold">مصروف متكرر</h2><p className="text-xs text-muted mt-1">للراتب أو الإيجار: عرّف القيمة الافتراضية مرة، ثم سجّلها في الشهر عند دفعها.</p></div>
        <form action={addExpenseTemplateAction} className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-3 items-end">
          <label><span className="block text-xs text-muted mb-1">البند *</span><input name="title" required placeholder="راتب هند" className="w-full rounded border border-border bg-background px-2 py-1.5 text-sm" /></label>
          <label><span className="block text-xs text-muted mb-1">التصنيف *</span><select name="category" defaultValue="salary" className="w-full rounded border border-border bg-background px-2 py-1.5 text-sm">{["salary", "fixed", "other"].map((category) => <option key={category} value={category}>{EXPENSE_CATEGORY_LABELS[category as keyof typeof EXPENSE_CATEGORY_LABELS]}</option>)}</select></label>
          <label><span className="block text-xs text-muted mb-1">القيمة الافتراضية *</span><input name="default_amount" type="number" min="0.01" step="0.01" required className="w-full rounded border border-border bg-background px-2 py-1.5 text-sm" /></label>
          <label><span className="block text-xs text-muted mb-1">المدفوع له</span><input name="payee" placeholder="اختياري" className="w-full rounded border border-border bg-background px-2 py-1.5 text-sm" /></label>
          <button className="rounded-md border border-border px-4 py-2 text-sm hover:bg-primary-soft">إضافة بند متكرر</button>
        </form>
        {templates.length > 0 && <div className="overflow-x-auto"><table className="w-full text-sm"><thead className="bg-primary-soft text-primary-dark"><tr><th className="px-3 py-2 text-right">البند</th><th className="px-3 py-2 text-right">التصنيف</th><th className="px-3 py-2 text-right">القيمة</th><th className="px-3 py-2 text-right">تسجيل في هذا الشهر</th></tr></thead><tbody>{templates.map((template) => <tr key={template.id} className="border-t border-border"><td className="px-3 py-2">{template.title}{template.payee ? ` — ${template.payee}` : ""}</td><td className="px-3 py-2">{EXPENSE_CATEGORY_LABELS[template.category as keyof typeof EXPENSE_CATEGORY_LABELS] ?? template.category}</td><td className="px-3 py-2">{template.default_amount.toFixed(0)} ج.م</td><td className="px-3 py-2">{templateIdsRecorded.has(template.id) ? <span className="text-primary">تم تسجيله</span> : <form action={recordExpenseTemplateAction} className="flex flex-wrap gap-2 items-center"><input type="hidden" name="template_id" value={template.id} /><input name="expense_date" type="date" required defaultValue={today.startsWith(month) ? today : range.from} className="rounded border border-border bg-background px-2 py-1 text-xs" /><select name="payment_method" defaultValue="cash" className="rounded border border-border bg-background px-2 py-1 text-xs">{PAYMENT_METHODS.map((method) => <option key={method.value} value={method.value}>{method.label}</option>)}</select><button className="rounded border border-border px-2 py-1 text-xs hover:bg-primary-soft">تسجيل</button></form>}</td></tr>)}</tbody></table></div>}
      </section>

      <section className="card-3d rounded-xl p-5 space-y-4">
        <div><h2 className="font-semibold">كشوف رواتب ونسب الأطباء</h2><p className="text-xs text-muted mt-1">النسبة تُحسب من المحصّل المنسوب للطبيب في الشهر، ويفضل إنشاء كشف أولًا ثم صرفه بعد المراجعة. الصرف وحده هو الذي ينشئ مصروف راتب تلقائيًا.</p></div>
        <form action={saveDoctorCompensationRuleAction} className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-3 items-end rounded-lg border border-border p-3">
          <label><span className="block text-xs text-muted mb-1">الدكتور *</span><select name="doctor_id" required className="w-full rounded border border-border bg-background px-2 py-1.5 text-sm"><option value="">اختر الطبيب</option>{doctors.map((doctor) => <option key={doctor.id} value={doctor.id}>{doctor.full_name}</option>)}</select></label>
          <label><span className="block text-xs text-muted mb-1">طريقة الاستحقاق *</span><select name="compensation_type" defaultValue="percentage" className="w-full rounded border border-border bg-background px-2 py-1.5 text-sm"><option value="fixed">مبلغ ثابت</option><option value="percentage">نسبة من المحصّل</option><option value="mixed">ثابت + نسبة</option></select></label>
          <label><span className="block text-xs text-muted mb-1">المبلغ الثابت</span><input name="fixed_amount" type="number" min="0" step="0.01" defaultValue="0" className="w-full rounded border border-border bg-background px-2 py-1.5 text-sm" /></label>
          <label><span className="block text-xs text-muted mb-1">النسبة %</span><input name="percentage" type="number" min="0" max="100" step="0.01" defaultValue="0" className="w-full rounded border border-border bg-background px-2 py-1.5 text-sm" /></label>
          <label><span className="block text-xs text-muted mb-1">تسري من *</span><input name="effective_from" type="date" required defaultValue={today} className="w-full rounded border border-border bg-background px-2 py-1.5 text-sm" /></label>
          <button className="rounded-md border border-border px-4 py-2 text-sm hover:bg-primary-soft">حفظ قاعدة الدكتور</button>
        </form>
        {rules.length > 0 && <div className="text-sm flex flex-wrap gap-x-5 gap-y-2">{rules.map((rule) => <div key={rule.id}><b>{rule.doctor_name}</b><span className="text-muted"> — {rule.compensation_type === "fixed" ? "ثابت" : rule.compensation_type === "percentage" ? "نسبة" : "ثابت + نسبة"}: {rule.fixed_amount > 0 ? `${rule.fixed_amount.toFixed(0)} ج.م` : ""}{rule.fixed_amount > 0 && rule.percentage > 0 ? " + " : ""}{rule.percentage > 0 ? `${rule.percentage}%` : ""} (من {rule.effective_from})</span></div>)}</div>}
        <div className="overflow-x-auto"><table className="w-full text-sm"><thead className="bg-primary-soft text-primary-dark"><tr><th className="px-3 py-2 text-right">الدكتور</th><th className="px-3 py-2 text-right">محصّل الشهر</th><th className="px-3 py-2 text-right">الثابت</th><th className="px-3 py-2 text-right">النسبة</th><th className="px-3 py-2 text-right">الاستحقاق</th><th className="px-3 py-2 text-right">الإجراء</th></tr></thead><tbody>{payrollPreview.map(({ rule, values, run }) => {
          const snapshot = run ?? { fixed_amount: values.fixedAmount, percentage: rule.percentage, collected_amount: values.collectedAmount, percentage_amount: values.percentageAmount, total_amount: values.totalAmount };
          return <tr key={rule.id} className="border-t border-border"><td className="px-3 py-2 font-medium">{rule.doctor_name}</td><td className="px-3 py-2">{snapshot.collected_amount.toFixed(0)} ج.م</td><td className="px-3 py-2">{snapshot.fixed_amount.toFixed(0)} ج.م</td><td className="px-3 py-2">{snapshot.percentage.toFixed(2)}% = {snapshot.percentage_amount.toFixed(0)} ج.م</td><td className="px-3 py-2 font-semibold">{snapshot.total_amount.toFixed(0)} ج.م</td><td className="px-3 py-2">{!run ? <form action={createDoctorPayrollRunAction}><input type="hidden" name="doctor_id" value={rule.doctor_id} /><input type="hidden" name="period_month" value={month} /><button className="rounded border border-border px-2 py-1 text-xs hover:bg-primary-soft">إنشاء كشف للمراجعة</button></form> : run.status === "paid" ? <span className="text-primary">تم الصرف {run.paid_date ?? ""}</span> : <div className="flex flex-wrap gap-2 items-center"><form action={refreshDoctorPayrollRunAction}><input type="hidden" name="payroll_run_id" value={run.id} /><button className="rounded border border-border px-2 py-1 text-xs hover:bg-primary-soft">تحديث الحساب</button></form><form action={payDoctorPayrollRunAction} className="flex gap-1 items-center"><input type="hidden" name="payroll_run_id" value={run.id} /><input name="paid_date" type="date" defaultValue={today} className="rounded border border-border bg-background px-1 py-1 text-xs" /><select name="payment_method" defaultValue="cash" className="rounded border border-border bg-background px-1 py-1 text-xs">{PAYMENT_METHODS.map((method) => <option key={method.value} value={method.value}>{method.label}</option>)}</select><button className="rounded-md btn-3d-primary px-2 py-1 text-xs">اعتماد وصرف</button></form></div>}</td></tr>;
        })}{payrollPreview.length === 0 && <tr><td colSpan={6} className="px-3 py-6 text-center text-muted">لا توجد قواعد رواتب سارية في هذا الشهر.</td></tr>}</tbody></table></div>
      </section>

      <section className="card-3d rounded-xl overflow-hidden">
        <div className="px-4 py-3 font-semibold">مصروفات {month}</div>
        <div className="overflow-x-auto"><table className="w-full text-sm"><thead className="bg-primary-soft text-primary-dark"><tr><th className="px-3 py-2 text-right">التاريخ</th><th className="px-3 py-2 text-right">التصنيف</th><th className="px-3 py-2 text-right">البند</th><th className="px-3 py-2 text-right">المدفوع له</th><th className="px-3 py-2 text-right">المبلغ</th><th className="px-3 py-2 text-right">الدفع</th><th className="px-3 py-2 text-right">ملاحظة</th><th className="px-3 py-2" /></tr></thead><tbody>{expenses.map((expense) => <tr key={expense.id} className="border-t border-border"><td className="px-3 py-2 whitespace-nowrap">{expense.expense_date}</td><td className="px-3 py-2">{EXPENSE_CATEGORY_LABELS[expense.category as keyof typeof EXPENSE_CATEGORY_LABELS] ?? expense.category}</td><td className="px-3 py-2 font-medium">{expense.title}{expense.source_type === "inventory_supply" && <span className="mr-2 text-xs text-muted">(توريد مخزن)</span>}</td><td className="px-3 py-2">{expense.payee ?? "-"}</td><td className="px-3 py-2 text-danger">{expense.amount.toFixed(0)} ج.م</td><td className="px-3 py-2">{paymentMethodLabel(expense.payment_method)}</td><td className="px-3 py-2 text-muted">{expense.note ?? "-"}</td><td className="px-3 py-2">{["manual", "template"].includes(expense.source_type) && <DeleteExpenseButton expenseId={expense.id} label={expense.title} />}</td></tr>)}{expenses.length === 0 && <tr><td colSpan={8} className="px-3 py-7 text-center text-muted">لا توجد مصروفات مسجلة لهذا الشهر.</td></tr>}</tbody></table></div>
      </section>
    </div>
  );
}
