import Link from "next/link";
import InventoryBrowser from "@/components/InventoryBrowser";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import {
  addSimpleInventoryItemAction,
  saveGeneralConsumableRuleAction,
} from "./actions";

const inputClass = "w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm";

const orthoLabels: Record<string, string> = {
  wire: "Wire", bracket: "Bracket", tube: "Tube", elastic: "Elastic", otie: "O-tie",
  power_chain: "Power chain", button: "Button", compressed_coil: "Compressed coil", anchorage_device: "Anchorage device",
};

export default async function InventoryPage() {
  const session = await getSession();
  const canManage = session ? await hasPermission(session.userId, session.role, "manage_inventory") : false;
  const canEditCatalog = session ? await hasPermission(session.userId, session.role, "edit_inventory_catalog") : false;
  const canDeleteInventory = session ? await hasPermission(session.userId, session.role, "delete_inventory_records") : false;
  if (!canManage) return <div className="card-3d rounded-xl p-5 text-sm text-muted">مفيش صلاحية عندك لعرض المخزن — كلم الأدمن لو محتاج توصل له.</div>;

  const [specialties, categories, suppliers, items, batches, bracketStock] = await Promise.all([
    db.selectFrom("inventory_specialties").select(["id", "name"]).where("active", "=", 1).orderBy("name").execute(),
    db.selectFrom("inventory_categories")
      .innerJoin("inventory_specialties", "inventory_specialties.id", "inventory_categories.specialty_id")
      .select(["inventory_categories.id", "inventory_categories.name", "inventory_categories.specialty_id", "inventory_specialties.name as specialty_name"])
      .where("inventory_categories.active", "=", 1)
      .orderBy("inventory_specialties.name").orderBy("inventory_categories.name").execute(),
    db.selectFrom("inventory_suppliers").select(["id", "name"]).where("active", "=", 1).orderBy("name").execute(),
    db.selectFrom("inventory_items")
      .leftJoin("inventory_specialties", "inventory_specialties.id", "inventory_items.specialty_id")
      .leftJoin("inventory_categories", "inventory_categories.id", "inventory_items.category_id")
      .leftJoin("inventory_suppliers", "inventory_suppliers.id", "inventory_items.supplier_id")
      .leftJoin("inventory_consumable_rules", "inventory_consumable_rules.item_id", "inventory_items.id")
      .select([
        "inventory_items.id", "inventory_items.name", "inventory_items.quantity", "inventory_items.unit", "inventory_items.specialty_id", "inventory_items.category_id", "inventory_items.catalog_group",
        "inventory_items.low_stock_threshold", "inventory_items.critical_stock_threshold", "inventory_items.reorder_quantity",
        "inventory_items.ortho_usage", "inventory_items.auto_deduction_key", "inventory_items.auto_deduction_per_attachment", "inventory_items.available_in_clinical_selection", "inventory_items.is_general_consumable", "inventory_specialties.name as specialty_name", "inventory_categories.name as category_name",
        "inventory_suppliers.name as preferred_supplier_name", "inventory_consumable_rules.quantity_per_completed_appointment",
        "inventory_consumable_rules.active as consumable_rule_active",
      ])
      .where("inventory_items.active", "=", 1)
      .orderBy("inventory_items.is_general_consumable", "desc").orderBy("inventory_items.name").execute(),
    db.selectFrom("inventory_supply_batches")
      .leftJoin("inventory_suppliers", "inventory_suppliers.id", "inventory_supply_batches.supplier_id")
      .select([
        "inventory_supply_batches.id", "inventory_supply_batches.item_id", "inventory_supply_batches.brand",
        "inventory_supply_batches.quantity_received", "inventory_supply_batches.quantity_remaining", "inventory_supply_batches.total_cost",
        "inventory_supply_batches.purchase_unit_label", "inventory_supply_batches.package_count", "inventory_supply_batches.units_per_package",
        "inventory_supply_batches.received_at", "inventory_suppliers.name as supplier_name",
      ])
      .orderBy("inventory_supply_batches.received_at", "asc").orderBy("inventory_supply_batches.id", "asc").execute(),
    db.selectFrom("orthodontic_bracket_stock").select(["brand", "fdi", "quantity"]).orderBy("brand").orderBy("fdi").execute(),
  ]);

  const generalItems = items.filter((item) => item.is_general_consumable === 1);

  return <div className="space-y-6">
    <div className="flex flex-wrap items-start justify-between gap-3">
      <div><h1 className="text-xl font-bold">المخزن</h1><p className="text-sm text-muted mt-1">الخامة سطر واحد للجرد ولشارت التقويم؛ الشركات والموردون توريدات تحتها.</p></div>
      <Link href="/settings" className="rounded-md border border-border px-3 py-2 text-sm hover:bg-primary-soft">إدارة الموردين والتخصصات</Link>
    </div>

    <InventoryBrowser specialties={specialties} categories={categories} canEditCatalog={canEditCatalog} canManage={canManage} canDeleteInventory={canDeleteInventory} suppliers={suppliers} bracketStock={bracketStock} batches={batches} items={items.map((item) => ({ id: item.id, name: item.name, quantity: item.quantity, unit: item.unit, specialty_id: item.specialty_id, category_id: item.category_id, catalog_group: item.catalog_group, critical_stock_threshold: item.critical_stock_threshold, auto_deduction_key: item.auto_deduction_key, auto_deduction_per_attachment: item.auto_deduction_per_attachment, available_in_clinical_selection: item.available_in_clinical_selection }))} />

    <section className="card-3d rounded-xl p-5 space-y-4">
      <div><h2 className="font-semibold">1) تعريف خامة علاجية أو مستهلك عام</h2><p className="text-xs text-muted mt-1">اكتب الخامة التي تريد جردها واختيارها طبيًا، مثل <b>NiTi 0.012</b> أو <b>O-tie Blue</b>، من غير شركة.</p></div>
      <form action={addSimpleInventoryItemAction} className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3 items-end">
        <div className="xl:col-span-2"><label className="block text-xs text-muted mb-1">اسم الخامة العلاجية *</label><input name="name" required placeholder="NiTi 0.012 أو O-tie Blue" className={inputClass} /></div>
        <div><label className="block text-xs text-muted mb-1">التخصص</label><select name="specialty_id" className={inputClass}><option value="">عام</option>{specialties.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></div>
        <div><label className="block text-xs text-muted mb-1">الفئة (اختياري)</label><select name="category_id" className={inputClass}><option value="">بدون فئة</option>{categories.map((category) => <option key={category.id} value={category.id}>{category.specialty_name} — {category.name}</option>)}</select></div>
        <div><label className="block text-xs text-muted mb-1">المجموعة الفرعية (اختياري)</label><input name="catalog_group" placeholder="مثال: NiTi أو O-tie" className={inputClass} /></div>
        <div><label className="block text-xs text-muted mb-1">وحدة الجرد *</label><input name="unit" required placeholder="Wire / قطعة / Pair" className={inputClass} /></div>
        <div><label className="block text-xs text-muted mb-1">استخدامه بشارت التقويم</label><select name="ortho_usage" className={inputClass}><option value="">ليس خامة شارت تقويم</option>{Object.entries(orthoLabels).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select></div>
        <label className="flex items-center gap-2 text-sm rounded-md border border-border px-3 py-2"><input type="checkbox" name="available_in_clinical_selection" value="1" defaultChecked /> متاح للاختيار الطبي</label>
        <label className="flex items-center gap-2 text-sm rounded-md border border-border px-3 py-2"><input type="checkbox" name="is_general_consumable" value="1" /> مستهلك عام لكل مريض تم</label>
        <div><label className="block text-xs text-muted mb-1">حد التنبيه</label><input name="low_stock_threshold" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} /></div>
        <div><label className="block text-xs text-muted mb-1">الحد الحرج</label><input name="critical_stock_threshold" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} /></div>
        <div><label className="block text-xs text-muted mb-1">كمية طلب مقترحة</label><input name="reorder_quantity" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} /></div>
        <div><label className="block text-xs text-muted mb-1">المورد المفضل للطلب</label><select name="preferred_supplier_id" className={inputClass}><option value="">يُحدد لاحقًا</option>{suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></div>
        <button className="rounded-md btn-3d-primary px-3 py-2 text-sm font-medium">حفظ الخامة</button>
      </form>
    </section>

    {generalItems.length > 0 && <section className="card-3d rounded-xl p-5 space-y-3">
      <div><h2 className="font-semibold">استهلاك المستهلكات العامة لكل مريض تم</h2><p className="text-xs text-muted mt-1">يخصم النظام الكمية مرة واحدة عند تحول الموعد إلى «تم». اتركها صفرًا لإيقاف الخصم التلقائي.</p></div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">{generalItems.map((item) => <form key={item.id} action={saveGeneralConsumableRuleAction} className="rounded-lg border border-border p-3 flex gap-2 items-end"><input type="hidden" name="item_id" value={item.id} /><div className="flex-1"><label className="block text-xs text-muted mb-1">{item.name} ({item.unit}) لكل مريض</label><input name="quantity_per_completed_appointment" type="number" min="0" step="0.01" defaultValue={item.consumable_rule_active ? item.quantity_per_completed_appointment ?? 0 : 0} className={inputClass} /></div><button className="rounded-md border border-border px-3 py-1.5 text-sm hover:bg-primary-soft">حفظ</button></form>)}</div>
    </section>}

  </div>;
}
