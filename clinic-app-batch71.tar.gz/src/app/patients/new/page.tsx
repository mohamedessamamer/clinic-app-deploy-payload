import NewPatientForm from "@/components/NewPatientForm";

export default function NewPatientPage() {
  return (
    <div className="max-w-lg mx-auto space-y-5">
      <h1 className="text-xl font-bold">مريض جديد</h1>

      <NewPatientForm />
    </div>
  );
}
