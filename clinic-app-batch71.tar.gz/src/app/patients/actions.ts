"use server";

import { revalidatePath } from "next/cache";
import path from "node:path";
import fs from "node:fs/promises";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";

// نفس مسار الرفع المستخدم في src/app/patients/[id]/actions.ts (لازم يتطابق بالظبط
// عشان مسح ملفات الصور من على القرص يشتغل صح).
const UPLOAD_ROOT = process.env.CLINIC_UPLOAD_DIR
  ? path.join(path.resolve(process.env.CLINIC_UPLOAD_DIR), "patients")
  : path.join(process.cwd(), "data", "uploads", "patients");

// بيمسح مريض (حالة) نهائيًا من النظام مع كل بياناته المرتبطة (زيارات، فواتيرها،
// مواعيد، مجموعات الصور/الأشعة والملفات نفسها على القرص) — للأدمن بس (فحص مباشر
// على الدور، مش عن طريق نظام الصلاحيات المرن العادي، لأن ده تحديدًا مطلوب يفضل
// حكرًا على الأدمن دايمًا من غير إمكانية منحه لحد تاني بالغلط). الهدف الأساسي:
// تنظيف حالات تجربة (test) اتعملت أثناء تجربة النظام. عملية لا رجعة فيها خالص —
// التأكيد بيحصل في الواجهة (window.confirm) قبل ما الأكشن ده يتستدعى أصلاً.
export async function deletePatientAction(formData: FormData): Promise<{ ok: boolean; reason?: string }> {
  const session = await getSession();
  if (!session || session.role !== "admin") return { ok: false, reason: "الحذف متاح للأدمن فقط." };

  const patientId = Number(formData.get("patient_id"));
  if (!patientId) return { ok: false, reason: "بيانات المريض غير صالحة." };

  // لازم نجيب مسارات ملفات الصور من قاعدة البيانات قبل ما نمسح صفوفها، عشان نقدر
  // نمسح الملفات نفسها من على القرص بعد كده.
  const imageRows = await db
    .selectFrom("patient_images")
    .innerJoin("patient_image_groups", "patient_image_groups.id", "patient_images.group_id")
    .select(["patient_images.file_path"])
    .where("patient_image_groups.patient_id", "=", patientId)
    .execute();

  await db.transaction().execute(async (trx) => {
    const patientVisits = await trx.selectFrom("visits").select("id").where("patient_id", "=", patientId).execute();
    const visitIds = patientVisits.map((v) => v.id);
    const patientInvoices = await trx.selectFrom("invoices").select("id").where("patient_id", "=", patientId).execute();
    const invoiceIds = patientInvoices.map((invoice) => invoice.id);

    const patientImageGroups = await trx
      .selectFrom("patient_image_groups")
      .select("id")
      .where("patient_id", "=", patientId)
      .execute();
    const groupIds = patientImageGroups.map((g) => g.id);
    // حالات الإشعارات باقية عمدًا بعد اختفاء إشعار الجرس 48 ساعة، ولذلك يجب
    // حذفها مع الإشعارات المرتبطة أولًا عند حذف ملف المريض. غياب الخطوتين دول
    // كان يخلّي SQLite يرفض حذف بعض المرضى رغم تنظيف المواعيد والفواتير.
    const notificationCases = await trx
      .selectFrom("notification_cases")
      .select("id")
      .where("patient_id", "=", patientId)
      .execute();
    const notificationCaseIds = notificationCases.map((row) => row.id);

    await trx.deleteFrom("notifications").where("patient_id", "=", patientId).execute();
    if (notificationCaseIds.length > 0) {
      await trx.deleteFrom("notifications").where("notification_case_id", "in", notificationCaseIds).execute();
      await trx.deleteFrom("notification_cases").where("id", "in", notificationCaseIds).execute();
    }

    // بيانات التقويم لها مفاتيح خارجية مستقلة عن visits العادي؛ من غير حذفها
    // الأول كانت بعض الحالات (مثل عائشة حسن/عماد السيد) تفشل عند حذف المريض.
    await trx.deleteFrom("ortho_inventory_deductions").where("patient_id", "=", patientId).execute();
    await trx.deleteFrom("ortho_visits").where("patient_id", "=", patientId).execute();
    await trx.deleteFrom("orthodontic_charts").where("patient_id", "=", patientId).execute();
    await trx.deleteFrom("collection_requests").where("patient_id", "=", patientId).execute();
    await trx.deleteFrom("patient_credits").where("patient_id", "=", patientId).execute();

    // فك أي إشارة "دفعة متابعة" قبل حذف الفواتير. مهم أن يشمل ذلك أي سجل قديم
    // لمريض آخر اتربط بالخطأ بفاتورة هذا المريض؛ وإلا تمنع FK حذف الحالة كلها.
    if (invoiceIds.length > 0) {
      await trx.updateTable("invoices").set({ parent_invoice_id: null }).where("parent_invoice_id", "in", invoiceIds).execute();
      await trx.updateTable("appointments").set({ purpose_linked_invoice_id: null }).where("purpose_linked_invoice_id", "in", invoiceIds).execute();
    }
    if (visitIds.length > 0) {
      await trx.updateTable("invoices").set({ parent_invoice_id: null }).where("visit_id", "in", visitIds).execute();
    }
    await trx.updateTable("invoices").set({ parent_invoice_id: null }).where("patient_id", "=", patientId).execute();

    if (groupIds.length > 0) {
      await trx.deleteFrom("patient_images").where("group_id", "in", groupIds).execute();
    }
    await trx.deleteFrom("patient_image_groups").where("patient_id", "=", patientId).execute();

    if (visitIds.length > 0) {
      await trx.deleteFrom("invoices").where("visit_id", "in", visitIds).execute();
    }
    await trx.deleteFrom("invoices").where("patient_id", "=", patientId).execute();
    await trx.deleteFrom("visits").where("patient_id", "=", patientId).execute();
    await trx.deleteFrom("appointments").where("patient_id", "=", patientId).execute();
    await trx.deleteFrom("patients").where("id", "=", patientId).execute();
  });

  // مسح ملفات الصور نفسها من على القرص - best-effort زي deleteImageAction، لو فايل
  // مش موجود أصلاً منسيبش الحذف كله يفشل بسبب كده.
  for (const row of imageRows) {
    if (!row.file_path.startsWith("/patient-files/")) continue;
    const relative = row.file_path.replace(/^\/patient-files\//, "");
    const filePath = path.join(path.dirname(UPLOAD_ROOT), relative);
    await fs.unlink(filePath).catch(() => {});
  }

  revalidatePath("/patients");
  revalidatePath("/front-desk");
  revalidatePath("/invoices");
  revalidatePath("/");
  return { ok: true };
}
