"use client";

import Link from "next/link";
import { useMemo, useState } from "react";

type Patient = { id:number; full_name:string; file_number:string };

export default function QuickPatientSearch({ patients }: { patients:Patient[] }) {
  const [query, setQuery] = useState("");
  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return q.length < 2 ? [] : patients.filter(p => p.full_name.toLowerCase().includes(q) || p.file_number.toLowerCase().includes(q)).slice(0,6);
  }, [patients, query]);
  return <div className="relative w-full sm:w-[22rem]">
    <input value={query} onChange={e=>setQuery(e.target.value)} className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary" placeholder="بحث عن مريض بالاسم أو رقم الملف..." />
    {results.length > 0 && <div className="absolute z-30 mt-1 w-full card-3d rounded-lg overflow-hidden">
      {results.map(p => <Link key={p.id} href={`/patients/${p.id}`} className="block border-b border-border last:border-0 px-3 py-2 hover:bg-primary-soft"><strong className="text-sm">{p.full_name}</strong><span className="block text-xs text-muted">{p.file_number}</span></Link>)}
    </div>}
  </div>;
}
