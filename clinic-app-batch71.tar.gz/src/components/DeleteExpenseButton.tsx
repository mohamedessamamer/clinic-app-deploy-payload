"use client";

import { useTransition } from "react";
import { deleteExpenseAction } from "@/app/expenses/actions";

export default function DeleteExpenseButton({ expenseId, label }: { expenseId: number; label: string }) {
  const [isPending, startTransition] = useTransition();
  return (
    <button
      type="button"
      disabled={isPending}
      className="text-xs text-danger hover:underline disabled:opacity-60"
      onClick={() => {
        if (!window.confirm(`هل تريد حذف مصروف «${label}»؟`)) return;
        const formData = new FormData();
        formData.set("expense_id", String(expenseId));
        startTransition(async () => {
          const result = await deleteExpenseAction(formData);
          if (!result.ok) window.alert(result.reason ?? "لم يتم حذف المصروف.");
        });
      }}
    >
      حذف
    </button>
  );
}
