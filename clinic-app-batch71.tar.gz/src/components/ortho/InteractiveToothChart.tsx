"use client";

// ===================================================================
// شارت التقويم v2 — "Interactive chart" (النسخة الحقيقية، مدموجة مع قاعدة
// البيانات، دمج 2026-08-27)
// ===================================================================
// نفس السلوك بالظبط اللي كان في البروتوتايب المعزول (src/components/prototype/
// InteractiveToothChart.tsx) — الفرق الوحيد إن كل أكشن بيغيّر حالة بيستدعي
// server action حقيقي بدل useState محلي بس. الـprops (teeth/stripCounts/
// miniscrews) جايين جاهزين من الصفحة (Server Component)، مش state داخلي —
// بعد كل أكشن ناجح بنعمل router.refresh() عشان الصفحة تجيب أحدث نسخة من
// قاعدة البيانات (تشمل تحديث الـInventory list والـInteractive report في
// الأب OrthoChartV2 كمان، مش بس الشارت نفسه).
//
// bulkBond اتشال من هنا (كان معرّض عن طريق ref في البروتوتايب) — دلوقتي
// التركيب الجماعي بيحصل جوه saveOrthoVisitAction نفسها لما الخدمة تكون
// "Bonding Upper/Lower" (transaction واحدة مع حفظ الزيارة)، فمفيش داعي لربط
// منفصل بين الكومبوننتين.

import { useState, useTransition } from "react";
import { getClinicToday } from "@/lib/clinic-date";
import { useRouter } from "next/navigation";
import { UPPER_ROW, LOWER_ROW, gapsFor, type ToothMeta } from "@/lib/ortho/fdi-teeth";
import {
  manualBondToothAction,
  confirmDebondAction,
  confirmNoBracketsAction,
  confirmRebondAction,
  toggleExtractedAction,
  recordStrippingAction,
  undoStrippingAction,
  toggleMiniscrewAction,
  saveToothCommentAction,
} from "@/app/patients/[id]/orthodontics/ortho-v2-actions";

export type BracketStatus = "none" | "bonded" | "broken";

export interface ToothState {
  bracket: BracketStatus;
  debondDate: string | null;
  bondedDate: string | null;
  rebondCount: number;
  extracted: boolean;
  comment: string;
}

type ToothStateMap = Record<number, ToothState>;
type GapMode = "none" | "stripping" | "miniscrew";
type ChartTab = "chart" | "treatment" | "occlusion";

// كل سن يُعرض من الرسم الواحد داخل SVG مستقل (من غير إنشاء crop files)، لذلك
// نقدر نرتّب التيجان في قوس حقيقي ونصغّرها من غير أي تغيير في الـFDI/actions.
const ARCH_X = [4.6, 10.8, 17.1, 23.1, 29.0, 34.8, 40.5, 46.4, 53.6, 59.5, 65.2, 71.0, 76.9, 82.9, 89.2, 95.4];
// These are calculated from the exact SVG wire curves below, after its
// viewBox-to-canvas scaling. A bracket centre therefore sits on the wire at
// every FDI position, including the molars at both ends of the arch.
const UPPER_Y = [132, 121, 112, 104, 98, 94, 91, 90, 90, 91, 94, 98, 104, 112, 121, 132];
const LOWER_Y = [258, 267, 274, 280, 285, 289, 291, 292, 292, 291, 289, 285, 280, 274, 267, 258];

type SourceBox = { x: number; y: number; w: number; h: number };

// Exact alpha bounds of every crown in hand-painted-full-mouth-transparent.png.
// These were measured from the transparent source, rather than inferred from
// tooth type. That is what prevents the vertical slices visible in batch 69.
const UPPER_SOURCE_BOXES: SourceBox[] = [
  { x:72,y:256,w:120,h:117 }, { x:189,y:256,w:115,h:116 }, { x:310,y:256,w:126,h:117 }, { x:422,y:244,w:96,h:126 },
  { x:516,y:237,w:92,h:137 }, { x:610,y:224,w:98,h:168 }, { x:700,y:222,w:86,h:144 }, { x:794,y:218,w:108,h:164 },
  { x:900,y:218,w:110,h:165 }, { x:994,y:224,w:88,h:144 }, { x:1086,y:224,w:95,h:166 }, { x:1178,y:238,w:88,h:136 },
  { x:1264,y:244,w:89,h:128 }, { x:1366,y:256,w:116,h:116 }, { x:1480,y:256,w:116,h:114 }, { x:1596,y:257,w:116,h:115 },
];
const LOWER_SOURCE_BOXES: SourceBox[] = [
  { x:80,y:672,w:121,h:118 }, { x:202,y:672,w:120,h:117 }, { x:324,y:672,w:122,h:118 }, { x:440,y:686,w:94,h:134 },
  { x:532,y:700,w:92,h:134 }, { x:626,y:716,w:98,h:166 }, { x:715,y:722,w:85,h:134 }, { x:798,y:722,w:87,h:136 },
  { x:883,y:722,w:87,h:135 }, { x:966,y:722,w:85,h:135 }, { x:1057,y:715,w:99,h:167 }, { x:1152,y:700,w:92,h:135 },
  { x:1241,y:688,w:91,h:132 }, { x:1350,y:672,w:119,h:117 }, { x:1470,y:672,w:118,h:117 }, { x:1589,y:672,w:119,h:117 },
];

function crownWidth(position: number): number {
  if (position >= 7) return 64;
  if (position === 6) return 61;
  if (position >= 4) return 57;
  if (position === 3) return 52;
  if (position === 2) return 56;
  return 65;
}

function CrownIllustration({ arch, fdi, index }: { arch: "upper" | "lower"; fdi: number; index: number }) {
  const source = (arch === "upper" ? UPPER_SOURCE_BOXES : LOWER_SOURCE_BOXES)[index];
  return (
    <svg viewBox={`${source.x - source.w / 2} ${source.y - source.h / 2} ${source.w} ${source.h}`} className={`ortho-chart-crown ortho-chart-crown--${arch}`} aria-label={`Tooth ${fdi}`}>
      <image href="/ortho-v2/illustrations/hand-painted-full-mouth-transparent.png" width="1672" height="941" preserveAspectRatio="xMidYMid meet" />
    </svg>
  );
}

function emptyToothState(): ToothState {
  return { bracket: "none", debondDate: null, bondedDate: null, rebondCount: 0, extracted: false, comment: "" };
}

function todayStr(): string {
  return getClinicToday();
}

function daysSince(dateStr: string | null): number | null {
  if (!dateStr) return null;
  const then = new Date(dateStr);
  if (Number.isNaN(then.getTime())) return null;
  return Math.floor((Date.now() - then.getTime()) / (1000 * 60 * 60 * 24));
}

const UPPER_GAPS = gapsFor(UPPER_ROW);
const LOWER_GAPS = gapsFor(LOWER_ROW);

function isMolarPosition(position: number): boolean {
  return position >= 6;
}

const ALL_TEETH = [...UPPER_ROW, ...LOWER_ROW];
const TOOTH_BY_FDI: Record<number, ToothMeta> = Object.fromEntries(ALL_TEETH.map((t) => [t.fdi, t]));

export default function InteractiveToothChart({
  patientId,
  editable,
  teeth,
  stripCounts,
  miniscrews,
  upperBulkBondingDate = null,
  lowerBulkBondingDate = null,
}: {
  patientId: number;
  editable: boolean;
  teeth: ToothStateMap;
  stripCounts: Record<string, number>;
  miniscrews: Record<string, boolean>;
  upperBulkBondingDate?: string | null;
  lowerBulkBondingDate?: string | null;
}) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();

  const [mode, setMode] = useState<GapMode>("none");
  const [activeTab, setActiveTab] = useState<ChartTab>("chart");
  const [rebondPrompt, setRebondPrompt] = useState<{ fdi: number } | null>(null);
  const [debondPrompt, setDebondPrompt] = useState<{ fdi: number } | null>(null);
  const [extractMenu, setExtractMenu] = useState<{ fdi: number; x: number; y: number } | null>(null);
  const [selectedTooth, setSelectedTooth] = useState<number | null>(null);
  const [commentDraft, setCommentDraft] = useState("");

  function stateFor(fdi: number): ToothState {
    return teeth[fdi] ?? emptyToothState();
  }

  function bondingDateFor(arch: "upper" | "lower"): string | null {
    const explicitDate = arch === "upper" ? upperBulkBondingDate : lowerBulkBondingDate;
    if (explicitDate) return explicitDate;
    // Older records may have tooth-level bonding dates but no bulk-bonding
    // field. Keep their clinical date visible instead of hiding the badge.
    const toothDates = (arch === "upper" ? UPPER_ROW : LOWER_ROW)
      .map((tooth) => stateFor(tooth.fdi).bondedDate)
      .filter((date): date is string => Boolean(date))
      .sort();
    return toothDates[0] ?? null;
  }

  function run(action: () => Promise<{ ok: boolean; reason?: string }>) {
    startTransition(async () => {
      const res = await action();
      if (!res.ok) window.alert(res.reason || "حصل خطأ، حاول تاني.");
      router.refresh();
    });
  }

  function handleBracketDoubleClick(t: ToothMeta) {
    if (!editable || isPending) return;
    const state = stateFor(t.fdi);
    if (state.bracket === "bonded") {
      setDebondPrompt({ fdi: t.fdi });
    } else if (state.bracket === "broken") {
      setRebondPrompt({ fdi: t.fdi });
    } else {
      if (state.extracted) {
        window.alert(`Tooth ${t.fdi} is marked extracted — it can't get a bracket/tube. Undo the extraction first (right-click the tooth) if this was a mistake.`);
        return;
      }
      const isMolar = isMolarPosition(t.position);
      if (window.confirm(`Bond a new ${isMolar ? "tube" : "bracket"} on tooth ${t.fdi}?`)) {
        run(() => manualBondToothAction({ patientId, fdi: t.fdi, date: todayStr() }));
      }
    }
  }

  function confirmDebonded() {
    if (!debondPrompt) return;
    const { fdi } = debondPrompt;
    run(() => confirmDebondAction({ patientId, fdi, date: todayStr() }));
    setDebondPrompt(null);
  }

  function confirmNoBrackets() {
    if (!debondPrompt) return;
    const { fdi } = debondPrompt;
    run(() => confirmNoBracketsAction({ patientId, fdi }));
    setDebondPrompt(null);
  }

  function confirmRebond(kind: "new" | "old") {
    if (!rebondPrompt) return;
    const { fdi } = rebondPrompt;
    run(() => confirmRebondAction({ patientId, fdi, kind, date: todayStr() }));
    setRebondPrompt(null);
  }

  function toggleExtracted() {
    if (!extractMenu) return;
    const { fdi } = extractMenu;
    run(() => toggleExtractedAction({ patientId, fdi }));
    setExtractMenu(null);
  }

  function handleGapClick(gapId: string) {
    if (!editable || isPending) return;
    if (mode === "stripping") {
      run(() => recordStrippingAction({ patientId, gapId }));
    } else if (mode === "miniscrew") {
      run(() => toggleMiniscrewAction({ patientId, gapId }));
    }
  }

  function handleStripUndo(gapId: string) {
    if (!editable || isPending) return;
    run(() => undoStrippingAction({ patientId, gapId }));
  }

  function saveComment() {
    if (selectedTooth == null) return;
    run(() => saveToothCommentAction({ patientId, fdi: selectedTooth, comment: commentDraft }));
  }

  function openToothDetails(fdi: number) {
    setSelectedTooth(fdi);
    setCommentDraft(stateFor(fdi).comment);
  }

  function backgroundClick() {
    if (mode !== "none") setMode("none");
    setSelectedTooth(null);
  }

  function bracketColor(status: BracketStatus) {
    // الشكل فقط هو الذي تغير: الزر نفسه والـdouble click والـstate/actions
    // كما هي. البراكيت صار مرسوماً كقطعة معدنية بدل المربع الأزرق.
    if (status === "bonded") return "ortho-bracket--bonded";
    if (status === "broken") return "ortho-bracket--broken";
    return "ortho-bracket--empty";
  }

  function useLongPress(onLongPress: (e: React.TouchEvent) => void) {
    let timer: ReturnType<typeof setTimeout> | null = null;
    let moved = false;
    let startX = 0,
      startY = 0;
    return {
      onTouchStart: (e: React.TouchEvent) => {
        moved = false;
        startX = e.touches[0].clientX;
        startY = e.touches[0].clientY;
        timer = setTimeout(() => {
          if (!moved) onLongPress(e);
        }, 550);
      },
      onTouchMove: (e: React.TouchEvent) => {
        const dx = Math.abs(e.touches[0].clientX - startX);
        const dy = Math.abs(e.touches[0].clientY - startY);
        if (dx > 10 || dy > 10) moved = true;
      },
      onTouchEnd: () => {
        if (timer) clearTimeout(timer);
      },
    };
  }

  function renderTooth(t: ToothMeta, index: number, arch: "upper" | "lower") {
    const state = stateFor(t.fdi);
    const width = crownWidth(t.position);
    const top = (arch === "upper" ? UPPER_Y : LOWER_Y)[index];
    return (
      <div
        key={t.fdi}
        className={`ortho-chart-tooth ortho-chart-tooth--${arch} ${selectedTooth === t.fdi ? "is-selected" : ""}`}
        style={{ left: `${ARCH_X[index]}%`, top, width, opacity: state.extracted ? 0.25 : 1 } as React.CSSProperties}
        onClick={(e) => { e.stopPropagation(); openToothDetails(t.fdi); }}
        onContextMenu={(e) => { e.stopPropagation(); e.preventDefault(); if (editable) setExtractMenu({ fdi: t.fdi, x: e.clientX, y: e.clientY }); }}
        {...useLongPress(() => { if (editable) setExtractMenu({ fdi: t.fdi, x: 200, y: 200 }); })}
        title={`FDI ${t.fdi}`}
      >
        <span className="ortho-chart-fdi">{t.fdi}</span>
        <CrownIllustration arch={arch} fdi={t.fdi} index={index} />
        <button
          type="button"
          onDoubleClick={(e) => { e.stopPropagation(); handleBracketDoubleClick(t); }}
          className={`ortho-bracket ortho-chart-bracket ${bracketColor(state.bracket)} ${!editable ? "cursor-default" : ""}`}
          title={state.bracket === "bonded" ? "Bracket bonded — double-click to record a break" : state.bracket === "broken" ? `Broken ${state.debondDate ? "(" + state.debondDate + ")" : ""} — double-click to rebond` : "No bracket"}
        ><span /><i /></button>
        {state.rebondCount > 0 && <span className="ortho-chart-rebond">{state.rebondCount}</span>}
        {state.bracket === "broken" && state.debondDate && <span className="ortho-chart-debond-date">{state.debondDate}</span>}
      </div>
    );
  }

  function renderGap(gap: { id: string; a: number; b: number }, index: number, arch: "upper" | "lower") {
    const x = (ARCH_X[index] + ARCH_X[index + 1]) / 2;
    const y = ((arch === "upper" ? UPPER_Y : LOWER_Y)[index] + (arch === "upper" ? UPPER_Y : LOWER_Y)[index + 1]) / 2 + 43;
    const count = stripCounts[gap.id] ?? 0;
    const screw = Boolean(miniscrews[gap.id]);
    return (
      <button
        type="button"
        key={gap.id}
        className={`ortho-chart-gap ortho-chart-gap--${arch} ${mode !== "none" ? "is-recording" : ""}`}
        style={{ left: `${x}%`, top: y } as React.CSSProperties}
        onClick={(e) => { e.stopPropagation(); if (count > 0 && mode === "none") handleStripUndo(gap.id); else handleGapClick(gap.id); }}
        title={mode === "none" ? undefined : "Click to record"}
      >
        {(mode === "stripping" || count > 0) && <span className="ortho-chart-strip-mark" />}
        {(mode === "miniscrew" || screw) && <span className={`ortho-chart-miniscrew ${screw ? "is-active" : ""}`} />}
        {count > 0 && <span className="ortho-chart-strip-count">{count}</span>}
      </button>
    );
  }

  function renderArch(row: ToothMeta[], gaps: { id: string; a: number; b: number }[], arch: "upper" | "lower") {
    const bulkBondingDate = bondingDateFor(arch);
    // The wire passes through the bracket centers, not through the roots. Keeping
    // this geometry independent from the tooth illustrations makes the two arches
    // read as a clean clinical chart at every screen width.
    const wire = arch === "upper" ? "M45 195 Q520 100 995 195" : "M45 330 Q520 407 995 330";
    return <>
      <svg className={`ortho-chart-wire ortho-chart-wire--${arch}`} viewBox="0 0 1040 580" preserveAspectRatio="none" aria-hidden="true"><path d={wire} /></svg>
      {bulkBondingDate && <div className={`ortho-chart-bulk ortho-chart-bulk--${arch}`}><span>{arch === "upper" ? "Upper bonding" : "Lower bonding"}</span><strong>{bulkBondingDate.slice(0, 10)}</strong></div>}
      {row.map((tooth, index) => renderTooth(tooth, index, arch))}
      {gaps.map((gap, index) => renderGap(gap, index, arch))}
    </>;
  }

  return (
    <div className={`space-y-4 ${isPending ? "opacity-70 pointer-events-none" : ""}`} onClick={backgroundClick}>
      <div className="ortho-interactive-shell">
        <div className="ortho-chart-command-row">
          {editable && <div className="ortho-chart-command-center">
            <button type="button" className={`ortho-chart-mode-button ${mode === "stripping" ? "is-active" : ""}`} aria-pressed={mode === "stripping"} onClick={(e) => { e.stopPropagation(); setMode(mode === "stripping" ? "none" : "stripping"); }}>Stripping</button>
            <button type="button" className={`ortho-chart-mode-button ${mode === "miniscrew" ? "is-active" : ""}`} aria-pressed={mode === "miniscrew"} onClick={(e) => { e.stopPropagation(); setMode(mode === "miniscrew" ? "none" : "miniscrew"); }}>Miniscrews</button>
          </div>}
        </div>
        <div className="overflow-x-auto ortho-chart-scroll">
          <div className="ortho-arch-canvas">
            {renderArch(UPPER_ROW, UPPER_GAPS, "upper")}
            {renderArch(LOWER_ROW, LOWER_GAPS, "lower")}
            <span className="ortho-chart-midline ortho-chart-midline--upper" aria-hidden="true" />
            <span className="ortho-chart-midline ortho-chart-midline--lower" aria-hidden="true" />
            <div className="ortho-chart-tabs" role="tablist" aria-label="Orthodontic chart view">
              {(["chart", "treatment", "occlusion"] as ChartTab[]).map((tab) => <button key={tab} type="button" role="tab" aria-selected={activeTab === tab} className={activeTab === tab ? "is-active" : ""} onClick={(e) => { e.stopPropagation(); setActiveTab(tab); }}>{tab === "chart" ? "Chart view" : tab === "treatment" ? "Treatment" : "Occlusion"}</button>)}
            </div>
          </div>
        </div>
      </div>

      {selectedTooth != null && (
        <div className="card-3d rounded-lg p-3 text-sm space-y-2" onClick={(e) => e.stopPropagation()}>
          <div className="flex items-center justify-between">
            <span className="font-semibold">Tooth FDI {selectedTooth} details</span>
            <button type="button" className="text-xs text-muted hover:underline" onClick={() => setSelectedTooth(null)}>
              Close
            </button>
          </div>
          <textarea
            value={commentDraft}
            onChange={(e) => setCommentDraft(e.target.value)}
            onBlur={saveComment}
            placeholder="Note on this tooth..."
            rows={2}
            disabled={!editable}
            className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-xs disabled:opacity-60"
          />
        </div>
      )}

      {debondPrompt && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/30" onClick={() => setDebondPrompt(null)}>
          <div className="card-3d rounded-lg p-4 space-y-3 w-72" onClick={(e) => e.stopPropagation()}>
            <div className="text-sm font-semibold text-center">Tooth {debondPrompt.fdi}</div>
            <div className="flex flex-col gap-2">
              <button type="button" onClick={confirmDebonded} className="btn-3d-primary px-3 py-1.5 rounded-md text-xs">
                Debonded
              </button>
              {(() => {
                const days = daysSince(stateFor(debondPrompt.fdi).bondedDate);
                if (days === null || days > 7) return null;
                return (
                  <button
                    type="button"
                    onClick={confirmNoBrackets}
                    className="px-3 py-1.5 rounded-md border border-border text-xs hover:bg-primary-soft"
                    title="This tooth was actually never bonded — corrects a bulk-bonding mistake"
                  >
                    No brackets (bonding mistake)
                  </button>
                );
              })()}
              <button type="button" onClick={() => setDebondPrompt(null)} className="text-xs text-muted hover:underline">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {rebondPrompt && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/30" onClick={() => setRebondPrompt(null)}>
          <div className="card-3d rounded-lg p-4 space-y-3 w-64" onClick={(e) => e.stopPropagation()}>
            <div className="text-sm font-semibold text-center">Rebond tooth {rebondPrompt.fdi}</div>
            <div className="flex gap-2 justify-center">
              <button type="button" onClick={() => confirmRebond("new")} className="btn-3d-primary px-3 py-1.5 rounded-md text-xs">
                New bracket
              </button>
              <button type="button" onClick={() => confirmRebond("old")} className="px-3 py-1.5 rounded-md border border-border text-xs hover:bg-primary-soft">
                Old bracket
              </button>
            </div>
          </div>
        </div>
      )}

      {extractMenu && (
        <div className="fixed inset-0 z-40" onClick={() => setExtractMenu(null)}>
          <div className="absolute card-3d rounded-md shadow-lg py-1 text-sm" style={{ left: extractMenu.x, top: extractMenu.y }} onClick={(e) => e.stopPropagation()}>
            <button type="button" onClick={toggleExtracted} className="w-full text-left px-3 py-1.5 hover:bg-primary-soft whitespace-nowrap">
              {stateFor(extractMenu.fdi).extracted ? "Undo extraction" : "Extracted"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export { TOOTH_BY_FDI };
