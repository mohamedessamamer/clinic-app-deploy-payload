"use client";

// Photos & X-rays — same real data as the patient file's PatientImageGallery
// (patient_image_groups/patient_images, same addImageGroupAction/deleteImageAction),
// but a separate English/LTR presentation matching the v2 chart's design instead of
// the shared Arabic/RTL card strip — the chart is meant to stay English regardless
// of the rest of the (Arabic/RTL) system, per the 2026-08-27 review round.
//
// Same round: images are now clustered visually by their upload group (with a
// date + description caption per cluster, like the original system's gallery)
// instead of one flat unlabeled pool — and each image supports rotation, which
// is persisted to the database (rotateImageAction) so it survives a refresh.

import { useCallback, useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { deleteImageAction, deleteImageGroupAction, rotateImageAction } from "@/app/patients/[id]/actions";

type GroupImage = { id: number; file_path: string; rotation: number };
type ImageGroup = { id: number; label: string | null; taken_at: string; images: GroupImage[] };
type FlatImage = { id: number; file_path: string; label: string | null; taken_at: string; rotation: number };

function extensionOf(filePath: string): string {
  const match = /\.[a-zA-Z0-9]+$/.exec(filePath);
  return match ? match[0] : "";
}

export default function OrthoImageGallery({ groups, patientId, editable, compact = false }: { groups: ImageGroup[]; patientId: number; editable: boolean; compact?: boolean }) {
  const router = useRouter();
  const [, startTransition] = useTransition();

  const nonEmptyGroups = groups.filter((g) => g.images.length > 0);

  // ليستة مسطحة بنفس ترتيب العرض — مستخدمة بس لتنقل الأسهم جوه الـ lightbox.
  const flatImages: FlatImage[] = nonEmptyGroups.flatMap((g) =>
    g.images.map((img) => ({ id: img.id, file_path: img.file_path, label: g.label, taken_at: g.taken_at, rotation: img.rotation || 0 }))
  );

  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const close = useCallback(() => setOpenIndex(null), []);
  const prev = useCallback(() => {
    setOpenIndex((i) => (i === null || flatImages.length === 0 ? i : (i - 1 + flatImages.length) % flatImages.length));
  }, [flatImages.length]);
  const next = useCallback(() => {
    setOpenIndex((i) => (i === null || flatImages.length === 0 ? i : (i + 1) % flatImages.length));
  }, [flatImages.length]);

  useEffect(() => {
    if (openIndex === null) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") close();
      else if (e.key === "ArrowLeft") prev();
      else if (e.key === "ArrowRight") next();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [openIndex, close, prev, next]);

  function handleDelete(imageId: number, e: React.MouseEvent) {
    e.stopPropagation();
    const ok = window.confirm("Delete this photo? This can't be undone.");
    if (!ok) return;
    const formData = new FormData();
    formData.set("image_id", String(imageId));
    formData.set("patient_id", String(patientId));
    startTransition(async () => {
      await deleteImageAction(formData);
      router.refresh();
    });
  }

  function handleRotate(imageId: number, e: React.MouseEvent) {
    e.stopPropagation();
    const formData = new FormData();
    formData.set("image_id", String(imageId));
    formData.set("patient_id", String(patientId));
    startTransition(async () => {
      await rotateImageAction(formData);
      router.refresh();
    });
  }

  // Bulk download لكل صور مجموعة (يوم/دفعة) واحدة — دفعة 27. الملفات كلها
  // نفس الأصل (same-origin)، فبنعمل <a download> مؤقت لكل صورة ونضغطه برمجيًا
  // واحد ورا التاني (delay بسيط بينهم عشان المتصفح ميعتبرهاش popup spam).
  function handleDownloadGroup(group: ImageGroup, e: React.MouseEvent) {
    e.stopPropagation();
    group.images.forEach((img, i) => {
      setTimeout(() => {
        const a = document.createElement("a");
        a.href = img.file_path;
        a.download = `${group.taken_at}-${i + 1}${extensionOf(img.file_path)}`;
        document.body.appendChild(a);
        a.click();
        a.remove();
      }, i * 250);
    });
  }

  function handleDeleteGroup(group: ImageGroup, e: React.MouseEvent) {
    e.stopPropagation();
    const ok = window.confirm(`Delete all ${group.images.length} photo(s) from ${group.taken_at}? This can't be undone.`);
    if (!ok) return;
    const formData = new FormData();
    formData.set("group_id", String(group.id));
    formData.set("patient_id", String(patientId));
    startTransition(async () => {
      await deleteImageGroupAction(formData);
      router.refresh();
    });
  }

  const openImage = openIndex !== null ? flatImages[openIndex] : null;
  // 90/270 بتقلب الأبعاد بصريًا — لازم الصورة تتحط جوه إطار مربع في الـ lightbox
  // عشان ماتتقصش برة حدود الشاشة لما تلف.
  const openRotated90 = openImage ? openImage.rotation % 180 !== 0 : false;

  return (
    <div dir="ltr" className={compact ? "ortho-live-photo-gallery-shell" : undefined}>
      <div className={compact ? "ortho-live-photo-gallery" : "flex gap-3 flex-wrap items-start"}>
        {nonEmptyGroups.map((g) => {
          const startIndex = flatImages.findIndex((f) => f.id === g.images[0].id);
          return (
            <div key={g.id} className={compact ? "ortho-live-photo-group" : "rounded-md border border-border bg-background p-1.5 space-y-1"}>
              <div className={compact ? "flex gap-1" : "flex gap-1 flex-wrap"}>
                {g.images.map((img, i) => (
                  <div key={img.id} className={`relative rounded-md overflow-hidden border border-border bg-background group ${compact ? "ortho-live-photo-tile" : "w-20 h-20"}`}>
                    <button type="button" onClick={() => setOpenIndex(startIndex + i)} className="block w-full h-full cursor-zoom-in">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={img.file_path}
                        alt={g.label || "Photo"}
                        className="w-full h-full object-cover"
                        style={img.rotation ? { transform: `rotate(${img.rotation}deg)` } : undefined}
                      />
                    </button>
                    {editable && (
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-center justify-center gap-1 opacity-0 group-hover:opacity-100 pointer-events-none">
                        <button
                          type="button"
                          onClick={(e) => handleRotate(img.id, e)}
                          className="text-white text-xs bg-black/50 rounded px-1.5 py-0.5 pointer-events-auto"
                          title="Rotate"
                          aria-label="Rotate photo"
                        >
                          ⟳
                        </button>
                        <button
                          type="button"
                          onClick={(e) => handleDelete(img.id, e)}
                          className="text-white text-xs bg-black/50 rounded px-1.5 py-0.5 pointer-events-auto"
                          title="Delete"
                          aria-label="Delete photo"
                        >
                          ×
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
              <div className="text-[11px] text-muted flex items-center gap-1.5 flex-wrap">
                <span>
                  {g.taken_at}
                  {g.label ? ` · ${g.label}` : ""}
                </span>
                {editable && g.images.length > 1 && (
                  <>
                    <button
                      type="button"
                      onClick={(e) => handleDownloadGroup(g, e)}
                      className="text-primary hover:underline"
                      title="Download all photos in this group"
                    >
                      ⬇ all
                    </button>
                    <button
                      type="button"
                      onClick={(e) => handleDeleteGroup(g, e)}
                      className="text-red-600 hover:underline"
                      title="Delete all photos in this group"
                    >
                      × all
                    </button>
                  </>
                )}
              </div>
            </div>
          );
        })}
        {flatImages.length === 0 && <p className="text-xs text-muted">No photos or X-rays uploaded for this patient yet.</p>}
      </div>

      {openIndex !== null && openImage && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4" onClick={close}>
          {flatImages.length > 1 && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                prev();
              }}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-white/80 hover:text-white text-4xl px-3 py-2 select-none"
              aria-label="Previous"
            >
              ‹
            </button>
          )}

          <div
            className={`flex items-center justify-center ${openRotated90 ? "max-w-[85vh] max-h-[90vw]" : "max-w-[90vw] max-h-[85vh]"}`}
            onClick={(e) => e.stopPropagation()}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={openImage.file_path}
              alt={openImage.label || "Photo"}
              className={openRotated90 ? "max-h-[85vh] max-w-[85vh] object-contain rounded shadow-2xl" : "max-w-[90vw] max-h-[85vh] object-contain rounded shadow-2xl"}
              style={openImage.rotation ? { transform: `rotate(${openImage.rotation}deg)` } : undefined}
            />
          </div>

          {flatImages.length > 1 && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                next();
              }}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-white/80 hover:text-white text-4xl px-3 py-2 select-none"
              aria-label="Next"
            >
              ›
            </button>
          )}

          <div className="absolute top-4 right-4 flex items-center gap-2">
            {editable && (
              <button
                type="button"
                onClick={(e) => handleRotate(openImage.id, e)}
                className="whitespace-nowrap text-white/90 hover:text-white text-sm bg-black/40 hover:bg-black/60 rounded-md px-3 py-1.5 transition-colors"
              >
                ⟳ Rotate
              </button>
            )}

            <a
              href={openImage.file_path}
              download={`${openImage.taken_at}-${openIndex! + 1}${extensionOf(openImage.file_path)}`}
              onClick={(e) => e.stopPropagation()}
              className="whitespace-nowrap text-white/90 hover:text-white text-sm bg-black/40 hover:bg-black/60 rounded-md px-3 py-1.5 transition-colors"
            >
              ⬇ Download
            </a>
          </div>

          <div className="absolute bottom-4 inset-x-0 text-center text-white/70 text-xs">
            {openIndex + 1} / {flatImages.length}
            {openImage.taken_at ? ` · ${openImage.taken_at}` : ""}
          </div>
        </div>
      )}
    </div>
  );
}
