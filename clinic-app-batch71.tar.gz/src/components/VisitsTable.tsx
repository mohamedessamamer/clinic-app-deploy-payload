"use client";

import { useState, useTransition } from "react";
import { updateVisitAction, deleteVisitAction, updateVisitAssistantDoctorAction } from "@/app/patients/[id]/actions";
import ServiceCombobox from "@/components/ServiceCombobox";

type Visit = {
  id: number;
  visit_date: string;
  service_id: number | null;
  service_name: string | null;
  service_name_en?: string | null;
  notes: string | null;
  doctor_name: string | null;
  created_at: string;
  ortho_visit_id?: number | null;
  primary_doctor_id?: number | null;
  performing_doctor_id?: number | null;
};

type Service = { id: number; name: string; name_en?: string | null; code?: string | null; default_price?: number | null };
type Doctor = { id: number; full_name: string };

const VISIT_EDIT_WINDOW_DAYS = 3;

// بيتحقق هل الزيارة لسه جوه فترة الـ 3 أيام (تعديل حر) — نفس الحد المطبق في
// السيرفر (actions.ts)، هنا بس لعرض/إخفاء زرار "تعديل" في الواجهة؛ التحقق
// الحقيقي والملزم بيحصل في السيرفر بغض النظر عن ساعة جهاز المستخدم.
function isWithinEditWindow(createdAt: string): boolean {
  const created = new Date(createdAt.replace(" ", "T") + "Z");
  const ageDays = (Date.now() - created.getTime()) / (1000 * 60 * 60 * 24);
  return ageDays <= VISIT_EDIT_WINDOW_DAYS;
}

export default function VisitsTable({
  patientId,
  visits,
  services,
  doctors,
  canEditMedicalRecord,
  canEditOldVisits,
  canDeleteVisits,
  canEditAssistantDoctor,
  currentDoctorId,
  language = "en",
}: {
  patientId: number;
  visits: Visit[];
  services: Service[];
  // قائمة الأطباء — مستخدمة بس في تعديل حقل "الطبيب المساعد" (اختيار من هو نفّذ
  // الخدمة فعليًا)، مش في فورم التعديل العام.
  doctors: Doctor[];
  // الملف الطبي مقصور على الدورين + الأدمن + مدير العيادة — لو false، زرار
  // "تعديل" مايظهرش خالص بغض النظر عن نافذة الـ3 أيام (الاستقبال/المحاسب عرض بس).
  canEditMedicalRecord: boolean;
  canEditOldVisits: boolean;
  // حذف نهائي للزيارة وفاتورتها (مش تعديل) — منفصل عن نافذة الـ3 أيام تمامًا،
  // محصور بصلاحية "delete_visits" بس (الأدمن افتراضيًا). لتصحيح إدخال مكرر/غلط
  // بالكامل، مش تصحيح بسيط في البيانات.
  canDeleteVisits: boolean;
  // دفعة 22: تعديل حقل "الطبيب المساعد" بس — حقل مستقل عن canEditMedicalRecord
  // تمامًا (بيسمح مثلاً للاستقبال يعدّله من غير ما يقدروا يلمسوا باقي سجل
  // الزيارات). بالإضافة لده، الطبيب الأساسي صاحب الزيارة نفسه يقدر يعدّله لزياراته
  // هو دايمًا (شوف isOwnVisitDoctor تحت) حتى لو canEditAssistantDoctor=false.
  canEditAssistantDoctor: boolean;
  currentDoctorId: number | null;
  language?: "en" | "ar";
}) {
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editServiceId, setEditServiceId] = useState<string>("");
  const [editingAssistantId, setEditingAssistantId] = useState<number | null>(null);
  const [isPending, startTransition] = useTransition();
  const en = language === "en";

  if (visits.length === 0) {
    return (
      <div className="overflow-x-auto">
        <table className="w-full text-sm mt-2 table-fixed">
          <thead className="bg-primary-soft text-primary-dark">
            <tr>
              <th className="text-right px-3 py-2 font-medium">{en ? "Date" : "التاريخ"}</th>
              <th className="text-right px-3 py-2 font-medium">{en ? "Service" : "نوع الخدمة"}</th>
              <th className="text-right px-3 py-2 font-medium">{en ? "Treatment notes" : "المعالجة"}</th>
              <th className="text-right px-3 py-2 font-medium">{en ? "Treating doctor" : "الدكتور"}</th>
              <th className="w-[10%]" />
            </tr>
          </thead>
          <tbody>
            <tr>
              <td colSpan={5} className="px-3 py-6 text-center text-muted">
                {en ? "No visits recorded yet." : "لا يوجد زيارات مسجلة بعد."}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm mt-2 table-fixed">
        <colgroup>
          <col className="w-[13%]" />
          <col className="w-[17%]" />
          <col />
          <col className="w-[15%]" />
          <col className="w-[13%]" />
        </colgroup>
        <thead className="bg-primary-soft text-primary-dark">
          <tr>
            <th className="text-right px-3 py-2 font-medium">{en ? "Date" : "التاريخ"}</th>
            <th className="text-right px-3 py-2 font-medium">{en ? "Service" : "نوع الخدمة"}</th>
            <th className="text-right px-3 py-2 font-medium">{en ? "Treatment notes" : "المعالجة"}</th>
            <th className="text-right px-3 py-2 font-medium">{en ? "Treating doctor" : "الدكتور"}</th>
            <th className="text-right px-3 py-2 font-medium" />
          </tr>
        </thead>
        <tbody>
          {visits.map((v) => {
            const editable = canEditMedicalRecord && (canEditOldVisits || isWithinEditWindow(v.created_at));
            const isEditing = editingId === v.id;

            if (isEditing) {
              return (
                <tr key={v.id} className="border-t border-border align-top bg-primary-soft/40">
                  <td colSpan={5} className="px-3 py-3">
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        const formData = new FormData(e.currentTarget);
                        startTransition(async () => {
                          await updateVisitAction(formData);
                          setEditingId(null);
                        });
                      }}
                      className="grid grid-cols-1 sm:grid-cols-4 gap-2 items-end"
                    >
                      <input type="hidden" name="visit_id" value={v.id} />
                      <input type="hidden" name="patient_id" value={patientId} />
                      <div>
                        <label className="block text-xs text-muted mb-1">{en ? "Date" : "التاريخ"}</label>
                        <input
                          type="date"
                          name="visit_date"
                          defaultValue={v.visit_date}
                          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-muted mb-1">{en ? "Service" : "نوع الخدمة"}</label>
                        <ServiceCombobox
                          name="service_id"
                          services={services}
                          value={editServiceId}
                          onChange={setEditServiceId}
                          useEnglish={en}
                          placeholder={en ? "Search by service name or code..." : undefined}
                        />
                      </div>
                      <div className="sm:col-span-1">
                        <label className="block text-xs text-muted mb-1">{en ? "Treatment notes" : "المعالجة"}</label>
                        <textarea
                          name="notes"
                          defaultValue={v.notes ?? ""}
                          rows={2}
                          className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary resize-y"
                        />
                      </div>
                      <div className="flex gap-2">
                        <button
                          type="submit"
                          disabled={isPending}
                          className="rounded-md btn-3d-primary px-3 py-1.5 text-sm font-medium disabled:opacity-60"
                        >
                          {en ? "Save" : "حفظ"}
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingId(null)}
                          disabled={isPending}
                          className="rounded-md border border-border px-3 py-1.5 text-sm hover:bg-primary-soft disabled:opacity-60"
                        >
                          {en ? "Cancel" : "إلغاء"}
                        </button>
                      </div>
                    </form>
                  </td>
                </tr>
              );
            }

            // الطبيب الأساسي صاحب الزيارة يقدر يعدّل حقل "الطبيب المساعد" لزياراته
            // هو دايمًا، بالإضافة لأي حد عنده صلاحية edit_visit_assistant_doctor.
            const isOwnVisitDoctor = currentDoctorId != null && v.primary_doctor_id === currentDoctorId;
            const canEditThisAssistant = canEditAssistantDoctor || isOwnVisitDoctor;
            const isEditingAssistant = editingAssistantId === v.id;

            // تنبيه بصري (دفعة 22): زيارة ليها خدمة محددة بس لسه من غير تفاصيل
            // معالجة — عشان الطبيب/مدير العيادة ياخدوا بالهم إنهم محتاجين
            // يكملوا الملف الطبي (مثلاً لو الاستقبال سجل الخدمة الأول). ده تنبيه
            // على مستوى الصف بس دلوقتي، مش نظام إشعارات كامل (لسه مش موجود).
            const needsNotes = !!v.service_id && !v.notes;

            return (
              <tr key={v.id} className={`border-t border-border align-top ${needsNotes ? "bg-amber-50 dark:bg-amber-900/10" : ""}`}>
                <td className="px-3 py-2 text-muted whitespace-nowrap">{v.visit_date}</td>
                <td className="px-3 py-2 break-words">{v.service_name_en || v.service_name || (v.ortho_visit_id ? "Orthodontic chart" : "-")}</td>
                <td className="px-3 py-2 break-words whitespace-pre-wrap">
                  {v.notes ?? (
                    <span className="text-amber-700 dark:text-amber-400 text-xs font-medium">{en ? "⚠ Treatment details needed" : "⚠ محتاج تفاصيل معالجة"}</span>
                  )}
                </td>
                <td className="px-3 py-2 break-words">
                  {isEditingAssistant ? (
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        const formData = new FormData(e.currentTarget);
                        startTransition(async () => {
                          await updateVisitAssistantDoctorAction(formData);
                          setEditingAssistantId(null);
                        });
                      }}
                      className="flex items-center gap-1 flex-wrap"
                    >
                      <input type="hidden" name="visit_id" value={v.id} />
                      <input type="hidden" name="patient_id" value={patientId} />
                      <select
                        name="performing_doctor_id"
                        defaultValue={v.performing_doctor_id != null ? String(v.performing_doctor_id) : ""}
                        className="rounded-md border border-border bg-background px-1.5 py-1 text-xs focus:outline-none focus:ring-2 focus:ring-primary"
                      >
                        <option value="">-</option>
                        {doctors.map((d) => (
                          <option key={d.id} value={d.id}>
                            {d.full_name}
                          </option>
                        ))}
                      </select>
                      <button type="submit" disabled={isPending} className="text-xs text-primary hover:underline disabled:opacity-60">
                        {en ? "Save" : "حفظ"}
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingAssistantId(null)}
                        disabled={isPending}
                        className="text-xs text-muted hover:underline disabled:opacity-60"
                      >
                        {en ? "Cancel" : "إلغاء"}
                      </button>
                    </form>
                  ) : (
                    <div className="flex items-center gap-2">
                      <span>{v.doctor_name ?? "-"}</span>
                      {canEditThisAssistant && (
                        <button
                          type="button"
                          onClick={() => setEditingAssistantId(v.id)}
                          className="text-xs text-primary hover:underline"
                        >
                          {en ? "Edit" : "تعديل"}
                        </button>
                      )}
                    </div>
                  )}
                </td>
                <td className="px-3 py-2 whitespace-nowrap space-x-2 space-x-reverse">
                  {editable && (
                    <button
                      type="button"
                      onClick={() => {
                        setEditServiceId(v.service_id != null ? String(v.service_id) : "");
                        setEditingId(v.id);
                      }}
                      className="text-xs text-primary hover:underline"
                    >
                      {en ? "Edit" : "تعديل"}
                    </button>
                  )}
                  {canDeleteVisits && (
                    <button
                      type="button"
                      disabled={isPending}
                      onClick={() => {
                        const ok = window.confirm(
                          en
                            ? `Delete this visit (${v.service_name_en || v.service_name || "No service"} — ${v.visit_date}) permanently, including its invoice? This cannot be undone.`
                            : `متأكد إنك عايز تمسح الزيارة دي (${v.service_name_en || v.service_name || "بدون خدمة"} — ${v.visit_date}) نهائيًا مع فاتورتها؟ الإجراء ده مش ممكن يترجع.`
                        );
                        if (!ok) return;
                        const formData = new FormData();
                        formData.set("visit_id", String(v.id));
                        formData.set("patient_id", String(patientId));
                        startTransition(async () => {
                          const result = await deleteVisitAction(formData);
                          if (result && !result.ok) window.alert(result.reason ?? (en ? "Could not delete this visit." : "معرفناش نمسح الزيارة دي."));
                        });
                      }}
                      className="text-xs text-danger hover:underline disabled:opacity-60"
                    >
                      {en ? "Delete" : "حذف"}
                    </button>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
