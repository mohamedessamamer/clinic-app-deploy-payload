"use client";

import Link from "next/link";

export default function PatientRecordTabs({ orthodonticHref }: { orthodonticHref:string }) {
  const go = (id:string) => (event: React.MouseEvent<HTMLAnchorElement>) => { event.preventDefault(); document.getElementById(id)?.scrollIntoView({ behavior:"smooth", block:"start" }); };
  return <nav className="medical-tabs" aria-label="Patient record sections">
    <a href="#patient-summary" onClick={go("patient-summary")}>Summary</a>
    <a href="#medical-visits" onClick={go("medical-visits")}>Visits</a>
    <a href="#patient-photos" onClick={go("patient-photos")}>Photos &amp; X-rays</a>
    <Link href={orthodonticHref}>Orthodontic chart</Link>
  </nav>;
}
