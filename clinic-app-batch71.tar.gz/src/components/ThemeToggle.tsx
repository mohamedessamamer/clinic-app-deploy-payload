"use client";

import { useEffect, useState } from "react";

export default function ThemeToggle() {
  const [dark, setDark] = useState(false);

  useEffect(() => {
    // الوضع الفاتح هو الافتراضي المقصود للتصميم. لا نأخذ وضع نظام التشغيل
    // تلقائياً حتى لا تتحول الواجهة كلها للداكن من غير اختيار المستخدم.
    // المفتاح الجديد يعيد أي اختيار قديم غير مقصود إلى الفاتح مرة واحدة.
    const saved = window.localStorage.getItem("clinic-theme-v2");
    const useDark = saved === "dark";
    document.body.dataset.theme = useDark ? "dark" : "light";
    setDark(useDark);
  }, []);

  function toggle() {
    const next = !dark;
    setDark(next);
    document.body.dataset.theme = next ? "dark" : "light";
    window.localStorage.setItem("clinic-theme-v2", next ? "dark" : "light");
  }

  return (
    <button type="button" onClick={toggle} className="clinic-theme-toggle" aria-label={dark ? "تفعيل الوضع الفاتح" : "تفعيل الوضع الداكن"} title={dark ? "الوضع الفاتح" : "الوضع الداكن"}>
      {dark ? "☀" : "☾"}
    </button>
  );
}
