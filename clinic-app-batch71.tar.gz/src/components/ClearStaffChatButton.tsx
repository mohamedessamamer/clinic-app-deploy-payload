"use client";

import { useTransition } from "react";
import { clearStaffChatAction } from "@/app/settings/actions";

export default function ClearStaffChatButton() {
  const [pending, startTransition] = useTransition();
  return (
    <button
      type="button"
      disabled={pending}
      onClick={() => {
        if (!window.confirm("سيتم حذف كل رسائل الشات الحالية فورًا. هل تريد المتابعة؟")) return;
        startTransition(async () => {
          const result = await clearStaffChatAction();
          if (!result.ok) window.alert(result.reason || "تعذر تصفير الشات.");
          else window.alert("تم تصفير الشات.");
        });
      }}
      className="rounded-md border border-danger text-danger px-3 py-2 text-sm hover:bg-danger-soft disabled:opacity-60"
    >
      {pending ? "جارٍ التصفير..." : "تصفير الشات الآن"}
    </button>
  );
}
