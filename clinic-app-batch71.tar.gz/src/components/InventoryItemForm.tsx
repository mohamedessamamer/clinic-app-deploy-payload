"use client";

import { useMemo, useState } from "react";
import { addInventoryVariantAction } from "@/app/inventory/actions";

type Product = { id: number; name: string; categoryName: string; specialtyName: string };
type AttributeGroup = { id: number; product_id: number; name: string };
type AttributeValue = { id: number; attribute_group_id: number; value: string };
type Unit = { id: number; name: string; short_name: string | null };
type Supplier = { id: number; name: string };

const inputClass = "w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm";

export default function InventoryItemForm({
  products,
  attributeGroups,
  attributeValues,
  units,
  suppliers,
}: {
  products: Product[];
  attributeGroups: AttributeGroup[];
  attributeValues: AttributeValue[];
  units: Unit[];
  suppliers: Supplier[];
}) {
  const [productId, setProductId] = useState("");
  const selectedGroups = useMemo(() => attributeGroups.filter((group) => group.product_id === Number(productId)), [attributeGroups, productId]);

  return (
    <form action={addInventoryVariantAction} className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3 items-end">
      <div className="xl:col-span-2">
        <label className="block text-xs text-muted mb-1">الصنف من الكتالوج</label>
        <select name="product_id" value={productId} onChange={(event) => setProductId(event.target.value)} className={inputClass}>
          <option value="">صنف حر (للاستخدامات القديمة أو المؤقتة)</option>
          {products.map((product) => <option key={product.id} value={product.id}>{product.specialtyName} — {product.categoryName} — {product.name}</option>)}
        </select>
      </div>
      <div className="xl:col-span-2">
        <label className="block text-xs text-muted mb-1">اسم العرض (اختياري مع الكتالوج)</label>
        <input name="name" placeholder="يتكون تلقائيًا من الصنف والمواصفات" className={inputClass} />
      </div>

      {selectedGroups.map((group) => {
        const values = attributeValues.filter((value) => value.attribute_group_id === group.id);
        return (
          <div key={group.id}>
            <label className="block text-xs text-muted mb-1">{group.name}</label>
            <select name={`attribute_group_${group.id}`} className={inputClass} defaultValue="">
              <option value="">بدون تحديد</option>
              {values.map((value) => <option key={value.id} value={value.id}>{value.value}</option>)}
            </select>
          </div>
        );
      })}

      <div>
        <label className="block text-xs text-muted mb-1">المورد</label>
        <select name="supplier_id" className={inputClass} defaultValue=""><option value="">غير محدد</option>{suppliers.map((supplier) => <option key={supplier.id} value={supplier.id}>{supplier.name}</option>)}</select>
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">كود الصنف</label>
        <input name="item_code" className={inputClass} />
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">استخدامه في شارت التقويم</label>
        <select name="ortho_usage" className={inputClass} defaultValue="">
          <option value="">ليس خامة شارت تقويم</option>
          <option value="wire">Wire</option>
          <option value="bracket">Bracket</option>
          <option value="tube">Tube</option>
          <option value="elastic">Elastic</option>
          <option value="otie">O-tie</option>
          <option value="power_chain">Power chain</option>
          <option value="button">Button</option>
          <option value="compressed_coil">Compressed coil</option>
          <option value="anchorage_device">Anchorage device (يظهر في خطة التقويم)</option>
        </select>
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">الرصيد الحالي</label>
        <input name="quantity" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} />
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">الوحدة</label>
        <select name="unit" className={inputClass} defaultValue=""><option value="">اختر الوحدة</option>{units.map((unit) => <option key={unit.id} value={unit.short_name || unit.name}>{unit.name}{unit.short_name ? ` (${unit.short_name})` : ""}</option>)}</select>
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">حد التنبيه</label>
        <input name="low_stock_threshold" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} />
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">الحد الحرج</label>
        <input name="critical_stock_threshold" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} />
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">الكمية المقترحة للطلب</label>
        <input name="reorder_quantity" type="number" min="0" step="0.01" defaultValue="0" className={inputClass} />
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">الصلاحية (إن وجدت)</label>
        <input name="expiry_date" type="date" className={inputClass} />
      </div>
      <div>
        <button type="submit" className="w-full rounded-md btn-3d-primary px-3 py-2 text-sm font-medium">إضافة للمخزن</button>
      </div>
    </form>
  );
}
