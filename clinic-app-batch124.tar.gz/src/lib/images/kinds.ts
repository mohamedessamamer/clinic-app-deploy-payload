// Batch 124: أنواع صور المريض اللي السيستم بيتعرف عليها تلقائيًا وقت الرفع.
// ملف عادي (من غير sharp ولا server-only) عشان الواجهة تستورد الأسماء والتسميات.

export const IMAGE_KINDS = [
  "face_profile",
  "face_frontal",
  "face_smile",
  "intraoral_front",
  "intraoral_right",
  "intraoral_left",
  "intraoral_upper",
  "intraoral_lower",
  "xray_pano",
  "xray_ceph",
  "xray_other",
  "other",
] as const;

export type ImageKind = (typeof IMAGE_KINDS)[number];

export const IMAGE_KIND_LABELS: Record<ImageKind, string> = {
  face_profile: "وش جانبي",
  face_frontal: "وش أمامي",
  face_smile: "وش مبتسم",
  intraoral_front: "أسنان أمامي",
  intraoral_right: "أسنان يمين",
  intraoral_left: "أسنان شمال",
  intraoral_upper: "الفك العلوي (سقف الفم)",
  intraoral_lower: "الفك السفلي",
  xray_pano: "بانوراما",
  xray_ceph: "سيفالومتري",
  xray_other: "أشعة أخرى / مقاطع",
  other: "غير محدد",
};

export const FACE_KINDS: ImageKind[] = ["face_frontal", "face_smile", "face_profile"];
export const INTRAORAL_KINDS: ImageKind[] = ["intraoral_front", "intraoral_right", "intraoral_left", "intraoral_upper", "intraoral_lower"];
export const XRAY_KINDS: ImageKind[] = ["xray_pano", "xray_ceph", "xray_other"];

/** المجموعة العامة — التصنيف التلقائي بيبقى واثق فيها أكتر من النوع التفصيلي. */
export function imageKindFamily(kind: ImageKind): "face" | "intraoral" | "xray" | "other" {
  if (FACE_KINDS.includes(kind)) return "face";
  if (INTRAORAL_KINDS.includes(kind)) return "intraoral";
  if (XRAY_KINDS.includes(kind)) return "xray";
  return "other";
}

export function isImageKind(value: string | null | undefined): value is ImageKind {
  return !!value && (IMAGE_KINDS as readonly string[]).includes(value);
}
