// Batch 123: قاعدة «3 دقائق داخل العيادة».
// المريض اللي قعد جوه العيادة 3 دقائق أو أكثر اتعمل له خدمة فعلًا، فمينفعش
// يتسجل «لم يحضر» أو يتلغي (كان بيختفي من السيستم ومن السجلات). الخيار الوحيد
// بعدها هو «تم». نفس الدالة بتتستخدم في السيرفر (التحقق الحقيقي) وفي الواجهة
// (تعطيل الزرار فقط) — ملف عادي من غير "use server" عشان يتستورد من الاتنين.

export const CLINIC_CONFIRM_MS = 3 * 60_000;

export type ClinicVisitTiming = {
  entered_room_id?: number | null;
  entered_at?: string | null;
  clinic_confirmed_at?: string | null;
};

/** true لو المريض قضى 3 دقائق داخل العيادة (حاليًا أو في دخلة سابقة). */
export function isClinicVisitConfirmed(appt: ClinicVisitTiming, now = Date.now()): boolean {
  if (appt.clinic_confirmed_at) return true;
  if (!appt.entered_room_id || !appt.entered_at) return false;
  const entered = Date.parse(appt.entered_at);
  return Number.isFinite(entered) && now - entered >= CLINIC_CONFIRM_MS;
}

/** قيمة clinic_confirmed_at اللي تتحفظ لحظة خروج المريض من العيادة. */
export function clinicConfirmedAtOnExit(appt: ClinicVisitTiming, now = Date.now()): string | null {
  if (appt.clinic_confirmed_at) return appt.clinic_confirmed_at;
  return isClinicVisitConfirmed(appt, now) ? appt.entered_at ?? null : null;
}

export const CLINIC_CONFIRMED_MESSAGE = "المريض قضى أكثر من 3 دقائق داخل العيادة — لازم يتعمله «تم»، ومينفعش «لم يحضر» أو إلغاء.";
