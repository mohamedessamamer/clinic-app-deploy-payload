import "server-only";

import { db } from "@/lib/db/client";

/** تثبيت بداية الانتظار بعد ثلاث دقائق متصلة في الاستقبال. */
export async function confirmReceptionWaits() {
  const threshold = new Date(Date.now() - 3 * 60_000).toISOString();
  await db.updateTable("appointments")
    .set((eb) => ({ reception_wait_started_at: eb.ref("attended_at") }))
    .where("status", "=", "attended")
    .where("entered_room_id", "is", null)
    .where("attended_at", "is not", null)
    .where("attended_at", "<=", threshold)
    .where("reception_wait_started_at", "is", null)
    .execute();
}
