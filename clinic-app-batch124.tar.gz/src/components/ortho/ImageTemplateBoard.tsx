"use client";

// Batch 124: شاشة مراجعة توزيع الصور على التمبلت.
// السيستم بيقترح مكان كل صورة بعد الرفع (تحليل على السيرفر من غير أي خدمة
// خارجية)، والمستخدم بيسحب أي صورة لمكانها الصح قبل الحفظ. السحب بالماوس
// (drag & drop) أو بالدوس مرتين على الموبايل: دوسة على الصورة تختارها، ودوسة
// على الخانة تحطها فيها.

import { useEffect, useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  saveGroupTemplateAction,
  setPatientAvatarAction,
  suggestGroupTemplateAction,
  type TemplateImage,
} from "@/app/patients/[id]/images/template-actions";
import { IMAGE_KIND_LABELS, isImageKind, type ImageKind } from "@/lib/images/kinds";
import type { ImageTemplate } from "@/lib/images/template";

type Props = { groupId: number; patientId: number; onClose: () => void };

const FACE_KINDS: ImageKind[] = ["face_frontal", "face_smile", "face_profile"];

export default function ImageTemplateBoard({ groupId, patientId, onClose }: Props) {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [template, setTemplate] = useState<ImageTemplate | null>(null);
  const [images, setImages] = useState<TemplateImage[]>([]);
  const [assignments, setAssignments] = useState<Record<string, number>>({});
  const [selected, setSelected] = useState<number | null>(null);
  const [saving, startSaving] = useTransition();

  useEffect(() => {
    let cancelled = false;
    suggestGroupTemplateAction(groupId).then((result) => {
      if (cancelled) return;
      if (!result.ok || !result.template || !result.images) {
        setError(result.error || "تعذر تجهيز التمبلت.");
        setLoading(false);
        return;
      }
      setTemplate(result.template);
      setImages(result.images);
      setAssignments(result.assignments ?? {});
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, [groupId]);

  const imageById = useMemo(() => new Map(images.map((image) => [image.id, image])), [images]);
  const assignedIds = useMemo(() => new Set(Object.values(assignments)), [assignments]);
  const tray = images.filter((image) => !assignedIds.has(image.id));

  function place(slotKey: string, imageId: number) {
    setAssignments((current) => {
      const next = { ...current };
      // لو الصورة كانت في خانة تانية، بنبدّل الاتنين مكانهم.
      const previousSlot = Object.keys(next).find((key) => next[key] === imageId);
      const displaced = next[slotKey];
      next[slotKey] = imageId;
      if (previousSlot && previousSlot !== slotKey) {
        if (displaced != null) next[previousSlot] = displaced;
        else delete next[previousSlot];
      }
      return next;
    });
    setSelected(null);
  }

  function clearSlot(slotKey: string) {
    setAssignments((current) => {
      const next = { ...current };
      delete next[slotKey];
      return next;
    });
  }

  function save() {
    startSaving(async () => {
      const result = await saveGroupTemplateAction(groupId, assignments);
      if (!result.ok) {
        setError(result.error || "تعذر حفظ التوزيع.");
        return;
      }
      router.refresh();
      onClose();
    });
  }

  function makeAvatar(imageId: number) {
    startSaving(async () => {
      const result = await setPatientAvatarAction(patientId, imageId);
      if (!result.ok) setError(result.error || "تعذر تحديث صورة الملف.");
      else router.refresh();
    });
  }

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/45 p-3" role="dialog" aria-modal="true" aria-label="ترتيب الصور في التمبلت">
      <div className="card-3d w-full max-w-5xl max-h-[92vh] overflow-y-auto rounded-xl p-4 text-right">
        <div className="flex items-center justify-between gap-2">
          <h3 className="font-semibold">مراجعة توزيع الصور</h3>
          <button type="button" onClick={onClose} className="rounded-md border border-border px-3 py-1.5 text-sm hover:bg-primary-soft">إغلاق</button>
        </div>
        <p className="mt-1 text-xs text-muted">
          السيستم وزّع الصور تلقائيًا. اسحب أي صورة لمكانها الصح (أو دوس على الصورة وبعدين على الخانة) قبل الحفظ.
        </p>
        {error && <p className="mt-2 text-sm text-danger">{error}</p>}

        {loading ? (
          <p className="mt-6 text-sm text-muted">جارٍ تحليل الصور…</p>
        ) : template ? (
          <>
            <div
              className="image-template-grid mt-4"
              style={{ gridTemplateColumns: `repeat(${template.columns}, minmax(0, 1fr))` }}
            >
              {template.slots.map((slot) => {
                const imageId = assignments[slot.key];
                const image = imageId != null ? imageById.get(imageId) : undefined;
                return (
                  <div
                    key={slot.key}
                    className={`image-template-slot ${selected != null ? "is-target" : ""}`}
                    onDragOver={(event) => event.preventDefault()}
                    onDrop={(event) => {
                      event.preventDefault();
                      const dragged = Number(event.dataTransfer.getData("text/plain"));
                      if (dragged) place(slot.key, dragged);
                    }}
                    onClick={() => { if (selected != null) place(slot.key, selected); }}
                  >
                    <div className="image-template-slot-label">
                      <span>{slot.label}</span>
                      {image && <button type="button" onClick={(event) => { event.stopPropagation(); clearSlot(slot.key); }} title="تفريغ الخانة">×</button>}
                    </div>
                    {image ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={image.filePath}
                        alt={slot.label}
                        draggable
                        onDragStart={(event) => event.dataTransfer.setData("text/plain", String(image.id))}
                        onClick={(event) => { event.stopPropagation(); setSelected((current) => (current === image.id ? null : image.id)); }}
                        className={selected === image.id ? "is-selected" : ""}
                      />
                    ) : (
                      <div className="image-template-empty">فاضية</div>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="mt-4">
              <h4 className="text-sm font-semibold">صور من غير مكان ({tray.length})</h4>
              <div className="image-template-tray mt-2">
                {tray.map((image) => (
                  <div key={image.id} className="image-template-tray-item">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={image.filePath}
                      alt={image.kind && isImageKind(image.kind) ? IMAGE_KIND_LABELS[image.kind] : "صورة"}
                      draggable
                      onDragStart={(event) => event.dataTransfer.setData("text/plain", String(image.id))}
                      onClick={() => setSelected((current) => (current === image.id ? null : image.id))}
                      className={selected === image.id ? "is-selected" : ""}
                    />
                    <span>{image.kind && isImageKind(image.kind) ? IMAGE_KIND_LABELS[image.kind] : "غير محدد"}</span>
                  </div>
                ))}
                {!tray.length && <p className="text-xs text-muted">كل الصور اتحطت في التمبلت.</p>}
              </div>
            </div>

            <div className="mt-4 flex flex-wrap items-center gap-2">
              <button type="button" disabled={saving} onClick={save} className="rounded-md btn-3d-primary px-4 py-2 text-sm disabled:opacity-50">
                {saving ? "جارٍ الحفظ…" : "حفظ التوزيع"}
              </button>
              {(() => {
                const faceId = template.slots
                  .filter((slot) => FACE_KINDS.includes(slot.kind as ImageKind))
                  .map((slot) => assignments[slot.key])
                  .find((id) => id != null);
                if (faceId == null) return null;
                return (
                  <button type="button" disabled={saving} onClick={() => makeAvatar(faceId)} className="rounded-md border border-border px-3 py-2 text-sm hover:bg-primary-soft">
                    اجعل صورة الوش دي صورة الملف
                  </button>
                );
              })()}
            </div>
          </>
        ) : null}
      </div>
    </div>
  );
}
