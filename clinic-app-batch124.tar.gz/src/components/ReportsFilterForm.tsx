"use client";

import { useRef, useState, useTransition } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { unlockDoctorReportAction } from "@/app/reports/actions";

type Doctor = { id: number; full_name: string };
type Service = { id: number; name: string; code?: string | null };

// فورم فلاتر تقرير الإيرادات — بيبعت نفسه (GET لنفس الصفحة) تلقائيًا بمجرد أي
// تغيير، زي DateFilterForm بالظبط. اختيار "شهر كامل" مش حقل بيتبعت لوحده — بس
// أداة مساعدة بتملى حقلي "من"/"إلى" بأول وآخر يوم في الشهر المختار وتبعت الفورم.
export default function ReportsFilterForm({
  from,
  to,
  minFrom = null,
  doctorId,
  serviceId,
  doctors,
  services,
  showDoctorFilter,
  requirePassword,
}: {
  from: string;
  to: string;
  // reports_own بس: أقدم تاريخ "من" مسموح بيه (شهرين قبل "إلى") — ملحوظة بصرية
  // (min على حقل التاريخ) بس، التحقق الحقيقي والتقصير بيحصل في السيرفر دايمًا.
  minFrom?: string | null;
  doctorId: number | null;
  serviceId: number | null;
  doctors: Doctor[];
  services: Service[];
  // reports_own بس (بدون reports_full، عادة دكتور): مقفول على نفسه، من غير قايمة اختيار دكتور خالص.
  showDoctorFilter: boolean;
  requirePassword: boolean;
}) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const formRef = useRef<HTMLFormElement>(null);
  const fromRef = useRef<HTMLInputElement>(null);
  const toRef = useRef<HTMLInputElement>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [passwordError, setPasswordError] = useState("");
  const [isPending, startTransition] = useTransition();

  function setRange(fromStr: string, toStr: string) {
    if (fromRef.current) fromRef.current.value = fromStr;
    if (toRef.current) toRef.current.value = toStr;
  }

  function applyMonth(monthValue: string) {
    if (!monthValue) return;
    const [y, m] = monthValue.split("-").map(Number);
    const first = new Date(Date.UTC(y, m - 1, 1)).toISOString().slice(0, 10);
    const last = new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10);
    setRange(first, last);
  }

  function applyCurrentMonth() {
    const now = new Date();
    applyMonth(`${now.getUTCFullYear()}-${String(now.getUTCMonth() + 1).padStart(2, "0")}`);
  }

  function applyPrevMonth() {
    const now = new Date();
    const prev = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 1, 1));
    applyMonth(`${prev.getUTCFullYear()}-${String(prev.getUTCMonth() + 1).padStart(2, "0")}`);
  }

  function applyToday() {
    const now = new Date();
    const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
    setRange(today, today);
  }

  return (
    <>
    <form
      ref={formRef}
      method="get"
      onSubmit={(event) => {
        if (!requirePassword) return;
        event.preventDefault();
        setPasswordError("");
        setShowPassword(true);
      }}
      className="card-3d rounded-xl p-4 flex items-end gap-3 flex-wrap"
    >
      <input type="hidden" name="tab" value="financial" />
      <input type="hidden" name="financial_tab" value={searchParams.get("financial_tab") || "revenue"} />
      <div>
        <label className="block text-xs text-muted mb-1">من</label>
        <input
          ref={fromRef}
          type="date"
          name="from"
          defaultValue={from}
          min={minFrom ?? undefined}
          className="rounded-md border border-border bg-background px-2 py-1.5 text-sm"
        />
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">إلى</label>
        <input
          ref={toRef}
          type="date"
          name="to"
          defaultValue={to}
          className="rounded-md border border-border bg-background px-2 py-1.5 text-sm"
        />
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">اختيار شهر كامل</label>
        <input
          type="month"
          onChange={(e) => applyMonth(e.target.value)}
          className="rounded-md border border-border bg-background px-2 py-1.5 text-sm"
        />
      </div>
      <div className="flex gap-1">
        <button type="button" onClick={applyToday} className="px-2 py-1.5 rounded-md border border-border text-xs hover:bg-primary-soft">
          اليوم
        </button>
        <button type="button" onClick={applyCurrentMonth} className="px-2 py-1.5 rounded-md border border-border text-xs hover:bg-primary-soft">
          الشهر ده
        </button>
        <button type="button" onClick={applyPrevMonth} className="px-2 py-1.5 rounded-md border border-border text-xs hover:bg-primary-soft">
          الشهر اللي فات
        </button>
      </div>

      {showDoctorFilter && (
        <div>
          <label className="block text-xs text-muted mb-1">الدكتور</label>
          <select
            name="doctor_id"
            defaultValue={doctorId ?? ""}
            className="rounded-md border border-border bg-background px-2 py-1.5 text-sm"
          >
            <option value="">كل الأطباء</option>
            {doctors.map((d) => (
              <option key={d.id} value={d.id}>
                {d.full_name}
              </option>
            ))}
          </select>
        </div>
      )}

      <div>
        <label className="block text-xs text-muted mb-1">الخدمة</label>
        <select
          name="service_id"
          defaultValue={serviceId ?? ""}
          className="rounded-md border border-border bg-background px-2 py-1.5 text-sm"
        >
          <option value="">كل الخدمات</option>
          {services.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
      </div>

      <button type="submit" className="px-3 py-1.5 rounded-md btn-3d-primary text-sm">
        تطبيق
      </button>
    </form>
    {showPassword && (
      <div className="fixed inset-0 z-[100] grid place-items-center bg-black/45 p-4" onClick={() => setShowPassword(false)}>
        <form
          className="card-3d w-full max-w-sm rounded-xl p-5 space-y-4"
          onClick={(event) => event.stopPropagation()}
          onSubmit={(event) => {
            event.preventDefault();
            const reportForm = formRef.current;
            if (!reportForm) return;
            const unlockData = new FormData(reportForm);
            unlockData.set("password", String(new FormData(event.currentTarget).get("password") || ""));
            startTransition(async () => {
              const result = await unlockDoctorReportAction(unlockData);
              if (!result.ok || !result.url) {
                setPasswordError(result.reason || "تعذر فتح التقرير");
                return;
              }
              setShowPassword(false);
              router.push(result.url);
              router.refresh();
            });
          }}
        >
          <div>
            <h2 className="font-semibold">تأكيد كلمة المرور</h2>
            <p className="mt-1 text-xs text-muted">أدخل كلمة مرور حسابك لإظهار إجماليات الفترة المختارة.</p>
          </div>
          <label className="block text-sm">
            <span className="mb-1 block text-xs text-muted">كلمة المرور</span>
            <input name="password" type="password" required autoFocus className="w-full rounded-md border border-border bg-background px-3 py-2" />
          </label>
          {passwordError && <p className="text-xs text-danger">{passwordError}</p>}
          <div className="flex gap-2">
            <button type="submit" disabled={isPending} className="rounded-md btn-3d-primary px-4 py-2 text-sm disabled:opacity-60">{isPending ? "جاري التحقق..." : "إظهار التقرير"}</button>
            <button type="button" onClick={() => setShowPassword(false)} className="rounded-md border border-border px-4 py-2 text-sm">إلغاء</button>
          </div>
        </form>
      </div>
    )}
    </>
  );
}
