"use client";

import { useState, type ReactNode } from "react";

export type ReportSection = { key: string; label: string; items: { key: string; label: string; content: ReactNode }[] };

export default function ReportsWorkspace({ sections, initialSection, initialReport }: { sections: ReportSection[]; initialSection?: string; initialReport?: string }) {
  const [sectionKey, setSectionKey] = useState(initialSection);
  const [reportKeys, setReportKeys] = useState<Record<string, string>>({ [initialSection ?? sections[0]?.key]: initialReport ?? "" });
  const section = sections.find((item) => item.key === sectionKey) ?? sections[0];
  if (!section) return null;
  const report = section.items.find((item) => item.key === reportKeys[section.key]) ?? section.items[0];
  function select(sectionId: string, reportId: string) {
    setSectionKey(sectionId);
    setReportKeys((old) => ({ ...old, [sectionId]: reportId }));
    const url = new URL(window.location.href);
    url.searchParams.set("tab", sectionId);
    url.searchParams.set(sectionId === "financial" ? "financial_tab" : "report", reportId);
    window.history.replaceState(null, "", url);
  }
  const buttonClass = (active: boolean) => `w-full text-right px-3 py-2 rounded-md text-sm transition-colors ${active ? "bg-primary text-white font-medium" : "hover:bg-primary-soft"}`;
  return <div className="reports-workspace" dir="rtl">
    <aside className="reports-navigation">
      <nav aria-label="تصنيفات التقارير" className="card-3d rounded-xl p-2 flex flex-col gap-1">
        {sections.map((item) => <button key={item.key} type="button" aria-pressed={item.key === section.key} className={buttonClass(item.key === section.key)} onClick={() => select(item.key, reportKeys[item.key] || item.items[0]?.key || "")}>{item.label}</button>)}
      </nav>
      <nav aria-label="التقارير الفرعية" className="card-3d rounded-xl p-2 flex flex-col gap-1">
        {section.items.map((item) => <button key={item.key} type="button" aria-pressed={item.key === report?.key} className={buttonClass(item.key === report?.key)} onClick={() => select(section.key, item.key)}>{item.label}</button>)}
      </nav>
    </aside>
    <div className="min-w-0 space-y-6">{report?.content}</div>
  </div>;
}
