"use client";

// Batch 124: تظبيط تمبلت صور التقويم من الإعدادات (تبويب شارت التقويم).
// كل خانة ليها اسم ونوع الصورة المتوقع فيها؛ الترتيب هنا هو ترتيب العرض،
// وعدد الأعمدة بيحدد شكل الشبكة.

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { saveOrthoImageTemplateAction } from "@/app/settings/actions";
import { IMAGE_KIND_LABELS, isImageKind } from "@/lib/images/kinds";
import { DEFAULT_TEMPLATE, TEMPLATE_KIND_OPTIONS, type ImageTemplate, type TemplateSlot, type TemplateSlotKind } from "@/lib/images/template";

const kindLabel = (kind: TemplateSlotKind) => (kind === "any" ? "أي صورة" : isImageKind(kind) ? IMAGE_KIND_LABELS[kind] : kind);

export default function OrthoImageTemplateForm({ template }: { template: ImageTemplate }) {
  const router = useRouter();
  const [columns, setColumns] = useState(template.columns);
  const [slots, setSlots] = useState<TemplateSlot[]>(template.slots);
  const [message, setMessage] = useState("");
  const [saving, startSaving] = useTransition();

  function updateSlot(index: number, patch: Partial<TemplateSlot>) {
    setSlots((current) => current.map((slot, position) => (position === index ? { ...slot, ...patch } : slot)));
  }

  function move(index: number, direction: -1 | 1) {
    setSlots((current) => {
      const target = index + direction;
      if (target < 0 || target >= current.length) return current;
      const next = [...current];
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  }

  function addSlot() {
    const key = `slot_${Date.now().toString(36)}`;
    setSlots((current) => [...current, { key, label: "خانة جديدة", kind: "any" }]);
  }

  function save() {
    setMessage("");
    startSaving(async () => {
      const result = await saveOrthoImageTemplateAction({ columns, slots });
      setMessage(result.ok ? "اتحفظ." : result.error || "تعذر الحفظ.");
      if (result.ok) router.refresh();
    });
  }

  return (
    <div className="space-y-3">
      <div>
        <h3 className="font-semibold">تمبلت صور التقويم</h3>
        <p className="text-sm text-muted mt-1">
          لما يترفع طقم صور للمريض، السيستم بيتعرف على نوع كل صورة ويحطها في خانتها هنا، وبيعرض شاشة مراجعة قبل الحفظ.
        </p>
      </div>

      <label className="block text-sm">
        <span className="text-muted">عدد الأعمدة</span>
        <input
          type="number"
          min={1}
          max={6}
          value={columns}
          onChange={(event) => setColumns(Math.min(6, Math.max(1, Number(event.target.value) || 1)))}
          className="mt-1 w-24 rounded-md border border-border bg-background px-2 py-1.5 text-sm"
        />
      </label>

      <div className="space-y-2">
        {slots.map((slot, index) => (
          <div key={slot.key} className="flex flex-wrap items-center gap-2 rounded-md border border-border p-2">
            <span className="text-xs text-muted w-6 text-center">{index + 1}</span>
            <input
              value={slot.label}
              onChange={(event) => updateSlot(index, { label: event.target.value })}
              placeholder="اسم الخانة"
              className="flex-1 min-w-[10rem] rounded-md border border-border bg-background px-2 py-1.5 text-sm"
            />
            <select
              value={slot.kind}
              onChange={(event) => updateSlot(index, { kind: event.target.value as TemplateSlotKind })}
              className="rounded-md border border-border bg-background px-2 py-1.5 text-sm"
            >
              {TEMPLATE_KIND_OPTIONS.map((kind) => (
                <option key={kind} value={kind}>{kindLabel(kind)}</option>
              ))}
            </select>
            <button type="button" onClick={() => move(index, -1)} className="rounded-md border border-border px-2 py-1 text-sm hover:bg-primary-soft" title="لفوق">▲</button>
            <button type="button" onClick={() => move(index, 1)} className="rounded-md border border-border px-2 py-1 text-sm hover:bg-primary-soft" title="لتحت">▼</button>
            <button type="button" onClick={() => setSlots((current) => current.filter((_, position) => position !== index))} className="rounded-md bg-danger-soft px-2 py-1 text-sm text-danger hover:opacity-85">حذف</button>
          </div>
        ))}
        {!slots.length && <p className="text-sm text-muted">مفيش خانات — ضيف خانة أو ارجع للتمبلت الافتراضي.</p>}
      </div>

      <div className="flex flex-wrap gap-2">
        <button type="button" onClick={addSlot} className="rounded-md border border-border px-3 py-2 text-sm hover:bg-primary-soft">+ خانة</button>
        <button type="button" onClick={() => { setSlots(DEFAULT_TEMPLATE.slots); setColumns(DEFAULT_TEMPLATE.columns); }} className="rounded-md border border-border px-3 py-2 text-sm hover:bg-primary-soft">التمبلت الافتراضي</button>
        <button type="button" disabled={saving} onClick={save} className="rounded-md btn-3d-primary px-4 py-2 text-sm disabled:opacity-50">{saving ? "جارٍ الحفظ…" : "حفظ التمبلت"}</button>
        {message && <span className="self-center text-sm text-muted">{message}</span>}
      </div>
    </div>
  );
}
