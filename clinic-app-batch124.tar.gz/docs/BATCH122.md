# Batch 122

- Shared central-schedule appointment cards now power the home waiting timeline and the doctor's no-shift appointment list.
- Home cards use the full available width; patient/service are on the right and status/timer/doctor on the left. Clinic picker stacks above adjacent cards.
- Doctors cannot see the front-desk clinic totals strip. Doctors without a shift can see and complete their own appointments without creating a grid.
- Both home totals retain the single `view_home_daily_totals` permission.
- Main and secondary report menus share one right-hand column, with secondary items below the main categories.
- Entering a clinic requires attended status and cannot restart an already-running entry. Returning to waiting preserves attendance; no-show resets the attendance cycle.

Validation: TypeScript, production webpack build, security tests, server-action export checks, deployment payload checks, and browser integration tests passed. Browser checks cover desktop/mobile card layout, doctor appointment isolation, no-shift completion, totals permissions, stacked report navigation, entry/return/no-show and timer persistence.

Packaging excludes local test data, databases, credentials, dependencies and build output. This release has not been deployed to the live server.

Deployment: upload `clinic-app-batch122.tar.gz` to the existing deployment-payload repository before running `deploy122.sh` on the server. The script verifies the archive checksum and Batch 121 baseline for changed source files, builds in staging, preserves persistent data and previous releases, checks health, and rolls back on failure. A baseline mismatch stops deployment; do not bypass it without reviewing the live changes.
