// Batch 123 browser integration test (local only — never against production).
// Run: CLINIC_DB_PATH=test-data/clinic.db npx next start -p 3123, then: node scripts/test-batch123.mjs
import assert from "node:assert/strict";
import path from "node:path";
import fs from "node:fs";
import Database from "better-sqlite3";
import { SignJWT } from "jose";
import { chromium } from "playwright";

const BASE = process.env.TEST_BASE_URL || "http://localhost:3123";
const SECRET = process.env.TEST_SESSION_SECRET || "batch122-local-test-only-secret-at-least-32";
const dbPath = path.resolve("test-data/clinic.db");
assert(dbPath.includes(path.sep + "test-data" + path.sep), "test DB only");
const db = new Database(dbPath);
db.prepare("UPDATE appointments SET status='cancelled' WHERE status IN ('booked','attended')").run();
const today = new Intl.DateTimeFormat("en-CA", { timeZone: "Africa/Cairo" }).format(new Date());
const suffix = Date.now();
const doctor = Number(db.prepare("INSERT INTO doctors(full_name) VALUES (?)").run("طبيب 123 " + suffix).lastInsertRowid);
const roomIds = db.prepare("SELECT id FROM rooms ORDER BY id").all().map((r) => r.id);
while (roomIds.length < 2) roomIds.push(Number(db.prepare("INSERT INTO rooms(name) VALUES (?)").run("عيادة " + (roomIds.length + 1)).lastInsertRowid));
const [room1, room2] = roomIds;
const service = Number(db.prepare("INSERT INTO services(name, default_price) VALUES (?, 100)").run("خدمة 123 " + suffix).lastInsertRowid);
const users = {};
for (const role of ["admin", "doctor"]) {
  const username = role + "123_" + suffix;
  const id = Number(db.prepare("INSERT INTO users(username,password_hash,full_name,role,doctor_id,must_change_password) VALUES (?, 'unused', ?, ?, ?, 0)").run(username, role, role, role === "doctor" ? doctor : null).lastInsertRowid);
  users[role] = { userId: id, username, fullName: role, role, doctorId: role === "doctor" ? doctor : null, sessionVersion: 0 };
  db.prepare("INSERT OR REPLACE INTO user_permissions VALUES (?, 'view_home_dashboard', 1)").run(id);
}
const names = ["أحمد اختبار", "بسمة اختبار", "كريم اختبار"];
const appts = names.map((name, i) => {
  const patient = Number(db.prepare("INSERT INTO patients(file_number,full_name,phone,birth_date) VALUES (?,?,?,?)").run("T123-" + suffix + i, name, "01000000001", "1990-01-01").lastInsertRowid);
  return Number(db.prepare("INSERT INTO appointments(patient_id,doctor_id,room_id,appointment_date,start_time,status,purpose_type,purpose_service_id) VALUES (?,?,?,?,?,'booked','service',?)").run(patient, doctor, room1, today, ["12:00", "13:00", "14:00"][i], service).lastInsertRowid);
});
const [A, B, C] = appts;
const state = (id) => db.prepare("SELECT * FROM appointments WHERE id=?").get(id);
async function until(predicate, message) {
  for (let n = 0; n < 100; n++) { if (predicate()) return; await new Promise((r) => setTimeout(r, 100)); }
  assert(predicate(), message);
}
const browser = await chromium.launch({ headless: true, ...(process.env.CHROME_PATH ? { executablePath: process.env.CHROME_PATH } : {}) });
fs.mkdirSync("test-data/screenshots", { recursive: true });
const errors = [];
async function pageFor(role) {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  const token = await new SignJWT(users[role]).setProtectedHeader({ alg: "HS256" }).setIssuedAt().setExpirationTime("1h").sign(new TextEncoder().encode(SECRET));
  await context.addCookies([{ name: "clinic_session", value: token, url: BASE }]);
  const page = await context.newPage();
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("dialog", (d) => d.dismiss());
  return page;
}
try {
  const admin = await pageFor("admin");
  const clinicPanel = admin.locator(".home-timeline-panel");
  const reception = admin.locator(".home-clinic-reception");
  await admin.goto(BASE + "/");
  await clinicPanel.getByText("الاستقبال", { exact: true }).waitFor();

  // A: حضر ثم دخل Clinic 1 → يظهر في حالة العيادات.
  await admin.locator("#appt-cell-" + A).click({ position: { x: 20, y: 20 } });
  await until(() => state(A).status === "attended", "A attended");
  await admin.locator("#appt-cell-" + A + " .schedule-card-status--attended").waitFor();
  await admin.locator("#appt-cell-" + A).click({ position: { x: 20, y: 20 } });
  await admin.locator("#appt-cell-" + A + " .schedule-entry-picker button").first().click();
  await until(() => state(A).entered_room_id === room1, "A entered clinic 1");
  await clinicPanel.locator("#appt-cell-" + A).waitFor();

  // (1) كليك يمين على المريض داخل العيادة → نفس قايمة الجدول، «لم يحضر» فعّال أول 3 دقائق.
  await clinicPanel.locator("#appt-cell-" + A).click({ button: "right" });
  const menu = admin.locator(".z-50.card-3d");
  await menu.getByRole("button", { name: "تم", exact: true }).waitFor();
  assert.equal(await menu.getByRole("button", { name: "رسائل واتساب" }).count(), 1, "whatsapp in clinic menu");
  assert.equal(await menu.getByRole("button", { name: "لم يحضر", exact: true }).isEnabled(), true, "no-show active in first 3 minutes");
  assert.equal(await menu.getByRole("button", { name: "حضر", exact: true }).count(), 0, "attended item replaced");
  await admin.keyboard.press("Escape");
  await admin.mouse.click(5, 400);

  // (6) بعد 3 دقائق داخل العيادة: «لم يحضر» والإلغاء معطلين، والسيرفر يرفض.
  db.prepare("UPDATE appointments SET entered_at=? WHERE id=?").run(new Date(Date.now() - 5 * 60_000).toISOString(), A);
  await admin.reload();
  await clinicPanel.locator("#appt-cell-" + A).click({ button: "right" });
  assert.equal(await menu.getByRole("button", { name: "لم يحضر", exact: true }).isDisabled(), true, "no-show disabled after 3 minutes");
  assert.equal(await menu.getByRole("button", { name: "إلغاء (تفضية الخانة)" }).isDisabled(), true, "cancel disabled after 3 minutes");
  await admin.mouse.click(5, 400);

  // (2) B يدخل نفس العيادة → A يتنقل لخانة «الاستقبال» ويتثبت كزيارة.
  await admin.locator("#appt-cell-" + B).click({ position: { x: 20, y: 20 } });
  await until(() => state(B).status === "attended", "B attended");
  await admin.locator("#appt-cell-" + B + " .schedule-card-status--attended").waitFor();
  await admin.locator("#appt-cell-" + B).click({ position: { x: 20, y: 20 } });
  await admin.locator("#appt-cell-" + B + " .schedule-entry-picker button").first().click();
  await until(() => state(B).entered_room_id === room1 && state(A).entered_room_id === null, "B pushes A out");
  assert(state(A).left_clinic_at, "A moved to reception");
  assert(state(A).clinic_confirmed_at, "A visit confirmed");
  assert.equal(state(A).status, "attended");
  await reception.locator("#appt-cell-" + A).waitFor();
  assert.equal(await admin.locator(".home-appointments-panel #appt-cell-" + A).count(), 0, "A not back in waiting list");
  await reception.locator("#appt-cell-" + A).click({ button: "right" });
  assert.equal(await menu.getByRole("button", { name: "لم يحضر", exact: true }).isDisabled(), true, "reception no-show disabled");
  await admin.mouse.click(5, 400);
  await admin.screenshot({ path: "test-data/screenshots/b123-home-reception.png", fullPage: true });

  // (3) C حضر → كليك يمين يظهر «لم يحضر» بدل «حضر» مع رسالة تأكيد.
  await admin.locator("#appt-cell-" + C).click({ position: { x: 20, y: 20 } });
  await until(() => state(C).status === "attended", "C attended");
  await admin.locator("#appt-cell-" + C + " .schedule-card-status--attended").waitFor();
  await admin.locator(".home-appointments-panel #appt-cell-" + C).click({ button: "right" });
  await menu.getByRole("button", { name: "لم يحضر", exact: true }).click();
  const confirm = admin.getByRole("dialog", { name: "تأكيد تغيير الحالة" });
  await confirm.getByRole("button", { name: "رجوع" }).click();
  assert.equal(state(C).status, "attended", "cancel confirm keeps state");
  await admin.locator(".home-appointments-panel #appt-cell-" + C).click({ button: "right" });
  await menu.getByRole("button", { name: "لم يحضر", exact: true }).click();
  await confirm.getByRole("button", { name: "نعم، لم يحضر" }).click();
  await until(() => state(C).status === "no_show", "C no-show after confirmation");
  // (4) «لم يحضر» يفضل ظاهر في الشاشة الرئيسية.
  await admin.reload();
  await admin.locator(".home-appointments-panel #appt-cell-" + C).waitFor();

  // نفس السلوك في الجدول: الإلغاء بتأكيد.
  await admin.goto(BASE + "/front-desk");
  await admin.locator("#appt-cell-" + C).click({ button: "right" });
  await menu.getByRole("button", { name: "حضر", exact: true }).waitFor();
  await menu.getByRole("button", { name: "إلغاء (تفضية الخانة)" }).click();
  await confirm.getByRole("button", { name: "رجوع" }).click();
  assert.equal(state(C).status, "no_show");

  // (5) الطبيب من غير شيفت يشوف مريضه داخل العيادة في الشاشة الرئيسية.
  const doc = await pageFor("doctor");
  await doc.goto(BASE + "/");
  await doc.locator(".home-timeline-panel #appt-cell-" + B).waitFor();
  await doc.locator(".home-clinic-reception #appt-cell-" + A).waitFor();
  await doc.screenshot({ path: "test-data/screenshots/b123-doctor-home.png", fullPage: true });

  // الخروج من خانة الاستقبال بعد «تم».
  const fd = db.prepare("UPDATE appointments SET status='done', completed_at=? WHERE id=?");
  fd.run(new Date().toISOString(), A);
  await admin.goto(BASE + "/");
  await admin.locator(".home-timeline-panel #appt-cell-" + B).waitFor();
  assert.equal(await reception.locator("#appt-cell-" + A).count(), 0, "done leaves reception");
  assert.deepEqual(errors, []);
  console.log("PASS batch 123: clinic menu, 3-minute rule, push-out to reception, no-show confirm, home no-show, doctor visibility.");
} finally { await browser.close(); db.close(); }
