// Batch 124 browser integration test (local only).
// Run: CLINIC_DB_PATH=test-data/clinic.db npx next start -p 3124, then:
//   FIXTURES=<dir with sample photos> node scripts/test-batch124.mjs
import assert from "node:assert/strict";
import path from "node:path";
import fs from "node:fs";
import Database from "better-sqlite3";
import { SignJWT } from "jose";
import { chromium } from "playwright";

const BASE = process.env.TEST_BASE_URL || "http://localhost:3124";
const SECRET = process.env.TEST_SESSION_SECRET || "batch122-local-test-only-secret-at-least-32";
const FIXTURES = process.env.FIXTURES || "test-data/fixtures";
const dbPath = path.resolve("test-data/clinic.db");
assert(dbPath.includes(path.sep + "test-data" + path.sep), "test DB only");
const db = new Database(dbPath);
const suffix = Date.now();
const adminId = Number(db.prepare("INSERT INTO users(username,password_hash,full_name,role,must_change_password) VALUES (?, 'unused', 'admin', 'admin', 0)").run("admin124_" + suffix).lastInsertRowid);
db.prepare("INSERT OR REPLACE INTO user_permissions VALUES (?, 'view_home_dashboard', 1)").run(adminId);
const patientId = Number(db.prepare("INSERT INTO patients(file_number,full_name,phone,birth_date) VALUES (?,?,?,?)").run("T124-" + suffix, "مريض تمبلت", "01000000002", "2000-01-01").lastInsertRowid);

const files = fs.readdirSync(FIXTURES).filter((name) => /\.(png|jpe?g)$/i.test(name)).sort().map((name) => path.resolve(FIXTURES, name));
assert(files.length >= 6, "need sample images in " + FIXTURES);

const browser = await chromium.launch({ headless: true, ...(process.env.CHROME_PATH ? { executablePath: process.env.CHROME_PATH } : {}) });
fs.mkdirSync("test-data/screenshots", { recursive: true });
const errors = [];
const images = () => db.prepare("SELECT * FROM patient_images pi JOIN patient_image_groups g ON g.id=pi.group_id WHERE g.patient_id=?").all(patientId);
async function until(predicate, message) {
  for (let n = 0; n < 200; n += 1) { if (predicate()) return; await new Promise((r) => setTimeout(r, 150)); }
  assert(predicate(), message);
}
try {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  const token = await new SignJWT({ userId: adminId, username: "admin124", fullName: "admin", role: "admin", doctorId: null, sessionVersion: 0 })
    .setProtectedHeader({ alg: "HS256" }).setIssuedAt().setExpirationTime("1h").sign(new TextEncoder().encode(SECRET));
  await context.addCookies([{ name: "clinic_session", value: token, url: BASE }]);
  const page = await context.newPage();
  page.on("pageerror", (e) => errors.push(e.message));

  // الرفع من شارت التقويم: الصور بتترفع، والسيستم بيصنفها، وشاشة المراجعة بتفتح.
  await page.goto(`${BASE}/patients/${patientId}/orthodontics`);
  const input = page.locator('input[type="file"]').first();
  await input.waitFor({ state: "attached" });
  await input.setInputFiles(files);
  await page.getByRole("button", { name: /Upload \(/ }).first().click();
  await until(() => images().length === files.length, "all files uploaded");

  // التصنيف التلقائي اتسجل مع كل صورة.
  const kinds = images().map((row) => row.image_kind);
  assert(kinds.every((kind) => kind), "every image got an auto kind: " + JSON.stringify(kinds));
  assert(kinds.some((kind) => kind.startsWith("xray")), "x-rays detected");
  assert(kinds.some((kind) => kind.startsWith("face")), "face photos detected");
  assert(kinds.some((kind) => kind.startsWith("intraoral")), "intraoral photos detected");

  // شاشة المراجعة: التمبلت ظاهر بخانات متملية، والصور الزيادة في الترَاي.
  const board = page.getByRole("dialog", { name: "ترتيب الصور في التمبلت" });
  await board.waitFor();
  await board.locator(".image-template-slot img").first().waitFor();
  const filled = await board.locator(".image-template-slot img").count();
  assert(filled >= 5, "slots auto-filled: " + filled);
  await page.screenshot({ path: "test-data/screenshots/b124-template-board.png", fullPage: true });

  // سحب صورة من الترَاي لخانة (بالدوس: صورة ثم خانة).
  const trayCount = await board.locator(".image-template-tray-item img").count();
  if (trayCount > 0) {
    await board.locator(".image-template-tray-item img").first().click();
    await board.locator(".image-template-slot").first().click();
  }
  await board.getByRole("button", { name: "حفظ التوزيع" }).click();
  await until(() => images().some((row) => row.template_slot), "assignments saved");
  const patient = () => db.prepare("SELECT * FROM patients WHERE id=?").get(patientId);
  await until(() => patient().avatar_path, "patient thumbnail created from a face photo");
  const avatarFile = path.join(process.env.CLINIC_UPLOAD_DIR || "data/uploads", patient().avatar_path.replace("/patient-files/", ""));
  assert(fs.existsSync(avatarFile), "thumbnail file written: " + avatarFile);

  // التوزيع المحفوظ بيرجع زي ما هو لما الشاشة تتفتح تاني من المعرض.
  await page.reload();
  await page.getByRole("button", { name: "⊞ template" }).first().click();
  await board.waitFor();
  await board.locator(".image-template-slot img").first().waitFor();
  const reopened = await board.locator(".image-template-slot img").count();
  assert.equal(reopened, images().filter((row) => row.template_slot).length, "saved layout reopened as-is");
  assert.deepEqual(errors, []);
  console.log("PASS batch 124: auto classification, template board, manual fix, saved layout and patient thumbnail.");
} finally { await browser.close(); db.close(); }
