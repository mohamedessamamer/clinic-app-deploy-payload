import type { Role } from "./auth";

// ثوابت الصلاحيات فقط — من غير أي استيراد لطبقة قاعدة البيانات، عشان يصلح
// للاستخدام في مكونات العميل (client components) زي PermissionsManager كمان.
// الدوال اللي بتلمس قاعدة البيانات (getPermissionOverrides..) موجودة في lib/permissions.ts.
export const PERMISSION_DEFS = [
  { key: "reports_full", label: "عرض كل التقارير (كل الأطباء وكل الفترات)" },
  { key: "reports_own", label: "عرض تقريره الشخصي بس (للدكتور)" },
  { key: "collect_payments", label: "تحصيل المدفوعات من الاستقبال" },
  { key: "manage_inventory", label: "إدارة المخزون" },
  { key: "manage_expenses", label: "إدارة المصروفات والمرتبات" },
  { key: "manage_settings", label: "الوصول لصفحة الإعدادات" },
  { key: "schedule_all_rooms", label: "عرض الجدول المركزي لكل الغرف/العيادات (مش بس شيفته هو)" },
  { key: "schedule_edit", label: "التعديل في الجدول المركزي (حجز مواعيد وتغيير حالتها)" },
  {
    key: "override_visit_doctor",
    label: "اختيار مقدم خدمة مختلف في سجل الكشوفات والزيارات (لدكاترة مساعدين) — من غير ما يأثر على التحصيل المالي",
  },
] as const;

export type PermissionKey = (typeof PERMISSION_DEFS)[number]["key"];

export const ROLE_DEFAULT_PERMISSIONS: Record<Role, PermissionKey[]> = {
  admin: [
    "reports_full",
    "collect_payments",
    "manage_inventory",
    "manage_expenses",
    "manage_settings",
    "schedule_all_rooms",
    "schedule_edit",
    "override_visit_doctor",
  ],
  clinic_manager: ["reports_full", "manage_inventory", "schedule_all_rooms", "override_visit_doctor"],
  accountant: ["reports_full", "collect_payments", "manage_expenses"],
  reception: ["collect_payments", "schedule_all_rooms", "schedule_edit"],
  // الدكتور افتراضيًا يشوف الجدول المركزي لشيفته/غرفته بس النهاردة، وبشكل عرض فقط
  // (من غير حجز أو تغيير حالة) — الأدمن يقدر يوسّع الصلاحيات دي لدكتور معيّن من
  // صفحة الإعدادات لو حابب (schedule_all_rooms و/أو schedule_edit).
  doctor: ["reports_own"],
};
