import { test } from "node:test";
import assert from "node:assert/strict";
import { chainAnchors, chainLabel, chainQty, chainTeeth, normalizeChains, otieQtyForArch } from "../../src/lib/ortho/power-chain.ts";

test("canine to a miniscrew between 16 and 15: teeth 15,14,13 + the screw = 4", () => {
  const chain = { arch: "upper" as const, from: 13, to: "16-15" };
  assert.deepEqual(chainTeeth(chain), [15, 14, 13]);
  assert.equal(chainQty(chain), 4);
  assert.deepEqual(chainAnchors(chain), ["16-15", 15, 14, 13]);
  assert.equal(chainLabel({ ...chain, onHooks: false }), "MS 16/15-13");
});

test("screw on the left side, lower arch", () => {
  const chain = { arch: "lower" as const, from: 33, to: "35-36" };
  assert.deepEqual(chainTeeth(chain), [33, 34, 35]);
  assert.equal(chainQty(chain), 4);
  assert.deepEqual(chainAnchors(chain), [33, 34, 35, "35-36"]);
});

test("screw to screw and non-adjacent gaps are rejected", () => {
  assert.equal(normalizeChains([{ arch: "upper", from: "16-15", to: "25-26" }]).ok, false);
  assert.equal(normalizeChains([{ arch: "upper", from: 13, to: "16-14" }]).ok, false);
  assert.equal(normalizeChains([{ arch: "upper", from: 13, to: "36-35" }]).ok, false);
  assert.deepEqual(normalizeChains([{ arch: "upper", from: 13, to: "16-15", onHooks: true }]), { ok: true, chains: [{ arch: "upper", from: 13, to: "16-15", onHooks: true }] });
});

test("O-ties: a chain to a screw on brackets covers only real teeth", () => {
  assert.equal(otieQtyForArch("upper", [15, 14, 13, 12], [{ arch: "upper", from: 13, to: "16-15", onHooks: false }]), 1);
});
