import { test } from "node:test";
import assert from "node:assert/strict";
import { classifyElastic, colorForSize, describeElastics, normalizeElastics, shouldStartNewElastic, sizeLabel, upsertElasticsLine } from "../../src/lib/ortho/elastics.ts";

const t = (fdi: number, palatal = false) => ({ fdi, palatal });
const e = (size: string, ...points: { fdi: number; palatal: boolean }[]) => ({ itemId: 1, size, points });

test("size label and colours", () => {
  assert.equal(sizeLabel("Elastic 3/16"), "3/16");
  assert.equal(colorForSize("Elastic 3/16"), "#2563EB");
  assert.equal(colorForSize("Elastic 1/8"), "#DC2626");
  assert.equal(colorForSize("Elastic 5/16"), "#16A34A");
});

test("classification by the clinic's own definitions", () => {
  assert.deepEqual(classifyElastic([t(13), t(46)]), { kind: "Class II", side: "right" });
  assert.deepEqual(classifyElastic([t(23), t(36)]), { kind: "Class II", side: "left" });
  assert.deepEqual(classifyElastic([t(43), t(16)]), { kind: "Class III", side: "right" });
  assert.deepEqual(classifyElastic([t(13), t(14), t(44), t(43)]), { kind: "Settling", side: "right" });
  assert.deepEqual(classifyElastic([t(23), t(24), t(35), t(34)]), { kind: "Settling Class II component", side: "left" });
  assert.deepEqual(classifyElastic([t(23), t(24), t(36), t(35)]), { kind: "Settling Class II component", side: "left" });
  assert.deepEqual(classifyElastic([t(33), t(34), t(25), t(24)]), { kind: "Settling Class III component", side: "left" });
  assert.deepEqual(classifyElastic([t(13), t(33)]), { kind: "Diagonal", side: "both" });
  assert.deepEqual(classifyElastic([t(26, true), t(36)]), { kind: "Cross", side: "left" });
  assert.equal(classifyElastic([t(13), t(16)]).kind, "Custom");
});

test("auto text: same both sides, mixed sides, mixed sizes", () => {
  assert.equal(describeElastics([e("Elastic 3/16", t(13), t(46)), e("Elastic 3/16", t(23), t(36))]), "Class II elastics right & left side (3/16)");
  assert.equal(describeElastics([e("Elastic 3/16", t(23), t(24), t(34), t(33)), e("Elastic 3/16", t(13), t(46))]), "Class II right & settling left (3/16)");
  assert.equal(describeElastics([e("Elastic 3/16", t(13), t(46)), e("Elastic 5/16", t(26, true), t(36))]), "Class II right (3/16) & cross elastic 26p-36 (5/16)");
});

test("right/left split automatically, diagonal does not split", () => {
  assert.equal(shouldStartNewElastic([t(13), t(46)], t(23)), true);
  assert.equal(shouldStartNewElastic([t(13)], t(33)), false);
  assert.equal(shouldStartNewElastic([t(13), t(14)], t(24)), false);
});

test("normalize", () => {
  assert.equal(normalizeElastics([{ size: "x", points: [t(13)] }]).ok, false);
  assert.equal(normalizeElastics([{ size: "x", points: [{ screw: "16-15", palatal: false }, { screw: "46-45", palatal: false }] }]).ok, false);
  assert.equal(normalizeElastics([{ size: "x", points: [t(13), { screw: "46-45", palatal: false }] }]).ok, true);
  assert.equal(normalizeElastics([{ size: "x", points: [t(18), t(13)] }]).ok, false);
});

test("note line is replaced, not duplicated", () => {
  const once = upsertElasticsLine("Patient cooperative", "Class II right (3/16)");
  assert.equal(once, "Patient cooperative\nElastics: Class II right (3/16)");
  assert.equal(upsertElasticsLine(once, "Settling right (1/8)"), "Patient cooperative\nElastics: Settling right (1/8)");
  assert.equal(upsertElasticsLine(once, ""), "Patient cooperative");
});

test("pair right/left even with a third elastic of another size", () => {
  const text = describeElastics([
    { itemId: 1, size: "Elastic 3/16", points: [{ fdi: 13, palatal: false }, { fdi: 46, palatal: false }] },
    { itemId: 2, size: "Elastic 5/16", points: [{ fdi: 16, palatal: true }, { fdi: 46, palatal: false }] },
    { itemId: 1, size: "Elastic 3/16", points: [{ fdi: 23, palatal: false }, { fdi: 36, palatal: false }] },
  ]);
  assert.equal(text, "Class II elastics right & left side (3/16) & cross elastic 16p-46 (5/16)");
});
