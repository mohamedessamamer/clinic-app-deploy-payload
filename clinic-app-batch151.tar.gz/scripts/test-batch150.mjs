// Batch 150 browser integration test (local only, test DB only).
// Real app + real chart: two O-tie colours, power chains by teeth (hooks/brackets),
// stock deductions per arch, "not deducted" when the colour has no power-chain item,
// the drawing on the chart, the clean chart (no bracket shadow on desktop, faint on touch),
// and that deleting the visit refunds everything.
//
// Run: CLINIC_DB_PATH=$PWD/test-data/clinic.db SESSION_SECRET=batch149-local-test-only-secret-at-least-32 npx next start -p 3149
//      then: node scripts/test-batch150.mjs
import assert from "node:assert/strict";
import path from "node:path";
import fs from "node:fs";
import Database from "better-sqlite3";
import { SignJWT } from "jose";
import { chromium } from "playwright";

const BASE = process.env.TEST_BASE_URL || "http://localhost:3149";
const SECRET = process.env.TEST_SESSION_SECRET || "batch149-local-test-only-secret-at-least-32";
const dbPath = path.resolve("test-data/clinic.db");
assert(dbPath.includes(path.sep + "test-data" + path.sep), "test DB only");
const db = new Database(dbPath);
db.pragma("busy_timeout = 5000");
const suffix = Date.now();
const adminId = Number(db.prepare("INSERT INTO users(username,password_hash,full_name,role,must_change_password) VALUES (?, 'unused', 'admin', 'admin', 0)").run(`admin150_${suffix}`).lastInsertRowid);
const doctorId = Number(db.prepare("INSERT INTO doctors(full_name, active) VALUES (?, 1)").run(`Dr Test ${suffix}`).lastInsertRowid);
db.prepare("INSERT OR REPLACE INTO clinic_settings(key, value) VALUES ('inventory_deductions_enabled', '1')").run();
const item = (name, usage, qty) => Number(db.prepare("INSERT INTO inventory_items(name, quantity, ortho_usage, available_in_clinical_selection) VALUES (?, ?, ?, 1)").run(name, qty, usage).lastInsertRowid);
const purple = item(`O-tie — Purple (ELC-014) ${suffix}`, "otie", 500);
const pink = item(`O-tie — Pink (ELC-016) ${suffix}`, "otie", 500);
const purpleChain = Number(db.prepare("SELECT id FROM inventory_items WHERE name = 'Power chain — Purple (ELC-014)'").get()?.id ?? item("Power chain — Purple (ELC-014)", "power_chain", 300));
db.prepare("DELETE FROM inventory_items WHERE ortho_usage = 'power_chain' AND name LIKE 'Power chain — Pink%'").run();
db.prepare("UPDATE inventory_items SET available_in_clinical_selection = 0 WHERE ortho_usage = 'otie' AND name LIKE 'O-tie — P% (ELC-01_) %' AND id NOT IN (?, ?)").run(purple, pink);
const qty = (id) => db.prepare("SELECT quantity FROM inventory_items WHERE id = ?").get(id).quantity;
const before = { purple: qty(purple), pink: qty(pink), chain: qty(purpleChain) };

const patientId = Number(db.prepare("INSERT INTO patients(file_number,full_name,phone,birth_date) VALUES (?,?,?,?)").run(`T150-${suffix}`, "Chart test 150", "01000000150", "2008-01-01").lastInsertRowid);
const st = {};
for (const q of [1, 2, 3, 4]) for (let i = 1; i <= 8; i++) st[q * 10 + i] = { bracket: i === 8 ? "none" : "bonded", debondDate: null, bondedDate: "2026-09-01", rebondCount: 0, extracted: false, comment: "" };
db.prepare("INSERT INTO orthodontic_charts(patient_id, tooth_states) VALUES (?, ?)").run(patientId, JSON.stringify(st));
const emptyPatient = Number(db.prepare("INSERT INTO patients(file_number,full_name,phone,birth_date) VALUES (?,?,?,?)").run(`T150E-${suffix}`, "No brackets 150", "01000000151", "2008-01-01").lastInsertRowid);
db.prepare("INSERT INTO orthodontic_charts(patient_id, tooth_states) VALUES (?, '{}')").run(emptyPatient);

const results = [];
const ok = (name) => { results.push(name); console.log("✓", name); };
const errors = [];
const dialogs = [];
const browser = await chromium.launch({ headless: true, ...(process.env.CHROME_PATH ? { executablePath: process.env.CHROME_PATH } : {}) });
fs.mkdirSync("test-data/screenshots", { recursive: true });
const token = await new SignJWT({ userId: adminId, username: "admin150", fullName: "admin", role: "admin", doctorId: null, sessionVersion: 0 })
  .setProtectedHeader({ alg: "HS256" }).setIssuedAt().setExpirationTime("1h").sign(new TextEncoder().encode(SECRET));
try {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1100 } });
  await context.addCookies([{ name: "clinic_session", value: token, url: BASE }]);
  const page = await context.newPage();
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("dialog", async (d) => { dialogs.push(d.message()); await d.accept(); });

  // clean chart: patient without brackets has no wire and no visible bracket shadow
  await page.goto(`${BASE}/patients/${emptyPatient}/orthodontics`);
  await page.locator(".ortho-arch-canvas").waitFor();
  assert.equal(await page.locator(".ortho-chart-wire").count(), 0, "no wire without brackets");
  const shadow = await page.locator(".ortho-bracket--empty").first().evaluate((e) => getComputedStyle(e).opacity);
  assert.equal(shadow, "0", "desktop: bracket shadow hidden");
  await page.locator(".ortho-chart-tooth").nth(3).hover();
  await page.waitForTimeout(250);
  const hovered = await page.locator(".ortho-chart-tooth").nth(3).locator(".ortho-bracket--empty").evaluate((e) => getComputedStyle(e).opacity);
  assert.equal(hovered, "0.35", "desktop: shadow on hover");
  ok("clean chart on desktop: no wire, no shadow, shadow appears on hover");

  const touch = await browser.newContext({ viewport: { width: 820, height: 1180 }, hasTouch: true, isMobile: true });
  await touch.addCookies([{ name: "clinic_session", value: token, url: BASE }]);
  const tab = await touch.newPage();
  await tab.goto(`${BASE}/patients/${emptyPatient}/orthodontics`);
  await tab.locator(".ortho-arch-canvas").waitFor();
  const faint = await tab.locator(".ortho-bracket--empty").first().evaluate((e) => getComputedStyle(e).opacity);
  assert.equal(faint, "0.16", "touch: faint shadow");
  await touch.close();
  ok("tablet/phone (touch): faint shadow always visible");

  // a visit with two O-tie colours and two power chains
  await page.goto(`${BASE}/patients/${patientId}/orthodontics`);
  const editor = page.locator("#ortho-visit-editor");
  await editor.waitFor();
  await editor.locator(".ortho-visit-field", { hasText: "Doctor" }).locator("select").selectOption(String(doctorId));
  await editor.locator(".ortho-visit-field", { hasText: "Visit Type" }).locator("select").selectOption("Consultation");
  await editor.locator(".ortho-visit-field", { hasText: "O-tie upper" }).locator("button").first().click();
  await editor.locator(".ortho-visit-field", { hasText: "O-tie upper" }).getByRole("button", { name: "Purple (ELC-014) 500", exact: true }).click();
  await editor.locator(".ortho-visit-field", { hasText: "O-tie lower" }).locator("button").first().click();
  await editor.locator(".ortho-visit-field", { hasText: "O-tie lower" }).getByRole("button", { name: "Pink (ELC-016) 500", exact: true }).click();
  await editor.locator(".ortho-visit-field", { hasText: "Power chain" }).locator(".ortho-pc-open").click();
  const picker = page.locator(".ortho-pc-sheet");
  await picker.waitFor();
  const tooth = (n) => picker.getByRole("button", { name: `Tooth ${n}`, exact: true });
  await tooth(13).click(); await tooth(23).click();
  await tooth(43).click(); await tooth(33).click();
  await picker.locator(".ortho-pc-chip").first().getByRole("button", { name: /On brackets/ }).click();
  assert.match(await picker.locator(".ortho-pc-chip").first().textContent(), /On hooks/);
  await page.screenshot({ path: "test-data/screenshots/150-picker.png" });
  await picker.getByRole("button", { name: "Done" }).click();
  assert.match(await editor.locator(".ortho-visit-field", { hasText: "Power chain" }).locator(".ortho-pc-open").textContent(), /13-23 on hooks \(6\).*43-33 \(6\)/);
  await editor.getByRole("button", { name: /Save Visit/ }).click();
  const visitRow = () => db.prepare("SELECT * FROM ortho_visits WHERE patient_id = ? ORDER BY id DESC").get(patientId);
  for (let n = 0; n < 50 && !visitRow(); n += 1) await page.waitForTimeout(200);
  const visit = visitRow();
  assert(visit, "visit saved");
  ok("visit saved with two O-tie colours and two chains (4 taps + 1 toggle)");

  const chains = JSON.parse(visit.power_chains);
  assert.equal(chains.length, 2);
  assert.deepEqual(chains.map((c) => [c.arch, c.qty, c.onHooks, c.deducted]), [["upper", 6, true, true], ["lower", 6, false, false]]);
  assert.equal(visit.power_chain_qty, 12);
  assert.equal(visit.otie_lower_item_id, pink);
  for (let n = 0; n < 40 && !dialogs.some((m) => /not deducted/.test(m)); n += 1) await page.waitForTimeout(200);
  assert(dialogs.some((m) => /not deducted/.test(m) && /Pink/.test(m)), "warning shown for the pink chain: " + dialogs.join(" | "));
  ok("pink chain saved but marked not deducted, with a warning (save not blocked)");

  // stock: upper 10 brackets on hooks -> 10 purple O-ties; lower 10 brackets, 6 under the chain -> 4 pink; purple chain 6
  assert.equal(before.purple - qty(purple), 10, "purple O-ties");
  assert.equal(before.pink - qty(pink), 4, "pink O-ties");
  assert.equal(before.chain - qty(purpleChain), 6, "purple chain");
  ok("stock: Purple O-tie 10, Pink O-tie 4, Purple chain 6, Pink chain 0");

  // the drawing on the chart
  await page.reload();
  const overlay = page.locator("svg.ortho-chart-appliances");
  await overlay.waitFor();
  assert.equal(await overlay.locator("rect").count(), 14, "O-tie rings on brackets only (not tubes), none under the lower chain on brackets");
  assert.equal(await overlay.locator("polyline").count(), 2, "2 chains drawn");
  const strokes = await overlay.locator("rect").evaluateAll((els) => [...new Set(els.map((e) => e.getAttribute("stroke")))]);
  assert.deepEqual(strokes.sort(), ["#7E22CE", "#EC4899"].sort());
  await page.locator(".ortho-arch-canvas").screenshot({ path: "test-data/screenshots/150-chart.png" });
  const table = await page.locator(".ortho-visits-table-scroll").textContent();
  assert.match(table, /not deducted/);
  ok("chart: rings in each arch colour (10 upper + 4 lower), 2 thin chains; visits table shows chains + not deducted");

  // delete the visit -> everything back
  await page.locator("#ortho-visit-editor").getByRole("button", { name: /Delete/ }).first().click();
  for (let n = 0; n < 50 && visitRow(); n += 1) await page.waitForTimeout(200);
  assert.equal(visitRow(), undefined, "visit deleted");
  assert.deepEqual({ purple: qty(purple), pink: qty(pink), chain: qty(purpleChain) }, before, "all stock refunded");
  ok("deleting the visit refunds O-ties (both colours) and the chain");

  assert.deepEqual(errors.filter((m) => !m.includes("Minified React error #418")), [], "page errors: " + errors.join(" | "));
  console.log(`\nALL ${results.length} CHECKS PASSED`);
} finally {
  await browser.close();
  db.close();
}
