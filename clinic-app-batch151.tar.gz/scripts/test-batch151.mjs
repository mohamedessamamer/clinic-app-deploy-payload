// Batch 151 browser integration test (local only, test DB only).
// Elastics with the box (auto right/left split, cross with a palatal end), 1 pack per size,
// the auto "Elastics:" line in Note + the medical file, a power chain to a miniscrew,
// the drawing on the chart, and full refund on delete.
//
// Run: CLINIC_DB_PATH=$PWD/test-data/clinic.db SESSION_SECRET=batch149-local-test-only-secret-at-least-32 npx next start -p 3149
//      then: node scripts/test-batch151.mjs
import assert from "node:assert/strict";
import path from "node:path";
import fs from "node:fs";
import Database from "better-sqlite3";
import { SignJWT } from "jose";
import { chromium } from "playwright";

const BASE = process.env.TEST_BASE_URL || "http://localhost:3149";
const SECRET = process.env.TEST_SESSION_SECRET || "batch149-local-test-only-secret-at-least-32";
const dbPath = path.resolve("test-data/clinic.db");
assert(dbPath.includes(path.sep + "test-data" + path.sep), "test DB only");
const db = new Database(dbPath);
db.pragma("busy_timeout = 5000");
const suffix = Date.now();
const adminId = Number(db.prepare("INSERT INTO users(username,password_hash,full_name,role,must_change_password) VALUES (?, 'unused', 'admin', 'admin', 0)").run(`admin151_${suffix}`).lastInsertRowid);
const doctorId = Number(db.prepare("INSERT INTO doctors(full_name, active) VALUES (?, 1)").run(`Dr Test ${suffix}`).lastInsertRowid);
db.prepare("INSERT OR REPLACE INTO clinic_settings(key, value) VALUES ('inventory_deductions_enabled', '1')").run();
const byName = (name) => db.prepare("SELECT id FROM inventory_items WHERE name = ?").get(name).id;
const e316 = byName("Elastic 3/16"), e18 = byName("Elastic 1/8"), e516 = byName("Elastic 5/16");
db.prepare("UPDATE inventory_items SET quantity = 50 WHERE id IN (?, ?, ?)").run(e316, e18, e516);
db.prepare("UPDATE inventory_items SET available_in_clinical_selection = 0 WHERE ortho_usage = 'otie' AND name LIKE 'O-tie — Purple (ELC-014) %'").run(); // leftovers of older test runs
const purple = Number(db.prepare("INSERT INTO inventory_items(name, quantity, ortho_usage, available_in_clinical_selection) VALUES (?, 500, 'otie', 1)").run(`O-tie — Purple (ELC-014) ${suffix}`).lastInsertRowid);
const purpleChain = Number(db.prepare("SELECT id FROM inventory_items WHERE name = 'Power chain — Purple (ELC-014)'").get()?.id ?? db.prepare("INSERT INTO inventory_items(name, quantity, ortho_usage, available_in_clinical_selection) VALUES ('Power chain — Purple (ELC-014)', 300, 'power_chain', 1)").run().lastInsertRowid);
const qty = (id) => db.prepare("SELECT quantity FROM inventory_items WHERE id = ?").get(id).quantity;
const ids = { e316, e18, e516, purple, purpleChain: Number(purpleChain) };
const before = Object.fromEntries(Object.entries(ids).map(([k, id]) => [k, qty(id)]));

const patientId = Number(db.prepare("INSERT INTO patients(file_number,full_name,phone,birth_date) VALUES (?,?,?,?)").run(`T151-${suffix}`, "Chart test 151", "01000000152", "2008-01-01").lastInsertRowid);
const st = {};
for (const q of [1, 2, 3, 4]) for (let i = 1; i <= 8; i++) st[q * 10 + i] = { bracket: i === 8 ? "none" : "bonded", debondDate: null, bondedDate: "2026-09-01", rebondCount: 0, extracted: false, comment: "" };
db.prepare("INSERT INTO orthodontic_charts(patient_id, tooth_states, miniscrews) VALUES (?, ?, ?)").run(patientId, JSON.stringify(st), JSON.stringify({ "14-13": true }));
// an earlier visit with purple O-ties (so "↺ Same" has something to copy)
const purpleName = `O-tie — Purple (ELC-014) ${suffix}`;
db.prepare("INSERT INTO ortho_visits(patient_id, visit_date, doctor_id, otie_item_id, otie_color) VALUES (?, '2026-10-01', ?, ?, ?)").run(patientId, doctorId, purple, purpleName);

const results = [];
const ok = (name) => { results.push(name); console.log("✓", name); };
const errors = [];
const dialogs = [];
const browser = await chromium.launch({ headless: true, ...(process.env.CHROME_PATH ? { executablePath: process.env.CHROME_PATH } : {}) });
fs.mkdirSync("test-data/screenshots", { recursive: true });
const token = await new SignJWT({ userId: adminId, username: "admin151", fullName: "admin", role: "admin", doctorId: null, sessionVersion: 0 })
  .setProtectedHeader({ alg: "HS256" }).setIssuedAt().setExpirationTime("1h").sign(new TextEncoder().encode(SECRET));
try {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1100 } });
  await context.addCookies([{ name: "clinic_session", value: token, url: BASE }]);
  const page = await context.newPage();
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("dialog", async (d) => { dialogs.push(d.message()); await d.accept(); });

  await page.goto(`${BASE}/patients/${patientId}/orthodontics`);
  const editor = page.locator("#ortho-visit-editor");
  await editor.waitFor();
  await editor.locator(".ortho-visit-field", { hasText: "Doctor" }).locator("select").selectOption(String(doctorId));
  await editor.locator(".ortho-visit-field", { hasText: "Visit Type" }).locator("select").selectOption("Consultation");
  // O-ties not changed this visit: "↺ Same" copies the last colours and deducts nothing
  await editor.locator(".ortho-otie-same").click();
  assert.equal(await editor.locator(".ortho-otie-same").getAttribute("aria-pressed"), "true");
  assert.match(await editor.locator(".ortho-visit-field", { hasText: "O-tie upper" }).textContent(), /Purple.*not deducted/);
  ok("O-tie ↺ Same: last colours copied, marked not deducted");

  // power chain from the miniscrew (between 14 and 13) to 11 -> 3 teeth + 1 ring = 4
  await editor.locator(".ortho-visit-field", { hasText: "Power chain" }).locator(".ortho-pc-open").click();
  let picker = page.locator(".ortho-pc-sheet");
  await picker.getByRole("button", { name: "Miniscrew 14/13", exact: true }).click();
  await picker.getByRole("button", { name: "Tooth 11", exact: true }).click();
  assert.match(await picker.locator(".ortho-pc-chip").first().textContent(), /MS 14\/13-11.*Qty 4/);
  // screw to screw is refused
  await picker.getByRole("button", { name: "Miniscrew 14/13", exact: true }).click();
  await picker.getByRole("button", { name: "Miniscrew 14/13", exact: true }).click();
  await picker.getByRole("button", { name: "Done" }).click();
  ok("power chain from a miniscrew: MS 14/13-11, Qty 4");

  // elastics: Class II both sides with 3/16 (no 'next' button needed), then a cross 5/16 with palatal 16
  await editor.locator(".ortho-visit-field", { hasText: "Elastics" }).locator(".ortho-pc-open").click();
  picker = page.locator(".ortho-pc-sheet", { hasText: "Elastics" });
  await picker.waitFor();
  const t = (n) => picker.getByRole("button", { name: `Tooth ${n}`, exact: true });
  await picker.locator(".ortho-pc-sizes").getByRole("button", { name: "3/16", exact: true }).click();
  await t(13).click(); await t(46).click();
  await t(23).click(); await t(36).click();
  assert.equal(await picker.locator(".ortho-pc-chip").count(), 2, "auto split right/left");
  await picker.locator(".ortho-pc-next").click();
  await picker.locator(".ortho-pc-sizes").getByRole("button", { name: "5/16", exact: true }).click();
  await t(16).click(); await t(16).click(); await t(46).click();
  // box elastic 1/8 around 4 teeth, tapped in a crossing order on purpose (14, 43, 13, 44)
  await picker.locator(".ortho-pc-next").click();
  await picker.locator(".ortho-pc-sizes").getByRole("button", { name: "1/8", exact: true }).click();
  await t(14).click(); await t(43).click(); await t(13).click(); await t(44).click();
  const auto = await picker.locator(".ortho-pc-auto").textContent();
  assert.match(auto, /Class II elastics right & left side \(3\/16\)/, auto);
  assert.match(auto, /Cross/i, auto);
  await page.screenshot({ path: "test-data/screenshots/151-elastics-picker.png" });
  await picker.getByRole("button", { name: "Done" }).click();
  const note = await editor.locator("textarea").first().inputValue();
  assert.match(note, /^Elastics: Class II elastics right & left side \(3\/16\)/m, note);
  ok("elastics picker: right/left split by itself, cross with palatal end, auto text in Note");

  await editor.getByRole("button", { name: /Save Visit/ }).click();
  const visitRow = () => db.prepare("SELECT * FROM ortho_visits WHERE patient_id = ? AND visit_date <> '2026-10-01' ORDER BY id DESC").get(patientId);
  for (let n = 0; n < 50 && !visitRow(); n += 1) await page.waitForTimeout(200);
  const visit = visitRow();
  assert(visit, "visit saved: " + dialogs.join(" | "));
  const elastics = JSON.parse(visit.elastics);
  assert.equal(elastics.length, 4);
  assert.equal(elastics[2].points[0].palatal, true);
  assert.equal(visit.elastics_size, "Elastic 3/16 + Elastic 5/16 + Elastic 1/8");
  assert.equal(visit.otie_same, 1);
  assert.equal(visit.otie_item_id, purple);
  const chains = JSON.parse(visit.power_chains);
  assert.equal(chains[0].qty, 4);
  const medical = db.prepare("SELECT notes FROM visits WHERE ortho_visit_id = ?").get(visit.id);
  assert.match(medical?.notes ?? "", /Elastics: Class II elastics right & left side/, "medical file paragraph");
  ok("saved: 4 elastics, sizes 3/16 + 5/16 + 1/8, chain qty 4, Elastics line in the medical file");

  assert.equal(before.e316 - qty(e316), 1, "3/16: one pack");
  assert.equal(before.e516 - qty(e516), 1, "5/16: one pack");
  assert.equal(before.e18 - qty(e18), 1, "1/8: one pack");
  assert.equal(before.purpleChain - qty(ids.purpleChain), 4, "chain 4");
  assert.equal(before.purple - qty(purple), 0, "O-tie Same: nothing deducted");
  ok("stock: 1 pack per size (3/16 ×1, 5/16 ×1, 1/8 ×1), chain 4 in the same purple, O-ties 0 (Same)");

  await page.reload();
  const overlay = page.locator("svg.ortho-chart-appliances");
  await overlay.waitFor();
  await page.waitForTimeout(300);
  assert.equal(await overlay.locator("g.ortho-chart-elastic").count(), 4, "4 elastics drawn");
  assert.equal(await overlay.locator("g.ortho-chart-elastic path:first-child").evaluateAll((els) => els.filter((e) => e.getAttribute("d").trim().endsWith("Z")).length), 4, "each elastic is a closed loop");
  assert.equal(await overlay.locator("polyline").count(), 1, "1 chain drawn");
  assert.equal(await overlay.locator('circle[fill="#fff"]').count(), 1, "palatal end = hollow circle");
  assert.equal(await overlay.locator("text", { hasText: "✕" }).count(), 1, "cross mark");
  const colours = await overlay.locator("g.ortho-chart-elastic path:first-child").evaluateAll((els) => els.map((e) => e.getAttribute("stroke")));
  assert.deepEqual(colours, ["#2563EB", "#2563EB", "#16A34A", "#DC2626"]);
  // the box must not cross itself: its 4 corners go round in order (no bow-tie)
  const box = await overlay.locator("g.ortho-chart-elastic path:first-child").nth(3).getAttribute("d");
  const corners = box.replace(/[MZ]/g, "").split("L").map((c) => c.trim().split(",").map(Number));
  const cross = (a, b, c, d) => { const o = (p, q, r) => Math.sign((q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0])); return o(a, b, c) !== o(a, b, d) && o(c, d, a) !== o(c, d, b); };
  assert.equal(corners.length, 4);
  assert(!cross(corners[0], corners[1], corners[2], corners[3]) && !cross(corners[1], corners[2], corners[3], corners[0]), "box elastic is a clean square, not a bow-tie: " + box);
  const tabsOnTop = await page.evaluate(() => {
    const tabs = document.querySelector(".ortho-chart-tabs");
    if (!tabs) return true;
    const r = tabs.getBoundingClientRect();
    const el = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
    return tabs.contains(el);
  });
  assert(tabsOnTop, "chart tabs stay clickable above the drawing");
  assert.match(await page.locator(".ortho-visits-table tbody tr").first().textContent(), /same · not deducted/);
  await page.locator(".ortho-arch-canvas").screenshot({ path: "test-data/screenshots/151-chart.png" });
  ok("chart: 4 closed elastic loops (box = square) (blue, blue, green), hollow palatal end, ✕ for cross, chain to the screw, tabs on top");

  await page.locator("#ortho-visit-editor").getByRole("button", { name: /Delete/ }).first().click();
  for (let n = 0; n < 50 && visitRow(); n += 1) await page.waitForTimeout(200);
  assert.equal(visitRow(), undefined, "visit deleted");
  assert.deepEqual(Object.fromEntries(Object.entries(ids).map(([k, id]) => [k, qty(id)])), before, "all stock refunded");
  ok("deleting the visit refunds elastics packs, O-ties and the chain");

  assert.deepEqual(errors.filter((m) => !m.includes("Minified React error #418")), [], "page errors: " + errors.join(" | "));
  console.log(`\nALL ${results.length} CHECKS PASSED`);
} finally {
  await browser.close();
  db.close();
}
