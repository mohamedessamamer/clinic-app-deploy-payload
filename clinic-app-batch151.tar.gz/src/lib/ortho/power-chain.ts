// دفعة 150 — أماكن الـ Power chain على الأسنان.
//
// قبل كده الزيارة كانت بتسجّل "عدد" بس. دلوقتي كل سلسلة = فك + من سنة لسنة
// (من 7 لـ 7) + على البراكتس ولا على الهوكس. العدد بيتحسب لوحده = عدد الأسنان
// في المدى، شاملة أي سنة مخلوعة جوه المدى (السلسلة بتعدّي عليها — قرار صاحب
// العيادة). ممكن أكتر من سلسلة في نفس الفك، وممكن سلسلتين على نفس السنة.
//
// ملف نقي من غير أي import لقاعدة البيانات أو React، عشان يتستخدم في السيرفر
// والواجهة والاختبارات بنفس المنطق بالظبط.

export type ChainArch = "upper" | "lower";

/** طرف السلسلة: رقم سنة، أو ميني سكرو بين سنتين (نفس id الفجوة في الشارت، زي "16-15"). */
export type ChainEnd = number | string;

export interface PowerChainInput {
  arch: ChainArch;
  from: ChainEnd;
  to: ChainEnd;
  onHooks: boolean;
}

export interface PowerChainSaved extends PowerChainInput {
  qty: number;
  /** صنف المخزن اللي اتخصم منه (null لو مفيش صنف بلون الـ O-tie ده). */
  itemId: number | null;
  /** false = اتحفظ بس متخصمش من المخزن (مفيش صنف للون ده). */
  deducted: boolean;
  color: string | null;
}

/** صفوف البوكس: من 7 لـ 7، بنفس ترتيب الشارت (يمين المريض على الشمال). */
export const UPPER_BOX = [17, 16, 15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 26, 27] as const;
export const LOWER_BOX = [47, 46, 45, 44, 43, 42, 41, 31, 32, 33, 34, 35, 36, 37] as const;

export const MAX_CHAINS_PER_VISIT = 6;

export function boxFor(arch: ChainArch): readonly number[] {
  return arch === "upper" ? UPPER_BOX : LOWER_BOX;
}

export function archOfTooth(fdi: number): ChainArch | null {
  if ((UPPER_BOX as readonly number[]).includes(fdi)) return "upper";
  if ((LOWER_BOX as readonly number[]).includes(fdi)) return "lower";
  return null;
}

// دفعة 151: الميني سكرو كطرف. السكرو بين سنتين = نص خطوة بينهم في ترتيب البوكس.
export function isScrew(end: ChainEnd): end is string {
  return typeof end === "string";
}

export function screwTeeth(gapId: string): [number, number] | null {
  const match = /^(\d{2})-(\d{2})$/.exec(gapId);
  return match ? [Number(match[1]), Number(match[2])] : null;
}

/** مكان الطرف في صف البوكس (السنة = رقم صحيح، السكرو = نص بين سنتين متجاورتين). */
export function endIndex(arch: ChainArch, end: ChainEnd): number {
  const box = boxFor(arch);
  if (!isScrew(end)) return box.indexOf(end);
  const pair = screwTeeth(end);
  if (!pair) return -1;
  const a = box.indexOf(pair[0]);
  const b = box.indexOf(pair[1]);
  if (a < 0 || b < 0 || Math.abs(a - b) !== 1) return -1;
  return Math.min(a, b) + 0.5;
}

/** الأسنان اللي السلسلة بتعدّي عليها بالترتيب، من غير ما يفرق مين الأول. */
export function chainTeeth(chain: Pick<PowerChainInput, "arch" | "from" | "to">): number[] {
  const box = boxFor(chain.arch);
  const a = endIndex(chain.arch, chain.from);
  const b = endIndex(chain.arch, chain.to);
  if (a < 0 || b < 0) return [];
  const [lo, hi] = a <= b ? [a, b] : [b, a];
  return box.filter((_, index) => index >= lo && index <= hi);
}

/** الأطراف بالترتيب للرسم: أسنان، والسكرو في أوله أو آخره. */
export function chainAnchors(chain: Pick<PowerChainInput, "arch" | "from" | "to">): ChainEnd[] {
  const a = endIndex(chain.arch, chain.from);
  const b = endIndex(chain.arch, chain.to);
  const teeth = chainTeeth(chain);
  const [first, last] = a <= b ? [chain.from, chain.to] : [chain.to, chain.from];
  return [...(isScrew(first) ? [first] : []), ...teeth, ...(isScrew(last) ? [last] : [])];
}

/** العدد = الأسنان + حلقة زيادة لكل سكرو (قرار صاحب العيادة). */
export function chainQty(chain: Pick<PowerChainInput, "arch" | "from" | "to">): number {
  return chainTeeth(chain).length + (isScrew(chain.from) ? 1 : 0) + (isScrew(chain.to) ? 1 : 0);
}

function endLabel(end: ChainEnd): string {
  if (!isScrew(end)) return String(end);
  const pair = screwTeeth(end);
  return pair ? `MS ${pair[0]}/${pair[1]}` : "MS";
}

export function chainLabel(chain: Pick<PowerChainInput, "arch" | "from" | "to" | "onHooks">): string {
  const a = endIndex(chain.arch, chain.from);
  const b = endIndex(chain.arch, chain.to);
  const [first, last] = a <= b ? [chain.from, chain.to] : [chain.to, chain.from];
  return `${endLabel(first)}-${endLabel(last)}${chain.onHooks ? " on hooks" : ""}`;
}

/**
 * بيراجع المدخلات اللي جاية من الواجهة: فك صحيح، والسنتين في نفس الفك، ومدى
 * فيه سنتين على الأقل. أي حاجة مش صح بترجع رسالة بدل ما تتحفظ ناقصة.
 */
export function normalizeChains(raw: unknown): { ok: true; chains: PowerChainInput[] } | { ok: false; reason: string } {
  if (raw == null) return { ok: true, chains: [] };
  if (!Array.isArray(raw)) return { ok: false, reason: "Power chain data is invalid." };
  if (raw.length > MAX_CHAINS_PER_VISIT) return { ok: false, reason: `At most ${MAX_CHAINS_PER_VISIT} power chains per visit.` };
  const chains: PowerChainInput[] = [];
  for (const item of raw) {
    if (typeof item !== "object" || item === null) return { ok: false, reason: "Power chain data is invalid." };
    const { arch, from, to, onHooks } = item as Record<string, unknown>;
    if (arch !== "upper" && arch !== "lower") return { ok: false, reason: "Power chain arch is invalid." };
    const toEnd = (value: unknown): ChainEnd | null => {
      if (typeof value === "string" && screwTeeth(value)) return value;
      const n = Number(value);
      return Number.isInteger(n) ? n : null;
    };
    const f = toEnd(from);
    const t = toEnd(to);
    if (f == null || t == null || endIndex(arch, f) < 0 || endIndex(arch, t) < 0) {
      return { ok: false, reason: "Power chain ends must be teeth or miniscrews in the same arch (7 to 7)." };
    }
    if (f === t) return { ok: false, reason: "A power chain needs two different ends." };
    if (isScrew(f) && isScrew(t)) return { ok: false, reason: "A power chain needs at least one tooth (not screw to screw)." };
    chains.push({ arch, from: f, to: t, onHooks: onHooks === true });
  }
  return { ok: true, chains };
}

/**
 * عدد الـ O-ties لكل فك = البراكتس المتركّبة (مش التيوبس) ناقص الأسنان اللي
 * عليها سلسلة "على البراكتس" (السلسلة نفسها بتربط البراكت). السلسلة على الهوكس
 * مابتشيلش الـ O-tie. السنة اللي عليها سلسلتين بتتطرح مرة واحدة بس.
 */
export function otieQtyForArch(arch: ChainArch, bondedBracketTeeth: number[], chains: PowerChainInput[]): number {
  const bonded = new Set(bondedBracketTeeth.filter((fdi) => (arch === "upper" ? fdi < 30 : fdi > 30)));
  const covered = new Set<number>();
  for (const chain of chains) {
    if (chain.arch !== arch || chain.onHooks) continue;
    for (const fdi of chainTeeth(chain)) if (bonded.has(fdi)) covered.add(fdi);
  }
  return bonded.size - covered.size;
}

/** بيقرا العمود power_chains من قاعدة البيانات من غير ما يقع لو النص بايظ. */
export function parseSavedChains(raw: string | null | undefined): PowerChainSaved[] {
  if (!raw) return [];
  try {
    const value = JSON.parse(raw);
    if (!Array.isArray(value)) return [];
    return value
      .filter((item) => item && (item.arch === "upper" || item.arch === "lower") && (Number.isInteger(item.from) || typeof item.from === "string") && (Number.isInteger(item.to) || typeof item.to === "string"))
      .map((item) => ({
        arch: item.arch,
        from: item.from,
        to: item.to,
        onHooks: item.onHooks === true,
        qty: Number.isFinite(item.qty) ? item.qty : chainQty(item),
        itemId: Number.isInteger(item.itemId) ? item.itemId : null,
        deducted: item.deducted !== false,
        color: typeof item.color === "string" ? item.color : null,
      }));
  } catch {
    return [];
  }
}
