// دفعة 151 — الأساتك بأماكنها والتسمية التلقائية.
//
// كل أستك = مسار نقط بالترتيب (سنة أو ميني سكرو)، فوق وتحت بأي عدد. كل نقطة
// برة (buccal) أو جوة (palatal/lingual). اللون حسب المقاس: 3/16 أزرق، 1/8 أحمر،
// 5/16 أخضر (قرار صاحب العيادة). التسمية بتتحسب لوحدها لكل جنب (يمين = 1x/4x،
// شمال = 2x/3x) بتعريفات صاحب العيادة نفسه.
// ملف نقي: نفس المنطق في الواجهة والسيرفر والاختبارات.

// نسخة صغيرة من screwTeeth (power-chain.ts) — الملف لازم يفضل من غير imports
// عشان اختبارات node --experimental-strip-types تشغّله مباشرة.
function screwTeeth(gapId: string): [number, number] | null {
  const match = /^(\d{2})-(\d{2})$/.exec(gapId);
  return match ? [Number(match[1]), Number(match[2])] : null;
}

export type ElasticPoint = { fdi: number; palatal: boolean } | { screw: string; palatal: boolean };

export interface ElasticInput {
  itemId: number | null;
  /** اسم صنف المخزن (فيه المقاس). */
  size: string;
  points: ElasticPoint[];
}

export const MAX_ELASTICS_PER_VISIT = 8;

const SIZE_COLORS: Record<string, string> = { "3/16": "#2563EB", "1/8": "#DC2626", "5/16": "#16A34A" };
const EXTRA_COLORS = ["#9333EA", "#EA580C", "#0891B2", "#4D7C0F", "#BE185D"];

/** "Elastic 3/16" → "3/16". */
export function sizeLabel(name: string): string {
  const match = /(\d+\s*\/\s*\d+)/.exec(name);
  return match ? match[1].replace(/\s+/g, "") : name.replace(/^elastics?\s*/i, "").trim() || name;
}

export function colorForSize(name: string): string {
  const label = sizeLabel(name);
  if (SIZE_COLORS[label]) return SIZE_COLORS[label];
  let hash = 0;
  for (const char of label) hash = (hash * 31 + char.charCodeAt(0)) >>> 0;
  return EXTRA_COLORS[hash % EXTRA_COLORS.length];
}

const UPPER = new Set([17, 16, 15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 26, 27]);
const LOWER = new Set([47, 46, 45, 44, 43, 42, 41, 31, 32, 33, 34, 35, 36, 37]);

export function pointTooth(point: ElasticPoint): number | null {
  return "fdi" in point ? point.fdi : null;
}

/** الفك والجنب بتوع النقطة. السكرو بياخدهم من السنتين اللي هو بينهم. */
export function pointArch(point: ElasticPoint): "upper" | "lower" | null {
  const fdi = "fdi" in point ? point.fdi : screwTeeth(point.screw)?.[0] ?? null;
  if (fdi == null) return null;
  return fdi < 30 ? "upper" : "lower";
}

export function pointSide(point: ElasticPoint): "right" | "left" | null {
  const fdi = "fdi" in point ? point.fdi : screwTeeth(point.screw)?.[0] ?? null;
  if (fdi == null) return null;
  const quadrant = Math.floor(fdi / 10);
  return quadrant === 1 || quadrant === 4 ? "right" : "left";
}

export function samePoint(a: ElasticPoint, b: ElasticPoint): boolean {
  return "fdi" in a && "fdi" in b ? a.fdi === b.fdi : "screw" in a && "screw" in b ? a.screw === b.screw : false;
}

/**
 * التقسيم التلقائي يمين/شمال: الأستك اللي فيه نقطة فوق ونقطة تحت وكله في جنب
 * واحد بيخلص لوحده لما تدوس على الجنب التاني. والـ Diagonal (13→33) بيكمّل
 * عادي لأنه بيعدّي الجنب قبل ما يبقى فيه الفكين.
 */
export function shouldStartNewElastic(current: ElasticPoint[], next: ElasticPoint): boolean {
  if (current.length < 2) return false;
  const arches = new Set(current.map(pointArch));
  const sides = new Set(current.map(pointSide));
  return arches.has("upper") && arches.has("lower") && sides.size === 1 && !sides.has(pointSide(next));
}

export function normalizeElastics(raw: unknown): { ok: true; elastics: ElasticInput[] } | { ok: false; reason: string } {
  if (raw == null) return { ok: true, elastics: [] };
  if (!Array.isArray(raw)) return { ok: false, reason: "Elastics data is invalid." };
  if (raw.length > MAX_ELASTICS_PER_VISIT) return { ok: false, reason: `At most ${MAX_ELASTICS_PER_VISIT} elastics per visit.` };
  const elastics: ElasticInput[] = [];
  for (const item of raw) {
    if (typeof item !== "object" || item === null) return { ok: false, reason: "Elastics data is invalid." };
    const { itemId, size, points } = item as Record<string, unknown>;
    if (!Array.isArray(points) || points.length < 2 || points.length > 8) return { ok: false, reason: "Each elastic needs 2 to 8 points." };
    const clean: ElasticPoint[] = [];
    for (const point of points) {
      const p = point as Record<string, unknown>;
      const palatal = p?.palatal === true;
      if (typeof p?.screw === "string" && screwTeeth(p.screw)) clean.push({ screw: p.screw, palatal });
      else if (Number.isInteger(p?.fdi) && (UPPER.has(p.fdi as number) || LOWER.has(p.fdi as number))) clean.push({ fdi: p.fdi as number, palatal });
      else return { ok: false, reason: "Elastic points must be teeth 7 to 7 or miniscrews." };
    }
    if (!clean.some((point) => "fdi" in point)) return { ok: false, reason: "An elastic needs at least one tooth." };
    elastics.push({ itemId: Number.isInteger(itemId) ? (itemId as number) : null, size: typeof size === "string" ? size : "", points: clean });
  }
  return { ok: true, elastics };
}

export function parseSavedElastics(raw: string | null | undefined): (ElasticInput & { kind?: string })[] {
  if (!raw) return [];
  try {
    const parsed = normalizeElastics(JSON.parse(raw));
    return parsed.ok ? parsed.elastics : [];
  } catch {
    return [];
  }
}

const position = (fdi: number) => fdi % 10;

function setEq(values: number[], expected: number[]): boolean {
  const a = [...new Set(values)].sort();
  const b = [...expected].sort();
  return a.length === b.length && a.every((value, index) => value === b[index]);
}

/** نوع الأستك الواحد (من غير الجنب). */
export function classifyElastic(points: ElasticPoint[]): { kind: string; side: "right" | "left" | "both" } {
  const sides = new Set(points.map(pointSide));
  const side = sides.size === 1 ? ([...sides][0] ?? "right") : "both";
  const arches = new Set(points.map(pointArch));
  const interArch = arches.has("upper") && arches.has("lower");
  if (points.some((point) => point.palatal) && interArch) return { kind: "Cross", side };
  const teeth = points.map(pointTooth).filter((fdi): fdi is number => fdi != null);
  const up = teeth.filter((fdi) => fdi < 30).map(position);
  const low = teeth.filter((fdi) => fdi > 30).map(position);
  if (side === "both") {
    if (teeth.length === 2 && up.length === 1 && low.length === 1 && up[0] === 3 && low[0] === 3) return { kind: "Diagonal", side };
    return { kind: "Custom", side };
  }
  if (!interArch) return { kind: "Custom", side };
  const hasScrew = points.some((point) => "screw" in point);
  if (!hasScrew) {
    if (setEq(up, [3, 4]) && setEq(low, [3, 4])) return { kind: "Settling", side };
    if (setEq(up, [3, 4]) && (setEq(low, [4, 5]) || setEq(low, [5, 6]))) return { kind: "Settling Class II component", side };
    if (setEq(low, [3, 4]) && (setEq(up, [4, 5]) || setEq(up, [5, 6]))) return { kind: "Settling Class III component", side };
    if (setEq(up, [3]) && (setEq(low, [6]) || setEq(low, [7]))) return { kind: "Class II", side };
    if (setEq(low, [3]) && (setEq(up, [6]) || setEq(up, [7]))) return { kind: "Class III", side };
  }
  return { kind: "Custom", side };
}

function pointText(point: ElasticPoint): string {
  if ("fdi" in point) return `${point.fdi}${point.palatal ? "p" : ""}`;
  const pair = screwTeeth(point.screw);
  return pair ? `MS${pair[0]}/${pair[1]}` : "MS";
}

/**
 * السطر اللي بيتكتب لوحده في Note (ومنه للملف الطبي).
 * نفس النوع والمقاس في الجنبين ← "Class II elastics right & left side (3/16)".
 * غير كده ← "Class II right & settling left (3/16)".
 */
export function describeElastics(elastics: ElasticInput[]): string {
  if (elastics.length === 0) return "";
  const items = elastics.map((elastic) => {
    const { kind, side } = classifyElastic(elastic.points);
    const label = kind === "Custom" || kind === "Cross" ? `${kind === "Cross" ? "Cross elastic" : "Elastic"} ${elastic.points.map(pointText).join("-")}` : kind;
    return { kind, side, label, size: sizeLabel(elastic.size) };
  });
  const sizes = [...new Set(items.map((item) => item.size).filter(Boolean))];
  const oneSize = sizes.length <= 1;
  const sizeSuffix = (size: string) => (size ? ` (${size})` : "");
  // نفس النوع والمقاس يمين وشمال ← سطر واحد "right & left side"، حتى لو فيه أساتك تانية معاهم.
  const used = new Set<number>();
  const parts: string[] = [];
  items.forEach((item, index) => {
    if (used.has(index) || item.kind === "Custom" || item.kind === "Cross" || item.kind === "Diagonal" || item.side === "both") return;
    const mate = items.findIndex((other, j) => j !== index && !used.has(j) && other.kind === item.kind && other.size === item.size && other.side !== "both" && other.side !== item.side);
    if (mate < 0) return;
    used.add(index);
    used.add(mate);
    parts.push(`${item.kind} elastics right & left side${oneSize ? "" : sizeSuffix(item.size)}`);
  });
  const order = (item: (typeof items)[number]) => (item.side === "right" ? 0 : item.side === "left" ? 1 : 2);
  items
    .map((item, index) => ({ item, index }))
    .filter(({ index }) => !used.has(index))
    .sort((a, b) => order(a.item) - order(b.item))
    .forEach(({ item }) => {
      const where = item.kind === "Custom" || item.kind === "Cross" || item.kind === "Diagonal" || item.side === "both" ? "" : ` ${item.side}`;
      parts.push(`${item.label}${where}${oneSize ? "" : sizeSuffix(item.size)}`);
    });
  const text = parts.map((part, index) => (index === 0 ? part : part.charAt(0).toLowerCase() + part.slice(1))).join(" & ");
  return `${text}${oneSize ? sizeSuffix(sizes[0] ?? "") : ""}`;
}

/** بيحط/يبدّل سطر "Elastics: ..." في الـ Note من غير ما يلمس باقي الكلام. */
export function upsertElasticsLine(note: string, text: string): string {
  const lines = (note ?? "").split("\n").filter((line) => !/^Elastics:/i.test(line.trim()));
  if (text) lines.push(`Elastics: ${text}`);
  return lines.filter((line, index, all) => line.trim() !== "" || (index > 0 && index < all.length - 1)).join("\n").trim();
}
