import type { ColumnType, Generated } from "kysely";

export interface DoctorsTable {
  id: Generated<number>;
  full_name: string;
  active: Generated<number>;
  // دفعة 22: هل الدكتور ده "استشاري" (عنده دكاترة مساعدين معرفين تحته، جدول
  // consultant_assistants تحت) — 0/1.
  is_consultant: Generated<number>;
  created_at: Generated<string>;
}

// ربط استشاري بدكاترة مساعدين (many-to-many، دفعة 22) — استشاري واحد ممكن
// يكون عنده أكتر من مساعد، ومساعد نظريًا ممكن يشتغل تحت أكتر من استشاري.
export interface ConsultantAssistantsTable {
  consultant_doctor_id: number;
  assistant_doctor_id: number;
}

export interface UsersTable {
  id: Generated<number>;
  username: string;
  password_hash: string;
  full_name: string;
  role: "admin" | "doctor" | "reception" | "accountant" | "clinic_manager";
  doctor_id: number | null;
  active: Generated<number>;
  medical_ui_language: Generated<"en" | "ar">;
  color_theme: Generated<"revere" | "medical">;
  contact_name: string | null;
  // 1 = الحساب لسه على كلمة السر الافتراضية "123" ولازم يغيّرها. بيتحدّث وقت
  // الدخول نفسه (شوف src/app/login/actions.ts) فبيصحّح نفسه تلقائيًا لأي حساب
  // اتغيّرت كلمة سره قبل كده من غير ما نحتاج نخمّن حالته وقت الترحيل.
  must_change_password: Generated<number>;
  session_version: Generated<number>;
  created_at: Generated<string>;
}

export interface LoginAttemptsTable {
  id: Generated<number>;
  username: string;
  succeeded: Generated<number>;
  attempted_at: Generated<string>;
}

export interface RoomsTable {
  id: Generated<number>;
  name: string;
  created_at: Generated<string>;
}

export interface ShiftsTable {
  id: Generated<number>;
  room_id: number;
  doctor_id: number;
  shift_date: string;
  start_time: string;
  end_time: string;
  created_at: Generated<string>;
}

export interface DoctorWeeklyShiftsTable {
  id: Generated<number>;
  room_id: number;
  weekday: number;
  doctor_id: number;
  start_time: string;
  end_time: string;
  created_at: Generated<string>;
}

export interface DoctorDateShiftsTable {
  id: Generated<number>;
  room_id: number;
  doctor_id: number;
  shift_date: string;
  created_by: number | null;
  created_at: Generated<string>;
}

export interface ServicesTable {
  id: Generated<number>;
  name: string;
  name_en: string | null;
  category: string | null;
  default_price: Generated<number>;
  code: string | null;
  price_note: string | null;
  prepaid: Generated<number>;
  has_lab_cost: Generated<number>;
  lab_cost: Generated<number>;
  /** دفعة 142: 1 = الخدمة دي معناها إن التقويم خلص (مثبت، فك تقويم). */
  ends_ortho: Generated<number>;
  /** دفعة 134: 0 = متوقفة — بتختفي من قوايم الاختيار وبتفضل للسجلات القديمة. */
  active: Generated<number>;
  created_at: Generated<string>;
}

export interface ServiceDoctorsTable {
  service_id: number;
  doctor_id: number;
}

export interface PatientsTable {
  id: Generated<number>;
  file_number: string;
  full_name: string;
  age: number | null; // قديم — للمرضى اللي اتسجلوا قبل ما نبدأ نطلب تاريخ الميلاد.
  birth_date: string | null; // YYYY-MM-DD — المصدر الحالي لحساب السن، شوف src/lib/age.ts.
  phone_country_code: Generated<string>;
  phone: string | null;
  address: string | null;
  archived_at: string | null;
  archived_by: number | null;
  archive_reason: "manual" | "inactive" | null;
  archive_activity_at: string | null;
  created_at: Generated<string>;
  // Batch 124: صورة الملف (thumbnail) المقصوصة من أول صورة وش مرفوعة.
  avatar_path: string | null;
  // الصورة الأصلية اللي اتقصت منها صورة الملف.
  avatar_image_id: number | null;
}

export interface AppointmentsTable {
  id: Generated<number>;
  patient_id: number;
  room_id: number;
  doctor_id: number;
  appointment_date: string;
  start_time: string;
  duration_minutes: number | null;
  status: Generated<"booked" | "attended" | "done" | "cancelled" | "no_show">;
  attended_at: string | null;
  // بداية انتظار الاستقبال المعتمدة. لا تتغير عند دخول المريض للعيادة أو رجوعه منها.
  reception_wait_started_at: string | null;
  entered_room_id: number | null;
  entered_at: string | null;
  // Batch 123: خرج من العيادة لخانة الاستقبال وينتظر «تم».
  left_clinic_at: string | null;
  // Batch 123: قضى 3 دقائق داخل العيادة؛ «لم يحضر» والإلغاء ممنوعين بعده.
  clinic_confirmed_at: string | null;
  completed_at: string | null;
  confirmed_at: string | null;
  reschedule_pending: Generated<number>;
  notes: string | null;
  pending_service_id: number | null;
  pending_price: number | null;
  pending_discount_percent: number | null;
  completed_without_payment: Generated<number>;
  debt_on_completion: number | null;
  // "المريض جاي يعمل إيه" — دفعة 26. شوف التعليق فوق tryAddColumn في client.ts.
  purpose_type: "bonding_upper" | "bonding_lower" | "service" | null;
  purpose_service_id: number | null;
  // دفعة 27 (P3.2): ربط بفاتورة مفتوحة فعلية — شوف التعليق فوق tryAddColumn.
  purpose_linked_invoice_id: number | null;
  created_at: Generated<string>;
}

export interface PatientReferralsTable {
  id: Generated<number>;
  patient_id: number;
  appointment_id: number | null;
  from_doctor_id: number;
  to_doctor_id: number;
  request_text: string;
  status: Generated<"pending" | "completed">;
  created_by: number;
  created_at: Generated<string>;
  completed_by: number | null;
  completed_at: string | null;
}

export interface TasksTable {
  id: Generated<number>;
  patient_id: number | null;
  created_by: number;
  recipient_type: "user" | "reception";
  recipient_user_id: number | null;
  task_text: string;
  source_type: Generated<"manual" | "referral">;
  referral_id: number | null;
  status: Generated<"open" | "completed" | "closed">;
  completed_by: number | null;
  completed_at: string | null;
  closed_by: number | null;
  closed_at: string | null;
  created_at: Generated<string>;
  updated_at: Generated<string>;
}

export interface AppointmentRemindersTable {
  id: Generated<number>;
  appointment_id: number;
  patient_id: number;
  token_hash: string;
  delivery_method: Generated<"automatic" | "manual">;
  appointment_date: string;
  sent_at: string | null;
  expires_at: string;
  response_status: Generated<"pending" | "confirmed" | "reschedule_pending" | "reschedule_approved" | "send_failed">;
  responded_at: string | null;
  requested_date: string | null;
  requested_time: string | null;
  requested_room_id: number | null;
  approved_by: number | null;
  approved_at: string | null;
  send_attempts: Generated<number>;
  last_attempt_at: string | null;
  error_message: string | null;
  created_at: Generated<string>;
  updated_at: Generated<string>;
}

export interface VisitsTable {
  id: Generated<number>;
  patient_id: number;
  visit_date: ColumnType<string, string | undefined, string>;
  service_id: number | null;
  notes: string | null;
  primary_doctor_id: number | null;
  performing_doctor_id: number | null;
  room_id: number | null;
  created_by: number | null;
  appointment_id: number | null;
  ortho_visit_id: number | null;
  created_at: Generated<string>;
  notes_synced_from_ortho: Generated<number>;
}

export interface InvoicesTable {
  id: Generated<number>;
  visit_id: number | null;
  patient_id: Generated<number | null>;
  doctor_id: Generated<number | null>;
  appointment_id: Generated<number | null>;
  service_id: Generated<number | null>;
  invoice_date: Generated<string>;
  amount: Generated<number>;
  paid: Generated<number>;
  discount_percent: Generated<number>;
  price_overridden: Generated<number>;
  payment_method: string | null;
  parent_invoice_id: number | null;
  original_price: number | null;
  created_at: Generated<string>;
  /** دفعة 145: مجموع تسويات المديونية الفعّالة على الفاتورة (بدون تحصيل). الباقي = amount - paid - متابعات - settled_amount. */
  settled_amount: Generated<number>;
}

export interface CollectionRequestsTable {
  id: Generated<number>;
  appointment_id: number;
  patient_id: number;
  doctor_id: number;
  service_id: number | null;
  requested_amount: number | null;
  status: Generated<"pending" | "settled" | "cancelled">;
  requested_by: number;
  requested_at: Generated<string>;
  settled_by: number | null;
  settled_at: string | null;
  cancelled_by: number | null;
  cancelled_at: string | null;
}

export interface PatientCreditsTable {
  id: Generated<number>;
  patient_id: number;
  appointment_id: number | null;
  original_amount: number;
  available_amount: number;
  payment_method: string | null;
  received_by: number;
  received_at: Generated<string>;
  note: string | null;
  status: Generated<"active" | "used" | "refunded">;
}

export interface ClinicSettingsTable {
  key: string;
  value: string;
}

export interface NotificationCasesTable {
  id: Generated<number>;
  rule_key: string;
  patient_id: number;
  doctor_id: number | null;
  last_visit_date: string | null;
  status: Generated<"open" | "snoozed" | "resolved">;
  last_stage_days: Generated<number>;
  last_notified_at: string | null;
  reason: string | null;
  next_review_date: string | null;
  resolved_by: number | null;
  resolved_at: string | null;
  updated_at: Generated<string>;
  created_at: Generated<string>;
}

export interface NotificationsTable {
  id: Generated<number>;
  recipient_user_id: number;
  type: string;
  title: string;
  body: string;
  patient_id: number | null;
  notification_case_id: number | null;
  dedupe_key: string;
  read_at: string | null;
  expires_at: string;
  created_at: Generated<string>;
}

export interface ChatMessagesTable {
  id: Generated<number>;
  sender_user_id: number;
  recipient_user_id: number | null;
  audience: "reception" | "doctor" | "all_doctors";
  body: string;
  created_at: Generated<string>;
}

export interface ChatReadStatesTable {
  user_id: number;
  last_read_message_id: number;
  updated_at: Generated<string>;
}

export interface AuditLogTable {
  id: Generated<number>;
  entity_type: string;
  entity_id: number;
  field: string;
  old_value: string | null;
  new_value: string | null;
  reason: string | null;
  changed_by: number | null;
  changed_at: Generated<string>;
  // تاريخ الحدث الفعلي (زي تاريخ زيارة اتسجلت بأثر رجعي) لو مختلف عن changed_at
  // (وقت الحفظ الفعلي). اختياري — NULL يعني ارجع لـchanged_at.
  event_date: string | null;
}

export interface PatientImageGroupsTable {
  id: Generated<number>;
  patient_id: number;
  label: string | null;
  taken_at: Generated<string>;
  created_at: Generated<string>;
}

export interface PatientImagesTable {
  id: Generated<number>;
  group_id: number;
  file_path: string;
  rotation: Generated<number>;
  // Batch 124: التعرف التلقائي على نوع الصورة + خانة التمبلت بعد المراجعة.
  image_kind: string | null;
  image_confidence: number | null;
  template_slot: string | null;
  // Batch 127: كشف التكرار وقت الرفع.
  content_hash: string | null;
  original_name: string | null;
  file_size: number | null;
  // Batch 130: 1 لو النوع اتحط بالتعلم المحافظ من تصحيحات سابقة (مش تصنيف
  // السيستم العادي) — راجع src/lib/images/learned-overrides.ts.
  image_kind_learned: Generated<number>;
  created_at: Generated<string>;
}

/** Batch 127: سجل تصحيحات التصنيف اليدوية — الأساس لأي تظبيط مستقبلي للعتبات. */
export interface PatientImageCorrectionsTable {
  id: Generated<number>;
  image_id: number;
  patient_id: number;
  old_kind: string | null;
  old_confidence: number | null;
  new_kind: string;
  features_json: string | null;
  corrected_by: number | null;
  corrected_at: Generated<string>;
}

export interface InventoryItemsTable {
  id: Generated<number>;
  name: string;
  quantity: Generated<number>;
  unit: string | null;
  expiry_date: string | null;
  low_stock_threshold: Generated<number>;
  product_id: number | null;
  supplier_id: number | null;
  attribute_value_ids: string | null;
  item_code: string | null;
  ortho_usage: string | null;
  reorder_quantity: Generated<number>;
  critical_stock_threshold: Generated<number>;
  specialty_id: number | null;
  category_id: number | null;
  catalog_group: string | null;
  auto_deduction_key: string | null;
  auto_deduction_per_attachment: Generated<number>;
  available_in_clinical_selection: Generated<number>;
  active: Generated<number>;
  is_general_consumable: Generated<number>;
  created_at: Generated<string>;
}

export interface ExpenseTemplatesTable {
  id: Generated<number>;
  title: string;
  category: string;
  payee: string | null;
  default_amount: number;
  note: string | null;
  active: Generated<number>;
  effective_from: Generated<string | null>;
  effective_to: Generated<string | null>;
  created_by: number | null;
  created_at: Generated<string>;
}

export interface ExpensesTable {
  id: Generated<number>;
  expense_date: string;
  category: string;
  title: string;
  payee: string | null;
  amount: number;
  payment_method: string | null;
  note: string | null;
  source_type: string;
  source_id: number | null;
  template_id: number | null;
  doctor_id: Generated<number | null>;
  patient_id: Generated<number | null>;
  service_id: Generated<number | null>;
  affects_commission: Generated<number>;
  // يُستثنى من وعاء «صافي النقدية» — لسداد النسب نفسه فقط، منعًا للدائرية.
  excluded_from_commission_base: Generated<number>;
  created_by: number | null;
  created_at: Generated<string>;
}

export interface DoctorCompensationRulesTable {
  id: Generated<number>;
  doctor_id: number;
  compensation_type: "fixed" | "percentage" | "mixed";
  fixed_amount: Generated<number>;
  percentage: Generated<number>;
  effective_from: string;
  active: Generated<number>;
  created_by: number | null;
  updated_at: Generated<string>;
}

export interface DoctorPayrollRunsTable {
  id: Generated<number>;
  doctor_id: number;
  period_month: string;
  fixed_amount: number;
  percentage: number;
  collected_amount: number;
  percentage_amount: number;
  total_amount: number;
  status: "draft" | "paid";
  paid_date: string | null;
  expense_id: number | null;
  created_by: number | null;
  paid_by: number | null;
  created_at: Generated<string>;
}

export interface HrCompensationRulesTable {
  id: Generated<number>;
  person_type: "doctor" | "staff";
  person_id: number;
  staff_group: "doctor" | "employee" | "nursing";
  compensation_type: "fixed" | "percentage" | "mixed";
  fixed_basis: "monthly" | "shift";
  fixed_amount: Generated<number>;
  percentage_basis: "personal" | "clinic" | "clinic_net_cash";
  percentage_mode: "fixed" | "progressive";
  percentage: Generated<number>;
  // أيام الأسبوع مفصولة بفاصلة بترقيم weekdayOf (0=الأحد .. 6=السبت)، مثل "0,1".
  shift_weekdays: string | null;
  effective_from: string;
  effective_to: string | null;
  active: Generated<number>;
  created_by: number | null;
  updated_at: Generated<string>;
}

export interface HrPeriodSettlementsTable {
  id: Generated<number>;
  kind: "salary" | "commission";
  period_from: string;
  period_to: string;
  amount: number;
  // تاريخ السداد الفعلي (للتوثيق). القيد المحاسبي للمصروف المقابل بيبقى على
  // آخر يوم في الشهر المستحق، وممكن يكون شهر مختلف تمامًا.
  paid_date: string;
  payment_method: Generated<string>;
  expense_id: number | null;
  created_by: number | null;
  created_at: Generated<string>;
}

export interface HrPayrollRunsTable {
  id: Generated<number>;
  person_type: "doctor" | "staff";
  person_id: number;
  person_name: string;
  staff_group: "doctor" | "employee" | "nursing";
  period_from: string;
  period_to: string;
  shift_count: Generated<number>;
  // NULL = اتبع العدد المحسوب من أيام الشيفت؛ أي رقم = تعديل يدوي مقصود.
  shift_count_override: number | null;
  fixed_amount: Generated<number>;
  percentage_basis: string;
  percentage_mode: string;
  percentage: Generated<number>;
  gross_collected: Generated<number>;
  lab_cost: Generated<number>;
  net_collected: Generated<number>;
  percentage_amount: Generated<number>;
  incentives: Generated<number>;
  deductions: Generated<number>;
  total_amount: Generated<number>;
  status: "draft" | "paid";
  paid_date: string | null;
  expense_id: number | null;
  created_by: number | null;
  paid_by: number | null;
  created_at: Generated<string>;
}

export interface HrStaffTable {
  id: Generated<number>;
  full_name: string;
  staff_group: "employee" | "nursing";
  linked_user_id: number | null;
  employment_start: string;
  employment_end: string | null;
  notes: string | null;
  active: Generated<number>;
  created_by: number | null;
  created_at: Generated<string>;
  updated_at: Generated<string>;
}

export interface HrDocumentsTable {
  id: Generated<number>;
  person_type: "doctor" | "staff";
  person_id: number;
  document_type: string;
  label: string | null;
  file_path: string;
  original_name: string;
  uploaded_by: number | null;
  created_at: Generated<string>;
}

export interface InventorySupplyBatchesTable {
  id: Generated<number>;
  item_id: number;
  supplier_id: number | null;
  brand: string | null;
  quantity_received: number;
  quantity_remaining: number;
  purchase_unit_label: string | null;
  package_count: number | null;
  units_per_package: number | null;
  total_cost: number | null;
  received_at: Generated<string>;
  note: string | null;
  created_by: number | null;
  created_at: Generated<string>;
}

export interface InventoryStockMovementsTable {
  id: Generated<number>;
  item_id: number;
  batch_id: number | null;
  appointment_id: number | null;
  movement_type: "supply" | "count_adjustment" | "ortho_use" | "general_consumption" | "return";
  quantity: number;
  note: string | null;
  created_by: number | null;
  created_at: Generated<string>;
}

export interface InventoryConsumableRulesTable {
  item_id: number;
  quantity_per_completed_appointment: number;
  active: Generated<number>;
  updated_at: Generated<string>;
}

export interface InventorySpecialtiesTable {
  id: Generated<number>;
  name: string;
  parent_id: number | null;
  active: Generated<number>;
  created_at: Generated<string>;
}

export interface InventoryCategoriesTable {
  id: Generated<number>;
  specialty_id: number;
  name: string;
  active: Generated<number>;
  created_at: Generated<string>;
}

export interface InventoryProductsTable {
  id: Generated<number>;
  category_id: number;
  name: string;
  active: Generated<number>;
  created_at: Generated<string>;
}

export interface InventoryAttributeGroupsTable {
  id: Generated<number>;
  product_id: number;
  name: string;
  sort_order: Generated<number>;
}

export interface InventoryAttributeValuesTable {
  id: Generated<number>;
  attribute_group_id: number;
  value: string;
  sort_order: Generated<number>;
  active: Generated<number>;
}

export interface InventoryUnitsTable {
  id: Generated<number>;
  name: string;
  short_name: string;
  active: Generated<number>;
}

export interface InventorySuppliersTable {
  id: Generated<number>;
  name: string;
  phone_country_code: Generated<string>;
  phone: string | null;
  notes: string | null;
  active: Generated<number>;
  created_at: Generated<string>;
  is_ortho: Generated<number>;
  is_general: Generated<number>;
}

export interface SupplierInvoicesTable {
  id: Generated<number>;
  supplier_id: number;
  invoice_number: string | null;
  amount: number;
  invoice_date: Generated<string>;
  created_by: number | null;
  created_at: Generated<string>;
  // NULL = خُد تخصص المورد نفسه (مورد بتخصص واحد بس). لازم قيمة صريحة فقط
  // لو المورد شغال في تقويم وجينيرال مع بعض (batch 107).
  specialty: 'ortho' | 'general' | null;
}

export interface SupplierPaymentsTable {
  id: Generated<number>;
  supplier_id: number;
  invoice_id: number | null;
  amount: number;
  payment_date: Generated<string>;
  created_by: number | null;
  created_at: Generated<string>;
  notes: string | null;
}

export interface InventoryPurchaseDraftsTable {
  id: Generated<number>;
  supplier_id: number;
  status: Generated<'open' | 'sent' | 'closed'>;
  created_at: Generated<string>;
  updated_at: Generated<string>;
}

export interface InventoryPurchaseDraftItemsTable {
  id: Generated<number>;
  draft_id: number;
  item_id: number;
  suggested_quantity: number;
  created_at: Generated<string>;
}

export interface InventoryStockAlertsTable {
  item_id: number;
  level: 'low' | 'critical';
  cycle: Generated<number>;
  resolved_at: string | null;
  updated_at: Generated<string>;
}

export interface UserPermissionsTable {
  user_id: number;
  permission_key: string;
  granted: number;
}

// شارت تشخيص وخطة علاج التقويم — سجل واحد بس لكل مريض (patient_id UNIQUE).
// شوف التعليق فوق CREATE TABLE في schema.sql للتفاصيل.
export interface OrthodonticChartsTable {
  id: Generated<number>;
  patient_id: number;
  sex: "male" | "female" | null;
  chief_complaint: string | null;
  diagnosis_summary: string | null;
  past_medical_history: string | null;
  missing_teeth: string | null; // JSON array نصي
  antero_posterior: "class1" | "class2" | "class3" | null;
  facial_height: "increased" | "average" | "decreased" | null;
  mx_incisor_inclination: "proclined" | "average" | "retroclined" | null;
  mn_incisor_inclination: "proclined" | "average" | "retroclined" | null;
  molar_relation_right: "class1" | "class2" | "class3" | null;
  molar_relation_left: "class1" | "class2" | "class3" | null;
  overbite: "open_bite" | "average" | "deep_bite" | null;
  overjet: "increased" | "average" | "decreased" | null;
  midline_upper_direction: "right" | "left" | null;
  midline_upper_mm: number | null;
  midline_lower_direction: "right" | "left" | null;
  midline_lower_mm: number | null;
  space_upper_type: "crowding" | "spacing" | null;
  space_upper_mm: number | null;
  space_lower_type: "crowding" | "spacing" | null;
  space_lower_mm: number | null;
  sna_case: number | null;
  snb_case: number | null;
  anb_case: number | null;
  mma_case: number | null;
  u1_pp_case: number | null;
  l1_mp_case: number | null;
  nasolabial_case: number | null;
  nasolabial_angle: "acute" | "average" | "obtuse" | null;
  lips: "competent" | "incompetent" | null;
  extraction_choice: "extraction" | "non_extraction" | null;
  extraction_teeth: string | null; // JSON array نصي
  anchorage: "minimal" | "moderate" | "maximum" | null;
  anchorage_note: string | null;
  hints: string | null;
  // تركيب التقويم (bonding) والريبوندينج — دفعة 25 (تكملة). فك علوي/سفلي كل
  // واحد بيتسجل مرة واحدة بس (الأكشن نفسه بيرفض أي محاولة تانية لو bonding_*_date
  // متسجل بالفعل)، وبيخصم من المخزون وقت التسجيل. الريبوندينج تكراري لأي سن،
  // شوف rebonding_counts/broken_teeth.
  prescription: string | null; // "Roth" / "MBT" / "Andrews" أو نص حر تاني
  bonding_upper_bracket_item_id: number | null;
  bonding_upper_bracket_qty: number | null;
  bonding_upper_tube_item_id: number | null;
  bonding_upper_tube_qty: number | null;
  bonding_upper_date: string | null;
  bonding_upper_not_bonded_teeth: string | null; // JSON array نصي
  bonding_lower_bracket_item_id: number | null;
  bonding_lower_bracket_qty: number | null;
  bonding_lower_tube_item_id: number | null;
  bonding_lower_tube_qty: number | null;
  bonding_lower_date: string | null;
  bonding_lower_not_bonded_teeth: string | null; // JSON array نصي
  // broken_teeth: أسنان براكتها مكسورة/واقعة دلوقتي (لسه ماترّكبتش تاني) — علم
  // حالة، مش سجل تاريخي. بيتصفّر أوتوماتيك للسن لما يتسجل ريبوندينج عليه.
  broken_teeth: string | null; // JSON array نصي
  // rebonding_counts: عدد مرات الريبوندينج التراكمي لكل سن — JSON object نصي
  // {"UR6": 2, "LL4": 1}. بيزيد واحد كل مرة confirmRebondingAction بينفذ.
  rebonding_counts: string | null;
  // tooth_comments: ملاحظة نصية حرة لأي سن — JSON object نصي {"UR6": "..."}.
  // بيتحفظ مع باقي الشارت (زرار الحفظ العادي)، مش أكشن فوري.
  tooth_comments: string | null;
  // شارت التقويم v2 (دمج 2026-08-27) — شوف التعليق في schema.sql/client.ts.
  // tooth_states: JSON object نصي {"16": {"bracket":"bonded","extracted":false,
  // "debondDate":null,"bondedDate":"...","rebondCount":0}, ...} — مصدر الحقيقة
  // لحالة كل سن في الشارت التفاعلي (أدق من bonding_upper/lower_* اللي بتاعة
  // الفك ككل فوق).
  tooth_states: string | null;
  strip_counts: string | null; // JSON object نصي {gapId: عدد}
  miniscrews: string | null; // JSON object نصي {gapId: true}
  // شارت التقويم v2 — حقول أعلى الصفحة الجديدة، شوف التعليق في client.ts.
  bracket_type: string | null;
  slot: string | null;
  extraction_quadrants: string | null; // JSON object نصي {ur,ul,lr,ll}
  anchorage_device: string | null;
  treatment_note: string | null;
  created_by: number | null;
  updated_by: number | null;
  created_at: Generated<string>;
  updated_at: Generated<string>;
}

// شارت التقويم v2 — زيارات الـFollow up (صف واحد لكل زيارة). شوف التعليق في
// schema.sql فوق CREATE TABLE ortho_visits للتفاصيل الكاملة.
export interface OrthoVisitsTable {
  id: Generated<number>;
  patient_id: number;
  visit_date: string;
  service: string | null;
  upper_wire_size: string | null;
  upper_wire_type: string | null;
  lower_wire_size: string | null;
  lower_wire_type: string | null;
  note: string | null;
  elastics_dispensed: Generated<number>;
  elastics_size: string | null;
  otie_color: string | null;
  power_chain_qty: number | null;
  buttons_qty: number | null;
  compressed_coil_mm: number | null;
  upper_wire_item_id: number | null;
  lower_wire_item_id: number | null;
  elastic_item_id: number | null;
  otie_item_id: number | null;
  power_chain_item_id: number | null;
  buttons_item_id: number | null;
  compressed_coil_item_id: number | null;
  bonding_bracket_item_id: number | null;
  bonding_bracket_brand: string | null;
  bonding_tube_item_id: number | null;
  doctor_id: number | null;
  seen_by_consultant: Generated<number>;
  consultant_doctor_id: number | null;
  bonding_applied: Generated<number>;
  debond_applied: Generated<number>;
  debond_snapshot: string | null;
  otie_lower_item_id: number | null; // دفعة 150
  otie_lower_color: string | null; // دفعة 150
  power_chains: string | null; // دفعة 150: JSON
  elastics: string | null; // دفعة 151: JSON
  otie_same: Generated<number>; // دفعة 151
  created_by: number | null;
  updated_by: number | null;
  created_at: Generated<string>;
  updated_at: Generated<string>;
}

export interface OrthodonticBracketStockTable {
  id: Generated<number>;
  brand: string;
  fdi: number;
  quantity: number;
  updated_at: Generated<string>;
}

export interface OrthodonticBracketStockMovementsTable {
  id: Generated<number>;
  brand: string;
  fdi: number;
  quantity: number;
  movement_type: "case_purchase" | "refill_purchase" | "manual_count" | "ortho_use" | "return";
  patient_id: number | null;
  visit_id: number | null;
  movement_date: Generated<string | null>;
  note: string | null;
  created_by: number | null;
  created_at: Generated<string>;
}

export interface OrthodonticTubeStockTable {
  fdi: number;
  quantity: Generated<number>;
  updated_at: Generated<string>;
}

export interface OrthodonticTubeStockMovementsTable {
  id: Generated<number>;
  fdi: number;
  quantity: number;
  movement_type: "case_purchase" | "refill_purchase" | "manual_count" | "ortho_use" | "return";
  patient_id: number | null;
  visit_id: number | null;
  movement_date: string | null;
  note: string | null;
  created_by: number | null;
  created_at: Generated<string>;
  undone_by: number | null;
  undone_at: string | null;
}

// شارت التقويم v2 — سجل خصومات المخزون القابل للـUndo. شوف التعليق في
// schema.sql فوق CREATE TABLE ortho_inventory_deductions.
export interface OrthoInventoryDeductionsTable {
  id: Generated<number>;
  patient_id: number;
  visit_id: number | null;
  item_id: number | null;
  label: string;
  qty: number;
  teeth: string | null; // JSON array نصي لأرقام FDI (خصومات التيوبز المجمّعة)
  deduction_date: string;
  created_by: number | null;
  created_at: Generated<string>;
  undone_by: number | null;
  undone_at: string | null;
}

// شارت التقويم v2 — قوايم الاختيارات القابلة للتعديل من الإعدادات (مقاسات/أنواع
// الوير، ألوان الـO-tie، مقاسات الإيلاستكس).
export interface OrthoOptionListsTable {
  id: Generated<number>;
  category: "wire_size" | "wire_type" | "otie_color" | "elastic_size" | "anchorage_device";
  value: string;
  sort_order: Generated<number>;
  active: Generated<number>;
  created_at: Generated<string>;
}

// تكامل WhatsApp Cloud API — شوف التعليق فوق CREATE TABLE whatsapp_accounts في
// schema.sql لتفاصيل تخزين التوكن المشفّر.
export interface WhatsappAccountsTable {
  id: Generated<number>;
  waba_id: string;
  phone_number_id: string;
  display_phone_number: string | null;
  verified_name: string | null;
  business_id: string | null;
  access_token_encrypted: string;
  token_type: Generated<string>;
  environment: Generated<"test" | "production">;
  coexistence_mode: Generated<number>;
  connection_status: Generated<"connected" | "disconnected" | "error">;
  last_error: string | null;
  connected_by: number | null;
  connected_at: Generated<string>;
  updated_at: Generated<string>;
}

export interface WhatsappContactsTable {
  id: Generated<number>;
  account_id: number;
  wa_id: string;
  profile_name: string | null;
  patient_id: number | null;
  last_message_at: string | null;
  created_at: Generated<string>;
}

export interface WhatsappMessagesTable {
  id: Generated<number>;
  account_id: number;
  contact_id: number;
  wamid: string | null;
  direction: "inbound" | "outbound";
  message_type: Generated<string>;
  body: string | null;
  template_name: string | null;
  status: Generated<"pending" | "sent" | "delivered" | "read" | "failed">;
  error_message: string | null;
  is_echo: Generated<number>;
  sent_by: number | null;
  wa_timestamp: string | null;
  created_at: Generated<string>;
}

export interface WhatsappMessageTemplatesTable {
  id: Generated<number>;
  account_id: number;
  meta_template_id: string | null;
  name: string;
  language: string;
  category: Generated<string>;
  body_text: string;
  status: Generated<"pending" | "approved" | "rejected" | "paused" | "disabled">;
  rejected_reason: string | null;
  created_by: number | null;
  created_at: Generated<string>;
  updated_at: Generated<string>;
}

export interface WhatsappWebhookEventsTable {
  event_key: string;
  event_type: string;
  received_at: Generated<string>;
}

export interface WhatsappManualTemplatesTable {
  id: Generated<number>;
  name: string;
  header_text: string | null;
  body_text: string;
  recipient_type: string;
  variable_map: Generated<string>;
  quick_slot: number | null;
  active: Generated<number>;
  created_by: number | null;
  created_at: Generated<string>;
  updated_at: Generated<string>;
}

export interface WhatsappAutomationRulesTable {
  id: Generated<number>; name: string; template_id: number;
  trigger_type: "appointment_relative" | "appointment_completed";
  day_offset: Generated<number>; send_time: Generated<string>; delay_minutes: Generated<number>;
  variable_map: Generated<string>; active: Generated<number>; created_by: number | null;
  created_at: Generated<string>; updated_at: Generated<string>;
}
export interface WhatsappAutomationDeliveriesTable {
  id: Generated<number>; rule_id: number; appointment_id: number;
  status: Generated<"pending" | "sent" | "failed" | "skipped">; scheduled_for: string;
  sent_at: string | null; error_message: string | null; created_at: Generated<string>;
}
export interface WhatsappManualDeliveriesTable {
  id: Generated<number>; appointment_id: number; template_id: number; patient_id: number;
  status: Generated<"opened" | "responded">; attempts: Generated<number>;
  last_opened_at: Generated<string>; opened_by: number | null;
}
export interface PatientReviewInvitesTable {
  id: Generated<number>; token_hash: string; appointment_id: number; patient_id: number;
  doctor_id: number; expires_at: string; created_at: Generated<string>;
}
export interface PatientReviewsTable {
  id: Generated<number>; token_hash: string; appointment_id: number | null; patient_id: number | null;
  doctor_id: number; visit_date: string; anonymous: Generated<number>; rating: number;
  comment: string | null; submitted_at: Generated<string>;
}

/** دفعة 145: تجميد المديونية وتسويتها. */
export interface DebtFreezesTable {
  id: Generated<number>;
  patient_id: number;
  frozen_date: string;
  reason: string | null;
  frozen_by: number | null;
  created_at: Generated<string>;
  cleared_at: string | null;
  cleared_by: number | null;
}
export interface DebtSettlementsTable {
  id: Generated<number>;
  patient_id: number;
  settled_date: string;
  total_amount: number;
  reason: string | null;
  settled_by: number | null;
  created_at: Generated<string>;
  cancelled_at: string | null;
  cancelled_by: number | null;
}
export interface DebtSettlementLinesTable {
  id: Generated<number>;
  settlement_id: number;
  invoice_id: number;
  amount: number;
}

/** دفعة 144: إيقاف علاج التقويم. */
export interface OrthoTreatmentStopsTable {
  id: Generated<number>;
  patient_id: number;
  stopped_date: string;
  reason: string | null;
  stopped_by: number | null;
  created_at: Generated<string>;
  cleared_at: string | null;
  cleared_by: number | null;
}

export interface Database {
  doctors: DoctorsTable;
  consultant_assistants: ConsultantAssistantsTable;
  users: UsersTable;
  login_attempts: LoginAttemptsTable;
  user_permissions: UserPermissionsTable;
  rooms: RoomsTable;
  shifts: ShiftsTable;
  doctor_weekly_shifts: DoctorWeeklyShiftsTable;
  doctor_date_shifts: DoctorDateShiftsTable;
  services: ServicesTable;
  service_doctors: ServiceDoctorsTable;
  patients: PatientsTable;
  appointments: AppointmentsTable;
  patient_referrals: PatientReferralsTable;
  tasks: TasksTable;
  appointment_reminders: AppointmentRemindersTable;
  visits: VisitsTable;
  invoices: InvoicesTable;
  collection_requests: CollectionRequestsTable;
  patient_credits: PatientCreditsTable;
  patient_image_groups: PatientImageGroupsTable;
  patient_images: PatientImagesTable;
  patient_image_corrections: PatientImageCorrectionsTable;
  inventory_items: InventoryItemsTable;
  expense_templates: ExpenseTemplatesTable;
  expenses: ExpensesTable;
  doctor_compensation_rules: DoctorCompensationRulesTable;
  doctor_payroll_runs: DoctorPayrollRunsTable;
  hr_staff: HrStaffTable;
  hr_compensation_rules: HrCompensationRulesTable;
  hr_payroll_runs: HrPayrollRunsTable;
  hr_period_settlements: HrPeriodSettlementsTable;
  hr_documents: HrDocumentsTable;
  inventory_specialties: InventorySpecialtiesTable;
  inventory_categories: InventoryCategoriesTable;
  inventory_products: InventoryProductsTable;
  inventory_attribute_groups: InventoryAttributeGroupsTable;
  inventory_attribute_values: InventoryAttributeValuesTable;
  inventory_units: InventoryUnitsTable;
  inventory_suppliers: InventorySuppliersTable;
  supplier_invoices: SupplierInvoicesTable;
  supplier_payments: SupplierPaymentsTable;
  inventory_purchase_drafts: InventoryPurchaseDraftsTable;
  inventory_purchase_draft_items: InventoryPurchaseDraftItemsTable;
  inventory_stock_alerts: InventoryStockAlertsTable;
  inventory_supply_batches: InventorySupplyBatchesTable;
  inventory_stock_movements: InventoryStockMovementsTable;
  inventory_consumable_rules: InventoryConsumableRulesTable;
  clinic_settings: ClinicSettingsTable;
  notification_cases: NotificationCasesTable;
  notifications: NotificationsTable;
  chat_messages: ChatMessagesTable;
  chat_read_states: ChatReadStatesTable;
  audit_log: AuditLogTable;
  orthodontic_charts: OrthodonticChartsTable;
  ortho_visits: OrthoVisitsTable;
  ortho_treatment_stops: OrthoTreatmentStopsTable;
  debt_freezes: DebtFreezesTable;
  debt_settlements: DebtSettlementsTable;
  debt_settlement_lines: DebtSettlementLinesTable;
  orthodontic_bracket_stock: OrthodonticBracketStockTable;
  orthodontic_bracket_stock_movements: OrthodonticBracketStockMovementsTable;
  orthodontic_tube_stock: OrthodonticTubeStockTable;
  orthodontic_tube_stock_movements: OrthodonticTubeStockMovementsTable;
  ortho_inventory_deductions: OrthoInventoryDeductionsTable;
  ortho_option_lists: OrthoOptionListsTable;
  whatsapp_accounts: WhatsappAccountsTable;
  whatsapp_contacts: WhatsappContactsTable;
  whatsapp_messages: WhatsappMessagesTable;
  whatsapp_message_templates: WhatsappMessageTemplatesTable;
  whatsapp_webhook_events: WhatsappWebhookEventsTable;
  whatsapp_manual_templates: WhatsappManualTemplatesTable;
  whatsapp_automation_rules: WhatsappAutomationRulesTable;
  whatsapp_automation_deliveries: WhatsappAutomationDeliveriesTable;
  whatsapp_manual_deliveries: WhatsappManualDeliveriesTable;
  patient_review_invites: PatientReviewInvitesTable;
  patient_reviews: PatientReviewsTable;
}
