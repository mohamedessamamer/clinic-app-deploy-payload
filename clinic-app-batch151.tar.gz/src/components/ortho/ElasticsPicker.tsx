"use client";

// دفعة 151 — بوكس الأساتك. شبكة واحدة للفكين (من 7 لـ 7) + الميني سكرو المرسوم.
// بتدوس على الأسنان بالترتيب: ضغطة = برة، ضغطة كمان على نفس النقطة = جوة
// (palatal/lingual)، والتالتة = بتتشال. اليمين والشمال بيتفصلوا لوحدهم، و
// "Next elastic" للحالة النادرة: أستكين في نفس الجنب. كل الكلام English.

import { useState } from "react";
import { LOWER_BOX, UPPER_BOX } from "@/lib/ortho/power-chain";
import { classifyElastic, colorForSize, describeElastics, MAX_ELASTICS_PER_VISIT, samePoint, shouldStartNewElastic, sizeLabel, type ElasticInput, type ElasticPoint } from "@/lib/ortho/elastics";

type Size = { id: number; name: string };

export default function ElasticsPicker({
  value,
  sizes,
  screws,
  lastVisit,
  onDone,
  onCancel,
}: {
  value: ElasticInput[];
  sizes: Size[];
  /** الميني سكرو المرسوم على الشارت (id الفجوة زي "16-15"). */
  screws: string[];
  lastVisit: ElasticInput[];
  onDone: (elastics: ElasticInput[]) => void;
  onCancel: () => void;
}) {
  const [elastics, setElastics] = useState<ElasticInput[]>(() => value.map((item) => ({ ...item, points: item.points.map((point) => ({ ...point })) })));
  const [current, setCurrent] = useState<number>(() => (value.length ? value.length - 1 : -1));
  const [size, setSize] = useState<Size | null>(() => {
    const last = value.at(-1);
    return (last && sizes.find((item) => item.id === last.itemId)) ?? sizes[0] ?? null;
  });
  const [message, setMessage] = useState("");

  function tap(point: ElasticPoint) {
    setMessage("");
    if (!size) {
      setMessage("Add an elastic size in stock first.");
      return;
    }
    const next = elastics.map((item) => ({ ...item, points: [...item.points] }));
    const active = current >= 0 ? next[current] : undefined;
    const existing = active ? active.points.findIndex((p) => samePoint(p, point)) : -1;
    if (active && existing >= 0) {
      // نفس النقطة في نفس الأستك: برة → جوة → تتشال.
      const p = active.points[existing];
      if (!p.palatal) active.points[existing] = { ...p, palatal: true };
      else active.points.splice(existing, 1);
      if (active.points.length === 0) {
        next.splice(current, 1);
        setCurrent(next.length - 1);
      }
      setElastics(next);
      return;
    }
    if (!active || shouldStartNewElastic(active.points, point)) {
      if (next.length >= MAX_ELASTICS_PER_VISIT) {
        setMessage(`At most ${MAX_ELASTICS_PER_VISIT} elastics per visit.`);
        return;
      }
      next.push({ itemId: size.id, size: size.name, points: [point] });
      setElastics(next);
      setCurrent(next.length - 1);
      return;
    }
    if (active.points.length >= 8) {
      setMessage("An elastic can have up to 8 points.");
      return;
    }
    active.points.push(point);
    setElastics(next);
  }

  function chooseSize(item: Size) {
    setSize(item);
    if (current >= 0) setElastics((list) => list.map((elastic, index) => (index === current ? { ...elastic, itemId: item.id, size: item.name } : elastic)));
  }

  function badgeFor(point: ElasticPoint) {
    const marks: { label: string; hex: string; palatal: boolean }[] = [];
    elastics.forEach((elastic, index) => {
      const order = elastic.points.findIndex((p) => samePoint(p, point));
      if (order >= 0) marks.push({ label: `${String.fromCharCode(65 + index)}${order + 1}`, hex: colorForSize(elastic.size), palatal: elastic.points[order].palatal });
    });
    return marks;
  }

  function cell(point: ElasticPoint, text: string, key: string, isScrew = false) {
    const marks = badgeFor(point);
    const first = marks[0];
    return (
      <button
        key={key}
        type="button"
        className={`${isScrew ? "ortho-pc-screw" : "ortho-pc-tooth"} ${first ? (first.palatal ? "is-palatal" : "is-on") : ""}`}
        style={{ "--pc": first?.hex ?? "#94a3b8" } as React.CSSProperties}
        onClick={() => tap(point)}
        aria-label={isScrew ? `Miniscrew ${text}` : `Tooth ${text}`}
      >
        {isScrew ? "⊙" : text}
        {marks.length > 0 && <i style={{ background: first.hex }}>{marks.map((mark) => mark.label).join(",")}</i>}
      </button>
    );
  }

  function row(teeth: readonly number[]) {
    const out: React.ReactNode[] = [];
    teeth.forEach((fdi, index) => {
      if (index === 7) out.push(<span key={`mid${fdi}`} className="ortho-pc-mid" aria-hidden="true" />);
      out.push(cell({ fdi, palatal: false }, String(fdi), `t${fdi}`));
      const nextTooth = teeth[index + 1];
      if (nextTooth != null) {
        const gap = screws.find((id) => id === `${fdi}-${nextTooth}` || id === `${nextTooth}-${fdi}`);
        if (gap) out.push(cell({ screw: gap, palatal: false }, gap.replace("-", "/"), `s${gap}`, true));
      }
    });
    return <div className="ortho-pc-row">{out}</div>;
  }

  const auto = describeElastics(elastics.filter((elastic) => elastic.points.length >= 2));

  return (
    <div className="ortho-pc-backdrop" role="dialog" aria-modal="true" aria-label="Elastics" onClick={(event) => event.stopPropagation()}>
      <div className="ortho-pc-sheet">
        <h3>Elastics</h3>
        <p className="ortho-pc-hint">Tap teeth in order. 1 tap = buccal · 2 taps = palatal/lingual · 3 taps = remove. Right and left split by themselves.</p>
        <div className="ortho-pc-sizes">
          {sizes.map((item) => (
            <button key={item.id} type="button" className={size?.id === item.id ? "is-on" : ""} style={{ "--pc": colorForSize(item.name) } as React.CSSProperties} onClick={() => chooseSize(item)}>
              {sizeLabel(item.name)}
            </button>
          ))}
          {lastVisit.length > 0 && (
            <button type="button" className="is-same" onClick={() => { setElastics(lastVisit.map((item) => ({ ...item, points: item.points.map((point) => ({ ...point })) }))); setCurrent(lastVisit.length - 1); }}>
              ↺ Same as last visit
            </button>
          )}
        </div>
        <div className="ortho-pc-label">UPPER</div>
        {row(UPPER_BOX)}
        <div className="ortho-pc-label">LOWER</div>
        {row(LOWER_BOX)}
        {message && <p className="ortho-pc-message" role="alert">{message}</p>}
        {elastics.length > 0 && (
          <div className="ortho-pc-chips">
            {elastics.map((elastic, index) => {
              const { kind, side } = classifyElastic(elastic.points);
              const text = elastic.points.map((p) => ("fdi" in p ? `${p.fdi}${p.palatal ? "p" : ""}` : `MS${p.screw.replace("-", "/")}`)).join("→");
              return (
                <div key={index} className={`ortho-pc-chip ${index === current ? "is-current" : ""}`} style={{ "--pc": colorForSize(elastic.size) } as React.CSSProperties} onClick={() => setCurrent(index)}>
                  <span><b>{String.fromCharCode(65 + index)}</b> · {text} · {sizeLabel(elastic.size)}</span>
                  <span className="ortho-pc-chip-actions">
                    <em>{elastic.points.length < 2 ? "add a point" : `${kind}${side === "both" || kind === "Custom" || kind === "Cross" ? "" : side === "right" ? " R" : " L"}`}</em>
                    <button type="button" aria-label="Remove elastic" onClick={(event) => { event.stopPropagation(); setElastics((list) => list.filter((_, i) => i !== index)); setCurrent((value) => Math.min(value, elastics.length - 2)); }}>×</button>
                  </span>
                </div>
              );
            })}
          </div>
        )}
        <button type="button" className="ortho-pc-next" onClick={() => setCurrent(-1)}>+ Next elastic (only for 2 elastics on the same side)</button>
        {auto && <div className="ortho-pc-auto"><b>Auto:</b> {auto}</div>}
        <div className="ortho-pc-actions">
          <button type="button" className="is-primary" onClick={() => {
            const incomplete = elastics.find((elastic) => elastic.points.length < 2);
            if (incomplete) { setMessage("Every elastic needs at least 2 points (or remove it)."); return; }
            onDone(elastics);
          }}>Done</button>
          <button type="button" onClick={onCancel}>Cancel</button>
        </div>
      </div>
    </div>
  );
}
