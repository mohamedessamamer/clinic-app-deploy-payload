import { notFound } from "next/navigation";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { displayAge } from "@/lib/age";
import { hasPermission } from "@/lib/permissions";
import type { Role } from "@/lib/auth";
import OrthoChartV2 from "@/components/ortho/OrthoChartV2";
import type { ToothState } from "@/components/ortho/InteractiveToothChart";

// شارت تقويم v2 — دمج البروتوتايب المعزول مع السيستم الحقيقي (2026-08-27).
// نفس صلاحية التعديل القديمة بالظبط (دكتور + أدمن + مدير عيادة).
function canEditMedicalRecordFor(role: string | undefined): boolean {
  return role === "doctor" || role === "admin" || role === "clinic_manager";
}

function parseJsonObject<T>(raw: string | null, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export default async function OrthodonticChartPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const patientId = Number(id);
  if (!patientId) notFound();

  const patient = await db.selectFrom("patients").selectAll().where("id", "=", patientId).executeTakeFirst();
  if (!patient) notFound();

  const session = await getSession();
  const editable = canEditMedicalRecordFor(session?.role);

  const [chartRow, doctors, optionRows, visitRows, deductionRows, eventRows, imageGroups, canEditAfterSave, canUndoInventory] = await Promise.all([
    db.selectFrom("orthodontic_charts").selectAll().where("patient_id", "=", patientId).executeTakeFirst(),
    db.selectFrom("doctors").select(["id", "full_name"]).where("active", "=", 1).orderBy("full_name").execute(),
    db.selectFrom("ortho_option_lists").select(["category", "value"]).where("active", "=", 1).orderBy("sort_order").execute(),
    db
      .selectFrom("ortho_visits")
      .selectAll()
      .where("patient_id", "=", patientId)
      .orderBy("id", "desc")
      .execute(),
    db
      .selectFrom("ortho_inventory_deductions")
      .selectAll()
      .where("patient_id", "=", patientId)
      .orderBy("deduction_date", "desc")
      .orderBy("id", "desc")
      .execute(),
    db
      .selectFrom("audit_log")
      .selectAll()
      .where("entity_type", "=", "orthodontic_chart")
      .where("entity_id", "=", patientId)
      .orderBy("id", "desc")
      .execute(),
    db
      .selectFrom("patient_image_groups")
      .selectAll()
      .where("patient_id", "=", patientId)
      .orderBy("taken_at", "desc")
      .execute(),
    session ? hasPermission(session.userId, session.role as Role, "edit_ortho_visit_after_save") : Promise.resolve(false),
    session ? hasPermission(session.userId, session.role as Role, "undo_ortho_inventory_deduction") : Promise.resolve(false),
  ]);

  const imageGroupsWithFiles = await Promise.all(
    imageGroups.map(async (g) => ({
      ...g,
      images: await db.selectFrom("patient_images").selectAll().where("group_id", "=", g.id).execute(),
    }))
  );

  const optionsByCategory: Record<string, string[]> = {};
  for (const row of optionRows) {
    if (!optionsByCategory[row.category]) optionsByCategory[row.category] = [];
    optionsByCategory[row.category].push(row.value);
  }

  const toothStates = parseJsonObject<Record<number, ToothState>>(chartRow?.tooth_states ?? null, {});
  const stripCounts = parseJsonObject<Record<string, number>>(chartRow?.strip_counts ?? null, {});
  const miniscrews = parseJsonObject<Record<string, boolean>>(chartRow?.miniscrews ?? null, {});
  const extractionQuadrants = parseJsonObject<{ ur: string; ul: string; lr: string; ll: string } | null>(chartRow?.extraction_quadrants ?? null, null);

  const visits = visitRows.map((v) => ({
    id: v.id,
    date: v.visit_date,
    service: v.service ?? "",
    upperSize: v.upper_wire_size ?? "",
    upperType: v.upper_wire_type ?? "",
    lowerSize: v.lower_wire_size ?? "",
    lowerType: v.lower_wire_type ?? "",
    note: v.note ?? "",
    elasticsDispensed: v.elastics_dispensed === 1,
    elasticsSize: v.elastics_size ?? "",
    otieColor: v.otie_color ?? "",
    powerChainQty: v.power_chain_qty != null ? String(v.power_chain_qty) : "",
    buttonsQty: v.buttons_qty != null ? String(v.buttons_qty) : "",
    compressedCoilMm: v.compressed_coil_mm != null ? String(v.compressed_coil_mm) : "",
    doctorId: v.doctor_id,
    bondingApplied: v.bonding_applied === 1,
  }));

  const inventoryLog = deductionRows.map((d) => ({
    id: d.id,
    label: d.label,
    qty: d.qty,
    teeth: d.teeth ? (JSON.parse(d.teeth) as number[]) : null,
    date: d.deduction_date,
    undoneAt: d.undone_at,
  }));

  const chartEvents = eventRows.map((e) => ({
    id: e.id,
    date: e.event_date || e.changed_at.slice(0, 10),
    text: e.reason || "",
  }));

  return (
    <OrthoChartV2
        patientId={patientId}
        patientName={patient.full_name}
        fileNumber={patient.file_number}
        patientAge={displayAge(patient)}
        patientPhone={patient.phone}
        editable={editable}
        canEditAfterSave={canEditAfterSave}
        canUndoInventory={canUndoInventory}
        defaultDoctorId={session?.doctorId ?? null}
        doctors={doctors}
        options={{
          wireSizes: optionsByCategory.wire_size || [],
          wireTypes: optionsByCategory.wire_type || [],
          otieColors: optionsByCategory.otie_color || [],
          elasticSizes: optionsByCategory.elastic_size || [],
          anchorageDevices: optionsByCategory.anchorage_device || [],
        }}
        chart={{
          bracket_type: chartRow?.bracket_type ?? null,
          prescription: chartRow?.prescription ?? null,
          slot: chartRow?.slot ?? null,
          chief_complaint: chartRow?.chief_complaint ?? null,
          extraction_quadrants: extractionQuadrants,
          anchorage_device: chartRow?.anchorage_device ?? null,
          treatment_note: chartRow?.treatment_note ?? null,
        }}
        toothStates={toothStates}
        stripCounts={stripCounts}
        miniscrews={miniscrews}
        diagnostic={{
          antero_posterior: chartRow?.antero_posterior ?? null,
          facial_height: chartRow?.facial_height ?? null,
          mx_incisor_inclination: chartRow?.mx_incisor_inclination ?? null,
          mn_incisor_inclination: chartRow?.mn_incisor_inclination ?? null,
          molar_relation_right: chartRow?.molar_relation_right ?? null,
          molar_relation_left: chartRow?.molar_relation_left ?? null,
          overbite: chartRow?.overbite ?? null,
          overjet: chartRow?.overjet ?? null,
          midline_upper_direction: chartRow?.midline_upper_direction ?? null,
          midline_upper_mm: chartRow?.midline_upper_mm ?? null,
          midline_lower_direction: chartRow?.midline_lower_direction ?? null,
          midline_lower_mm: chartRow?.midline_lower_mm ?? null,
          space_upper_type: chartRow?.space_upper_type ?? null,
          space_upper_mm: chartRow?.space_upper_mm ?? null,
          space_lower_type: chartRow?.space_lower_type ?? null,
          space_lower_mm: chartRow?.space_lower_mm ?? null,
          nasolabial_angle: chartRow?.nasolabial_angle ?? null,
          lips: chartRow?.lips ?? null,
        }}
        visits={visits}
        inventoryLog={inventoryLog}
        chartEvents={chartEvents}
        imageGroups={imageGroupsWithFiles}
      />
  );
}
