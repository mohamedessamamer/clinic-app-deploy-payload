"use client";

import { useEffect, useMemo, useRef, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { addAppointmentAction, updateAppointmentStatusAction, setAppointmentPurposeAction } from "@/app/appointments/actions";
import {
  getPatientBillableInvoicesAction,
  getBookedSlotsForRoomDateAction,
  recordAppointmentBillingAction,
  recordPendingBillingAction,
} from "@/app/appointments/billing-actions";
import { PAYMENT_METHODS } from "@/lib/payment-methods";
import ServiceCombobox from "@/components/ServiceCombobox";

type Room = { id: number; name: string };
type Patient = { id: number; full_name: string; file_number: string };
type Doctor = { id: number; full_name: string };
type Service = { id: number; name: string; code: string | null; default_price: number };
type BillableInvoice = { id: number; service_name: string; visit_date: string; balance: number };
type Appt = {
  id: number;
  patient_id: number;
  patient_name: string;
  doctor_id: number;
  doctor_name: string;
  room_id: number;
  start_time: string;
  duration_minutes: number | null;
  status: "booked" | "attended" | "done" | "cancelled" | "no_show";
  notes: string | null;
  // true لو الموعد "تم" بس لسه ملوش فاتورة/زيارة مسجلة (حصل "تم" من غير بوكس تحصيل —
  // إما لأن اللي حددها معهوش صلاحية تحصيل المدفوعات، أو دوس "تخطي"). بيستخدم عشان
  // الاستقبال يقدر يفتح بوكس التحصيل لاحقًا لموعد "تم" أصلاً من غير رجوعه لحالة تانية.
  needs_billing?: boolean;
  // لو اللي حدد "تم" معهوش صلاحية تحصيل المدفوعات (زي الدكتور)، بيقدر يحدد هنا الخدمة
  // والسعر المتوقع "المطلوب دفعه" من غير ما يسجل دفع فعلي — بتظهر جنب "محتاج تحصيل"
  // في الجدول عشان الاستقبال يشوفها على طول، وبتتملى تلقائي في بوكس التحصيل بتاعه.
  pending_service_id?: number | null;
  pending_service_name?: string | null;
  pending_price?: number | null;
  pending_discount_percent?: number | null;
  // true لو المريض بيعمل متابعة (خدمة كودها "0") ومفيش صور/أشعة اتسجلت له من
  // أكتر من 6 شهور (أو مالوش صور خالص) — تنبيه بصري بس، مش بيمنع أي إجراء.
  needs_new_photos?: boolean;
  // "المريض جاي يعمل إيه" (دفعة 26) — لابل تحت اسم المريض، تتحدد وقت الحجز أو
  // بعدين من قايمة الزر اليمين على الخانة. bonding_upper/bonding_lower = تركيب
  // أول/تاني تقويم (بيودّي لشارت التقويم مباشرة لمين معاه صلاحية تعديل الملف
  // الطبي)، service = أي خدمة عادية تانية من القايمة (بما فيها "متابعة تقويم"
  // الموجودة أصلاً في قايمة الخدمات — مفيش نوع مخصوص ليها).
  purpose_type?: "bonding_upper" | "bonding_lower" | "service" | null;
  purpose_service_id?: number | null;
  purpose_service_name?: string | null;
  purpose_service_category?: string | null;
  // true لو المريض عنده شارت تقويم فعلي بالفعل (بدأ علاج تقويم قبل كده) —
  // بيستخدم عشان أي موعد ليه (حتى لو معلمش عليه "المريض جاي يعمل إيه") يوّدي
  // لشارت التقويم على طول من أكونت الطبيب، بدل الملف الطبي العادي.
  is_ortho_patient?: boolean;
};

const PURPOSE_LABELS: Record<"bonding_upper" | "bonding_lower", string> = {
  bonding_upper: "تركيب أول تقويم",
  bonding_lower: "تركيب تاني تقويم",
};

function purposeLabelOf(appt: Appt): string | null {
  if (appt.purpose_type === "bonding_upper" || appt.purpose_type === "bonding_lower") return PURPOSE_LABELS[appt.purpose_type];
  if (appt.purpose_type === "service") return appt.purpose_service_name ?? null;
  return null;
}

// أي مريض تقويم: إما عنده شارت تقويم فعلي بالفعل، أو الموعد ده معلّم عليه
// صراحة إنه تركيب أول/تاني تقويم، أو الخدمة المحددة كـ"جاي يعمل إيه" من قايمة
// خدمات التقويم (فئة "Orthodontics") — زي "متابعة تقويم" مثلًا. مراجعة
// 2026-08-27: لينك الشارت بقى مربوط بالجدول لأي حالة من التلاتة دول، مش بس
// تركيب أول/تاني كان قبل كده.
function isOrthoAppt(appt: Appt): boolean {
  return (
    !!appt.is_ortho_patient ||
    appt.purpose_type === "bonding_upper" ||
    appt.purpose_type === "bonding_lower" ||
    (appt.purpose_type === "service" && appt.purpose_service_category === "Orthodontics")
  );
}

// وجهة الدوسة على لابل "المريض جاي يعمل إيه": من أكونت الطبيب بتوديك لملف
// العلاج المناسب (شارت التقويم لو المريض ده مريض تقويم بأي شكل من الأشكال
// فوق، الملف الطبي العام لأي حاجة تانية) — من أي أكونت تاني (استقبال/محاسب/
// أدمن...) بتوديك للملف المالي دايمًا.
function purposeHrefOf(appt: Appt, isDoctorView: boolean): string {
  if (!isDoctorView) return `/patients/${appt.patient_id}/billing`;
  if (isOrthoAppt(appt)) return `/patients/${appt.patient_id}/orthodontics`;
  return `/patients/${appt.patient_id}`;
}

const STATUS_LABELS: Record<Appt["status"], string> = {
  booked: "محجوز",
  attended: "حضر",
  done: "تم",
  cancelled: "ملغي",
  no_show: "لم يحضر",
};

function statusClasses(status: Appt["status"]): string {
  switch (status) {
    case "booked":
      return "bg-primary-soft text-primary-dark border-primary/40";
    case "attended":
      return "bg-amber-100 text-amber-900 border-amber-300";
    case "done":
      return "bg-emerald-100 text-emerald-900 border-emerald-300";
    case "no_show":
      return "bg-danger-soft text-danger border-danger/40";
    default:
      return "bg-background text-foreground border-border";
  }
}

type CellPlan = { kind: "empty" } | { kind: "skip" } | { kind: "start"; appt: Appt; span: number };

export default function CentralSchedule({
  date,
  rooms,
  timeSlots,
  slotMinutes,
  appointments,
  patients,
  doctors,
  services = [],
  canEdit = true,
  canCollectPayments = false,
  canEditAssistantDoctor = false,
  isDoctorView = false,
  roomShiftDoctorIds = {},
}: {
  date: string;
  rooms: Room[];
  timeSlots: string[];
  slotMinutes: number;
  appointments: Appt[];
  patients: Patient[];
  doctors: Doctor[];
  services?: Service[];
  // لو false، الجدول بيبقى عرض بس — من غير حجز خانة فاضية أو تغيير حالة موعد
  // بالزر اليمين (حسب صلاحية "schedule_edit"). التزامن التلقائي بيفضل شغال زي ما هو.
  canEdit?: boolean;
  // لو true، الضغط على "تم" بيفتح بوكس تحصيل (اختيار خدمة/سعر/خصم أو دفعة متابعة على
  // فاتورة سابقة) قبل ما يتحدد الموعد كـ"تم" — حسب صلاحية "collect_payments".
  canCollectPayments?: boolean;
  // دفعة 22: إظهار حقل "الطبيب المساعد" الاختياري جوه بوكس التحصيل — نفس صلاحية
  // سجل الزيارات بالملف الطبي (edit_visit_assistant_doctor أو override_visit_doctor).
  canEditAssistantDoctor?: boolean;
  // بيحدد وجهة الضغط على اسم المريض في خانة الجدول: من أكونت الطبيب (true) بيفتح
  // الملف الطبي للمريض، ومن أي أكونت تاني (استقبال/محاسب/أدمن...) بيفتح ملفه المالي.
  isDoctorView?: boolean;
  // خريطة غرفة → دكتور صاحب الشيفت فيها النهاردة (حسب doctor_weekly_shifts). بتتحدد
  // كـ"الخيار الأول" (المحدد افتراضيًا) في قايمة اختيار الدكتور وقت الحجز — والتحصيل
  // بعد كده بيوَرّث نفس الدكتور ده أوتوماتيك من غير ما يحتاج اختيار تاني، إلا لو حد
  // غيّره وقت الحجز نفسه لحالة مريض جاي فجأة لدكتور تاني (زي ما اتفقنا).
  roomShiftDoctorIds?: Record<number, number>;
}) {
  const router = useRouter();
  const [, startTransition] = useTransition();
  const [contextMenu, setContextMenu] = useState<{
    apptId: number;
    x: number;
    y: number;
    patientName: string;
    status: Appt["status"];
    needsBilling: boolean;
  } | null>(null);
  const [bookingModal, setBookingModal] = useState<{ roomId: number; roomName: string; startTime: string } | null>(null);
  // بحث المريض جوه بوكس الحجز — نفس فكرة البحث الفوري اللي فوق الجدول، بس بيرجع
  // بالمريض المختار كـ patient_id مخفي بدل select عادي طويل.
  const [bookingPatientSearch, setBookingPatientSearch] = useState("");
  const [bookingSelectedPatient, setBookingSelectedPatient] = useState<Patient | null>(null);
  // "المريض جاي يعمل إيه؟" (اختياري) جوه بوكس الحجز نفسه — نفس الحقول بتتبعت مع
  // فورم الحجز العادي لـ addAppointmentAction. purposeType فاضي = بدون تحديد.
  const [bookingPurposeType, setBookingPurposeType] = useState<"" | "bonding_upper" | "bonding_lower" | "service">("");
  const [bookingPurposeServiceId, setBookingPurposeServiceId] = useState("");

  // قايمة تعديل "المريض جاي يعمل إيه؟" لموعد موجود بالفعل — بتتفتح من عنصر جديد
  // جوه قايمة الزر اليمين على الخانة، متاحة في أي وقت (وقت الحجز أو بعده) زي ما
  // المستخدم طلب. بتتملى بالقيمة الحالية للموعد لما تتفتح.
  const [purposeModal, setPurposeModal] = useState<{ apptId: number; patientName: string } | null>(null);
  const [purposeModalType, setPurposeModalType] = useState<"" | "bonding_upper" | "bonding_lower" | "service">("");
  const [purposeModalServiceId, setPurposeModalServiceId] = useState("");
  const [purposeModalPending, startPurposeModalTransition] = useTransition();

  function openPurposeModal(appt: Appt) {
    setContextMenu(null);
    setPurposeModalType(appt.purpose_type === "bonding_upper" || appt.purpose_type === "bonding_lower" ? appt.purpose_type : appt.purpose_type === "service" ? "service" : "");
    setPurposeModalServiceId(appt.purpose_service_id ? String(appt.purpose_service_id) : "");
    setPurposeModal({ apptId: appt.id, patientName: appt.patient_name });
  }

  function closePurposeModal() {
    setPurposeModal(null);
    setPurposeModalType("");
    setPurposeModalServiceId("");
  }

  function savePurposeModal() {
    if (!purposeModal) return;
    const fd = new FormData();
    fd.set("appointment_id", String(purposeModal.apptId));
    fd.set("purpose_type", purposeModalType);
    if (purposeModalType === "service" && purposeModalServiceId) fd.set("purpose_service_id", purposeModalServiceId);
    startPurposeModalTransition(async () => {
      await setAppointmentPurposeAction(fd);
      router.refresh();
    });
    closePurposeModal();
  }
  // mode "collect": بوكس التحصيل الكامل (لصلاحية collect_payments) — بيسجل دفع فعلي.
  // mode "pending": بوكس "المطلوب دفعه" بس (لمين معهوش الصلاحية، زي الدكتور) — بيحدد
  // خدمة وسعر متوقع من غير أي تسجيل مالي فعلي.
  const [billingModal, setBillingModal] = useState<{
    apptId: number;
    patientId: number;
    patientName: string;
    mode: "collect" | "pending";
    roomId: number;
    doctorId: number;
  } | null>(null);
  const [highlightApptId, setHighlightApptId] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const menuRef = useRef<HTMLDivElement>(null);
  // دوسة طويلة (long-press) على موبايل/تابلت = نفس تأثير الزر اليمين على
  // ديسكتوب (فتح قايمة تغيير حالة الموعد) — تاتش مالوش زر يمين خالص. تايمر
  // واحد مشترك كفاية لأن لمسة واحدة بس بتكون فعّالة في أي لحظة، وبيتلغي لو
  // المستخدم حرّك إصبعه (يعني بيسكرول الجدول، مش بيعمل long-press).
  const touchLongPressRef = useRef<{ timer: ReturnType<typeof setTimeout>; startX: number; startY: number } | null>(null);
  const LONG_PRESS_MS = 550;
  const LONG_PRESS_MOVE_CANCEL_PX = 10;

  // حالة بوكس التحصيل
  const [serviceNameSearch, setServiceNameSearch] = useState("");
  const [serviceCodeSearch, setServiceCodeSearch] = useState("");
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [price, setPrice] = useState("");
  const [discountPercent, setDiscountPercent] = useState("0");
  const [amountNow, setAmountNow] = useState("");
  const [amountTouched, setAmountTouched] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState("cash");
  const [followupOptions, setFollowupOptions] = useState<BillableInvoice[] | null>(null);
  const [loadingFollowups, setLoadingFollowups] = useState(false);
  const [targetInvoiceId, setTargetInvoiceId] = useState("");
  const [performingDoctorId, setPerformingDoctorId] = useState("");

  // حجز الموعد القادم (اختياري) — بيظهر جوه بوكس التحصيل (mode "collect") بعد
  // اختيار الخدمة، بنفس الغرفة والدكتور بتوع الموعد الحالي. مربع الوقت بيعرض بس
  // الفترات المتاحة فعلًا لليوم المختار (getBookedSlotsForRoomDateAction).
  const today = useMemo(() => new Date().toISOString().slice(0, 10), []);
  const [nextApptDate, setNextApptDate] = useState("");
  const [nextApptTime, setNextApptTime] = useState("");
  const [nextApptDuration, setNextApptDuration] = useState(String(slotMinutes));
  const [bookedSlotsForNextAppt, setBookedSlotsForNextAppt] = useState<Set<string>>(new Set());
  const [loadingNextApptSlots, setLoadingNextApptSlots] = useState(false);

  function resetNextAppt() {
    setNextApptDate("");
    setNextApptTime("");
    setNextApptDuration(String(slotMinutes));
    setBookedSlotsForNextAppt(new Set());
  }

  useEffect(() => {
    if (!billingModal || billingModal.mode !== "collect" || !nextApptDate) {
      setBookedSlotsForNextAppt(new Set());
      return;
    }
    let cancelled = false;
    setLoadingNextApptSlots(true);
    getBookedSlotsForRoomDateAction(billingModal.roomId, nextApptDate).then((slots) => {
      if (cancelled) return;
      setBookedSlotsForNextAppt(new Set(slots));
      setLoadingNextApptSlots(false);
    });
    return () => {
      cancelled = true;
    };
  }, [billingModal, nextApptDate]);

  const nextApptAvailableTimes = useMemo(
    () => timeSlots.filter((t) => !bookedSlotsForNextAppt.has(t)),
    [timeSlots, bookedSlotsForNextAppt]
  );

  // لو الوقت المختار بقى محجوز (بعد ما اليوم اتغيّر مثلًا)، امسحه بدل ما يفضل
  // متحدد بقيمة بقت غير متاحة.
  useEffect(() => {
    if (nextApptTime && bookedSlotsForNextAppt.has(nextApptTime)) setNextApptTime("");
  }, [bookedSlotsForNextAppt, nextApptTime]);

  // تزامن الجدول بين أكتر من جهاز/شاشة في الاستقبال — كل 4.5 ثانية، وطالما مفيش
  // مودال حجز أو قايمة يمين مفتوحة (عشان مايقطعش حد وهو بيدخل بيانات)، وطالما
  // التاب ده ظاهر فعليًا (مش تاب تاني مفتوح في الخلفية).
  useEffect(() => {
    const interval = setInterval(() => {
      if (document.visibilityState !== "visible") return;
      if (contextMenu || bookingModal || billingModal) return;
      router.refresh();
    }, 4500);
    return () => clearInterval(interval);
  }, [router, contextMenu, bookingModal, billingModal]);

  // لما يتم اختيار خدمة "متابعة" (كود 0) في بوكس التحصيل، بيتجاب فواتير المريض السابقة
  // اللي لسه عليها مبلغ مستحق، عشان تظهر في الـ drop list يتم الاختيار منها.
  useEffect(() => {
    if (!billingModal || selectedService?.code !== "0") {
      setFollowupOptions(null);
      return;
    }
    let cancelled = false;
    setLoadingFollowups(true);
    getPatientBillableInvoicesAction(billingModal.patientId).then((rows) => {
      if (cancelled) return;
      setFollowupOptions(rows);
      setLoadingFollowups(false);
    });
    return () => {
      cancelled = true;
    };
  }, [billingModal, selectedService]);

  useEffect(() => {
    if (!contextMenu) return;
    function onClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setContextMenu(null);
    }
    window.addEventListener("click", onClickOutside);
    return () => window.removeEventListener("click", onClickOutside);
  }, [contextMenu]);

  useEffect(() => {
    if (highlightApptId === null) return;
    const t = setTimeout(() => setHighlightApptId(null), 2500);
    return () => clearTimeout(t);
  }, [highlightApptId]);

  const liveAppointments = useMemo(() => appointments.filter((a) => a.status !== "cancelled"), [appointments]);

  // خطة كل خانة لكل غرفة: تبدأ موعد (وبتاخد rowSpan) أو خانة اتغطت بموعد فوقها (skip،
  // ملهاش <td> خالص) أو خانة فاضية قابلة للحجز.
  const plans = useMemo(() => {
    const result: Record<number, CellPlan[]> = {};
    for (const room of rooms) {
      const cells: CellPlan[] = timeSlots.map(() => ({ kind: "empty" }));
      const roomAppts = liveAppointments
        .filter((a) => a.room_id === room.id)
        .sort((a, b) => a.start_time.localeCompare(b.start_time));
      for (const appt of roomAppts) {
        const startIdx = timeSlots.indexOf(appt.start_time);
        if (startIdx === -1) continue;
        const span = Math.max(1, Math.round((appt.duration_minutes || slotMinutes) / slotMinutes));
        cells[startIdx] = { kind: "start", appt, span };
        for (let i = startIdx + 1; i < Math.min(startIdx + span, timeSlots.length); i++) {
          cells[i] = { kind: "skip" };
        }
      }
      result[room.id] = cells;
    }
    return result;
  }, [rooms, timeSlots, liveAppointments, slotMinutes]);

  const apptByPatient = useMemo(() => {
    const map = new Map<number, Appt[]>();
    for (const a of liveAppointments) {
      if (!map.has(a.patient_id)) map.set(a.patient_id, []);
      map.get(a.patient_id)!.push(a);
    }
    return map;
  }, [liveAppointments]);

  const searchResults = useMemo(() => {
    const q = search.trim();
    if (!q) return [];
    return patients
      .filter((p) => p.full_name.includes(q) || p.file_number.includes(q))
      .slice(0, 8);
  }, [search, patients]);

  function jumpToAppointment(apptId: number) {
    setHighlightApptId(apptId);
    setSearch("");
    setTimeout(() => {
      document.getElementById(`appt-cell-${apptId}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 50);
  }

  function openBookingModal(roomId: number, roomName: string, startTime: string) {
    setBookingPatientSearch("");
    setBookingSelectedPatient(null);
    setBookingPurposeType("");
    setBookingPurposeServiceId("");
    setBookingModal({ roomId, roomName, startTime });
  }

  function closeBookingModal() {
    setBookingModal(null);
    setBookingPatientSearch("");
    setBookingSelectedPatient(null);
    setBookingPurposeType("");
    setBookingPurposeServiceId("");
  }

  // بحث المريض في بوكس الحجز: بيدور في أي جزء من الاسم (مش أول الاسم بس) — كتابة
  // "عزت" في "أحمد عزت" بترجعه من غير ما تحتاج تكتب "أحمد" الأول. نفس منطق
  // البحث الرئيسي فوق (searchResults) ونفس منطق صفحة "المرضى" (بحث %term%) —
  // موحّد في كل مربعات البحث عن مريض في النظام.
  const bookingPatientResults = useMemo(() => {
    const q = bookingPatientSearch.trim();
    if (!q) return [];
    return patients.filter((p) => p.full_name.includes(q) || p.file_number.includes(q)).slice(0, 8);
  }, [bookingPatientSearch, patients]);

  function submitBooking(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!bookingModal || !bookingSelectedPatient) return;
    const fd = new FormData(e.currentTarget);
    startTransition(() => {
      addAppointmentAction(fd);
    });
    closeBookingModal();
  }

  function setStatus(id: number, status: string) {
    const fd = new FormData();
    fd.set("id", String(id));
    fd.set("status", status);
    startTransition(() => {
      updateAppointmentStatusAction(fd);
    });
    setContextMenu(null);
  }

  // "تم": لو المستخدم عنده صلاحية تحصيل المدفوعات، بيفتح بوكس الفوترة الكامل (السعر
  // بيتحدد وبعدين يتحدد الموعد "تم" لما البوكس يتقفل، والدفع الفعلي بيتسجل). لو معهوش
  // الصلاحية (زي الدكتور)، بيفتحله بوكس "المطلوب دفعه" بس — يحدد الخدمة والسعر المتوقع
  // من غير ما يقدر يسجل دفع فعلي؛ الاستقبال بيشوفها على طول جنب "محتاج تحصيل" في
  // الجدول، وبتتملى تلقائي لما يفتح بوكس التحصيل الحقيقي بأثر رجعي (تسجيل التحصيل).
  function onMarkDone(appt: Appt) {
    setContextMenu(null);
    setServiceNameSearch("");
    setServiceCodeSearch("");
    setTargetInvoiceId("");
    setFollowupOptions(null);
    setPaymentMethod("cash");
    setPerformingDoctorId("");
    resetNextAppt();

    if (!canCollectPayments) {
      setSelectedService(null);
      setPrice("");
      setDiscountPercent("0");
      setAmountNow("");
      setAmountTouched(false);
      setBillingModal({
        apptId: appt.id,
        patientId: appt.patient_id,
        patientName: appt.patient_name,
        mode: "pending",
        roomId: appt.room_id,
        doctorId: appt.doctor_id,
      });
      return;
    }

    // فتح بوكس التحصيل بأثر رجعي لموعد "تم" أصلاً وحدد له الدكتور "المطلوب دفعه" —
    // نملي بيانات الخدمة/السعر من هناك تلقائيًا عشان الاستقبال ميحتاجش يدخلها تاني.
    if (appt.needs_billing && appt.pending_service_id) {
      const svc = services.find((s) => s.id === appt.pending_service_id) ?? null;
      setSelectedService(svc);
      setPrice(appt.pending_price != null ? String(appt.pending_price) : svc ? String(svc.default_price) : "");
      setDiscountPercent(appt.pending_discount_percent != null ? String(appt.pending_discount_percent) : "0");
      setAmountNow("");
      setAmountTouched(false);
    } else {
      setSelectedService(null);
      setPrice("");
      setDiscountPercent("0");
      setAmountNow("");
      setAmountTouched(false);
    }
    setBillingModal({
      apptId: appt.id,
      patientId: appt.patient_id,
      patientName: appt.patient_name,
      mode: "collect",
      roomId: appt.room_id,
      doctorId: appt.doctor_id,
    });
  }

  function closeBillingModal() {
    setBillingModal(null);
    setSelectedService(null);
    resetNextAppt();
  }

  function selectService(s: Service) {
    setSelectedService(s);
    setServiceNameSearch("");
    setServiceCodeSearch("");
    setTargetInvoiceId("");
    if (s.code === "0") {
      // خدمة متابعة: مفيش سعر/خصم — البوكس بيبان فاضي علشان يتكتب فيه اللي هيتدفع دلوقتي.
      setPrice("0");
      setDiscountPercent("0");
      setAmountNow("");
      setAmountTouched(false);
    } else {
      setPrice(String(s.default_price));
      setDiscountPercent("0");
      setAmountNow(String(s.default_price));
      setAmountTouched(false);
    }
  }

  const computedTotal = useMemo(() => {
    const p = Number(price) || 0;
    const d = Math.min(100, Math.max(0, Number(discountPercent) || 0));
    return Math.max(0, p * (1 - d / 100));
  }, [price, discountPercent]);

  // المبلغ المطلوب دفعه بيتحدث تلقائيًا مع السعر/الخصم طالما المستخدم لسه ما عدلش
  // خانة "المبلغ المدفوع دلوقتي" بنفسه يدويًا (بعد اختيار الخدمة).
  useEffect(() => {
    if (!selectedService || selectedService.code === "0" || amountTouched) return;
    setAmountNow(String(Math.round(computedTotal * 100) / 100));
  }, [computedTotal, selectedService, amountTouched]);

  // مربوطين بمربعين منفصلين: البحث بالاسم بيدور على أي جزء من الاسم (substring)، لكن
  // البحث بالكود لازم يكون تطابق تام للرقم بالظبط — عشان كتابة "0" متجيبش أي خدمة
  // كودها فيه صفر زي "100" أو "120" أو "160"، تجيب بس اللي كودها "0" نفسه.
  const filteredServices = useMemo(() => {
    const nameQ = serviceNameSearch.trim();
    const codeQ = serviceCodeSearch.trim();
    if (!nameQ && !codeQ) return [];
    const byName = nameQ ? services.filter((s) => s.name.includes(nameQ)) : [];
    const byCode = codeQ ? services.filter((s) => s.code === codeQ) : [];
    const merged = new Map<number, Service>();
    for (const s of [...byName, ...byCode]) merged.set(s.id, s);
    return [...merged.values()].slice(0, 8);
  }, [serviceNameSearch, serviceCodeSearch, services]);

  const selectedTargetBalance = useMemo(() => {
    if (!targetInvoiceId || !followupOptions) return null;
    return followupOptions.find((f) => String(f.id) === targetInvoiceId) ?? null;
  }, [targetInvoiceId, followupOptions]);

  function submitBilling() {
    if (!billingModal || !selectedService) return;
    const isFollowup = selectedService.code === "0";
    if (isFollowup && !targetInvoiceId) return;

    const fd = new FormData();
    fd.set("appointment_id", String(billingModal.apptId));
    fd.set("service_id", String(selectedService.id));
    fd.set("payment_method", paymentMethod);
    fd.set("amount_now", String(Number(amountNow) || 0));
    if (isFollowup) {
      fd.set("target_invoice_id", targetInvoiceId);
    } else {
      fd.set("price", String(Number(price) || 0));
      fd.set("discount_percent", String(Number(discountPercent) || 0));
    }
    // دفعة 24: الطبيب المساعد بقى بيتبعت في الحالتين (متابعة وغير متابعة) — كان
    // قبل كده محصور بس على غير المتابعة.
    if (performingDoctorId) fd.set("performing_doctor_id", performingDoctorId);

    // حجز الموعد القادم اختياري — بيتسجل بس لو الاستقبال حدد تاريخ ووقت فعلًا،
    // بنفس غرفة ودكتور الموعد الحالي.
    const shouldBookNext = !!(nextApptDate && nextApptTime);
    const nextApptFd = shouldBookNext ? new FormData() : null;
    if (nextApptFd) {
      nextApptFd.set("patient_id", String(billingModal.patientId));
      nextApptFd.set("room_id", String(billingModal.roomId));
      nextApptFd.set("doctor_id", String(billingModal.doctorId));
      nextApptFd.set("appointment_date", nextApptDate);
      nextApptFd.set("start_time", nextApptTime);
      nextApptFd.set("duration_minutes", nextApptDuration);
    }

    startTransition(() => {
      recordAppointmentBillingAction(fd);
      if (nextApptFd) addAppointmentAction(nextApptFd);
    });
    closeBillingModal();
  }

  // بوكس "المطلوب دفعه" (لمين معهوش صلاحية تحصيل المدفوعات) — بيسجل الخدمة والسعر
  // المتوقع كـ pending_* على الموعد نفسه من غير أي زيارة/فاتورة أو دفع فعلي.
  function submitPending() {
    if (!billingModal || !selectedService) return;
    const fd = new FormData();
    fd.set("appointment_id", String(billingModal.apptId));
    fd.set("service_id", String(selectedService.id));
    fd.set("price", String(Number(price) || 0));
    fd.set("discount_percent", String(Number(discountPercent) || 0));
    startTransition(() => {
      recordPendingBillingAction(fd);
    });
    closeBillingModal();
  }

  const durationOptions = [1, 2, 3, 4].map((n) => n * slotMinutes);

  return (
    <div className="space-y-3">
      {/* بحث فوري عن مريض */}
      <div className="relative max-w-sm">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="بحث عن مريض بالاسم أو رقم الملف..."
          className="w-full rounded-md border border-border bg-background px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
        {searchResults.length > 0 && (
          <div className="absolute z-20 mt-1 w-full card-3d rounded-md shadow-lg overflow-hidden">
            {searchResults.map((p) => {
              const todays = apptByPatient.get(p.id) ?? [];
              return (
                <div key={p.id} className="flex items-center justify-between gap-2 px-3 py-2 text-sm border-b border-border last:border-b-0 hover:bg-primary-soft">
                  <div>
                    <div className="font-medium">{p.full_name}</div>
                    <div className="text-xs text-muted">ملف {p.file_number}</div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    {todays.map((a) => (
                      <button
                        key={a.id}
                        type="button"
                        onClick={() => jumpToAppointment(a.id)}
                        className="text-xs px-2 py-1 rounded-md bg-primary-soft text-primary-dark hover:bg-primary hover:text-white"
                        title="روح لموعده في الجدول"
                      >
                        {a.start_time}
                      </button>
                    ))}
                    <Link
                      href={isDoctorView ? `/patients/${p.id}` : `/patients/${p.id}/billing`}
                      className="text-xs px-2 py-1 rounded-md border border-border hover:bg-primary-soft whitespace-nowrap"
                    >
                      فتح الملف
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* legend */}
      <div className="flex flex-wrap items-center gap-3 text-xs text-muted">
        {(["booked", "attended", "done", "no_show"] as const).map((s) => (
          <span key={s} className="flex items-center gap-1">
            <span className={`inline-block w-3 h-3 rounded-sm border ${statusClasses(s)}`} />
            {STATUS_LABELS[s]}
          </span>
        ))}
        {canEdit ? (
          <span className="text-muted">
            دوس على خانة فاضية للحجز، أو دوس بالزر اليمين (أو دوسة طويلة على الموبايل/التابلت) على موعد لتغيير حالته. الموعد اللي "تم" مبيترجعش أو يتلغي.
            {" "}
            <span className="text-danger font-semibold">محتاج تحصيل</span> يعني "تم" بس لسه من غير فوترة
            {canCollectPayments ? " — دوس بالزر اليمين عليه لتسجيل التحصيل." : "."}
            {" "}
            <span className="text-amber-700 font-semibold">محتاج صور جديدة</span> يعني المريض بيعمل متابعة ومفيش
            صور/أشعة اتسجلت له من أكتر من 6 شهور.
          </span>
        ) : (
          <span className="text-muted">عرض فقط — التعديل في الجدول (حجز/تغيير حالة) مقصور على الاستقبال.</span>
        )}
      </div>

      {/* central grid */}
      <div className="card-3d rounded-xl overflow-auto max-h-[70vh]">
        <table className="w-full text-xs border-collapse">
          <thead className="sticky top-0 z-10">
            <tr className="bg-primary-soft text-primary-dark">
              <th className="sticky right-0 z-20 bg-primary-soft px-2 py-2 font-medium whitespace-nowrap">الوقت</th>
              {rooms.map((r) => (
                <th key={r.id} className="px-2 py-2 font-medium whitespace-nowrap min-w-[140px]">
                  {r.name}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {timeSlots.map((time, rowIdx) => (
              <tr key={time}>
                <td className="sticky right-0 bg-surface z-10 px-2 py-1 text-muted whitespace-nowrap border-e border-border">{time}</td>
                {rooms.map((room) => {
                  const plan = plans[room.id]?.[rowIdx] ?? { kind: "empty" as const };
                  if (plan.kind === "skip") return null;
                  if (plan.kind === "start") {
                    const appt = plan.appt;
                    const highlighted = highlightApptId === appt.id;
                    // موعد "تم" وليه فاتورة/زيارة مسجلة بقى سجل نهائي — مينفعش يتلغى أو تتغير
                    // حالته تاني. لو "تم" بس لسه محتاج تحصيل (حصل "تم" من غير بوكس)، بس
                    // اللي عنده صلاحية تحصيل المدفوعات هو اللي يقدر يفتحله قايمة (لتسجيل
                    // التحصيل بأثر رجعي) — أي حد تاني (زي الدكتور اللي حدده) مش هيقدر يعمل
                    // حاجة تانية بيه.
                    const canActOnAppt = canEdit && (appt.status !== "done" || (!!appt.needs_billing && canCollectPayments));
                    return (
                      <td
                        key={room.id}
                        id={`appt-cell-${appt.id}`}
                        rowSpan={plan.span}
                        onContextMenu={(e) => {
                          if (!canActOnAppt) return;
                          e.preventDefault();
                          setContextMenu({
                            apptId: appt.id,
                            x: e.clientX,
                            y: e.clientY,
                            patientName: appt.patient_name,
                            status: appt.status,
                            needsBilling: !!appt.needs_billing,
                          });
                        }}
                        onTouchStart={(e) => {
                          if (!canActOnAppt) return;
                          const touch = e.touches[0];
                          const startX = touch.clientX;
                          const startY = touch.clientY;
                          const timer = setTimeout(() => {
                            touchLongPressRef.current = null;
                            setContextMenu({
                              apptId: appt.id,
                              x: startX,
                              y: startY,
                              patientName: appt.patient_name,
                              status: appt.status,
                              needsBilling: !!appt.needs_billing,
                            });
                          }, LONG_PRESS_MS);
                          touchLongPressRef.current = { timer, startX, startY };
                        }}
                        onTouchMove={(e) => {
                          const state = touchLongPressRef.current;
                          if (!state) return;
                          const touch = e.touches[0];
                          if (
                            Math.abs(touch.clientX - state.startX) > LONG_PRESS_MOVE_CANCEL_PX ||
                            Math.abs(touch.clientY - state.startY) > LONG_PRESS_MOVE_CANCEL_PX
                          ) {
                            clearTimeout(state.timer);
                            touchLongPressRef.current = null;
                          }
                        }}
                        onTouchEnd={() => {
                          const state = touchLongPressRef.current;
                          if (state) {
                            clearTimeout(state.timer);
                            touchLongPressRef.current = null;
                          }
                        }}
                        onTouchCancel={() => {
                          const state = touchLongPressRef.current;
                          if (state) {
                            clearTimeout(state.timer);
                            touchLongPressRef.current = null;
                          }
                        }}
                        className={`align-top p-1.5 border ${statusClasses(appt.status)} transition-shadow ${
                          canActOnAppt ? "cursor-context-menu [-webkit-touch-callout:none] select-none" : "cursor-default"
                        } ${highlighted ? "ring-2 ring-primary ring-offset-1" : ""}`}
                      >
                        <Link
                          href={
                            isDoctorView
                              ? isOrthoAppt(appt)
                                ? `/patients/${appt.patient_id}/orthodontics`
                                : `/patients/${appt.patient_id}`
                              : `/patients/${appt.patient_id}/billing`
                          }
                          onClick={(e) => e.stopPropagation()}
                          className="font-semibold truncate block hover:underline"
                          title={isDoctorView ? (isOrthoAppt(appt) ? "فتح شارت التقويم" : "فتح الملف الطبي") : "فتح الملف المالي"}
                        >
                          {appt.patient_name}
                        </Link>
                        {purposeLabelOf(appt) && (
                          <Link
                            href={purposeHrefOf(appt, isDoctorView)}
                            onClick={(e) => e.stopPropagation()}
                            className="text-[10px] text-primary truncate block hover:underline"
                            title={isDoctorView ? "فتح الملف المرتبط بالخدمة" : "فتح الملف المالي"}
                          >
                            {purposeLabelOf(appt)}
                          </Link>
                        )}
                        <div className="text-[10px] truncate">{appt.doctor_name}</div>
                        <div className="text-[10px] opacity-80">{STATUS_LABELS[appt.status]}</div>
                        {appt.status === "done" && appt.needs_billing && (
                          <div className="text-[10px] font-semibold text-danger">
                            محتاج تحصيل
                            {appt.pending_service_name && (
                              <>
                                {" "}
                                — {appt.pending_service_name} ·{" "}
                                {Math.max(0, (appt.pending_price ?? 0) * (1 - (appt.pending_discount_percent ?? 0) / 100)).toFixed(0)} ج.م
                              </>
                            )}
                          </div>
                        )}
                        {appt.needs_new_photos && (
                          <div className="text-[10px] font-semibold text-amber-700">محتاج صور جديدة (من أكتر من 6 شهور)</div>
                        )}
                        {appt.notes && <div className="text-[10px] opacity-70 truncate">{appt.notes}</div>}
                      </td>
                    );
                  }
                  return (
                    <td
                      key={room.id}
                      onClick={canEdit ? () => openBookingModal(room.id, room.name, time) : undefined}
                      className={`border border-border h-7 ${canEdit ? "cursor-pointer hover:bg-primary-soft/50" : ""}`}
                      title={canEdit ? "دوس للحجز" : undefined}
                    />
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* right-click context menu */}
      {contextMenu && (
        <div
          ref={menuRef}
          style={{ position: "fixed", top: contextMenu.y, left: contextMenu.x }}
          className="z-50 card-3d rounded-md shadow-lg py-1 text-sm min-w-[140px]"
        >
          <div className="px-3 py-1.5 text-xs text-muted border-b border-border truncate">{contextMenu.patientName}</div>
          {contextMenu.status === "done" ? (
            // بيوصل هنا بس لو الموعد "تم" ومحتاج تحصيل ومعاه صلاحية التحصيل (اتفحص قبل
            // فتح القايمة أصلاً) — الخيار الوحيد المتاح هو تسجيل التحصيل بأثر رجعي، من غير
            // أي إمكانية للرجوع لحالة تانية أو الإلغاء.
            <button
              type="button"
              onClick={() => {
                const appt = liveAppointments.find((a) => a.id === contextMenu.apptId);
                if (!appt) return;
                onMarkDone(appt);
              }}
              className="w-full text-right px-3 py-1.5 hover:bg-primary-soft"
            >
              تسجيل التحصيل
            </button>
          ) : (
            <>
              <button type="button" onClick={() => setStatus(contextMenu.apptId, "attended")} className="w-full text-right px-3 py-1.5 hover:bg-primary-soft">
                حضر
              </button>
              <button
                type="button"
                onClick={() => {
                  const appt = liveAppointments.find((a) => a.id === contextMenu.apptId);
                  if (!appt) return;
                  onMarkDone(appt);
                }}
                className="w-full text-right px-3 py-1.5 hover:bg-primary-soft"
              >
                تم
              </button>
              <button
                type="button"
                onClick={() => setStatus(contextMenu.apptId, "cancelled")}
                className="w-full text-right px-3 py-1.5 hover:bg-danger-soft text-danger"
              >
                إلغاء (تفضية الخانة)
              </button>
            </>
          )}
          <button
            type="button"
            onClick={() => {
              const appt = liveAppointments.find((a) => a.id === contextMenu.apptId);
              if (!appt) return;
              openPurposeModal(appt);
            }}
            className="w-full text-right px-3 py-1.5 hover:bg-primary-soft border-t border-border"
          >
            تحديد/تغيير الخدمة
          </button>
        </div>
      )}

      {/* booking modal */}
      {bookingModal && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={closeBookingModal}>
          <form
            onClick={(e) => e.stopPropagation()}
            onSubmit={submitBooking}
            className="card-3d rounded-xl p-5 w-full max-w-sm space-y-3"
          >
            <h3 className="font-semibold">
              حجز — {bookingModal.roomName} · {bookingModal.startTime}
            </h3>
            <input type="hidden" name="appointment_date" value={date} />
            <input type="hidden" name="room_id" value={bookingModal.roomId} />
            <input type="hidden" name="start_time" value={bookingModal.startTime} />

            <div className="relative">
              <label className="block text-xs text-muted mb-1">المريض</label>
              <input type="hidden" name="patient_id" value={bookingSelectedPatient?.id ?? ""} />
              {bookingSelectedPatient ? (
                <div className="flex items-center justify-between gap-2 rounded-md border border-border bg-background px-2 py-1.5 text-sm">
                  <span>
                    {bookingSelectedPatient.full_name} ({bookingSelectedPatient.file_number})
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setBookingSelectedPatient(null);
                      setBookingPatientSearch("");
                    }}
                    className="text-xs text-primary hover:underline shrink-0"
                  >
                    تغيير
                  </button>
                </div>
              ) : (
                <>
                  <input
                    type="text"
                    autoFocus
                    value={bookingPatientSearch}
                    onChange={(e) => setBookingPatientSearch(e.target.value)}
                    placeholder="اكتب اسم المريض أو رقم الملف..."
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                  {bookingPatientResults.length > 0 && (
                    <div className="absolute z-10 mt-1 w-full card-3d rounded-md shadow-lg overflow-hidden max-h-48 overflow-y-auto">
                      {bookingPatientResults.map((p) => (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => {
                            setBookingSelectedPatient(p);
                            setBookingPatientSearch("");
                          }}
                          className="w-full text-right px-3 py-1.5 text-sm hover:bg-primary-soft flex items-center justify-between gap-2"
                        >
                          <span>{p.full_name}</span>
                          <span className="text-xs text-muted shrink-0">{p.file_number}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>

            <div>
              <label className="block text-xs text-muted mb-1">الدكتور</label>
              {/* افتراضيًا بيبقى محدد صاحب شيفت الغرفة دي النهاردة (لو موجود) — التحصيل
                  بعد كده هيورّث نفس الدكتور ده تلقائيًا. التغيير هنا وقت الحجز بس هو
                  الطريقة الوحيدة (لحالة مريض جاي فجأة لدكتور تاني غير صاحب الشيفت). */}
              <select
                name="doctor_id"
                required
                defaultValue={roomShiftDoctorIds[bookingModal.roomId] ?? ""}
                className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
              >
                <option value="">اختر دكتور</option>
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.full_name}
                    {roomShiftDoctorIds[bookingModal.roomId] === d.id ? " (صاحب الشيفت)" : ""}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-muted mb-1">المدة</label>
              <select name="duration_minutes" defaultValue={slotMinutes} className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm">
                {durationOptions.map((m) => (
                  <option key={m} value={m}>
                    {m} دقيقة
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-muted mb-1">ملاحظات (اختياري)</label>
              <input name="notes" className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm" />
            </div>

            <div>
              <label className="block text-xs text-muted mb-1">المريض جاي يعمل إيه؟ (اختياري)</label>
              <input type="hidden" name="purpose_type" value={bookingPurposeType} />
              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => setBookingPurposeType("")}
                  className={`px-2.5 py-1 rounded-md border text-xs ${bookingPurposeType === "" ? "btn-3d-primary border-transparent" : "border-border hover:bg-primary-soft"}`}
                >
                  بدون تحديد
                </button>
                <button
                  type="button"
                  onClick={() => setBookingPurposeType("bonding_upper")}
                  className={`px-2.5 py-1 rounded-md border text-xs ${bookingPurposeType === "bonding_upper" ? "btn-3d-primary border-transparent" : "border-border hover:bg-primary-soft"}`}
                >
                  تركيب أول تقويم
                </button>
                <button
                  type="button"
                  onClick={() => setBookingPurposeType("bonding_lower")}
                  className={`px-2.5 py-1 rounded-md border text-xs ${bookingPurposeType === "bonding_lower" ? "btn-3d-primary border-transparent" : "border-border hover:bg-primary-soft"}`}
                >
                  تركيب تاني تقويم
                </button>
                <button
                  type="button"
                  onClick={() => setBookingPurposeType("service")}
                  className={`px-2.5 py-1 rounded-md border text-xs ${bookingPurposeType === "service" ? "btn-3d-primary border-transparent" : "border-border hover:bg-primary-soft"}`}
                >
                  خدمة تانية
                </button>
              </div>
              {bookingPurposeType === "service" && (
                <div className="mt-1.5">
                  <ServiceCombobox name="purpose_service_id" services={services} value={bookingPurposeServiceId} onChange={setBookingPurposeServiceId} />
                </div>
              )}
            </div>

            <div className="flex gap-2 justify-end pt-1">
              <button type="button" onClick={closeBookingModal} className="px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft">
                إلغاء
              </button>
              <button
                type="submit"
                disabled={!bookingSelectedPatient}
                className="px-3 py-1.5 rounded-md btn-3d-primary text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
              >
                + حجز
              </button>
            </div>
          </form>
        </div>
      )}

      {/* بوكس "المريض جاي يعمل إيه" — تحديد/تغيير الخدمة لموعد موجود بالفعل، بيتفتح من
          قايمة كليك يمين/دوسة طويلة على خانة الموعد (دفعة 26). */}
      {purposeModal && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={closePurposeModal}>
          <div onClick={(e) => e.stopPropagation()} className="card-3d rounded-xl p-5 w-full max-w-sm space-y-3">
            <h3 className="font-semibold">المريض جاي يعمل إيه؟ — {purposeModal.patientName}</h3>
            <div className="flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={() => setPurposeModalType("")}
                className={`px-2.5 py-1 rounded-md border text-xs ${purposeModalType === "" ? "btn-3d-primary border-transparent" : "border-border hover:bg-primary-soft"}`}
              >
                بدون تحديد
              </button>
              <button
                type="button"
                onClick={() => setPurposeModalType("bonding_upper")}
                className={`px-2.5 py-1 rounded-md border text-xs ${purposeModalType === "bonding_upper" ? "btn-3d-primary border-transparent" : "border-border hover:bg-primary-soft"}`}
              >
                تركيب أول تقويم
              </button>
              <button
                type="button"
                onClick={() => setPurposeModalType("bonding_lower")}
                className={`px-2.5 py-1 rounded-md border text-xs ${purposeModalType === "bonding_lower" ? "btn-3d-primary border-transparent" : "border-border hover:bg-primary-soft"}`}
              >
                تركيب تاني تقويم
              </button>
              <button
                type="button"
                onClick={() => setPurposeModalType("service")}
                className={`px-2.5 py-1 rounded-md border text-xs ${purposeModalType === "service" ? "btn-3d-primary border-transparent" : "border-border hover:bg-primary-soft"}`}
              >
                خدمة تانية
              </button>
            </div>
            {purposeModalType === "service" && (
              <ServiceCombobox name="purpose_service_id" services={services} value={purposeModalServiceId} onChange={setPurposeModalServiceId} />
            )}
            <div className="flex gap-2 justify-end pt-1">
              <button type="button" onClick={closePurposeModal} className="px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft">
                إلغاء
              </button>
              <button
                type="button"
                onClick={savePurposeModal}
                disabled={purposeModalPending}
                className="px-3 py-1.5 rounded-md btn-3d-primary text-sm font-medium disabled:opacity-50"
              >
                حفظ
              </button>
            </div>
          </div>
        </div>
      )}

      {/* بوكس التحصيل — بيتفتح لما يتم اختيار "تم" (لو المستخدم عنده صلاحية تحصيل المدفوعات) */}
      {billingModal && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={closeBillingModal}>
          <div onClick={(e) => e.stopPropagation()} className="card-3d rounded-xl p-5 w-full max-w-sm space-y-3 max-h-[90vh] overflow-y-auto">
            <h3 className="font-semibold">
              {billingModal.mode === "collect" ? "تحصيل" : "المطلوب دفعه"} — {billingModal.patientName}
            </h3>
            {billingModal.mode === "pending" && (
              <p className="text-xs text-muted -mt-2">
                حدد الخدمة والسعر المتوقع بس من غير تسجيل دفع فعلي — الاستقبال هيشوفها ويسجل التحصيل الفعلي بعدين.
              </p>
            )}

            {/* اختيار الخدمة بالبحث بالاسم أو الكود */}
            <div className="relative">
              <label className="block text-xs text-muted mb-1">الخدمة</label>
              {selectedService ? (
                <div className="flex items-center justify-between gap-2 rounded-md border border-border bg-background px-2 py-1.5 text-sm">
                  <span>
                    {selectedService.name} {selectedService.code ? `(${selectedService.code})` : ""}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedService(null);
                      setFollowupOptions(null);
                      setTargetInvoiceId("");
                      setServiceNameSearch("");
                      setServiceCodeSearch("");
                    }}
                    className="text-xs text-primary hover:underline shrink-0"
                  >
                    تغيير
                  </button>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      autoFocus
                      value={serviceNameSearch}
                      onChange={(e) => setServiceNameSearch(e.target.value)}
                      placeholder="بحث بالاسم..."
                      className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                    <input
                      type="text"
                      value={serviceCodeSearch}
                      onChange={(e) => setServiceCodeSearch(e.target.value)}
                      placeholder="بحث بالكود (بالظبط)..."
                      className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  {filteredServices.length > 0 && (
                    <div className="absolute z-10 mt-1 w-full card-3d rounded-md shadow-lg overflow-hidden max-h-48 overflow-y-auto">
                      {filteredServices.map((s) => (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => selectService(s)}
                          className="w-full text-right px-3 py-1.5 text-sm hover:bg-primary-soft flex items-center justify-between gap-2"
                        >
                          <span>{s.name}</span>
                          <span className="text-xs text-muted shrink-0">
                            {s.code ? `#${s.code}` : ""} {s.code !== "0" ? `— ${s.default_price} ج.م` : ""}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>

            {/* بوكس "المطلوب دفعه" (مين معهوش صلاحية تحصيل المدفوعات) — سعر وخصم بس،
                من غير مبلغ مدفوع أو وسيلة دفع، لأنه مش بيسجل دفع فعلي. */}
            {selectedService && billingModal.mode === "pending" && (
              <>
                <div>
                  <label className="block text-xs text-muted mb-1">السعر</label>
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs text-muted mb-1">خصم (%)</label>
                  <input
                    type="number"
                    step="1"
                    min={0}
                    max={100}
                    value={discountPercent}
                    onChange={(e) => setDiscountPercent(e.target.value)}
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
                <div className="text-sm">
                  المطلوب دفعه: <span className="font-semibold">{computedTotal.toFixed(0)} ج.م</span>
                </div>
              </>
            )}

            {selectedService && billingModal.mode === "collect" && selectedService.code === "0" && (
              <>
                <div>
                  <label className="block text-xs text-muted mb-1">الخدمة الأصلية (اللي هتتخصم منها الدفعة)</label>
                  {loadingFollowups ? (
                    <div className="text-xs text-muted">جاري التحميل...</div>
                  ) : followupOptions && followupOptions.length > 0 ? (
                    <select
                      value={targetInvoiceId}
                      onChange={(e) => setTargetInvoiceId(e.target.value)}
                      className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                    >
                      <option value="">اختر خدمة</option>
                      {followupOptions.map((f) => (
                        <option key={f.id} value={f.id}>
                          {f.service_name} — {f.visit_date} — الباقي {f.balance.toFixed(0)} ج.م
                        </option>
                      ))}
                    </select>
                  ) : (
                    <div className="text-xs text-danger">مفيش فواتير سابقة لسه عليها مبلغ مستحق لهذا المريض.</div>
                  )}
                </div>

                {selectedTargetBalance && (
                  <div className="text-sm">
                    الباقي المستحق: <span className="text-danger font-semibold">{selectedTargetBalance.balance.toFixed(0)} ج.م</span>
                  </div>
                )}

                {/* دفعة 24: الطبيب المساعد ممكن يتغيّر مع كل دفعة متابعة. */}
                {canEditAssistantDoctor && (
                  <div>
                    <label className="block text-xs text-muted mb-1">الطبيب المساعد (لو مختلف)</label>
                    <select
                      value={performingDoctorId}
                      onChange={(e) => setPerformingDoctorId(e.target.value)}
                      className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                    >
                      <option value="">نفس دكتور الموعد</option>
                      {doctors.map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.full_name}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                <div>
                  <label className="block text-xs text-muted mb-1">المبلغ المدفوع دلوقتي</label>
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    value={amountNow}
                    onChange={(e) => setAmountNow(e.target.value)}
                    placeholder="0"
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
              </>
            )}

            {selectedService && billingModal.mode === "collect" && selectedService.code !== "0" && (
              <>
                <div>
                  <label className="block text-xs text-muted mb-1">السعر</label>
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs text-muted mb-1">خصم (%)</label>
                  <input
                    type="number"
                    step="1"
                    min={0}
                    max={100}
                    value={discountPercent}
                    onChange={(e) => setDiscountPercent(e.target.value)}
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
                <div className="text-sm">
                  المطلوب دفعه: <span className="font-semibold">{computedTotal.toFixed(0)} ج.م</span>
                </div>
                <div>
                  <label className="block text-xs text-muted mb-1">المبلغ المدفوع دلوقتي</label>
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    value={amountNow}
                    onChange={(e) => {
                      setAmountTouched(true);
                      setAmountNow(e.target.value);
                    }}
                    className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                  />
                </div>
                {canEditAssistantDoctor && (
                  <div>
                    <label className="block text-xs text-muted mb-1">الطبيب المساعد (لو مختلف)</label>
                    <select
                      value={performingDoctorId}
                      onChange={(e) => setPerformingDoctorId(e.target.value)}
                      className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                    >
                      <option value="">نفس دكتور الموعد</option>
                      {doctors.map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.full_name}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </>
            )}

            {selectedService && billingModal.mode === "collect" && (
              <div>
                <label className="block text-xs text-muted mb-1">وسيلة الدفع</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm"
                >
                  {PAYMENT_METHODS.map((m) => (
                    <option key={m.value} value={m.value}>
                      {m.label}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* حجز الموعد القادم — اختياري، بيظهر بعد اختيار الخدمة والدفع في بوكس
                التحصيل الحقيقي بس (مش بوكس "المطلوب دفعه"). نفس غرفة ودكتور الموعد
                الحالي؛ مربع الوقت بيعرض بس الفترات المتاحة فعلًا لليوم المختار. */}
            {selectedService && billingModal.mode === "collect" && (
              <div className="border-t border-dashed border-border pt-3 space-y-2">
                <label className="block text-xs font-medium">حجز الموعد القادم (اختياري)</label>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[10px] text-muted mb-1">التاريخ</label>
                    <input
                      type="date"
                      value={nextApptDate}
                      min={today}
                      onChange={(e) => {
                        setNextApptDate(e.target.value);
                        setNextApptTime("");
                      }}
                      className="w-full rounded-md border border-border bg-background px-1.5 py-1.5 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-muted mb-1">الوقت</label>
                    <select
                      value={nextApptTime}
                      onChange={(e) => setNextApptTime(e.target.value)}
                      disabled={!nextApptDate || loadingNextApptSlots}
                      className="w-full rounded-md border border-border bg-background px-1.5 py-1.5 text-xs disabled:opacity-50"
                    >
                      <option value="">
                        {!nextApptDate ? "اختر تاريخ الأول" : loadingNextApptSlots ? "جاري التحميل..." : "اختر وقت"}
                      </option>
                      {nextApptAvailableTimes.map((t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] text-muted mb-1">عدد الفترات</label>
                    <select
                      value={nextApptDuration}
                      onChange={(e) => setNextApptDuration(e.target.value)}
                      className="w-full rounded-md border border-border bg-background px-1.5 py-1.5 text-xs"
                    >
                      {durationOptions.map((m) => (
                        <option key={m} value={m}>
                          {m} د
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                {nextApptDate && !loadingNextApptSlots && nextApptAvailableTimes.length === 0 && (
                  <div className="text-[10px] text-danger">مفيش فترات متاحة في اليوم ده لنفس الغرفة.</div>
                )}
              </div>
            )}

            <div className="flex items-center justify-between gap-2 pt-1 flex-wrap">
              <button
                type="button"
                onClick={() => {
                  setStatus(billingModal.apptId, "done");
                  closeBillingModal();
                }}
                className="text-xs text-muted hover:underline"
              >
                تخطي وتحديد &quot;تم&quot; من غير تسجيل مالي
              </button>
              <div className="flex gap-2">
                <button type="button" onClick={closeBillingModal} className="px-3 py-1.5 rounded-md border border-border text-sm hover:bg-primary-soft">
                  إلغاء
                </button>
                {billingModal.mode === "pending" ? (
                  <button
                    type="button"
                    disabled={!selectedService}
                    onClick={submitPending}
                    className="px-3 py-1.5 rounded-md btn-3d-primary text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    تسجيل المطلوب و&quot;تم&quot;
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={!selectedService || (selectedService.code === "0" && !targetInvoiceId)}
                    onClick={submitBilling}
                    className="px-3 py-1.5 rounded-md btn-3d-primary text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    تسجيل وإنهاء
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
