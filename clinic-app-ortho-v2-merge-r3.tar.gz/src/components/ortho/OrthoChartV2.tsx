"use client";

// ===================================================================
// شارت التقويم v2 — صفحة 1 كاملة (النسخة الحقيقية، دمج 2026-08-27)
// ===================================================================
// نفس التصميم اللي المستخدم راجعه ووافق عليه في البروتوتايب المعزول
// (design_id Canva: DAHTZKEWWQI) — الفرق إن كل حاجة دلوقتي مربوطة بقاعدة
// البيانات الحقيقية للمريض: أعلى الصفحة + Treatment Plan فورم واحد
// (saveOrthoTopSectionAction)، الصور والأشعة بتستخدم نفس الداتا/actions
// الحقيقية اللي في ملف المريض العادي (addImageGroupAction/deleteImageAction)
// لكن من خلال عرض إنجليزي/LTR مستقل (OrthoImageGallery/OrthoAddImageGroupForm)
// بدل مكون المريض العادي العربي/RTL — الشارت ده المفروض يفضل إنجليزي طول
// الوقت مهما كانت لغة باقي السيستم (طلب صريح من المستخدم بعد أول نشر حقيقي،
// راجع claude/orthodontic-chart-v2-preview-status.md تحديث 12). والـInventory
// list/Interactive report بيقروا من ortho_inventory_deductions/audit_log الحقيقيين.

import { useState, useRef, useMemo, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import InteractiveToothChart, { type ToothState } from "./InteractiveToothChart";
import DiagnosticChart, { type DiagnosticChartData } from "./DiagnosticChart";
import FollowUpsTable, { type OrthoDoctorOption, type OrthoOptionLists, type OrthoVisitRow } from "./FollowUpsTable";
import OrthoImageGallery from "./OrthoImageGallery";
import OrthoAddImageGroupForm from "./OrthoAddImageGroupForm";
import { saveOrthoTopSectionAction, undoOrthoInventoryDeductionAction } from "@/app/patients/[id]/orthodontics/ortho-v2-actions";

const MOCK_BRACKET_TYPES = ["American", "Ormco", "3M"];
const PRESCRIPTION_OPTIONS = ["Roth", "MBT", "Andrews"];
const SLOT_OPTIONS = ["18", "22"];
const POSITIONS = ["1", "2", "3", "4", "5", "6", "7", "8"];

type ChartView = "interactive" | "diagnostic";

interface ExtractionState {
  ur: string;
  ul: string;
  lr: string;
  ll: string;
}

export interface InventoryLogEntry {
  id: number;
  label: string;
  qty: number;
  teeth: number[] | null;
  date: string;
  undoneAt: string | null;
}

export interface ChartEventEntry {
  id: number;
  date: string;
  text: string;
}

export interface ImageGroupWithFiles {
  id: number;
  label: string | null;
  taken_at: string;
  images: { id: number; file_path: string; rotation: number }[];
}

function Dropdown({
  name,
  defaultValue,
  options,
  placeholder = "—",
  disabled,
}: {
  name: string;
  defaultValue: string | null;
  options: string[];
  placeholder?: string;
  disabled?: boolean;
}) {
  return (
    <select name={name} defaultValue={defaultValue ?? ""} disabled={disabled} className="rounded-md border border-border bg-background px-2 py-1 text-xs disabled:opacity-60">
      <option value="">{placeholder}</option>
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  );
}

export default function OrthoChartV2({
  patientId,
  patientName,
  fileNumber,
  patientAge,
  patientPhone,
  editable,
  canEditAfterSave,
  canUndoInventory,
  defaultDoctorId,
  doctors,
  options,
  chart,
  toothStates,
  stripCounts,
  miniscrews,
  diagnostic,
  visits,
  inventoryLog,
  chartEvents,
  imageGroups,
}: {
  patientId: number;
  patientName: string;
  fileNumber: string;
  patientAge: number | null;
  patientPhone: string | null;
  editable: boolean;
  canEditAfterSave: boolean;
  canUndoInventory: boolean;
  defaultDoctorId: number | null;
  doctors: OrthoDoctorOption[];
  options: OrthoOptionLists & { anchorageDevices: string[] };
  chart: {
    bracket_type: string | null;
    prescription: string | null;
    slot: string | null;
    chief_complaint: string | null;
    extraction_quadrants: ExtractionState | null;
    anchorage_device: string | null;
    treatment_note: string | null;
  };
  toothStates: Record<number, ToothState>;
  stripCounts: Record<string, number>;
  miniscrews: Record<string, boolean>;
  diagnostic: DiagnosticChartData;
  visits: OrthoVisitRow[];
  inventoryLog: InventoryLogEntry[];
  chartEvents: ChartEventEntry[];
  imageGroups: ImageGroupWithFiles[];
}) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [view, setView] = useState<ChartView>("interactive");
  const [showInventoryModal, setShowInventoryModal] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);

  function handleTopSectionSubmit(formData: FormData) {
    startTransition(async () => {
      const res = await saveOrthoTopSectionAction(formData);
      if (!res.ok) window.alert(res.reason || "حصل خطأ، حاول تاني.");
      router.refresh();
    });
  }

  function undoDeduction(id: number) {
    if (!window.confirm("Undo this inventory deduction?")) return;
    startTransition(async () => {
      const res = await undoOrthoInventoryDeductionAction({ patientId, deductionId: id });
      if (!res.ok) window.alert(res.reason || "حصل خطأ، حاول تاني.");
      router.refresh();
    });
  }

  const inventoryByDate = useMemo(() => {
    const map = new Map<string, InventoryLogEntry[]>();
    inventoryLog.forEach((l) => {
      const key = l.date || "—";
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(l);
    });
    return Array.from(map.entries());
  }, [inventoryLog]);

  const chartEventsByDate = useMemo(() => {
    const map = new Map<string, ChartEventEntry[]>();
    chartEvents.forEach((ev) => {
      const key = ev.date || "—";
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(ev);
    });
    return Array.from(map.entries());
  }, [chartEvents]);

  const activeInventoryCount = inventoryLog.filter((l) => !l.undoneAt).length;

  return (
    <div dir="ltr" className={`space-y-4 ${isPending ? "opacity-70 pointer-events-none" : ""}`}>
      <form ref={formRef} action={handleTopSectionSubmit} className="space-y-4">
        <input type="hidden" name="patient_id" value={patientId} />

        {/* Title + back link — سطر واحد مضغوط بدل الهيدر الكبير اللي كان في
            page.tsx (كان مكرر ومساحته كبيرة، طلب المستخدم بعد أول نشر حقيقي). */}
        <div className="flex items-center gap-3 flex-wrap">
          <Link href={`/patients/${patientId}`} className="text-xs text-primary hover:underline shrink-0">
            ← Back to patient file
          </Link>
          <h1 className="text-lg font-bold">Orthodontic chart</h1>
          <span className="text-xs text-muted">
            File #{fileNumber}
            {patientAge != null ? ` · Age: ${patientAge}` : ""}
            {patientPhone ? ` · Phone: ${patientPhone}` : ""}
          </span>
        </div>

        {/* Name + Brackets/Rx/Slot */}
        <div className="card-3d rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="text-sm">
              <span className="text-muted">Name: </span>
              <span className="font-semibold">{patientName}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-muted">Brackets:</span>
              <Dropdown name="bracket_type" defaultValue={chart.bracket_type} options={MOCK_BRACKET_TYPES} disabled={!editable} />
              <Dropdown name="prescription" defaultValue={chart.prescription} options={PRESCRIPTION_OPTIONS} disabled={!editable} />
              <Dropdown name="slot" defaultValue={chart.slot} options={SLOT_OPTIONS} disabled={!editable} />
            </div>
          </div>
        </div>

        {/* Photos & X-rays — نفس الداتا الحقيقية اللي في ملف المريض العادي (صورة
            المريض واحدة بغض النظر عن الشاشة)، لكن عرض إنجليزي/LTR مستقل يطابق
            تصميم الشارت الجديد. اتنقل هنا (فوق الـChief Complaint) زي الترتيب
            الأصلي في البروتوتايب. */}
        <div className="card-3d rounded-xl p-5 space-y-3" dir="ltr">
          <h2 className="font-semibold">Photos &amp; X-rays</h2>
          <OrthoImageGallery groups={imageGroups} patientId={patientId} editable={editable} />
          {editable && <OrthoAddImageGroupForm patientId={patientId} />}
        </div>

        {/* Chief Complaint + Treatment Plan */}
        <div className="grid sm:grid-cols-2 gap-4">
          <div className="card-3d rounded-xl p-5 space-y-1.5">
            <div className="text-sm font-semibold">Chief Complaint</div>
            <textarea
              name="chief_complaint"
              defaultValue={chart.chief_complaint ?? ""}
              disabled={!editable}
              placeholder="Eg.: Spacing"
              rows={3}
              className="w-full resize-none rounded-md border border-border bg-background px-2 py-1.5 text-sm placeholder:text-muted disabled:opacity-60"
            />
            <div className="flex flex-col items-start gap-1">
              <button type="button" onClick={() => setShowInventoryModal(true)} className="text-sm font-medium text-primary underline hover:no-underline">
                Inventory list{activeInventoryCount > 0 ? ` (${activeInventoryCount})` : ""}
              </button>
              <button type="button" onClick={() => setShowReportModal(true)} className="text-sm font-medium text-primary underline hover:no-underline">
                Interactive report{chartEvents.length > 0 ? ` (${chartEvents.length})` : ""}
              </button>
            </div>
          </div>

          <div className="card-3d rounded-xl p-5 space-y-3">
            <div className="text-sm font-semibold">Treatment Plan</div>

            <div className="flex items-start gap-6 flex-wrap">
              <div className="space-y-1.5">
                <div className="text-xs text-muted">Extraction:</div>
                <div className="relative inline-block">
                  <div className="grid grid-cols-2 gap-x-3">
                    <div className="pb-1.5 flex justify-center" style={{ borderBottom: "2px solid #1c2521" }}>
                      <Dropdown name="extraction_ur" defaultValue={chart.extraction_quadrants?.ur ?? null} options={POSITIONS} disabled={!editable} />
                    </div>
                    <div className="pb-1.5 flex justify-center" style={{ borderBottom: "2px solid #1c2521" }}>
                      <Dropdown name="extraction_ul" defaultValue={chart.extraction_quadrants?.ul ?? null} options={POSITIONS} disabled={!editable} />
                    </div>
                    <div className="pt-1.5 flex justify-center">
                      <Dropdown name="extraction_lr" defaultValue={chart.extraction_quadrants?.lr ?? null} options={POSITIONS} disabled={!editable} />
                    </div>
                    <div className="pt-1.5 flex justify-center">
                      <Dropdown name="extraction_ll" defaultValue={chart.extraction_quadrants?.ll ?? null} options={POSITIONS} disabled={!editable} />
                    </div>
                  </div>
                  <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 pointer-events-none" style={{ width: "2px", background: "#1c2521" }} />
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="text-xs text-muted">Anchorage:</div>
                <Dropdown name="anchorage_device" defaultValue={chart.anchorage_device} options={options.anchorageDevices} disabled={!editable} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="text-xs text-muted">Notes (free text)</div>
              <textarea
                name="treatment_note"
                defaultValue={chart.treatment_note ?? ""}
                disabled={!editable}
                rows={2}
                className="w-full resize-none rounded-md border border-border bg-background px-2 py-1.5 text-sm disabled:opacity-60"
              />
            </div>
          </div>
        </div>

        {editable && (
          <button type="submit" className="px-4 py-2 rounded-md text-sm font-medium btn-3d-primary">
            Save
          </button>
        )}
      </form>

      {/* Diagnosis / Interactive chart toggle */}
      <div className="card-3d rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <button type="button" onClick={() => setView((v) => (v === "interactive" ? "diagnostic" : "interactive"))} className="text-xs text-primary underline hover:no-underline">
            {view === "interactive" ? "Diagnostic chart" : "Interactive chart"}
          </button>
          <h3 className="font-bold">{view === "interactive" ? "Interactive chart" : "Diagnosis:"}</h3>
        </div>

        <div style={{ display: view === "interactive" ? "block" : "none" }}>
          <InteractiveToothChart patientId={patientId} editable={editable} teeth={toothStates} stripCounts={stripCounts} miniscrews={miniscrews} />
        </div>
        <div style={{ display: view === "diagnostic" ? "block" : "none" }}>
          <DiagnosticChart patientId={patientId} editable={editable} data={diagnostic} />
        </div>
      </div>

      <FollowUpsTable
        patientId={patientId}
        editable={editable}
        canEditAfterSave={canEditAfterSave}
        defaultDoctorId={defaultDoctorId}
        doctors={doctors}
        options={options}
        visits={visits}
      />

      {showInventoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={() => setShowInventoryModal(false)}>
          <div className="card-3d rounded-xl p-5 w-full max-w-md max-h-[80vh] flex flex-col space-y-3" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold">Inventory list</h3>
              <button type="button" onClick={() => setShowInventoryModal(false)} className="text-muted text-lg leading-none px-1">
                ×
              </button>
            </div>
            <p className="text-xs text-muted">Materials used for this patient since treatment started.</p>
            <div className="overflow-y-auto space-y-3">
              {inventoryLog.length === 0 && <p className="text-xs text-muted">Nothing used yet.</p>}
              {inventoryByDate.map(([date, entries]) => (
                <div key={date} className="rounded-lg border border-border p-2 space-y-1.5">
                  <div className="text-[11px] font-semibold text-muted">📅 {date}</div>
                  {entries.map((l) => (
                    <div key={l.id} className={`flex items-center justify-between gap-2 text-xs rounded-md border border-border px-2 py-1.5 ${l.undoneAt ? "opacity-50 line-through" : ""}`}>
                      <span>
                        − {l.qty} × {l.label}
                        {l.teeth && l.teeth.length > 0 ? ` (${l.teeth.join(", ")})` : ""}
                      </span>
                      {!l.undoneAt && canUndoInventory && (
                        <button type="button" onClick={() => undoDeduction(l.id)} className="text-muted hover:text-red-600 shrink-0" title="Undo this deduction">
                          Undo
                        </button>
                      )}
                      {l.undoneAt && <span className="text-muted shrink-0">Undone</span>}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={() => setShowReportModal(false)}>
          <div className="card-3d rounded-xl p-5 w-full max-w-md max-h-[80vh] flex flex-col space-y-3" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold">Interactive report</h3>
              <button type="button" onClick={() => setShowReportModal(false)} className="text-muted text-lg leading-none px-1">
                ×
              </button>
            </div>
            <p className="text-xs text-muted">Everything that happened on the Interactive chart, by date.</p>
            <div className="overflow-y-auto space-y-3">
              {chartEvents.length === 0 && <p className="text-xs text-muted">Nothing recorded yet.</p>}
              {chartEventsByDate.map(([date, events]) => (
                <div key={date} className="rounded-lg border border-border p-2 space-y-1.5">
                  <div className="text-[11px] font-semibold text-muted">📅 {date}</div>
                  {events.map((ev) => (
                    <div key={ev.id} className="text-xs rounded-md border border-border px-2 py-1.5">
                      {ev.text}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
