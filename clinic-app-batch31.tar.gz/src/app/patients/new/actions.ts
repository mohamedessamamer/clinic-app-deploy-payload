"use server";

import { redirect } from "next/navigation";
import { db } from "@/lib/db/client";
import { isThreePartName, isValidBirthDate } from "@/lib/patient-details";

async function nextFileNumber() {
  const last = await db
    .selectFrom("patients")
    .select("file_number")
    .orderBy("id", "desc")
    .limit(1)
    .executeTakeFirst();
  const lastNum = last ? parseInt(last.file_number.replace(/\D/g, ""), 10) || 0 : 0;
  return `P-${String(lastNum + 1).padStart(4, "0")}`;
}

export async function createPatientAction(formData: FormData) {
  const full_name = String(formData.get("full_name") || "").trim();
  const birth_date = String(formData.get("birth_date") || "").trim() || null;
  const phone = String(formData.get("phone") || "").trim() || null;
  const address = String(formData.get("address") || "").trim() || null;

  if (!isThreePartName(full_name)) redirect("/patients/new?error=name");
  if (!isValidBirthDate(birth_date)) redirect("/patients/new?error=birth_date");
  if (!phone) redirect("/patients/new?error=phone");

  const file_number = await nextFileNumber();

  // age القديم بيفضل null للمرضى الجداد كلهم — السن دلوقتي بيتحسب من birth_date
  // وقت العرض (شوف src/lib/age.ts)، مش بيتخزن كرقم ثابت.
  const result = await db
    .insertInto("patients")
    .values({ file_number, full_name, age: null, birth_date, phone, address })
    .executeTakeFirst();

  redirect(`/patients/${result.insertId}`);
}
