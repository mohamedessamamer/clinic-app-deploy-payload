"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { completeEmbeddedSignupAction, connectTestAccountManuallyAction } from "@/app/whatsapp/actions";

// Meta Embedded Signup (Facebook Login for Business, config_id-based).
//
// ملاحظة مهمة (اكتُشفت بعد تصحيح فعلي على السيرفر): استخدام window.FB.login()
// من مكتبة الـFacebook JS SDK بيتعرّض في متصفحات Chrome الحديثة لميزة اسمها
// FedCM (Federated Credential Management) — Chrome بيقاطع نافذة الـlogin
// ويستبدلها بنافذة "Sign in with..." خاصة بيه، وده بيلغي كل الـparameters اللي
// بنبعتها (config_id, response_type=code, الصلاحيات..) ويرجع بدالها
// response_type=token&scope=openid عادي جدًا — فيديئي برسالة "This app isn't
// available. This app needs at least one supported permission." من غير أي علاقة
// بإعدادات الـpermissions أو الـconfiguration في Meta Dashboard.
//
// الحل: نبني رابط نافذة الـOAuth يدويًا ونفتحه بـwindow.open() (navigation
// عادي)، من غير ما نمر على FB.login() خالص — كده Chrome معهوش سبب يتدخل بـFedCM.
// بعد الموافقة، فيسبوك بيرجّع النافذة لـredirect_uri (الصفحة الرئيسية لنفس
// الدومين) ومعاها ?code=...، وWhatsAppOAuthRelay.tsx (شغال في كل صفحات
// السيستم) بيلقط الكود ده ويبعته هنا عن طريق postMessage.
//
// بيانات الـWABA/رقم الهاتف (waba_id, phone_number_id) بتوصل عن طريق رسالة
// postMessage منفصلة من نوع "WA_EMBEDDED_SIGNUP" — دي بتتبعت من واجهة اختيار
// الحساب/الرقم اللي فيسبوك نفسه بيعرضها جوه نفس النافذة قبل الـredirect
// الأخير، ومستقلة تمامًا عن مشكلة FedCM فوق.

declare global {
  interface Window {
    __waSignupHandler?: (event: MessageEvent) => void;
  }
}

type SignupData = { waba_id?: string; phone_number_id?: string; business_id?: string };

function randomState() {
  return "wa_signup_" + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export default function WhatsAppConnectButton() {
  const [status, setStatus] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [confirmCoexistence, setConfirmCoexistence] = useState(false);
  const [isPending, startTransition] = useTransition();
  const signupData = useRef<SignupData>({});
  const pendingState = useRef<string | null>(null);
  const pendingMeta = useRef<{ coexistence: boolean; environment: "test" | "production" } | null>(null);

  const appId = process.env.NEXT_PUBLIC_WHATSAPP_APP_ID;
  const configId = process.env.NEXT_PUBLIC_WHATSAPP_CONFIG_ID;
  const graphVersion = process.env.NEXT_PUBLIC_WHATSAPP_GRAPH_VERSION || "v23.0";

  useEffect(() => {
    function onMessage(event: MessageEvent) {
      if (event.origin === window.location.origin && event.data?.type === "WA_SIGNUP_OAUTH_CODE") {
        const { code, state } = event.data as { code: string; state: string };
        if (!pendingState.current || state !== pendingState.current || !pendingMeta.current) return;
        const meta = pendingMeta.current;
        pendingState.current = null;
        pendingMeta.current = null;
        setStatus("جاري تأكيد الربط...");
        startTransition(async () => {
          const result = await completeEmbeddedSignupAction({
            code,
            wabaId: signupData.current.waba_id ?? "",
            phoneNumberId: signupData.current.phone_number_id ?? "",
            businessId: signupData.current.business_id,
            coexistence: meta.coexistence,
            environment: meta.environment,
          });
          setStatus(null);
          if (!result.ok) {
            setError(result.error ?? "فشل الربط");
          } else {
            window.location.reload();
          }
        });
        return;
      }
      if (event.origin !== "https://www.facebook.com" && event.origin !== "https://web.facebook.com") return;
      try {
        const data = JSON.parse(typeof event.data === "string" ? event.data : "{}");
        if (data?.type === "WA_EMBEDDED_SIGNUP" && data.data) {
          signupData.current = { ...signupData.current, ...data.data };
        }
      } catch {
        // رسائل postMessage تانية من نفس الأصل مش شكل واتساب — نتجاهلها.
      }
    }
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, []);

  const [manualError, setManualError] = useState<string | null>(null);
  const [manualPending, startManualTransition] = useTransition();

  function submitManualTestAccount(formData: FormData) {
    setManualError(null);
    startManualTransition(async () => {
      const result = await connectTestAccountManuallyAction(formData);
      if (!result.ok) {
        setManualError(result.error ?? "فشل الربط");
      } else {
        window.location.reload();
      }
    });
  }

  function startSignup(coexistence: boolean, environment: "test" | "production") {
    setError(null);
    if (!appId || !configId) {
      setError("متغيرات NEXT_PUBLIC_WHATSAPP_APP_ID أو NEXT_PUBLIC_WHATSAPP_CONFIG_ID غير مضبوطة على السيرفر.");
      return;
    }
    if (coexistence && !confirmCoexistence) {
      setError("لازم تأكد الصندوق تحت الأول قبل ربط رقم العيادة الحقيقي.");
      return;
    }
    signupData.current = {};
    const state = randomState();
    pendingState.current = state;
    pendingMeta.current = { coexistence, environment };
    setStatus("جاري فتح نافذة واتساب...");

    const redirectUri = `${window.location.origin}/`;
    const extras = coexistence
      ? { featureType: "whatsapp_business_app_onboarding", sessionInfoVersion: "3" }
      : { sessionInfoVersion: "3" };

    const params = new URLSearchParams({
      client_id: appId,
      config_id: configId,
      response_type: "code",
      override_default_response_type: "true",
      redirect_uri: redirectUri,
      state,
      extras: JSON.stringify(extras),
    });

    const url = `https://www.facebook.com/${graphVersion}/dialog/oauth?${params.toString()}`;
    const popup = window.open(url, "wa_embedded_signup", "width=600,height=720");
    if (!popup) {
      setStatus(null);
      setError("المتصفح منع فتح النافذة (popup blocker) — اسمح بالنوافذ المنبثقة لهذا الموقع وجرب تاني.");
    }
  }

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-slate-200 p-3">
        <p className="mb-2 text-sm font-medium">1) ربط رقم Meta التجريبي (للتطوير وApp Review)</p>
        <button
          type="button"
          disabled={isPending}
          onClick={() => startSignup(false, "test")}
          className="btn-primary rounded-lg px-4 py-2 text-sm"
        >
          Connect WhatsApp (رقم تجريبي)
        </button>
      </div>

      <div className="rounded-lg border border-amber-300 bg-amber-50 p-3">
        <p className="mb-2 text-sm font-medium text-amber-900">2) ربط رقم العيادة الحقيقي (Coexistence)</p>
        <label className="mb-2 flex items-start gap-2 text-xs text-amber-900">
          <input
            type="checkbox"
            checked={confirmCoexistence}
            onChange={(e) => setConfirmCoexistence(e.target.checked)}
            className="mt-0.5"
          />
          <span>
            أنا متأكد إن رقم العيادة الحالي هيفضل شغال عادي على تطبيق WhatsApp Business عند السكرتارية بعد الربط ده
            (Coexistence) — مفيش نقل أو تسجيل للرقم بره التطبيق.
          </span>
        </label>
        <button
          type="button"
          disabled={isPending || !confirmCoexistence}
          onClick={() => startSignup(true, "production")}
          className="btn-secondary rounded-lg px-4 py-2 text-sm disabled:opacity-50"
        >
          Connect WhatsApp (رقم العيادة — Coexistence)
        </button>
      </div>

      {status && <p className="text-sm text-muted">{status}</p>}
      {error && <p className="text-sm text-red-700">{error}</p>}

      <div className="rounded-lg border border-slate-200 p-3">
        <p className="mb-1 text-sm font-medium">3) ربط رقم Meta التجريبي يدويًا (بديل مؤقت)</p>
        <p className="mb-2 text-xs text-muted">
          رقم اختبار Meta (اللي شكله +1 555...) رقم افتراضي مش حقيقي، فمش بيقدر يستقبل رسالة تحقق SMS — عشان كده خطوة
          &quot;Verify your phone number&quot; جوه نافذة الـConnect بتفشل معاه دايمًا. الحل: Meta نفسها بتديك WABA ID
          وPhone Number ID وAccess token جاهزين من صفحة App Dashboard ← WhatsApp ← API Setup (Try it out) من غير أي
          OAuth. انسخهم من هناك واحطهم هنا.
        </p>
        <form action={submitManualTestAccount} className="space-y-2">
          <input
            name="waba_id"
            placeholder="WhatsApp Business Account ID"
            required
            className="w-full rounded-md border border-slate-300 px-2 py-1.5 text-sm"
          />
          <input
            name="phone_number_id"
            placeholder="Phone Number ID"
            required
            className="w-full rounded-md border border-slate-300 px-2 py-1.5 text-sm"
          />
          <input
            name="access_token"
            type="password"
            placeholder="Access token (من زرار Generate token)"
            required
            className="w-full rounded-md border border-slate-300 px-2 py-1.5 text-sm"
          />
          <button
            type="submit"
            disabled={manualPending}
            className="btn-secondary rounded-lg px-4 py-2 text-sm disabled:opacity-50"
          >
            ربط الرقم التجريبي يدويًا
          </button>
        </form>
        {manualError && <p className="mt-2 text-sm text-red-700">{manualError}</p>}
      </div>
    </div>
  );
}
