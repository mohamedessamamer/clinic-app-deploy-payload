import sharp from "sharp";
import { isImageKind, type ImageKind } from "@/lib/images/kinds";

// Batch 124: التعرف التلقائي على صور المريض وقت الرفع — كله على السيرفر نفسه،
// الصور مابتخرجش لأي خدمة خارجية.
//
// الفكرة على مرحلتين:
//  1) قياسات بكسل بسيطة على نسخة 96×96 من كل صورة (تشبّع، لون بشرة، أحمر اللثة،
//     خلفية سودة، تماثل، سنان في منطقة الفم...). دي بتحدد "العيلة" بثقة عالية:
//     أشعة / صورة وش / صورة جوه الفم.
//  2) التوزيع على خانات التمبلت بيتعمل على مستوى الدفعة كلها (assignTemplate تحت)
//     بالمقارنة بين الصور المرفوعة مع بعض، مش بعتبات مطلقة لكل صورة لوحدها —
//     ده أدق بكتير: أقل صورة تماثلًا بين صور الوش هي الجانبية، وأكترهم سنان
//     ظاهرة هي المبتسمة، وهكذا.
// أي حاجة السيستم مش متأكد منها بتفضل في "صور من غير مكان" والمستخدم بيسحبها
// مكانها في شاشة المراجعة قبل الحفظ.

export type ImageFamily = "xray" | "face" | "intraoral" | "template" | "other";

export type ImageFeatures = {
  aspect: number;
  colorRatio: number;
  skinRatio: number;
  /** نسبة أكبر كتلة بشرة متصلة — الوش الحقيقي مقابل بكسلات متفرقة. */
  faceBlobRatio: number;
  redStrong: number;
  redCenter: number;
  darkRatio: number;
  symmetry: number;
  /** توازن البشرة يمين/شمال — الوش الجانبي بيبقى واطي. */
  balance: number;
  /** نسبة الأبيض القوي (سنان) حوالين مركز الشفايف — بتفرق المبتسم عن غيره. */
  teethWhite: number;
  /** عدد أنواع المحتوى المختلفة في مربعات الصورة — التمبلت الجاهز بيجمع أشعة وصور مع بعض. */
  mixedCells: number;
  /** Batch 126: خطوط فاصلة ثابتة اللون جوه الصورة (شبكة تمبلت جاهز). */
  gridBands: number;
  mouthBright: number;
  teethTopHeavy: number;
  teethLeftHeavy: number;
  brightCenter: number;
};

export type ImageAnalysis = {
  family: ImageFamily;
  kind: ImageKind;
  confidence: number;
  width: number;
  height: number;
  features: ImageFeatures;
  faceBox: { x: number; y: number; width: number; height: number } | null;
};

const SIZE = 96;

function toHsv(r: number, g: number, b: number) {
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const v = max / 255;
  const s = max === 0 ? 0 : (max - min) / max;
  let h = 0;
  if (max !== min) {
    const d = max - min;
    if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) * 60;
    else if (max === g) h = ((b - r) / d + 2) * 60;
    else h = ((r - g) / d + 4) * 60;
  }
  return { h, s, v };
}

function isSkinPixel(r: number, g: number, b: number, s: number, v: number) {
  return r > 70 && g > 35 && b > 18 && r > g && g >= b * 0.85 && r - Math.min(g, b) > 12 && r - g < 110 && s > 0.12 && s < 0.6 && v > 0.25;
}

/**
 * أكبر كتلة متصلة من بكسلات البشرة — بتشيل أي بكسلات متفرقة من الخلفية أو من
 * صورة جنبها، فمقاييس شكل الوش (التماثل، منطقة الفم) بتتحسب على الوش نفسه.
 */
function largestSkinBlob(mask: Uint8Array): { blob: Uint8Array; minX: number; maxX: number; minY: number; maxY: number; size: number } {
  const seen = new Uint8Array(mask.length);
  const best = { blob: new Uint8Array(mask.length), minX: SIZE, maxX: 0, minY: SIZE, maxY: 0, size: 0 };
  const queue = new Int32Array(mask.length);
  for (let start = 0; start < mask.length; start += 1) {
    if (!mask[start] || seen[start]) continue;
    let head = 0, tail = 0, size = 0;
    let minX = SIZE, maxX = 0, minY = SIZE, maxY = 0;
    const cells: number[] = [];
    queue[tail++] = start;
    seen[start] = 1;
    while (head < tail) {
      const index = queue[head++];
      const x = index % SIZE;
      const y = (index - x) / SIZE;
      size += 1;
      cells.push(index);
      if (x < minX) minX = x;
      if (x > maxX) maxX = x;
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
      const neighbours = [x > 0 ? index - 1 : -1, x < SIZE - 1 ? index + 1 : -1, y > 0 ? index - SIZE : -1, y < SIZE - 1 ? index + SIZE : -1];
      for (const next of neighbours) {
        if (next >= 0 && mask[next] && !seen[next]) {
          seen[next] = 1;
          queue[tail++] = next;
        }
      }
    }
    if (size > best.size) {
      best.size = size;
      best.minX = minX; best.maxX = maxX; best.minY = minY; best.maxY = maxY;
      best.blob = new Uint8Array(mask.length);
      for (const index of cells) best.blob[index] = 1;
    }
  }
  return best;
}

export async function extractFeatures(source: Buffer | string): Promise<{ features: ImageFeatures; width: number; height: number; skinBox: ImageAnalysis["faceBox"] }> {
  const image = sharp(source as Buffer, { failOn: "none" }).rotate();
  const metadata = await image.metadata();
  const { data } = await image.removeAlpha().resize(SIZE, SIZE, { fit: "fill" }).raw().toBuffer({ resolveWithObject: true });

  const total = SIZE * SIZE;
  const skinMask = new Uint8Array(total);
  let colored = 0, skin = 0, redStrong = 0, dark = 0;
  let centerCount = 0, redCenterCount = 0, brightCenterCount = 0;
  let mouthCount = 0, mouthBrightCount = 0;
  let teeth = 0, teethTop = 0, teethLeft = 0;
  let minX = SIZE, maxX = 0, minY = SIZE, maxY = 0;

  for (let y = 0; y < SIZE; y += 1) {
    for (let x = 0; x < SIZE; x += 1) {
      const i = (y * SIZE + x) * 3;
      const r = data[i], g = data[i + 1], b = data[i + 2];
      const { h, s, v } = toHsv(r, g, b);
      const nx = x / (SIZE - 1);
      const ny = y / (SIZE - 1);
      const redHue = h <= 22 || h >= 335;
      const bright = v > 0.6 && s < 0.25;

      if (s > 0.18 && v > 0.12) colored += 1;
      if (v < 0.12) dark += 1;
      if (redHue && s > 0.42 && v > 0.2) redStrong += 1;
      if (isSkinPixel(r, g, b, s, v)) {
        skin += 1;
        skinMask[y * SIZE + x] = 1;
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
      if (nx > 0.2 && nx < 0.8 && ny > 0.2 && ny < 0.8) {
        centerCount += 1;
        if (redHue && s > 0.42 && v > 0.2) redCenterCount += 1;
        if (bright) brightCenterCount += 1;
      }
      // منطقة الفم التقريبية في صورة وش: نص الصورة أفقيًا، الثلث السفلي رأسيًا.
      if (nx > 0.3 && nx < 0.7 && ny > 0.55 && ny < 0.85) {
        mouthCount += 1;
        if (bright) mouthBrightCount += 1;
      }
      if (bright) {
        teeth += 1;
        if (ny < 0.5) teethTop += 1;
        if (nx < 0.5) teethLeft += 1;
      }
    }
  }

  // Batch 126: التمبلت الجاهز (صورة مجمّعة اتعملت برة السيستم) بيجمع أشعة
  // وصور فوتوغرافية في نفس الصورة. بنقسمها 4×4 (على نسخة أكبر عشان المربعات
  // تبان)، وبنعتبرها تمبلت لو فيها مربعين أشعة على الأقل ومربعين صور على
  // الأقل. الأشعة لوحدها أو الصور لوحدها مابتتحسبش.
  const gridSize = 192;
  const grid = await sharp(source as Buffer, { failOn: "none" })
    .rotate()
    .removeAlpha()
    .resize(gridSize, gridSize, { fit: "fill" })
    .raw()
    .toBuffer();
  const cells = 4;
  const cellSize = Math.floor(gridSize / cells);
  let xrayCells = 0, photoCells = 0;
  for (let cy = 0; cy < cells; cy += 1) {
    for (let cx = 0; cx < cells; cx += 1) {
      let colored = 0, skinPixels = 0, redPixels = 0, pixels = 0, sum = 0, sumSquares = 0;
      for (let y = cy * cellSize; y < (cy + 1) * cellSize; y += 1) {
        for (let x = cx * cellSize; x < (cx + 1) * cellSize; x += 1) {
          const i = (y * gridSize + x) * 3;
          const r = grid[i], g = grid[i + 1], b = grid[i + 2];
          const { h, s, v } = toHsv(r, g, b);
          pixels += 1;
          sum += v;
          sumSquares += v * v;
          if (s > 0.18 && v > 0.12) colored += 1;
          if (isSkinPixel(r, g, b, s, v)) skinPixels += 1;
          if ((h <= 22 || h >= 335) && s > 0.42 && v > 0.2) redPixels += 1;
        }
      }
      if (!pixels) continue;
      const mean = sum / pixels;
      const deviation = Math.sqrt(Math.max(0, sumSquares / pixels - mean * mean));
      const hasDetail = deviation > 0.08 && mean > 0.12 && mean < 0.92;
      if (redPixels / pixels >= 0.15 || skinPixels / pixels >= 0.30) photoCells += 1;
      else if (colored / pixels < 0.04 && skinPixels / pixels < 0.02 && hasDetail) xrayCells += 1;
    }
  }
  const mixedCells = xrayCells >= 2 && photoCells >= 2 ? 2 : 1;

  // Batch 126: تمبلت جاهز متعمول برة السيستم بيبقى صور جنب بعض بينهم خطوط فاصلة
  // ثابتة اللون (أبيض أو أسود) ماشية على طول الصورة. بندوّر على الخطوط دي في
  // النص (مش عند الحواف، عشان الخلفية السودة في صور الوش ماتتحسبش فاصل).
  function flatBands(axis: "x" | "y"): number {
    const flat: boolean[] = [];
    const rich: boolean[] = [];
    for (let line = 0; line < gridSize; line += 1) {
      let sum = 0, sumSquares = 0, colored = 0;
      for (let step = 0; step < gridSize; step += 1) {
        const x = axis === "x" ? line : step;
        const y = axis === "x" ? step : line;
        const i = (y * gridSize + x) * 3;
        const { s, v } = toHsv(grid[i], grid[i + 1], grid[i + 2]);
        sum += v;
        sumSquares += v * v;
        if (s > 0.18 && v > 0.12) colored += 1;
      }
      const mean = sum / gridSize;
      const deviation = Math.sqrt(Math.max(0, sumSquares / gridSize - mean * mean));
      flat.push(deviation < 0.05 && colored / gridSize < 0.02 && (mean < 0.22 || mean > 0.80));
      // سطر "مليان": فيه تفاصيل أو لون حقيقي — يعني جواه صورة مش خلفية.
      rich.push(deviation > 0.12 || colored / gridSize > 0.15);
    }
    let bands = 0;
    let start = -1;
    for (let line = 0; line <= gridSize; line += 1) {
      if (line < gridSize && flat[line]) { if (start < 0) start = line; continue; }
      if (start < 0) continue;
      const end = line - 1;
      // فاصل حقيقي: رفيع، مش ملزوق في الحافة، وفيه صورة فعلية على جنبيه.
      const thin = end - start + 1 <= gridSize * 0.10;
      const before = start - 3;
      const after = end + 3;
      const contentBoth = before >= 0 && after < gridSize && rich[before] && rich[after];
      if (thin && contentBoth && start > gridSize * 0.05 && end < gridSize * 0.95) bands += 1;
      start = -1;
    }
    return bands;
  }
  const bandsX = flatBands("x");
  const bandsY = flatBands("y");
  // شبكة حقيقية: فاصل على الأقل في كل اتجاه، وثلاثة فواصل إجمالًا على الأقل.
  const gridBands = bandsX >= 1 && bandsY >= 1 && bandsX + bandsY >= 3 ? Math.min(bandsX, bandsY) : 0;

  // توازن البشرة بين نص الصورة اليمين والشمال (الوش الجانبي بيبقى مايل لجهة).
  let skinLeft = 0, skinRight = 0;
  for (let y = 0; y < SIZE; y += 1) {
    for (let x = 0; x < SIZE; x += 1) {
      if (!skinMask[y * SIZE + x]) continue;
      if (x < SIZE / 2) skinLeft += 1; else skinRight += 1;
    }
  }
  const balance = Math.max(skinLeft, skinRight) > 0 ? Math.min(skinLeft, skinRight) / Math.max(skinLeft, skinRight) : 0;

  // الابتسامة: بندوّر على مركز الشفايف (أحمر قوي) وبنقيس الأبيض القوي (السنان)
  // في شباك صغير حواليه. الجلد نفسه فاتح لكن مش أبيض بالدرجة دي.
  let lipX = 0, lipY = 0, lipCount = 0;
  for (let y = 0; y < SIZE; y += 1) {
    for (let x = 0; x < SIZE; x += 1) {
      const i = (y * SIZE + x) * 3;
      const { h, s, v } = toHsv(data[i], data[i + 1], data[i + 2]);
      if ((h <= 12 || h >= 348) && s > 0.45 && v > 0.3 && v < 0.85) {
        lipCount += 1;
        lipX += x;
        lipY += y;
      }
    }
  }
  let teethWhite = 0;
  if (lipCount > 0) {
    const centreX = lipX / lipCount;
    const centreY = lipY / lipCount;
    const halfHeight = Math.round(SIZE * 0.045);
    const halfWidth = Math.round(SIZE * 0.085);
    let white = 0, cells = 0;
    for (let y = Math.max(0, Math.round(centreY - halfHeight)); y <= Math.min(SIZE - 1, Math.round(centreY + halfHeight)); y += 1) {
      for (let x = Math.max(0, Math.round(centreX - halfWidth)); x <= Math.min(SIZE - 1, Math.round(centreX + halfWidth)); x += 1) {
        const i = (y * SIZE + x) * 3;
        const { s, v } = toHsv(data[i], data[i + 1], data[i + 2]);
        cells += 1;
        if (v > 0.8 && s < 0.16) white += 1;
      }
    }
    teethWhite = cells ? white / cells : 0;
  }

  // التماثل ومنطقة الفم بيتحسبوا على أكبر كتلة بشرة متصلة (الوش نفسه).
  const blob = largestSkinBlob(skinMask);
  let symmetryMatches = 0, symmetryCells = 0;
  if (blob.size > 0 && blob.maxX > blob.minX) {
    for (let y = blob.minY; y <= blob.maxY; y += 1) {
      for (let x = blob.minX; x <= blob.maxX; x += 1) {
        const mirrored = blob.maxX - (x - blob.minX);
        symmetryCells += 1;
        if (blob.blob[y * SIZE + x] === blob.blob[y * SIZE + mirrored]) symmetryMatches += 1;
      }
    }
    minX = blob.minX; maxX = blob.maxX; minY = blob.minY; maxY = blob.maxY;
    // منطقة الفم: النص الأفقي الأوسط من الكتلة، بين 55% و90% من ارتفاعها.
    const blobWidth = blob.maxX - blob.minX + 1;
    const blobHeight = blob.maxY - blob.minY + 1;
    mouthCount = 0;
    mouthBrightCount = 0;
    for (let y = blob.minY + Math.round(blobHeight * 0.55); y <= blob.minY + Math.round(blobHeight * 0.92) && y < SIZE; y += 1) {
      for (let x = blob.minX + Math.round(blobWidth * 0.25); x <= blob.minX + Math.round(blobWidth * 0.75) && x < SIZE; x += 1) {
        const i = (y * SIZE + x) * 3;
        const { s, v } = toHsv(data[i], data[i + 1], data[i + 2]);
        mouthCount += 1;
        if (v > 0.55 && s < 0.3) mouthBrightCount += 1;
      }
    }
  }

  return {
    width: metadata.width ?? SIZE,
    height: metadata.height ?? SIZE,
    skinBox: skin > total * 0.02
      ? { x: minX / SIZE, y: minY / SIZE, width: (maxX - minX + 1) / SIZE, height: (maxY - minY + 1) / SIZE }
      : null,
    features: {
      aspect: (metadata.width ?? SIZE) / Math.max(1, metadata.height ?? SIZE),
      colorRatio: colored / total,
      skinRatio: skin / total,
      faceBlobRatio: blob.size / total,
      redStrong: redStrong / total,
      redCenter: centerCount ? redCenterCount / centerCount : 0,
      darkRatio: dark / total,
      symmetry: symmetryCells ? symmetryMatches / symmetryCells : 0,
      balance,
      teethWhite,
      mixedCells: Math.max(1, mixedCells),
      gridBands,
      mouthBright: mouthCount ? mouthBrightCount / mouthCount : 0,
      teethTopHeavy: teeth ? teethTop / teeth : 0.5,
      teethLeftHeavy: teeth ? teethLeft / teeth : 0.5,
      brightCenter: centerCount ? brightCenterCount / centerCount : 0,
    },
  };
}

/**
 * العيلة: أشعة / وش / جوه الفم.
 * العتبات دي اتظبطت على صور حقيقية من العيادة (16 صورة: بانوراما، سيفالومتري،
 * وش أمامي/جانبي/مائل بابتسامة ومن غيرها، وصور داخل الفم بالمرايا):
 *   - الأشعة: تشبّع لوني صفر تقريبًا (0.00) مقابل 0.30+ في أي صورة فوتوغرافية.
 *   - داخل الفم: أحمر لثة قوي (0.13 فأكتر) مقابل 0.07 كحد أقصى في صور الوش.
 */
export function familyOf(f: ImageFeatures): ImageFamily {
  // تمبلت جاهز: نفس الصورة فيها أشعة وصور فوتوغرافية مع بعض.
  // تمبلت جاهز: إما خليط أشعة وصور في صورة واحدة، أو شبكة صور بينها خطوط فاصلة.
  if (f.mixedCells >= 2 || f.gridBands >= 1) return "template";
  if (f.colorRatio < 0.05 && f.skinRatio < 0.05) return "xray";
  // اللثة الحمرا هي اللي بتميز صور جوه الفم. الحد اترفع في دفعة 126 عشان صورة
  // الوش المتاخدة من تحت (خدود وشفايف) ماتتحسبش صورة فك علوي.
  if (f.redStrong >= 0.18 || f.redCenter >= 0.20) return "intraoral";
  if (f.skinRatio >= 0.10) return "face";
  if (f.colorRatio < 0.12) return "xray";
  return "other";
}

/** صورة وش أمامية (اللي بتصلح صورة ملف): بشرة كتير + تماثل عالي. */
export function isFrontalFace(f: ImageFeatures): boolean {
  // Batch 127: كانت 0.72 — طلعت عالية جدًا لصور مبتسمة حقيقية (الابتسامة نفسها
  // بتقلل التماثل شوية بسبب فتح الفم/ميل الرأس البسيط). صور عيادة حقيقية طلعت
  // 0.644 و0.681 لوشين أماميين واضحين واتحطوا غلط "45 درجة". راجع batch-127
  // notes في classify-report لصور المريض 830.
  return familyOf(f) === "face" && f.skinRatio >= 0.26 && f.symmetry >= 0.62 && f.balance >= 0.65;
}

/**
 * ابتسامة واضحة: بياض قوي في منطقة الفم (`mouthBright`, بيتحسب من كتلة
 * البشرة نفسها) — مش محتاجة تلاقي شفة حمرا الأول زي `teethWhite` القديمة.
 * الابتسامة الواسعة بتقلل مساحة الشفة الحمرا الظاهرة أصلًا (الفم مفتوح)،
 * فـ`teethWhite` كانت بترجع صفر بالظبط في أقوى حالات الابتسامة — ده اللي
 * كان بيمنع أي صورة تتصنف face_smile خالص لمريض 830 (كل الصور طلعت
 * teethWhite=0.000). `mouthBright` بيتحسب من منطقة تلت الوش السفلي مباشرة،
 * فمش بيعتمد على إيجاد الشفة الأول.
 */
function looksSmiling(f: ImageFeatures): boolean {
  return f.teethWhite > 0.01 || f.mouthBright > 0.3;
}

/** نوع تقريبي لصورة واحدة لوحدها. */
export function kindOf(f: ImageFeatures): { kind: ImageKind; confidence: number } {
  const family = familyOf(f);
  if (family === "xray") {
    if (f.aspect >= 1.6 && f.darkRatio < 0.35) return { kind: "xray_pano", confidence: 0.85 };
    if (f.aspect >= 0.7 && f.aspect <= 1.55) return { kind: "xray_ceph", confidence: 0.7 };
    return { kind: "xray_other", confidence: 0.5 };
  }
  if (family === "template") return { kind: "template_sheet", confidence: 0.6 };
  if (family === "face") {
    // Batch 126: لقطة قريبة جدًا (الوش مالي الكادر ومفيش خلفية) — زي صورة الوش
    // من تحت — مش بورتريه ومش صورة ملف؛ بتفضل في Extra-Oral لكن في الآخر.
    if (f.faceBlobRatio > 0.62 && f.darkRatio < 0.12) return { kind: "other", confidence: 0.25 };
    // Batch 127: بند الابتسامة بقى بيتحسب مرة واحدة ويتطبق على الأمامي والجانبي
    // والـ45 درجة الثلاثة بنفس الطريقة — قبل كده كانت في مكان واحد بس (الأمامي)
    // فأي صورة "جانبي مبتسم" أو "45 مبتسم" كانت بتفقد معلومة الابتسامة تمامًا.
    const smiling = looksSmiling(f);
    if (isFrontalFace(f)) {
      return smiling ? { kind: "face_smile", confidence: 0.6 } : { kind: "face_frontal", confidence: 0.7 };
    }
    // الجانبي: بشرة قليلة (نص الكادر شعر/خلفية) أو مائلة بقوة لجهة واحدة.
    if (f.skinRatio < 0.26 || f.balance < 0.70) {
      return smiling ? { kind: "face_profile_smile", confidence: 0.55 } : { kind: "face_profile", confidence: 0.6 };
    }
    // غير كده وش 45 درجة: بشرة كتير ومتوازنة بس التماثل أقل من الأمامي.
    return smiling ? { kind: "face_oblique_smile", confidence: 0.45 } : { kind: "face_oblique", confidence: 0.5 };
  }
  if (family === "intraoral") {
    if (f.redCenter >= 0.4 && f.teethWhite < 0.05) return { kind: "intraoral_lower", confidence: 0.35 };
    if (f.redCenter < 0.15 && f.skinRatio > 0.55) return { kind: "intraoral_upper", confidence: 0.35 };
    if (f.aspect >= 1.7) return { kind: f.teethLeftHeavy >= 0.5 ? "intraoral_right" : "intraoral_left", confidence: 0.3 };
    return { kind: "intraoral_front", confidence: 0.45 };
  }
  return { kind: "other", confidence: 0.2 };
}

export async function analyzeImage(source: Buffer | string): Promise<ImageAnalysis> {
  // Batch 126: على ويندوز الملف ساعات بيبقى لسه متقفول (مضاد فيروسات/فهرسة) بعد
  // ما اتكتب مباشرة، فقراءته بتفشل أول مرة. بنعيد المحاولة كام مرة بفاصل بسيط
  // قبل ما نستسلم ونسجل الصورة من غير نوع.
  let lastError: unknown = null;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      const { features, width, height, skinBox } = await extractFeatures(source);
      const family = familyOf(features);
      const { kind, confidence } = kindOf(features);
      return {
        family,
        kind,
        confidence,
        width,
        height,
        features,
        faceBox: family === "face" && skinBox ? padBox(skinBox) : null,
      };
    } catch (error) {
      lastError = error;
      if (attempt < 2) await new Promise((resolve) => setTimeout(resolve, 200 * (attempt + 1)));
    }
  }
  {
    const error = lastError;
    // Batch 126: الفشل ماكانش بيتكتب في أي مكان، فكان صعب نعرف ليه الصور بتتسجل
    // "غير محدد" على جهاز معين. دلوقتي السبب بيظهر في لوج السيرفر.
    console.error("[images] analyzeImage failed", error);
    return {
      family: "other",
      kind: "other",
      confidence: 0,
      width: 0,
      height: 0,
      faceBox: null,
      features: { aspect: 1, colorRatio: 0, skinRatio: 0, faceBlobRatio: 0, balance: 0, teethWhite: 0, mixedCells: 1, gridBands: 0, redStrong: 0, redCenter: 0, darkRatio: 0, symmetry: 0, mouthBright: 0, teethTopHeavy: 0.5, teethLeftHeavy: 0.5, brightCenter: 0 },
    };
  }
}

function padBox(box: { x: number; y: number; width: number; height: number }) {
  const padX = box.width * 0.12;
  const padY = box.height * 0.15;
  const x = Math.max(0, box.x - padX);
  const y = Math.max(0, box.y - padY);
  return { x, y, width: Math.min(1 - x, box.width + padX * 2), height: Math.min(1 - y, box.height + padY * 2) };
}

// ---------------------------------------------------------------------------
// توزيع الدفعة على خانات التمبلت (المقارنة بين صور نفس الرفعة).
// ---------------------------------------------------------------------------

export type AssignableImage = { id: number; analysis: Pick<ImageAnalysis, "family" | "kind" | "features"> };

const NO_MATCH = -1;

function scoreFor(kind: ImageKind, image: AssignableImage): number {
  const { family, features: f } = image.analysis;
  switch (kind) {
    case "xray_pano":
      // البانوراما نسبتها حوالي 2:1 — بنقيس القرب من النسبة دي مش مجرد "أعرض صورة".
      // البانوراما خلفيتها فاتحة نسبيًا، بعكس مقاطع الأشعة المقطعية السودة.
      return family === "xray" && f.aspect >= 1.55 ? 2 - Math.abs(f.aspect - 2.1) - f.darkRatio * 2 + (1 - f.colorRatio) * 0.8 : NO_MATCH;
    case "xray_ceph":
      return family === "xray" ? 1.6 - Math.abs(f.aspect - 1.1) - f.darkRatio + (1 - f.colorRatio) * 0.8 : NO_MATCH;
    case "xray_other":
      return family === "xray" ? 0.5 : NO_MATCH;
    case "face_profile":
      // الجانبي: أقل تماثلًا، ومفيش سنان باينة في منطقة الفم.
      return family === "face" ? 1 + (1 - f.symmetry) * 2.5 + (0.15 - Math.min(f.mouthBright, 0.15)) * 4 : NO_MATCH;
    case "face_smile":
      return family === "face" ? 1 + f.mouthBright * 4 + f.symmetry : NO_MATCH;
    case "face_frontal":
      return family === "face" ? 1 + f.symmetry * 2.5 - f.mouthBright * 3 : NO_MATCH;
    case "intraoral_upper":
      return family === "intraoral" ? 1 + f.redCenter * 2 + (f.teethTopHeavy - 0.5) * 2 - f.brightCenter : NO_MATCH;
    case "intraoral_lower":
      return family === "intraoral" ? 1 + f.redCenter * 2 + (0.5 - f.teethTopHeavy) * 2 - f.brightCenter : NO_MATCH;
    case "intraoral_front":
      return family === "intraoral" ? 1 + f.brightCenter * 2 + f.symmetry - Math.abs(f.aspect - 1.3) * 0.4 : NO_MATCH;
    case "intraoral_right":
      return family === "intraoral" ? 1 + f.brightCenter + (f.teethLeftHeavy - 0.5) * 2 + Math.min(f.aspect, 2) * 0.3 : NO_MATCH;
    case "intraoral_left":
      return family === "intraoral" ? 1 + f.brightCenter + (0.5 - f.teethLeftHeavy) * 2 + Math.min(f.aspect, 2) * 0.3 : NO_MATCH;
    case "other":
      return 0.1;
    default:
      return NO_MATCH;
  }
}

/**
 * توزيع أفضل صورة لكل خانة: بنحسب درجة لكل (صورة، خانة) وناخد الأعلى كل مرة.
 * الخانات اللي نوعها "any" بتتملى في الآخر بأي صورة فاضلة.
 */
export function assignTemplate(
  // Batch 130 (مرحلة 5): "kind" ممكن يبقى نوع مخصّص (custom_...) — النوع هنا
  // مقصود يكون string عام عشان الدالة تقبل أي تمبلت متخزّن، بس أي خانة نوعها
  // مش من ImageKind الثابتة (يعني مخصّصة) بتتجاهل هنا تمامًا زي "any" في عدم
  // التوزيع التلقائي (مفيش scoreFor لها) — تفضل خانة يدوية بحتة دايمًا.
  slots: { key: string; kind: string }[],
  images: AssignableImage[]
): { assignments: Record<string, number>; unassigned: number[] } {
  const assignments: Record<string, number> = {};
  const takenImages = new Set<number>();
  const takenSlots = new Set<string>();

  const pairs: { slot: string; image: number; score: number }[] = [];
  for (const slot of slots) {
    if (!isImageKind(slot.kind)) continue;
    for (const image of images) {
      const score = scoreFor(slot.kind, image);
      if (score > NO_MATCH) pairs.push({ slot: slot.key, image: image.id, score });
    }
  }
  pairs.sort((a, b) => b.score - a.score);
  for (const pair of pairs) {
    if (takenSlots.has(pair.slot) || takenImages.has(pair.image)) continue;
    assignments[pair.slot] = pair.image;
    takenSlots.add(pair.slot);
    takenImages.add(pair.image);
  }

  const leftovers = images.filter((image) => !takenImages.has(image.id)).map((image) => image.id);
  for (const slot of slots) {
    if (slot.kind !== "any" || takenSlots.has(slot.key)) continue;
    const next = leftovers.shift();
    if (next == null) break;
    assignments[slot.key] = next;
    takenSlots.add(slot.key);
    takenImages.add(next);
  }

  return { assignments, unassigned: images.filter((image) => !takenImages.has(image.id)).map((image) => image.id) };
}

/**
 * قص مربع الوش من الصورة الأصلية لصورة ملف المريض. Batch 130: أي فشل في
 * حساب/تنفيذ القص الدقيق (extract) — أيًا كان سببه — بيرجع تلقائيًا لنفس
 * أسلوب "من غير faceBox" (resize/cover كامل الصورة) بدل ما يفشل تمامًا
 * ويمنع تحديد صورة الملف خالص. كان ده بيظهر كرسالة "تعذر تجهيز صورة الملف"
 * سواء وقت الرفع التلقائي أو وقت الاختيار اليدوي.
 */
export async function cropFaceThumbnail(source: Buffer | string, faceBox: ImageAnalysis["faceBox"], size = 320): Promise<Buffer> {
  const fallback = () => sharp(source as Buffer, { failOn: "none" }).rotate().resize(size, size, { fit: "cover", position: "top" }).jpeg({ quality: 82 }).toBuffer();

  if (!faceBox) return fallback();

  try {
    const image = sharp(source as Buffer, { failOn: "none" }).rotate();
    const metadata = await image.metadata();
    const width = metadata.width ?? 0;
    const height = metadata.height ?? 0;
    if (!width || !height) return fallback();

    const side = Math.min(
      Math.max(Math.round(faceBox.width * width), Math.round(faceBox.height * height)),
      Math.min(width, height)
    );
    if (side <= 0) return fallback();
    const centerX = Math.round((faceBox.x + faceBox.width / 2) * width);
    const centerY = Math.round((faceBox.y + faceBox.height / 2) * height);
    const left = Math.min(Math.max(0, centerX - Math.round(side / 2)), width - side);
    const top = Math.min(Math.max(0, centerY - Math.round(side / 2)), height - side);
    return await sharp(source as Buffer, { failOn: "none" })
      .rotate()
      .extract({ left, top, width: side, height: side })
      .resize(size, size, { fit: "cover" })
      .jpeg({ quality: 82 })
      .toBuffer();
  } catch (error) {
    console.error("[images] cropFaceThumbnail: precise crop failed, falling back to full-image resize", error);
    return fallback();
  }
}
