"use client";

import { useCallback, useEffect, useState } from "react";

type GroupImage = { id: number; file_path: string };
type ImageGroup = {
  id: number;
  label: string | null;
  taken_at: string;
  images: GroupImage[];
};

type FlatImage = { id: number; file_path: string; label: string | null; taken_at: string };

export default function PatientImageGallery({ groups }: { groups: ImageGroup[] }) {
  // ليستة مسطحة بكل صور المريض بنفس ترتيب العرض، عشان أسهم اليمين/الشمال في الـ
  // lightbox تتنقل على كل الصور مش بس صور المجموعة الحالية.
  const flatImages: FlatImage[] = groups.flatMap((g) =>
    g.images.map((img) => ({ id: img.id, file_path: img.file_path, label: g.label, taken_at: g.taken_at }))
  );

  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const close = useCallback(() => setOpenIndex(null), []);
  const prev = useCallback(() => {
    setOpenIndex((i) => (i === null || flatImages.length === 0 ? i : (i - 1 + flatImages.length) % flatImages.length));
  }, [flatImages.length]);
  const next = useCallback(() => {
    setOpenIndex((i) => (i === null || flatImages.length === 0 ? i : (i + 1) % flatImages.length));
  }, [flatImages.length]);

  useEffect(() => {
    if (openIndex === null) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") close();
      else if (e.key === "ArrowLeft") prev();
      else if (e.key === "ArrowRight") next();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [openIndex, close, prev, next]);

  if (flatImages.length === 0) {
    return <p className="text-sm text-muted">لا يوجد صور أو أشعة مرفوعة لهذا المريض بعد.</p>;
  }

  let cursor = 0;

  return (
    <>
      <div className="flex gap-4 overflow-x-auto pb-2">
        {groups.map((g) => {
          const startIndex = cursor;
          cursor += g.images.length;
          return (
            <div key={g.id} className="shrink-0 w-64 border border-border rounded-lg p-2 bg-background">
              <div className="grid grid-cols-2 gap-1.5">
                {g.images.slice(0, 4).map((img, i) => (
                  <button
                    key={img.id}
                    type="button"
                    onClick={() => setOpenIndex(startIndex + i)}
                    className="block"
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={img.file_path}
                      alt={g.label || "صورة"}
                      className="w-full h-28 object-cover rounded hover:opacity-80 transition-opacity cursor-zoom-in"
                    />
                  </button>
                ))}
                {g.images.length === 0 && (
                  <div className="col-span-2 h-28 flex items-center justify-center text-xs text-muted bg-surface rounded">
                    لا صور
                  </div>
                )}
              </div>
              <div className="text-xs text-muted mt-1">{g.taken_at}</div>
              {g.label && <div className="text-xs">{g.label}</div>}
            </div>
          );
        })}
      </div>

      {openIndex !== null && (
        <div
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          onClick={close}
        >
          {flatImages.length > 1 && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                prev();
              }}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-white/80 hover:text-white text-4xl px-3 py-2 select-none"
              aria-label="السابقة"
            >
              ‹
            </button>
          )}

          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={flatImages[openIndex].file_path}
            alt={flatImages[openIndex].label || "صورة"}
            className="max-w-[90vw] max-h-[85vh] object-contain rounded shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          />

          {flatImages.length > 1 && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                next();
              }}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-white/80 hover:text-white text-4xl px-3 py-2 select-none"
              aria-label="التالية"
            >
              ›
            </button>
          )}

          <div className="absolute bottom-4 inset-x-0 text-center text-white/70 text-xs">
            {openIndex + 1} / {flatImages.length}
            {flatImages[openIndex].taken_at ? ` · ${flatImages[openIndex].taken_at}` : ""}
          </div>
        </div>
      )}
    </>
  );
}
