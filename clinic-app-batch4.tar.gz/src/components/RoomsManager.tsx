"use client";

import { addRoomAction, deleteRoomAction } from "@/app/settings/actions";

type Room = { id: number; name: string };

export default function RoomsManager({ rooms }: { rooms: Room[] }) {
  return (
    <div className="space-y-3">
      <div className="space-y-2">
        {rooms.map((r) => (
          <div key={r.id} className="flex items-center justify-between gap-3 border border-border rounded-md px-3 py-2 text-sm">
            <span>{r.name}</span>
            <form
              action={deleteRoomAction}
              onSubmit={(e) => {
                if (!window.confirm(`متأكد إنك عايز تحذف "${r.name}"؟`)) {
                  e.preventDefault();
                }
              }}
            >
              <input type="hidden" name="id" value={r.id} />
              <button type="submit" className="text-xs text-red-600 hover:underline">
                حذف
              </button>
            </form>
          </div>
        ))}
        {rooms.length === 0 && <p className="text-sm text-muted">مفيش عيادات/غرف مسجلة لسه.</p>}
      </div>

      <form action={addRoomAction} className="flex items-end gap-2 flex-wrap">
        <div className="flex-1 min-w-[200px]">
          <label className="block text-xs text-muted mb-1">اسم العيادة/الغرفة الجديدة</label>
          <input
            name="name"
            required
            placeholder="مثلاً: عيادة رقم 3"
            className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
          />
        </div>
        <button
          type="submit"
          className="rounded-md bg-primary text-white px-4 py-2 text-sm font-medium hover:bg-primary-dark"
        >
          + إضافة عيادة
        </button>
      </form>
    </div>
  );
}
