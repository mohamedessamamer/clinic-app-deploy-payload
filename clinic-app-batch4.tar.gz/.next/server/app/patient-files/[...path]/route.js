var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/patient-files/[...path]/route.js")
R.c("server/chunks/[externals]__0zitnyu._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0eysni9._.js")
R.c("server/chunks/_next-internal_server_app_patient-files_[___path]_route_actions_1sjx77-.js")
R.m(39304)
module.exports=R.m(39304).exports
