import type { Role } from "./auth";

// ثوابت الصلاحيات فقط — من غير أي استيراد لطبقة قاعدة البيانات، عشان يصلح
// للاستخدام في مكونات العميل (client components) زي PermissionsManager كمان.
// الدوال اللي بتلمس قاعدة البيانات (getPermissionOverrides..) موجودة في lib/permissions.ts.
export const PERMISSION_DEFS = [
  { key: "reports_full", label: "عرض كل التقارير (كل الأطباء وكل الفترات)" },
  { key: "reports_own", label: "عرض تقريره الشخصي بس (للدكتور) — بحد أقصى شهرين، إلا لو معاه صلاحية كل التقارير" },
  { key: "collect_payments", label: "تحصيل المدفوعات من الاستقبال" },
  { key: "manage_inventory", label: "إدارة المخزن" },
  { key: "edit_inventory_catalog", label: "تعديل أو حذف أصناف المخزن وإعداداتها" },
  {
    key: "view_patient_billing",
    label: "عرض الملف المالي للمريض — افتراضيًا مش متاح للدكتور، لازم تُمنح له لوحده لو محتاجها",
    // ملحوظة (دفعة 20): نفس الصلاحية دي كمان بتحكم بوكس "إضافة خدمة" الجديد جوه
    // الملف المالي (بديل بوكس "إضافة خدمة" اللي كان تحت الجدول في /front-desk).
  },
  { key: "manage_expenses", label: "إدارة المصروفات والمرتبات" },
  { key: "manage_settings", label: "الوصول لصفحة الإعدادات" },
  { key: "schedule_all_rooms", label: "عرض الجدول المركزي لكل الغرف/العيادات (مش بس شيفته هو)" },
  { key: "schedule_edit", label: "التعديل في الجدول المركزي (حجز مواعيد وتغيير حالتها)" },
  {
    key: "override_visit_doctor",
    label: "اختيار مقدم خدمة مختلف في سجل الزيارات (لدكاترة مساعدين) — من غير ما يأثر على التحصيل المالي",
  },
  {
    key: "edit_old_visits",
    label: "تعديل زيارات قديمة في سجل الزيارات (أكتر من 3 أيام من إضافتها) — غير كده أي حد يقدر يعدّل بس خلال أول 3 أيام",
  },
  {
    key: "edit_invoice_payments",
    label: "تعديل المدفوع وسعر الخدمة في فاتورة اتسجلت بالفعل (تصحيح غلطة إدخال من الاستقبال)",
    // ملحوظة (دفعة 20): نفس الصلاحية دي بقت كمان بتتحكم في إمكانية تسجيل خدمة
    // جديدة بتاريخ غير النهاردة من الملف المالي للمريض ("تحصيل في يوم غير اليوم
    // اللي دخل فيه الفلوس") — عمدًا معملناش صلاحية جديدة ليها، اتفاق مع المستخدم.
  },
  {
    key: "delete_visits",
    label: "حذف زيارة (وفاتورتها) من سجل الزيارات نهائيًا — لتصحيح إدخال مكرر أو غلط، للأدمن بس افتراضيًا",
  },
  {
    key: "view_invoice_totals",
    label:
      "عرض إجماليات اليوم في صفحة الفواتير (إجمالي الفواتير/المحصّل/المتبقي) وتقرير تعديلات اليوم — سعر/مدفوع/متبقي كل فاتورة على حدة ظاهر للكل بغض النظر عن الصلاحية دي",
  },
  {
    key: "edit_patient_info",
    label: "تعديل بيانات المريض الأساسية (الاسم/تاريخ الميلاد/التليفون/العنوان) من ملفه — للأدمن والاستقبال افتراضيًا",
  },
  {
    key: "edit_visit_assistant_doctor",
    label:
      "تعديل حقل \"الطبيب المساعد\" بس في زيارة مسجلة بالفعل — حقل مستقل عن باقي سجل الزيارات (بدون فتح إضافة/تعديل باقي الملف الطبي)، للأدمن ومدير العيادة والاستقبال افتراضيًا. الطبيب صاحب الزيارة الأساسي يقدر يعدّله دايمًا لزياراته هو من غير الحاجة لصلاحية دي.",
  },
  {
    key: "edit_ortho_visit_after_save",
    label:
      "تعديل زيارة فولو أب في شارت التقويم بعد ما تتحفظ (زرار Edit) — خدمة الـBonding نفسها بتفضل مقفولة دايمًا حتى مع الصلاحية دي (تصحيحها بيتم من الشارت مباشرة). للأدمن بس افتراضيًا.",
  },
  {
    key: "undo_ortho_inventory_deduction",
    label: "إلغاء (Undo) خصم مخزون مسجل من شارت التقويم (Inventory list) — للأدمن بس افتراضيًا.",
  },
  {
    key: "upload_ortho_photos",
    label:
      "رفع/تدوير/حذف صور وأشعة في شارت التقويم بس (زي قسم Photos & X-rays في الملف الطبي العادي) — من غير فتح باقي شارت التقويم للتعديل. للاستقبال افتراضيًا. الدكتور/الأدمن/مدير العيادة أصلاً عندهم دخول كامل للشارت من غير الحاجة للصلاحية دي.",
  },
  {
    key: "view_needs_treatment_reminder",
    label:
      "شوف تنبيه \"محتاج إدخال معالجة\" (موعد اتسجل \"تم\" ولسه الدكتور مدخلش المعالجة الطبية — عكس تنبيه \"محتاج تحصيل\" الخاص بالاستقبال) في جدول المواعيد. للدكتور افتراضيًا، وقابلة للمنح الفردي لأي دور تاني (مدير عيادة مثلاً).",
  },
  {
    key: "create_collection_requests_all_doctors",
    label:
      "إدخال طلبات التحصيل لكل الأطباء من الجدول — مخصص لدكتورة/موظف إدخال البيانات، مع بقاء التحصيل منسوبًا لطبيب الموعد الأصلي",
  },
  {
    key: "send_staff_chat_to_doctors",
    label: "إرسال شات لطبيب معيّن أو لكل الأطباء — للطبيب فقط؛ بدونه يرسل الطبيب للاستقبال فقط",
  },
] as const;

export type PermissionKey = (typeof PERMISSION_DEFS)[number]["key"];

export const ROLE_DEFAULT_PERMISSIONS: Record<Role, PermissionKey[]> = {
  admin: [
    "reports_full",
    "collect_payments",
    "manage_inventory",
    "edit_inventory_catalog",
    "manage_expenses",
    "manage_settings",
    "schedule_all_rooms",
    "schedule_edit",
    "override_visit_doctor",
    "edit_old_visits",
    "edit_invoice_payments",
    "delete_visits",
    "view_invoice_totals",
    "view_patient_billing",
    "edit_patient_info",
    "edit_visit_assistant_doctor",
    "edit_ortho_visit_after_save",
    "undo_ortho_inventory_deduction",
  ],
  clinic_manager: [
    "reports_full",
    "manage_inventory",
    "schedule_all_rooms",
    "override_visit_doctor",
    "edit_old_visits",
    "edit_invoice_payments",
    "view_invoice_totals",
    "view_patient_billing",
    "edit_visit_assistant_doctor",
  ],
  accountant: [
    "reports_full",
    "collect_payments",
    "manage_expenses",
    "edit_invoice_payments",
    "view_invoice_totals",
    "view_patient_billing",
  ],
  // manage_inventory ضمن الافتراضي هنا عشان الاستقبال كان عنده وصول للمخزون
  // أصلاً (رابط ثابت في القائمة قبل ما يبقى صلاحية) — عشان التحويل للنظام
  // الجديد ميقفلش حاجة كانت شغالة بالفعل. لسه ممكن تُسحب من مستخدم استقبال
  // معيّن من الإعدادات لو حابب.
  reception: [
    "collect_payments",
    "schedule_all_rooms",
    "schedule_edit",
    "view_patient_billing",
    "manage_inventory",
    "edit_patient_info",
    "edit_visit_assistant_doctor",
    "upload_ortho_photos",
  ],
  // الدكتور افتراضيًا يشوف الجدول المركزي لشيفته/غرفته بس النهاردة، وبشكل عرض فقط
  // (من غير حجز أو تغيير حالة) — الأدمن يقدر يوسّع الصلاحيات دي لدكتور معيّن من
  // صفحة الإعدادات لو حابب (schedule_all_rooms و/أو schedule_edit).
  doctor: ["reports_own", "view_needs_treatment_reminder"],
};
