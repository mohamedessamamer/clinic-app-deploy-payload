import type { ColumnType, Generated } from "kysely";

export interface DoctorsTable {
  id: Generated<number>;
  full_name: string;
  active: Generated<number>;
  // دفعة 22: هل الدكتور ده "استشاري" (عنده دكاترة مساعدين معرفين تحته، جدول
  // consultant_assistants تحت) — 0/1.
  is_consultant: Generated<number>;
  created_at: Generated<string>;
}

// ربط استشاري بدكاترة مساعدين (many-to-many، دفعة 22) — استشاري واحد ممكن
// يكون عنده أكتر من مساعد، ومساعد نظريًا ممكن يشتغل تحت أكتر من استشاري.
export interface ConsultantAssistantsTable {
  consultant_doctor_id: number;
  assistant_doctor_id: number;
}

export interface UsersTable {
  id: Generated<number>;
  username: string;
  password_hash: string;
  full_name: string;
  role: "admin" | "doctor" | "reception" | "accountant" | "clinic_manager";
  doctor_id: number | null;
  active: Generated<number>;
  medical_ui_language: Generated<"en" | "ar">;
  created_at: Generated<string>;
}

export interface RoomsTable {
  id: Generated<number>;
  name: string;
  created_at: Generated<string>;
}

export interface ShiftsTable {
  id: Generated<number>;
  room_id: number;
  doctor_id: number;
  shift_date: string;
  start_time: string;
  end_time: string;
  created_at: Generated<string>;
}

export interface DoctorWeeklyShiftsTable {
  id: Generated<number>;
  room_id: number;
  weekday: number;
  doctor_id: number;
  start_time: string;
  end_time: string;
  created_at: Generated<string>;
}

export interface DoctorDateShiftsTable {
  id: Generated<number>;
  room_id: number;
  doctor_id: number;
  shift_date: string;
  created_by: number | null;
  created_at: Generated<string>;
}

export interface ServicesTable {
  id: Generated<number>;
  name: string;
  name_en: string | null;
  category: string | null;
  default_price: Generated<number>;
  code: string | null;
  price_note: string | null;
  prepaid: Generated<number>;
  created_at: Generated<string>;
}

export interface ServiceDoctorsTable {
  service_id: number;
  doctor_id: number;
}

export interface PatientsTable {
  id: Generated<number>;
  file_number: string;
  full_name: string;
  age: number | null; // قديم — للمرضى اللي اتسجلوا قبل ما نبدأ نطلب تاريخ الميلاد.
  birth_date: string | null; // YYYY-MM-DD — المصدر الحالي لحساب السن، شوف src/lib/age.ts.
  phone_country_code: Generated<string>;
  phone: string | null;
  address: string | null;
  created_at: Generated<string>;
}

export interface AppointmentsTable {
  id: Generated<number>;
  patient_id: number;
  room_id: number;
  doctor_id: number;
  appointment_date: string;
  start_time: string;
  duration_minutes: number | null;
  status: Generated<"booked" | "attended" | "done" | "cancelled" | "no_show">;
  notes: string | null;
  pending_service_id: number | null;
  pending_price: number | null;
  pending_discount_percent: number | null;
  // "المريض جاي يعمل إيه" — دفعة 26. شوف التعليق فوق tryAddColumn في client.ts.
  purpose_type: "bonding_upper" | "bonding_lower" | "service" | null;
  purpose_service_id: number | null;
  // دفعة 27 (P3.2): ربط بفاتورة مفتوحة فعلية — شوف التعليق فوق tryAddColumn.
  purpose_linked_invoice_id: number | null;
  created_at: Generated<string>;
}

export interface VisitsTable {
  id: Generated<number>;
  patient_id: number;
  visit_date: ColumnType<string, string | undefined, string>;
  service_id: number | null;
  notes: string | null;
  primary_doctor_id: number | null;
  performing_doctor_id: number | null;
  room_id: number | null;
  created_by: number | null;
  appointment_id: number | null;
  created_at: Generated<string>;
  notes_synced_from_ortho: Generated<number>;
}

export interface InvoicesTable {
  id: Generated<number>;
  visit_id: number | null;
  patient_id: Generated<number | null>;
  doctor_id: Generated<number | null>;
  appointment_id: Generated<number | null>;
  service_id: Generated<number | null>;
  invoice_date: Generated<string>;
  amount: Generated<number>;
  paid: Generated<number>;
  discount_percent: Generated<number>;
  price_overridden: Generated<number>;
  payment_method: string | null;
  parent_invoice_id: number | null;
  original_price: number | null;
  created_at: Generated<string>;
}

export interface CollectionRequestsTable {
  id: Generated<number>;
  appointment_id: number;
  patient_id: number;
  doctor_id: number;
  service_id: number | null;
  requested_amount: number | null;
  status: Generated<"pending" | "settled" | "cancelled">;
  requested_by: number;
  requested_at: Generated<string>;
  settled_by: number | null;
  settled_at: string | null;
  cancelled_by: number | null;
  cancelled_at: string | null;
}

export interface PatientCreditsTable {
  id: Generated<number>;
  patient_id: number;
  appointment_id: number | null;
  original_amount: number;
  available_amount: number;
  payment_method: string | null;
  received_by: number;
  received_at: Generated<string>;
  note: string | null;
  status: Generated<"active" | "used" | "refunded">;
}

export interface ClinicSettingsTable {
  key: string;
  value: string;
}

export interface NotificationCasesTable {
  id: Generated<number>;
  rule_key: string;
  patient_id: number;
  doctor_id: number | null;
  last_visit_date: string | null;
  status: Generated<"open" | "snoozed" | "resolved">;
  last_stage_days: Generated<number>;
  last_notified_at: string | null;
  reason: string | null;
  next_review_date: string | null;
  resolved_by: number | null;
  resolved_at: string | null;
  updated_at: Generated<string>;
  created_at: Generated<string>;
}

export interface NotificationsTable {
  id: Generated<number>;
  recipient_user_id: number;
  type: string;
  title: string;
  body: string;
  patient_id: number | null;
  notification_case_id: number | null;
  dedupe_key: string;
  read_at: string | null;
  expires_at: string;
  created_at: Generated<string>;
}

export interface ChatMessagesTable {
  id: Generated<number>;
  sender_user_id: number;
  recipient_user_id: number | null;
  audience: "reception" | "doctor" | "all_doctors";
  body: string;
  created_at: Generated<string>;
}

export interface ChatReadStatesTable {
  user_id: number;
  last_read_message_id: number;
  updated_at: Generated<string>;
}

export interface AuditLogTable {
  id: Generated<number>;
  entity_type: string;
  entity_id: number;
  field: string;
  old_value: string | null;
  new_value: string | null;
  reason: string | null;
  changed_by: number | null;
  changed_at: Generated<string>;
  // تاريخ الحدث الفعلي (زي تاريخ زيارة اتسجلت بأثر رجعي) لو مختلف عن changed_at
  // (وقت الحفظ الفعلي). اختياري — NULL يعني ارجع لـchanged_at.
  event_date: string | null;
}

export interface PatientImageGroupsTable {
  id: Generated<number>;
  patient_id: number;
  label: string | null;
  taken_at: Generated<string>;
  created_at: Generated<string>;
}

export interface PatientImagesTable {
  id: Generated<number>;
  group_id: number;
  file_path: string;
  rotation: Generated<number>;
  created_at: Generated<string>;
}

export interface InventoryItemsTable {
  id: Generated<number>;
  name: string;
  quantity: Generated<number>;
  unit: string | null;
  expiry_date: string | null;
  low_stock_threshold: Generated<number>;
  product_id: number | null;
  supplier_id: number | null;
  attribute_value_ids: string | null;
  item_code: string | null;
  ortho_usage: string | null;
  reorder_quantity: Generated<number>;
  critical_stock_threshold: Generated<number>;
  specialty_id: number | null;
  category_id: number | null;
  catalog_group: string | null;
  auto_deduction_key: string | null;
  available_in_clinical_selection: Generated<number>;
  active: Generated<number>;
  is_general_consumable: Generated<number>;
  created_at: Generated<string>;
}

export interface InventorySupplyBatchesTable {
  id: Generated<number>;
  item_id: number;
  supplier_id: number | null;
  brand: string | null;
  quantity_received: number;
  quantity_remaining: number;
  total_cost: number | null;
  received_at: Generated<string>;
  note: string | null;
  created_by: number | null;
  created_at: Generated<string>;
}

export interface InventoryStockMovementsTable {
  id: Generated<number>;
  item_id: number;
  batch_id: number | null;
  appointment_id: number | null;
  movement_type: "supply" | "count_adjustment" | "ortho_use" | "general_consumption" | "return";
  quantity: number;
  note: string | null;
  created_by: number | null;
  created_at: Generated<string>;
}

export interface InventoryConsumableRulesTable {
  item_id: number;
  quantity_per_completed_appointment: number;
  active: Generated<number>;
  updated_at: Generated<string>;
}

export interface InventorySpecialtiesTable {
  id: Generated<number>;
  name: string;
  parent_id: number | null;
  active: Generated<number>;
  created_at: Generated<string>;
}

export interface InventoryCategoriesTable {
  id: Generated<number>;
  specialty_id: number;
  name: string;
  active: Generated<number>;
  created_at: Generated<string>;
}

export interface InventoryProductsTable {
  id: Generated<number>;
  category_id: number;
  name: string;
  active: Generated<number>;
  created_at: Generated<string>;
}

export interface InventoryAttributeGroupsTable {
  id: Generated<number>;
  product_id: number;
  name: string;
  sort_order: Generated<number>;
}

export interface InventoryAttributeValuesTable {
  id: Generated<number>;
  attribute_group_id: number;
  value: string;
  sort_order: Generated<number>;
  active: Generated<number>;
}

export interface InventoryUnitsTable {
  id: Generated<number>;
  name: string;
  short_name: string;
  active: Generated<number>;
}

export interface InventorySuppliersTable {
  id: Generated<number>;
  name: string;
  phone_country_code: Generated<string>;
  phone: string | null;
  notes: string | null;
  active: Generated<number>;
  created_at: Generated<string>;
}

export interface InventoryPurchaseDraftsTable {
  id: Generated<number>;
  supplier_id: number;
  status: Generated<'open' | 'sent' | 'closed'>;
  created_at: Generated<string>;
  updated_at: Generated<string>;
}

export interface InventoryPurchaseDraftItemsTable {
  id: Generated<number>;
  draft_id: number;
  item_id: number;
  suggested_quantity: number;
  created_at: Generated<string>;
}

export interface InventoryStockAlertsTable {
  item_id: number;
  level: 'low' | 'critical';
  cycle: Generated<number>;
  resolved_at: string | null;
  updated_at: Generated<string>;
}

export interface UserPermissionsTable {
  user_id: number;
  permission_key: string;
  granted: number;
}

// شارت تشخيص وخطة علاج التقويم — سجل واحد بس لكل مريض (patient_id UNIQUE).
// شوف التعليق فوق CREATE TABLE في schema.sql للتفاصيل.
export interface OrthodonticChartsTable {
  id: Generated<number>;
  patient_id: number;
  sex: "male" | "female" | null;
  chief_complaint: string | null;
  past_medical_history: string | null;
  missing_teeth: string | null; // JSON array نصي
  antero_posterior: "class1" | "class2" | "class3" | null;
  facial_height: "increased" | "average" | "decreased" | null;
  mx_incisor_inclination: "proclined" | "average" | "retroclined" | null;
  mn_incisor_inclination: "proclined" | "average" | "retroclined" | null;
  molar_relation_right: "class1" | "class2" | "class3" | null;
  molar_relation_left: "class1" | "class2" | "class3" | null;
  overbite: "open_bite" | "average" | "deep_bite" | null;
  overjet: "increased" | "average" | "decreased" | null;
  midline_upper_direction: "right" | "left" | null;
  midline_upper_mm: number | null;
  midline_lower_direction: "right" | "left" | null;
  midline_lower_mm: number | null;
  space_upper_type: "crowding" | "spacing" | null;
  space_upper_mm: number | null;
  space_lower_type: "crowding" | "spacing" | null;
  space_lower_mm: number | null;
  sna_case: number | null;
  snb_case: number | null;
  anb_case: number | null;
  mma_case: number | null;
  u1_pp_case: number | null;
  l1_mp_case: number | null;
  nasolabial_case: number | null;
  nasolabial_angle: "acute" | "average" | "obtuse" | null;
  lips: "competent" | "incompetent" | null;
  extraction_choice: "extraction" | "non_extraction" | null;
  extraction_teeth: string | null; // JSON array نصي
  anchorage: "minimal" | "moderate" | "maximum" | null;
  anchorage_note: string | null;
  hints: string | null;
  // تركيب التقويم (bonding) والريبوندينج — دفعة 25 (تكملة). فك علوي/سفلي كل
  // واحد بيتسجل مرة واحدة بس (الأكشن نفسه بيرفض أي محاولة تانية لو bonding_*_date
  // متسجل بالفعل)، وبيخصم من المخزون وقت التسجيل. الريبوندينج تكراري لأي سن،
  // شوف rebonding_counts/broken_teeth.
  prescription: string | null; // "Roth" / "MBT" / "Andrews" أو نص حر تاني
  bonding_upper_bracket_item_id: number | null;
  bonding_upper_bracket_qty: number | null;
  bonding_upper_tube_item_id: number | null;
  bonding_upper_tube_qty: number | null;
  bonding_upper_date: string | null;
  bonding_upper_not_bonded_teeth: string | null; // JSON array نصي
  bonding_lower_bracket_item_id: number | null;
  bonding_lower_bracket_qty: number | null;
  bonding_lower_tube_item_id: number | null;
  bonding_lower_tube_qty: number | null;
  bonding_lower_date: string | null;
  bonding_lower_not_bonded_teeth: string | null; // JSON array نصي
  // broken_teeth: أسنان براكتها مكسورة/واقعة دلوقتي (لسه ماترّكبتش تاني) — علم
  // حالة، مش سجل تاريخي. بيتصفّر أوتوماتيك للسن لما يتسجل ريبوندينج عليه.
  broken_teeth: string | null; // JSON array نصي
  // rebonding_counts: عدد مرات الريبوندينج التراكمي لكل سن — JSON object نصي
  // {"UR6": 2, "LL4": 1}. بيزيد واحد كل مرة confirmRebondingAction بينفذ.
  rebonding_counts: string | null;
  // tooth_comments: ملاحظة نصية حرة لأي سن — JSON object نصي {"UR6": "..."}.
  // بيتحفظ مع باقي الشارت (زرار الحفظ العادي)، مش أكشن فوري.
  tooth_comments: string | null;
  // شارت التقويم v2 (دمج 2026-08-27) — شوف التعليق في schema.sql/client.ts.
  // tooth_states: JSON object نصي {"16": {"bracket":"bonded","extracted":false,
  // "debondDate":null,"bondedDate":"...","rebondCount":0}, ...} — مصدر الحقيقة
  // لحالة كل سن في الشارت التفاعلي (أدق من bonding_upper/lower_* اللي بتاعة
  // الفك ككل فوق).
  tooth_states: string | null;
  strip_counts: string | null; // JSON object نصي {gapId: عدد}
  miniscrews: string | null; // JSON object نصي {gapId: true}
  // شارت التقويم v2 — حقول أعلى الصفحة الجديدة، شوف التعليق في client.ts.
  bracket_type: string | null;
  slot: string | null;
  extraction_quadrants: string | null; // JSON object نصي {ur,ul,lr,ll}
  anchorage_device: string | null;
  treatment_note: string | null;
  created_by: number | null;
  updated_by: number | null;
  created_at: Generated<string>;
  updated_at: Generated<string>;
}

// شارت التقويم v2 — زيارات الـFollow up (صف واحد لكل زيارة). شوف التعليق في
// schema.sql فوق CREATE TABLE ortho_visits للتفاصيل الكاملة.
export interface OrthoVisitsTable {
  id: Generated<number>;
  patient_id: number;
  visit_date: string;
  service: string | null;
  upper_wire_size: string | null;
  upper_wire_type: string | null;
  lower_wire_size: string | null;
  lower_wire_type: string | null;
  note: string | null;
  elastics_dispensed: Generated<number>;
  elastics_size: string | null;
  otie_color: string | null;
  power_chain_qty: number | null;
  buttons_qty: number | null;
  compressed_coil_mm: number | null;
  upper_wire_item_id: number | null;
  lower_wire_item_id: number | null;
  elastic_item_id: number | null;
  otie_item_id: number | null;
  power_chain_item_id: number | null;
  buttons_item_id: number | null;
  compressed_coil_item_id: number | null;
  bonding_bracket_item_id: number | null;
  bonding_bracket_brand: string | null;
  bonding_tube_item_id: number | null;
  doctor_id: number | null;
  bonding_applied: Generated<number>;
  created_by: number | null;
  updated_by: number | null;
  created_at: Generated<string>;
  updated_at: Generated<string>;
}

export interface OrthodonticBracketStockTable {
  id: Generated<number>;
  brand: string;
  fdi: number;
  quantity: number;
  updated_at: Generated<string>;
}

export interface OrthodonticBracketStockMovementsTable {
  id: Generated<number>;
  brand: string;
  fdi: number;
  quantity: number;
  movement_type: "case_purchase" | "refill_purchase" | "manual_count" | "ortho_use" | "return";
  patient_id: number | null;
  visit_id: number | null;
  note: string | null;
  created_by: number | null;
  created_at: Generated<string>;
}

// شارت التقويم v2 — سجل خصومات المخزون القابل للـUndo. شوف التعليق في
// schema.sql فوق CREATE TABLE ortho_inventory_deductions.
export interface OrthoInventoryDeductionsTable {
  id: Generated<number>;
  patient_id: number;
  visit_id: number | null;
  item_id: number | null;
  label: string;
  qty: number;
  teeth: string | null; // JSON array نصي لأرقام FDI (خصومات التيوبز المجمّعة)
  deduction_date: string;
  created_by: number | null;
  created_at: Generated<string>;
  undone_by: number | null;
  undone_at: string | null;
}

// شارت التقويم v2 — قوايم الاختيارات القابلة للتعديل من الإعدادات (مقاسات/أنواع
// الوير، ألوان الـO-tie، مقاسات الإيلاستكس).
export interface OrthoOptionListsTable {
  id: Generated<number>;
  category: "wire_size" | "wire_type" | "otie_color" | "elastic_size" | "anchorage_device";
  value: string;
  sort_order: Generated<number>;
  active: Generated<number>;
  created_at: Generated<string>;
}

export interface Database {
  doctors: DoctorsTable;
  consultant_assistants: ConsultantAssistantsTable;
  users: UsersTable;
  user_permissions: UserPermissionsTable;
  rooms: RoomsTable;
  shifts: ShiftsTable;
  doctor_weekly_shifts: DoctorWeeklyShiftsTable;
  doctor_date_shifts: DoctorDateShiftsTable;
  services: ServicesTable;
  service_doctors: ServiceDoctorsTable;
  patients: PatientsTable;
  appointments: AppointmentsTable;
  visits: VisitsTable;
  invoices: InvoicesTable;
  collection_requests: CollectionRequestsTable;
  patient_credits: PatientCreditsTable;
  patient_image_groups: PatientImageGroupsTable;
  patient_images: PatientImagesTable;
  inventory_items: InventoryItemsTable;
  inventory_specialties: InventorySpecialtiesTable;
  inventory_categories: InventoryCategoriesTable;
  inventory_products: InventoryProductsTable;
  inventory_attribute_groups: InventoryAttributeGroupsTable;
  inventory_attribute_values: InventoryAttributeValuesTable;
  inventory_units: InventoryUnitsTable;
  inventory_suppliers: InventorySuppliersTable;
  inventory_purchase_drafts: InventoryPurchaseDraftsTable;
  inventory_purchase_draft_items: InventoryPurchaseDraftItemsTable;
  inventory_stock_alerts: InventoryStockAlertsTable;
  inventory_supply_batches: InventorySupplyBatchesTable;
  inventory_stock_movements: InventoryStockMovementsTable;
  inventory_consumable_rules: InventoryConsumableRulesTable;
  clinic_settings: ClinicSettingsTable;
  notification_cases: NotificationCasesTable;
  notifications: NotificationsTable;
  chat_messages: ChatMessagesTable;
  chat_read_states: ChatReadStatesTable;
  audit_log: AuditLogTable;
  orthodontic_charts: OrthodonticChartsTable;
  ortho_visits: OrthoVisitsTable;
  orthodontic_bracket_stock: OrthodonticBracketStockTable;
  orthodontic_bracket_stock_movements: OrthodonticBracketStockMovementsTable;
  ortho_inventory_deductions: OrthoInventoryDeductionsTable;
  ortho_option_lists: OrthoOptionListsTable;
}
