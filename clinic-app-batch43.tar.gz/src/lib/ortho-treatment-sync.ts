import type { Transaction } from "kysely";
import type { Database } from "@/lib/db/types";

// دفعة 27 (P2.4) — الفصل الكامل بين الملف الطبي والمالي: لو الدكتور دخل
// المعالجة من شارت التقويم (خدمة + مقاسات الأسلاك + الملاحظة الحرة)، تتنسخ
// تلقائيًا لحقل "تفاصيل المعالجة" (notes) في زيارة الملف الطبي المقابلة —
// كباراجراف واحد، وكل بند مفصول بشرطة واضحة. السلك مع الفك (المقاس + النوع)
// يظل بندًا واحدًا، مثل: Upper wire 12 NiTi.
export function buildOrthoTreatmentParagraph(input: {
  service: string | null;
  upperWireSize: string | null;
  upperWireType: string | null;
  lowerWireSize: string | null;
  lowerWireType: string | null;
  elastics: string | null;
  otie: string | null;
  powerChainQty: number | null;
  buttonsQty: number | null;
  compressedCoilMm: number | null;
  note: string | null;
}): string | null {
  const parts: string[] = [];
  if (input.service) parts.push(input.service);
  if (input.upperWireSize && input.upperWireSize !== "Same") {
    parts.push(`Upper wire ${input.upperWireSize} ${input.upperWireType ?? ""}`.trim());
  }
  if (input.lowerWireSize && input.lowerWireSize !== "Same") {
    parts.push(`Lower wire ${input.lowerWireSize} ${input.lowerWireType ?? ""}`.trim());
  }
  if (input.elastics) parts.push(`Elastics ${input.elastics}`);
  if (input.otie) parts.push(`O-tie ${input.otie}`);
  if (input.powerChainQty && input.powerChainQty > 0) parts.push(`Power chain ${input.powerChainQty} pcs`);
  if (input.buttonsQty && input.buttonsQty > 0) parts.push(`Buttons ${input.buttonsQty}`);
  if (input.compressedCoilMm && input.compressedCoilMm > 0) parts.push(`Compressed coil ${input.compressedCoilMm} mm`);
  if (input.note) parts.push(input.note);
  if (parts.length === 0) return null;
  return parts.join(" - ");
}

// "الزيارة المقابلة" في الملف الطبي العادي — بنفس المريض والتاريخ بس. لو فيه
// أكتر من زيارة لنفس المريض في نفس اليوم، بناخد الأحدث.
async function findCorrespondingMedicalVisit(trx: Transaction<Database>, params: { patientId: number; visitDate: string }) {
  return trx
    .selectFrom("visits")
    .select(["id", "notes", "notes_synced_from_ortho"])
    .where("patient_id", "=", params.patientId)
    .where("visit_date", "=", params.visitDate)
    .orderBy("id", "desc")
    .executeTakeFirst();
}

// بيتنادى بعد حفظ (إضافة/تعديل) زيارة متابعة في شارت التقويم. بينسخ الباراجراف
// لحقل notes بتاع الزيارة المقابلة — بس لو مفيش نص يدوي حقيقي مكتوب هناك
// بالفعل (notes فاضي، أو آخر نص كان هو نفسه جاي من مزامنة سابقة). نص كتبه
// الطبيب يدويًا في الملف الطبي نفسه (notes_synced_from_ortho=0) مايتلمسش خالص
// — من غير ما نرفض العملية لو الزيارة المقابلة مش موجودة أصلاً (وقتها ببساطة
// مفيش حاجة تتزامن، زي ما هو متفق).
export async function syncOrthoNoteToMedicalVisit(
  trx: Transaction<Database>,
  params: { patientId: number; visitDate: string; paragraph: string | null; performingDoctorId: number }
) {
  let visit = await findCorrespondingMedicalVisit(trx, params);
  // زيارة التقويم هي سجل طبي أيضًا. في السابق كنا نحدّث زيارة عامة موجودة فقط؛
  // لذلك كان إدخال الشارت يختفي تمامًا لو الطبيب لم ينشئ سطرًا يدويًا قبله.
  // الآن، عند وجود موعد في ذلك اليوم، ننشئ السطر تلقائيًا ونورّث الخدمة والطبيب
  // الأساسي والغرفة من الموعد. أما مقدم الخدمة الفعلي فهو الطبيب الذي اختاره
  // المستخدم في شارت التقويم، وليس بالضرورة صاحب الموعد.
  // لا ننشئ سطرًا فارغًا إذا لم يكتب الطبيب أي تفاصيل.
  if (!visit && params.paragraph) {
    const appointment = await trx
      .selectFrom("appointments")
      .select(["id", "doctor_id", "room_id", "purpose_service_id"])
      .where("patient_id", "=", params.patientId)
      .where("appointment_date", "=", params.visitDate)
      .where("status", "!=", "cancelled")
      .orderBy("start_time")
      .executeTakeFirst();
    if (appointment) {
      const inserted = await trx
        .insertInto("visits")
        .values({
          patient_id: params.patientId,
          visit_date: params.visitDate,
          service_id: appointment.purpose_service_id,
          notes: params.paragraph,
          notes_synced_from_ortho: 1,
          primary_doctor_id: appointment.doctor_id,
          performing_doctor_id: params.performingDoctorId,
          room_id: appointment.room_id,
          appointment_id: appointment.id,
          created_by: null,
        })
        .executeTakeFirst();
      visit = { id: Number(inserted.insertId), notes: params.paragraph, notes_synced_from_ortho: 1 };
    }
  }
  if (!visit) return;
  // اختيار الطبيب داخل شارت التقويم هو مصدر الحقيقة لمقدم الخدمة الفعلي؛ نحدّثه
  // حتى لو كانت ملاحظة الزيارة العامة مكتوبة يدويًا، لكن لا نمسح تلك الملاحظة.
  if (visit.notes && !visit.notes_synced_from_ortho) {
    // الحماية القديمة كانت تمنع المزامنة بالكامل عند وجود ملاحظة يدوية، وده
    // سبب اختفاء تعديلات الشارت. نحافظ على النص اليدوي ونبدّل فقط جزء الشارت
    // المميز، حتى يستمر التحديث كل مرة من غير فقد أي كتابة موجودة.
    const marker = "Orthodontic chart: ";
    const markerIndex = visit.notes.indexOf(marker);
    const manualPart = markerIndex >= 0 ? visit.notes.slice(0, markerIndex).trimEnd() : visit.notes.trimEnd();
    const mergedNotes = params.paragraph ? `${manualPart}${manualPart ? "\n" : ""}${marker}${params.paragraph}` : manualPart || null;
    await trx.updateTable("visits").set({ notes: mergedNotes, performing_doctor_id: params.performingDoctorId }).where("id", "=", visit.id).execute();
    return;
  }
  await trx
    .updateTable("visits")
    .set({
      notes: params.paragraph,
      notes_synced_from_ortho: params.paragraph ? 1 : 0,
      performing_doctor_id: params.performingDoctorId,
    })
    .where("id", "=", visit.id)
    .execute();
}

// بيتنادى بعد حذف زيارة متابعة من شارت التقويم (deleteOrthoVisitAction) —
// بيمسح النص من الزيارة المقابلة بس لو هو نفسه اللي كان جاي من المزامنة.
export async function clearSyncedOrthoNote(trx: Transaction<Database>, params: { patientId: number; visitDate: string }) {
  const visit = await findCorrespondingMedicalVisit(trx, params);
  if (!visit) return;
  if (!visit.notes_synced_from_ortho) {
    const marker = "Orthodontic chart: ";
    const markerIndex = visit.notes?.indexOf(marker) ?? -1;
    if (markerIndex >= 0) {
      await trx.updateTable("visits").set({ notes: visit.notes!.slice(0, markerIndex).trimEnd() || null }).where("id", "=", visit.id).execute();
    }
    return;
  }
  await trx.updateTable("visits").set({ notes: null, notes_synced_from_ortho: 0 }).where("id", "=", visit.id).execute();
}
