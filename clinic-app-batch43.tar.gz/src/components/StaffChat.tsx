"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { getChatDoctorsAction, getStaffChatAction, getStaffChatUnreadCountAction, markStaffChatReadAction, sendStaffChatAction } from "@/app/chat/actions";

type Message = { id: number; body: string; created_at: string; sender_user_id: number; sender_name: string; recipient_user_id: number | null; audience: "reception" | "doctor" | "all_doctors" };
type Doctor = { id: number; full_name: string };

export default function StaffChat({ currentUserId, role }: { currentUserId: number; role: string }) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [open, setOpen] = useState(false);
  const [popup, setPopup] = useState(false);
  const [popupMessage, setPopupMessage] = useState<Message | null>(null);
  const [unreadCount, setUnreadCount] = useState(0);
  const [draft, setDraft] = useState("");
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [recipient, setRecipient] = useState("");
  const [broadcast, setBroadcast] = useState(false);
  const [busy, startTransition] = useTransition();
  const initialized = useRef(false);
  const lastSeenId = useRef(0);
  const listRef = useRef<HTMLDivElement>(null);
  const isDoctor = role === "doctor";
  const isReceptionSide = ["reception", "admin", "clinic_manager"].includes(role);

  async function refreshMessages() {
    const [rows, unread] = await Promise.all([getStaffChatAction(), getStaffChatUnreadCountAction()]);
    const newest = rows.at(-1);
    if (initialized.current && newest && newest.id > lastSeenId.current && newest.sender_user_id !== currentUserId) {
      setPopupMessage(newest);
      setPopup(true);
    }
    if (newest) lastSeenId.current = newest.id;
    initialized.current = true;
    setMessages(rows);
    setUnreadCount(unread);
  }

  useEffect(() => {
    refreshMessages().catch(() => undefined);
    const timer = window.setInterval(() => refreshMessages().catch(() => undefined), 2000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    if (open && (isReceptionSide || isDoctor) && !doctors.length) getChatDoctorsAction().then(setDoctors).catch(() => undefined);
  }, [open, isReceptionSide, isDoctor, doctors.length]);

  useEffect(() => {
    if (open) listRef.current?.scrollTo({ top: listRef.current.scrollHeight });
  }, [open, messages]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  function showChat() {
    setOpen(true);
    setPopup(false);
    setUnreadCount(0);
    markStaffChatReadAction().catch(() => undefined);
  }

  function send() {
    startTransition(async () => {
      const form = new FormData();
      form.set("body", draft);
      if (broadcast) form.set("broadcast", "1");
      if (recipient) form.set("recipient_user_id", recipient);
      const result = await sendStaffChatAction(form);
      if (!result.ok) return window.alert(result.reason || "تعذر إرسال الرسالة.");
      setDraft("");
      await refreshMessages();
    });
  }

  return (
    <>
      <button type="button" onClick={showChat} className="relative h-9 w-9 rounded-full border border-border bg-background hover:bg-primary-soft text-base" title="الشات الداخلي" aria-label="الشات الداخلي">
        ▣
        {unreadCount > 0 && <span className="absolute -top-1 -left-1 h-3.5 w-3.5 rounded-full bg-red-600 border-2 border-surface" aria-label={`${unreadCount} رسالة غير مقروءة`} />}
      </button>
      {popup && !open && (
        <button type="button" onClick={showChat} className="fixed z-50 top-20 left-5 w-72 rounded-xl bg-primary text-white shadow-xl p-3 text-right text-sm">
          <div className="text-[11px] text-white/80 mb-1">{popupMessage?.sender_name ?? "رسالة جديدة"}</div>
          <div className="truncate">{popupMessage?.body ?? ""}</div>
        </button>
      )}
      {open && (
        <section className="fixed z-50 top-20 left-4 w-[min(25rem,calc(100vw-2rem))] h-[min(34rem,calc(100vh-6rem))] card-3d rounded-xl shadow-2xl flex flex-col overflow-hidden" dir="rtl">
          <header className="flex items-center justify-between px-3 py-2 border-b border-border bg-primary-soft">
            <div><strong>شات العيادة</strong><span className="text-xs text-muted mr-2">الرسائل تُحفظ 48 ساعة</span></div>
            <button type="button" onClick={() => setOpen(false)} className="text-lg leading-none" aria-label="إغلاق">×</button>
          </header>
          <div ref={listRef} className="flex-1 overflow-y-auto p-3 space-y-2 bg-background">
            {!messages.length && <p className="text-sm text-muted text-center py-8">ابدأ رسالة للاستقبال أو للأطباء.</p>}
            {messages.map((message) => {
              const mine = message.sender_user_id === currentUserId;
              return (
                <div key={message.id} className={`max-w-[85%] rounded-xl px-3 py-2 text-sm ${mine ? "bg-primary text-white mr-auto" : "bg-surface border border-border ml-auto"}`}>
                  <div className={`text-[10px] mb-1 ${mine ? "text-white/80" : "text-muted"}`}>{mine ? "أنت" : message.sender_name}{message.audience === "all_doctors" ? " — لكل الأطباء" : ""}</div>
                  <p className="whitespace-pre-wrap">{message.body}</p>
                </div>
              );
            })}
          </div>
          <div className="border-t border-border p-2 space-y-2">
            {(isReceptionSide || (isDoctor && doctors.length > 0)) && (
              <div className="flex gap-2 text-xs">
                <select value={recipient} disabled={broadcast} onChange={(event) => setRecipient(event.target.value)} className="min-w-0 flex-1 rounded border border-border bg-background px-2 py-1.5">
                  <option value="">{isDoctor ? "إرسال للاستقبال" : "اختر طبيبًا للرد المباشر"}</option>
                  {doctors.map((doctor) => <option key={doctor.id} value={doctor.id}>{doctor.full_name}</option>)}
                </select>
                <label className="flex items-center gap-1 whitespace-nowrap"><input type="checkbox" checked={broadcast} onChange={(event) => { setBroadcast(event.target.checked); if (event.target.checked) setRecipient(""); }} /> كل الأطباء</label>
              </div>
            )}
            {isDoctor && <p className="text-[11px] text-muted">{recipient || broadcast ? "سيتم الإرسال حسب الاختيار." : "رسالتك ستصل إلى الاستقبال."}</p>}
            <div className="flex gap-2">
              <textarea value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => { if (event.key === "Escape") setOpen(false); if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); send(); } }} rows={2} placeholder="اكتب رسالة…" className="min-w-0 flex-1 rounded border border-border bg-background px-2 py-1.5 text-sm" />
              <button type="button" disabled={busy || !draft.trim()} onClick={send} className="rounded btn-3d-primary px-3 text-sm">إرسال</button>
            </div>
          </div>
        </section>
      )}
    </>
  );
}
