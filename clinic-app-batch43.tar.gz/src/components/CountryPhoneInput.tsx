"use client";

import { useState } from "react";
import { COUNTRY_CALLING_CODES, normalizePhoneNumber } from "@/lib/phone";

export default function CountryPhoneInput({
  defaultCountryCode = "+20",
  defaultPhone = "",
  language = "ar",
  required = false,
}: {
  defaultCountryCode?: string | null;
  defaultPhone?: string | null;
  language?: "ar" | "en";
  required?: boolean;
}) {
  const [countryCode, setCountryCode] = useState(defaultCountryCode || "+20");
  const [phone, setPhone] = useState(normalizePhoneNumber(defaultPhone || ""));
  const egypt = countryCode === "+20";

  return (
    <div className="flex gap-2" dir="ltr">
      <select
        name="phone_country_code"
        value={countryCode}
        onChange={(event) => setCountryCode(event.target.value)}
        aria-label={language === "en" ? "Country calling code" : "كود الدولة"}
        className="w-20 shrink-0 rounded-md border border-border bg-background px-1 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-primary"
      >
        {COUNTRY_CALLING_CODES.map((country) => (
          <option key={country.code} value={country.code}>
            {country.label}
          </option>
        ))}
      </select>
      <input
        name="phone"
        value={phone}
        onChange={(event) => setPhone(normalizePhoneNumber(event.target.value).slice(0, egypt ? 11 : 15))}
        required={required}
        inputMode="numeric"
        maxLength={egypt ? 11 : 15}
        placeholder={egypt ? "01227166444" : "Phone number"}
        className="min-w-0 flex-1 rounded-md border border-border bg-background px-3 py-2 text-base tracking-wide focus:outline-none focus:ring-2 focus:ring-primary"
      />
    </div>
  );
}
