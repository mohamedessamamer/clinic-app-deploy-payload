"use server";

import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";

// سجل النظام: نفس جدول audit_log اللي كان بيتعرض في شاشة الفواتير ليوم واحد بس،
// بس بفلتر فترة كامل. مفيش أي كود في النظام بيمسح من الجدول ده، فكل التاريخ
// المسجَّل موجود ومتاح — اللي كان ناقص هو شاشة تعرضه.

export type SystemLogRow = {
  id: number;
  entityType: string;
  entityId: number;
  event: string;
  oldValue: string | null;
  newValue: string | null;
  reason: string | null;
  changedAt: string;
  changedBy: string | null;
};

export type SystemLogResult =
  | { ok: false; error: string }
  | { ok: true; rows: SystemLogRow[]; truncated: boolean; events: string[] };

const MAX_ROWS = 500;
const DATE = /^\d{4}-\d{2}-\d{2}$/;

// أسماء عربية لأنواع الأحداث. أي حدث جديد مش في القايمة بيتعرض بمفتاحه الخام
// بدل ما يختفي — عشان إضافة حدث جديد في الكود ما تحتاجش تعديل هنا عشان يبان.
export const EVENT_LABELS: Record<string, string> = {
  delete_patient: "حذف مريض",
  update_patient: "تعديل بيانات مريض",
  delete_visit: "حذف زيارة",
  delete_expense: "حذف مصروف",
  clear_expenses_data: "مسح بيانات المصروفات",
  save_compensation_rule: "حفظ قاعدة راتب",
  stop_compensation_rule: "إيقاف قاعدة راتب",
  delete_compensation_rule: "حذف قاعدة راتب",
  end_employment: "إنهاء خدمة موظف",
  delete_document: "حذف مستند HR",
  deactivate_user: "إيقاف مستخدم",
  create_user: "إنشاء مستخدم",
  reset_password: "تصفير كلمة سر",
  update_permissions: "تغيير صلاحيات",
  appointment_status: "تغيير حالة موعد",
  collect_payment: "تحصيل دفعة",
};

export async function getSystemLogAction(params: {
  from: string;
  to: string;
  event?: string;
  userId?: number;
}): Promise<SystemLogResult> {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "view_system_log"))) {
    return { ok: false, error: "مفيش صلاحية عندك لعرض سجل النظام." };
  }
  if (!DATE.test(params.from) || !DATE.test(params.to)) {
    return { ok: false, error: "التاريخ غير صحيح." };
  }
  if (params.to < params.from) {
    return { ok: false, error: "تاريخ النهاية لازم يكون بعد تاريخ البداية." };
  }

  let query = db
    .selectFrom("audit_log")
    .leftJoin("users", "users.id", "audit_log.changed_by")
    .select([
      "audit_log.id",
      "audit_log.entity_type",
      "audit_log.entity_id",
      "audit_log.field",
      "audit_log.old_value",
      "audit_log.new_value",
      "audit_log.reason",
      "audit_log.changed_at",
      "users.full_name as changed_by_name",
    ])
    .where("audit_log.changed_at", ">=", `${params.from} 00:00:00`)
    .where("audit_log.changed_at", "<=", `${params.to} 23:59:59`);

  if (params.event) query = query.where("audit_log.field", "=", params.event);
  if (params.userId) query = query.where("audit_log.changed_by", "=", params.userId);

  // بنجيب صف زيادة عشان نعرف لو فيه أكتر من الحد ونحذّر المستخدم بدل ما نقص
  // النتائج في صمت ويفتكر إن دي كل الأحداث في الفترة.
  const rows = await query.orderBy("audit_log.id", "desc").limit(MAX_ROWS + 1).execute();
  const truncated = rows.length > MAX_ROWS;

  // قايمة الأحداث الموجودة فعلاً في الفترة دي — عشان الفلتر يعرض اللي ليه نتائج بس.
  const eventRows = await db
    .selectFrom("audit_log")
    .select("field")
    .distinct()
    .where("changed_at", ">=", `${params.from} 00:00:00`)
    .where("changed_at", "<=", `${params.to} 23:59:59`)
    .execute();

  return {
    ok: true,
    truncated,
    events: eventRows.map((row) => row.field).sort(),
    rows: rows.slice(0, MAX_ROWS).map((row) => ({
      id: row.id,
      entityType: row.entity_type,
      entityId: row.entity_id,
      event: row.field,
      oldValue: row.old_value,
      newValue: row.new_value,
      reason: row.reason,
      changedAt: row.changed_at,
      changedBy: row.changed_by_name,
    })),
  };
}

export async function getSystemLogUsersAction() {
  const session = await getSession();
  if (!session || !(await hasPermission(session.userId, session.role, "view_system_log"))) return [];
  return db.selectFrom("users").select(["id", "full_name"]).orderBy("full_name").execute();
}
