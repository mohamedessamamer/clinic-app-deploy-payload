"use client";

import { useEffect, useState, useTransition } from "react";
import {
  EVENT_LABELS,
  getSystemLogAction,
  getSystemLogUsersAction,
  type SystemLogResult,
} from "@/app/reports/system-log-actions";

const input = "rounded border border-border bg-background px-2 py-1.5 text-sm";

function eventLabel(event: string) {
  return EVENT_LABELS[event] || event;
}

export default function SystemLogReport() {
  const [range, setRange] = useState({ from: "", to: "" });
  const [event, setEvent] = useState("");
  const [userId, setUserId] = useState("");
  const [users, setUsers] = useState<{ id: number; full_name: string }[]>([]);
  const [result, setResult] = useState<SystemLogResult | null>(null);
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    let cancelled = false;
    getSystemLogUsersAction().then((rows) => {
      if (!cancelled) setUsers(rows);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  function run() {
    startTransition(async () => {
      const data = await getSystemLogAction({
        from: range.from,
        to: range.to,
        event: event || undefined,
        userId: userId ? Number(userId) : undefined,
      });
      setResult(data);
    });
  }

  function preset(days: number) {
    const end = new Date();
    const start = new Date(end.getTime() - days * 86_400_000);
    const iso = (date: Date) => date.toISOString().slice(0, 10);
    setRange({ from: iso(start), to: iso(end) });
  }

  return (
    <section className="card-3d rounded-xl p-5 space-y-4">
      <div>
        <h2 className="font-semibold">سجل النظام</h2>
        <p className="mt-1 text-xs text-muted">
          كل تعديل أو حذف حسّاس اتعمل في النظام: مين عمله وإمتى. السجل محفوظ من أول يوم ومش بيتمسح.
        </p>
      </div>

      <div className="flex flex-wrap items-end gap-2">
        <label className="text-xs text-muted">
          من
          <input
            id="systemlog-from"
            type="date"
            value={range.from}
            onChange={(e) => setRange((current) => ({ ...current, from: e.target.value }))}
            className={`${input} mt-1 block w-40`}
          />
        </label>
        <label className="text-xs text-muted">
          إلى
          <input
            id="systemlog-to"
            type="date"
            value={range.to}
            onChange={(e) => setRange((current) => ({ ...current, to: e.target.value }))}
            className={`${input} mt-1 block w-40`}
          />
        </label>
        <label className="text-xs text-muted">
          نوع الحدث
          <select
            id="systemlog-event"
            value={event}
            onChange={(e) => setEvent(e.target.value)}
            className={`${input} mt-1 block w-48`}
          >
            <option value="">كل الأحداث</option>
            {(result?.ok ? result.events : []).map((key) => (
              <option key={key} value={key}>{eventLabel(key)}</option>
            ))}
          </select>
        </label>
        <label className="text-xs text-muted">
          المستخدم
          <select
            id="systemlog-user"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            className={`${input} mt-1 block w-44`}
          >
            <option value="">كل المستخدمين</option>
            {users.map((user) => (
              <option key={user.id} value={user.id}>{user.full_name}</option>
            ))}
          </select>
        </label>
        <button
          type="button"
          onClick={run}
          disabled={isPending || !range.from || !range.to}
          className="h-9 rounded-md btn-3d-primary px-4 text-sm font-medium disabled:opacity-50"
        >
          {isPending ? "..." : "عرض التقرير"}
        </button>
        <div className="flex gap-1">
          <button type="button" onClick={() => preset(7)} className="h-9 rounded border border-border px-2 text-xs">آخر أسبوع</button>
          <button type="button" onClick={() => preset(30)} className="h-9 rounded border border-border px-2 text-xs">آخر شهر</button>
          <button type="button" onClick={() => preset(365)} className="h-9 rounded border border-border px-2 text-xs">آخر سنة</button>
        </div>
      </div>

      {result && !result.ok && (
        <p className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{result.error}</p>
      )}

      {result?.ok && result.truncated && (
        <p className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
          الفترة دي فيها أحداث أكتر من الحد المعروض (500). ضيّق الفترة أو فلتر بنوع الحدث عشان تشوف الباقي.
        </p>
      )}

      {result?.ok && (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-right">
                <th className="p-2 whitespace-nowrap">الوقت</th>
                <th className="p-2">الحدث</th>
                <th className="p-2">التفاصيل</th>
                <th className="p-2 whitespace-nowrap">بواسطة</th>
              </tr>
            </thead>
            <tbody>
              {result.rows.map((row) => (
                <tr key={row.id} className="border-b border-border align-top">
                  <td className="p-2 whitespace-nowrap text-xs text-muted">{row.changedAt.slice(0, 16).replace("T", " ")}</td>
                  <td className="p-2 whitespace-nowrap font-medium">{eventLabel(row.event)}</td>
                  <td className="p-2">
                    {row.newValue || "—"}
                    {row.oldValue ? <span className="text-xs text-muted"> (كان: {row.oldValue})</span> : null}
                    {row.reason ? <span className="text-xs text-muted"> — {row.reason}</span> : null}
                  </td>
                  <td className="p-2 whitespace-nowrap">{row.changedBy || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {!result.rows.length && <p className="py-6 text-center text-sm text-muted">لا توجد أحداث في الفترة المختارة.</p>}
        </div>
      )}
    </section>
  );
}
