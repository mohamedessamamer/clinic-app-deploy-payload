"use client";

import { useMemo, useState, useTransition, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { receiveOrthodonticBracketCaseAction, receiveOrthodonticBracketRefillAction, setOrthodonticBracketCountAction } from "@/app/inventory/actions";
import { BRACKET_BRANDS, BRACKET_TEETH } from "@/lib/ortho/bracket-stock";

type Cell = { brand: string; fdi: number; quantity: number };
const upper = BRACKET_TEETH.slice(0, 10);
const lower = BRACKET_TEETH.slice(10);

export default function OrthodonticBracketStock({ cells, canEditCatalog }: { cells: Cell[]; canEditCatalog: boolean }) {
  const [brand, setBrand] = useState<(typeof BRACKET_BRANDS)[number]>("American");
  const [isPending, startTransition] = useTransition();
  const router = useRouter();
  const stock = useMemo(() => new Map(cells.filter((cell) => cell.brand === brand).map((cell) => [cell.fdi, cell.quantity])), [cells, brand]);
  function submit(action: (formData: FormData) => Promise<void>) {
    return (event: FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      const form = event.currentTarget;
      startTransition(async () => { await action(new FormData(form)); form.reset(); router.refresh(); });
    };
  }
  return <section className="card-3d rounded-xl p-5 space-y-4">
    <div><h2 className="font-semibold">براكتس — جرد الفصوص</h2><p className="text-xs text-muted mt-1">كل مربع يمثل السن نفسه في الـInteractive chart. العدد الظاهر هو الرصيد الحالي لهذا السن. الـCase يضيف قطعة واحدة لكل واحد من 20 سنًا، والـRefill يضاف لسن واحد.</p></div>
    <div className="flex flex-wrap gap-2 items-end">
      <label className="text-sm"><span className="block text-xs text-muted mb-1">الشركة</span><select value={brand} onChange={(event) => setBrand(event.target.value as typeof brand)} className="rounded-md border border-border bg-background px-2 py-1.5">{BRACKET_BRANDS.map((value) => <option key={value}>{value}</option>)}</select></label>
      <form onSubmit={submit(receiveOrthodonticBracketCaseAction)} className="flex gap-1.5 items-end"><input type="hidden" name="brand" value={brand} /><label className="text-sm"><span className="block text-xs text-muted mb-1">شراء Case</span><input name="cases" type="number" min="1" step="1" required placeholder="عدد الحالات" className="w-28 rounded-md border border-border bg-background px-2 py-1.5" /></label><button disabled={isPending} className="rounded-md btn-3d-primary px-3 py-1.5 text-sm disabled:opacity-60">إضافة Case</button></form>
    </div>
    <div className="overflow-x-auto"><table className="min-w-[680px] w-full text-center border-separate border-spacing-1"><thead><tr className="text-xs text-muted"><th className="text-right px-2">الفك / رقم السن</th>{upper.map((fdi) => <th key={fdi}>{fdi}</th>)}</tr></thead><tbody>
      {[["علوي", upper], ["سفلي", lower]].map(([label, teeth]) => <tr key={String(label)}><th className="text-right px-2 text-sm">{label}</th>{(teeth as readonly number[]).map((fdi) => <td key={fdi} className="rounded-md border border-border bg-background p-1 align-top"><div className="text-[10px] text-muted">سن {fdi}</div>{canEditCatalog ? <form onSubmit={submit(setOrthodonticBracketCountAction)} className="flex justify-center gap-1"><input type="hidden" name="brand" value={brand} /><input type="hidden" name="fdi" value={fdi} /><input name="quantity" type="number" min="0" step="1" defaultValue={stock.get(fdi) ?? 0} aria-label={`رصيد ${brand} للسن ${fdi}`} className="w-11 rounded border border-border bg-background px-1 py-1 text-center text-sm" /><button disabled={isPending} title="حفظ الجرد اليدوي" className="text-xs text-primary">✓</button></form> : <b className="text-sm">{stock.get(fdi) ?? 0}</b>}</td>)}</tr>)}
    </tbody></table></div>
    <form onSubmit={submit(receiveOrthodonticBracketRefillAction)} className="flex flex-wrap items-end gap-2 rounded-lg border border-border bg-primary-soft/30 p-3"><input type="hidden" name="brand" value={brand} /><label className="text-sm"><span className="block text-xs text-muted mb-1">Refill لسن</span><select name="fdi" required defaultValue="" className="rounded-md border border-border bg-background px-2 py-1.5"><option value="" disabled>اختر السن</option>{BRACKET_TEETH.map((fdi) => <option key={fdi} value={fdi}>{fdi}</option>)}</select></label><label className="text-sm"><span className="block text-xs text-muted mb-1">عدد الفصوص</span><input name="quantity" type="number" min="1" step="1" required className="w-24 rounded-md border border-border bg-background px-2 py-1.5" /></label><button disabled={isPending} className="rounded-md border border-primary px-3 py-1.5 text-sm text-primary disabled:opacity-60">إضافة Refill</button></form>
  </section>;
}
