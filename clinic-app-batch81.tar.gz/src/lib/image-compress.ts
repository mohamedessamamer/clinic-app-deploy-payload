// ضغط الصور على المتصفح قبل الرفع — نفس فكرة الـ compressImage اللي في
// البروتوتايب المعزول (src/components/prototype/OrthoChartV2.tsx)، لكن هنا
// بترجع Blob/File حقيقي يتبعت فعلاً في FormData بدل object URL للمعاينة بس.
//
// الهدف (رد على سؤال المستخدم 2026-08-27): تصغير حجم الملف من غير ما الجودة
// أو أبعاد الصورة الأصلية تتأثر بشكل ملحوظ:
// - لو الصورة أصلاً صغيرة بترجع كما هي.
// - غير كده بيتم تصغير أكبر بعد إلى 2400px وإعادة ترميز الصور الفوتوغرافية
//   JPEG بجودة 80%، مع محاولة ثانية عند الملفات شديدة التفاصيل.
// - PNG الشفاف يظل PNG حتى لا تضيع الشفافية؛ PNG غير الشفاف يتحول إلى JPG.
// - ملفات PDF أو أي حاجة مش image/* بترجع زي ما هي (مفيش canvas ينفع يضغطها).
const MAX_DIM = 2400;
const JPEG_QUALITY = 0.8;
const FALLBACK_JPEG_QUALITY = 0.78;
const SKIP_IF_UNDER_BYTES = 300 * 1024;
const RETRY_ABOVE_BYTES = 1500 * 1024;

export function compressImageFile(file: File): Promise<File> {
  return new Promise((resolve) => {
    if (!file.type.startsWith("image/") || file.type === "image/svg+xml") {
      resolve(file);
      return;
    }
    if (file.size <= SKIP_IF_UNDER_BYTES) {
      resolve(file);
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        const needsResize = width > MAX_DIM || height > MAX_DIM;
        if (needsResize) {
          const scale = MAX_DIM / Math.max(width, height);
          width = Math.round(width * scale);
          height = Math.round(height * scale);
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve(file);
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        let keepPng = false;
        if (file.type === "image/png") {
          try {
            const pixels = ctx.getImageData(0, 0, width, height).data;
            for (let index = 3; index < pixels.length; index += 4) {
              if (pixels[index] < 255) { keepPng = true; break; }
            }
          } catch { keepPng = true; }
        }
        const outputType = keepPng ? "image/png" : "image/jpeg";
        const finish = (blob: Blob | null) => {
            if (!blob) {
              resolve(file);
              return;
            }
            // لو الناتج المضغوط طلع أكبر من الأصلي (نادر، بيحصل مع صور
            // مضغوطة أصلاً جدًا) بنسيب الأصلي زي ما هو.
            if (blob.size >= file.size) {
              resolve(file);
              return;
            }
            const extension = outputType === "image/png" ? ".png" : ".jpg";
            const newName = file.name.replace(/\.[a-zA-Z0-9]+$/, "") + extension;
            resolve(new File([blob], newName, { type: outputType, lastModified: Date.now() }));
        };
        canvas.toBlob((firstBlob) => {
          if (outputType === "image/jpeg" && firstBlob && firstBlob.size > RETRY_ABOVE_BYTES) {
            canvas.toBlob(finish, outputType, FALLBACK_JPEG_QUALITY);
            return;
          }
          finish(firstBlob);
        }, outputType, JPEG_QUALITY);
      };
      img.onerror = () => resolve(file);
      img.src = reader.result as string;
    };
    reader.onerror = () => resolve(file);
    reader.readAsDataURL(file);
  });
}
