"use client";

import { useMemo, useRef, useState } from "react";
import { addImageGroupAction } from "@/app/patients/[id]/actions";
import { getClinicToday } from "@/lib/clinic-date";
import { compressImageFile } from "@/lib/image-compress";

export default function AddImageGroupForm({ patientId, language = "en" }: { patientId: number; language?: "en" | "ar" }) {
  const today = useMemo(() => getClinicToday(), []);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fileNames, setFileNames] = useState<string[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [compressing, setCompressing] = useState(false);
  const en = language === "en";

  // بيحط الملفات (من الاختيار العادي أو السحب والإفلات) على الـ input نفسه
  // عشان تتبعت مع الفورم عادي (زي ما لو المستخدم اختارها بالضغط "Choose Files").
  async function setFilesOnInput(files: FileList | File[]) {
    if (!fileInputRef.current) return;
    setCompressing(true);
    const prepared = await Promise.all(Array.from(files).map(compressImageFile));
    const dt = new DataTransfer();
    for (const f of prepared) dt.items.add(f);
    fileInputRef.current.files = dt.files;
    setFileNames(Array.from(dt.files).map((f) => f.name));
    setCompressing(false);
  }

  function handleDrop(e: React.DragEvent<HTMLDivElement>) {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files?.length) void setFilesOnInput(e.dataTransfer.files);
  }

  return (
    <form
      action={addImageGroupAction}
      encType="multipart/form-data"
      onSubmit={() => {
        // نصفّر معاينة الأسماء بعد ما الفورم يتبعت (بعد الحدث ده الـ browser
        // يبقى لسه قاري input.files الحالية عشان يبعتها، فالتصفير هنا آمن).
        setTimeout(() => setFileNames([]), 0);
      }}
      className="flex flex-wrap items-end gap-2 border-t border-dashed border-border pt-3 mt-1"
    >
      <input type="hidden" name="patient_id" value={patientId} />
      <div>
        <label className="block text-xs text-muted mb-1">{en ? "Date" : "التاريخ"}</label>
        <input
          type="date"
          name="taken_at"
          defaultValue={today}
          className="rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>
      <div>
        <label className="block text-xs text-muted mb-1">{en ? "Description (optional)" : "وصف (اختياري)"}</label>
        <input
          name="label"
          placeholder={en ? "Example: panoramic X-ray" : "مثال: أشعة بانوراما"}
          className="rounded-md border border-border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>
      <div className="flex-1 min-w-[240px]">
        <label className="block text-xs text-muted mb-1">{en ? "Photos / X-rays" : "الصور/الأشعة"}</label>
        <div
          role="button"
          tabIndex={0}
          onClick={() => fileInputRef.current?.click()}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") fileInputRef.current?.click();
          }}
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={`rounded-md border-2 border-dashed px-3 py-2.5 text-xs text-center cursor-pointer transition-colors ${
            isDragging ? "border-primary bg-primary-soft" : "border-border hover:bg-primary-soft/40"
          }`}
        >
          {compressing ? <span className="text-primary-dark font-medium">{en ? "Compressing images…" : "جاري ضغط الصور…"}</span> : fileNames.length > 0 ? (
            <span className="text-primary-dark font-medium">
              {en ? `${fileNames.length} photo/file selected — ` : `${fileNames.length} صورة/ملف محدد — `}{fileNames.slice(0, 2).join("، ")}
              {fileNames.length > 2 ? "..." : ""}
            </span>
          ) : (
            <span className="text-muted">{en ? "Drag and drop photos here, or click to select multiple files" : "اسحب الصور هنا وأفلتها، أو دوس هنا للاختيار — تقدر تختار أو تسحب أكتر من صورة مرة واحدة"}</span>
          )}
          <input
            ref={fileInputRef}
            type="file"
            name="files"
            multiple
            accept="image/*,.pdf"
            onChange={(e) => { if (e.target.files) void setFilesOnInput(e.target.files); }}
            className="hidden"
          />
        </div>
      </div>
      <button
        type="submit"
        disabled={compressing || fileNames.length === 0}
        className="rounded-md btn-3d-primary px-4 py-1.5 text-sm font-medium transition-colors"
      >
        {en ? "+ Add group" : "+ إضافة مجموعة"}
      </button>
    </form>
  );
}
