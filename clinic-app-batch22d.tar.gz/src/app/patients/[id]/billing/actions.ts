"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db/client";
import { getSession } from "@/lib/session";
import { hasPermission } from "@/lib/permissions";
import { logOverride } from "@/lib/audit";

// كود خدمة "متابعة" — نفس المعيار المستخدم في بوكس التحصيل بالجدول المركزي
// (src/app/appointments/billing-actions.ts).
const FOLLOWUP_SERVICE_CODE = "0";

// إضافة خدمة (وتحصيل دفعها) من داخل الملف المالي للمريض مباشرة — دي الطريقة
// الوحيدة دلوقتي لتسجيل خدمة/زيارة مالية بره سياق الجدول المركزي (بديل بوكس
// "إضافة خدمة" اللي كان تحت الجدول في /front-desk وانشال، دفعة 20). محصورة
// بصلاحية view_patient_billing — نفس الصلاحية اللي بتتحكم في عرض الصفحة دي
// أصلاً، عشان مين يقدر يشوف الملف المالي هو نفسه اللي يقدر يسجل عليه خدمة.
export async function addPatientServiceAction(formData: FormData) {
  const session = await getSession();
  if (!session) return;

  const canAdd = await hasPermission(session.userId, session.role, "view_patient_billing");
  if (!canAdd) return;

  const patientId = Number(formData.get("patient_id"));
  const serviceId = Number(formData.get("service_id"));
  const doctorId = Number(formData.get("doctor_id"));
  let visitDate = String(formData.get("visit_date") || "").trim();
  const paymentMethod = String(formData.get("payment_method") || "").trim() || null;
  const amountNow = Math.max(0, Number(formData.get("amount_now") || 0));

  if (!patientId || !serviceId || !doctorId) return;

  const today = new Date().toISOString().slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(visitDate)) visitDate = today;

  // تسجيل خدمة بتاريخ غير النهاردة ("تحصيل في يوم غير اليوم اللي دخل فيه
  // الفلوس") محصور بصلاحية edit_invoice_payments — نفس الصلاحية اللي أصلاً
  // بتحكم تعديل فاتورة اتسجلت بالفعل (مدير العيادة/المحاسب/الأدمن افتراضيًا،
  // قابلة للمنح لدكتور معيّن). الاستقبال (اللي معهوش الصلاحية دي افتراضيًا)
  // مقفول على تاريخ النهاردة بس، بغض النظر عن أي قيمة اتبعتت في الفورم.
  if (visitDate !== today) {
    const canBackdate = await hasPermission(session.userId, session.role, "edit_invoice_payments");
    if (!canBackdate) visitDate = today;
  }

  const service = await db
    .selectFrom("services")
    .select(["id", "name", "code", "default_price"])
    .where("id", "=", serviceId)
    .executeTakeFirst();
  if (!service) return;

  const isFollowup = service.code === FOLLOWUP_SERVICE_CODE;

  // ملحوظة (دفعة 21): الفورم ده دلوقتي بيسجل خدمة جديدة مستقلة دايمًا
  // (appointment_id: null) بغض النظر عن وجود أي موعد "تم" لسه محتاج تحصيل
  // لنفس المريض. الربط التلقائي القديم كان بيسبب مشكلة: أي خدمة جديدة تتضاف
  // (حتى لو خالص مالهاش علاقة بالموعد المعلّق) كانت بتقفل الموعد المعلّق
  // القديم وتمسح تفاصيله من غير ما حد يحصّل فلوسه فعليًا. دلوقتي تحصيل موعد
  // معلّق بيتم بس عن طريق بوكس التحصيل المخصص (PendingCollectionCard) اللي
  // بيستخدم recordAppointmentBillingAction ويحدد الموعد بالـ id بتاعه بنفسه.
  if (isFollowup) {
    const targetInvoiceId = Number(formData.get("target_invoice_id"));
    if (!targetInvoiceId) return;

    // تأكيد إن الفاتورة الأصلية فعلاً بتاعة نفس المريض ده (وليست دفعة متابعة
    // هي نفسها) قبل الربط، عشان مايحصلش خلط بيانات بين مرضى.
    const targetInvoice = await db
      .selectFrom("invoices")
      .innerJoin("visits", "visits.id", "invoices.visit_id")
      .select(["invoices.id"])
      .where("invoices.id", "=", targetInvoiceId)
      .where("visits.patient_id", "=", patientId)
      .where("invoices.parent_invoice_id", "is", null)
      .executeTakeFirst();
    if (!targetInvoice) return;

    const visitResult = await db
      .insertInto("visits")
      .values({
        patient_id: patientId,
        visit_date: visitDate,
        service_id: service.id,
        notes: "دفعة متابعة",
        primary_doctor_id: doctorId,
        performing_doctor_id: doctorId,
        room_id: null,
        created_by: session.userId,
        appointment_id: null,
      })
      .executeTakeFirst();
    const visitId = Number(visitResult.insertId);

    await db
      .insertInto("invoices")
      .values({
        visit_id: visitId,
        amount: 0,
        paid: amountNow,
        discount_percent: 0,
        price_overridden: 0,
        payment_method: paymentMethod,
        parent_invoice_id: targetInvoice.id,
      })
      .execute();
  } else {
    const price = Math.max(0, Number(formData.get("price") || service.default_price));
    const discountPercent = Math.min(100, Math.max(0, Number(formData.get("discount_percent") || 0)));
    const amount = Math.max(0, price * (1 - discountPercent / 100));
    const priceOverridden = Math.round(service.default_price) !== Math.round(price);

    const visitResult = await db
      .insertInto("visits")
      .values({
        patient_id: patientId,
        visit_date: visitDate,
        service_id: service.id,
        notes: null,
        primary_doctor_id: doctorId,
        performing_doctor_id: doctorId,
        room_id: null,
        created_by: session.userId,
        appointment_id: null,
      })
      .executeTakeFirst();
    const visitId = Number(visitResult.insertId);

    const invoiceResult = await db
      .insertInto("invoices")
      .values({
        visit_id: visitId,
        amount,
        paid: amountNow,
        discount_percent: discountPercent,
        price_overridden: priceOverridden ? 1 : 0,
        payment_method: paymentMethod,
        parent_invoice_id: null,
        original_price: price,
      })
      .executeTakeFirst();

    if (priceOverridden) {
      await logOverride({
        entityType: "invoice_price",
        entityId: Number(invoiceResult.insertId),
        field: "السعر",
        oldValue: service.default_price,
        newValue: price,
        changedBy: session.userId,
        reason: `تعديل سعر خدمة "${service.name}" عند الإضافة من الملف المالي`,
      });
    }
  }

  revalidatePath(`/patients/${patientId}/billing`);
  revalidatePath(`/patients/${patientId}`);
  revalidatePath("/invoices");
  revalidatePath("/front-desk");
  revalidatePath("/");
}
