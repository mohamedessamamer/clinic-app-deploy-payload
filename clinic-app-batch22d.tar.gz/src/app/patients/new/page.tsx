import { createPatientAction } from "./actions";

export default async function NewPatientPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error } = await searchParams;

  return (
    <div className="max-w-lg mx-auto space-y-5">
      <h1 className="text-xl font-bold">مريض جديد</h1>

      {error && (
        <div className="rounded-md bg-danger-soft text-danger text-sm px-3 py-2">
          من فضلك أدخل اسم المريض.
        </div>
      )}

      <form action={createPatientAction} className="card-3d rounded-xl p-5 space-y-4">
        <div>
          <label className="block text-sm text-muted mb-1">الاسم *</label>
          <input
            name="full_name"
            required
            className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-muted mb-1">تاريخ الميلاد</label>
            <input
              name="birth_date"
              type="date"
              lang="en-GB"
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <p className="text-xs text-muted mt-1">
              السن بيتحسب منه تلقائي بالسنين. تقدر تكتب التاريخ مباشرة من الكيبورد (يوم/شهر/سنة بالترتيب)، أو تكتب
              السنة بس وهتلاقي الكاليندر بيفتح عليها على طول.
            </p>
          </div>
          <div>
            <label className="block text-sm text-muted mb-1">رقم التليفون</label>
            <input
              name="phone"
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
        </div>
        <div>
          <label className="block text-sm text-muted mb-1">العنوان</label>
          <input
            name="address"
            className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
        <button
          type="submit"
          className="w-full rounded-md btn-3d-primary py-2 text-sm font-medium transition-colors"
        >
          حفظ
        </button>
      </form>
    </div>
  );
}
