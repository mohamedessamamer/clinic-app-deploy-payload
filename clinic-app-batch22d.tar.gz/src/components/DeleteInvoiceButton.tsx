"use client";

import { useTransition } from "react";
import { deleteVisitAction } from "@/app/patients/[id]/actions";

// زرار حذف مشترك لفاتورة/خدمة اتسجلت غلط — بيمسح الزيارة وفاتورتها سوا نهائيًا
// (نفس أكشن deleteVisitAction المستخدم أصلاً في سجل الزيارات بالملف الطبي، دفعة
// 12)، بس متاح كمان من صفحة "الفواتير" ومن جدول الملف المالي (دفعة 21) — عشان
// أي فاتورة غلط تتصحح من نفس الشاشة اللي بانت فيها، من غير ما تحتاج تروح لسجل
// الزيارات بالملف الطبي. محصور بصلاحية delete_visits (الأدمن بس افتراضيًا)،
// والتحقق الحقيقي في الأكشن نفسه على السيرفر مش هنا بس.
export default function DeleteInvoiceButton({
  visitId,
  patientId,
  confirmLabel,
  className,
}: {
  visitId: number;
  patientId: number;
  confirmLabel: string;
  className?: string;
}) {
  const [isPending, startTransition] = useTransition();

  return (
    <button
      type="button"
      disabled={isPending}
      onClick={(e) => {
        e.stopPropagation();
        const ok = window.confirm(`متأكد إنك عايز تمسح "${confirmLabel}" نهائيًا مع فاتورتها؟ الإجراء ده مش ممكن يترجع.`);
        if (!ok) return;
        const fd = new FormData();
        fd.set("visit_id", String(visitId));
        fd.set("patient_id", String(patientId));
        startTransition(() => {
          deleteVisitAction(fd);
        });
      }}
      className={className ?? "text-xs text-danger hover:underline disabled:opacity-60"}
    >
      حذف
    </button>
  );
}
